# Executions

## Current execution
- **EP-0002**: ACTIVE / COMPLETE (see status in `EP-0002.md`)

## Next execution
- **EP-0003**: PLANNED (not started)  
  - Start only when explicitly approved: “Approved – start EP-0003”

## Index
- `docs/executions/EP-0002.md`
- `docs/executions/EP-0003.md`
- `docs/executions/EP-0009.md`

