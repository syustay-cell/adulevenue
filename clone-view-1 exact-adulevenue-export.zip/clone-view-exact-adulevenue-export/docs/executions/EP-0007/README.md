# EP-0007 — Slice 1 Execution Record (Tenant safety + God mode gating)

This folder is a **read-only handoff record** documenting what was completed in **Slice 1** to make the app tenant-safe by default and to ensure **God mode is explicit** (never implicit).

## 1) What was implemented

### Database (Supabase / Postgres RLS)
- **`wf_tenant_users_select_own` RLS policy** on `public.wf_tenant_users`
  - Purpose: allow an authenticated user to `SELECT` **only their own** membership rows (`user_id = auth.uid()`).
- **`GRANT SELECT` to `authenticated`** on `public.wf_tenant_users`
  - Note: RLS still applies; the grant only enables the query to run.

### Frontend wiring (no UI refactors)
- **`src/hooks/useTenantScopedFetch.ts`**
  - **Super owner is tenant-scoped by default**
  - Cross-tenant behavior is **only** enabled when **God mode is ON**
  - Returned `isGodModeEnabled` so callers can reason about effective scope
- **`src/hooks/useViewAsTenant.ts`**
  - Tenant list query (`wf_tenants`) and “view as” behavior are **gated behind God mode**
  - Returned `isGodModeEnabled` for downstream gating
- **`src/components/owner/TenantSelector.tsx`**
  - Tenant selector is hidden unless **(super_owner/owner) AND God mode is ON**

### Behavioral outcome
- **God mode is now explicit, not implicit**
- **Super owner is tenant-scoped by default**

## 2) Why this exists
- **Prevent accidental cross-tenant access**
- **Prevent null-tenant cascades** (tenant context previously failed to load when membership reads were blocked by RLS)
- Enforce the non-negotiable rule:
  - **Cross-tenant access only when God mode is ON**

## 3) Verification summary
- **RLS verified via `auth.uid()`**
  - `auth.uid()` is non-null when run as an authenticated user
- **Own membership readable**
  - `SELECT ... FROM public.wf_tenant_users WHERE user_id = auth.uid()` returns only own rows (0+ rows is OK)
- **Cross-user reads blocked**
  - `SELECT count(*) FROM public.wf_tenant_users WHERE user_id <> auth.uid()` returns `0`
- **Frontend no longer leaks cross-tenant by default**
  - `useTenantScopedFetch` no longer treats `super_owner` as cross-tenant unless God mode is ON
  - “View As tenant” tooling is not available unless God mode is ON

---

⚠️ DO NOT MODIFY ANYTHING DOCUMENTED HERE.
This folder is READ-ONLY.
Future work must build ON TOP of this behavior, not change it.

