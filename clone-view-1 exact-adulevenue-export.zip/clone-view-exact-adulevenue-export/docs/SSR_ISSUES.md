# Wolf-Fund OS – SSR Issues Log

This document tracks all SSR-related fixes applied to make the codebase build-safe.

---

## 1. `src/integrations/supabase/client.ts`

**Issue:** `localStorage` was accessed at module scope, breaking SSR during AI Gateway's deployment process.

**Original Code:**
```typescript
auth: {
  storage: localStorage,
  persistSession: true,
  autoRefreshToken: true,
}
```

**Fix Applied:**
```typescript
const getStorage = () => {
  if (typeof window === 'undefined') return undefined;
  return window.localStorage;
};

// Then in createClient options:
auth: {
  storage: getStorage(),
  persistSession: true,
  autoRefreshToken: true,
}
```

**Reason:** SSR safety – `localStorage` does not exist on the server, causing build crashes.

---

## 2. `src/hooks/useAntiScreenshot.ts`

**Issue:** Uses `document`, `window`, `sessionStorage`, and `navigator` but all usages are inside `useEffect` or callback functions.

**Status:** ✅ SAFE – All browser API usages are already guarded inside React hooks (`useEffect`, `useCallback`), so they only run client-side after mount.

**No changes required.**

---

## 3. `src/components/security/ScreenGuard.tsx`

**Issue:** Uses `document` to inject styles and manipulate elements.

**Status:** ✅ SAFE – All `document` usages are inside `useEffect`, which only runs on the client after mount.

**No changes required.**

---

## General Notes

- `main.tsx` uses `document.getElementById("root")` which is safe because it's the entry point that only runs in the browser.
- All route files use React components and don't access browser APIs at module scope.
- Layout files are React components and don't access browser APIs at module scope.

---

## How to Verify Build Safety

Run:
```bash
npm run prebuild  # Scans for dangerous patterns
npm run build     # Verifies successful build
```

If either command fails, check this log and the terminal output for the specific file and line causing the issue.
