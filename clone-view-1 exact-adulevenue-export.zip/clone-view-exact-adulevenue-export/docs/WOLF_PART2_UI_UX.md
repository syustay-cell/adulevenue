# WOLF FUND – PART 2 UI/UX BRIEF

> Lead Engine, My Day, ISO Portal, Admin Reports

---

## 0. Global Style & UX Principles

### Look & Feel
- Clean, modern SaaS (think Stripe/Linear, not busy CRM)
- Light theme by default, subtle grays, plenty of white space
- Rounded corners, soft drop shadows for cards, no neon colors

### Layout
- Left sidebar for main app navigation (Dashboard, Lead Engine, ISO, Reports, etc.)
- Main content area uses:
  - Page title
  - Short one-line description
  - Cards and tables in responsive grids

### Common Components
- **Top bar**: user avatar + role ("Admin", "Worker", "ISO Partner"), quick access to settings/help
- **Toasts**: always use consistent error/success messages based on `data.ok`, `message`, `error_code`
- **Empty states**: never show just blank tables – always guide the user ("No leads yet. Upload a list to get started.")

---

## 1. /lead-engine – Lead Engine Dashboard (Admin + Workers)

### 1.1 Page Layout

**Header:**
- Title: Lead Engine
- Subtitle: "Upload, enrich, and work outbound leads."

**Content Layout:**
- 2-column layout on desktop:
  - Left: Upload & Research
  - Right: Dialer & Outreach
- On mobile: stack sections vertically

---

### 1.2 Section A – Upload Panel

**Card: "Upload Lead List"**

Elements:
- Button: "Upload CSV / Excel"
- File dropzone with:
  - Icon (cloud upload)
  - Text: "Drop a file here or click to browse"
- After upload:
  - Column mapping modal:
    - Left: detected headers (e.g. Company, Phone, ContactName)
    - Right: dropdown to map to: `business_name`, `phone`, `full_name`, `email`, `city`, `state`, `website`, etc.
  - Options:
    - Checkbox: "Run AI enrichment after import"
    - Text input: "List Name" (default to filename)

**Success state:**
- Toast: "Lead list created – 2,153 contacts imported."
- Small summary beneath: "List: East Coast HVAC, 2,153 leads. 438 missing emails, 320 missing phones."

---

### 1.3 Section B – Research Queue

**Card: "Research Queue (Enrichment)"**

**Table:**
| Column | Description |
|--------|-------------|
| Business | Company name |
| City / State | Location |
| Email | Badge: "Missing" or show email |
| Phone | Badge: "Missing" or show phone |
| Source | upload, scraped, knight_campaign, etc. |
| Actions | Buttons |

Rows show leads where:
- email or phone is null, OR
- status = 'new'

**Actions per row:**
- Button: "AI Enrich"
- Button: "Edit" (inline modal to edit fields manually)

**Bulk actions (top toolbar):**
- Checkbox column +
  - "AI Enrich Selected"
  - "Mark as Bad Data"

**Empty state text:**
> "No leads need enrichment. Great work. New uploads with missing information will appear here."

---

### 1.4 Section C – Dialer Queue

**Card: "Dialer Queue"**

Target: only leads assigned to the current worker (or pulled via `lead-assign-queue`).

**Top controls:**
- Filter chips:
  - Status: New / Contacted / Interested / Follow-up Due
  - Priority: A / B / C
- Button: "Start Session" (on click, highlight the first lead in the list)

**Main area: Active Lead Panel**
- Large display:
  - Name + Business
  - Phone (click-to-call link for softphone/VoIP or simply for reference)
  - Status pill
  - AI score / priority chip ("Priority A – 92")
- Outcome buttons (horizontal row):
  - Interested
  - No Answer
  - Voicemail
  - Bad Fit
  - Wrong Number
  - Follow Up
- Secondary:
  - "Lock for Application" (if not already locked)
  - "View History" (drawer with client_activity timeline)

**When an outcome is clicked:**
- Immediately record via `lead-record-outcome`
- Auto-advance to next lead in queue
- Show a small toast: "Outcome logged: No Answer. Moving to next lead."

---

### 1.5 Section D – Outreach Queue

**Card: "Outreach Queue (Email & SMS)"**

**Table:**
| Column | Description |
|--------|-------------|
| Lead | Name/Business |
| Channel | email / SMS |
| Last Contacted | Date |
| Next Action | e.g., "Send Step 2 email" |
| Status | queued, sent, replied |
| Actions | Buttons |

**Actions:**
- **"AI Draft & Send Email":**
  - Calls `ai-draft-outreach`
  - Shows draft in a modal with:
    - Subject (editable)
    - Body (editable)
    - Buttons: "Send" (calls `send-smart-email`), "Cancel"
- **"AI Draft & Send SMS":**
  - Similar flow, using `send-smart-sms`

**Empty state:**
> "No outreach actions due. Once you start sequences, leads needing follow-up will appear here."

---

## 2. /my-day – Worker Dashboard (All Internal Workers)

### 2.1 Layout

**Header:**
- Title: My Day
- Subtitle: "Your leads, tasks, and performance snapshot."

**Top – Three Cards (Row):**

| Card | Content |
|------|---------|
| My Leads | Big number: total leads currently assigned. Subtext: "X follow-ups due today." Small link: "Go to Lead Engine" (filters by my leads) |
| My Tasks | Number: pending worker_assignments. Subtext: "Next due: Call John @ ABC Plumbing at 3:00 PM." Button: "Open Tasks" |
| My Performance (7 days) | Small sparkline chart. Stats: Calls: X, Emails/SMS: Y, New apps started: Z |

**Middle – Task List**

Table or cards:
| Column | Description |
|--------|-------------|
| Type | Call / Email / Follow-up |
| Lead / Client | Name |
| Due At | Time |
| Status | Status |
| Quick action | e.g. "Complete" or "Go to Lead" |

**Bottom – Recent Activity**

Chronological feed from `client_activity`:
> "You emailed Jane (Funding follow-up)"  
> "You logged 'Interested' for Mike's HVAC LLC"

---

## 3. ISO Portal – /iso, /iso/submit, /iso/deals, /iso/commissions

> **Rule:** Entire ISO experience should feel simple, non-technical, and safe.
> Think of it like a "partner portal", not a dev tool.

---

### 3.1 /iso – ISO Home

**Header:**
- Title: ISO Partner Portal
- Subtitle: "Submit deals, track statuses, and view commissions."

**Show 3 cards:**

| Card | Content |
|------|---------|
| Deals In Progress | Big number: count where status not funded/declined. Subtext: "X in underwriting, Y sent to funders." |
| Funded Deals | Big number: funded count (last 90 days). Subtext: "Total funded: $X." |
| Commissions | Big number: total paid commissions. Subtext: "Pending: $Y." |

**Buttons:**
- Primary: "Submit New Deal" → `/iso/submit`
- Secondary: "View Pipeline" → `/iso/deals`

---

### 3.2 /iso/submit – Deal Submission

Create a wizard-style form (multi-step) instead of one giant form.

**Step 1: Client & Business Info**
- Fields:
  - Client Full Name
  - Business Name
  - Email
  - Phone
  - Industry (dropdown)
  - Time in Business (dropdown e.g. 0–6 months, 6–12, 1–2 yrs, 2+ yrs)
  - Monthly Revenue (approximate range)

**Step 2: Funding Request**
- Requested Amount
- Use of Funds (short textarea or dropdown list)
- Existing Advances? (Yes/No + brief details)

**Step 3: Documents**
- Upload:
  - Bank statements (3–6 months)
  - ID
  - Voided check (optional)
- Show file names + ability to remove

**Step 4: Review & Submit**
- Show summary of entered info
- Checkbox: "I confirm I have client authorization to submit this application."
- Button: "Submit Application"

**On submit:**
- Call `iso-submit-deal`
- Show thank-you screen:
  > "Deal submitted. You can track this application in your Pipeline."

---

### 3.3 /iso/deals – Pipeline

**Table:**
| Column | Description |
|--------|-------------|
| Application ID | ID |
| Client Name | Name |
| Business | Business name |
| Status | Badge |
| Requested / Funded Amount | Amount |
| Last Updated | Date |
| Actions | e.g. "View Details" |

**Filter bar:**
- Status filter: All / Intake / Docs Pending / Underwriting / Sent to Funder / Approved / Funded / Declined

ISO only sees their own deals (by `iso_partner_id`).

**Row click → slide-out panel or detail view:**
- Show:
  - Basic client + business info
  - Status timeline ("Submitted → Underwriting → Sent to Funder → Funded")
  - Notes from Wolf team if we choose to add later

---

### 3.4 /iso/commissions – Commissions

**Table:**
| Column | Description |
|--------|-------------|
| Deal / Application ID | ID |
| Client / Business | Name |
| Funded Amount | Amount |
| Commission % | Percentage |
| Commission Amount | Amount |
| Status | Pending / Scheduled / Paid |
| Paid Date | Date (if any) |
| Reference / Notes | Notes |

**At top:**
- Summaries:
  - "Total Paid: $X"
  - "Pending: $Y"
  - "Last Payment: [Date]"

---

## 4. /admin/reports – Admin Reports (Brief UX)

**Header:**
- Title: Reports & Analytics
- Subtitle: "Funding, pipeline, ISO & worker performance."

### Tabs or sections:

#### 4.1 Funding Overview
- **Cards:**
  - Total Funded (All-time, YTD, Last 30 days)
- **Chart:**
  - Monthly funded volume (bar chart)

#### 4.2 Pipeline
- **Funnel chart:**
  - Leads → Apps → Underwriting → Sent to Funder → Approved → Funded
- Table by stage

#### 4.3 ISO Performance
**Table:**
| Column | Description |
|--------|-------------|
| ISO | Name |
| Deals Submitted | Count |
| Deals Funded | Count |
| Hit Rate % | Percentage |
| Funded Volume | Amount |
| Commission Paid | Amount |

#### 4.4 Worker Performance
**Table by internal worker:**
| Column | Description |
|--------|-------------|
| Worker name | Name |
| New Leads Worked | Count |
| Calls/Emails/SMS | Count |
| Apps Started | Count |
| Funded Volume Influenced | Amount |

> Keep it visual: cards + charts + simple tables.

---

## 5. Implementation Notes

1. **All new edge functions MUST:**
   - Use `success()` / `failure()` / `optionsOk()`
   - Always respond HTTP 200 (except OPTIONS)
   - Include `message` + `error_code` for errors

2. **All new AI work:**
   - Use `safeAIRequest`
   - Log via `logAIUsage`

3. **All new frontend calls:**
   - Must check:
   ```typescript
   if (error) { /* transport */ }
   if (!data?.ok) { /* toast using message + error_code */ }
   ```
   - Never assume success without checking `data.ok`

---

## 6. TL;DR for Team/Investors

Part 2 of Wolf Fund turns the platform into a **self-feeding deal machine**.

We are adding:
- An **internal Lead Engine** where workers and AI can upload lists, enrich data, call, email, and text prospects at scale — fully tracked, with lead locks and conversion paths
- A **clean, separate ISO Portal** so external partners can submit and track their deals and commissions without ever seeing our internal leads or tools
- A **unified Reporting layer** so we can see funded volume, conversion rates, ISO performance, and worker productivity in one place
- **Data pipelines** to connect Wolf Fund funding to ABG construction projects and track how much capital is deployed into development
- **Campaign hooks** so the Knight Campaign cinematic marketing funnels feed directly into the Lead Engine and applications with clear source tracking
