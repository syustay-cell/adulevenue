# 🐺 WOLF ECOSYSTEM V1 — API ARCHITECTURE

> Complete API endpoints and backend architecture specification

---

## TABLE OF CONTENTS

1. [Architecture Overview](#1-architecture-overview)
2. [Authentication](#2-authentication)
3. [Lead Management APIs](#3-lead-management-apis)
4. [Application APIs](#4-application-apis)
5. [Underwriting APIs](#5-underwriting-apis)
6. [Credit Repair APIs](#6-credit-repair-apis)
7. [User & Role APIs](#7-user--role-apis)
8. [ISO Partner APIs](#8-iso-partner-apis)
9. [Document APIs](#9-document-apis)
10. [Communication APIs](#10-communication-apis)
11. [AI/ML Edge Functions](#11-aiml-edge-functions)
12. [Webhook Handlers](#12-webhook-handlers)
13. [Error Handling](#13-error-handling)
14. [Rate Limiting](#14-rate-limiting)

---

## 1. ARCHITECTURE OVERVIEW

### System Architecture

```
┌─────────────────────────────────────────────────────────────────────┐
│                        WOLF ECOSYSTEM ARCHITECTURE                   │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  ┌─────────────────────────────────────────────────────────────┐   │
│  │                    CLIENT LAYER                              │   │
│  │  ┌─────────┐  ┌─────────┐  ┌─────────┐  ┌─────────┐         │   │
│  │  │  React  │  │  React  │  │  React  │  │  React  │         │   │
│  │  │  Admin  │  │  Worker │  │   ISO   │  │  Client │         │   │
│  │  └────┬────┘  └────┬────┘  └────┬────┘  └────┬────┘         │   │
│  └───────┼────────────┼────────────┼────────────┼───────────────┘   │
│          │            │            │            │                   │
│  ┌───────▼────────────▼────────────▼────────────▼───────────────┐   │
│  │                   SUPABASE CLIENT SDK                        │   │
│  │  • Real-time subscriptions                                   │   │
│  │  • Auth (JWT)                                                │   │
│  │  • Storage                                                   │   │
│  │  • Database queries                                          │   │
│  └───────────────────────────┬──────────────────────────────────┘   │
│                              │                                      │
│  ┌───────────────────────────▼──────────────────────────────────┐   │
│  │                    API GATEWAY LAYER                         │   │
│  │                  (Supabase Edge Functions)                   │   │
│  │  ┌──────────────────────────────────────────────────────┐   │   │
│  │  │  Auth Middleware │ Rate Limiting │ Request Validation │   │   │
│  │  └──────────────────────────────────────────────────────┘   │   │
│  └───────────────────────────┬──────────────────────────────────┘   │
│                              │                                      │
│  ┌───────────────────────────▼──────────────────────────────────┐   │
│  │                   BUSINESS LOGIC LAYER                       │   │
│  │  ┌────────────┐ ┌────────────┐ ┌────────────┐ ┌───────────┐ │   │
│  │  │   Lead     │ │ Underwrite │ │  Credit    │ │    ISO    │ │   │
│  │  │  Engine    │ │   Engine   │ │   Repair   │ │  Partner  │ │   │
│  │  └────────────┘ └────────────┘ └────────────┘ └───────────┘ │   │
│  └───────────────────────────┬──────────────────────────────────┘   │
│                              │                                      │
│  ┌───────────────────────────▼──────────────────────────────────┐   │
│  │                      AI/ML LAYER                             │   │
│  │  ┌────────────┐ ┌────────────┐ ┌────────────┐               │   │
│  │  │  Lead      │ │ Document   │ │  Credit    │               │   │
│  │  │  Scoring   │ │    OCR     │ │  Analysis  │               │   │
│  │  └────────────┘ └────────────┘ └────────────┘               │   │
│  │  ┌────────────┐ ┌────────────┐                              │   │
│  │  │  Research  │ │  Dispute   │                              │   │
│  │  │   Intel    │ │  Letters   │                              │   │
│  │  └────────────┘ └────────────┘                              │   │
│  └───────────────────────────┬──────────────────────────────────┘   │
│                              │                                      │
│  ┌───────────────────────────▼──────────────────────────────────┐   │
│  │                    DATA LAYER                                │   │
│  │  ┌──────────────────┐  ┌──────────────────────────────────┐ │   │
│  │  │    PostgreSQL    │  │         Supabase Storage         │ │   │
│  │  │    (Supabase)    │  │  (Documents, Files, Attachments) │ │   │
│  │  └──────────────────┘  └──────────────────────────────────┘ │   │
│  └──────────────────────────────────────────────────────────────┘   │
│                                                                     │
│  ┌──────────────────────────────────────────────────────────────┐   │
│  │                 EXTERNAL INTEGRATIONS                        │   │
│  │  ┌─────────┐ ┌─────────┐ ┌─────────┐ ┌─────────┐ ┌────────┐ │   │
│  │  │ DocuSign│ │ Resend  │ │ Twilio  │ │ Clearbit│ │ AI Gateway│ │   │
│  │  │   API   │ │  Email  │ │   SMS   │ │Enrichmt │ │   AI   │ │   │
│  │  └─────────┘ └─────────┘ └─────────┘ └─────────┘ └────────┘ │   │
│  └──────────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────────┘
```

### Technology Stack

| Layer | Technology |
|-------|------------|
| Frontend | React 18, TypeScript, Tailwind CSS, shadcn/ui |
| State Management | TanStack Query, Zustand |
| Backend | Supabase Edge Functions (Deno) |
| Database | PostgreSQL (Supabase) |
| Storage | Supabase Storage |
| Auth | Supabase Auth (JWT) |
| AI/ML | AI Gateway AI Gateway (Gemini, GPT) |
| Email | Resend API |
| SMS | Twilio API |
| E-Sign | DocuSign API |
| Real-time | Supabase Realtime |

---

## 2. AUTHENTICATION

### Auth Flow

```typescript
// Client-side authentication
import { supabase } from '@/integrations/supabase/client';

// Sign up
const { data, error } = await supabase.auth.signUp({
  email: 'user@example.com',
  password: 'securePassword123',
  options: {
    data: {
      full_name: 'John Doe',
    }
  }
});

// Sign in
const { data, error } = await supabase.auth.signInWithPassword({
  email: 'user@example.com',
  password: 'securePassword123'
});

// Get session
const { data: { session } } = await supabase.auth.getSession();

// Sign out
await supabase.auth.signOut();
```

### JWT Verification in Edge Functions

```typescript
// Edge function auth middleware
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_ANON_KEY')!,
      {
        global: {
          headers: { Authorization: req.headers.get('Authorization')! },
        },
      }
    );

    // Verify user
    const { data: { user }, error } = await supabase.auth.getUser();
    if (error || !user) {
      return new Response(JSON.stringify({ error: 'Unauthorized' }), {
        status: 401,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // Check role
    const { data: roles } = await supabase
      .from('user_roles')
      .select('role')
      .eq('user_id', user.id)
      .eq('approved', true);

    // ... rest of function
  } catch (error) {
    return new Response(JSON.stringify({ error: error.message }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
```

---

## 3. LEAD MANAGEMENT APIs

### 3.1 Lead Import & Processing

#### `process-lead-list`
Process uploaded Excel/CSV files.

```typescript
// POST /functions/v1/process-lead-list
interface ProcessLeadListRequest {
  listId: string;
  sourceType?: 'ocm' | 'iso' | 'purchased' | 'generic';
  isoPartnerId?: string;
}

interface ProcessLeadListResponse {
  success: boolean;
  listId: string;
  stats: {
    total: number;
    dialer: number;
    email: number;
    research: number;
    rejected: number;
    qualityScore: number;
  };
  headerMapping: Record<string, string>;
}
```

#### `lead-enrich-classify`
AI enrichment and classification.

```typescript
// POST /functions/v1/lead-enrich-classify
interface LeadEnrichRequest {
  leadId: string;
}

interface LeadEnrichResponse {
  leadId: string;
  enrichedData: {
    business_age_years: number;
    estimated_revenue: number;
    industry: string;
    employee_count: string;
    website: string;
  };
  aiScore: number;
  aiPriority: 'A' | 'B' | 'C' | 'D';
  recommendedPath: 'funding_first' | 'credit_first' | 'hybrid' | 'do_not_work';
  riskFlags: string[];
}
```

### 3.2 Research Queue APIs

#### `wolf-research-intel`
Deep AI research on leads.

```typescript
// POST /functions/v1/wolf-research-intel
interface ResearchIntelRequest {
  lead_id: string;
}

interface ResearchIntelResponse {
  lead_id: string;
  funding_score: number;
  funding_recommendation: string;
  credit_risk: string;
  identity_theft_risk: string;
  industry_risk: string;
  business_age_years: number;
  estimated_revenue: number;
  
  // OCM-specific
  license_status?: string;
  expiration_window?: string;
  municipality?: string;
  zoning_risk?: string;
  
  mystic_tips: {
    call_script: string;
    questions: string[];
    weak_points: string[];
    recommended_offer: string;
  };
}
```

### 3.3 Dialer APIs

#### Database Functions (RPC)

```typescript
// Get next lead for dialer worker
const { data: lead, error } = await supabase
  .rpc('get_next_lead_for_worker', { p_worker_id: userId });

// Mark call outcome
const { error } = await supabase
  .rpc('mark_call_outcome', {
    p_lead_id: leadId,
    p_worker_id: userId,
    p_outcome: 'answered',
    p_next_action: 'send_intake',
    p_callback_at: null
  });

// Claim research lead
const { data: lead, error } = await supabase
  .rpc('claim_next_research_lead', { p_worker_id: userId });

// Lock lead for application
const { error } = await supabase
  .rpc('lock_lead_for_application', {
    p_lead_id: leadId,
    p_worker_id: userId,
    p_days: 7
  });

// Request lead release
const { data: request, error } = await supabase
  .rpc('request_lead_release', {
    p_lead_id: leadId,
    p_from_worker_id: userId
  });

// Respond to release request
const { error } = await supabase
  .rpc('respond_to_lead_release', {
    p_request_id: requestId,
    p_responder_id: userId,
    p_response: 'release' // or 'split_50_50' or 'reject'
  });
```

---

## 4. APPLICATION APIs

### 4.1 Fast Track Applications

```typescript
// Create application
const { data, error } = await supabase
  .from('fast_track_applications')
  .insert({
    email: 'client@example.com',
    phone: '5551234567',
    business_name: 'ABC Corp',
    in_business_over_6_months: true,
    has_previous_loan: false,
    user_id: userId,
    lead_id: leadId
  })
  .select()
  .single();

// Update application status
const { error } = await supabase
  .from('fast_track_applications')
  .update({ status: 'in_review' })
  .eq('id', applicationId);

// Get applications for admin
const { data, error } = await supabase
  .from('fast_track_applications')
  .select(`
    *,
    lead:leads(*),
    underwriting:underwriting_cases(*)
  `)
  .order('created_at', { ascending: false });
```

### 4.2 Application Document Upload

```typescript
// Upload document to storage
const { data, error } = await supabase.storage
  .from('fast-track-documents')
  .upload(`${applicationId}/bank_statement_1.pdf`, file);

// Update application with document path
const { error: updateError } = await supabase
  .from('fast_track_applications')
  .update({
    bank_statements: [...existingStatements, data.path]
  })
  .eq('id', applicationId);
```

---

## 5. UNDERWRITING APIs

### 5.1 Underwriting Analysis

#### `underwriter-analyze-application`
AI-powered financial analysis.

```typescript
// POST /functions/v1/underwriter-analyze-application
interface AnalyzeRequest {
  applicationId: string;
  applicationType: 'fast_track' | 'loan';
}

interface AnalyzeResponse {
  caseId: string;
  fundabilityStatus: 'fundable' | 'conditional' | 'not_fundable';
  riskLevel: 'low' | 'medium' | 'high' | 'borderline';
  
  bankingMetrics: {
    avgMonthlyRevenue: number;
    avgDailyBalance: number;
    lowestBalance: number;
    nsfCount: number;
    negativeDays: number;
    monthsAnalyzed: number;
  };
  
  existingFunding: {
    detected: boolean;
    positions: Array<{
      lender: string;
      dailyPayment: number;
      estimatedBalance: number;
      verified: boolean;
    }>;
    totalEstimatedBalance: number;
  };
  
  riskFlags: string[];
  
  aiRecommendations: string;
  funderSummary: string;
}
```

#### `verify-bank-statement`
Vision AI bank statement parsing.

```typescript
// POST /functions/v1/verify-bank-statement
interface VerifyBankStatementRequest {
  filePath: string;
  applicationId: string;
}

interface VerifyBankStatementResponse {
  success: boolean;
  extractedData: {
    monthlyRevenue: number[];
    avgDailyBalance: number;
    nsfCount: number;
    negativeDays: number;
    recurringDebits: Array<{
      description: string;
      amount: number;
      frequency: string;
    }>;
    largeDeposits: Array<{
      date: string;
      amount: number;
      type: string;
    }>;
  };
}
```

### 5.2 Legal Risk Scanning

#### `legal-risk-scan`
Public records and legal issue detection.

```typescript
// POST /functions/v1/legal-risk-scan
interface LegalRiskScanRequest {
  name: string;
  business_name: string;
  state?: string;
}

interface LegalRiskScanResponse {
  riskLevel: 'low' | 'medium' | 'high';
  findings: {
    courtCases: Array<{
      caseNumber: string;
      type: string;
      status: string;
      date: string;
    }>;
    liens: Array<{
      type: string;
      amount: number;
      filedDate: string;
    }>;
    bankruptcies: Array<{
      chapter: string;
      status: string;
      filedDate: string;
    }>;
    uccFilings: Array<{
      filingNumber: string;
      secured_party: string;
      date: string;
    }>;
  };
  summary: string;
}
```

### 5.3 Funder Submission

#### `send-to-funder`
Send application package to funders.

```typescript
// POST /functions/v1/send-to-funder
interface SendToFunderRequest {
  applicationId: string;
  applicationType: string;
  funderIds: string[];
  shareLevel: 'summary_only' | 'summary_with_docs' | 'full_package';
  customMessage?: string;
}

interface SendToFunderResponse {
  success: boolean;
  submissionIds: string[];
  emailsSent: number;
}
```

---

## 6. CREDIT REPAIR APIs

### 6.1 Case Management

```typescript
// Create credit repair case
const { data, error } = await supabase
  .from('credit_repair_cases')
  .insert({
    credit_repair_application_id: applicationId,
    original_application_id: originalAppId,
    original_application_type: 'fast_track',
    from_declined_funding: true,
    assigned_specialist_id: specialistId
  })
  .select()
  .single();

// Update case status
const { error } = await supabase
  .from('credit_repair_cases')
  .update({ status: 'investigation' })
  .eq('id', caseId);
```

### 6.2 AI Analysis Functions

#### `credit-repair-analyze-report`
Analyze uploaded credit report.

```typescript
// POST /functions/v1/credit-repair-analyze-report
interface AnalyzeReportRequest {
  caseId: string;
  reportFilePath: string;
}

interface AnalyzeReportResponse {
  items: Array<{
    creditorName: string;
    accountNumber: string;
    itemType: string;
    balance: number;
    sourceBureau: string;
    disputeRecommendation: string;
    riskTags: string[];
  }>;
  summary: {
    totalItems: number;
    highPriorityItems: number;
    estimatedRemovalRate: number;
    estimatedTimeframe: string;
  };
}
```

#### `credit-repair-generate-strategy`
Generate dispute strategy with compliance codes.

```typescript
// POST /functions/v1/credit-repair-generate-strategy
interface GenerateStrategyRequest {
  caseId: string;
}

interface GenerateStrategyResponse {
  strategy: {
    phase1Items: string[];
    phase2Items: string[];
    estimatedTimeline: string;
  };
  complianceMapping: Array<{
    itemId: string;
    metro2Code: string;
    fcraSection: string;
    fdcpaSection: string;
    disputeBasis: string;
  }>;
}
```

#### `credit-repair-generate-letters`
Generate dispute letters.

```typescript
// POST /functions/v1/credit-repair-generate-letters
interface GenerateLettersRequest {
  caseId: string;
  itemIds: string[];
}

interface GenerateLettersResponse {
  letters: Array<{
    id: string;
    target: 'bureau' | 'creditor' | 'collector';
    targetName: string;
    subject: string;
    body: string;
    itemId: string;
  }>;
}
```

#### `send-dispute-letters`
Send approved letters.

```typescript
// POST /functions/v1/send-dispute-letters
interface SendDisputeLettersRequest {
  letterIds: string[];
  sendMethod: 'email' | 'print' | 'certified_mail';
}

interface SendDisputeLettersResponse {
  success: boolean;
  sentCount: number;
  trackingNumbers?: string[];
}
```

### 6.3 Credit Eligibility Check

#### `wolf-credit-screener`
Soft credit check for eligibility.

```typescript
// POST /functions/v1/wolf-credit-screener
interface CreditScreenerRequest {
  case_id?: string;
  lead_id?: string;
  application_id?: string;
}

interface CreditScreenerResponse {
  eligibilityStatus: 'funding_ready' | 'needs_credit_clean' | 'high_risk' | 'unknown';
  softScore: number;
  riskFlags: string[];
  notes: {
    summary: string;
    recommendations: string[];
  };
}
```

---

## 7. USER & ROLE APIs

### 7.1 Role Management

```typescript
// Check user role
const hasRole = async (userId: string, role: string) => {
  const { data, error } = await supabase
    .rpc('has_role', { _user_id: userId, _role: role });
  return data;
};

// Get user roles
const { data: roles } = await supabase
  .from('user_roles')
  .select('*')
  .eq('user_id', userId);

// Approve worker (admin only)
const { error } = await supabase
  .from('user_roles')
  .update({
    approved: true,
    approved_by: adminId,
    approved_at: new Date().toISOString()
  })
  .eq('user_id', workerId)
  .eq('role', 'worker');
```

### 7.2 Worker Session Management

```typescript
// Start call session
const { data: session, error } = await supabase
  .from('call_sessions')
  .insert({
    worker_id: userId,
    is_active: true
  })
  .select()
  .single();

// End call session
const { error } = await supabase
  .from('call_sessions')
  .update({
    is_active: false,
    ended_at: new Date().toISOString()
  })
  .eq('id', sessionId);

// Log worker activity
const { error } = await supabase
  .from('worker_activity_logs')
  .insert({
    worker_id: userId,
    action_type: 'call',
    lead_id: leadId,
    details: { outcome: 'connected', duration: 180 }
  });
```

---

## 8. ISO PARTNER APIs

### 8.1 ISO Applications

```typescript
// Submit ISO application
const { data, error } = await supabase
  .from('iso_partner_applications')
  .insert({
    full_name: 'John Partner',
    email: 'john@isocompany.com',
    phone: '5551234567',
    company_name: 'ISO Funding Inc',
    funding_type: 'MCA',
    monthly_deals: '10-20'
  })
  .select()
  .single();

// Approve ISO partner
const { error } = await supabase
  .from('iso_partner_applications')
  .update({
    status: 'approved',
    approved: true,
    approved_by: adminId,
    approved_at: new Date().toISOString()
  })
  .eq('id', applicationId);
```

### 8.2 ISO Commission Tracking

```typescript
// Get ISO commissions
const { data, error } = await supabase
  .from('iso_commissions')
  .select(`
    *,
    funded_contract:funded_contracts(*),
    iso_partner:iso_partner_applications(*)
  `)
  .eq('iso_partner_id', partnerId);

// Calculate commission
const { data, error } = await supabase
  .rpc('calculate_iso_commission', {
    p_funded_contract_id: contractId,
    p_iso_partner_id: partnerId
  });
```

---

## 9. DOCUMENT APIs

### 9.1 Document Upload

```typescript
// Upload to specific bucket
const uploadDocument = async (
  bucket: string,
  path: string,
  file: File
) => {
  const { data, error } = await supabase.storage
    .from(bucket)
    .upload(path, file, {
      cacheControl: '3600',
      upsert: false
    });
  return { data, error };
};

// Get signed URL for viewing
const getSignedUrl = async (bucket: string, path: string) => {
  const { data, error } = await supabase.storage
    .from(bucket)
    .createSignedUrl(path, 3600); // 1 hour expiry
  return data?.signedUrl;
};
```

### 9.2 Document OCR

#### `extract-all-documents`
Extract data from all application documents.

```typescript
// POST /functions/v1/extract-all-documents
interface ExtractDocumentsRequest {
  applicationId: string;
  applicationType: string;
}

interface ExtractDocumentsResponse {
  extractions: Array<{
    documentType: string;
    parsedData: Record<string, any>;
    confidence: number;
  }>;
}
```

#### `extract-id-fields`
OCR for driver's license.

```typescript
// POST /functions/v1/extract-id-fields
interface ExtractIdRequest {
  filePath: string;
  applicationId: string;
}

interface ExtractIdResponse {
  full_name: string;
  address: string;
  city: string;
  state: string;
  zip: string;
  dob: string;
  license_number: string;
  expiration_date: string;
}
```

### 9.3 E-Signature

#### `initiate-docusign`
Send document for signature.

```typescript
// POST /functions/v1/initiate-docusign
interface InitiateDocuSignRequest {
  recipientEmail: string;
  recipientName: string;
  documentType: 'iso_agreement' | 'credit_repair_agreement' | 'client_engagement';
  relatedId: string;
  templateVariables?: Record<string, string>;
}

interface InitiateDocuSignResponse {
  envelopeId: string;
  signingUrl: string;
  requestId: string;
}
```

---

## 10. COMMUNICATION APIs

### 10.1 Email Notifications

#### `send-notification-email`
Base email sending function.

```typescript
// POST /functions/v1/send-notification-email
interface SendEmailRequest {
  to: string;
  subject: string;
  html: string;
  templateName?: string;
}

interface SendEmailResponse {
  success: boolean;
  messageId: string;
}
```

#### `notify-status-change`
Application status change notification.

```typescript
// POST /functions/v1/notify-status-change
interface StatusChangeRequest {
  applicationId: string;
  applicationType: string;
  newStatus: string;
  recipientEmail: string;
}
```

### 10.2 SMS Notifications

#### `send-sms-notification`
Twilio SMS integration.

```typescript
// POST /functions/v1/send-sms-notification
interface SendSmsRequest {
  to: string;
  message: string;
}

interface SendSmsResponse {
  success: boolean;
  sid: string;
}
```

### 10.3 Follow-Up System

#### `check-follow-ups`
Scheduled function for follow-up reminders.

```typescript
// POST /functions/v1/check-follow-ups
// Called by cron job daily

interface FollowUpResult {
  checked: number;
  remindersent: number;
  applications: string[];
}
```

---

## 11. AI/ML EDGE FUNCTIONS

### 11.1 Lead Intelligence

| Function | Purpose | Model |
|----------|---------|-------|
| `wolf-brain-lead-intake` | Initial lead scoring | Gemini 2.5 Flash |
| `wolf-brain-enrich-lead` | Deep enrichment | Gemini 2.5 Flash |
| `wolf-research-intel` | Full research profile | Gemini 2.5 Pro |
| `lead-enrich-classify` | Classification | Gemini 2.5 Flash |

### 11.2 Document Processing

| Function | Purpose | Model |
|----------|---------|-------|
| `verify-bank-statement` | Bank statement OCR | Gemini 2.5 Flash (Vision) |
| `extract-id-fields` | ID document OCR | Gemini 2.5 Flash (Vision) |
| `extract-all-documents` | Multi-doc extraction | Gemini 2.5 Flash (Vision) |

### 11.3 Credit Repair

| Function | Purpose | Model |
|----------|---------|-------|
| `credit-repair-analyze-report` | Credit report analysis | Gemini 2.5 Pro |
| `credit-repair-generate-strategy` | Dispute strategy | Gemini 2.5 Pro |
| `credit-repair-generate-letters` | Letter generation | Gemini 2.5 Flash |

### 11.4 Chat & Assistant

| Function | Purpose | Model |
|----------|---------|-------|
| `chat-assistant` | Homepage chatbot | Gemini 2.5 Flash |
| `wolf-assistant` | Internal help assistant | Gemini 2.5 Flash |
| `underwriter-assistant` | Underwriting Q&A | Gemini 2.5 Pro |

### AI Gateway AI Gateway Integration

```typescript
// Using AI Gateway AI Gateway
const response = await fetch('https://wolf-fund.com/api/v1/ai/chat', {
  method: 'POST',
  headers: {
    'Authorization': `Bearer ${Deno.env.get('AI_GATEWAY_API_KEY')}`,
    'Content-Type': 'application/json',
  },
  body: JSON.stringify({
    model: 'google/gemini-2.5-flash',
    messages: [
      { role: 'system', content: systemPrompt },
      { role: 'user', content: userPrompt }
    ],
    response_format: { type: 'json_object' }
  }),
});

const result = await response.json();
```

---

## 12. WEBHOOK HANDLERS

### 12.1 DocuSign Webhook

#### `docusign-webhook`
Handle DocuSign envelope events.

```typescript
// POST /functions/v1/docusign-webhook
// Validates HMAC signature from DocuSign

// Events handled:
// - envelope-completed: Document signed
// - envelope-declined: Signature declined
// - envelope-voided: Document voided

interface DocuSignWebhookPayload {
  event: string;
  envelopeId: string;
  status: string;
  recipientEmail: string;
}
```

### 12.2 Billing Webhook

#### `billing-webhook`
Handle Stripe payment events.

```typescript
// POST /functions/v1/billing-webhook
// Events: checkout.session.completed, invoice.paid, subscription.*
```

### 12.3 Lead Intake Webhook

#### `lead-intake-router`
External lead intake API.

```typescript
// POST /functions/v1/lead-intake-router
interface LeadIntakeRequest {
  source: string;
  api_key: string;
  lead: {
    name: string;
    email: string;
    phone: string;
    business_name: string;
    requested_amount?: number;
  };
}
```

---

## 13. ERROR HANDLING

### Standard Error Response

```typescript
interface ApiError {
  error: string;
  code?: string;
  details?: Record<string, any>;
}

// HTTP Status Codes
// 200 - Success
// 201 - Created
// 400 - Bad Request (validation error)
// 401 - Unauthorized (not authenticated)
// 403 - Forbidden (not authorized)
// 404 - Not Found
// 409 - Conflict (duplicate)
// 422 - Unprocessable Entity
// 429 - Too Many Requests
// 500 - Internal Server Error
```

### Error Handling Pattern

```typescript
try {
  // ... operation
} catch (error) {
  console.error('Operation failed:', error);
  
  // Log to audit
  await supabase.from('audit_logs').insert({
    user_id: userId,
    action_type: 'error',
    resource_type: 'operation',
    resource_id: resourceId,
    changes: { error: error.message }
  });
  
  return new Response(
    JSON.stringify({ error: 'Operation failed', details: error.message }),
    { status: 500, headers: corsHeaders }
  );
}
```

---

## 14. RATE LIMITING

### Rate Limits by Endpoint Type

| Endpoint Type | Limit | Window |
|---------------|-------|--------|
| Authentication | 10 | 15 min |
| Lead Import | 5 | 1 min |
| AI Analysis | 30 | 1 min |
| Email Send | 100 | 1 hour |
| SMS Send | 50 | 1 hour |
| Document Upload | 20 | 1 min |
| General API | 100 | 1 min |

### Implementation

```typescript
// Rate limiting with Upstash Redis (optional)
import { Ratelimit } from '@upstash/ratelimit';
import { Redis } from '@upstash/redis';

const ratelimit = new Ratelimit({
  redis: Redis.fromEnv(),
  limiter: Ratelimit.slidingWindow(100, '1 m'),
});

const { success, limit, reset, remaining } = await ratelimit.limit(userId);

if (!success) {
  return new Response(
    JSON.stringify({ error: 'Rate limit exceeded' }),
    {
      status: 429,
      headers: {
        ...corsHeaders,
        'X-RateLimit-Limit': limit.toString(),
        'X-RateLimit-Remaining': remaining.toString(),
        'X-RateLimit-Reset': reset.toString(),
      }
    }
  );
}
```

---

## DEPLOYMENT

### Edge Function Deployment

```bash
# Deploy all functions
supabase functions deploy

# Deploy specific function
supabase functions deploy wolf-brain-lead-intake

# Set secrets
supabase secrets set AI_GATEWAY_API_KEY=xxx
supabase secrets set RESEND_API_KEY=xxx
supabase secrets set TWILIO_ACCOUNT_SID=xxx
supabase secrets set TWILIO_AUTH_TOKEN=xxx
supabase secrets set DOCUSIGN_INTEGRATION_KEY=xxx
```

### Environment Variables

| Variable | Description |
|----------|-------------|
| `SUPABASE_URL` | Supabase project URL |
| `SUPABASE_ANON_KEY` | Supabase anon key |
| `SUPABASE_SERVICE_ROLE_KEY` | Service role key |
| `AI_GATEWAY_API_KEY` | AI Gateway AI Gateway key |
| `RESEND_API_KEY` | Resend email API key |
| `TWILIO_ACCOUNT_SID` | Twilio account SID |
| `TWILIO_AUTH_TOKEN` | Twilio auth token |
| `TWILIO_PHONE_NUMBER` | Twilio sender number |
| `DOCUSIGN_INTEGRATION_KEY` | DocuSign integration key |
| `DOCUSIGN_SECRET_KEY` | DocuSign secret key |
| `DOCUSIGN_ACCOUNT_ID` | DocuSign account ID |

---

*Document Version: 1.0*
*Last Updated: December 2, 2024*
*Wolf Ecosystem V1 Specification*
