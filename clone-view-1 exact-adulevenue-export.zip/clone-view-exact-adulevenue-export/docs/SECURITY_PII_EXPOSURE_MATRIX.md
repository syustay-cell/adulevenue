# PII Exposure Audit (UI-only) — PII Exposure Matrix

Scope: **UI-only inspection + documentation + minimal UI masking/conditional rendering patches**. No schema/RLS/workflow/API changes.

## Definitions (audit-specific)

- **Client PII (high risk)**: any raw client identifiers (phone number, email address; also name/address/SSN/EIN when shown alongside lead/client record).
- **Owner**: role set includes `owner` or `super_owner` (UI check: `canViewRawPii`)  
  Evidence:

```3:5:src/lib/masking.ts
export function canViewRawPii(roles: AppRole[]): boolean {
  return hasRole(roles, ["owner", "super_owner"]);
}
```

- **Non-owner**: any other role (worker/dialer/partner/legal/etc) — **must not see raw phone/email in UI**.

## PII Exposure Matrix (client identifiers)

Legend:
- **Masking location**: where masking/owner-only rendering is enforced (file:line).
- **Role visibility**: what the UI will render for **Owner** vs **Non-owner**.
- **Copy/export risk**: whether the UI renders copyable text for the field (even if masked).

| Screen / Route | Component | Field | Masking location (file:line) | Role visibility (Owner / Non-owner) | Copy/export risk |
|---|---|---|---|---|---|
| Puzzle Panel (header) | `PuzzlePanelHeader` | `phone_primary`, `email_primary` links + TTS text | `src/components/puzzle-panel/PuzzlePanelHeader.tsx:18-55,83-115` | **Owner**: raw + `tel:`/`mailto:` links; **Non-owner**: masked text, no links; ListenButton reads masked values | Yes (masked for non-owner) |
| Global search results | `SearchResultRow` | `phone_primary`, `email_primary` | `src/components/global-search/SearchResultRow.tsx:14-63` | **Owner**: raw; **Non-owner**: masked | Yes (masked for non-owner) |
| Worker Dialer Queue (`/worker/queue`) | `CurrentLeadCard` | `lead.phone`, `lead.email` display + call action | `src/components/dialer/CurrentLeadCard.tsx:28-39,106-122` | **Owner**: raw + call allowed; **Non-owner**: masked display; call blocked (no `tel:` navigation) | Yes (masked for non-owner) |
| Worker Dialer Queue (`/worker/queue`) | `ClientWorkspaceDrawer` | `lead.phone`, `lead.email` | `src/components/dialer/ClientWorkspaceDrawer.tsx:273-296` | **Owner**: raw + links; **Non-owner**: masked text, no links | Yes (masked for non-owner) |
| Worker Dialer Queue (`/worker/queue`) | `ClientProfileDrawer` | `lead.phone`, `lead.email` | `src/components/dialer/ClientProfileDrawer.tsx:18-92` | **Owner**: raw + links; **Non-owner**: masked text, no links | Yes (masked for non-owner) |
| Worker Dialer Queue (`/worker/queue`) | `LeadQuickInfoPopup` | popup “Quick Info” (multiple PII fields) | `src/components/dialer/LeadQuickInfoPopup.tsx:11-72` | **Owner**: full content; **Non-owner**: **Access denied** panel (no PII rendered) | No (blocked for non-owner) |
| Worker Dialer Queue (`/worker/queue`) | `MyFollowUpsPanel` | outreach task “to” (phone/email) | `src/components/dialer/MyFollowUpsPanel.tsx:259-264` | **Owner**: raw; **Non-owner**: masked | Yes (masked for non-owner) |
| Worker Dialer Queue (`/worker/queue`) | `DialerMessagingPanel` | shows phone/email in badges + success toasts | `src/components/dialer/DialerMessagingPanel.tsx:39-52,193-218` | **Owner**: raw; **Non-owner**: masked in badges and toast strings | Yes (masked for non-owner) |
| Worker Follow-Ups (`/worker/follow-ups`) | `FollowUpDashboard` | `lead.phone` display + `tel:` call action | `src/pages/FollowUpDashboard.tsx:107-117` (call blocked), and masked phone in list | **Owner**: raw + call allowed; **Non-owner**: masked phone; call blocked + disabled buttons | Yes (masked for non-owner) |
| Worker Pipeline (`/worker/pipeline`) | `MyPipelinePage` | `lead.email`, `lead.phone` | `src/pages/MyPipeline.tsx:29-33,152-162` | **Owner**: raw; **Non-owner**: masked | Yes (masked for non-owner) |
| Lead Engine: Lead list viewer (modal) | `LeadListsPanel` | raw imported “Phone/Email” columns | `src/components/lead-engine/LeadListsPanel.tsx:337-364` | **Owner**: raw; **Non-owner**: masked | Yes (masked for non-owner) |
| Lead Engine: Full lead profile drawer | `LeadProfileDrawer` | full extracted lead profile (includes phone/email/address/etc) | `src/components/lead-engine/LeadProfileDrawer.tsx:111-133` | **Owner**: full content; **Non-owner**: **Access denied** panel | No (blocked for non-owner) |
| Lead Engine: AI Research profile drawer | `ResearchProfileDrawer` | enriched phone/email + intelligence | `src/components/lead-engine/ResearchProfileDrawer.tsx:28-74` | **Owner**: full content; **Non-owner**: **Access denied** panel | No (blocked for non-owner) |
| Credit Fix case detail | `CreditFixCaseDetail` | application `phone`, `email` links | `src/components/credit-fix/CreditFixCaseDetail.tsx:167-194` | **Owner**: raw + links; **Non-owner**: masked text, no links | Yes (masked for non-owner) |
| Shared UI component | `ClickablePhone`, `ClickableEmail` | any phone/email passed in props | `src/components/ui/clickable-contact.tsx:12-68` | **Owner**: clickable link; **Non-owner**: masked, non-clickable | Yes (masked for non-owner) |

## UI-only patches applied (this branch)

- **Mask PII outside owner-only surfaces**: commit `36f9e6e`
- **Mask PII in dialer messaging + lead list views**: commit `96ae887`
- **Mask phone + block `tel:` for non-owners on follow-ups**: commit `1106f9b`
- **Mask phone/email in worker pipeline**: commit `fd2c8ca`

## Residual risks / BLOCKERS (not fixable UI-only)

These are **intentionally not “fixed”** in this audit because they require backend/system-mediated comms (your upcoming #2).

- **Client-side raw identifiers still exist in memory/payloads**: some components still call edge functions with `to_phone` / `to_email` directly from client state (example evidence: `SmartSmsPanel` passes `to_phone: smsLead.phone` in `src/components/lead-engine/SmartSmsPanel.tsx:65-79`). UI masking prevents casual copying but does not prevent a malicious user with devtools from extracting values.
- **Any `tel:` navigation from non-owner must be replaced by system-mediated call**: UI now blocks in key places, but the underlying comms architecture (server-side resolution + masked UI) is still the real enforcement boundary.

## Notes (out of scope for this matrix)

- Public site “Contact/Terms” pages may contain the company’s own phone/email; those are **not client PII** and are excluded from the matrix.
