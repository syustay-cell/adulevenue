# TLC Multi-Domain Invariants Charter

This charter defines the permanent guardrails for the TLC multi-domain
system. These are not features or implementation steps. Any proposal that
violates these invariants is rejected by default.

## Invariants

1) One backend, one source of truth
- Wolf OS is the single authoritative backend.
- No duplicate Supabase projects, no shadow databases, no parallel systems.

2) Public sites never touch the database directly
- All public interactions route through existing Wolf OS intake endpoints.
- Public sites do not connect to the database.

3) Mandatory, consistent metadata tagging
- Every public submission includes: source_domain, source_site, program,
  and intent.
- If it cannot be tagged, it does not ship.

4) Explicit, unique domain-to-program mapping
- Each public domain maps to one and only one program slug.
- No ambiguous or shared mappings across domains.

5) Strict narrative separation by domain
- National sites stay institutional and evergreen.
- State pilot sites stay local and dynamic.
- Content must not blur these roles.

6) No new auth systems
- If public auth ever exists, it uses the same backend identity spine.
- No separate or parallel auth models.

7) Tight security boundaries
- No broad CORS wildcards for sensitive endpoints.
- Public exposure remains strictly limited and intentional.

