# 🚀 WOLF FUND – LEAD ENGINE V3

**Full Developer + QA Technical Specification**

Upload → Extraction → Routing → Research Q → Dialer → Credit Fix

---

## SECTION 1 — SYSTEM OVERVIEW

Lead Engine V3 is the core pipeline for turning uploaded lists into qualified leads, filtered into the correct workflows:

### 1. Upload & Extraction
- User uploads CSV/XLSX into Upload & Extract
- System identifies headers → maps field names → normalizes phones/emails → computes quality
- File becomes one of two source types:
  - **OCM** (dispensaries, licenses, cannabis)
  - **Generic**

### 2. Routing Engine

Every row is automatically assigned a route:

| Condition | Route | Bucket | Notes |
|-----------|-------|--------|-------|
| Valid Phone | `dialer` | Dialer bucket | Highest priority |
| No phone, but valid email | `email` | Email-only bucket | Secondary |
| No phone & no email | `research` | Research Q | Needs enrichment |
| Missing business + missing contact | `reject` | Reject bucket | Discard |

### 3. Research Q (AI-Funded Intelligence)

For research leads:
- AI analyzes:
  - Funding Score (0–100)
  - Funding Path (Funding First / Credit First / Hybrid / Do Not Work)
  - Credit Risk
  - Identity Theft Risk
  - Industry Risk
  - OCM license intelligence (if available)
- UI shows a detailed Research Profile Drawer.

### 4. Dialer Workflow
- Loads Dialer leads in FIFO with scoring.
- Worker presses:
  - Connected / No Answer / Voicemail / Callback / Wrong Number / Not Interested / Skip
- System updates lead status → auto-advances to next.

### 5. Credit Fix Integration
- Any lead can be routed to Credit Repair Studio.
- Future: auto-detect bad credit → auto-route to Credit Fix Back Office.

---

## SECTION 2 — DATA MODEL

### lead_lists Table

Stores uploaded file metadata.

| Column | Description |
|--------|-------------|
| `id` | Primary key |
| `status` | pending, processing, completed, failed |
| `total_rows` | # rows found |
| `processed_rows` | # rows usable |
| `dialer_count` | # routed to dialer |
| `email_count` | # routed to email |
| `research_count` | # routed to research |
| `rejected_count` | # rejected |
| `header_confidence` | 0–100 rating |
| `field_coverage` | % of phone/email coverage |
| `raw_headers` | array of original headers |
| `header_mapping` | full mapping object |
| `import_quality_score` | 0–100 |
| `source_type` | ocm_upload or generic_upload |
| `error_message` | failure reason |

---

### leads Table — Key Fields

| Column | Type | Notes |
|--------|------|-------|
| `business_name` | text | |
| `full_name` | text | |
| `phone` | text (normalized 10-digit) | |
| `email` | text | |
| `address/city/state/zip` | text | |
| `normalized_fields` | JSON | |
| `raw_data` | JSON | |
| `route` | dialer, email, research, reject | |
| `import_bucket` | same as route | |
| `research_status` | pending, completed | |
| `import_confidence_score` | 0–100 | |
| `ocm_license_id` | text | |
| `ocm_status` | text | |
| `ocm_expiration_date` | date | |
| `enriched_name` | text | |
| `enriched_phone` | text | |
| `enriched_email` | text | |
| `funding_score` | number | |
| `funding_recommendation` | text | |
| `credit_risk` | text | |
| `industry_risk` | text | |
| `ai_notes` | JSON | |

---

## SECTION 3 — EDGE FUNCTIONS

### ✔ process-lead-list

**Location:** `supabase/functions/process-lead-list/index.ts`

Handles:
- Parsing XLSX/CSV
- Header detection (first row with ≥3 fields)
- AI-like scoring system
- Routing logic
- Import Quality Score calculation
- OCM license extraction

**Routing Logic:**
```
if phone exists → dialer
else if email exists → email
else if neither → research
if business and contact missing → reject
```

**Confidence Scoring:**
- +20 business
- +10 name
- +25 phone
- +20 email
- +10 city/state
- +10 license
- +5 expiration

Max score 100.

**OCM Detection:**
- If headers include "license", "dispensary", "cannabis", etc.
- Source = `ocm_upload`

---

### ✔ research-intel

**Location:** `supabase/functions/research-intel/index.ts`

Given a lead:
- Pulls normalized + enriched fields
- Sends profile to AI Gateway AI
- AI returns JSON:
  - `funding_score`
  - `funding_recommendation`
  - `credit_risk`
  - `identity_theft_risk`
  - `business_age_years`
  - `estimated_revenue`
  - `industry_risk`
  - `notes[]`

Fallback logic included.

Updates lead DB and logs event.

---

## SECTION 4 — FRONTEND LOGIC

### Upload & Extract
- User selects file → file uploaded → function invoked → UI polls for status.
- Show summary card:
  - Source
  - Header confidence
  - Dialer / Email / Research / Reject counts
  - Quality badge color

---

### Research Queue

**Location:** `src/components/lead-engine/ResearchQueue.tsx`

Columns:
- Business
- Contact
- Missing Fields
- Route
- AI Funding Score (if exists)
- Status

**Action:** Run Research Q

Opens Drawer:
- Funding Score
- Funding Path
- Lead Profile
- Credit & Identity Risk
- Funding Eligibility
- OCM Intel
- AI Observations

**Actions:**
- Call Now
- Send Funding Link
- Move to Credit
- Archive

---

### Dialer UI

**Location:** `src/components/lead-engine/LeadCallQueue.tsx`

- Shows one lead at a time.
- Shows:
  - Name + business
  - Phone
  - Priority score
  - Notes box
  - Recent outcomes
- Buttons:
  - Connected (moves to callback status)
  - No Answer → auto-advance
  - Voicemail → auto-advance
  - Wrong #
  - Not Interested → archive
  - Skip → move to next
- Dialer list = all leads with `route = 'dialer'` or `import_bucket = 'dialer'`

---

## SECTION 5 — ACCEPTANCE CRITERIA

### UPLOAD
- System correctly maps headers (90%+ accuracy on standard lists)
- `source_type` correct on OCM lists
- Quality score accuracy ±5%
- No more than 3% false rejects

### ROUTING

| Case | Expected | Must Pass |
|------|----------|-----------|
| Phone present | dialer | 100% |
| Email only | email | 100% |
| No phone/email | research | 100% |
| Missing names | reject | 100% |

### RESEARCH Q
- AI response parsed cleanly every time
- Research Profile shows real lead data
- AI Funding Score stored in DB
- Funding Path displayed properly
- OCM block shows only if OCM data exists

### DIALER
- Lead order stable
- Auto-advance < 0.5 sec
- Status update correct on every outcome
- No duplicate leads appear

---

## SECTION 6 — QA PLAN

### Test Cases

| ID | Area | Test | Expected Result |
|----|------|------|-----------------|
| TC-001 | Upload | Upload valid CSV with 100 rows | Processing completes, stats accurate |
| TC-002 | Upload | Upload XLSX with multiple sheets | Uses sheet with most data |
| TC-003 | Upload | Upload file with no header row | System finds header in first 10 rows |
| TC-004 | Headers | OCM list with license columns | source_type = ocm_upload |
| TC-005 | Headers | Generic business list | source_type = generic |
| TC-006 | Routing | Row with phone | route = dialer |
| TC-007 | Routing | Row with email only | route = email |
| TC-008 | Routing | Row with no contact | route = research |
| TC-009 | Routing | Empty row | rejected |
| TC-010 | Research Q | Run on lead with phone | Profile shows phone |
| TC-011 | Research Q | Run on OCM lead | OCM Intel section visible |
| TC-012 | Research Q | AI unavailable | Fallback scoring works |
| TC-013 | Dialer | Start session | Session active indicator |
| TC-014 | Dialer | Mark No Answer | Auto-advances to next |
| TC-015 | Dialer | Mark Interested | Lead locked to worker |
| TC-016 | Dialer | Bad Number | Lead marked dead |
| TC-017 | Error | Upload fails | error_message set, Retry visible |
| TC-018 | Error | Retry failed list | Reprocesses successfully |
| TC-019 | Performance | 1000 row file | Completes in < 60s |
| TC-020 | Performance | 10 concurrent users | No race conditions |

---

## SECTION 7 — FUTURE ROADMAP

### A. Lead Mining AI Bot (Autonomous)
- Scrapes public data in niche industries daily
- Generates new leads automatically
- Sends them directly into Lead Engine v3

### B. Auto-Routing to Credit Fix
- AI detects bad credit from application
- Automatically creates Credit Fix case
- Specialist receives it instantly

### C. Lead Aging & Auto-Releasing
- Unworked leads in dialer return to pool after X hours
- Underwriter → opener lock logic integrated

---

## APPENDIX: File Locations

| Component | Path |
|-----------|------|
| Lead Engine Page | `src/pages/LeadEnginePage.tsx` |
| Lead Lists Panel | `src/components/lead-engine/LeadListsPanel.tsx` |
| Call Queue | `src/components/lead-engine/LeadCallQueue.tsx` |
| Research Queue | `src/components/lead-engine/ResearchQueue.tsx` |
| Research Drawer | `src/components/lead-engine/ResearchProfileDrawer.tsx` |
| Dialer V3 Page | `src/pages/LeadDialerV3.tsx` |
| Process List Function | `supabase/functions/process-lead-list/index.ts` |
| Research Intel Function | `supabase/functions/research-intel/index.ts` |
| Wolf Brain Intake | `supabase/functions/wolf-brain-lead-intake/index.ts` |
| Wolf Research Intel | `supabase/functions/wolf-research-intel/index.ts` |
