# Documentation Reconciliation (Wolf Fund Platform)

## Purpose
This document reconciles discrepancies between architecture/spec docs and the current code/export artifacts. It should be updated whenever exports or migrations materially change. If merge conflicts reappear, keep the detailed **Sources** entries so every claim remains traceable.
This document reconciles discrepancies between architecture/spec docs and the current code/export artifacts. It should be updated whenever exports or migrations materially change.

---

## Verified System Presence (Code + Schema Evidence)

### IP Guardian
- **Tables:** `wf_ip_assets`, `wf_ip_versions`, `wf_ip_events`, `wf_ip_legal_drafts`, `wf_ip_filing_packets`, `wf_ip_evidence_bundles`
- **Functions:** `wf-ip-auto-register`, `wf-ip-legal-generate`, `wf-ip-filing-generate`, `wf-ip-evidence-bundle-generate`
- **Sources:**
  - Schema exports: `exports/07_ONE_SHOT_SCHEMA.part009.sql`, `supabase/migrations/20251205055236_c477e2a0-23a6-4044-94a3-6a5da07dae1a.sql`
  - Function index: `exports/05_EDGE_FUNCTIONS_INDEX.md`
  - UI references: `src/components/motherboard/DefenseWarRoomTab.tsx`
- **UI/Code:** Motherboard references and IP Guardian components exist in `src/components/motherboard/*` and schema exports.

### Motherboard
- **Tables:** `motherboard_commands` (plus governance/health logs in exports/migrations)
- **Functions:** `motherboard-apply-config-change`, `motherboard-generate-suggestions`, `wolf-motherboard-health`, `wf-governance-scan`
- **Sources:**
  - UI: `src/components/motherboard/*`
  - Routes: `docs/ROUTE_VERIFICATION.md`
  - Function index: `exports/05_EDGE_FUNCTIONS_INDEX.md`
- **UI/Code:** `src/components/motherboard/*`, route in `docs/ROUTE_VERIFICATION.md`

### Session Management
- **Tables:** `wolf_sessions`, `wolf_session_settings`, `wolf_session_analytics`
- **Functions:** `wolf-session-start`, `wolf-session-end`, `wolf-session-heartbeat`, `wolf-session-validate`, `wolf-session-expirer`, `wolf-live-session-feed`
- **Sources:**
  - Schema exports: `exports/07_ONE_SHOT_SCHEMA.part008.sql`
  - Function index: `exports/05_EDGE_FUNCTIONS_INDEX.md`

### Outreach Automation
- **Tables:** `outreach_campaigns`, `outreach_events`, `outreach_sequences`, `outreach_steps`, `outreach_enrollments`, `outreach_tasks`, `outreach_inboxes`
- **Functions:** `outreach-create-campaign`, `outreach-schedule-batch`, `outreach-send-batch`, `outreach-task-manager`, `send-smart-email`, `send-smart-sms`, `wf-email-send`
- **Sources:**
  - Schema exports: `exports/07_ONE_SHOT_SCHEMA.part012.sql`, `exports/07_ONE_SHOT_SCHEMA.part013.sql`
  - Function index: `exports/05_EDGE_FUNCTIONS_INDEX.md`

### Commission Engine (v1.1)
- **Tables:** `deal_commissions`, `iso_commissions`, `worker_commission_splits`, `commissions`
- **Functions:** `calculate-deal-commissions`, `calculate-iso-commissions`
- **Sources:**
  - Schema exports: `exports/07_ONE_SHOT_SCHEMA.part010.sql`, `exports/07_ONE_SHOT_SCHEMA.part012.sql`
  - Function index: `exports/05_EDGE_FUNCTIONS_INDEX.md`
  - Engine code: `src/lib/commissionEngine.ts`
- **UI/Code:** `src/lib/commissionEngine.ts`

### Renewal Engine
- **Tables:** `renewal_rules`, `renewal_offers`, `renewal_opportunities`
- **Functions:** `detect-renewals`, `identify-renewal-opportunities`
- **Sources:**
  - Schema exports: `exports/07_ONE_SHOT_SCHEMA.part012.sql`
  - Function index: `exports/05_EDGE_FUNCTIONS_INDEX.md`

---

## Count Reconciliation

### Edge Functions
- **Export index (authoritative snapshot):** `exports/05_EDGE_FUNCTIONS_INDEX.md` lists **156** functions (export date: 2025-12-14).
- **Repo count (current source):** `supabase/functions/` contains **173** function directories (excluding `_shared`), including additional entries like `phase8-deploy-audit`, `phase8-ledger-smoke`, `upload-fast-track-statement`, and `wf-iso-import-leads`.
- **Repo count (current source):** `supabase/functions/` contains **173** function directories (excluding `_shared`).
- **Spec mismatch:** `WOLF_ECOSYSTEM_V1_SPECIFICATION.md` previously stated **53 total** (outdated or subset).

**Resolution:** Use the export as the official published count, and call out the repo count as a “live” number that may exceed the export.

### Storage Buckets
- **Export index (authoritative):** `exports/02_STORAGE_BUCKETS.md` lists **12** buckets.
- **Docs mismatch:** `PLATFORM_ARCHITECTURE.md` listed **4**, `WOLF_ECOSYSTEM_V1_SPECIFICATION.md` listed **7**.

**Resolution:** Update both docs to list all 12 buckets and cite the export as the source of truth.

---

## Lead Lifecycle
The canonical lead lifecycle state machine is the one in `WOLF_ECOSYSTEM_V1_SPECIFICATION.md`. Higher-level summaries (e.g., 8–10 stages) are acceptable for exec overviews, but must be labeled as simplified.

---

## Action Items
1. Keep `PLATFORM_ARCHITECTURE.md` and `WOLF_ECOSYSTEM_V1_SPECIFICATION.md` aligned with export artifacts.
2. When exports update, re-run reconciliation steps and update this document.
