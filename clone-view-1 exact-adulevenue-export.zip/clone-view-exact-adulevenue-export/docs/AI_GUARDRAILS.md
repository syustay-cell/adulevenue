# Wolf-Fund OS – AI & Developer Guardrails

This document defines the rules that ALL AI agents and developers MUST follow when working on Wolf-Fund OS.

---

## ❌ FORBIDDEN ACTIONS

### 1. No Project Resets
- **NEVER** delete the Wolf-Fund project
- **NEVER** create a new project "instead" of fixing issues
- **NEVER** scaffold a new project from scratch
- **NEVER** overwrite the existing repo with a fresh template

### 2. No SSR-Unsafe Code
- **NEVER** use `localStorage`, `sessionStorage`, `window`, `document`, or `navigator` at module top-level
- All browser API usage MUST be:
  - Inside `useEffect`
  - Inside `useCallback` / `useMemo`
  - Wrapped in `if (typeof window !== 'undefined')`

### 3. No Unauthorized Changes
- **NEVER** modify database schemas without explicit approval
- **NEVER** remove existing routes or dashboards
- **NEVER** rename established files without explicit instruction
- **NEVER** change business logic when asked for UI changes only

---

## ✅ REQUIRED ACTIONS

### Before Any Code Changes
1. Read existing file contents before modifying
2. Understand the current structure
3. Check `docs/MOTHERBOARD_MAP.md` for route/layout relationships
4. Check `src/routes/ROUTE_MAP.ts` for the current route structure

### Before Any Deployment
1. Run `npm run prebuild` – Check for SSR violations
2. Run `npm run build` – Verify successful compilation
3. If either fails:
   - **STOP** immediately
   - Report the exact error (file, line, message)
   - Fix only what the error points to
   - Re-run checks

### When Adding New Routes
1. Add to the appropriate `*Routes.tsx` file in `src/routes/`
2. Update `src/routes/ROUTE_MAP.ts`
3. Update `docs/MOTHERBOARD_MAP.md`
4. Use the correct guard component (`ProtectedRoute`, `OwnerGuard`, etc.)
5. Use the correct layout component

### When Adding New Roles
1. Add to `src/config/roleRoutes.ts`
2. Update `ROLE_HIERARCHY` with appropriate level
3. Update `DEFAULT_DASHBOARDS`
4. Update documentation

---

## 📁 Configuration Files

### Role & Route Config
- `src/config/roleRoutes.ts` – Role definitions, hierarchy, default dashboards
- `src/routes/ROUTE_MAP.ts` – Human-readable route map

### Documentation
- `docs/SSR_ISSUES.md` – SSR fixes and their reasons
- `docs/MOTHERBOARD_MAP.md` – Complete role/route/layout reference
- `docs/AI_GUARDRAILS.md` – This file

### Build Scripts
- `scripts/prebuild-check.ts` – SSR safety scanner

---

## 🔒 Protected Files

These files are auto-generated or critical – **DO NOT** modify directly:
- `src/integrations/supabase/types.ts` – Auto-generated from Supabase
- `.env` files – Managed by environment
- `package-lock.json` – Managed by npm

---

## 📋 Checklist for AI Agents

Before responding with code changes:
- [ ] Did I read the existing file content?
- [ ] Did I check the route/layout maps?
- [ ] Am I only changing what was requested?
- [ ] Is all browser API usage SSR-safe?
- [ ] Did I update documentation if needed?

Before marking a task complete:
- [ ] Would `npm run prebuild` pass?
- [ ] Would `npm run build` pass?
- [ ] Did I explain what was changed and why?

---

## Version History

- **V27** – Initial guardrails document created
- Tracks SSR fixes, route structure, and AI behavior rules
