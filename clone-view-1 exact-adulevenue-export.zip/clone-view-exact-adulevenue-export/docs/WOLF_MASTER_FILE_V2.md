# 🐺 WOLF-FUND.COM — MASTER FILE (V2)

> This document is the single source of truth for the Wolf-Fund.com + ABG + TLC ecosystem.
> All AI tools, developers, and vendors must follow THIS spec before writing code.

---

## 1. BRANDS

- `wolf-fund` – Core funding, credit, underwriting, Lead Engine
- `abg` – ABG BuildSuite (architecture, manufacturing, logistics)
- `tlc` – The Lefkowitz Center (TLC campus, families, veterans, SUD)

Brand registration lives in:

- `src/contexts/BrandContext.tsx`
- `src/brands/*`

No brand may be used if it is not declared here.

---

## 2. ROLES & DASHBOARDS

C-suite & Investors:
- `/ceo` – `CeoDashboard`
- `/cfo` – `CfoDashboard`
- `/clo` – `CloDashboard`
- `/investor` – `InvestorDashboard`
- `/donors` – `DonorGovernmentDashboard`
- `/win-director` – `WinDirectorDashboard`
- `/partner/factory` – `PartnerFactoryDashboard`

Operational roles:
- Owner, Admin, Worker, ISO, Client, Funder – existing routes in `src/routes/*`.

TLC roles:
- TLC Owner / Clinical / Intake / Family – mapped via `src/brands/tlc/routes.tsx`.

WIN:
- WIN field and director roles routed via `/win-*`.

---

## 3. LEAD ENGINE V3

All leads must have:
- `funding_path` ∈ {`FUNDING_FIRST`, `CREDIT_FIRST`, `NEEDS_MORE_INFO`}
- `funding_score` 0–100
- `priority_band` ∈ {`A`, `B`, `C`, `D`, `F`}
- `credit_risk` ∈ {`low`, `medium`, `high`, `unknown`}

UI:
- Worker view must use `LeadLaneBoard` (lanes by funding path).
- Each lead must be able to open an **Executive Intelligence Summary**.

---

## 4. EXECUTIVE INTELLIGENCE SUMMARY

Standard output shape must include:
- Summary paragraph
- Risk factors[]
- Next steps[]
- Missing information[]
- Credit fix action items[]
- Funding path, score, priority, risk bands

UI:
- `ExecutiveIntelCard` renders the PDF-style view.
- Underwriting & Lead Engine MUST call `runResearchIntel()` to populate data.

---

## 5. CREDIT FIX BACK OFFICE

Legal & contract flow:
- Credit repair application → generate contract using `renderElBoriCreditRepairContract()`.
- Store contract in Supabase `credit_fix_contracts` (and document bucket).
- CLO dashboard has visibility into active credit-fix contracts.

All templates are derived from: `EL BORI NEW FILE.pdf`.

---

## 6. MODERN UI CONTRACT

Components:
- Use only `WolfCard`, `WolfStat`, `WolfTable`, and the approved UI library.
- No raw `<table border="1">`, inline styles, or legacy layouts.

Every new page must:
- Use the shared `DashboardLayout`.
- Declare a clear title.
- Use cards / stats / tables, not freestyle.

---

## 7. DO NOTS

- Do NOT create parallel motherboard folders (only `src/motherboard/*`).
- Do NOT invent new brands outside `BRAND_REGISTRY`.
- Do NOT bypass this file when designing flows.

---

This V2 spec supersedes any V1 fragments that conflict with it.
