# MCA Dev Blueprint v1.1

## Overview

This is the master development blueprint for Wolf Fund's MCA platform. It covers 7 interconnected modules that work together to create a complete MCA lifecycle management system.

## Module Overview

| Module | Name | Description |
|--------|------|-------------|
| 1 | Compliance OS | State rules, checklists, KYC/KYB |
| 2 | Product Catalog & Risk Matrix | Products, pricing, risk tiers |
| 3 | Collections Engine | Soft → Hard → Legal workflows |
| 4 | Renewal Engine | 35-60% paid triggers, auto-offers |
| 5 | Investor & SPV Layer | Funds, investors, allocations |
| 6 | Rule Engine | Configurable UW/Collections/Renewal rules |
| 7 | ISO Knowledge Hub | Training, scoreboard, badges |

## How Everything Connects

```
Lead Engine V3 → Deals → Rule Engine + Product Matrix + Compliance OS
                    ↓
              Commission Engine v1.1
                    ↓
              Funding (with Investor Layer allocation)
                    ↓
              Lifecycle (Collections + Renewals)
```

## Implementation Order

1. **Compliance OS + Rule Engine** (Modules 1 & 6)
2. **Product Matrix** (Module 2)  
3. **Collections Engine** (Module 3)
4. **Renewal Engine** (Module 4)
5. **Investor Layer** (Module 5)
6. **ISO Knowledge Hub** (Module 7)

## Key Integration Points

### Before Funding
- Compliance `overall_status` must be `PASS`
- Rule Engine must not output `DECLINE`
- Commission Engine calculates splits
- Investor Layer assigns fund/SPV allocation

### During Lifecycle
- Collections Engine handles NSF, dpd tracking
- Renewal Engine watches paid % for opportunities
- Portfolio/Investor reporting aggregates performance

### Cross-Module Dependencies
- ISO Knowledge Hub training completion can gate product access via Rule Engine
- Collections status affects renewal eligibility
- Rule Engine is consulted by UW, Collections, and Renewals
