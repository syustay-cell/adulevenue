# 🐺 WOLF ECOSYSTEM V1 — LIFECYCLE FLOWCHARTS

> Visual diagrams of all system workflows and data flows

---

## TABLE OF CONTENTS

1. [Complete Lead Lifecycle](#1-complete-lead-lifecycle)
2. [Lead Ingestion Flow](#2-lead-ingestion-flow)
3. [Research Queue Flow](#3-research-queue-flow)
4. [Dialer Session Flow](#4-dialer-session-flow)
5. [Application & Underwriting Flow](#5-application--underwriting-flow)
6. [Credit Repair Workflow](#6-credit-repair-workflow)
7. [ISO Partner Flow](#7-iso-partner-flow)
8. [Document Processing Flow](#8-document-processing-flow)
9. [Closed-Loop Funding Cycle](#9-closed-loop-funding-cycle)
10. [AI Decision Tree](#10-ai-decision-tree)
11. [User Role Permissions](#11-user-role-permissions)
12. [System Architecture](#12-system-architecture)

---

## 1. COMPLETE LEAD LIFECYCLE

```mermaid
flowchart TD
    subgraph INGESTION["📥 INGESTION"]
        A[Excel/CSV Upload] --> B{Parse & Validate}
        B -->|Valid| C[Normalize Fields]
        B -->|Invalid| D[❌ Reject]
        C --> E{Has Contact Info?}
    end

    subgraph ROUTING["🔀 ROUTING"]
        E -->|Phone| F[📞 Dialer Queue]
        E -->|Email Only| G[📧 Email Queue]
        E -->|Neither| H[🔬 Research Queue]
    end

    subgraph ENRICHMENT["🧠 ENRICHMENT"]
        H --> I[Worker Claims Lead]
        I --> J[Run AI Research]
        J --> K{Contact Found?}
        K -->|Yes + Phone| F
        K -->|Yes + Email| G
        K -->|No| L[Archive]
    end

    subgraph DIALER["📞 DIALER"]
        F --> M[Worker Starts Session]
        M --> N[Load Next Lead]
        N --> O[Make Call]
        O --> P{Outcome?}
        P -->|Connected| Q[Send Intake]
        P -->|No Answer| R{Attempts < 5?}
        R -->|Yes| S[Schedule Callback]
        R -->|No| T[Move to Archive]
        P -->|Not Interested| T
        S --> N
        Q --> U[Intake Completed]
    end

    subgraph UNDERWRITING["📋 UNDERWRITING"]
        U --> V[Create Underwriting Case]
        V --> W[AI Analysis]
        W --> X{Fundable?}
        X -->|Yes| Y[Request Docs]
        X -->|Conditional| Z[Request More Info]
        X -->|No - Credit| AA[Move to Credit Fix]
        Y --> AB[Run File]
        AB --> AC[Send to Funders]
        AC --> AD{Offers?}
        AD -->|Yes| AE[Funding Call]
        AD -->|No| AF[Decline]
        AE --> AG[✅ FUNDED]
    end

    subgraph CREDIT["🔧 CREDIT REPAIR"]
        AA --> AH[Create Credit Case]
        AF --> AH
        AH --> AI[AI Analyze Report]
        AI --> AJ[Generate Strategy]
        AJ --> AK[Send Disputes]
        AK --> AL{Results?}
        AL -->|Improved| AM{Score >= 600?}
        AM -->|Yes| V
        AM -->|No| AK
        AL -->|No Change| AK
    end

    style AG fill:#22c55e
    style D fill:#ef4444
    style L fill:#6b7280
    style T fill:#6b7280
```

---

## 2. LEAD INGESTION FLOW

```mermaid
flowchart TD
    subgraph UPLOAD["FILE UPLOAD"]
        A[User Uploads File] --> B[Store in Supabase Storage]
        B --> C[Create lead_lists Record]
        C --> D[Trigger process-lead-list Function]
    end

    subgraph PARSING["FILE PARSING"]
        D --> E[Download File from Storage]
        E --> F[Detect File Type]
        F --> G{CSV or Excel?}
        G -->|CSV| H[Parse CSV]
        G -->|Excel| I[Parse Excel]
        H --> J[Extract Headers]
        I --> J
    end

    subgraph MAPPING["HEADER MAPPING"]
        J --> K[AI Header Detection]
        K --> L[Calculate Confidence Scores]
        L --> M{Confidence > 80%?}
        M -->|Yes| N[Auto-Map Fields]
        M -->|No| O[Flag for Review]
        O --> P[Manual Mapping UI]
        P --> N
    end

    subgraph PROCESSING["ROW PROCESSING"]
        N --> Q[For Each Row]
        Q --> R[Normalize Phone]
        R --> S[Normalize Email]
        S --> T[Validate Business Name]
        T --> U[Extract OCM Fields if Present]
        U --> V{Valid Row?}
        V -->|Yes| W[Classify Route]
        V -->|No| X[Add to Rejected]
    end

    subgraph CLASSIFICATION["ROUTE CLASSIFICATION"]
        W --> Y{Has Phone?}
        Y -->|Yes| Z[route = dialer]
        Y -->|No| AA{Has Email?}
        AA -->|Yes| AB[route = email]
        AA -->|No| AC[route = research]
        Z --> AD[Insert Lead]
        AB --> AD
        AC --> AD
        X --> AD
    end

    subgraph COMPLETION["FINALIZATION"]
        AD --> AE[Update List Stats]
        AE --> AF[Calculate Quality Score]
        AF --> AG[Set Status = completed]
        AG --> AH[Return Summary]
    end
```

---

## 3. RESEARCH QUEUE FLOW

```mermaid
flowchart TD
    subgraph CLAIM["LEAD CLAIM"]
        A[Worker Opens Research Q] --> B[Click 'Claim Next Lead']
        B --> C[claim_next_research_lead RPC]
        C --> D{Lead Available?}
        D -->|Yes| E[Lock Lead to Worker]
        D -->|No| F[Show 'No Leads' Message]
        E --> G[Display Lead Card]
    end

    subgraph RESEARCH["MANUAL RESEARCH"]
        G --> H[View Known Info]
        H --> I[Click Quick Links]
        I --> J[Google Search]
        I --> K[LinkedIn Search]
        I --> L[Google Maps]
        J --> M[Find Contact Info]
        K --> M
        L --> M
    end

    subgraph AI_RESEARCH["AI RESEARCH"]
        G --> N[Click 'Run AI Research']
        N --> O[wolf-research-intel Function]
        O --> P[Call Enrichment APIs]
        P --> Q[Clearbit / PeopleDataLabs]
        P --> R[Google Places API]
        P --> S[LinkedIn API]
        Q --> T[Aggregate Data]
        R --> T
        S --> T
        T --> U[AI Analysis]
        U --> V[Generate Intelligence Profile]
        V --> W[Display in Profile Drawer]
    end

    subgraph OUTPUT["LEAD OUTPUT"]
        M --> X[Fill Enrichment Form]
        W --> X
        X --> Y{Contact Info Found?}
        Y -->|Phone| Z[Click 'Send to Dialer']
        Y -->|Email Only| AA[Click 'Send to Email']
        Y -->|Neither| AB[Click 'Cannot Find Info']
        Z --> AC[Update Lead Route]
        AA --> AC
        AB --> AD[Archive Lead]
        AC --> AE[Claim Next Lead]
    end
```

---

## 4. DIALER SESSION FLOW

```mermaid
flowchart TD
    subgraph SESSION["SESSION MANAGEMENT"]
        A[Worker Opens Dialer] --> B{Active Session?}
        B -->|Yes| C[Resume Session]
        B -->|No| D[Click 'Start Session']
        D --> E[Create call_sessions Record]
        E --> F[Load First Lead]
        C --> F
    end

    subgraph LEAD_LOAD["LEAD LOADING"]
        F --> G[get_next_lead_for_worker RPC]
        G --> H{Lead Found?}
        H -->|Yes| I[Display Lead Card]
        H -->|No| J[Show 'No Leads Available']
        I --> K[Display AI Insights]
        K --> L[Show Call Button]
    end

    subgraph CALL["CALL HANDLING"]
        L --> M[Worker Clicks Call]
        M --> N[tel: Link Opens Dialer]
        N --> O[Call In Progress]
        O --> P[Worker Selects Outcome]
    end

    subgraph OUTCOMES["OUTCOME PROCESSING"]
        P --> Q{Outcome Type?}
        Q -->|Connected| R[Show Connected Options]
        Q -->|No Answer| S[Auto-Load Next Lead]
        Q -->|Voicemail| S
        Q -->|Wrong Number| T[Mark Dead]
        Q -->|Not Interested| T
        Q -->|Callback| U[Open Calendar]
        
        R --> V{Action?}
        V -->|Send Intake| W[Create Application Draft]
        V -->|Fast Track| X[Open Fast Track Form]
        V -->|Add Notes| Y[Save Notes]
        V -->|Transfer| Z[Transfer to Underwriter]
        
        U --> AA[Select Date/Time]
        AA --> AB[Schedule Callback]
        AB --> S
        
        T --> S
        W --> S
        Z --> S
    end

    subgraph LOCKING["LEAD LOCKING"]
        W --> AC[Lock Lead for 7 Days]
        X --> AC
        AC --> AD[Update lead_ownerships]
    end

    subgraph END_SESSION["SESSION END"]
        S --> AE{Continue?}
        AE -->|Yes| G
        AE -->|No| AF[Click 'Stop Session']
        AF --> AG[End call_sessions Record]
    end
```

---

## 5. APPLICATION & UNDERWRITING FLOW

```mermaid
flowchart TD
    subgraph APPLICATION["APPLICATION SUBMISSION"]
        A[Client/Worker Submits App] --> B[Create fast_track_applications]
        B --> C[Upload Documents]
        C --> D[Store in Supabase Storage]
        D --> E[Set Status = pending]
    end

    subgraph DOC_PROCESSING["DOCUMENT PROCESSING"]
        E --> F[extract-all-documents Function]
        F --> G[Download Each Document]
        G --> H{Document Type?}
        H -->|Bank Statement| I[verify-bank-statement]
        H -->|Driver License| J[extract-id-fields]
        H -->|Other| K[Generic OCR]
        I --> L[Vision AI Analysis]
        J --> L
        K --> L
        L --> M[Store in document_extractions]
    end

    subgraph UNDERWRITING["UNDERWRITING ANALYSIS"]
        M --> N[Admin Clicks 'Run AI Analysis']
        N --> O[underwriter-analyze-application]
        O --> P[Build Analysis Prompt]
        P --> Q[Call Gemini AI]
        Q --> R[Parse Response]
        R --> S[Create/Update underwriting_cases]
    end

    subgraph ANALYSIS_OUTPUT["ANALYSIS OUTPUT"]
        S --> T{Fundability?}
        T -->|Fundable| U[🟢 Show Fundable Badge]
        T -->|Conditional| V[🟡 Show Conditional Badge]
        T -->|Not Fundable| W[🔴 Show Not Fundable]
        
        U --> X[Display Banking Metrics]
        V --> X
        W --> X
        
        X --> Y[Show Existing Funding Table]
        Y --> Z[Show Risk Flags]
        Z --> AA[Show AI Recommendations]
    end

    subgraph FUNDER_SEND["FUNDER SUBMISSION"]
        AA --> AB{Ready to Send?}
        AB -->|Yes| AC[Open Funder Selection]
        AB -->|No| AD[Request More Docs]
        
        AC --> AE[Select Funders]
        AE --> AF[Choose Share Level]
        AF --> AG[send-to-funder Function]
        AG --> AH[Generate Funder Package]
        AH --> AI[Send Emails]
        AI --> AJ[Create funder_submissions]
    end

    subgraph FUNDING["FUNDING COMPLETION"]
        AJ --> AK{Funder Response?}
        AK -->|Offer| AL[Record Offer]
        AK -->|Decline| AM[Update Status]
        AL --> AN[Schedule Funding Call]
        AN --> AO[3-Way Call]
        AO --> AP{Funded?}
        AP -->|Yes| AQ[✅ Create funded_contracts]
        AP -->|No| AR[Back to Offers]
    end
```

---

## 6. CREDIT REPAIR WORKFLOW

```mermaid
flowchart TD
    subgraph ENTRY["CASE ENTRY"]
        A[Funding Declined] --> B[Admin Clicks 'Move to Credit']
        C[Direct Credit App] --> D[Create credit_repair_applications]
        B --> D
        D --> E[Create credit_repair_cases]
        E --> F[Assign to Specialist]
    end

    subgraph INTAKE["INTAKE PHASE"]
        F --> G[Specialist Opens Case]
        G --> H[Status: intake]
        H --> I[Request Credit Report]
        I --> J[Client Uploads Report]
    end

    subgraph ANALYSIS["AI ANALYSIS"]
        J --> K[credit-repair-analyze-report]
        K --> L[Vision AI Parses Report]
        L --> M[Identify Negative Items]
        M --> N[Create credit_repair_items]
        N --> O[Status: investigation]
    end

    subgraph STRATEGY["STRATEGY GENERATION"]
        O --> P[Specialist Clicks 'Generate Strategy']
        P --> Q[credit-repair-generate-strategy]
        Q --> R[AI Determines Priority]
        R --> S[Map Compliance Codes]
        S --> T[FCRA Sections]
        S --> U[FDCPA Sections]
        S --> V[Metro 2 Codes]
        T --> W[Display Strategy]
        U --> W
        V --> W
    end

    subgraph DISPUTES["DISPUTE LETTERS"]
        W --> X[Select Items to Dispute]
        X --> Y[credit-repair-generate-letters]
        Y --> Z[AI Generates Professional Letters]
        Z --> AA[Create credit_repair_dispute_drafts]
        AA --> AB[Specialist Reviews]
        AB --> AC{Approve?}
        AC -->|Yes| AD[Status: approved]
        AC -->|No| AE[Edit Letter]
        AE --> AB
    end

    subgraph SENDING["LETTER SENDING"]
        AD --> AF[Select Send Method]
        AF --> AG{Method?}
        AG -->|Email| AH[send-dispute-letters]
        AG -->|Print| AI[Generate PDF]
        AG -->|Certified| AJ[Certified Mail API]
        AH --> AK[Status: disputes_sent]
        AI --> AK
        AJ --> AK
    end

    subgraph RESULTS["RESULTS TRACKING"]
        AK --> AL[Wait 30-45 Days]
        AL --> AM[Check for Responses]
        AM --> AN{Item Removed?}
        AN -->|Yes| AO[Update Item: deleted]
        AN -->|No| AP[Update Item: verified]
        AO --> AQ[Status: results_received]
        AP --> AQ
    end

    subgraph COMPLETION["CASE COMPLETION"]
        AQ --> AR{Score >= 600?}
        AR -->|Yes| AS[Status: completed]
        AR -->|No| AT[Continue Disputes]
        AT --> X
        AS --> AU{From Funding Decline?}
        AU -->|Yes| AV[Auto-Create New App]
        AU -->|No| AW[Offer Funding Options]
        AV --> AX[🔄 REFUNNEL TO UNDERWRITING]
    end
```

---

## 7. ISO PARTNER FLOW

```mermaid
flowchart TD
    subgraph ONBOARDING["ISO ONBOARDING"]
        A[Prospect Visits ISO Page] --> B[Submit ISO Application]
        B --> C[Create iso_partner_applications]
        C --> D[Status: pending]
        D --> E[Admin Reviews]
        E --> F{Approve?}
        F -->|Yes| G[Send DocuSign Agreement]
        F -->|No| H[Reject Application]
        G --> I[initiate-docusign Function]
        I --> J[ISO Signs Agreement]
        J --> K[docusign-webhook Received]
        K --> L[Status: approved]
        L --> M[Create worker Role]
    end

    subgraph PORTAL["ISO PORTAL"]
        M --> N[ISO Logs In]
        N --> O[View ISO Dashboard]
        O --> P[See Stats: Leads, Funded, Commissions]
        O --> Q[Submit New Lead]
        O --> R[Upload Lead File]
    end

    subgraph SUBMISSION["LEAD SUBMISSION"]
        Q --> S[Fill Lead Form]
        S --> T[Create lead with iso_partner_id]
        T --> U[Lead Enters Wolf Pipeline]
        R --> V[process-lead-list with ISO Attribution]
        V --> U
    end

    subgraph TRACKING["DEAL TRACKING"]
        U --> W[Lead Progresses Through Pipeline]
        W --> X{Funded?}
        X -->|Yes| Y[Create funded_contracts]
        Y --> Z[Calculate Commission]
        Z --> AA[Create iso_commissions]
        AA --> AB[Display in ISO Dashboard]
        X -->|No| AC[Show Current Status]
    end

    subgraph PAYOUTS["COMMISSION PAYOUTS"]
        AB --> AD{Payment Due?}
        AD -->|Yes| AE[Admin Approves Payment]
        AE --> AF[Mark as Paid]
        AF --> AG[Update ISO Dashboard]
    end
```

---

## 8. DOCUMENT PROCESSING FLOW

```mermaid
flowchart TD
    subgraph UPLOAD["DOCUMENT UPLOAD"]
        A[User Selects Document] --> B{Document Type?}
        B -->|Bank Statement| C[fast-track-documents Bucket]
        B -->|ID Document| C
        B -->|Other| C
        C --> D[Upload to Supabase Storage]
        D --> E[Get Storage Path]
        E --> F[Update Application Record]
    end

    subgraph OCR["DOCUMENT OCR"]
        F --> G[Admin Triggers Analysis]
        G --> H{Document Type?}
        
        H -->|Bank Statement| I[verify-bank-statement]
        I --> J[Download from Storage]
        J --> K[Convert to Base64]
        K --> L[Gemini Vision API]
        L --> M[Extract Financial Data]
        M --> N[Revenue, Balances, NSF]
        
        H -->|Driver License| O[extract-id-fields]
        O --> P[Download from Storage]
        P --> Q[Convert to Base64]
        Q --> R[Gemini Vision API]
        R --> S[Extract ID Fields]
        S --> T[Name, Address, DOB, License#]
    end

    subgraph STORAGE["EXTRACTION STORAGE"]
        N --> U[Create document_extractions]
        T --> U
        U --> V[parsed_data JSON]
        V --> W[Link to Application]
    end

    subgraph VERIFICATION["DATA VERIFICATION"]
        W --> X[Display Extracted Data]
        X --> Y{Data Correct?}
        Y -->|Yes| Z[Use in Underwriting]
        Y -->|No| AA[Manual Correction]
        AA --> AB[Update document_extractions]
        AB --> Z
    end

    subgraph COMPARISON["ID VERIFICATION"]
        Z --> AC[Compare ID Name to App Name]
        AC --> AD{Names Match?}
        AD -->|Yes| AE[✅ Verified]
        AD -->|No| AF[⚠️ Flag Mismatch]
        AF --> AG[Show Warning to Admin]
    end
```

---

## 9. CLOSED-LOOP FUNDING CYCLE

```mermaid
flowchart TD
    subgraph INITIAL["INITIAL CONTACT"]
        A[New Lead] --> B[Dialer Contact]
        B --> C[Application Submitted]
    end

    subgraph UNDERWRITING["FIRST UNDERWRITING"]
        C --> D[AI Analysis]
        D --> E{Fundable?}
        E -->|Yes| F[Send to Funders]
        E -->|Conditional| G[Request More Docs]
        E -->|No - Credit| H[Credit Repair Track]
        G --> D
    end

    subgraph FUNDING["FUNDING"]
        F --> I{Funded?}
        I -->|Yes| J[✅ FUNDED]
        I -->|No - Declined| H
    end

    subgraph CREDIT_FIX["CREDIT REPAIR"]
        H --> K[Create Credit Case]
        K --> L[AI Strategy]
        L --> M[Send Disputes]
        M --> N[Wait 30-90 Days]
        N --> O{Score Improved?}
        O -->|Yes >= 600| P[Auto-Create New App]
        O -->|No| M
    end

    subgraph REFUNNEL["REFUNNEL"]
        P --> Q[Notify Original Worker]
        Q --> R[New Underwriting]
        R --> S{Fundable Now?}
        S -->|Yes| F
        S -->|No| K
    end

    subgraph POST_FUNDING["POST-FUNDING"]
        J --> T[funded_contracts Created]
        T --> U[Calculate Commissions]
        U --> V[Track Payments]
        V --> W{Contract Ending?}
        W -->|Yes| X[Renewal Eligible Check]
        X --> Y[Contact for Renewal]
        Y --> C
    end

    style J fill:#22c55e
    style A fill:#3b82f6
```

---

## 10. AI DECISION TREE

```mermaid
flowchart TD
    subgraph INPUT["AI INPUT DATA"]
        A[Lead/Application Data] --> B[Business Name]
        A --> C[Contact Info]
        A --> D[Financial Data]
        A --> E[Credit Indicators]
        A --> F[Industry/License]
    end

    subgraph SCORING["AI SCORING"]
        B --> G[Business Validation]
        C --> H[Contact Quality Score]
        D --> I[Financial Health Score]
        E --> J[Credit Risk Score]
        F --> K[Industry Risk Score]
        
        G --> L[Aggregate Funding Score]
        H --> L
        I --> L
        J --> L
        K --> L
    end

    subgraph CLASSIFICATION["AI CLASSIFICATION"]
        L --> M{Score >= 80?}
        M -->|Yes| N[Priority: A]
        M -->|No| O{Score >= 60?}
        O -->|Yes| P[Priority: B]
        O -->|No| Q{Score >= 40?}
        Q -->|Yes| R[Priority: C]
        Q -->|No| S[Priority: D]
    end

    subgraph ROUTING["AI ROUTING DECISION"]
        N --> T{Credit Risk?}
        P --> T
        R --> T
        S --> U[do_not_work]
        
        T -->|Low| V[funding_first]
        T -->|Medium| W{Has Existing Funding?}
        T -->|High| X[credit_first]
        
        W -->|Yes| Y[hybrid]
        W -->|No| V
    end

    subgraph OUTPUT["AI OUTPUT"]
        V --> Z[Route to Dialer Priority Queue]
        Y --> Z
        X --> AA[Flag for Credit Pre-Screen]
        U --> AB[Archive / Do Not Contact]
    end
```

---

## 11. USER ROLE PERMISSIONS

```mermaid
flowchart TD
    subgraph ROLES["USER ROLES"]
        A[Admin] --> A1[Full System Access]
        B[Worker/Dialer] --> B1[Dialer + Own Leads]
        C[Researcher] --> C1[Research Queue Only]
        D[Underwriter] --> D1[Applications + Analysis]
        E[Credit Specialist] --> E1[Credit Cases Only]
        F[ISO Partner] --> F1[Own Submissions Only]
        G[User/Client] --> G1[Own Applications Only]
    end

    subgraph ADMIN_ACCESS["ADMIN ACCESS"]
        A1 --> H[All Leads]
        A1 --> I[All Applications]
        A1 --> J[All Users]
        A1 --> K[All Reports]
        A1 --> L[Settings]
        A1 --> M[Funders]
    end

    subgraph WORKER_ACCESS["WORKER ACCESS"]
        B1 --> N[Dialer Interface]
        B1 --> O[Own Locked Leads]
        B1 --> P[Own Applications]
        B1 --> Q[Own Stats]
    end

    subgraph RESEARCHER_ACCESS["RESEARCHER ACCESS"]
        C1 --> R[Research Queue]
        C1 --> S[Enrichment Tools]
        C1 --> T[Own Completed Count]
    end

    subgraph UNDERWRITER_ACCESS["UNDERWRITER ACCESS"]
        D1 --> U[All Applications]
        D1 --> V[AI Analysis Tools]
        D1 --> W[Funder Submission]
        D1 --> X[Document Review]
    end

    subgraph CREDIT_ACCESS["CREDIT SPECIALIST ACCESS"]
        E1 --> Y[Assigned Cases Only]
        E1 --> Z[AI Dispute Tools]
        E1 --> AA[Letter Generation]
        E1 --> AB[Activity Logging]
    end

    subgraph ISO_ACCESS["ISO PARTNER ACCESS"]
        F1 --> AC[Own Leads/Apps]
        F1 --> AD[Commission Reports]
        F1 --> AE[Lead Submission]
    end
```

---

## 12. SYSTEM ARCHITECTURE

```mermaid
flowchart TD
    subgraph CLIENT["CLIENT LAYER"]
        A[React Frontend]
        A1[Admin Dashboard]
        A2[Worker Dashboard]
        A3[ISO Portal]
        A4[Client Portal]
        A --> A1
        A --> A2
        A --> A3
        A --> A4
    end

    subgraph API["API LAYER"]
        B[Supabase Client SDK]
        B1[Auth]
        B2[Database]
        B3[Storage]
        B4[Realtime]
        B --> B1
        B --> B2
        B --> B3
        B --> B4
    end

    subgraph FUNCTIONS["EDGE FUNCTIONS"]
        C[Lead Processing]
        C1[process-lead-list]
        C2[lead-enrich-classify]
        C3[wolf-research-intel]
        
        D[Underwriting]
        D1[underwriter-analyze-application]
        D2[verify-bank-statement]
        D3[legal-risk-scan]
        D4[send-to-funder]
        
        E[Credit Repair]
        E1[credit-repair-analyze-report]
        E2[credit-repair-generate-strategy]
        E3[credit-repair-generate-letters]
        
        F[Communications]
        F1[send-notification-email]
        F2[send-sms-notification]
        F3[initiate-docusign]
        
        C --> C1
        C --> C2
        C --> C3
        D --> D1
        D --> D2
        D --> D3
        D --> D4
        E --> E1
        E --> E2
        E --> E3
        F --> F1
        F --> F2
        F --> F3
    end

    subgraph AI["AI LAYER"]
        G[AI Gateway]
        G1[Gemini 2.5 Flash]
        G2[Gemini 2.5 Pro]
        G --> G1
        G --> G2
    end

    subgraph EXTERNAL["EXTERNAL SERVICES"]
        H[Resend Email]
        I[Twilio SMS]
        J[DocuSign]
        K[Clearbit]
    end

    subgraph DATA["DATA LAYER"]
        L[(PostgreSQL)]
        M[(Supabase Storage)]
    end

    A --> B
    B --> FUNCTIONS
    FUNCTIONS --> G
    FUNCTIONS --> EXTERNAL
    FUNCTIONS --> DATA
    B --> DATA
```

---

## LEGEND

| Symbol | Meaning |
|--------|---------|
| 🟢 | Success / Positive Outcome |
| 🟡 | Conditional / Warning |
| 🔴 | Failure / Negative Outcome |
| ✅ | Completed / Approved |
| ❌ | Rejected / Failed |
| 📞 | Phone / Dialer Related |
| 📧 | Email Related |
| 🔬 | Research Related |
| 📋 | Document / Application |
| 🔧 | Credit Repair |
| 🤖 | AI Operation |
| 🔄 | Loop / Cycle |

---

*Document Version: 1.0*
*Last Updated: December 2, 2024*
*Wolf Ecosystem V1 Specification*
