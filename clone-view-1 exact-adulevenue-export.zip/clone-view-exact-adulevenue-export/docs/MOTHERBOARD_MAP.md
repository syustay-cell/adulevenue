# Wolf-Fund OS – Motherboard Map

This document provides a human-readable overview of all roles, dashboards, and layouts in the Wolf-Fund OS.

---

## Role Overview

| Role | Default Dashboard | Layout | Description |
|------|------------------|--------|-------------|
| Owner | `/owner/motherboard` | OwnerLayout | Full system control, all tenants visible |
| Admin | `/admin/dashboard` | ProtectedLayout | Back-office operations, underwriting |
| Worker | `/worker/dashboard` | ProtectedLayout | Lead processing, dialer, pipeline |
| ISO | `/iso/dashboard` | ProtectedLayout | Partner portal, deals, commissions |
| Funder | `/funder/portal` | FunderLayout | Deal rooms, offers, contracts |
| Legal | `/legal/dashboard` | OpsLayout | Legal cases, ID theft, disputes |
| Credit Repair Specialist | `/credit-specialist-dashboard` | OpsLayout | Credit cases, dispute drafts |
| Public | `/` | None | Marketing pages, applications |

---

## Owner Sections

**Layout:** `OwnerLayout` (src/layouts/OwnerLayout.tsx)

| Route | Label | Description |
|-------|-------|-------------|
| `/owner/motherboard` | Motherboard | Central control panel, metrics, events |
| `/owner/security` | Security | IP tracking, session management |
| `/owner/settings` | Settings | Global configuration |
| `/owner/settings/voice` | Voice & TTS | Text-to-speech configuration |

**Legacy Aliases:**
- `/owner-dashboard` → Owner Dashboard
- `/wolf-motherboard` → Wolf Motherboard
- `/ceo-dashboard` → CEO Dashboard
- `/ip-guardian` → IP Guardian

---

## Admin Sections

**Layout:** `ProtectedLayout` (src/layouts/ProtectedLayout.tsx)

| Route | Label | Description |
|-------|-------|-------------|
| `/admin/dashboard` | Dashboard | Main admin overview |
| `/admin/reports` | Reports | Analytics and reporting |
| `/admin/billing` | Billing | Subscription management |
| `/admin/documents` | Documents | Document management |
| `/admin/templates` | Templates | Email/SMS templates |
| `/admin/credit-desk` | Credit Desk | Credit repair oversight |
| `/admin/underwriting` | Underwriting | Deal underwriting queue |
| `/admin/underwriting/:caseId` | Case Detail | Individual case review |

---

## Worker Sections

**Layout:** `ProtectedLayout` (src/layouts/ProtectedLayout.tsx)

| Route | Label | Description |
|-------|-------|-------------|
| `/worker/dashboard` | Dashboard | Worker home |
| `/worker/queue` | My Queue | Dialer queue (DialerV3) |
| `/worker/pipeline` | My Pipeline | Personal deal pipeline |
| `/worker/follow-ups` | Follow-Ups | Scheduled callbacks |
| `/worker/tasks` | Tasks | Task list |
| `/worker/my-day` | My Day | Daily overview |
| `/worker/leads` | Lead Mining | Lead research |

---

## ISO Partner Sections

**Layout:** `ProtectedLayout` (src/layouts/ProtectedLayout.tsx)
**Guard:** `ProtectedISORoute`

| Route | Label | Description |
|-------|-------|-------------|
| `/iso/portal` | Portal | Main ISO portal |
| `/iso/dashboard` | Dashboard | Partner dashboard |
| `/iso/submit` | Submit Deal | New deal submission |
| `/iso/deals` | My Deals | Deal tracking |
| `/iso/commissions` | Commissions | Commission history |

---

## Funder Sections

**Layout:** `FunderLayout` (src/layouts/FunderLayout.tsx)
**Guard:** `ProtectedFunderRoute`

| Route | Label | Description |
|-------|-------|-------------|
| `/funder/portal` | Portal | Funder home |
| `/funder/deal/:dealRoomId` | Deal Room | Secure deal view |

---

## Legal Sections

**Layout:** `OpsLayout` (src/layouts/OpsLayout.tsx)

| Route | Label | Description |
|-------|-------|-------------|
| `/legal/dashboard` | Dashboard | Legal cases overview |
| `/legal/queue` | Queue | Case queue |
| `/legal/settings` | Settings | Legal settings |

---

## Public Routes (No Auth Required)

**Layout:** None (uses page-level layouts)

| Route | Label | Description |
|-------|-------|-------------|
| `/` | Home | Landing page |
| `/services` | Services | Service offerings |
| `/how-it-works` | How It Works | Process explanation |
| `/apply` | Apply | Application selection |
| `/fast-track` | Fast Track | Fast track application |
| `/loan-application` | Loan | Loan application |
| `/credit-repair-application` | Credit Repair | Credit repair intake |
| `/contact` | Contact | Contact form |
| `/auth` | Auth | Login/signup |
| `/membership` | Membership | Membership OS portal |

---

## Layout Files

| Layout | Path | Used By |
|--------|------|---------|
| OwnerLayout | `src/layouts/OwnerLayout.tsx` | Owner routes |
| ProtectedLayout | `src/layouts/ProtectedLayout.tsx` | Admin, Worker, ISO |
| FunderLayout | `src/layouts/FunderLayout.tsx` | Funder routes |
| OpsLayout | `src/layouts/OpsLayout.tsx` | Legal, Credit Specialist |
| TLCLayout | `src/layouts/TLCLayout.tsx` | TLC brand routes |
| PartnerLayout | `src/layouts/PartnerLayout.tsx` | Partner lanes |
| DashboardLayout | `src/layouts/DashboardLayout.tsx` | Generic dashboards |
| InternalLayout | `src/layouts/InternalLayout.tsx` | Internal pages with Wolf Assistant |

---

## Guard Components

| Guard | Path | Purpose |
|-------|------|---------|
| OwnerGuard | `src/components/guards/RoleGuards.tsx` | Owner-only access |
| ProtectedRoute | `src/components/ProtectedRoute.tsx` | Role-based access |
| ProtectedISORoute | `src/components/ProtectedISORoute.tsx` | ISO partner access |
| ProtectedFunderRoute | `src/components/ProtectedFunderRoute.tsx` | Funder access |

---

## Notes

1. All protected routes require authentication.
2. Role hierarchy is enforced via `user_roles` table in Supabase.
3. Legacy aliases are maintained for backwards compatibility.
4. Tenant isolation is enforced via RLS policies on `tenant_id`.
