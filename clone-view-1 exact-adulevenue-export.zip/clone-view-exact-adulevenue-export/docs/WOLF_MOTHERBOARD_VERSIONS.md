# Wolf Motherboard Version History

This document tracks the evolution of Wolf Motherboard governance features.

---

## V19 – Governance Automation Engine

### What V19 Does

V19 transforms passive governance signals into an automated workflow with scheduled scans, persistent alerts, one-click remediation actions, and full audit trail. It builds on V14 (billing), V17 (playbook drift), and V18 (IP defense) by adding persistence, alerting, and remediation logging.

The system runs scheduled governance scans, compares results against configurable thresholds, creates alerts when thresholds are breached, and logs all remediation actions for audit purposes.

### Where to Access

| Feature | Location |
|---------|----------|
| **Governance Overview** | Wolf Motherboard → Governance tab |
| **Alerts Panel** | Wolf Motherboard → Governance tab → Alerts tab |
| **Brand Comparison** | Wolf Motherboard → Governance tab → Brand Comparison tab |
| **Reports History** | Wolf Motherboard → Governance tab → Reports tab |
| **Actions Audit** | Wolf Motherboard → Governance tab → Actions tab |

### Core Capabilities

1. **Scheduled Governance Scan** – `wf-governance-scan-cron` wraps existing scan, persists snapshots to `wf_governance_reports`
2. **Governance Alerts** – Threshold-based alerts stored in `wf_governance_alerts` with acknowledge/resolve workflow
3. **One-Click Remediation** – Routes to existing functions (playbook drift resolve, filing packet create), logs to `wf_governance_actions`
4. **Governance Report Export** – HTML export with disclaimers, browser print-to-PDF
5. **Brand Comparison View** – Side-by-side readout of defense scores and metrics per brand
6. **Audit Trail** – All actions logged to `wf_governance_actions`

### How to Use

#### Running a Governance Scan
1. Open **Wolf Motherboard** → **Governance** tab
2. Click **"Quick Scan"** for live results (not persisted)
3. Click **"Full Scan + Save"** to persist results and trigger alert checks

#### Managing Alerts
1. Navigate to **Alerts** tab
2. Open alerts show threshold breaches with current vs threshold values
3. Click **"Acknowledge"** to mark as seen
4. Click **"Resolve"** when issue is fixed
5. Alert badge in summary strip shows open alert count

#### Exporting Reports
1. Navigate to **Reports** tab
2. View historical scan snapshots
3. Click **"Export"** to download HTML report
4. Use browser print-to-PDF for PDF version

#### Brand Comparison
1. Navigate to **Brand Comparison** tab
2. View defense scores, asset counts, and critical items per brand
3. Identify which brands need attention

### Database Changes

| Table | Purpose |
|-------|---------|
| `wf_governance_reports` | Scan snapshots (summary, checks, signals) |
| `wf_governance_actions` | Remediation audit trail |
| `wf_governance_alerts` | Threshold breach alerts with status workflow |

### Governance Logic Additions

New signals added to `wf-governance-scan` output:

```typescript
signals.alerts = {
  open_count: number,
  high_severity_open_count: number
}
summary.automation_status = "ok" | "issues"
```

Alert thresholds configurable via `wolf_master_config`:

```json
{
  "category": "governance",
  "key": "alert_thresholds",
  "value": {
    "ip_defense_score_min": 70,
    "unpriced_events_max": 0,
    "playbook_pending_drift_max": 0,
    "legal_backlog_max": 5
  }
}
```

### Safety Guardrails

🔒 **Non-negotiable protections enforced:**

1. **All remediation actions show confirmation modal** before execution
2. **No external API calls or auto-filing** – internal documentation only
3. **Alerts are internal objects only** – email notifications deferred to V19.1+
4. **UI copy uses neutral language** – "internal configuration update", "review with your team"
5. **Report disclaimers** – Every exported report includes "INTERNAL DOCUMENT – NOT LEGAL ADVICE" header

### Config/Env Notes

- Alert thresholds stored in `wolf_master_config` (category: governance, key: alert_thresholds)
- Default thresholds seeded on migration
- All RLS policies use `tenant_id` + `wf_tenant_users` pattern for isolation
- No additional environment variables required

---

## V18 – IP Defense War Room + Evidence Locker

### What V18 Does

V18 introduces a complete **IP Defense** layer for Wolf Fund and all ecosystem brands. It provides brand-level visibility into "defense readiness" (how well-protected each brand's intellectual property is) and asset-level evidence bundling for attorney preparation.

The system tracks defense status progression (`draft` → `prepped` → `attorney_reviewed` → `filed_externally`) for each IP asset, surfaces gaps in coverage, and enables one-click generation of comprehensive evidence bundles that stitch together all relevant documentation for a given asset. **No auto-filing occurs anywhere** — this is strictly internal documentation and attorney prep tooling.

### Where to Access

| Feature | Location |
|---------|----------|
| **Defense War Room** | Wolf Motherboard → Defense tab |
| **Evidence Locker** | IP Guardian → Select an asset → Evidence Locker tab |
| **Governance Signals** | Wolf Motherboard → Governance tab (ip_defense signals) |

### How to Use

#### Viewing Brand Defense Readiness
1. Open **Wolf Motherboard** → **Defense** tab
2. Each brand card shows:
   - Defense Readiness score (0-100) with badge (✅/⚠️/🟥)
   - Key metrics: high/critical assets, with packets, attorney-reviewed, externally filed
   - Gap counts: assets missing packets, AI-generated without drafts
3. Click **"Open IP Guardian"** to drill into a specific brand's assets

#### Generating an Evidence Bundle
1. Open **IP Guardian**
2. Select any IP asset from the list
3. Navigate to the **Evidence Locker** tab
4. Review the timeline (versions + events) and linked drafts/packets
5. Click **"Generate Evidence Bundle"**
6. Add optional notes for attorney
7. Preview the generated HTML or download it

#### Marking Packets as Reviewed/Filed
1. In the Evidence Locker, find the **Filing Packets** section
2. Toggle **"Attorney Reviewed"** when counsel has reviewed
3. Toggle **"Externally Filed"** (manual only) when you've filed outside the system
4. Add **attorney name** and **filing reference** as needed

### Governance Signals

V18 extends `wf-governance-scan` with:

```typescript
signals.ip_defense = {
  brand_readiness: {
    "wolf-fund": { 
      score: 90, 
      high_critical_no_packet: 0, 
      unreviewed_critical: 1 
    },
    "abg": { 
      score: 72, 
      high_critical_no_packet: 2, 
      unreviewed_critical: 3 
    }
  }
}
```

**New Checks:**
- `ip.defense_gaps` — Warns when high/critical assets lack packets or drafts
- `ip.unreviewed_critical` — Counts critical assets without attorney review

**Summary Status:**
- `summary.defense_status` = `"ok"` | `"issues"` (alongside billing/ip/ai/playbook)

### Database Changes

| Table | New Columns |
|-------|-------------|
| `wf_ip_assets` | `defense_status`, `defense_notes` |
| `wf_ip_filing_packets` | `attorney_reviewed`, `attorney_name`, `externally_filed`, `external_filing_ref` |
| `wf_ip_evidence_bundles` | New table for storing generated bundles |

### Safety Guardrails

🔒 **Non-negotiable protections enforced:**

1. **Evidence Bundle Header**: Every generated bundle includes:
   > "DRAFT – ATTORNEY REVIEW REQUIRED – NOT LEGAL ADVICE – NOT A FILING"

2. **Strong Footer Language**:
   > "This is internal documentation only. Attorney review is required before any legal action or filing."

3. **No Auto-Filing**: `externally_filed` is a manual checkbox only — no external API calls

4. **Internal Language Only**: All UI text uses phrases like "Review with counsel", "Prepare documentation", "Attorney review recommended" — never "filed" or "registration complete"

### Config/Env Notes

- No additional environment variables required for V18
- All RLS policies use `tenant_id` for multi-tenant isolation
- Evidence bundles are stored as HTML in database (no file storage needed)

---

## V20 – Dev Autopilot & Live Suggestions

### Purpose

Turn Wolf Motherboard into a senior dev lead that constantly watches what's being built and surfaces reminders like:
- "This route isn't in any playbook yet."
- "You're using this event, but it's not priced."
- "This brand asset isn't in IP Guardian."
- "This flow has no SOP link."

### Where to Access

| Feature | Location |
|---------|----------|
| **Dev Assist Tab** | Wolf Motherboard → Dev Assist tab |
| **Dev Health Summary** | Dev Assist → Summary strip at top |
| **Dev To-Dos** | Dev Assist → Actionable suggestion list |
| **Recent Actions** | Dev Assist → History at bottom |

### Key Additions

1. **Dev Autopilot Signal Layer**
   - New `signals.dev_autopilot` section in `wf-governance-scan`:
     - `unpriced_events` - event types being logged but not in billing plans
     - `unplaybooked_routes` - routes not covered by any brand playbook
     - `unregistered_ip_assets` - critical flows/components not in IP Guardian
     - `flows_without_sop` - playbook flows missing SOP URLs

2. **Developer To-Do Panel** (Motherboard → Dev Assist tab)
   - "Dev To-Dos" grouped by area: Billing, IP, Playbooks, AI Changes
   - Each item comes from suggestions in the governance scan
   - One click to:
     - Navigate to IP Guardian / Billing / Playbooks
     - Mark as "Handled" (creates backlog entry) or "Ignore" (with audit trail)

3. **Real Remediation Logic** (V20.1 Fix)
   - "Mark as Handled" now performs actual actions:
     - `dev.unpriced_events.handled` → Creates `wf_governance_actions` TODO for billing team
     - `dev.unplaybooked_routes.handled` → Creates TODO for playbook coverage
     - `dev.unregistered_ip_assets.handled` → Creates IP registration backlog
     - `dev.flows_without_sop.handled` → Creates SOP documentation backlog

4. **Config-Driven Route List** (V20.1 Fix)
   - Application routes pulled from `wolf_master_config` (category: `app`, key: `known_routes`)
   - No more hardcoded route array in edge function
   - Add new routes via config without code deployment

5. **Tenant-Scoped IP Queries** (V20.1 Fix)
   - IP asset comparisons now filter by `tenant_id`
   - Prevents cross-tenant asset leakage in multi-brand deployments

6. **Dev Suggestion Logging**
   - Every "Apply", "Ignore", or "Open" click logged to `wf_dev_suggestion_events`
   - Tracks: who clicked, what suggestion, when, resolution, metadata

7. **UX Polish** (V20.1 Fix)
   - Icons for each area (DollarSign, Shield, Code, BookOpen, FileText)
   - DateTime formatting shows time, not just date
   - React Router navigation instead of window.location
   - Proper loading states with Loader2 spinner

### Database Changes

```sql
-- New table for tracking dev actions on suggestions
CREATE TABLE wf_dev_suggestion_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES wf_tenants(id),
  suggestion_id text NOT NULL,
  action text NOT NULL CHECK (action IN ('opened', 'applied', 'ignored')),
  area text NOT NULL CHECK (area IN ('billing', 'ip', 'playbook', 'defense', 'ai_change')),
  source_check_id text,
  performed_by uuid,
  performed_at timestamptz DEFAULT now(),
  metadata jsonb DEFAULT '{}'
);

-- V20.1: Performance indexes
CREATE INDEX idx_dev_suggestion_events_tenant_performed 
  ON wf_dev_suggestion_events(tenant_id, performed_at DESC);
CREATE INDEX idx_dev_suggestion_events_tenant_suggestion 
  ON wf_dev_suggestion_events(tenant_id, suggestion_id);

-- V20.1: Config-driven routes
INSERT INTO wolf_master_config (category, key, value)
VALUES ('app', 'known_routes', '{"routes": ["/admin", "/credit-specialist-dashboard", ...]}');
```

### New Governance Checks (V20)

- `dev.unpriced_events` - warns when event types are used but not priced
- `dev.unplaybooked_routes` - warns when routes aren't in any playbook
- `dev.unregistered_ip_assets` - warns when critical flows aren't in IP Guardian
- `dev.flows_without_sop` - warns when playbook flows lack SOP documentation

### New Suggestions

Each check generates a corresponding suggestion with actions:
- **Navigate** - opens the relevant dashboard (Billing, IP Guardian, Playbooks)
- **Mark as Handled** - creates backlog entry in `wf_governance_actions` + logs to `wf_dev_suggestion_events`
- **Ignore** - logs decision to skip this item

### Remediation Action Types

| Target | Action Type | What It Does |
|--------|-------------|--------------|
| `dev.unpriced_events.handled` | `flag_unpriced_events` | Creates TODO with list of events needing pricing |
| `dev.unplaybooked_routes.handled` | `flag_unplaybooked_routes` | Creates TODO with routes needing playbook coverage |
| `dev.unregistered_ip_assets.handled` | `create_ip_backlog` | Creates IP registration task list |
| `dev.flows_without_sop.handled` | `create_sop_backlog` | Creates SOP documentation task list |

### Safety Guardrails

1. **Internal-Only Guidance**: All wording uses "Engineering reminder", "Governance recommendation", "Suggested developer action"
2. **No Auto-Enforcement**: Dev Assist only surfaces suggestions — creates backlog entries, doesn't auto-change config
3. **Audit Trail**: Every action logged to both `wf_dev_suggestion_events` and `wf_governance_actions`
4. **Legal Separation**: All legal-heavy language flows through V16-V19 guardrails
5. **Rate Limiting**: Duplicate-click protection via React Query mutation state

---

## Previous Versions

### V17 – Playbook Drift + SOP Compliance
- Brand playbooks with allowed routes/components/functions
- Drift detection for out-of-playbook items
- Approve/ignore workflow with auto-update to playbooks
- SOP links per brand

### V16 – Filing Prep Mode
- AI-generated legal drafts (copyright/trademark/patent)
- Filing packet generation with checklists
- Print-ready HTML output
- No auto-filing — attorney review required

### V15 – IP Guardian Core
- Asset registration and tracking
- Version history with hash signatures
- IP events timeline
- Legal priority tagging

### V13-V14 – Billing + Governance Spine
- Multi-tenant usage tracking
- Per-event billing with wf_usage_events
- Governance scan with billing/IP/AI signals

### V1-V12 – Foundation
- Wolf master config and flow rules
- Feature flags with auto-disable
- Health logging and telemetry
- Routing profiles and thresholds
