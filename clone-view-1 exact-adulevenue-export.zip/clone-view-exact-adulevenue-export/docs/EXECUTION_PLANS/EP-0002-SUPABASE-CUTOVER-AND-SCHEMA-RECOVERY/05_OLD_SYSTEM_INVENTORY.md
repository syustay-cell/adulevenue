# EP-0002 — OLD system inventory (Lovable)

Generated: 2025-12-19T17:27:26.168Z
Source of truth: **repo:/supabase (Lovable)**

## Summary counts
```
tables=237
edgeFunctions=169
functions(rpcs+db)=73
triggers=69
policies=236
rlsEnable=240
```

## Tables (ALL)
```
abg_project_funding_links
admin_sensitive_data_access
ai_events
call_sessions
client_activity
collection_cases
collection_events
commissions
compliance_deal_checks
compliance_disclosure_templates
compliance_states
credit_public_checks
credit_public_snapshot
credit_repair_dispute_drafts
credit_standards_reference
deals
email_messages
email_templates
fund_deal_allocations
funded_deals
funds
industry_rules
intake_clients
investor_positions
investors
iso_commissions
iso_partners
iso_statistics
iso_training_completions
iso_training_modules
kyc_results
lead_call_attempts
lead_call_logs
lead_files
lead_import_batches
lead_list_members
lead_lists
lead_lock_requests
lead_locks
lead_ownership_requests
lead_ownerships
lead_release_requests
lead_research_logs
lead_share_requests
lead_sources
lead_strategy_files
lead_tasks
leads
mca_products
outreach_enrollments
outreach_events
outreach_sequences
outreach_steps
product_pricing_rules
public.abg_projects
public.activity_events
public.activity_feed
public.activity_log
public.admin_application_views
public.application_comments
public.application_transactions
public.audit_logs
public.autopilot_actions
public.bank_verification_sessions
public.billing_plans
public.billing_subscriptions
public.calls
public.chat_messages
public.client_communications
public.client_notes
public.client_vault
public.communication_logs
public.contract_templates
public.conversation_participants
public.conversations
public.credit_attorney_reviews
public.credit_case_v2_activity
public.credit_cases_v2
public.credit_dispute_cases_v2
public.credit_dispute_drafts_v2
public.credit_dispute_items_v2
public.credit_disputes
public.credit_documents_vault
public.credit_fix_required_docs
public.credit_fix_task_templates
public.credit_repair_applications
public.credit_violation_templates
public.deal_commissions
public.deal_documents
public.deal_events
public.deal_funder_assignments
public.deal_offers
public.deal_protection_logs
public.deal_rooms
public.document_extractions
public.document_templates
public.fast_track_applications
public.funded_contracts
public.funded_deals
public.funder_applications
public.funder_communication_log
public.funder_pipeline
public.funder_submissions
public.funders
public.funding_calls
public.god_mode_alerts
public.intake_logs
public.iso_commissions
public.iso_partner_applications
public.lead_action_queue
public.lead_assignments
public.lead_conflict_requests
public.lead_events
public.lead_import_errors
public.lead_lane_assignments
public.lead_lane_events
public.lead_list_members
public.lead_notes
public.lead_pipeline
public.lead_scoring_rules
public.legal_cases
public.legal_client_applications
public.legal_risk_feedback
public.loan_applications
public.merchant_profiles
public.merchants
public.message_templates
public.messages_sent
public.outbound_emails
public.outreach_campaigns
public.outreach_inboxes
public.outreach_tasks
public.partner_applications
public.partner_invite_codes
public.portal_profiles
public.processing_vendor_rates
public.profiles
public.renewal_opportunities
public.risk_alerts
public.signature_requests
public.syndication_partners
public.system_anomalies
public.system_optimization_suggestions
public.templates_master_library
public.terminals
public.underwriting_feedback
public.underwriting_files
public.user_presence
public.user_roles
public.user_settings
public.wf_ai_cost_summary
public.wf_ai_usage_events
public.wf_alert_channels
public.wf_alert_events
public.wf_autopilot_actions
public.wf_autopilot_policies
public.wf_autopilot_runs
public.wf_billing_plans
public.wf_chat_session_overrides
public.wf_client_portal_tokens
public.wf_contract_templates
public.wf_credit_status
public.wf_dev_suggestion_events
public.wf_email_outbox
public.wf_email_templates
public.wf_events
public.wf_generated_contracts
public.wf_insight_runs
public.wf_insights
public.wf_ip_actions
public.wf_ip_assets
public.wf_ip_events
public.wf_ip_filing_packets
public.wf_ip_legal_drafts
public.wf_ip_versions
public.wf_leads
public.wf_playbook_drift_items
public.wf_playbook_runs
public.wf_playbook_steps
public.wf_playbook_triggers
public.wf_playbooks
public.wf_suggestions
public.wf_tasks
public.wf_tenant_billing_state
public.wf_tenant_users
public.wf_tenants
public.wf_usage_events
public.wf_worker_tags
public.wolf_ai_limits
public.wolf_credit_cases
public.wolf_devices
public.wolf_documents
public.wolf_events
public.wolf_feature_flags
public.wolf_flow_rules
public.wolf_health_log
public.wolf_identity_verifications
public.wolf_input_snapshots
public.wolf_legal_scans
public.wolf_master_config
public.wolf_master_config_history
public.wolf_provider_health
public.wolf_screenshot_attempts
public.wolf_security_correlations
public.wolf_security_events
public.wolf_session_analytics
public.wolf_session_settings
public.wolf_sessions
public.wolf_tenant_feature_flags
public.wolf_tenant_users
public.wolf_tenants
public.wolf_underwriting_cases
public.worker_activity_logs
public.worker_applications
public.worker_assignments
public.workflow_tasks
renewal_offers
renewal_rules
risk_tiers
settlements
sms_messages
spvs
system_settings
underwriting_cases
underwriting_metrics
underwriting_notes
underwriting_tasks
uw_rule_sets
uw_rules
wf_governance_actions
wf_governance_alerts
wf_governance_reports
wf_ip_evidence_bundles
wf_manual_tasks
wolf_suggestions
worker_assignments
worker_commission_splits
```

## Edge Functions (ALL, from repo supabase/functions/*)
```
abg-link-project-funding
ai-alert-engine
ai-autopilot-engine
ai-autopilot-scheduler
ai-draft-outreach
ai-insight-engine
ai-lead-worker
ai-playbook-engine
ai-report-get-or-refresh
anti-backdoor-monitor
apply-suggestion
attorney-review-router
auto-trigger-underwriting
autopilot-optimizer
bank-login-verify
billing-webhook
calculate-deal-commissions
calculate-iso-commissions
chat-assistant
check-follow-ups
client-lock-manager
complete-credit-repair-case
create-deal-room
create-vault-entry
credit-letter-compile
credit-readiness-test
credit-repair-analyze-report
credit-repair-generate-letters
credit-repair-generate-strategy
credit-repair-suggest-followup
credit-violation-detect
detect-renewals
document-generate-from-template
docusign-webhook
email-bounce-webhook
email-events
evaluate-routing
export-data
extract-all-documents
extract-id-fields
funder-pipeline-sync
generate-suggestions
get-bank-mirror
god-mode-feed
hubspot-webhook
identify-renewal-opportunities
initiate-docusign
iso-get-commissions
iso-get-pipeline
iso-submit-deal
lead-action-dispatch
lead-assign-queue
lead-enrich-ai
lead-enrich-classify
lead-enrichment-spider
lead-import-create-list
lead-import-parse
lead-intake-router
lead-lane-sync
lead-record-outcome
legal-risk-scan
log-activity
log-audit-event
marketing-knight-track
merchant-onboard
motherboard-apply-config-change
motherboard-generate-suggestions
motherboard-rollback-config
move-to-credit-repair
night-agent-router
notify-credit-repair-assignment
notify-status-change
notify-worker-approval
optimizer-cron
outreach-create-campaign
outreach-schedule-batch
outreach-send-batch
outreach-task-manager
outreach-webhook
phase8-deploy-audit
phase8-ledger-smoke
process-lead-list
rate-sheet-compare
realtime-voice-token
reports-get-admin-metrics
research-copilot
research-intel
resend-email-webhook
save-intake-route
save-research-intake
scan-risk-alerts
scheduled-legal-risk-scan
scheduled-underwriting-rescan
send-client-info
send-contract-to-client
send-dispute-letters
send-engagement-message
send-iso-confirmation-email
send-notification-email
send-smart-email
send-smart-sms
send-sms-notification
send-test-notifications
send-to-funder
sms-webhook
suggest-next-action
task-generator
text-to-speech
trigger-communication
twilio-sms-inbound
twilio-sms-status
underwriter-analyze-application
underwriter-assistant
upload-deal-contract
upload-template
verify-bank-statement
wf-ai-cost-summary
wf-ai-mode-engine
wf-ai-usage-log
wf-ai-worker
wf-analytics-overview
wf-billing-invoice-preview
wf-billing-log-usage
wf-billing-usage-summary
wf-case-auto-actions
wf-client-portal-exchange
wf-client-portal-request-link
wf-contract-generate
wf-credit-case-open
wf-credit-dispute-generate
wf-credit-dispute-mark-sent
wf-credit-dispute-save
wf-credit-monitor
wf-email-queue
wf-email-send
wf-governance-scan
wf-governance-scan-cron
wf-ip-auto-register
wf-ip-evidence-bundle-generate
wf-ip-filing-generate
wf-ip-legal-generate
wf-lead-assign
wf-lead-intake
wf-playbook-drift-resolve
wolf-admin-impersonate
wolf-assistant
wolf-brain-enrich-lead
wolf-brain-lead-intake
wolf-build-input-snapshot
wolf-call-bridge
wolf-credit-plan-generate
wolf-credit-screener
wolf-hub-chat
wolf-legal-scan
wolf-live-session-feed
wolf-login-guard
wolf-motherboard-health
wolf-portal-router
wolf-provider-health-check
wolf-research-intel
wolf-security-correlate
wolf-security-monitor
wolf-session-end
wolf-session-expirer
wolf-session-heartbeat
wolf-session-start
wolf-session-validate
wolf-tenant-bootstrap
wolf-underwriter-eval
```

## RPCs / DB functions (ALL, from migrations create function)
```
claim_next_research_lead
create_underwriting_case_for_application
get_lead_lock_state
get_next_lead
get_next_lead_for_agent
get_next_lead_for_worker
lock_lead_for_agent
lock_lead_for_application
log_sensitive_access
mark_call_outcome
move_application_to_credit_repair
public.audit_role_change
public.can_access_tenant
public.can_access_vault
public.claim_next_research_lead
public.complete_funding_call
public.get_next_dialer_lead
public.get_next_email_lead
public.get_next_lead_for_agent
public.get_next_lead_for_worker
public.get_role_level
public.handle_new_user_profile
public.handle_new_user_signup
public.handle_new_worker_signup
public.handle_updated_at
public.has_role
public.has_role_or_higher
public.is_legal
public.is_owner
public.is_owner_or_tenant_admin
public.is_superowner
public.is_tenant_member
public.lock_lead_for_client_work
public.lock_lead_for_opener
public.log_autopilot_action_event
public.log_credit_case_v2_event
public.log_funder_pipeline_event
public.log_god_mode_alert_event
public.log_identity_verification_event
public.log_lead_pipeline_event
public.log_merchant_profile_event
public.log_system_anomaly_event
public.log_wolf_tenant_event
public.log_wolf_tenant_feature_flag_event
public.log_wolf_tenant_user_event
public.promote_to_worker
public.record_call_attempt
public.request_lead_conflict
public.set_wf_autopilot_actions_updated_at
public.set_wf_autopilot_policies_updated_at
public.set_wf_insights_updated_at
public.set_wf_suggestions_updated_at
public.start_underwriting_case
public.submit_underwriting_package
public.tenant_has_access
public.tenant_is_admin
public.update_case_stage
public.update_portal_profiles_updated_at
public.update_updated_at_column
public.user_tenant_id
record_call_attempt
record_call_outcome
request_lead_release
request_lead_release_or_split
request_lead_share
research_center_stats
respond_lead_share
respond_to_lead_lock_request
respond_to_lead_release
respond_to_lead_request
start_call_session
stop_call_session
update_wf_ip_updated_at
```

## Triggers (ALL, from migrations)
```
set_updated_at ON public.fast_track_applications -> public.handle_updated_at  (20251129013534_ec4a5826-0a8b-4456-ad2c-6fe7f85dddc1.sql)
update_application_comments_updated_at ON public.application_comments -> public.handle_updated_at  (20251129032005_51cf35ac-f1f0-48a0-a9c6-f3dc59756e31.sql)
update_loan_applications_updated_at ON public.loan_applications -> public.handle_updated_at  (20251129033633_ec376bdf-d2b5-472b-a255-3b174d6a2de7.sql)
update_credit_repair_applications_updated_at ON public.credit_repair_applications -> public.handle_updated_at  (20251129033633_ec376bdf-d2b5-472b-a255-3b174d6a2de7.sql)
on_auth_user_created_worker ON auth.users -> public.handle_new_worker_signup  (20251129042018_e25b80e3-b546-45ca-b781-cc32f6ad4b1d.sql)
update_intake_logs_updated_at ON public.intake_logs -> public.handle_updated_at  (20251129050848_b226646a-fd78-448e-8c1f-30a2209a4551.sql)
on_auth_user_created ON auth.users -> public.handle_new_user_signup  (20251129074848_6ee5ab1e-8cc7-4a56-b4a8-6649afae9997.sql)
update_iso_partner_applications_updated_at ON public.iso_partner_applications -> public.handle_updated_at  (20251129174029_ed7fd888-d656-4100-a98d-fcf12b22a6a6.sql)
update_underwriting_cases_updated_at ON underwriting_cases -> handle_updated_at  (20251130055328_63935279-7585-45bf-9830-ad1d55731196.sql)
create_underwriting_case_fast_track ON fast_track_applications -> create_underwriting_case_for_application  (20251130055328_63935279-7585-45bf-9830-ad1d55731196.sql)
create_underwriting_case_loan ON loan_applications -> create_underwriting_case_for_application  (20251130055328_63935279-7585-45bf-9830-ad1d55731196.sql)
update_funded_contracts_updated_at ON public.funded_contracts -> public.handle_updated_at  (20251130174120_4b80a65b-8637-4120-946d-6fb1b9499491.sql)
update_iso_commissions_updated_at ON public.iso_commissions -> public.handle_updated_at  (20251130175018_1aba0957-eaa8-4111-aae6-bef8084ff9b5.sql)
update_risk_alerts_updated_at ON public.risk_alerts -> public.handle_updated_at  (20251130175018_1aba0957-eaa8-4111-aae6-bef8084ff9b5.sql)
update_contract_templates_updated_at ON public.contract_templates -> public.handle_updated_at  (20251130175018_1aba0957-eaa8-4111-aae6-bef8084ff9b5.sql)
update_lead_assignments_updated_at ON public.lead_assignments -> public.handle_updated_at  (20251130201708_a52c7e70-19f8-48b0-bd98-ef1cea62075c.sql)
update_email_templates_updated_at ON email_templates -> handle_updated_at  (20251130213326_90150b31-539c-4c92-aaea-73f0090c5781.sql)
update_dispute_drafts_updated_at ON credit_repair_dispute_drafts -> public.handle_updated_at  (20251201045513_40142c6a-7f18-4326-83ab-6dfd2eba02cb.sql)
set_billing_plans_updated_at ON public.billing_plans -> public.handle_updated_at  (20251201065910_2d08f094-aaac-42cb-bb42-9d11eb1b2275.sql)
set_billing_subscriptions_updated_at ON public.billing_subscriptions -> public.handle_updated_at  (20251201065910_2d08f094-aaac-42cb-bb42-9d11eb1b2275.sql)
update_leads_updated_at ON leads -> handle_updated_at  (20251201203902_cc9fdc1b-d256-4f83-9cfa-f4fcc3f77566.sql)
on_auth_user_created_profile ON auth.users -> public.handle_new_user_profile  (20251202185017_9edfe4dc-fffc-4b25-a445-0bf6b35f4a7f.sql)
tr_wt_updated ON public.workflow_tasks -> public.handle_updated_at  (20251203011126_768cb84a-44c0-45e4-9ff8-de1164251240.sql)
tr_mt_updated ON public.message_templates -> public.handle_updated_at  (20251203011126_768cb84a-44c0-45e4-9ff8-de1164251240.sql)
update_outreach_tasks_updated_at ON public.outreach_tasks -> public.handle_updated_at  (20251203013241_c99f7c13-c387-4968-8654-32f3efafa68e.sql)
update_messages_sent_updated_at ON public.messages_sent -> public.handle_updated_at  (20251203013241_c99f7c13-c387-4968-8654-32f3efafa68e.sql)
update_conversations_updated_at ON public.conversations -> public.handle_updated_at  (20251203035945_58796b61-38fa-4b06-9f44-5af15b1cf1b7.sql)
update_wolf_underwriting_cases_updated_at ON public.wolf_underwriting_cases -> public.handle_updated_at  (20251204053652_7fe5465a-373a-46ac-8b0e-6ba35e6f39b2.sql)
update_wolf_legal_scans_updated_at ON public.wolf_legal_scans -> public.handle_updated_at  (20251204053652_7fe5465a-373a-46ac-8b0e-6ba35e6f39b2.sql)
trigger_portal_profiles_updated_at ON public.portal_profiles -> public.update_portal_profiles_updated_at  (20251204064355_b8411004-8baa-42e9-a13d-56b7b4e1985b.sql)
trigger_audit_role_change ON public.user_roles -> public.audit_role_change  (20251204064355_b8411004-8baa-42e9-a13d-56b7b4e1985b.sql)
set_wf_leads_updated_at ON public.wf_leads -> public.handle_updated_at  (20251204212451_83616b0d-9a85-4593-a973-0eac3baaeac6.sql)
set_credit_cases_v2_updated_at ON public.credit_cases_v2 -> public.handle_updated_at  (20251204212451_83616b0d-9a85-4593-a973-0eac3baaeac6.sql)
set_credit_dispute_items_v2_updated_at ON public.credit_dispute_items_v2 -> public.handle_updated_at  (20251204222049_59ffb53c-670d-4591-bedb-346ad41858d4.sql)
set_credit_dispute_drafts_v2_updated_at ON public.credit_dispute_drafts_v2 -> public.handle_updated_at  (20251204222049_59ffb53c-670d-4591-bedb-346ad41858d4.sql)
set_wf_tasks_updated_at ON public.wf_tasks -> public.handle_updated_at  (20251204222049_59ffb53c-670d-4591-bedb-346ad41858d4.sql)
update_wf_ip_assets_updated_at ON public.wf_ip_assets -> update_wf_ip_updated_at  (20251205030810_9598b332-1f61-4e7f-9fbe-7bf37270b4a8.sql)
update_wf_ip_legal_drafts_updated_at ON public.wf_ip_legal_drafts -> update_wf_ip_updated_at  (20251205030810_9598b332-1f61-4e7f-9fbe-7bf37270b4a8.sql)
update_wf_playbook_drift_updated_at ON public.wf_playbook_drift_items -> public.handle_updated_at  (20251205051903_92a99310-db60-4c35-a150-d9d373e32c48.sql)
update_worker_assignments_updated_at ON public.worker_assignments -> public.update_updated_at_column  (20251206030117_ca506833-7dc7-468d-9304-17bf0ab48f26.sql)
update_funded_deals_updated_at ON public.funded_deals -> public.update_updated_at_column  (20251206030117_ca506833-7dc7-468d-9304-17bf0ab48f26.sql)
update_abg_projects_updated_at ON public.abg_projects -> public.update_updated_at_column  (20251206030117_ca506833-7dc7-468d-9304-17bf0ab48f26.sql)
update_wolf_ai_limits_updated_at ON public.wolf_ai_limits -> public.update_updated_at_column  (20251206033341_ed347fd6-e58c-47b1-b150-367d5a446fe7.sql)
update_document_templates_updated_at ON public.document_templates -> public.update_updated_at_column  (20251206033341_ed347fd6-e58c-47b1-b150-367d5a446fe7.sql)
update_wolf_provider_health_updated_at ON public.wolf_provider_health -> public.update_updated_at_column  (20251206033341_ed347fd6-e58c-47b1-b150-367d5a446fe7.sql)
update_lead_scoring_rules_updated_at ON public.lead_scoring_rules -> public.update_updated_at_column  (20251206033341_ed347fd6-e58c-47b1-b150-367d5a446fe7.sql)
update_templates_master_library_updated_at ON public.templates_master_library -> public.update_updated_at_column  (20251206213810_5b756b33-5b91-43de-b7f5-8e17e26ef7f2.sql)
update_user_settings_updated_at ON public.user_settings -> public.update_updated_at_column  (20251207061405_220b519b-512f-448f-890a-2d3d269caeb2.sql)
trg_wf_suggestions_updated_at ON public.wf_suggestions -> public.set_wf_suggestions_updated_at  (20251207170658_7881f272-e84d-49d8-9fdb-6081e535d014.sql)
trg_wf_insights_updated_at ON public.wf_insights -> public.set_wf_insights_updated_at  (20251207182117_8d955cc7-72a8-41dd-95c9-1c927c2b8fd5.sql)
trg_wf_autopilot_actions_updated_at ON public.wf_autopilot_actions -> public.set_wf_autopilot_actions_updated_at  (20251207200202_e5c560cb-6dae-4274-b081-e0606106bba2.sql)
trg_wf_autopilot_policies_updated_at ON public.wf_autopilot_policies -> public.set_wf_autopilot_policies_updated_at  (20251207205104_00879095-0595-4f6a-9200-2c11e9afcf25.sql)
set_wf_playbooks_updated_at ON public.wf_playbooks -> public.update_updated_at_column  (20251207211253_6b0a6bc4-7664-429d-a852-49c975d2d18d.sql)
update_partner_applications_updated_at ON public.partner_applications -> public.update_updated_at_column  (20251208225826_e41b6972-f680-4382-8b3f-942b75db8019.sql)
update_worker_applications_updated_at ON public.worker_applications -> public.update_updated_at_column  (20251208225826_e41b6972-f680-4382-8b3f-942b75db8019.sql)
update_funder_applications_updated_at ON public.funder_applications -> public.update_updated_at_column  (20251208225826_e41b6972-f680-4382-8b3f-942b75db8019.sql)
update_legal_client_applications_updated_at ON public.legal_client_applications -> public.update_updated_at_column  (20251208225826_e41b6972-f680-4382-8b3f-942b75db8019.sql)
trg_log_identity_verification_event ON public.wolf_identity_verifications -> public.log_identity_verification_event  (20251210090000_phase1_identity_tenant_os.sql)
trg_log_wolf_tenant_event ON public.wolf_tenants -> public.log_wolf_tenant_event  (20251210090000_phase1_identity_tenant_os.sql)
trg_log_wolf_tenant_user_event ON public.wolf_tenant_users -> public.log_wolf_tenant_user_event  (20251210090000_phase1_identity_tenant_os.sql)
trg_log_wolf_tenant_feature_flag_event ON public.wolf_tenant_feature_flags -> public.log_wolf_tenant_feature_flag_event  (20251210090000_phase1_identity_tenant_os.sql)
trg_log_lead_pipeline_event ON public.lead_pipeline -> public.log_lead_pipeline_event  (20251210120000_phase2_core_tables.sql)
trg_log_credit_case_v2_event ON public.credit_dispute_cases_v2 -> public.log_credit_case_v2_event  (20251210120000_phase2_core_tables.sql)
trg_log_funder_pipeline_event ON public.funder_pipeline -> public.log_funder_pipeline_event  (20251210120000_phase2_core_tables.sql)
trg_log_god_mode_alert_event ON public.god_mode_alerts -> public.log_god_mode_alert_event  (20251210120000_phase2_core_tables.sql)
trg_log_autopilot_action_event ON public.autopilot_actions -> public.log_autopilot_action_event  (20251210120000_phase2_core_tables.sql)
trg_log_merchant_profile_event ON public.merchant_profiles -> public.log_merchant_profile_event  (20251210120000_phase2_core_tables.sql)
trg_log_system_anomaly_event ON public.system_anomalies -> public.log_system_anomaly_event  (20251210120000_phase2_core_tables.sql)
on_auth_user_created ON auth.users -> public.handle_new_user_signup  (20251217000100_fix_auth_signup_triggers.sql)
```

## RLS policies (ALL, from migrations)
```
uw_files_admin_read ON public.underwriting_files  (20251202052624_565e57ae-c633-4880-8255-cb12f766166f.sql)
uw_files_admin_write ON public.underwriting_files  (20251202052624_565e57ae-c633-4880-8255-cb12f766166f.sql)
funding_calls_admin_read ON public.funding_calls  (20251202052624_565e57ae-c633-4880-8255-cb12f766166f.sql)
funding_calls_admin_write ON public.funding_calls  (20251202052624_565e57ae-c633-4880-8255-cb12f766166f.sql)
batches_admin_read ON lead_import_batches  (20251202053902_180db81d-7088-4cf3-bb7c-07571d242f60.sql)
batches_admin_write ON lead_import_batches  (20251202053902_180db81d-7088-4cf3-bb7c-07571d242f60.sql)
ownership_requests_worker_read ON lead_ownership_requests  (20251202053902_180db81d-7088-4cf3-bb7c-07571d242f60.sql)
ownership_requests_worker_write ON lead_ownership_requests  (20251202053902_180db81d-7088-4cf3-bb7c-07571d242f60.sql)
ownership_requests_owner_resolve ON lead_ownership_requests  (20251202053902_180db81d-7088-4cf3-bb7c-07571d242f60.sql)
splits_worker_read ON worker_commission_splits  (20251202053902_180db81d-7088-4cf3-bb7c-07571d242f60.sql)
uw_tasks_read ON underwriting_tasks  (20251202053902_180db81d-7088-4cf3-bb7c-07571d242f60.sql)
uw_tasks_write ON underwriting_tasks  (20251202053902_180db81d-7088-4cf3-bb7c-07571d242f60.sql)
strategy_files_read ON lead_strategy_files  (20251202053902_180db81d-7088-4cf3-bb7c-07571d242f60.sql)
strategy_files_write ON lead_strategy_files  (20251202053902_180db81d-7088-4cf3-bb7c-07571d242f60.sql)
profiles_select_own ON public.profiles  (20251202185017_9edfe4dc-fffc-4b25-a445-0bf6b35f4a7f.sql)
profiles_update_own ON public.profiles  (20251202185017_9edfe4dc-fffc-4b25-a445-0bf6b35f4a7f.sql)
profiles_admin_all ON public.profiles  (20251202185017_9edfe4dc-fffc-4b25-a445-0bf6b35f4a7f.sql)
calls_worker_select ON public.calls  (20251202185017_9edfe4dc-fffc-4b25-a445-0bf6b35f4a7f.sql)
calls_worker_insert ON public.calls  (20251202185017_9edfe4dc-fffc-4b25-a445-0bf6b35f4a7f.sql)
lead_notes_worker_select ON public.lead_notes  (20251202185017_9edfe4dc-fffc-4b25-a445-0bf6b35f4a7f.sql)
lead_notes_worker_insert ON public.lead_notes  (20251202185017_9edfe4dc-fffc-4b25-a445-0bf6b35f4a7f.sql)
lead_events_worker_select ON public.lead_events  (20251202185017_9edfe4dc-fffc-4b25-a445-0bf6b35f4a7f.sql)
lead_events_system_insert ON public.lead_events  (20251202185017_9edfe4dc-fffc-4b25-a445-0bf6b35f4a7f.sql)
mt_admin_all ON public.message_templates  (20251203011126_768cb84a-44c0-45e4-9ff8-de1164251240.sql)
mt_view ON public.message_templates  (20251203011126_768cb84a-44c0-45e4-9ff8-de1164251240.sql)
ms_view ON public.messages_sent  (20251203011126_768cb84a-44c0-45e4-9ff8-de1164251240.sql)
ms_insert ON public.messages_sent  (20251203011126_768cb84a-44c0-45e4-9ff8-de1164251240.sql)
ms_update ON public.messages_sent  (20251203011126_768cb84a-44c0-45e4-9ff8-de1164251240.sql)
wt_view ON public.workflow_tasks  (20251203011126_768cb84a-44c0-45e4-9ff8-de1164251240.sql)
wt_update ON public.workflow_tasks  (20251203011126_768cb84a-44c0-45e4-9ff8-de1164251240.sql)
wt_insert ON public.workflow_tasks  (20251203011126_768cb84a-44c0-45e4-9ff8-de1164251240.sql)
outreach_tasks_admin_full ON public.outreach_tasks  (20251203015235_2d327daf-92ac-4aaa-9ea5-ecca96febdbe.sql)
outreach_tasks_workers_own ON public.outreach_tasks  (20251203015235_2d327daf-92ac-4aaa-9ea5-ecca96febdbe.sql)
outreach_tasks_workers_update ON public.outreach_tasks  (20251203015235_2d327daf-92ac-4aaa-9ea5-ecca96febdbe.sql)
lead_list_members_admin ON lead_list_members  (20251206042622_6bd394c4-726d-4864-983b-abde637bac91.sql)
lead_list_members_worker ON lead_list_members  (20251206042622_6bd394c4-726d-4864-983b-abde637bac91.sql)
worker_can_see_own_assignments ON worker_assignments  (20251206042622_6bd394c4-726d-4864-983b-abde637bac91.sql)
worker_can_update_own_assignments ON worker_assignments  (20251206042622_6bd394c4-726d-4864-983b-abde637bac91.sql)
admin_manage_assignments ON worker_assignments  (20251206042622_6bd394c4-726d-4864-983b-abde637bac91.sql)
admin_manage_iso_partners ON iso_partners  (20251206042622_6bd394c4-726d-4864-983b-abde637bac91.sql)
iso_view_self ON iso_partners  (20251206042622_6bd394c4-726d-4864-983b-abde637bac91.sql)
admin_manage_funded_deals ON funded_deals  (20251206042622_6bd394c4-726d-4864-983b-abde637bac91.sql)
iso_view_own_funded_deals ON funded_deals  (20251206042622_6bd394c4-726d-4864-983b-abde637bac91.sql)
admin_manage_abg_links ON abg_project_funding_links  (20251206042622_6bd394c4-726d-4864-983b-abde637bac91.sql)
admin_manage_sequences ON outreach_sequences  (20251206042622_6bd394c4-726d-4864-983b-abde637bac91.sql)
worker_view_sequences ON outreach_sequences  (20251206042622_6bd394c4-726d-4864-983b-abde637bac91.sql)
admin_manage_steps ON outreach_steps  (20251206042622_6bd394c4-726d-4864-983b-abde637bac91.sql)
worker_view_steps ON outreach_steps  (20251206042622_6bd394c4-726d-4864-983b-abde637bac91.sql)
admin_manage_enrollments ON outreach_enrollments  (20251206042622_6bd394c4-726d-4864-983b-abde637bac91.sql)
worker_manage_own_enrollments ON outreach_enrollments  (20251206042622_6bd394c4-726d-4864-983b-abde637bac91.sql)
admin_view_outreach_events ON outreach_events  (20251206042622_6bd394c4-726d-4864-983b-abde637bac91.sql)
worker_view_own_outreach_events ON outreach_events  (20251206042622_6bd394c4-726d-4864-983b-abde637bac91.sql)
admin_manage_iso_commissions ON iso_commissions  (20251206042622_6bd394c4-726d-4864-983b-abde637bac91.sql)
iso_view_own_commissions ON iso_commissions  (20251206042622_6bd394c4-726d-4864-983b-abde637bac91.sql)
wolf_documents_admin_all ON public.wolf_documents  (20251206054759_4ec8f2c2-0f41-4565-98b4-924b499c2a4f.sql)
wolf_documents_worker_select ON public.wolf_documents  (20251206054759_4ec8f2c2-0f41-4565-98b4-924b499c2a4f.sql)
wf_ai_cost_summary_admin ON public.wf_ai_cost_summary  (20251206054759_4ec8f2c2-0f41-4565-98b4-924b499c2a4f.sql)
outreach_inboxes_admin_select ON public.outreach_inboxes  (20251206070336_1764648c-242d-4c26-b2eb-2fbd74cd9ba8.sql)
outreach_inboxes_admin_insert ON public.outreach_inboxes  (20251206070336_1764648c-242d-4c26-b2eb-2fbd74cd9ba8.sql)
outreach_inboxes_admin_update ON public.outreach_inboxes  (20251206070336_1764648c-242d-4c26-b2eb-2fbd74cd9ba8.sql)
outreach_inboxes_admin_delete ON public.outreach_inboxes  (20251206070336_1764648c-242d-4c26-b2eb-2fbd74cd9ba8.sql)
outreach_campaigns_admin_select ON public.outreach_campaigns  (20251206070336_1764648c-242d-4c26-b2eb-2fbd74cd9ba8.sql)
outreach_campaigns_admin_insert ON public.outreach_campaigns  (20251206070336_1764648c-242d-4c26-b2eb-2fbd74cd9ba8.sql)
outreach_campaigns_admin_update ON public.outreach_campaigns  (20251206070336_1764648c-242d-4c26-b2eb-2fbd74cd9ba8.sql)
outreach_campaigns_admin_delete ON public.outreach_campaigns  (20251206070336_1764648c-242d-4c26-b2eb-2fbd74cd9ba8.sql)
outreach_events_admin_select ON public.outreach_events  (20251206070336_1764648c-242d-4c26-b2eb-2fbd74cd9ba8.sql)
outreach_events_system_insert ON public.outreach_events  (20251206070336_1764648c-242d-4c26-b2eb-2fbd74cd9ba8.sql)
outreach_events_system_update ON public.outreach_events  (20251206070336_1764648c-242d-4c26-b2eb-2fbd74cd9ba8.sql)
outreach_events_worker_read_own ON public.outreach_events  (20251206070336_1764648c-242d-4c26-b2eb-2fbd74cd9ba8.sql)
outreach_sequences_admin_select ON public.outreach_sequences  (20251206070336_1764648c-242d-4c26-b2eb-2fbd74cd9ba8.sql)
outreach_sequences_admin_insert ON public.outreach_sequences  (20251206070336_1764648c-242d-4c26-b2eb-2fbd74cd9ba8.sql)
outreach_sequences_admin_update ON public.outreach_sequences  (20251206070336_1764648c-242d-4c26-b2eb-2fbd74cd9ba8.sql)
outreach_sequences_admin_delete ON public.outreach_sequences  (20251206070336_1764648c-242d-4c26-b2eb-2fbd74cd9ba8.sql)
ai_reports_select_roles ON public.ai_reports  (20251206080408_8146dfae-0815-43e1-98ec-cb2a1a3c16f3.sql)
ai_reports_insert_service ON public.ai_reports  (20251206080408_8146dfae-0815-43e1-98ec-cb2a1a3c16f3.sql)
ai_reports_update_service ON public.ai_reports  (20251206080408_8146dfae-0815-43e1-98ec-cb2a1a3c16f3.sql)
outreach_sequences_admin_read ON public.outreach_sequences  (20251206080408_8146dfae-0815-43e1-98ec-cb2a1a3c16f3.sql)
outreach_sequences_admin_write ON public.outreach_sequences  (20251206080408_8146dfae-0815-43e1-98ec-cb2a1a3c16f3.sql)
outreach_inboxes_admin_read ON public.outreach_inboxes  (20251206080408_8146dfae-0815-43e1-98ec-cb2a1a3c16f3.sql)
outreach_inboxes_admin_write ON public.outreach_inboxes  (20251206080408_8146dfae-0815-43e1-98ec-cb2a1a3c16f3.sql)
outreach_campaigns_admin_read ON public.outreach_campaigns  (20251206080408_8146dfae-0815-43e1-98ec-cb2a1a3c16f3.sql)
outreach_campaigns_admin_write ON public.outreach_campaigns  (20251206080408_8146dfae-0815-43e1-98ec-cb2a1a3c16f3.sql)
outreach_events_admin_read ON public.outreach_events  (20251206080408_8146dfae-0815-43e1-98ec-cb2a1a3c16f3.sql)
outreach_events_service_insert ON public.outreach_events  (20251206080408_8146dfae-0815-43e1-98ec-cb2a1a3c16f3.sql)
outreach_events_service_update ON public.outreach_events  (20251206080408_8146dfae-0815-43e1-98ec-cb2a1a3c16f3.sql)
admin_manage_compliance_states ON compliance_states  (20251206092803_55061ddf-2374-4257-8124-a1886d26fee6.sql)
admin_manage_disclosure_templates ON compliance_disclosure_templates  (20251206092803_55061ddf-2374-4257-8124-a1886d26fee6.sql)
admin_manage_compliance_checks ON compliance_deal_checks  (20251206092803_55061ddf-2374-4257-8124-a1886d26fee6.sql)
admin_manage_kyc_results ON kyc_results  (20251206092803_55061ddf-2374-4257-8124-a1886d26fee6.sql)
admin_manage_mca_products ON mca_products  (20251206092803_55061ddf-2374-4257-8124-a1886d26fee6.sql)
admin_manage_risk_tiers ON risk_tiers  (20251206092803_55061ddf-2374-4257-8124-a1886d26fee6.sql)
admin_manage_industry_rules ON industry_rules  (20251206092803_55061ddf-2374-4257-8124-a1886d26fee6.sql)
admin_manage_pricing_rules ON product_pricing_rules  (20251206092803_55061ddf-2374-4257-8124-a1886d26fee6.sql)
admin_manage_collection_cases ON collection_cases  (20251206092803_55061ddf-2374-4257-8124-a1886d26fee6.sql)
admin_manage_collection_events ON collection_events  (20251206092803_55061ddf-2374-4257-8124-a1886d26fee6.sql)
admin_manage_settlements ON settlements  (20251206092803_55061ddf-2374-4257-8124-a1886d26fee6.sql)
admin_manage_renewal_rules ON renewal_rules  (20251206092803_55061ddf-2374-4257-8124-a1886d26fee6.sql)
admin_manage_renewal_offers ON renewal_offers  (20251206092803_55061ddf-2374-4257-8124-a1886d26fee6.sql)
admin_manage_funds ON funds  (20251206092803_55061ddf-2374-4257-8124-a1886d26fee6.sql)
admin_manage_spvs ON spvs  (20251206092803_55061ddf-2374-4257-8124-a1886d26fee6.sql)
admin_manage_investors ON investors  (20251206092803_55061ddf-2374-4257-8124-a1886d26fee6.sql)
admin_manage_investor_positions ON investor_positions  (20251206092803_55061ddf-2374-4257-8124-a1886d26fee6.sql)
admin_manage_fund_allocations ON fund_deal_allocations  (20251206092803_55061ddf-2374-4257-8124-a1886d26fee6.sql)
admin_manage_uw_rule_sets ON uw_rule_sets  (20251206092803_55061ddf-2374-4257-8124-a1886d26fee6.sql)
admin_manage_uw_rules ON uw_rules  (20251206092803_55061ddf-2374-4257-8124-a1886d26fee6.sql)
admin_manage_training_modules ON iso_training_modules  (20251206092803_55061ddf-2374-4257-8124-a1886d26fee6.sql)
admin_manage_training_completions ON iso_training_completions  (20251206092803_55061ddf-2374-4257-8124-a1886d26fee6.sql)
admin_manage_iso_statistics ON iso_statistics  (20251206092803_55061ddf-2374-4257-8124-a1886d26fee6.sql)
workers_read_mca_products ON mca_products  (20251206092803_55061ddf-2374-4257-8124-a1886d26fee6.sql)
workers_read_risk_tiers ON risk_tiers  (20251206092803_55061ddf-2374-4257-8124-a1886d26fee6.sql)
workers_read_training_modules ON iso_training_modules  (20251206092803_55061ddf-2374-4257-8124-a1886d26fee6.sql)
underwriter_read_compliance ON compliance_states  (20251206092803_55061ddf-2374-4257-8124-a1886d26fee6.sql)
underwriter_read_products ON mca_products  (20251206092803_55061ddf-2374-4257-8124-a1886d26fee6.sql)
underwriter_read_pricing ON product_pricing_rules  (20251206092803_55061ddf-2374-4257-8124-a1886d26fee6.sql)
underwriter_read_risk_tiers ON risk_tiers  (20251206092803_55061ddf-2374-4257-8124-a1886d26fee6.sql)
underwriter_manage_compliance_checks ON compliance_deal_checks  (20251206092803_55061ddf-2374-4257-8124-a1886d26fee6.sql)
iso_read_own_statistics ON iso_statistics  (20251206092803_55061ddf-2374-4257-8124-a1886d26fee6.sql)
iso_read_training_modules ON iso_training_modules  (20251206092803_55061ddf-2374-4257-8124-a1886d26fee6.sql)
iso_manage_own_completions ON iso_training_completions  (20251206092803_55061ddf-2374-4257-8124-a1886d26fee6.sql)
admins_can_read_activity_events ON public.activity_events  (20251206150909_396b61df-8700-4913-acef-bf66ce46f1df.sql)
system_can_insert_activity_events ON public.activity_events  (20251206150909_396b61df-8700-4913-acef-bf66ce46f1df.sql)
users_can_read_own_activity_events ON public.activity_events  (20251206150909_396b61df-8700-4913-acef-bf66ce46f1df.sql)
wf_events_owner_admin_select ON public.wf_events  (20251207170658_7881f272-e84d-49d8-9fdb-6081e535d014.sql)
wf_events_worker_self ON public.wf_events  (20251207170658_7881f272-e84d-49d8-9fdb-6081e535d014.sql)
wf_events_system_insert ON public.wf_events  (20251207170658_7881f272-e84d-49d8-9fdb-6081e535d014.sql)
wf_suggestions_owner_admin_select ON public.wf_suggestions  (20251207170658_7881f272-e84d-49d8-9fdb-6081e535d014.sql)
wf_suggestions_target_user ON public.wf_suggestions  (20251207170658_7881f272-e84d-49d8-9fdb-6081e535d014.sql)
wf_suggestions_owner_admin_update ON public.wf_suggestions  (20251207170658_7881f272-e84d-49d8-9fdb-6081e535d014.sql)
wf_suggestions_system_insert ON public.wf_suggestions  (20251207170658_7881f272-e84d-49d8-9fdb-6081e535d014.sql)
wf_insights_owner_admin_select ON public.wf_insights  (20251207182117_8d955cc7-72a8-41dd-95c9-1c927c2b8fd5.sql)
wf_insights_worker_select ON public.wf_insights  (20251207182117_8d955cc7-72a8-41dd-95c9-1c927c2b8fd5.sql)
wf_insights_system_insert ON public.wf_insights  (20251207182117_8d955cc7-72a8-41dd-95c9-1c927c2b8fd5.sql)
wf_insights_owner_admin_update ON public.wf_insights  (20251207182117_8d955cc7-72a8-41dd-95c9-1c927c2b8fd5.sql)
wf_insight_runs_owner_admin_select ON public.wf_insight_runs  (20251207182117_8d955cc7-72a8-41dd-95c9-1c927c2b8fd5.sql)
wf_insight_runs_system_insert ON public.wf_insight_runs  (20251207182117_8d955cc7-72a8-41dd-95c9-1c927c2b8fd5.sql)
wf_insights_owner_admin_select ON public.wf_insights  (20251207185917_71acbbcf-40c2-454c-a577-3437bbd5eee6.sql)
wf_insights_worker_select ON public.wf_insights  (20251207185917_71acbbcf-40c2-454c-a577-3437bbd5eee6.sql)
wf_insights_owner_admin_update ON public.wf_insights  (20251207185917_71acbbcf-40c2-454c-a577-3437bbd5eee6.sql)
wf_insight_runs_owner_admin_select ON public.wf_insight_runs  (20251207185917_71acbbcf-40c2-454c-a577-3437bbd5eee6.sql)
wf_autopilot_runs_owner_admin_select ON public.wf_autopilot_runs  (20251207200202_e5c560cb-6dae-4274-b081-e0606106bba2.sql)
wf_autopilot_runs_system_insert ON public.wf_autopilot_runs  (20251207200202_e5c560cb-6dae-4274-b081-e0606106bba2.sql)
wf_autopilot_runs_system_update ON public.wf_autopilot_runs  (20251207200202_e5c560cb-6dae-4274-b081-e0606106bba2.sql)
wf_autopilot_actions_owner_admin_select ON public.wf_autopilot_actions  (20251207200202_e5c560cb-6dae-4274-b081-e0606106bba2.sql)
wf_autopilot_actions_worker_select ON public.wf_autopilot_actions  (20251207200202_e5c560cb-6dae-4274-b081-e0606106bba2.sql)
wf_autopilot_actions_system_insert ON public.wf_autopilot_actions  (20251207200202_e5c560cb-6dae-4274-b081-e0606106bba2.sql)
wf_autopilot_actions_owner_admin_update ON public.wf_autopilot_actions  (20251207200202_e5c560cb-6dae-4274-b081-e0606106bba2.sql)
wf_worker_tags_owner_admin_select ON public.wf_worker_tags  (20251207200202_e5c560cb-6dae-4274-b081-e0606106bba2.sql)
wf_worker_tags_worker_select ON public.wf_worker_tags  (20251207200202_e5c560cb-6dae-4274-b081-e0606106bba2.sql)
wf_worker_tags_system_write ON public.wf_worker_tags  (20251207200202_e5c560cb-6dae-4274-b081-e0606106bba2.sql)
wf_autopilot_actions_worker_update ON public.wf_autopilot_actions  (20251207202439_c1e05d15-63ca-46c3-80bd-a795515b8c68.sql)
wf_autopilot_policies_owner_admin_select ON public.wf_autopilot_policies  (20251207205104_00879095-0595-4f6a-9200-2c11e9afcf25.sql)
wf_autopilot_policies_owner_admin_update ON public.wf_autopilot_policies  (20251207205104_00879095-0595-4f6a-9200-2c11e9afcf25.sql)
wf_autopilot_policies_system_insert ON public.wf_autopilot_policies  (20251207205104_00879095-0595-4f6a-9200-2c11e9afcf25.sql)
wf_autopilot_policies_system_update ON public.wf_autopilot_policies  (20251207205104_00879095-0595-4f6a-9200-2c11e9afcf25.sql)
wf_alert_channels_owner_admin_select ON public.wf_alert_channels  (20251207205104_00879095-0595-4f6a-9200-2c11e9afcf25.sql)
wf_alert_channels_owner_admin_update ON public.wf_alert_channels  (20251207205104_00879095-0595-4f6a-9200-2c11e9afcf25.sql)
wf_alert_channels_system_insert ON public.wf_alert_channels  (20251207205104_00879095-0595-4f6a-9200-2c11e9afcf25.sql)
wf_alert_events_owner_admin_select ON public.wf_alert_events  (20251207205104_00879095-0595-4f6a-9200-2c11e9afcf25.sql)
wf_alert_events_worker_select ON public.wf_alert_events  (20251207205104_00879095-0595-4f6a-9200-2c11e9afcf25.sql)
wf_alert_events_system_insert ON public.wf_alert_events  (20251207205104_00879095-0595-4f6a-9200-2c11e9afcf25.sql)
wf_playbooks_owner_admin_select ON public.wf_playbooks  (20251207211253_6b0a6bc4-7664-429d-a852-49c975d2d18d.sql)
wf_playbooks_owner_admin_update ON public.wf_playbooks  (20251207211253_6b0a6bc4-7664-429d-a852-49c975d2d18d.sql)
wf_playbooks_owner_admin_insert ON public.wf_playbooks  (20251207211253_6b0a6bc4-7664-429d-a852-49c975d2d18d.sql)
wf_playbooks_owner_admin_delete ON public.wf_playbooks  (20251207211253_6b0a6bc4-7664-429d-a852-49c975d2d18d.sql)
wf_playbooks_system_all ON public.wf_playbooks  (20251207211253_6b0a6bc4-7664-429d-a852-49c975d2d18d.sql)
wf_playbook_steps_owner_admin_select ON public.wf_playbook_steps  (20251207211253_6b0a6bc4-7664-429d-a852-49c975d2d18d.sql)
wf_playbook_steps_owner_admin_insert ON public.wf_playbook_steps  (20251207211253_6b0a6bc4-7664-429d-a852-49c975d2d18d.sql)
wf_playbook_steps_owner_admin_update ON public.wf_playbook_steps  (20251207211253_6b0a6bc4-7664-429d-a852-49c975d2d18d.sql)
wf_playbook_steps_owner_admin_delete ON public.wf_playbook_steps  (20251207211253_6b0a6bc4-7664-429d-a852-49c975d2d18d.sql)
wf_playbook_steps_system_all ON public.wf_playbook_steps  (20251207211253_6b0a6bc4-7664-429d-a852-49c975d2d18d.sql)
wf_playbook_triggers_owner_admin_select ON public.wf_playbook_triggers  (20251207211253_6b0a6bc4-7664-429d-a852-49c975d2d18d.sql)
wf_playbook_triggers_owner_admin_insert ON public.wf_playbook_triggers  (20251207211253_6b0a6bc4-7664-429d-a852-49c975d2d18d.sql)
wf_playbook_triggers_owner_admin_update ON public.wf_playbook_triggers  (20251207211253_6b0a6bc4-7664-429d-a852-49c975d2d18d.sql)
wf_playbook_triggers_owner_admin_delete ON public.wf_playbook_triggers  (20251207211253_6b0a6bc4-7664-429d-a852-49c975d2d18d.sql)
wf_playbook_triggers_system_all ON public.wf_playbook_triggers  (20251207211253_6b0a6bc4-7664-429d-a852-49c975d2d18d.sql)
wf_playbook_runs_owner_admin_select ON public.wf_playbook_runs  (20251207211253_6b0a6bc4-7664-429d-a852-49c975d2d18d.sql)
wf_playbook_runs_worker_select ON public.wf_playbook_runs  (20251207211253_6b0a6bc4-7664-429d-a852-49c975d2d18d.sql)
wf_playbook_runs_system_all ON public.wf_playbook_runs  (20251207211253_6b0a6bc4-7664-429d-a852-49c975d2d18d.sql)
wolf_session_settings_owner_only ON public.wolf_session_settings  (20251208030206_257dab04-6f2c-482f-bd90-ece929d45935.sql)
screenshot_attempts_admin_read ON public.wolf_screenshot_attempts  (20251208030206_257dab04-6f2c-482f-bd90-ece929d45935.sql)
screenshot_attempts_insert_any ON public.wolf_screenshot_attempts  (20251208030206_257dab04-6f2c-482f-bd90-ece929d45935.sql)
vault_owner_legal_only ON public.client_vault  (20251208030206_257dab04-6f2c-482f-bd90-ece929d45935.sql)
merchants_tenant_isolation ON public.merchants  (20251209022437_77bdc8b8-ad7f-4ed2-95f9-4c6caf513275.sql)
deal_commissions_tenant_isolation ON public.deal_commissions  (20251209022437_77bdc8b8-ad7f-4ed2-95f9-4c6caf513275.sql)
deal_funder_assignments_access ON public.deal_funder_assignments  (20251209022437_77bdc8b8-ad7f-4ed2-95f9-4c6caf513275.sql)
terminals_tenant_isolation ON public.terminals  (20251209022437_77bdc8b8-ad7f-4ed2-95f9-4c6caf513275.sql)
legal_cases_access ON public.legal_cases  (20251209022437_77bdc8b8-ad7f-4ed2-95f9-4c6caf513275.sql)
lead_pipeline_tenant_select ON public.lead_pipeline  (20251210123000_phase2_rls_feature_flags.sql)
lead_pipeline_tenant_insert ON public.lead_pipeline  (20251210123000_phase2_rls_feature_flags.sql)
lead_pipeline_tenant_update ON public.lead_pipeline  (20251210123000_phase2_rls_feature_flags.sql)
lead_pipeline_tenant_delete ON public.lead_pipeline  (20251210123000_phase2_rls_feature_flags.sql)
lead_lane_events_tenant_select ON public.lead_lane_events  (20251210123000_phase2_rls_feature_flags.sql)
lead_lane_events_tenant_insert ON public.lead_lane_events  (20251210123000_phase2_rls_feature_flags.sql)
lead_lane_events_tenant_update ON public.lead_lane_events  (20251210123000_phase2_rls_feature_flags.sql)
lead_lane_events_tenant_delete ON public.lead_lane_events  (20251210123000_phase2_rls_feature_flags.sql)
lead_lane_assignments_tenant_select ON public.lead_lane_assignments  (20251210123000_phase2_rls_feature_flags.sql)
lead_lane_assignments_tenant_insert ON public.lead_lane_assignments  (20251210123000_phase2_rls_feature_flags.sql)
lead_lane_assignments_tenant_update ON public.lead_lane_assignments  (20251210123000_phase2_rls_feature_flags.sql)
lead_lane_assignments_tenant_delete ON public.lead_lane_assignments  (20251210123000_phase2_rls_feature_flags.sql)
lead_action_queue_tenant_select ON public.lead_action_queue  (20251210123000_phase2_rls_feature_flags.sql)
lead_action_queue_tenant_insert ON public.lead_action_queue  (20251210123000_phase2_rls_feature_flags.sql)
lead_action_queue_tenant_update ON public.lead_action_queue  (20251210123000_phase2_rls_feature_flags.sql)
lead_action_queue_tenant_delete ON public.lead_action_queue  (20251210123000_phase2_rls_feature_flags.sql)
credit_cases_v2_tenant_select ON public.credit_dispute_cases_v2  (20251210123000_phase2_rls_feature_flags.sql)
credit_cases_v2_tenant_insert ON public.credit_dispute_cases_v2  (20251210123000_phase2_rls_feature_flags.sql)
credit_cases_v2_tenant_update ON public.credit_dispute_cases_v2  (20251210123000_phase2_rls_feature_flags.sql)
credit_cases_v2_tenant_delete ON public.credit_dispute_cases_v2  (20251210123000_phase2_rls_feature_flags.sql)
credit_violation_templates_tenant_select ON public.credit_violation_templates  (20251210123000_phase2_rls_feature_flags.sql)
credit_violation_templates_tenant_insert ON public.credit_violation_templates  (20251210123000_phase2_rls_feature_flags.sql)
credit_violation_templates_tenant_update ON public.credit_violation_templates  (20251210123000_phase2_rls_feature_flags.sql)
credit_violation_templates_tenant_delete ON public.credit_violation_templates  (20251210123000_phase2_rls_feature_flags.sql)
credit_documents_vault_tenant_select ON public.credit_documents_vault  (20251210123000_phase2_rls_feature_flags.sql)
credit_documents_vault_tenant_insert ON public.credit_documents_vault  (20251210123000_phase2_rls_feature_flags.sql)
credit_documents_vault_tenant_update ON public.credit_documents_vault  (20251210123000_phase2_rls_feature_flags.sql)
credit_documents_vault_tenant_delete ON public.credit_documents_vault  (20251210123000_phase2_rls_feature_flags.sql)
credit_attorney_reviews_tenant_select ON public.credit_attorney_reviews  (20251210123000_phase2_rls_feature_flags.sql)
credit_attorney_reviews_tenant_insert ON public.credit_attorney_reviews  (20251210123000_phase2_rls_feature_flags.sql)
credit_attorney_reviews_tenant_update ON public.credit_attorney_reviews  (20251210123000_phase2_rls_feature_flags.sql)
funder_pipeline_tenant_select ON public.funder_pipeline  (20251210123000_phase2_rls_feature_flags.sql)
funder_pipeline_tenant_write ON public.funder_pipeline  (20251210123000_phase2_rls_feature_flags.sql)
bank_verification_sessions_tenant_select ON public.bank_verification_sessions  (20251210123000_phase2_rls_feature_flags.sql)
bank_verification_sessions_tenant_write ON public.bank_verification_sessions  (20251210123000_phase2_rls_feature_flags.sql)
syndication_partners_tenant_select ON public.syndication_partners  (20251210123000_phase2_rls_feature_flags.sql)
syndication_partners_tenant_write ON public.syndication_partners  (20251210123000_phase2_rls_feature_flags.sql)
deal_protection_logs_tenant_select ON public.deal_protection_logs  (20251210123000_phase2_rls_feature_flags.sql)
deal_protection_logs_tenant_insert ON public.deal_protection_logs  (20251210123000_phase2_rls_feature_flags.sql)
god_mode_alerts_tenant_select ON public.god_mode_alerts  (20251210123000_phase2_rls_feature_flags.sql)
god_mode_alerts_tenant_write ON public.god_mode_alerts  (20251210123000_phase2_rls_feature_flags.sql)
system_anomalies_superowner_select ON public.system_anomalies  (20251210123000_phase2_rls_feature_flags.sql)
system_anomalies_superowner_write ON public.system_anomalies  (20251210123000_phase2_rls_feature_flags.sql)
autopilot_actions_tenant_select ON public.autopilot_actions  (20251210123000_phase2_rls_feature_flags.sql)
autopilot_actions_tenant_write ON public.autopilot_actions  (20251210123000_phase2_rls_feature_flags.sql)
merchant_profiles_tenant_select ON public.merchant_profiles  (20251210123000_phase2_rls_feature_flags.sql)
merchant_profiles_tenant_write ON public.merchant_profiles  (20251210123000_phase2_rls_feature_flags.sql)
processing_vendor_rates_superowner_select ON public.processing_vendor_rates  (20251210123000_phase2_rls_feature_flags.sql)
processing_vendor_rates_superowner_write ON public.processing_vendor_rates  (20251210123000_phase2_rls_feature_flags.sql)
```

## RLS enabled tables (ALL, from migrations)
```
abg_project_funding_links
admin_sensitive_data_access
ai_events
call_sessions
client_activity
collection_cases
collection_events
commissions
compliance_deal_checks
compliance_disclosure_templates
compliance_states
credit_public_checks
credit_public_snapshot
credit_repair_dispute_drafts
credit_standards_reference
deals
email_messages
email_templates
fund_deal_allocations
funded_deals
funds
industry_rules
intake_clients
investor_positions
investors
iso_commissions
iso_partners
iso_statistics
iso_training_completions
iso_training_modules
kyc_results
lead_call_attempts
lead_call_logs
lead_files
lead_import_batches
lead_list_members
lead_lists
lead_lock_requests
lead_locks
lead_ownership_requests
lead_ownerships
lead_release_requests
lead_research_logs
lead_share_requests
lead_sources
lead_strategy_files
lead_tasks
leads
mca_products
outreach_enrollments
outreach_events
outreach_sequences
outreach_steps
product_pricing_rules
public.abg_projects
public.activity_events
public.activity_feed
public.activity_log
public.admin_application_views
public.ai_reports
public.application_comments
public.application_transactions
public.audit_logs
public.autopilot_actions
public.bank_verification_sessions
public.billing_plans
public.billing_subscriptions
public.calls
public.chat_messages
public.client_communications
public.client_notes
public.client_vault
public.communication_logs
public.contract_templates
public.conversation_participants
public.conversations
public.credit_attorney_reviews
public.credit_case_v2_activity
public.credit_cases_v2
public.credit_dispute_cases_v2
public.credit_dispute_drafts_v2
public.credit_dispute_items_v2
public.credit_disputes
public.credit_documents_vault
public.credit_fix_required_docs
public.credit_fix_task_templates
public.credit_repair_applications
public.credit_violation_templates
public.deal_commissions
public.deal_documents
public.deal_events
public.deal_funder_assignments
public.deal_offers
public.deal_protection_logs
public.deal_rooms
public.document_extractions
public.document_templates
public.fast_track_applications
public.funded_contracts
public.funded_deals
public.funder_applications
public.funder_communication_log
public.funder_pipeline
public.funder_submissions
public.funders
public.funding_calls
public.god_mode_alerts
public.intake_logs
public.iso_commissions
public.iso_partner_applications
public.lead_action_queue
public.lead_assignments
public.lead_conflict_requests
public.lead_events
public.lead_import_errors
public.lead_lane_assignments
public.lead_lane_events
public.lead_list_members
public.lead_notes
public.lead_pipeline
public.lead_scoring_rules
public.legal_cases
public.legal_client_applications
public.legal_risk_feedback
public.loan_applications
public.merchant_profiles
public.merchants
public.message_templates
public.messages_sent
public.outbound_emails
public.outreach_campaigns
public.outreach_events
public.outreach_inboxes
public.outreach_sequences
public.outreach_tasks
public.partner_applications
public.partner_invite_codes
public.portal_profiles
public.processing_vendor_rates
public.profiles
public.renewal_opportunities
public.risk_alerts
public.signature_requests
public.syndication_partners
public.system_anomalies
public.system_optimization_suggestions
public.templates_master_library
public.terminals
public.underwriting_feedback
public.underwriting_files
public.user_presence
public.user_roles
public.user_settings
public.wf_ai_cost_summary
public.wf_ai_usage_events
public.wf_alert_channels
public.wf_alert_events
public.wf_autopilot_actions
public.wf_autopilot_policies
public.wf_autopilot_runs
public.wf_billing_plans
public.wf_chat_session_overrides
public.wf_client_portal_tokens
public.wf_contract_templates
public.wf_credit_status
public.wf_dev_suggestion_events
public.wf_email_outbox
public.wf_email_templates
public.wf_events
public.wf_generated_contracts
public.wf_insight_runs
public.wf_insights
public.wf_ip_actions
public.wf_ip_assets
public.wf_ip_events
public.wf_ip_filing_packets
public.wf_ip_legal_drafts
public.wf_ip_versions
public.wf_leads
public.wf_playbook_drift_items
public.wf_playbook_runs
public.wf_playbook_steps
public.wf_playbook_triggers
public.wf_playbooks
public.wf_suggestions
public.wf_tasks
public.wf_tenant_billing_state
public.wf_tenant_users
public.wf_tenants
public.wf_usage_events
public.wf_worker_tags
public.wolf_ai_limits
public.wolf_credit_cases
public.wolf_devices
public.wolf_documents
public.wolf_events
public.wolf_feature_flags
public.wolf_flow_rules
public.wolf_health_log
public.wolf_identity_verifications
public.wolf_input_snapshots
public.wolf_legal_scans
public.wolf_master_config
public.wolf_master_config_history
public.wolf_provider_health
public.wolf_screenshot_attempts
public.wolf_security_correlations
public.wolf_security_events
public.wolf_session_analytics
public.wolf_session_settings
public.wolf_sessions
public.wolf_tenant_feature_flags
public.wolf_tenant_users
public.wolf_tenants
public.wolf_underwriting_cases
public.worker_activity_logs
public.worker_applications
public.worker_assignments
public.workflow_tasks
renewal_offers
renewal_rules
risk_tiers
settlements
sms_messages
spvs
system_settings
underwriting_cases
underwriting_metrics
underwriting_notes
underwriting_tasks
uw_rule_sets
uw_rules
wf_governance_actions
wf_governance_alerts
wf_governance_reports
wf_ip_evidence_bundles
wf_manual_tasks
wolf_suggestions
worker_assignments
worker_commission_splits
```