# EP-0002 — Acceptance tests

## Must-pass checks
- **No missing-table runtime errors/toasts** on core pages, including no `PGRST205` for:
  - `public.loan_applications`
  - `public.iso_partner_applications`
  - Lead Engine tables (list explicitly once proven)

- **Lead Engine** pages load and can read/write successfully (no schema cache errors).

- **Credit Fix** pages:
  - pass auth
  - correct permissions (no unintended “Access Denied” for intended roles)

- **Env alignment proof**
  - `/super/env-debug` shows the intended Supabase project in:
    - production (`wolf-fund.com`)
    - preview (Cloudflare Pages preview)

- **Routing invariant**
  - Mode switch behavior remains correct (EP-0001 remains intact).

## STOP RULE
Do not run migrations, create tables, or change Supabase until EP-0002 is explicitly approved with:
> “Approved – start EP-0002 implementation.”

