# EP-0002 — Implementation plan (max 6 steps)

> STOP RULE: Do not run migrations, create tables, or change Supabase until explicitly approved with:  
> **“Approved – start EP-0002 implementation.”**

## Step 1 — Freeze changes + rotate leaked keys
- Freeze schema changes while gaps are inventoried.
- Rotate any credentials that were exposed in logs/screenshots if applicable.

## Step 2 — Fix Cloudflare env vars (prod + preview) OR confirm correct project
- Confirm production/preview Supabase project refs using `/super/env-debug`.
- If mismatch, update Cloudflare Pages env vars (both Production + Preview):
  - `VITE_SUPABASE_URL`
  - `VITE_SUPABASE_ANON_KEY`

## Step 3 — Migrate schema (tables/types/extensions)
- Restore missing tables with reproducible SQL/migrations in repo.
- No renames. No invented schema.

## Step 4 — Migrate RLS/policies/roles
- Export/import policies and grants.
- Confirm “Access Denied” issues resolve with intended role access.

## Step 5 — Migrate functions/triggers/edge functions/storage
- Triggers + DB functions parity
- Edge functions deployed + required secrets set
- Storage buckets + policies recreated

## Step 6 — Validation checklist + rollback plan
- Validate against acceptance tests (below).
- Document rollback (restore old env vars / redeploy) and time-to-recover target.

