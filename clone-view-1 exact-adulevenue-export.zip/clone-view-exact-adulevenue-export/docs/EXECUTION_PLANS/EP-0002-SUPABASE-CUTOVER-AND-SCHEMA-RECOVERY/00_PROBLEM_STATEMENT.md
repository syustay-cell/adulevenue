# EP-0002 — Supabase cutover + schema recovery (planning only)

## Symptoms (observed)
- **Missing table errors** in production (PostgREST `PGRST205`), including:
  - `public.loan_applications`
  - `public.iso_partner_applications`
- UI can load, but backend reads/writes fail where these tables are used.
- Reports of **“Access Denied”** on Credit Fix pages (RLS/roles/policies likely involved).
- Risk: “legacy artifacts resurfacing” if environment alignment and schema parity are not locked down.

## Impact
- Production workflows that depend on these tables fail at runtime.
- Operators/users see broken actions or empty dashboards.

## Goal (what “done” means)
Restore full backend parity for the Supabase project production is using:
- Tables (and required types/extensions)
- RLS policies / roles / grants
- Triggers / functions
- Edge functions + required secrets
- Storage buckets + bucket policies

And prevent recurrence by:
- Proving production/preview env alignment before any schema work
- Making changes reproducible via repo migrations/scripts (no hidden one-off UI changes)

## STOP RULE
Do **not** run migrations, create tables, or change Supabase configuration until EP-0002 is explicitly approved with:
> “Approved – start EP-0002 implementation.”

