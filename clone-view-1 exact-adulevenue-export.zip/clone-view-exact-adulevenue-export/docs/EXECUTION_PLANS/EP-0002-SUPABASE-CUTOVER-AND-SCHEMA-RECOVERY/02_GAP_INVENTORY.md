# EP-0002 — Gap inventory (proven only; no guessing)

## Missing tables (proven from production runtime)
The following tables are missing in the Supabase schema cache for production project ref `ochuyydjomkpxbzrnptq` (PostgREST `PGRST205`):

- `public.loan_applications`
- `public.iso_partner_applications`

### Proof (copy/paste response examples)
- `Could not find the table 'public.loan_applications' in the schema cache`
- `Could not find the table 'public.iso_partner_applications' in the schema cache`

## “Exists in OLD vs exists in NEW” (requires Supabase UI proof)
Because the “old ref” provided is the same as the proven production ref (`ochuyydjomkpxbzrnptq`), the immediate question is:
- Do these tables exist **in the project** but are not exposed (e.g. not in `public`, permissions/RLS issues)?
- Or are they truly absent?

**Required proof to complete this section (screenshots):**
- Supabase Dashboard → Table Editor → list of tables for project `ochuyydjomkpxbzrnptq`

Fill this table only with screenshot-backed evidence:

| Object | Exists (Table Editor)? | Schema | Notes |
|---|---:|---|---|
| `loan_applications` | ☐ YES / ☐ NO | `public` |  |
| `iso_partner_applications` | ☐ YES / ☐ NO | `public` |  |

## Missing edge functions / triggers / RLS / storage buckets (placeholders until proven)
These must be filled using “list from OLD” vs “list from NEW” evidence, not guesses.

### Edge Functions
| Function name | Exists in project? | Deployed? | Notes |
|---|---:|---:|---|
| (TBD) |  |  |  |

### Triggers / DB Functions
| Name | Type | Exists? | Notes |
|---|---|---:|---|
| (TBD) | trigger/function |  |  |

### RLS Policies
| Table | Policy | Exists? | Notes |
|---|---|---:|---|
| (TBD) | (TBD) |  |  |

### Storage buckets
| Bucket | Exists? | Public? | Notes |
|---|---:|---:|---|
| (TBD) |  |  |  |

