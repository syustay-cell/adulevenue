# EP-0002 — Phase 0 proof (env alignment)

## Requirement
Before any schema work, prove which Supabase project production (and preview) is using.

## Known “old ref” (from user-provided screenshot)
- **Known ref**: `ochuyydjomkpxbzrnptq`

## Production proof — wolf-fund.com
### /super/env-debug (target)
- **Status**: NOT currently deployed on production.
- Evidence: `GET https://wolf-fund.com/super/env-debug` returns **HTTP 404**.

### Verified production Supabase project ref (proven from shipped JS bundle)
Because `/super/env-debug` is not deployed yet, this proof is based on extracting the Supabase hostname from the production JS bundle served by `wolf-fund.com`.

**Steps (copy/paste)**
1) Download `index.html`, locate entry script:
- `/assets/index-BsxcuqzL.js`

2) From entry script, locate App chunk:
- `/assets/App-MQ8VLJ5m.js`

3) Extract Supabase URL(s) from App chunk:
- Extracted URL: `https://ochuyydjomkpxbzrnptq.supabase.co`
- Extracted **project ref**: `ochuyydjomkpxbzrnptq`

**Conclusion (production)**
Production points to REF: **`ochuyydjomkpxbzrnptq`** (proven via shipped bundle extraction).

## Preview proof (if applicable)
Not yet proven in this repo because `/super/env-debug` is not deployed in preview either.

## Anon key fingerprint (prod)
When `/super/env-debug` is deployed, record:
- `anonKeyLength`
- `anonKeySuffix` (last 6)

Until then, Phase 0 should be completed by deploying `/super/env-debug` and copy/pasting the values from:
- (a) production `wolf-fund.com/super/env-debug`
- (b) Cloudflare preview `/super/env-debug`

