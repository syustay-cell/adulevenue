# EP-0002 — EXECUTION RUNBOOK (Option B: rebuild CURRENT prod Supabase to match legacy source-of-record)

## STOP RULE (enforced)
- Do **not** run any commands under **“APPLY”** sections until this runbook is explicitly approved.
- Do **not** paste keys in chat.

## Decommissioned Systems (read this first)
The legacy Supabase project (`tdzuhcswrojlleeupqvd`) is **decommissioned** and must be treated as a **read-only historical source-of-record only**.
There will be:
- no routing
- no redirects
- no auth
- no environment variables
- no dependencies
- no production traffic
ever pointing to the legacy project again.

This operation is a **one-time controlled extraction + re-deployment** into the current production Supabase project `ochuyydjomkpxbzrnptq`.
After execution, the legacy project is **irrelevant** and can be **forgotten**.

## 0) Project refs (proven sources)
- **CURRENT production Supabase (target to rebuild)**: `ochuyydjomkpxbzrnptq`  
  Source: `supabase/config.toml` (`project_id`) and production bundle extraction.
- **Legacy Supabase (decommissioned; historical source-of-record only)**: `tdzuhcswrojlleeupqvd`  
  Source: `PLATFORM_ARCHITECTURE.md` env block (historical).

## 1) Access confirmation (YES/NO gate)
### 1.1 Confirm Supabase CLI access (no secrets shown)

```bash
# Must be set in your shell (do NOT paste the value anywhere)
export SUPABASE_ACCESS_TOKEN="(set locally)"

npx --yes supabase projects list
```

Expected:
- Output includes access to the **target** ref:
  - `ochuyydjomkpxbzrnptq`

Optional (for historical verification only):
- Access to the legacy ref may exist, but it must remain read-only and never be used for production traffic:
  - `tdzuhcswrojlleeupqvd`

If either is missing: STOP (no deploy).

## 2) Deterministic DB deploy plan (repo migrations → CURRENT prod project)

### 2.1 Preflight backup (required)
Choose one:

**A) Supabase Dashboard backup**
- Create/download a backup snapshot for `ochuyydjomkpxbzrnptq` immediately before applying migrations.

**B) CLI dump (requires DB URL; do not paste it)**

```bash
export SUPABASE_DB_URL="(set locally; do NOT paste)"

pg_dump "$SUPABASE_DB_URL" \
  --format=custom \
  --file "backup_ochuyydjomkpxbzrnptq_$(date -u +%Y%m%dT%H%M%SZ).dump"
```

### 2.2 Link repo to the prod project (no secrets printed)

```bash
export SUPABASE_DB_PASSWORD="(set locally; do NOT paste)"

npx --yes supabase link \
  --project-ref "ochuyydjomkpxbzrnptq" \
  --password "$SUPABASE_DB_PASSWORD"
```

### 2.3 DRY RUN: list migrations that would apply

```bash
npx --yes supabase db push \
  --dry-run \
  --include-all \
  --include-roles \
  --include-seed
```

### 2.4 APPLY: push ALL missing migrations (schema, RLS, RPCs, triggers)

```bash
npx --yes supabase db push \
  --include-all \
  --include-roles \
  --include-seed
```

## 3) Deterministic Edge Functions deploy plan (repo functions → CURRENT prod project)

### 3.1 Required function env vars (names only)
These env var names are referenced via `Deno.env.get(...)` across `supabase/functions/*`:

```text
AI_GATEWAY_API_KEY
AI_GATEWAY_CHAT_COMPLETIONS_URL
AI_GATEWAY_MODELS_URL
AZURE_TTS_KEY
AZURE_TTS_REGION
CLIENT_PORTAL_BASE_URL
DATABASE_URL
DOCUSIGN_ACCOUNT_ID
DOCUSIGN_INTEGRATION_KEY
DOCUSIGN_SECRET_KEY
EMAIL_FROM_ADDRESS
GOOGLE_TTS_KEY
OPENAI_API_KEY
RESEND_API_KEY
SUPABASE_ANON_KEY
SUPABASE_DB_URL
SUPABASE_SERVICE_ROLE_KEY
SUPABASE_URL
TWILIO_ACCOUNT_SID
TWILIO_AUTH_TOKEN
TWILIO_PHONE_NUMBER
WOLF_AI_MOCK_MODE
WOLF_CREDIT_V2_DEMO_MODE
WOLF_TENANT_BOOTSTRAP_SECRET
```

### 3.2 DRY RUN: list currently deployed functions in prod project

```bash
npx --yes supabase functions list --project-ref "ochuyydjomkpxbzrnptq"
```

### 3.3 APPLY: deploy ALL functions from repo
This deploys every local function folder under `supabase/functions/*` (excluding `_shared`), and applies `verify_jwt` settings from `supabase/config.toml`:

```bash
export SUPABASE_PROJECT_REF="ochuyydjomkpxbzrnptq"

mapfile -t NO_VERIFY < <(
  awk '
    /^\[functions\./ {gsub(/^\[functions\.|\]$/,""); fn=$0}
    /verify_jwt *= *false/ {print fn}
  ' supabase/config.toml | sort -u
)

for fn in $(ls -1 supabase/functions | rg -v '^_' | sort); do
  if printf '%s\n' "${NO_VERIFY[@]}" | rg -qx "$fn"; then
    npx --yes supabase functions deploy "$fn" --project-ref "$SUPABASE_PROJECT_REF" --no-verify-jwt
  else
    npx --yes supabase functions deploy "$fn" --project-ref "$SUPABASE_PROJECT_REF"
  fi
done
```

## 4) Rollback plan (under 5 minutes goal)

### 4.1 DB rollback
There is no safe, universal “down migration” for this repo-wide push. Rollback is:
- **Restore the pre-change backup** (Dashboard restore or `pg_restore` from the dump).

If you used `pg_dump` (custom format):

```bash
export SUPABASE_DB_URL="(set locally; do NOT paste)"

# WARNING: This overwrites the database. Use only with explicit approval.
pg_restore --clean --if-exists --no-owner --no-privileges \
  --dbname "$SUPABASE_DB_URL" \
  "backup_ochuyydjomkpxbzrnptq_<timestamp>.dump"
```

### 4.2 Edge Functions rollback
Option A (preferred): redeploy functions from the previous git SHA (checkout previous SHA, run deploy loop again).

Option B: disable newly deployed functions:

```bash
export SUPABASE_PROJECT_REF="ochuyydjomkpxbzrnptq"

# Example:
# npx --yes supabase functions delete "function-name" --project-ref "$SUPABASE_PROJECT_REF"
```

## 5) Acceptance tests (post-deploy)

### 5.1 Backend “missing table” checks (no PGRST205)
- Login → Admin Dashboard loads without “Could not find table …”
- Lead Engine page loads and lists data
- Credit Fix routes behave correctly (no unintended “Access Denied”)

CLI probe (optional but deterministic):

```bash
export SUPABASE_PROJECT_REF="ochuyydjomkpxbzrnptq"
export SUPABASE_ANON_KEY="(set locally; do NOT paste)"

bash scripts/ep-0002/probe-postgrest-tables.sh
```

### 5.2 Environment alignment checks
- `/super/env-debug` (prod + preview) shows projectRef `ochuyydjomkpxbzrnptq`

### 5.3 UI regression check
- Confirm the **legacy yellow widget** does **not** appear.
- Confirm Mode switching behavior remains correct (EP-0001 intact).

