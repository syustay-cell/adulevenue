# 🐺 WOLF ECOSYSTEM V1 — DATABASE SCHEMA

> Complete Supabase database specification for developers

---

## TABLE OF CONTENTS

1. [Core Tables](#1-core-tables)
2. [Lead Management](#2-lead-management)
3. [Application & Underwriting](#3-application--underwriting)
4. [Credit Repair](#4-credit-repair)
5. [User & Role Management](#5-user--role-management)
6. [ISO & Commissions](#6-iso--commissions)
7. [Documents & Storage](#7-documents--storage)
8. [Communications](#8-communications)
9. [Analytics & Audit](#9-analytics--audit)
10. [Enums & Types](#10-enums--types)
11. [RLS Policies](#11-rls-policies)
12. [Database Functions](#12-database-functions)
13. [Triggers](#13-triggers)

---

## 1. CORE TABLES

### 1.1 users_profile

Extended profile data for authenticated users.

```sql
CREATE TABLE public.users_profile (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name TEXT,
  phone TEXT,
  avatar_url TEXT,
  timezone TEXT DEFAULT 'America/New_York',
  is_active BOOLEAN DEFAULT true,
  is_lead_gen_worker BOOLEAN DEFAULT false,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now(),
  
  UNIQUE(user_id)
);

-- Indexes
CREATE INDEX idx_users_profile_user_id ON public.users_profile(user_id);
```

### 1.2 user_roles

Role assignments (separate from profile for security).

```sql
CREATE TYPE public.app_role AS ENUM (
  'admin',
  'worker',
  'researcher',
  'underwriter',
  'credit_repair_specialist',
  'iso_partner',
  'funding_manager',
  'user'
);

CREATE TABLE public.user_roles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  role app_role NOT NULL,
  approved BOOLEAN DEFAULT false,
  approved_by UUID REFERENCES auth.users(id),
  approved_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT now(),
  
  UNIQUE(user_id, role)
);

-- Indexes
CREATE INDEX idx_user_roles_user_id ON public.user_roles(user_id);
CREATE INDEX idx_user_roles_role ON public.user_roles(role);
```

---

## 2. LEAD MANAGEMENT

### 2.1 lead_sources

Track origin of leads.

```sql
CREATE TABLE public.lead_sources (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  source_type TEXT NOT NULL, -- 'iso', 'upload', 'api', 'organic', 'ocm'
  iso_partner_id UUID REFERENCES public.iso_partner_applications(id),
  default_commission_rate DECIMAL(5,2),
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT now()
);
```

### 2.2 lead_lists

Imported lead file batches.

```sql
CREATE TABLE public.lead_lists (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  file_path TEXT NOT NULL,
  source TEXT,
  source_type TEXT, -- 'ocm', 'iso', 'purchased', 'organic'
  status TEXT DEFAULT 'pending', -- 'pending', 'processing', 'completed', 'failed'
  
  -- Processing stats
  total_rows INTEGER,
  processed_rows INTEGER DEFAULT 0,
  dialer_count INTEGER DEFAULT 0,
  email_count INTEGER DEFAULT 0,
  research_count INTEGER DEFAULT 0,
  rejected_count INTEGER DEFAULT 0,
  
  -- Quality metrics
  import_quality_score INTEGER, -- 0-100
  field_coverage DECIMAL(5,2), -- percentage
  header_confidence DECIMAL(5,2),
  
  -- Mappings
  raw_headers JSONB,
  header_mapping JSONB,
  processing_summary JSONB,
  error_message TEXT,
  
  created_by UUID REFERENCES auth.users(id),
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Indexes
CREATE INDEX idx_lead_lists_status ON public.lead_lists(status);
CREATE INDEX idx_lead_lists_source_type ON public.lead_lists(source_type);
```

### 2.3 leads

Master lead table.

```sql
CREATE TYPE public.lead_route AS ENUM ('dialer', 'email', 'research', 'rejected');
CREATE TYPE public.lead_status AS ENUM (
  'new', 'enriched', 'research_pending', 'research_completed',
  'dialer_queue', 'contacted', 'interested', 'callback',
  'intake_sent', 'intake_completed', 'underwriting',
  'docs_requested', 'docs_uploaded', 'funded',
  'credit_repair', 'dead', 'do_not_contact'
);
CREATE TYPE public.ai_priority AS ENUM ('A', 'B', 'C', 'D');
CREATE TYPE public.ai_recommended_path AS ENUM (
  'funding_first', 'credit_first', 'hybrid', 'do_not_work'
);
CREATE TYPE public.dialer_status AS ENUM (
  'new', 'in_progress', 'callback', 'not_interested', 'converted', 'dead'
);

CREATE TABLE public.leads (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  
  -- Source tracking
  list_id UUID REFERENCES public.lead_lists(id),
  source_id UUID REFERENCES public.lead_sources(id),
  iso_partner_id UUID REFERENCES public.iso_partner_applications(id),
  
  -- Contact info
  full_name TEXT,
  business_name TEXT,
  email TEXT,
  phone TEXT,
  website TEXT,
  address TEXT,
  city TEXT,
  state TEXT,
  postal_code TEXT,
  
  -- Validation flags
  has_phone BOOLEAN DEFAULT false,
  has_email BOOLEAN DEFAULT false,
  has_name BOOLEAN DEFAULT false,
  phone_valid BOOLEAN,
  email_valid BOOLEAN,
  
  -- Routing
  route lead_route DEFAULT 'research',
  status lead_status DEFAULT 'new',
  dialer_status dialer_status DEFAULT 'new',
  
  -- AI scoring
  ai_score INTEGER, -- 0-100
  ai_priority ai_priority,
  ai_recommended_path ai_recommended_path,
  ai_risk_flags TEXT[],
  ai_notes JSONB DEFAULT '{}',
  
  -- Enrichment data
  enrichment_status TEXT DEFAULT 'pending', -- 'pending', 'enriched', 'failed'
  enriched_at TIMESTAMPTZ,
  enriched_data JSONB DEFAULT '{}',
  
  -- Business intelligence
  estimated_revenue DECIMAL(15,2),
  business_age_years DECIMAL(4,1),
  industry TEXT,
  sic_code TEXT,
  naics_code TEXT,
  employee_count TEXT,
  
  -- Risk assessment
  funding_score INTEGER, -- 0-100
  credit_risk TEXT, -- 'low', 'medium', 'high'
  identity_theft_risk TEXT,
  industry_risk TEXT,
  
  -- OCM-specific fields
  license_id TEXT,
  license_type TEXT,
  license_status TEXT,
  license_expiration DATE,
  municipality TEXT,
  zoning_risk TEXT,
  property_owner TEXT,
  
  -- Ownership & locking
  current_owner_id UUID REFERENCES auth.users(id),
  current_owner_email TEXT,
  lock_expires_at TIMESTAMPTZ,
  lock_reason TEXT,
  
  -- Research tracking
  research_status TEXT DEFAULT 'pending',
  research_assigned_to UUID REFERENCES auth.users(id),
  research_started_at TIMESTAMPTZ,
  research_completed_at TIMESTAMPTZ,
  research_attempts INTEGER DEFAULT 0,
  
  -- Call tracking
  call_attempts INTEGER DEFAULT 0,
  last_called_at TIMESTAMPTZ,
  last_called_by UUID REFERENCES auth.users(id),
  last_call_outcome TEXT,
  next_callback_at TIMESTAMPTZ,
  
  -- Raw data storage
  raw_data JSONB DEFAULT '{}',
  
  -- Timestamps
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- Indexes
CREATE INDEX idx_leads_list_id ON public.leads(list_id);
CREATE INDEX idx_leads_route ON public.leads(route);
CREATE INDEX idx_leads_status ON public.leads(status);
CREATE INDEX idx_leads_dialer_status ON public.leads(dialer_status);
CREATE INDEX idx_leads_owner ON public.leads(current_owner_id);
CREATE INDEX idx_leads_email ON public.leads(email);
CREATE INDEX idx_leads_phone ON public.leads(phone);
CREATE INDEX idx_leads_ai_score ON public.leads(ai_score DESC);
CREATE INDEX idx_leads_funding_score ON public.leads(funding_score DESC);
CREATE INDEX idx_leads_license_id ON public.leads(license_id);
```

### 2.4 lead_call_attempts

Call history per lead.

```sql
CREATE TABLE public.lead_call_attempts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id UUID NOT NULL REFERENCES public.leads(id) ON DELETE CASCADE,
  agent_id UUID NOT NULL REFERENCES auth.users(id),
  agent_email TEXT NOT NULL,
  outcome TEXT NOT NULL, -- 'answered', 'no_answer', 'voicemail', 'busy', 'wrong_number', 'not_interested'
  duration_seconds INTEGER,
  notes TEXT,
  next_action TEXT,
  callback_scheduled_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Indexes
CREATE INDEX idx_lead_call_attempts_lead ON public.lead_call_attempts(lead_id);
CREATE INDEX idx_lead_call_attempts_agent ON public.lead_call_attempts(agent_id);
```

### 2.5 lead_ownerships

Track lead ownership transfers.

```sql
CREATE TABLE public.lead_ownerships (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id UUID NOT NULL REFERENCES public.leads(id) ON DELETE CASCADE,
  
  primary_owner_id UUID REFERENCES auth.users(id),
  primary_owner_email TEXT,
  secondary_owner_id UUID REFERENCES auth.users(id),
  secondary_owner_email TEXT,
  
  share_primary DECIMAL(5,2) DEFAULT 100,
  share_secondary DECIMAL(5,2) DEFAULT 0,
  
  lock_expires_at TIMESTAMPTZ,
  lock_reason TEXT,
  is_active BOOLEAN DEFAULT true,
  
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- Indexes
CREATE INDEX idx_lead_ownerships_lead ON public.lead_ownerships(lead_id);
CREATE INDEX idx_lead_ownerships_primary ON public.lead_ownerships(primary_owner_id);
```

### 2.6 lead_release_requests

Ownership transfer requests.

```sql
CREATE TABLE public.lead_release_requests (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id UUID NOT NULL REFERENCES public.leads(id) ON DELETE CASCADE,
  
  from_worker_id UUID NOT NULL REFERENCES auth.users(id),
  from_worker_email TEXT NOT NULL,
  to_worker_id UUID NOT NULL REFERENCES auth.users(id),
  to_worker_email TEXT NOT NULL,
  
  request_type TEXT NOT NULL, -- 'release', 'split_50_50'
  message TEXT,
  status TEXT DEFAULT 'pending', -- 'pending', 'approved', 'rejected'
  
  resolved_at TIMESTAMPTZ,
  resolved_by UUID REFERENCES auth.users(id),
  resolved_by_email TEXT,
  
  created_at TIMESTAMPTZ DEFAULT now()
);
```

---

## 3. APPLICATION & UNDERWRITING

### 3.1 fast_track_applications

Fast track funding applications.

```sql
CREATE TABLE public.fast_track_applications (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id),
  lead_id UUID REFERENCES public.leads(id),
  iso_partner_id UUID REFERENCES public.iso_partner_applications(id),
  
  -- Client info
  email TEXT NOT NULL,
  phone TEXT NOT NULL,
  client_name TEXT,
  business_name TEXT NOT NULL,
  
  -- Business details
  credit_score TEXT,
  in_business_over_6_months BOOLEAN NOT NULL,
  has_previous_loan BOOLEAN NOT NULL,
  previous_loan_company TEXT,
  previous_loan_amount TEXT,
  requested_amount DECIMAL(15,2),
  
  -- Status
  status TEXT DEFAULT 'pending', -- 'pending', 'in_review', 'docs_needed', 'approved', 'funded', 'declined', 'moved_to_credit_repair'
  
  -- Documents (storage paths)
  driver_license_front TEXT,
  driver_license_back TEXT,
  ein_document TEXT,
  ssn_card TEXT,
  void_check TEXT,
  bank_statements TEXT[],
  credit_card_statement TEXT,
  
  -- AI analysis
  ai_score INTEGER,
  ai_notes JSONB DEFAULT '{}',
  ai_recommended_path TEXT,
  ai_last_evaluated_at TIMESTAMPTZ,
  
  -- Scheduling
  follow_up_date TIMESTAMPTZ DEFAULT (now() + interval '20 days'),
  last_scan_at TIMESTAMPTZ,
  next_scan_at TIMESTAMPTZ,
  
  -- Worker assignment
  assigned_worker_id UUID REFERENCES auth.users(id),
  
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- Indexes
CREATE INDEX idx_fast_track_user ON public.fast_track_applications(user_id);
CREATE INDEX idx_fast_track_status ON public.fast_track_applications(status);
CREATE INDEX idx_fast_track_lead ON public.fast_track_applications(lead_id);
```

### 3.2 underwriting_cases

Underwriting analysis records.

```sql
CREATE TABLE public.underwriting_cases (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  application_id UUID NOT NULL,
  application_type TEXT NOT NULL, -- 'fast_track', 'loan'
  
  -- Assignment
  assigned_underwriter_id UUID REFERENCES auth.users(id),
  client_id UUID REFERENCES auth.users(id),
  
  -- Status
  status TEXT DEFAULT 'pending', -- 'pending', 'in_review', 'docs_needed', 'ready', 'approved', 'declined'
  
  -- AI Analysis Results
  fundability_status TEXT, -- 'fundable', 'conditional', 'not_fundable'
  risk_level TEXT, -- 'low', 'medium', 'high', 'borderline'
  
  -- Banking metrics
  avg_monthly_revenue DECIMAL(15,2),
  avg_daily_balance DECIMAL(15,2),
  lowest_balance DECIMAL(15,2),
  nsf_count INTEGER DEFAULT 0,
  negative_days INTEGER DEFAULT 0,
  months_analyzed INTEGER,
  
  -- Existing funding detection
  existing_funding_detected BOOLEAN DEFAULT false,
  existing_positions JSONB DEFAULT '[]',
  total_existing_balance DECIMAL(15,2),
  
  -- Risk flags
  risk_flags TEXT[],
  legal_issues JSONB DEFAULT '[]',
  
  -- AI internal notes
  ai_internal_notes TEXT,
  ai_funder_summary TEXT,
  ai_recommendations TEXT,
  
  -- Timestamps
  analyzed_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- Indexes
CREATE INDEX idx_underwriting_application ON public.underwriting_cases(application_id);
CREATE INDEX idx_underwriting_status ON public.underwriting_cases(status);
CREATE INDEX idx_underwriting_underwriter ON public.underwriting_cases(assigned_underwriter_id);
```

### 3.3 underwriting_feedback

User corrections for AI learning.

```sql
CREATE TABLE public.underwriting_feedback (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  application_id UUID NOT NULL,
  field TEXT NOT NULL,
  original_value TEXT,
  corrected_value TEXT,
  corrected_by UUID REFERENCES auth.users(id),
  created_at TIMESTAMPTZ DEFAULT now()
);
```

---

## 4. CREDIT REPAIR

### 4.1 credit_repair_applications

Client credit repair applications.

```sql
CREATE TABLE public.credit_repair_applications (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id),
  
  -- Client info
  email TEXT NOT NULL,
  phone TEXT NOT NULL,
  full_name TEXT NOT NULL,
  
  -- Credit details
  current_credit_score TEXT,
  desired_credit_score TEXT,
  negative_items TEXT,
  has_identity_theft BOOLEAN DEFAULT false,
  identity_theft_details TEXT,
  experian_username TEXT,
  goals TEXT,
  
  -- Status
  status TEXT DEFAULT 'pending',
  follow_up_date TIMESTAMPTZ DEFAULT (now() + interval '20 days'),
  
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);
```

### 4.2 credit_repair_cases

Active credit repair cases.

```sql
CREATE TABLE public.credit_repair_cases (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  credit_repair_application_id UUID NOT NULL REFERENCES public.credit_repair_applications(id),
  
  -- Original application (if came from funding decline)
  original_application_id UUID,
  original_application_type TEXT,
  from_declined_funding BOOLEAN DEFAULT false,
  
  -- Assignment
  assigned_specialist_id UUID REFERENCES auth.users(id),
  
  -- Status (Kanban stages)
  status TEXT DEFAULT 'intake', -- 'intake', 'docs_pending', 'investigation', 'disputes_sent', 'results_received', 'completed'
  
  -- AI analysis
  ai_score INTEGER,
  ai_recommended_path TEXT,
  ai_notes JSONB DEFAULT '{}',
  ai_last_evaluated_at TIMESTAMPTZ,
  
  -- Public records check
  last_public_check_at TIMESTAMPTZ,
  last_eligibility_status TEXT,
  last_soft_score INTEGER,
  
  -- Scheduling
  last_scan_at TIMESTAMPTZ,
  next_scan_at TIMESTAMPTZ,
  completed_at TIMESTAMPTZ,
  
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- Indexes
CREATE INDEX idx_credit_cases_specialist ON public.credit_repair_cases(assigned_specialist_id);
CREATE INDEX idx_credit_cases_status ON public.credit_repair_cases(status);
```

### 4.3 credit_repair_items

Individual negative items on credit report.

```sql
CREATE TABLE public.credit_repair_items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  case_id UUID NOT NULL REFERENCES public.credit_repair_cases(id) ON DELETE CASCADE,
  
  -- Account info
  creditor_name TEXT,
  account_number TEXT,
  item_type TEXT NOT NULL, -- 'collection', 'late_payment', 'charge_off', 'inquiry', 'public_record'
  source_bureau TEXT, -- 'equifax', 'experian', 'transunion'
  
  -- Dispute info
  status TEXT DEFAULT 'identified', -- 'identified', 'disputed', 'verified', 'deleted', 'updated'
  dispute_reason TEXT,
  dispute_basis_code TEXT,
  dispute_date TIMESTAMPTZ,
  resolution_date TIMESTAMPTZ,
  resolution_outcome TEXT,
  
  -- Compliance codes
  metro2_code TEXT,
  fcra_section TEXT,
  fdcpa_section TEXT,
  
  -- Jurisdiction
  client_state TEXT,
  collector_state TEXT,
  
  -- AI flags
  risk_tags TEXT[],
  ai_generated BOOLEAN DEFAULT false,
  ai_last_reviewed_at TIMESTAMPTZ,
  
  notes TEXT,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- Indexes
CREATE INDEX idx_credit_items_case ON public.credit_repair_items(case_id);
CREATE INDEX idx_credit_items_status ON public.credit_repair_items(status);
```

### 4.4 credit_repair_dispute_drafts

Generated dispute letters.

```sql
CREATE TABLE public.credit_repair_dispute_drafts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  case_id UUID NOT NULL REFERENCES public.credit_repair_cases(id) ON DELETE CASCADE,
  item_id UUID REFERENCES public.credit_repair_items(id),
  
  -- Letter content
  target TEXT NOT NULL, -- 'bureau', 'creditor', 'collector'
  target_name TEXT NOT NULL,
  subject TEXT NOT NULL,
  body TEXT NOT NULL,
  signature TEXT,
  
  -- Metadata
  worker_type TEXT DEFAULT 'ai', -- 'ai', 'human'
  status TEXT DEFAULT 'draft', -- 'draft', 'approved', 'sent', 'archived'
  
  created_by UUID REFERENCES auth.users(id),
  approved_by UUID REFERENCES auth.users(id),
  approved_at TIMESTAMPTZ,
  sent_at TIMESTAMPTZ,
  
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);
```

### 4.5 credit_repair_tasks

Tasks for credit repair cases.

```sql
CREATE TABLE public.credit_repair_tasks (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  case_id UUID NOT NULL REFERENCES public.credit_repair_cases(id) ON DELETE CASCADE,
  
  title TEXT NOT NULL,
  description TEXT,
  source TEXT DEFAULT 'manual', -- 'manual', 'ai', 'system'
  
  assigned_to UUID REFERENCES auth.users(id),
  due_date TIMESTAMPTZ,
  
  completed BOOLEAN DEFAULT false,
  completed_at TIMESTAMPTZ,
  
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);
```

### 4.6 credit_repair_activity_log

Activity history for cases.

```sql
CREATE TABLE public.credit_repair_activity_log (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  case_id UUID NOT NULL REFERENCES public.credit_repair_cases(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES auth.users(id),
  
  activity_type TEXT NOT NULL,
  description TEXT NOT NULL,
  hidden_notes TEXT, -- Admin-only notes (super admin visible only)
  
  metadata JSONB DEFAULT '{}',
  created_at TIMESTAMPTZ DEFAULT now()
);
```

---

## 5. USER & ROLE MANAGEMENT

### 5.1 call_sessions

Dialer session tracking.

```sql
CREATE TABLE public.call_sessions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  worker_id UUID NOT NULL REFERENCES auth.users(id),
  is_active BOOLEAN DEFAULT true,
  started_at TIMESTAMPTZ DEFAULT now(),
  ended_at TIMESTAMPTZ,
  
  -- Stats
  calls_made INTEGER DEFAULT 0,
  calls_connected INTEGER DEFAULT 0,
  intakes_sent INTEGER DEFAULT 0
);

-- Indexes
CREATE INDEX idx_call_sessions_worker ON public.call_sessions(worker_id);
CREATE INDEX idx_call_sessions_active ON public.call_sessions(is_active);
```

### 5.2 worker_activity_logs

Worker action tracking.

```sql
CREATE TABLE public.worker_activity_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  worker_id UUID NOT NULL REFERENCES auth.users(id),
  worker_email TEXT,
  
  action_type TEXT NOT NULL, -- 'call', 'email', 'intake_sent', 'document_upload', etc.
  lead_id UUID REFERENCES public.leads(id),
  application_id UUID,
  
  details JSONB DEFAULT '{}',
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Indexes
CREATE INDEX idx_worker_activity_worker ON public.worker_activity_logs(worker_id);
CREATE INDEX idx_worker_activity_type ON public.worker_activity_logs(action_type);
CREATE INDEX idx_worker_activity_date ON public.worker_activity_logs(created_at);
```

---

## 6. ISO & COMMISSIONS

### 6.1 iso_partner_applications

ISO partner signup and management.

```sql
CREATE TABLE public.iso_partner_applications (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id),
  
  -- Contact
  full_name TEXT NOT NULL,
  email TEXT NOT NULL,
  phone TEXT NOT NULL,
  company_name TEXT NOT NULL,
  
  -- Business details
  funding_type TEXT,
  monthly_deals TEXT,
  iso_volume_history TEXT,
  
  -- Agreement
  agreement_document TEXT,
  commission_rate DECIMAL(5,2) DEFAULT 8.00,
  
  -- Status
  status TEXT DEFAULT 'pending', -- 'pending', 'agreement_sent', 'approved', 'rejected'
  approved BOOLEAN DEFAULT false,
  approved_by UUID REFERENCES auth.users(id),
  approved_at TIMESTAMPTZ,
  
  notes TEXT,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- Indexes
CREATE INDEX idx_iso_applications_status ON public.iso_partner_applications(status);
CREATE INDEX idx_iso_applications_user ON public.iso_partner_applications(user_id);
```

### 6.2 iso_commissions

Commission tracking per funded deal.

```sql
CREATE TABLE public.iso_commissions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  iso_partner_id UUID NOT NULL REFERENCES public.iso_partner_applications(id),
  funded_contract_id UUID NOT NULL REFERENCES public.funded_contracts(id),
  
  commission_rate DECIMAL(5,2) NOT NULL,
  commission_amount DECIMAL(15,2) NOT NULL,
  
  payment_status TEXT DEFAULT 'pending', -- 'pending', 'approved', 'paid'
  payment_date TIMESTAMPTZ,
  payment_method TEXT,
  
  notes TEXT,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- Indexes
CREATE INDEX idx_iso_commissions_partner ON public.iso_commissions(iso_partner_id);
CREATE INDEX idx_iso_commissions_status ON public.iso_commissions(payment_status);
```

### 6.3 funded_contracts

Funded deal records.

```sql
CREATE TABLE public.funded_contracts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  application_id UUID NOT NULL,
  application_type TEXT NOT NULL,
  
  -- Client info
  client_name TEXT NOT NULL,
  business_name TEXT NOT NULL,
  
  -- Funding details
  funding_amount DECIMAL(15,2) NOT NULL,
  daily_payment DECIMAL(15,2),
  contract_start_date TIMESTAMPTZ DEFAULT now(),
  contract_end_date TIMESTAMPTZ NOT NULL,
  
  -- Original data
  original_credit_score TEXT,
  original_revenue DECIMAL(15,2),
  
  -- Status
  status TEXT DEFAULT 'active', -- 'active', 'completed', 'defaulted', 'renewed'
  renewal_eligible BOOLEAN DEFAULT false,
  
  notes TEXT,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);
```

---

## 7. DOCUMENTS & STORAGE

### 7.1 document_extractions

OCR/AI extracted document data.

```sql
CREATE TABLE public.document_extractions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  application_id UUID NOT NULL,
  application_type TEXT NOT NULL,
  
  document_type TEXT NOT NULL, -- 'bank_statement', 'driver_license', 'ein', 'ssn', 'void_check'
  raw_text TEXT,
  parsed_data JSONB DEFAULT '{}',
  
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Indexes
CREATE INDEX idx_doc_extractions_app ON public.document_extractions(application_id);
```

### 7.2 signature_requests

DocuSign / e-signature tracking.

```sql
CREATE TABLE public.signature_requests (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  
  -- Target
  recipient_email TEXT NOT NULL,
  recipient_name TEXT,
  recipient_user_id UUID REFERENCES auth.users(id),
  
  -- Document
  document_type TEXT NOT NULL, -- 'iso_agreement', 'credit_repair_agreement', 'client_engagement'
  related_id UUID,
  
  -- DocuSign
  docusign_envelope_id TEXT,
  docusign_status TEXT,
  
  -- Status
  status TEXT DEFAULT 'sent', -- 'sent', 'viewed', 'signed', 'declined', 'expired'
  signed_at TIMESTAMPTZ,
  signed_document_url TEXT,
  
  sent_by UUID REFERENCES auth.users(id),
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);
```

---

## 8. COMMUNICATIONS

### 8.1 communication_logs

All outbound communications.

```sql
CREATE TABLE public.communication_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  
  -- Recipient
  recipient_id UUID NOT NULL,
  recipient_type TEXT NOT NULL, -- 'lead', 'user', 'iso_partner'
  recipient_email TEXT,
  recipient_phone TEXT,
  
  -- Communication
  communication_type TEXT NOT NULL, -- 'email', 'sms', 'push'
  template_name TEXT,
  subject TEXT,
  content TEXT NOT NULL,
  
  -- Status
  status TEXT DEFAULT 'pending', -- 'pending', 'sent', 'delivered', 'failed', 'bounced'
  sent_at TIMESTAMPTZ,
  delivered_at TIMESTAMPTZ,
  error_message TEXT,
  
  metadata JSONB DEFAULT '{}',
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Indexes
CREATE INDEX idx_comm_logs_recipient ON public.communication_logs(recipient_id);
CREATE INDEX idx_comm_logs_type ON public.communication_logs(communication_type);
CREATE INDEX idx_comm_logs_status ON public.communication_logs(status);
```

### 8.2 email_templates

Reusable email templates.

```sql
CREATE TABLE public.email_templates (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  
  name TEXT NOT NULL,
  template_type TEXT NOT NULL, -- 'follow_up', 'intake', 'status_update', 'welcome', 'dispute'
  subject TEXT NOT NULL,
  body TEXT NOT NULL,
  
  is_default BOOLEAN DEFAULT false,
  created_by UUID REFERENCES auth.users(id),
  
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);
```

---

## 9. ANALYTICS & AUDIT

### 9.1 ai_events

AI decision audit log.

```sql
CREATE TABLE public.ai_events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  
  entity_type TEXT NOT NULL, -- 'lead', 'application', 'credit_case'
  entity_id UUID NOT NULL,
  event_type TEXT NOT NULL, -- 'intake', 'enrichment', 'routing', 'analysis', 'letter_generation'
  
  model_name TEXT,
  payload_in JSONB,
  payload_out JSONB,
  
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Indexes
CREATE INDEX idx_ai_events_entity ON public.ai_events(entity_type, entity_id);
CREATE INDEX idx_ai_events_type ON public.ai_events(event_type);
CREATE INDEX idx_ai_events_date ON public.ai_events(created_at);
```

### 9.2 audit_logs

System-wide audit trail.

```sql
CREATE TABLE public.audit_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  
  user_id UUID NOT NULL REFERENCES auth.users(id),
  action_type TEXT NOT NULL,
  resource_type TEXT NOT NULL,
  resource_id UUID NOT NULL,
  
  changes JSONB,
  ip_address TEXT,
  user_agent TEXT,
  
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Indexes
CREATE INDEX idx_audit_logs_user ON public.audit_logs(user_id);
CREATE INDEX idx_audit_logs_resource ON public.audit_logs(resource_type, resource_id);
CREATE INDEX idx_audit_logs_date ON public.audit_logs(created_at);
```

### 9.3 activity_feed

Real-time activity stream.

```sql
CREATE TABLE public.activity_feed (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  
  -- Actor
  actor_user_id UUID REFERENCES auth.users(id),
  actor_email TEXT,
  actor_role TEXT,
  
  -- Target
  target_user_id UUID REFERENCES auth.users(id),
  target_email TEXT,
  
  -- Event
  event_type TEXT NOT NULL,
  context_type TEXT NOT NULL, -- 'lead', 'application', 'credit_case', 'user'
  context_id UUID,
  
  summary TEXT NOT NULL,
  decision TEXT,
  decision_reason TEXT,
  details JSONB DEFAULT '{}',
  
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Indexes
CREATE INDEX idx_activity_actor ON public.activity_feed(actor_user_id);
CREATE INDEX idx_activity_context ON public.activity_feed(context_type, context_id);
CREATE INDEX idx_activity_date ON public.activity_feed(created_at DESC);
```

---

## 10. ENUMS & TYPES

### Complete Enum Definitions

```sql
-- User roles
CREATE TYPE public.app_role AS ENUM (
  'admin',
  'worker',
  'researcher', 
  'underwriter',
  'credit_repair_specialist',
  'iso_partner',
  'funding_manager',
  'user'
);

-- Lead routing
CREATE TYPE public.lead_route AS ENUM (
  'dialer',
  'email',
  'research',
  'rejected'
);

-- Lead status
CREATE TYPE public.lead_status AS ENUM (
  'new',
  'enriched',
  'research_pending',
  'research_completed',
  'dialer_queue',
  'contacted',
  'interested',
  'callback',
  'intake_sent',
  'intake_completed',
  'underwriting',
  'docs_requested',
  'docs_uploaded',
  'funded',
  'credit_repair',
  'dead',
  'do_not_contact'
);

-- Dialer status
CREATE TYPE public.dialer_status AS ENUM (
  'new',
  'in_progress',
  'callback',
  'not_interested',
  'converted',
  'dead'
);

-- AI priority
CREATE TYPE public.ai_priority AS ENUM ('A', 'B', 'C', 'D');

-- AI recommended path
CREATE TYPE public.ai_recommended_path AS ENUM (
  'funding_first',
  'credit_first',
  'hybrid',
  'do_not_work'
);
```

---

## 11. RLS POLICIES

### Core Security Function

```sql
-- Security definer function to check roles
CREATE OR REPLACE FUNCTION public.has_role(_user_id uuid, _role app_role)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.user_roles
    WHERE user_id = _user_id
      AND role = _role
      AND approved = true
  )
$$;
```

### Example RLS Policies

```sql
-- Leads: Workers can see dialer leads, researchers see research leads
CREATE POLICY "Workers can view dialer leads"
ON public.leads FOR SELECT
USING (
  has_role(auth.uid(), 'admin') OR
  has_role(auth.uid(), 'worker') OR
  (has_role(auth.uid(), 'researcher') AND route = 'research')
);

-- Applications: Users see own, admins see all
CREATE POLICY "Users view own applications"
ON public.fast_track_applications FOR SELECT
USING (
  user_id = auth.uid() OR
  has_role(auth.uid(), 'admin') OR
  has_role(auth.uid(), 'underwriter')
);

-- Credit cases: Specialists see assigned, admins see all
CREATE POLICY "Specialists view assigned cases"
ON public.credit_repair_cases FOR SELECT
USING (
  has_role(auth.uid(), 'admin') OR
  (has_role(auth.uid(), 'credit_repair_specialist') AND assigned_specialist_id = auth.uid())
);

-- ISO Partners see only their own data
CREATE POLICY "ISO partners view own submissions"
ON public.fast_track_applications FOR SELECT
USING (
  has_role(auth.uid(), 'admin') OR
  user_id = auth.uid() OR
  iso_partner_id IN (
    SELECT id FROM public.iso_partner_applications WHERE user_id = auth.uid()
  )
);
```

---

## 12. DATABASE FUNCTIONS

### Lead Management Functions

```sql
-- Get next lead for dialer worker
CREATE OR REPLACE FUNCTION public.get_next_lead_for_worker(p_worker_id uuid)
RETURNS public.leads
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_lead leads;
BEGIN
  -- Try new leads first
  SELECT * INTO v_lead
  FROM leads
  WHERE dialer_status = 'new'
    AND route = 'dialer'
    AND (current_owner_id IS NULL OR current_owner_id = p_worker_id)
  ORDER BY ai_score DESC NULLS LAST, funding_score DESC NULLS LAST
  LIMIT 1
  FOR UPDATE SKIP LOCKED;

  IF NOT FOUND THEN
    -- Try callback leads
    SELECT * INTO v_lead
    FROM leads
    WHERE dialer_status = 'callback'
      AND current_owner_id = p_worker_id
      AND next_callback_at <= now()
    ORDER BY next_callback_at ASC
    LIMIT 1
    FOR UPDATE SKIP LOCKED;
  END IF;

  IF NOT FOUND THEN
    RETURN NULL;
  END IF;

  -- Lock to worker
  UPDATE leads
  SET 
    dialer_status = 'in_progress',
    current_owner_id = p_worker_id,
    lock_expires_at = now() + interval '7 days'
  WHERE id = v_lead.id;

  SELECT * INTO v_lead FROM leads WHERE id = v_lead.id;
  RETURN v_lead;
END;
$$;

-- Claim next research lead
CREATE OR REPLACE FUNCTION public.claim_next_research_lead(p_worker_id uuid)
RETURNS public.leads
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_lead leads;
BEGIN
  UPDATE leads
  SET
    research_status = 'in_progress',
    research_assigned_to = p_worker_id,
    research_started_at = now(),
    research_attempts = COALESCE(research_attempts, 0) + 1
  WHERE id = (
    SELECT id FROM leads
    WHERE route = 'research'
      AND (research_status = 'pending' OR research_status IS NULL)
      AND status = 'new'
    ORDER BY created_at ASC
    LIMIT 1
    FOR UPDATE SKIP LOCKED
  )
  RETURNING * INTO v_lead;

  RETURN v_lead;
END;
$$;

-- Mark call outcome
CREATE OR REPLACE FUNCTION public.mark_call_outcome(
  p_lead_id uuid,
  p_worker_id uuid,
  p_outcome text,
  p_next_action text,
  p_callback_at timestamptz DEFAULT NULL
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_new_dialer_status dialer_status;
BEGIN
  -- Determine new status
  v_new_dialer_status := CASE
    WHEN p_next_action = 'schedule_callback' THEN 'callback'::dialer_status
    WHEN p_next_action = 'not_interested' THEN 'not_interested'::dialer_status
    WHEN p_next_action = 'dead' THEN 'dead'::dialer_status
    WHEN p_next_action = 'convert_to_application' THEN 'converted'::dialer_status
    ELSE 'new'::dialer_status
  END;

  -- Update lead
  UPDATE leads
  SET
    last_called_at = now(),
    last_call_outcome = p_outcome,
    last_called_by = p_worker_id,
    dialer_status = v_new_dialer_status,
    call_attempts = call_attempts + 1,
    next_callback_at = p_callback_at,
    status = CASE 
      WHEN p_next_action = 'convert_to_application' THEN 'interested'::lead_status
      WHEN p_next_action = 'dead' THEN 'dead'::lead_status
      ELSE status
    END
  WHERE id = p_lead_id;

  -- Log call attempt
  INSERT INTO lead_call_attempts (
    lead_id, agent_id, agent_email, outcome, next_action, callback_scheduled_at
  ) VALUES (
    p_lead_id,
    p_worker_id,
    (SELECT email FROM auth.users WHERE id = p_worker_id),
    p_outcome,
    p_next_action,
    p_callback_at
  );
END;
$$;
```

---

## 13. TRIGGERS

### Auto-update Timestamps

```sql
-- Generic updated_at trigger
CREATE OR REPLACE FUNCTION public.handle_updated_at()
RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

-- Apply to all tables with updated_at
CREATE TRIGGER set_updated_at
  BEFORE UPDATE ON public.leads
  FOR EACH ROW EXECUTE FUNCTION public.handle_updated_at();

CREATE TRIGGER set_updated_at
  BEFORE UPDATE ON public.fast_track_applications
  FOR EACH ROW EXECUTE FUNCTION public.handle_updated_at();

CREATE TRIGGER set_updated_at
  BEFORE UPDATE ON public.credit_repair_cases
  FOR EACH ROW EXECUTE FUNCTION public.handle_updated_at();

-- Add more triggers for other tables...
```

### Auto-create User Profile

```sql
CREATE OR REPLACE FUNCTION public.handle_new_user_signup()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Create profile
  INSERT INTO public.users_profile (user_id)
  VALUES (NEW.id);
  
  -- Assign default role
  INSERT INTO public.user_roles (user_id, role, approved)
  VALUES (NEW.id, 'user', true);
  
  RETURN NEW;
END;
$$;

CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user_signup();
```

---

## STORAGE BUCKETS

```sql
-- Required storage buckets
INSERT INTO storage.buckets (id, name, public) VALUES
  ('fast-track-documents', 'fast-track-documents', false),
  ('loan-application-documents', 'loan-application-documents', false),
  ('credit-repair-documents', 'credit-repair-documents', false),
  ('iso-partner-documents', 'iso-partner-documents', false),
  ('lead-imports', 'lead-imports', false),
  ('lead-lists', 'lead-lists', false),
  ('lead-files', 'lead-files', false);
```

---

*Document Version: 1.0*
*Last Updated: December 2, 2024*
*Wolf Ecosystem V1 Specification*
