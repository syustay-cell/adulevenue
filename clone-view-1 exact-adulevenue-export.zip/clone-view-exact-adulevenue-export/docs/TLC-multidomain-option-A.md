# TLC Multi-Domain Architecture (Option A)

Status: Documentation only. No implementation approved.

## Executive decision
Option A is required: two separate public sites, one shared backend.
Option B (single site with host-based theming) is rejected.

## Domains and roles (locked)

### wolf-fund.com
- Role: Private operating system (Wolf OS).
- Hosts Supabase, Edge Functions, identity spine, event ledger.
- Not a public brand or marketing site.

### thelefkowitzcenter.org
- Role: National institutional site.
- Audience: legislators, foundations, national partners, media.
- Tone: calm, evergreen, policy and replication oriented.
- Avoids day-to-day NJ development detail.

### tlc-nj.com
- Role: New Jersey pilot and development site.
- Audience: NJ donors, local partners, community, event attendees.
- Tone: local, dynamic, progress and milestones.

## System rules (non-negotiable)
All changes must comply with the TLC Invariants Charter:
`docs/TLC-invariants-charter.md`.

## Intake and data tagging (required)
Every public submission routed to Wolf OS intake endpoints must include:
- source_domain: window.location.hostname
- source_site: "tlc"
- program:
  - "national" for thelefkowitzcenter.org
  - "nj_pilot" for tlc-nj.com
- intent: a canonical value such as donor, family_help, partner, legislation,
  volunteer, etc.

Purpose: a single backend can route, segment, and report without duplication.

## CORS / origin allowlist
If Wolf OS endpoints enforce CORS, allow:
- https://thelefkowitzcenter.org
- https://www.thelefkowitzcenter.org
- https://tlc-nj.com
- https://www.tlc-nj.com

No broad wildcard CORS for sensitive endpoints.

## Auth redirect URLs (only if public auth exists)
If any TLC public site uses Supabase auth, the redirect URLs must include:
- https://thelefkowitzcenter.org/*
- https://tlc-nj.com/*
and www variants.

If no public auth exists, this remains out of scope.

## Canonical linking and cross-site navigation
- National site links to NJ site: "See the New Jersey Pilot in Action".
- NJ site links to national site: "About the National Lefkowitz Center Model".
- Use canonical tags per domain to avoid SEO duplication.

## Content responsibilities (minimal launch set)

thelefkowitzcenter.org:
- Home
- The Model
- Legislation and Policy
- National Vision or Replication
- Support and Partners (high level)
- Stories and Progress (institutional milestones)
- Get Involved (national paths)

tlc-nj.com:
- NJ Overview
- Campus Development (Phases and Milestones)
- Events and Fundraisers
- NJ Partners and Supporters
- Progress Updates (photos, milestones)
- Get Involved in NJ

## Scope boundaries
This document defines the approved architecture only.
No code, configuration, DNS, deployment, migration, or infrastructure changes
are authorized until explicit written greenlight is provided.

