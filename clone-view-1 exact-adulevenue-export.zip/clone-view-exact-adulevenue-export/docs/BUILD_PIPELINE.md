# Wolf-Fund OS – Build Pipeline

This document describes the build process and safety checks for Wolf-Fund OS.

---

## Build Commands

### Development
```bash
npm run dev
```
Starts the Vite development server with hot reload.

### Pre-Build Check
```bash
npm run prebuild
```
Scans `src/` for SSR-unsafe patterns:
- `window.` at module scope
- `document.` at module scope
- `localStorage` / `sessionStorage` at module scope
- `navigator.` at module scope

**Must pass before deployment.**

### Production Build
```bash
npm run build
```
Creates production-optimized bundle in `dist/`.

---

## Pre-Build Check Details

**Script:** `scripts/prebuild-check.ts`

### What It Checks
1. Scans all `.ts` and `.tsx` files in `src/`
2. Looks for browser-only APIs at module top-level
3. Skips files in the ignore list (e.g., `main.tsx`)
4. Reports violations with file path, line number, and code snippet

### Safe Patterns (Ignored)
Code inside these contexts is considered safe:
- `useEffect`
- `useCallback`
- `useMemo`
- `if (typeof window !== 'undefined')`

### Example Output
```
[prebuild-check] Scanning src/ for dangerous SSR patterns...

[prebuild-check] ✅ No SSR violations found.

[prebuild-check] Done.
```

Or with violations:
```
[prebuild-check] ⚠️  Found 2 potential SSR issue(s):

  1. /src/hooks/useExample.ts:15
     Pattern: "localStorage"
     Code: const value = localStorage.getItem('key');

  2. /src/components/Example.tsx:8
     Pattern: "window."
     Code: const width = window.innerWidth;

[prebuild-check] Review these manually.
```

---

## Fixing SSR Issues

### Pattern 1: Direct localStorage Usage
```typescript
// ❌ WRONG - Breaks SSR
const value = localStorage.getItem('key');

// ✅ CORRECT - SSR safe
const [value, setValue] = useState<string | null>(null);
useEffect(() => {
  setValue(localStorage.getItem('key'));
}, []);
```

### Pattern 2: Window/Document Access
```typescript
// ❌ WRONG - Breaks SSR
const width = window.innerWidth;

// ✅ CORRECT - SSR safe
const [width, setWidth] = useState(0);
useEffect(() => {
  setWidth(window.innerWidth);
}, []);
```

### Pattern 3: Conditional Guard
```typescript
// ✅ CORRECT - SSR safe with guard
const getStorage = () => {
  if (typeof window === 'undefined') return undefined;
  return window.localStorage;
};
```

---

## Deployment Checklist

1. [ ] `npm run prebuild` passes (no violations or all reviewed)
2. [ ] `npm run build` succeeds without errors
3. [ ] No TypeScript errors
4. [ ] No console errors in browser
5. [ ] All routes load correctly
6. [ ] Authentication flows work

---

## Troubleshooting

### "Houston, We Have a Problem" Error
**Cause:** SSR build failure, usually from browser API at module scope.

**Fix:**
1. Run `npm run prebuild` to find violations
2. Fix each violation using patterns above
3. Run `npm run build` to verify

### Build Timeout
**Cause:** Large bundle or circular imports.

**Fix:**
1. Check for circular imports in routes/layouts
2. Add lazy loading for heavy pages
3. Split large components

### Type Errors
**Cause:** Supabase types out of sync or missing imports.

**Fix:**
1. Check `src/integrations/supabase/types.ts` is up to date
2. Verify all imports resolve correctly
3. Run TypeScript check: `npx tsc --noEmit`
