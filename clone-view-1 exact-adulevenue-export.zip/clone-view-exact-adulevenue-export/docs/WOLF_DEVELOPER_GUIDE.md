# 🐺 WOLF ECOSYSTEM V1 — DEVELOPER GUIDE

> Module-by-module implementation instructions for developers

---

## TABLE OF CONTENTS

1. [Project Setup](#1-project-setup)
2. [Authentication Module](#2-authentication-module)
3. [Lead Engine Module](#3-lead-engine-module)
4. [Research Queue Module](#4-research-queue-module)
5. [Dialer V3 Module](#5-dialer-v3-module)
6. [Underwriting Module](#6-underwriting-module)
7. [Credit Fix Studio Module](#7-credit-fix-studio-module)
8. [ISO Partner Module](#8-iso-partner-module)
9. [Admin Dashboard Module](#9-admin-dashboard-module)
10. [AI Integration Guide](#10-ai-integration-guide)
11. [Real-time Features](#11-real-time-features)
12. [Testing Strategy](#12-testing-strategy)

---

## 1. PROJECT SETUP

### 1.1 Clone and Install

```bash
# Clone repository
git clone [repo-url]
cd wolf-ecosystem

# Install dependencies
npm install

# Start development server
npm run dev
```

### 1.2 Environment Configuration

Create `.env.local` (DO NOT commit):

```env
# These are automatically provided by Cloud hosting
VITE_SUPABASE_URL=your-project-url
VITE_SUPABASE_ANON_KEY=your-anon-key
VITE_SUPABASE_PROJECT_ID=your-project-id

# Google reCAPTCHA
VITE_RECAPTCHA_SITE_KEY=your-recaptcha-key
```

### 1.3 Project Structure

```
wolf-ecosystem/
├── src/
│   ├── components/
│   │   ├── ui/                 # shadcn components
│   │   ├── admin/              # Admin dashboard components
│   │   ├── credit-repair/      # Credit fix components
│   │   ├── dialer/             # Dialer components
│   │   ├── lead-engine/        # Lead engine components
│   │   ├── underwriting/       # Underwriting components
│   │   └── help/               # Help/assistant components
│   ├── hooks/                  # Custom React hooks
│   ├── lib/                    # Utilities and helpers
│   ├── pages/                  # Page components
│   ├── types/                  # TypeScript types
│   └── integrations/
│       └── supabase/           # Supabase client & types
├── supabase/
│   ├── functions/              # Edge functions
│   └── migrations/             # Database migrations
├── docs/                       # Documentation
└── tests/                      # Test files
```

### 1.4 Key Dependencies

```json
{
  "dependencies": {
    "@supabase/supabase-js": "^2.86.0",
    "@tanstack/react-query": "^5.83.0",
    "react": "^18.3.1",
    "react-router-dom": "^6.30.1",
    "tailwindcss": "latest",
    "framer-motion": "^12.23.24",
    "recharts": "^2.15.4",
    "zod": "^3.25.76",
    "react-hook-form": "^7.61.1"
  }
}
```

---

## 2. AUTHENTICATION MODULE

### 2.1 Implementation Steps

1. **Create Auth Page** (`src/pages/Auth.tsx`)

```typescript
import { useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useNavigate } from 'react-router-dom';
import ReCAPTCHA from 'react-google-recaptcha';
import { toast } from 'sonner';

export default function Auth() {
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [captchaToken, setCaptchaToken] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!captchaToken) {
      toast.error('Please complete the captcha');
      return;
    }
    
    setLoading(true);
    
    if (isLogin) {
      const { error } = await supabase.auth.signInWithPassword({
        email,
        password
      });
      if (error) {
        toast.error(error.message);
      } else {
        navigate('/');
      }
    } else {
      const { error } = await supabase.auth.signUp({
        email,
        password
      });
      if (error) {
        toast.error(error.message);
      } else {
        toast.success('Check your email for verification');
      }
    }
    
    setLoading(false);
  };

  return (
    // ... JSX implementation
  );
}
```

2. **Create Protected Route Component**

```typescript
// src/components/ProtectedRoute.tsx
import { useEffect, useState } from 'react';
import { Navigate } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';

interface ProtectedRouteProps {
  children: React.ReactNode;
  requiredRoles?: string[];
}

export function ProtectedRoute({ children, requiredRoles }: ProtectedRouteProps) {
  const [loading, setLoading] = useState(true);
  const [user, setUser] = useState<any>(null);
  const [hasRole, setHasRole] = useState(false);

  useEffect(() => {
    checkAuth();
  }, []);

  const checkAuth = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    setUser(user);
    
    if (user && requiredRoles?.length) {
      const { data: roles } = await supabase
        .from('user_roles')
        .select('role')
        .eq('user_id', user.id)
        .eq('approved', true);
      
      const userRoles = roles?.map(r => r.role) || [];
      setHasRole(requiredRoles.some(r => userRoles.includes(r)));
    } else {
      setHasRole(true);
    }
    
    setLoading(false);
  };

  if (loading) return <div>Loading...</div>;
  if (!user) return <Navigate to="/auth" />;
  if (!hasRole) return <Navigate to="/" />;
  
  return <>{children}</>;
}
```

3. **Create Auth Hook**

```typescript
// src/hooks/useAuth.ts
import { useEffect, useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { User } from '@supabase/supabase-js';

export function useAuth() {
  const [user, setUser] = useState<User | null>(null);
  const [roles, setRoles] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Get initial session
    supabase.auth.getSession().then(({ data: { session } }) => {
      setUser(session?.user ?? null);
      if (session?.user) {
        fetchRoles(session.user.id);
      } else {
        setLoading(false);
      }
    });

    // Listen for auth changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      async (event, session) => {
        setUser(session?.user ?? null);
        if (session?.user) {
          fetchRoles(session.user.id);
        } else {
          setRoles([]);
          setLoading(false);
        }
      }
    );

    return () => subscription.unsubscribe();
  }, []);

  const fetchRoles = async (userId: string) => {
    const { data } = await supabase
      .from('user_roles')
      .select('role')
      .eq('user_id', userId)
      .eq('approved', true);
    
    setRoles(data?.map(r => r.role) || []);
    setLoading(false);
  };

  const hasRole = (role: string) => roles.includes(role);
  const isAdmin = () => hasRole('admin');

  return { user, roles, loading, hasRole, isAdmin };
}
```

---

## 3. LEAD ENGINE MODULE

### 3.1 Implementation Steps

1. **Create Lead List Upload Component**

```typescript
// src/components/lead-engine/LeadListUpload.tsx
import { useState, useCallback } from 'react';
import { useDropzone } from 'react-dropzone';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { Progress } from '@/components/ui/progress';
import { Upload } from 'lucide-react';

export function LeadListUpload() {
  const [uploading, setUploading] = useState(false);
  const [progress, setProgress] = useState(0);

  const onDrop = useCallback(async (acceptedFiles: File[]) => {
    const file = acceptedFiles[0];
    if (!file) return;

    setUploading(true);
    
    try {
      // 1. Upload file to storage
      const fileName = `${Date.now()}_${file.name}`;
      const { data: uploadData, error: uploadError } = await supabase.storage
        .from('lead-lists')
        .upload(fileName, file);

      if (uploadError) throw uploadError;

      // 2. Create lead_list record
      const { data: listData, error: listError } = await supabase
        .from('lead_lists')
        .insert({
          name: file.name,
          file_path: uploadData.path,
          status: 'pending'
        })
        .select()
        .single();

      if (listError) throw listError;

      // 3. Trigger processing edge function
      const { data: processData, error: processError } = await supabase.functions
        .invoke('process-lead-list', {
          body: { listId: listData.id }
        });

      if (processError) throw processError;

      toast.success(`Processing ${processData.stats.total} leads`);
      
    } catch (error) {
      console.error('Upload failed:', error);
      toast.error('Failed to upload file');
    } finally {
      setUploading(false);
    }
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'text/csv': ['.csv'],
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': ['.xlsx'],
      'application/vnd.ms-excel': ['.xls']
    },
    maxFiles: 1
  });

  return (
    <div
      {...getRootProps()}
      className={`border-2 border-dashed rounded-lg p-8 text-center cursor-pointer
        ${isDragActive ? 'border-primary bg-primary/5' : 'border-border'}
        ${uploading ? 'opacity-50 pointer-events-none' : ''}`}
    >
      <input {...getInputProps()} />
      {uploading ? (
        <div className="space-y-2">
          <p>Uploading...</p>
          <Progress value={progress} />
        </div>
      ) : (
        <div>
          <Upload className="mx-auto h-12 w-12 text-muted-foreground" />
          <p className="mt-2">Drag & drop Excel/CSV file here</p>
          <p className="text-sm text-muted-foreground">or click to browse</p>
        </div>
      )}
    </div>
  );
}
```

2. **Create Lead Lists Table Component**

```typescript
// src/components/lead-engine/LeadListsTable.tsx
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { format } from 'date-fns';

export function LeadListsTable() {
  const { data: lists, isLoading } = useQuery({
    queryKey: ['lead-lists'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('lead_lists')
        .select('*')
        .order('created_at', { ascending: false });
      
      if (error) throw error;
      return data;
    }
  });

  if (isLoading) return <div>Loading...</div>;

  return (
    <Table>
      <TableHeader>
        <TableRow>
          <TableHead>Name</TableHead>
          <TableHead>Total</TableHead>
          <TableHead>Dialer</TableHead>
          <TableHead>Email</TableHead>
          <TableHead>Research</TableHead>
          <TableHead>Quality</TableHead>
          <TableHead>Status</TableHead>
          <TableHead>Date</TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        {lists?.map((list) => (
          <TableRow key={list.id}>
            <TableCell className="font-medium">{list.name}</TableCell>
            <TableCell>{list.total_rows || 0}</TableCell>
            <TableCell>{list.dialer_count || 0}</TableCell>
            <TableCell>{list.email_count || 0}</TableCell>
            <TableCell>{list.research_count || 0}</TableCell>
            <TableCell>
              {list.import_quality_score && (
                <Badge variant={
                  list.import_quality_score >= 80 ? 'default' :
                  list.import_quality_score >= 60 ? 'secondary' : 'destructive'
                }>
                  {list.import_quality_score}%
                </Badge>
              )}
            </TableCell>
            <TableCell>
              <Badge variant={
                list.status === 'completed' ? 'default' :
                list.status === 'processing' ? 'secondary' : 'outline'
              }>
                {list.status}
              </Badge>
            </TableCell>
            <TableCell>{format(new Date(list.created_at), 'MMM d, yyyy')}</TableCell>
          </TableRow>
        ))}
      </TableBody>
    </Table>
  );
}
```

3. **Create Process Lead List Edge Function**

```typescript
// supabase/functions/process-lead-list/index.ts
import { serve } from 'https://deno.land/std@0.168.0/http/server.ts';
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
    );

    const { listId } = await req.json();

    // 1. Get list info
    const { data: list, error: listError } = await supabase
      .from('lead_lists')
      .select('*')
      .eq('id', listId)
      .single();

    if (listError) throw listError;

    // 2. Update status to processing
    await supabase
      .from('lead_lists')
      .update({ status: 'processing' })
      .eq('id', listId);

    // 3. Download and parse file
    const { data: fileData, error: fileError } = await supabase.storage
      .from('lead-lists')
      .download(list.file_path);

    if (fileError) throw fileError;

    // 4. Parse CSV/Excel (simplified - use actual parser)
    const text = await fileData.text();
    const rows = parseCSV(text); // Implement CSV parsing
    
    // 5. Process each row
    let stats = { dialer: 0, email: 0, research: 0, rejected: 0 };
    
    for (const row of rows) {
      const lead = normalizeRow(row);
      const route = classifyLead(lead);
      
      // Insert lead
      await supabase.from('leads').insert({
        ...lead,
        list_id: listId,
        route,
        status: 'new'
      });

      stats[route]++;
    }

    // 6. Update list with stats
    await supabase
      .from('lead_lists')
      .update({
        status: 'completed',
        total_rows: rows.length,
        dialer_count: stats.dialer,
        email_count: stats.email,
        research_count: stats.research,
        rejected_count: stats.rejected,
        import_quality_score: calculateQuality(stats)
      })
      .eq('id', listId);

    return new Response(
      JSON.stringify({ success: true, stats }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    return new Response(
      JSON.stringify({ error: error.message }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});

function normalizeRow(row: any) {
  return {
    full_name: row.name || row.full_name || row['Full Name'] || null,
    business_name: row.business || row.company || row['Business Name'] || null,
    email: normalizeEmail(row.email || row['Email'] || row['E-mail']),
    phone: normalizePhone(row.phone || row['Phone'] || row['Phone Number']),
    // ... more fields
  };
}

function classifyLead(lead: any): string {
  if (!lead.phone && !lead.email) return 'research';
  if (!lead.phone) return 'email';
  return 'dialer';
}

function normalizePhone(phone: string | null): string | null {
  if (!phone) return null;
  return phone.replace(/\D/g, '').slice(-10);
}

function normalizeEmail(email: string | null): string | null {
  if (!email) return null;
  const trimmed = email.toLowerCase().trim();
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(trimmed) ? trimmed : null;
}

function calculateQuality(stats: { dialer: number; email: number; research: number; rejected: number; }) {
  const total = stats.dialer + stats.email + stats.research + stats.rejected;
  if (total === 0) return 0;
  return Math.round(((stats.dialer + stats.email + stats.research) / total) * 100);
}
```

---

## 4. RESEARCH QUEUE MODULE

### 4.1 Implementation Steps

1. **Create Research Queue Page**

```typescript
// src/pages/ResearchQueue.tsx
import { useState } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { ResearchQueueLead } from '@/components/lead-engine/ResearchQueueLead';
import { ResearchProfileDrawer } from '@/components/lead-engine/ResearchProfileDrawer';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { Button } from '@/components/ui/button';

export default function ResearchQueue() {
  const { user } = useAuth();
  const [currentLead, setCurrentLead] = useState<any>(null);
  const [showProfile, setShowProfile] = useState(false);

  const claimNextLead = async () => {
    const { data, error } = await supabase
      .rpc('claim_next_research_lead', { p_worker_id: user?.id });
    
    if (error || !data) {
      toast.error('No leads available');
      return;
    }
    
    setCurrentLead(data);
  };

  const handleRunAI = async () => {
    if (!currentLead) return;
    
    const { data, error } = await supabase.functions
      .invoke('wolf-research-intel', {
        body: { lead_id: currentLead.id }
      });
    
    if (error) {
      toast.error('AI research failed');
      return;
    }
    
    // Update local state with AI results
    setCurrentLead({ ...currentLead, ...data });
    setShowProfile(true);
  };

  const handleSaveAndRoute = async (route: 'dialer' | 'email') => {
    await supabase
      .from('leads')
      .update({
        route,
        research_status: 'completed',
        research_completed_at: new Date().toISOString()
      })
      .eq('id', currentLead.id);
    
    toast.success(`Lead sent to ${route} queue`);
    setCurrentLead(null);
    claimNextLead();
  };

  return (
    <div className="container mx-auto p-6">
      <h1 className="text-2xl font-bold mb-6">Research Queue</h1>
      
      {!currentLead ? (
        <Button onClick={claimNextLead} size="lg">
          🔍 Claim Next Lead
        </Button>
      ) : (
        <ResearchQueueLead
          lead={currentLead}
          onRunAI={handleRunAI}
          onSaveAndRoute={handleSaveAndRoute}
          onSkip={() => setCurrentLead(null)}
        />
      )}
      
      <ResearchProfileDrawer
        open={showProfile}
        onClose={() => setShowProfile(false)}
        lead={currentLead}
      />
    </div>
  );
}
```

2. **Create Research Queue Lead Component**

```typescript
// src/components/lead-engine/ResearchQueueLead.tsx
import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { ExternalLink } from 'lucide-react';

interface ResearchQueueLeadProps {
  lead: any;
  onRunAI: () => void;
  onSaveAndRoute: (route: 'dialer' | 'email') => void;
  onSkip: () => void;
}

export function ResearchQueueLead({ lead, onRunAI, onSaveAndRoute, onSkip }: ResearchQueueLeadProps) {
  const [formData, setFormData] = useState({
    full_name: lead.full_name || '',
    phone: lead.phone || '',
    email: lead.email || '',
    website: lead.website || '',
  });

  const quickLinks = [
    {
      label: 'Google',
      url: `https://www.google.com/search?q=${encodeURIComponent(lead.business_name || lead.full_name)}`
    },
    {
      label: 'LinkedIn',
      url: `https://www.linkedin.com/search/results/companies/?keywords=${encodeURIComponent(lead.business_name)}`
    },
    {
      label: 'Maps',
      url: `https://www.google.com/maps/search/${encodeURIComponent(lead.business_name + ' ' + (lead.city || ''))}`
    }
  ];

  return (
    <Card>
      <CardHeader>
        <CardTitle>Research: {lead.business_name || 'Unknown Business'}</CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Known Data */}
        <div className="bg-muted p-4 rounded-lg">
          <h4 className="font-medium mb-2">Known Information</h4>
          <p>Business: {lead.business_name || 'Unknown'}</p>
          <p>Address: {lead.address || 'Unknown'}, {lead.city}, {lead.state}</p>
          {lead.license_id && <p>License: {lead.license_id}</p>}
        </div>

        {/* Quick Links */}
        <div className="flex gap-2">
          {quickLinks.map(link => (
            <Button
              key={link.label}
              variant="outline"
              size="sm"
              onClick={() => window.open(link.url, '_blank')}
            >
              {link.label} <ExternalLink className="ml-1 h-3 w-3" />
            </Button>
          ))}
        </div>

        {/* Enrichment Form */}
        <div className="grid grid-cols-2 gap-4">
          <div>
            <Label>Owner Name</Label>
            <Input
              value={formData.full_name}
              onChange={(e) => setFormData({ ...formData, full_name: e.target.value })}
            />
          </div>
          <div>
            <Label>Phone</Label>
            <Input
              value={formData.phone}
              onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
            />
          </div>
          <div>
            <Label>Email</Label>
            <Input
              value={formData.email}
              onChange={(e) => setFormData({ ...formData, email: e.target.value })}
            />
          </div>
          <div>
            <Label>Website</Label>
            <Input
              value={formData.website}
              onChange={(e) => setFormData({ ...formData, website: e.target.value })}
            />
          </div>
        </div>

        {/* AI Button */}
        <Button onClick={onRunAI} className="w-full">
          🤖 Run AI Research
        </Button>

        {/* Action Buttons */}
        <div className="flex gap-2">
          <Button
            onClick={() => onSaveAndRoute('dialer')}
            disabled={!formData.phone}
            className="flex-1"
          >
            ✅ Send to Dialer
          </Button>
          <Button
            onClick={() => onSaveAndRoute('email')}
            disabled={!formData.email}
            variant="secondary"
            className="flex-1"
          >
            📧 Send to Email
          </Button>
          <Button onClick={onSkip} variant="outline">
            ❌ Cannot Find
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
```

---

## 5. DIALER V3 MODULE

### 5.1 Implementation Steps

1. **Create Dialer Session Hook**

```typescript
// src/hooks/useDialerSession.ts
import { useState, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from './useAuth';

export function useDialerSession() {
  const { user } = useAuth();
  const [session, setSession] = useState<any>(null);
  const [currentLead, setCurrentLead] = useState<any>(null);
  const [loading, setLoading] = useState(false);

  const startSession = useCallback(async () => {
    if (!user) return;
    
    setLoading(true);
    
    // End any existing sessions
    await supabase
      .from('call_sessions')
      .update({ is_active: false, ended_at: new Date().toISOString() })
      .eq('worker_id', user.id)
      .eq('is_active', true);

    // Start new session
    const { data, error } = await supabase
      .from('call_sessions')
      .insert({ worker_id: user.id, is_active: true })
      .select()
      .single();

    if (!error) {
      setSession(data);
      await loadNextLead();
    }
    
    setLoading(false);
  }, [user]);

  const stopSession = useCallback(async () => {
    if (!session) return;
    
    await supabase
      .from('call_sessions')
      .update({ is_active: false, ended_at: new Date().toISOString() })
      .eq('id', session.id);
    
    setSession(null);
    setCurrentLead(null);
  }, [session]);

  const loadNextLead = useCallback(async () => {
    if (!user) return;
    
    setLoading(true);
    
    const { data, error } = await supabase
      .rpc('get_next_lead_for_worker', { p_worker_id: user.id });

    setCurrentLead(data);
    setLoading(false);
    
    return data;
  }, [user]);

  const markOutcome = useCallback(async (
    outcome: string,
    nextAction: string,
    callbackAt?: string
  ) => {
    if (!currentLead || !user) return;
    
    await supabase.rpc('mark_call_outcome', {
      p_lead_id: currentLead.id,
      p_worker_id: user.id,
      p_outcome: outcome,
      p_next_action: nextAction,
      p_callback_at: callbackAt
    });

    // Auto-advance for certain outcomes
    if (['no_answer', 'voicemail', 'wrong_number'].includes(outcome)) {
      await loadNextLead();
    }
  }, [currentLead, user, loadNextLead]);

  return {
    session,
    currentLead,
    loading,
    startSession,
    stopSession,
    loadNextLead,
    markOutcome
  };
}
```

2. **Create Dialer Main Component**

```typescript
// src/pages/DialerV3.tsx
import { useDialerSession } from '@/hooks/useDialerSession';
import { CurrentLeadCard } from '@/components/dialer/CurrentLeadCard';
import { DialerSessionControls } from '@/components/dialer/DialerSessionControls';
import { AIInsightsPanel } from '@/components/dialer/AIInsightsPanel';
import { CallOutcomeButtons } from '@/components/dialer/CallOutcomeButtons';
import { Button } from '@/components/ui/button';
import { Spinner } from '@/components/ui/spinner';

export default function DialerV3() {
  const {
    session,
    currentLead,
    loading,
    startSession,
    stopSession,
    loadNextLead,
    markOutcome
  } = useDialerSession();

  return (
    <div className="container mx-auto p-6">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">Wolf Dialer V3</h1>
        <DialerSessionControls
          session={session}
          onStart={startSession}
          onStop={stopSession}
        />
      </div>

      {!session ? (
        <div className="text-center py-12">
          <p className="text-muted-foreground mb-4">
            Start a session to begin calling leads
          </p>
          <Button onClick={startSession} size="lg">
            🔴 Start Calling
          </Button>
        </div>
      ) : loading ? (
        <div className="text-center py-12">
          <Spinner />
          <p>Loading next lead...</p>
        </div>
      ) : currentLead ? (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
            <CurrentLeadCard lead={currentLead} />
            <CallOutcomeButtons
              onOutcome={(outcome, nextAction, callback) => {
                markOutcome(outcome, nextAction, callback);
              }}
            />
          </div>
          <div>
            <AIInsightsPanel lead={currentLead} />
          </div>
        </div>
      ) : (
        <div className="text-center py-12">
          <p>No leads available in queue</p>
        </div>
      )}
    </div>
  );
}
```

3. **Create Call Outcome Buttons**

```typescript
// src/components/dialer/CallOutcomeButtons.tsx
import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Calendar } from '@/components/ui/calendar';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';

interface CallOutcomeButtonsProps {
  onOutcome: (outcome: string, nextAction: string, callbackAt?: string) => void;
}

export function CallOutcomeButtons({ onOutcome }: CallOutcomeButtonsProps) {
  const [showCallback, setShowCallback] = useState(false);

  const outcomes = [
    { label: '✅ Connected', outcome: 'connected', action: 'show_options', variant: 'default' },
    { label: '📞 Callback', outcome: 'callback', action: 'schedule_callback', variant: 'secondary' },
    { label: '📭 Voicemail', outcome: 'voicemail', action: 'next', variant: 'outline' },
    { label: '❌ No Answer', outcome: 'no_answer', action: 'next', variant: 'outline' },
    { label: '🚫 Not Interested', outcome: 'not_interested', action: 'mark_dead', variant: 'destructive' },
    { label: '☎️ Wrong Number', outcome: 'wrong_number', action: 'mark_dead', variant: 'destructive' },
  ];

  return (
    <div>
      <div className="grid grid-cols-3 gap-2">
        {outcomes.map((item) => (
          <Button
            key={item.outcome}
            variant={item.variant as any}
            onClick={() => {
              if (item.action === 'schedule_callback') {
                setShowCallback(true);
              } else {
                onOutcome(item.outcome, item.action);
              }
            }}
          >
            {item.label}
          </Button>
        ))}
      </div>

      {/* Callback scheduler */}
      <Dialog open={showCallback} onOpenChange={setShowCallback}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Schedule Callback</DialogTitle>
          </DialogHeader>
          <Calendar
            mode="single"
            onSelect={(date) => {
              if (date) {
                onOutcome('callback', 'schedule_callback', date.toISOString());
                setShowCallback(false);
              }
            }}
          />
        </DialogContent>
      </Dialog>
    </div>
  );
}
```

---

## 6. UNDERWRITING MODULE

### 6.1 Implementation Steps

1. **Create Underwriting Case View**

```typescript
// src/components/underwriting/UnderwritingCase.tsx
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Checkbox } from '@/components/ui/checkbox';
import { Button } from '@/components/ui/button';
import { MetricCard } from '@/components/ui/metric-card';

interface UnderwritingCaseProps {
  applicationId: string;
  applicationType: string;
}

export function UnderwritingCase({ applicationId, applicationType }: UnderwritingCaseProps) {
  const { data: caseData, isLoading, refetch } = useQuery({
    queryKey: ['underwriting-case', applicationId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('underwriting_cases')
        .select('*')
        .eq('application_id', applicationId)
        .single();
      
      if (error && error.code !== 'PGRST116') throw error;
      return data;
    }
  });

  const runAnalysis = async () => {
    const { data, error } = await supabase.functions
      .invoke('underwriter-analyze-application', {
        body: { applicationId, applicationType }
      });
    
    if (error) {
      toast.error('Analysis failed');
      return;
    }
    
    toast.success('Analysis complete');
    refetch();
  };

  return (
    <div className="space-y-6">
      {/* Fundability Badge */}
      {caseData?.fundability_status && (
        <div className={`p-4 rounded-lg ${
          caseData.fundability_status === 'fundable' ? 'bg-green-500/10 border-green-500' :
          caseData.fundability_status === 'conditional' ? 'bg-yellow-500/10 border-yellow-500' :
          'bg-red-500/10 border-red-500'
        } border`}>
          <h3 className="font-bold text-lg">
            {caseData.fundability_status === 'fundable' ? '🟢 FUNDABLE' :
             caseData.fundability_status === 'conditional' ? '🟡 CONDITIONAL' :
             '🔴 NOT FUNDABLE'}
          </h3>
          <p>Risk Level: {caseData.risk_level}</p>
        </div>
      )}

      {/* Banking Metrics */}
      {caseData && (
        <Card>
          <CardHeader>
            <CardTitle>Banking Metrics</CardTitle>
          </CardHeader>
          <CardContent className="grid grid-cols-3 gap-4">
            <MetricCard label="Avg Revenue" value={`$${caseData.avg_monthly_revenue?.toLocaleString()}`} />
            <MetricCard label="Avg Balance" value={`$${caseData.avg_daily_balance?.toLocaleString()}`} />
            <MetricCard label="NSF Count" value={caseData.nsf_count} />
            <MetricCard label="Negative Days" value={caseData.negative_days} />
            <MetricCard label="Months Analyzed" value={caseData.months_analyzed} />
          </CardContent>
        </Card>
      )}

      {/* Existing Funding */}
      {caseData?.existing_funding_detected && (
        <Card>
          <CardHeader>
            <CardTitle>⚠️ Existing Funding Detected</CardTitle>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Lender</TableHead>
                  <TableHead>Daily Payment</TableHead>
                  <TableHead>Est. Balance</TableHead>
                  <TableHead>Verified</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {caseData.existing_positions?.map((pos: any, i: number) => (
                  <TableRow key={i}>
                    <TableCell>{pos.lender}</TableCell>
                    <TableCell>${pos.dailyPayment}</TableCell>
                    <TableCell>${pos.estimatedBalance?.toLocaleString()}</TableCell>
                    <TableCell>
                      <Checkbox checked={pos.verified} />
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      )}

      {/* Actions */}
      <div className="flex gap-2">
        <Button onClick={runAnalysis}>
          🤖 {caseData ? 'Re-Run Analysis' : 'Run AI Analysis'}
        </Button>
        <Button variant="outline">📄 Request Docs</Button>
        <Button variant="outline">📤 Send to Funders</Button>
        <Button variant="outline">📋 Download PDF</Button>
      </div>
    </div>
  );
}
```

2. **Create Underwriting Analysis Edge Function**

```typescript
// supabase/functions/underwriter-analyze-application/index.ts
import { serve } from 'https://deno.land/std@0.168.0/http/server.ts';
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
import { toast } from 'sonner';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
    );

    const { applicationId, applicationType } = await req.json();

    // 1. Get application data
    const { data: application, error: appError } = await supabase
      .from(applicationType === 'fast_track' ? 'fast_track_applications' : 'loan_applications')
      .select('*')
      .eq('id', applicationId)
      .single();

    if (appError) throw appError;

    // 2. Get bank statement extractions
    const { data: extractions } = await supabase
      .from('document_extractions')
      .select('*')
      .eq('application_id', applicationId)
      .eq('document_type', 'bank_statement');

    // 3. Prepare prompt for AI
    const prompt = buildUnderwritingPrompt(application, extractions);

    // 4. Call AI for analysis
    const aiResponse = await fetch('https://wolf-fund.com/api/v1/ai/chat', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${Deno.env.get('AI_GATEWAY_API_KEY')}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'google/gemini-2.5-flash',
        messages: [
          { role: 'system', content: 'You are an MCA underwriting analyst. Analyze the data and return JSON.' },
          { role: 'user', content: prompt }
        ],
        response_format: { type: 'json_object' }
      }),
    });

    const aiResult = await aiResponse.json();
    const analysis = JSON.parse(aiResult.choices[0].message.content);

    // 5. Create or update underwriting case
    const { data: caseData, error: caseError } = await supabase
      .from('underwriting_cases')
      .upsert({
        application_id: applicationId,
        application_type: applicationType,
        ...analysis,
        analyzed_at: new Date().toISOString()
      }, {
        onConflict: 'application_id'
      })
      .select()
      .single();

    if (caseError) throw caseError;

    // 6. Log AI event
    await supabase.from('ai_events').insert({
      entity_type: 'application',
      entity_id: applicationId,
      event_type: 'underwriting_analysis',
      model_name: 'gemini-2.5-flash',
      payload_in: { applicationId, applicationType },
      payload_out: analysis
    });

    return new Response(
      JSON.stringify({ success: true, case: caseData }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    return new Response(
      JSON.stringify({ error: error.message }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});

function buildUnderwritingPrompt(application: any, extractions: any[]) {
  return `
Analyze this MCA funding application and return JSON with the following structure:

Application Data:
- Business: ${application.business_name}
- Requested Amount: ${application.requested_amount || 'Not specified'}
- Credit Score: ${application.credit_score || 'Not provided'}
- Time in Business: ${application.in_business_over_6_months ? '6+ months' : 'Under 6 months'}
- Previous MCA: ${application.has_previous_loan ? 'Yes' : 'No'}

Bank Statement Data:
${JSON.stringify(extractions, null, 2)}

Return JSON:
{
  "fundability_status": "fundable" | "conditional" | "not_fundable",
  "risk_level": "low" | "medium" | "high" | "borderline",
  "avg_monthly_revenue": number,
  "avg_daily_balance": number,
  "lowest_balance": number,
  "nsf_count": number,
  "negative_days": number,
  "months_analyzed": number,
  "existing_funding_detected": boolean,
  "existing_positions": [{ "lender": string, "dailyPayment": number, "estimatedBalance": number, "verified": boolean }],
  "total_existing_balance": number,
  "risk_flags": string[],
  "ai_internal_notes": string,
  "ai_funder_summary": string,
  "ai_recommendations": string
}
`;
}
```

---

## 7. CREDIT FIX STUDIO MODULE

See `WOLF_UI_WIREFRAMES.md` Section 8 for component structure.

Key files to create:
- `src/pages/CreditSpecialistDashboard.tsx`
- `src/components/credit-lab/CreditCasesList.tsx`
- `src/components/credit-lab/CreditCaseWorkspace.tsx`
- `src/components/credit-lab/CreditAiPanel.tsx`
- `src/components/credit-repair/DisputeDraftsSection.tsx`
- `src/components/credit-repair/ComplianceAssistantPanel.tsx`

---

## 8. ISO PARTNER MODULE

Key files to create:
- `src/pages/ISOPartnerDashboard.tsx`
- `src/components/iso/ISOLeadSubmission.tsx`
- `src/components/iso/ISOCommissionTable.tsx`
- `src/components/iso/ISOPerformanceStats.tsx`

---

## 9. ADMIN DASHBOARD MODULE

Key files to create:
- `src/pages/Admin.tsx`
- `src/components/admin/AdminActivityFeed.tsx`
- `src/components/admin/UserManagementTable.tsx`
- `src/components/admin/FunderManagement.tsx`
- `src/components/admin/PerformanceDashboard.tsx`

---

## 10. AI INTEGRATION GUIDE

### 10.1 AI Gateway AI Gateway

```typescript
// Standard AI call pattern
async function callAI(prompt: string, systemPrompt: string) {
  const response = await fetch('https://wolf-fund.com/api/v1/ai/chat', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${Deno.env.get('AI_GATEWAY_API_KEY')}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      model: 'google/gemini-2.5-flash', // or gemini-2.5-pro for complex tasks
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: prompt }
      ],
      response_format: { type: 'json_object' }
    }),
  });

  const result = await response.json();
  return JSON.parse(result.choices[0].message.content);
}

// Vision AI for documents
async function analyzeDocument(imageBase64: string, prompt: string) {
  const response = await fetch('https://wolf-fund.com/api/v1/ai/chat', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${Deno.env.get('AI_GATEWAY_API_KEY')}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      model: 'google/gemini-2.5-flash',
      messages: [
        {
          role: 'user',
          content: [
            { type: 'text', text: prompt },
            { type: 'image_url', image_url: { url: `data:image/png;base64,${imageBase64}` } }
          ]
        }
      ],
      response_format: { type: 'json_object' }
    }),
  });

  const result = await response.json();
  return JSON.parse(result.choices[0].message.content);
}
```

### 10.2 Model Selection Guide

| Use Case | Recommended Model |
|----------|-------------------|
| Lead scoring | gemini-2.5-flash |
| Document OCR | gemini-2.5-flash (vision) |
| Complex analysis | gemini-2.5-pro |
| Chat assistant | gemini-2.5-flash |
| Dispute letter generation | gemini-2.5-flash |
| Deep research | gemini-2.5-pro |

---

## 11. REAL-TIME FEATURES

### 11.1 Enable Realtime for Tables

```sql
-- Run in Supabase SQL editor
ALTER PUBLICATION supabase_realtime ADD TABLE public.leads;
ALTER PUBLICATION supabase_realtime ADD TABLE public.activity_feed;
ALTER PUBLICATION supabase_realtime ADD TABLE public.lead_release_requests;
```

### 11.2 Subscribe to Changes

```typescript
// src/hooks/useRealtimeLeads.ts
import { useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';

export function useRealtimeLeads(onUpdate: (payload: any) => void) {
  useEffect(() => {
    const channel = supabase
      .channel('leads-changes')
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'leads' },
        (payload) => {
          onUpdate(payload);
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [onUpdate]);
}
```

---

## 12. TESTING STRATEGY

### 12.1 Unit Tests

```typescript
// tests/utils/normalizePhone.test.ts
import { normalizePhone } from '@/lib/utils';

describe('normalizePhone', () => {
  it('should remove non-digits', () => {
    expect(normalizePhone('(555) 123-4567')).toBe('5551234567');
  });

  it('should handle null', () => {
    expect(normalizePhone(null)).toBeNull();
  });
});
```

### 12.2 Integration Tests (Playwright)

```typescript
// tests/e2e/dialer.spec.ts
import { test, expect } from '@playwright/test';

test('dialer session flow', async ({ page }) => {
  // Login
  await page.goto('/auth');
  await page.fill('[name="email"]', 'worker@test.com');
  await page.fill('[name="password"]', 'password123');
  await page.click('button[type="submit"]');
  
  // Navigate to dialer
  await page.goto('/dialer');
  
  // Start session
  await page.click('text=Start Calling');
  
  // Verify lead loaded
  await expect(page.locator('.lead-card')).toBeVisible();
  
  // Mark outcome
  await page.click('text=No Answer');
  
  // Verify next lead loaded
  await expect(page.locator('.lead-card')).toBeVisible();
});
```

---

*Document Version: 1.0*
*Last Updated: December 2, 2024*
*Wolf Ecosystem V1 Specification*
