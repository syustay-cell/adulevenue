// Credit Repair Engine - Strategy-aware dispute processing
import { supabase } from "@/integrations/supabase/client";
import { getSystemModeState, type SystemModeState } from "./systemMode";
import { getStrategyConfigFromState, canAutoExecuteFromState, type StrategyConfig } from "./systemMode/strategyConfig";
import { logActivityEvent } from "./activity";

export interface DisputeItem {
  id: string;
  bureau: string;
  creditor_name?: string | null;
  account_type?: string | null;
  dispute_reason?: string | null;
}

export interface CreditRepairCycleResult {
  clientId: string;
  mode: string;
  disputesProcessed: number;
  capReached: boolean;
  usedThisMonth: number;
  maxPerMonth: number;
}

/**
 * Count how many disputes this client has had this month
 */
async function countClientDisputesThisMonth(clientId: string): Promise<number> {
  const startOfMonth = new Date();
  startOfMonth.setDate(1);
  startOfMonth.setHours(0, 0, 0, 0);

  const { count } = await supabase
    .from('credit_dispute_drafts_v2')
    .select('*', { count: 'exact', head: true })
    .eq('case_id', clientId)
    .gte('created_at', startOfMonth.toISOString());

  return count || 0;
}

/**
 * Get next dispute items based on pace
 * LOW: 1-2 items per cycle
 * MEDIUM: 3-5 items per cycle
 * HIGH: 5-8 items per cycle
 */
async function getNextDisputeItems(
  clientId: string, 
  pace: 'LOW' | 'MEDIUM' | 'HIGH'
): Promise<DisputeItem[]> {
  const limits = {
    LOW: 2,
    MEDIUM: 5,
    HIGH: 8,
  };

  const { data } = await supabase
    .from('credit_dispute_items_v2')
    .select('id, bureau, creditor_name, account_type, dispute_reason')
    .eq('case_id', clientId)
    .eq('dispute_status', 'pending')
    .limit(limits[pace]);

  return (data || []) as DisputeItem[];
}

/**
 * Simulate sending a dispute letter (in production, would call edge function)
 */
async function sendDisputeLetter(clientId: string, item: DisputeItem): Promise<boolean> {
  // In production, this would:
  // 1. Generate letter via AI
  // 2. Create draft in credit_dispute_drafts_v2
  // 3. Send via email/mail service
  
  // For now, we just create a draft record
  const { error } = await supabase
    .from('credit_dispute_drafts_v2')
    .insert({
      case_id: clientId,
      tenant_id: 'default', // Would come from context
      bureau: item.bureau,
      letter_type: 'dispute',
      body: `Dispute letter for ${item.creditor_name || 'account'} - ${item.dispute_reason || 'Verification requested'}`,
      status: 'sent',
      sent_at: new Date().toISOString(),
      items_included: [item.id],
    } as any);

  return !error;
}

/**
 * Run credit repair dispute cycle - strategy-aware
 * ECO: Lower pace, fewer disputes per month
 * STANDARD: Normal pace and limits
 * AGGRESSIVE: Higher pace, more disputes per month
 * MANUAL: Only proposes, doesn't send
 */
export async function runCreditRepairDisputeCycle(clientId: string): Promise<CreditRepairCycleResult> {
  const modeState = await getSystemModeState();
  const strategy = getStrategyConfigFromState(modeState);
  const allowAuto = canAutoExecuteFromState(modeState);
  const modeLabel = `${modeState.executionMode} · ${modeState.strategyProfile}`;

  const usedThisMonth = await countClientDisputesThisMonth(clientId);

  // Check monthly cap
  if (usedThisMonth >= strategy.maxDisputesPerClientPerMonth) {
    await logActivityEvent({
      actorType: 'SYSTEM',
      scope: 'CREDIT_REPAIR',
      eventType: 'DECISION',
      decision: 'INFO',
      severity: 'LOW',
      summary: `Dispute cap reached for client ${clientId.slice(0, 8)} – ${strategy.maxDisputesPerClientPerMonth}/month`,
      details: { clientId, usedThisMonth, maxPerMonth: strategy.maxDisputesPerClientPerMonth },
    });
    return {
      clientId,
      mode: modeLabel,
      disputesProcessed: 0,
      capReached: true,
      usedThisMonth,
      maxPerMonth: strategy.maxDisputesPerClientPerMonth,
    };
  }

  const items = await getNextDisputeItems(clientId, strategy.disputePace);

  if (!allowAuto) {
    // Manual mode – just propose
    await logActivityEvent({
      actorType: 'AI',
      scope: 'CREDIT_REPAIR',
      eventType: 'DECISION',
      decision: 'INFO',
      severity: 'LOW',
      summary: `AI prepared ${items.length} disputes (Manual mode – awaiting approval)`,
      details: { clientId, items: items.map(i => i.id), mode: 'MANUAL' },
    });
    return {
      clientId,
      mode: modeLabel,
      disputesProcessed: 0,
      capReached: false,
      usedThisMonth,
      maxPerMonth: strategy.maxDisputesPerClientPerMonth,
    };
  }

  let processed = 0;
  for (const item of items) {
    const sent = await sendDisputeLetter(clientId, item);
    if (sent) {
      processed++;
      
      await logActivityEvent({
        actorType: 'AI',
        scope: 'CREDIT_REPAIR',
        eventType: 'ACTION',
        decision: 'AUTO_ACTION',
        severity: 'MEDIUM',
        summary: `Autopilot generated & sent dispute for ${item.creditor_name || 'account'} (${item.bureau})`,
        details: { 
          clientId, 
          itemId: item.id, 
          bureau: item.bureau,
          pace: strategy.disputePace,
          mode: modeLabel,
        },
      });
    }
  }

  return {
    clientId,
    mode: modeLabel,
    disputesProcessed: processed,
    capReached: false,
    usedThisMonth: usedThisMonth + processed,
    maxPerMonth: strategy.maxDisputesPerClientPerMonth,
  };
}

/**
 * Get credit repair statistics for display
 */
export async function getCreditRepairStats(clientId: string): Promise<{
  usedThisMonth: number;
  maxPerMonth: number;
  remaining: number;
  pace: string;
}> {
  const modeState = await getSystemModeState();
  const strategy = getStrategyConfigFromState(modeState);
  const usedThisMonth = await countClientDisputesThisMonth(clientId);

  return {
    usedThisMonth,
    maxPerMonth: strategy.maxDisputesPerClientPerMonth,
    remaining: Math.max(0, strategy.maxDisputesPerClientPerMonth - usedThisMonth),
    pace: strategy.disputePace,
  };
}
