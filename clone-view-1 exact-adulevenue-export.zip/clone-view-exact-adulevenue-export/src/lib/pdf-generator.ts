import jsPDF from 'jspdf';

export const generateDisputeLetterPDF = async (draft: any) => {
  const doc = new jsPDF('p', 'mm', 'a4');
  const pageWidth = doc.internal.pageSize.getWidth();
  const pageHeight = doc.internal.pageSize.getHeight();
  const margin = 20;
  let yPos = margin;

  // Premium Wolf Fund Corp Letterhead with Gold Accent
  doc.setFillColor(34, 40, 49); // Dark navy background
  doc.rect(0, 0, pageWidth, 40, 'F');
  
  // Gold accent bar
  doc.setFillColor(255, 196, 54); // Wolf Fund gold
  doc.rect(0, 38, pageWidth, 2, 'F');
  
  doc.setTextColor(255, 255, 255);
  doc.setFontSize(24);
  doc.setFont('helvetica', 'bold');
  doc.text('WOLF FUND CORP™', margin, 18);
  
  doc.setFontSize(11);
  doc.setFont('helvetica', 'normal');
  doc.text('Credit Fix Back Office™', margin, 26);
  
  doc.setFontSize(9);
  doc.setTextColor(200, 200, 200);
  doc.text('123 Main Ave, Suite 200, Huntington NY 11746', margin, 32);
  doc.text('Phone: (646) 826-9799  |  compliance@wolf-fund.com  |  www.wolf-fund.com', margin, 36);
  
  doc.setTextColor(0, 0, 0);
  yPos = 55;

  // Date and Reference
  doc.setFontSize(10);
  doc.text(`Date: ${new Date().toLocaleDateString()}`, margin, yPos);
  yPos += 7;
  doc.text(`Reference: WF-CFB-${draft.id.slice(0, 8)}`, margin, yPos);
  yPos += 12;

  // Recipient
  doc.setFont('helvetica', 'bold');
  doc.text(`To: ${draft.target_name}`, margin, yPos);
  yPos += 7;
  doc.setFont('helvetica', 'normal');
  doc.text(`${draft.target.charAt(0).toUpperCase() + draft.target.slice(1)} Department`, margin, yPos);
  yPos += 15;

  // Subject
  doc.setFont('helvetica', 'bold');
  doc.text(`Re: ${draft.subject}`, margin, yPos);
  yPos += 12;

  // Body
  doc.setFont('helvetica', 'normal');
  const bodyLines = doc.splitTextToSize(draft.body, pageWidth - (margin * 2));
  bodyLines.forEach((line: string) => {
    if (yPos > 270) {
      doc.addPage();
      yPos = margin;
    }
    doc.text(line, margin, yPos);
    yPos += 5;
  });

  // Signature Block with script-style formatting
  yPos += 20;
  if (yPos > 240) {
    doc.addPage();
    yPos = margin;
  }
  
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(11);
  doc.text('Respectfully,', margin, yPos);
  yPos += 15;
  
  // If signature text exists, display it in script-like style
  if (draft.signature) {
    doc.setFont('times', 'italic');
    doc.setFontSize(14);
    const signatureLines = doc.splitTextToSize(draft.signature, pageWidth - (margin * 2));
    signatureLines.forEach((line: string) => {
      doc.text(line, margin, yPos);
      yPos += 6;
    });
  } else {
    doc.text('_________________________________', margin, yPos);
    yPos += 7;
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(10);
    doc.text('Authorized Representative', margin, yPos);
  }
  
  yPos += 8;
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(10);
  doc.text('Wolf Fund Corp™ – Credit Fix Back Office™', margin, yPos);

  // Professional Footer with Gold Accent
  const totalPages = doc.getNumberOfPages();
  for (let i = 1; i <= totalPages; i++) {
    doc.setPage(i);
    
    // Gold footer line
    doc.setDrawColor(255, 196, 54);
    doc.setLineWidth(0.5);
    doc.line(margin, pageHeight - 15, pageWidth - margin, pageHeight - 15);
    
    doc.setFontSize(7);
    doc.setTextColor(80, 80, 80);
    doc.setFont('helvetica', 'normal');
    doc.text(
      'Wolf Fund Corp™ – Credit Fix Back Office™  |  Confidential Business Communication',
      pageWidth / 2,
      pageHeight - 10,
      { align: 'center' }
    );
    doc.text(
      `Document Reference: WF-CFB-${draft.id.slice(0, 8)}  |  Page ${i} of ${totalPages}`,
      pageWidth / 2,
      pageHeight - 6,
      { align: 'center' }
    );
  }

  const fileName = `Dispute_Letter_${draft.target_name.replace(/\s+/g, '_')}_${Date.now()}.pdf`;
  doc.save(fileName);
  return fileName;
};

export const generateUnderwritingPDF = async (data: any) => {
  const doc = new jsPDF('p', 'mm', 'a4');
  const pageWidth = doc.internal.pageSize.getWidth();
  const pageHeight = doc.internal.pageSize.getHeight();
  const margin = 15;
  let yPos = margin;

  // Helper function to add text with word wrap
  const addText = (text: string, fontSize: number = 10, isBold: boolean = false) => {
    doc.setFontSize(fontSize);
    doc.setFont('helvetica', isBold ? 'bold' : 'normal');
    const lines = doc.splitTextToSize(text, pageWidth - (margin * 2));
    
    if (yPos + (lines.length * fontSize * 0.35) > pageHeight - margin) {
      doc.addPage();
      yPos = margin;
    }
    
    doc.text(lines, margin, yPos);
    yPos += lines.length * fontSize * 0.35 + 3;
  };

  // Helper function to add section header
  const addSectionHeader = (title: string) => {
    yPos += 5;
    doc.setFillColor(37, 99, 235); // Primary color
    doc.rect(margin, yPos - 5, pageWidth - (margin * 2), 8, 'F');
    doc.setTextColor(255, 255, 255);
    doc.setFontSize(12);
    doc.setFont('helvetica', 'bold');
    doc.text(title, margin + 3, yPos);
    doc.setTextColor(0, 0, 0);
    yPos += 8;
  };

  // Header
  doc.setFillColor(37, 99, 235);
  doc.rect(0, 0, pageWidth, 25, 'F');
  doc.setTextColor(255, 255, 255);
  doc.setFontSize(20);
  doc.setFont('helvetica', 'bold');
  doc.text('WOLF FUND CORP', margin, 12);
  doc.setFontSize(12);
  doc.text('AI Underwriting Report', margin, 19);
  doc.setTextColor(0, 0, 0);
  yPos = 35;

  // Application Details
  addSectionHeader('Application Information');
  addText(`Business Name: ${data.businessName}`, 10, true);
  addText(`Application Type: ${data.applicationType.replace('_', ' ').toUpperCase()}`, 10);
  addText(`Report Generated: ${new Date().toLocaleString()}`, 10);
  addText(`Application Date: ${new Date(data.createdAt).toLocaleString()}`, 10);

  // Fundability Status
  if (data.fundabilityStatus) {
    addSectionHeader('Fundability Assessment');
    const statusColor = data.fundabilityStatus === 'Fundable' ? [34, 197, 94] :
                       data.fundabilityStatus === 'Conditional' ? [234, 179, 8] : [239, 68, 68];
    doc.setFillColor(statusColor[0], statusColor[1], statusColor[2]);
    doc.rect(margin, yPos, pageWidth - (margin * 2), 12, 'F');
    doc.setTextColor(255, 255, 255);
    doc.setFontSize(14);
    doc.setFont('helvetica', 'bold');
    doc.text(`STATUS: ${data.fundabilityStatus.toUpperCase()}`, margin + 3, yPos + 8);
    doc.setTextColor(0, 0, 0);
    yPos += 15;
  }

  // Risk Level
  if (data.riskLevel) {
    addText(`Risk Level: ${data.riskLevel.toUpperCase()}`, 11, true);
  }

  // Banking Metrics
  addSectionHeader('Banking & Financial Metrics');
  
  if (data.metrics.avg_monthly_revenue !== null) {
    addText(`Average Monthly Revenue: $${data.metrics.avg_monthly_revenue.toLocaleString()}`, 10, true);
  }
  
  if (data.metrics.avg_daily_balance !== null) {
    addText(`Average Daily Balance: $${data.metrics.avg_daily_balance.toLocaleString()}`, 10, true);
  }
  
  if (data.metrics.nsf_count !== null) {
    addText(`NSF Count: ${data.metrics.nsf_count}`, 10);
  }
  
  if (data.metrics.negative_days !== null) {
    addText(`Negative Balance Days: ${data.metrics.negative_days}`, 10);
  }

  // Monthly Revenue Breakdown
  if (data.metrics.raw_metrics?.monthly_revenue_breakdown?.length > 0) {
    yPos += 3;
    addText('Monthly Revenue Breakdown:', 10, true);
    data.metrics.raw_metrics.monthly_revenue_breakdown.forEach((item: any) => {
      addText(`  ${item.month}: $${item.total_deposits?.toLocaleString() || '0'}`, 9);
    });
  }

  // Existing Funding
  if (data.metrics.raw_metrics?.funding_deductions?.length > 0) {
    addSectionHeader('Existing Funding Positions Detected');
    addText(`Total Positions: ${data.metrics.raw_metrics.funding_deductions.length}`, 10, true);
    yPos += 2;
    
    data.metrics.raw_metrics.funding_deductions.forEach((deduction: any, idx: number) => {
      addText(`${idx + 1}. ${deduction.label || 'Unknown Lender'}`, 9, true);
      addText(`   Payment: $${deduction.typical_amount || 'N/A'} | Frequency: ${deduction.frequency || 'N/A'}`, 9);
      addText(`   Balance: ~$${deduction.approx_balance?.toLocaleString() || 'Unknown'}`, 9);
      yPos += 1;
    });
  }

  // Red Flags
  if (data.metrics.raw_metrics?.red_flags?.length > 0) {
    addSectionHeader('Risk Flags & Red Flag Analysis');
    data.metrics.raw_metrics.red_flags.forEach((flag: any) => {
      addText(`⚠ ${flag.type.replace(/_/g, ' ').toUpperCase()}`, 10, true);
      addText(`  ${flag.description}`, 9);
      yPos += 1;
    });
  }

  // AI Analysis
  addSectionHeader('AI Underwriting Analysis');
  
  if (data.metrics.recommended_label) {
    addText(`Recommendation: ${data.metrics.recommended_label}`, 10, true);
    yPos += 2;
  }

  if (data.metrics.internal_summary) {
    addText('Internal Summary (Admin Only):', 10, true);
    addText(data.metrics.internal_summary, 9);
    yPos += 3;
  }

  if (data.metrics.funder_safe_summary) {
    addText('Funder-Safe Summary (Shareable):', 10, true);
    addText(data.metrics.funder_safe_summary, 9);
  }

  // Footer on last page
  const totalPages = doc.getNumberOfPages();
  for (let i = 1; i <= totalPages; i++) {
    doc.setPage(i);
    doc.setFontSize(8);
    doc.setTextColor(128, 128, 128);
    doc.text(
      `Wolf Fund Corp - Confidential Report | Page ${i} of ${totalPages}`,
      pageWidth / 2,
      pageHeight - 10,
      { align: 'center' }
    );
  }

  // Save the PDF
  const fileName = `Underwriting_Report_${data.applicationId.slice(0, 8)}_${Date.now()}.pdf`;
  doc.save(fileName);
  
  return fileName;
};
