// Central Strategy Configuration - ONE PLACE TO TUNE ALL MODES
// This is THE source of truth for how each mode (ECO/STANDARD/AGGRESSIVE) behaves
import type { StrategyProfile, SystemModeState } from '../systemMode';
import { isAutopilot } from '../systemMode';

export interface StrategyConfig {
  // Collections
  maxAutoCollectionsPerDay: number;
  autoCollectionsSeverities: ('LOW' | 'MEDIUM' | 'HIGH')[];

  // Renewals
  maxRenewalDraftsPerDay: number;
  autoSendRenewalStatuses: ('draft' | 'sent')[];
  renewalAmountMultiplier: number;
  renewalMaxFactor: number;

  // Leads / Outreach
  maxColdOutreachPerDay: number;
  maxFollowupsPerLead: number;
  outreachAggressiveness: 'LOW' | 'MEDIUM' | 'HIGH';

  // Credit Repair
  maxDisputesPerClientPerMonth: number;
  disputePace: 'LOW' | 'MEDIUM' | 'HIGH';

  // Safety
  hardStopHighRisk: boolean;
}

// DEFAULT CONFIGS BY STRATEGY
export const STRATEGY_CONFIG: Record<StrategyProfile, StrategyConfig> = {
  STANDARD: {
    maxAutoCollectionsPerDay: 200,
    autoCollectionsSeverities: ['LOW', 'MEDIUM'],
    maxRenewalDraftsPerDay: 75,
    autoSendRenewalStatuses: ['sent'],
    renewalAmountMultiplier: 1.0,
    renewalMaxFactor: 1.35,
    maxColdOutreachPerDay: 150,
    maxFollowupsPerLead: 3,
    outreachAggressiveness: 'MEDIUM',
    maxDisputesPerClientPerMonth: 8,
    disputePace: 'MEDIUM',
    hardStopHighRisk: true,
  },

  ECO: {
    maxAutoCollectionsPerDay: 75,
    autoCollectionsSeverities: ['LOW'],
    maxRenewalDraftsPerDay: 25,
    autoSendRenewalStatuses: [], // ECO: do NOT auto-send, only draft
    renewalAmountMultiplier: 0.75,
    renewalMaxFactor: 1.25,
    maxColdOutreachPerDay: 60,
    maxFollowupsPerLead: 2,
    outreachAggressiveness: 'LOW',
    maxDisputesPerClientPerMonth: 5,
    disputePace: 'LOW',
    hardStopHighRisk: true,
  },

  AGGRESSIVE: {
    maxAutoCollectionsPerDay: 400,
    autoCollectionsSeverities: ['LOW', 'MEDIUM', 'HIGH'],
    maxRenewalDraftsPerDay: 200,
    autoSendRenewalStatuses: ['sent'],
    renewalAmountMultiplier: 1.15,
    renewalMaxFactor: 1.45,
    maxColdOutreachPerDay: 400,
    maxFollowupsPerLead: 5,
    outreachAggressiveness: 'HIGH',
    maxDisputesPerClientPerMonth: 12,
    disputePace: 'HIGH',
    hardStopHighRisk: false, // allow more bold moves, rule engine still controls
  },
};

export function getStrategyConfigFromState(state: SystemModeState): StrategyConfig {
  return STRATEGY_CONFIG[state.strategyProfile] ?? STRATEGY_CONFIG.STANDARD;
}

export function getStrategyConfig(profile: StrategyProfile): StrategyConfig {
  return STRATEGY_CONFIG[profile] ?? STRATEGY_CONFIG.STANDARD;
}

// Helper: whether we should allow ANY auto-execution based on state
export function canAutoExecuteFromState(state: SystemModeState): boolean {
  return isAutopilot(state);
}

// Helper: get severity filter for collections based on strategy
export function getAllowedCollectionSeverities(profile: StrategyProfile): string[] {
  return STRATEGY_CONFIG[profile]?.autoCollectionsSeverities ?? ['LOW', 'MEDIUM'];
}

// Helper: check if a severity is allowed for auto-action
export function isSeverityAllowed(profile: StrategyProfile, severity: string): boolean {
  const allowed = STRATEGY_CONFIG[profile]?.autoCollectionsSeverities ?? [];
  return allowed.includes(severity.toUpperCase() as 'LOW' | 'MEDIUM' | 'HIGH');
}
