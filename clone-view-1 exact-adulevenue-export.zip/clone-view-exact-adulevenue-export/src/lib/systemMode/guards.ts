import type { SystemMode } from '../systemMode';
import { getSystemMode } from '../systemMode';

/**
 * Check if the current mode allows executing money movements (ACH, wires, settlements, renewals)
 */
export function canExecuteMoneyMovement(mode: SystemMode): boolean {
  return mode === 'AUTOPILOT';
}

/**
 * Check if the current mode allows modifying risk configuration (rules, caps, factor ranges)
 */
export function canModifyRiskConfig(mode: SystemMode): boolean {
  return mode === 'OPTIMIZATION_PILOT';
}

/**
 * Check if the current mode allows auto-executing actions
 */
export function canAutoExecute(mode: SystemMode): boolean {
  return mode === 'AUTOPILOT';
}

/**
 * Check if the current mode is in simulation/proposal-only mode
 */
export function isProposalOnly(mode: SystemMode): boolean {
  return mode === 'MANUAL' || mode === 'OPTIMIZATION_PILOT';
}

/**
 * Guard wrapper for funding a deal - throws if not in AUTOPILOT
 */
export async function guardFundDeal(dealId: string): Promise<void> {
  const mode = await getSystemMode();
  if (!canExecuteMoneyMovement(mode)) {
    throw new Error(`Cannot fund deal while in ${mode} mode. Switch to AUTOPILOT to execute money movements.`);
  }
}

/**
 * Guard wrapper for updating risk rules - throws if not in OPTIMIZATION_PILOT
 */
export async function guardModifyRiskConfig(): Promise<void> {
  const mode = await getSystemMode();
  if (!canModifyRiskConfig(mode)) {
    throw new Error('Only Optimization Pilot (555) can edit risk rules. Unlock with PIN 555 first.');
  }
}

/**
 * Guard wrapper for auto-executing actions - throws if not in AUTOPILOT
 */
export async function guardAutoExecute(actionDescription: string): Promise<void> {
  const mode = await getSystemMode();
  if (!canAutoExecute(mode)) {
    throw new Error(`Cannot auto-execute "${actionDescription}" while in ${mode} mode.`);
  }
}
