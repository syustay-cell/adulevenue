import type { SystemMode, SystemModeState } from '../systemMode';
import { isAutopilot, isManual, isOptimization } from '../systemMode';

export interface ModeBehavior {
  /** Does the system execute the action automatically? */
  autoExecute: boolean;
  /** Or only propose it for a human click? */
  proposeOnly: boolean;
  /** Is it allowed to change rules / risk caps / pricing? */
  canTuneMachine: boolean;
  /** Short label for UI & activity log */
  label: string;
  /** Sentence used by the narrator */
  narratorTagline: string;
  /** Color class for UI badges */
  colorClass: string;
}

export const MODE_BEHAVIOR: Record<SystemMode, ModeBehavior> = {
  MANUAL: {
    autoExecute: false,
    proposeOnly: true,
    canTuneMachine: false,
    label: 'Manual',
    narratorTagline: 'is watching but waiting for your approval.',
    colorClass: 'text-yellow-600',
  },
  AUTOPILOT: {
    autoExecute: true,
    proposeOnly: false,
    canTuneMachine: false,
    label: 'Autopilot',
    narratorTagline: 'is handling safe tasks automatically.',
    colorClass: 'text-green-600',
  },
  OPTIMIZATION_PILOT: {
    autoExecute: false,
    proposeOnly: true,
    canTuneMachine: true,
    label: 'Optimization 555',
    narratorTagline: 'is stress-testing and tuning the machine.',
    colorClass: 'text-blue-600',
  },
};

/**
 * Get the behavior configuration for a given system mode
 */
export function getModeBehavior(mode: SystemMode): ModeBehavior {
  return MODE_BEHAVIOR[mode];
}

/**
 * Get behavior from full system mode state
 */
export function getModeBehaviorFromState(state: SystemModeState): ModeBehavior {
  if (isManual(state)) return MODE_BEHAVIOR.MANUAL;
  if (isOptimization(state)) return MODE_BEHAVIOR.OPTIMIZATION_PILOT;
  return MODE_BEHAVIOR.AUTOPILOT;
}
