// MCA Blueprint Module 2: Product Catalog & Risk Matrix
import { supabase } from "@/integrations/supabase/client";

export interface ProductSuggestion {
  productCode: string;
  productName: string;
  riskTier: string;
  approvalMin: number;
  approvalMax: number;
  recommendedFactor: number;
  termMinDays: number;
  termMaxDays: number;
  reasons: string[];
}

export interface RiskTier {
  id: string;
  code: string;
  description: string | null;
  min_score: number;
  max_score: number;
  default_factor_rate_min: number | null;
  default_factor_rate_max: number | null;
  default_term_min_days: number | null;
  default_term_max_days: number | null;
}

export interface McaProduct {
  id: string;
  code: string;
  name: string;
  description: string | null;
  is_active: boolean;
}

export interface ProductPricingRule {
  id: string;
  product_id: string;
  risk_tier_id: string;
  state_code: string | null;
  factor_min: number;
  factor_max: number;
  term_min_days: number;
  term_max_days: number;
  max_approval_pct_of_avg_monthly: number;
  is_active: boolean;
}

export interface IndustryRule {
  id: string;
  naics_code: string | null;
  industry_label: string;
  product_allowed: boolean;
  excluded: boolean;
  notes: string | null;
}

export interface ProductSuggestionContext {
  stateCode: string;
  riskScore: number;
  avgMonthlyRevenue: number;
  naicsCode?: string | null;
  existingPositions?: number;
}

export async function getRiskTierForScore(score: number): Promise<RiskTier | null> {
  const { data, error } = await supabase
    .from('risk_tiers')
    .select('*')
    .lte('min_score', score)
    .gte('max_score', score)
    .single();

  if (error || !data) {
    // Fallback: get closest tier
    const { data: tiers } = await supabase
      .from('risk_tiers')
      .select('*')
      .order('min_score');
    
    if (tiers && tiers.length > 0) {
      for (const tier of tiers) {
        if (score >= tier.min_score && score <= tier.max_score) {
          return tier as RiskTier;
        }
      }
      // Return first tier as fallback
      return tiers[0] as RiskTier;
    }
    return null;
  }
  return data as RiskTier;
}

export async function getAllRiskTiers(): Promise<RiskTier[]> {
  const { data, error } = await supabase
    .from('risk_tiers')
    .select('*')
    .order('min_score');

  if (error) return [];
  return (data || []) as RiskTier[];
}

export async function getAllProducts(): Promise<McaProduct[]> {
  const { data, error } = await supabase
    .from('mca_products')
    .select('*')
    .eq('is_active', true)
    .order('code');

  if (error) return [];
  return (data || []) as McaProduct[];
}

export async function getProductPricingRules(productId: string, riskTierId: string, stateCode?: string): Promise<ProductPricingRule[]> {
  let query = supabase
    .from('product_pricing_rules')
    .select('*')
    .eq('product_id', productId)
    .eq('risk_tier_id', riskTierId)
    .eq('is_active', true);

  // Get state-specific or null (all states)
  if (stateCode) {
    query = query.or(`state_code.eq.${stateCode},state_code.is.null`);
  }

  const { data, error } = await query;
  if (error) return [];
  return (data || []) as ProductPricingRule[];
}

export async function checkIndustryExclusion(naicsCode: string): Promise<{ excluded: boolean; reason?: string }> {
  const { data } = await supabase
    .from('industry_rules')
    .select('*')
    .eq('naics_code', naicsCode)
    .single();

  if (data && data.excluded) {
    return { excluded: true, reason: data.notes || 'Industry excluded' };
  }
  return { excluded: false };
}

export async function getIndustryRules(): Promise<IndustryRule[]> {
  const { data, error } = await supabase
    .from('industry_rules')
    .select('*')
    .order('industry_label');

  if (error) return [];
  return (data || []) as IndustryRule[];
}

export async function suggestProductsForDeal(ctx: ProductSuggestionContext): Promise<ProductSuggestion[]> {
  const suggestions: ProductSuggestion[] = [];

  // Check industry exclusion
  if (ctx.naicsCode) {
    const { excluded, reason } = await checkIndustryExclusion(ctx.naicsCode);
    if (excluded) {
      return []; // No products available for excluded industries
    }
  }

  // Get risk tier
  const riskTier = await getRiskTierForScore(ctx.riskScore);
  if (!riskTier) {
    // Return default suggestion if no tier found
    return [{
      productCode: 'STD_MCA',
      productName: 'Standard MCA',
      riskTier: 'Unknown',
      approvalMin: Math.round(ctx.avgMonthlyRevenue * 0.5),
      approvalMax: Math.round(ctx.avgMonthlyRevenue * 1.0),
      recommendedFactor: 1.35,
      termMinDays: 60,
      termMaxDays: 120,
      reasons: ['Default suggestion - risk tier not configured'],
    }];
  }

  // Get all active products
  const products = await getAllProducts();

  for (const product of products) {
    // Get pricing rules for this product + tier
    const pricingRules = await getProductPricingRules(product.id, riskTier.id, ctx.stateCode);

    // Use state-specific rule first, then fallback to general
    const rule = pricingRules.find(r => r.state_code === ctx.stateCode) || pricingRules.find(r => !r.state_code);

    if (rule) {
      const approvalMax = Math.round(ctx.avgMonthlyRevenue * rule.max_approval_pct_of_avg_monthly);
      const approvalMin = Math.round(approvalMax * 0.5);
      const recommendedFactor = (rule.factor_min + rule.factor_max) / 2;

      const reasons: string[] = [];
      reasons.push(`Risk Score ${ctx.riskScore} → Tier ${riskTier.code}`);
      if (ctx.existingPositions && ctx.existingPositions > 0) {
        reasons.push(`${ctx.existingPositions} existing position(s)`);
      }
      reasons.push(`Avg Monthly Revenue: $${ctx.avgMonthlyRevenue.toLocaleString()}`);

      suggestions.push({
        productCode: product.code,
        productName: product.name,
        riskTier: riskTier.code,
        approvalMin,
        approvalMax,
        recommendedFactor,
        termMinDays: rule.term_min_days,
        termMaxDays: rule.term_max_days,
        reasons,
      });
    } else if (riskTier.default_factor_rate_min && riskTier.default_term_min_days) {
      // Use tier defaults
      const approvalMax = Math.round(ctx.avgMonthlyRevenue * 1.2);
      const approvalMin = Math.round(approvalMax * 0.5);

      suggestions.push({
        productCode: product.code,
        productName: product.name,
        riskTier: riskTier.code,
        approvalMin,
        approvalMax,
        recommendedFactor: ((riskTier.default_factor_rate_min || 1.2) + (riskTier.default_factor_rate_max || 1.4)) / 2,
        termMinDays: riskTier.default_term_min_days || 60,
        termMaxDays: riskTier.default_term_max_days || 120,
        reasons: [`Risk Tier ${riskTier.code} defaults applied`],
      });
    }
  }

  // If no suggestions, return default
  if (suggestions.length === 0) {
    return [{
      productCode: 'STD_MCA',
      productName: 'Standard MCA',
      riskTier: riskTier?.code || 'B',
      approvalMin: Math.round(ctx.avgMonthlyRevenue * 0.5),
      approvalMax: Math.round(ctx.avgMonthlyRevenue * 1.2),
      recommendedFactor: 1.30,
      termMinDays: 60,
      termMaxDays: 120,
      reasons: ['Default suggestion - no specific pricing rules configured'],
    }];
  }

  return suggestions;
}

export function formatFactorRate(factor: number): string {
  return factor.toFixed(2);
}

export function formatTermDays(days: number): string {
  if (days >= 30) {
    const months = Math.round(days / 30);
    return `${months} month${months !== 1 ? 's' : ''}`;
  }
  return `${days} days`;
}

export function calculateDailyPayment(amount: number, factor: number, termDays: number): number {
  const totalOwed = amount * factor;
  return Math.round((totalOwed / termDays) * 100) / 100;
}
