// V25: Security masking utilities for sensitive data

export type MaskLevel = 'none' | 'partial' | 'full' | 'vault';

export interface MaskOptions {
  level: MaskLevel;
  showLast?: number;
}

export function maskSSN(value: string | null | undefined, options: MaskOptions = { level: 'partial' }): string {
  if (!value) return '•••-••-••••';
  const clean = value.replace(/\D/g, '');
  
  switch (options.level) {
    case 'none':
      return clean.length === 9 
        ? `${clean.slice(0, 3)}-${clean.slice(3, 5)}-${clean.slice(5)}` 
        : value;
    case 'partial':
      return `•••-••-${clean.slice(-4) || '••••'}`;
    case 'full':
    case 'vault':
      return '•••-••-••••';
    default:
      return '•••-••-••••';
  }
}

export function maskPhone(value: string | null | undefined, options: MaskOptions = { level: 'partial' }): string {
  if (!value) return '(•••) •••-••••';
  const clean = value.replace(/\D/g, '');
  
  switch (options.level) {
    case 'none':
      return clean.length === 10 
        ? `(${clean.slice(0, 3)}) ${clean.slice(3, 6)}-${clean.slice(6)}` 
        : value;
    case 'partial':
      return `(•••) •••-${clean.slice(-4) || '••••'}`;
    case 'full':
    case 'vault':
      return '(•••) •••-••••';
    default:
      return '(•••) •••-••••';
  }
}

export function maskEmail(value: string | null | undefined, options: MaskOptions = { level: 'partial' }): string {
  if (!value) return '••••@••••.•••';
  
  switch (options.level) {
    case 'none':
      return value;
    case 'partial': {
      const [local, domain] = value.split('@');
      if (!local || !domain) return '••••@••••.•••';
      const maskedLocal = local.slice(0, 2) + '•'.repeat(Math.max(0, local.length - 2));
      return `${maskedLocal}@${domain}`;
    }
    case 'full':
    case 'vault':
      return '••••@••••.•••';
    default:
      return '••••@••••.•••';
  }
}

export function maskName(value: string | null | undefined, options: MaskOptions = { level: 'partial' }): string {
  if (!value) return '•••••• ••••••';
  
  switch (options.level) {
    case 'none':
      return value;
    case 'partial': {
      const parts = value.split(' ');
      return parts.map(p => p.slice(0, 1) + '•'.repeat(Math.max(0, p.length - 1))).join(' ');
    }
    case 'full':
    case 'vault':
      return '•••••• ••••••';
    default:
      return '•••••• ••••••';
  }
}

export function maskAddress(value: string | null | undefined, options: MaskOptions = { level: 'partial' }): string {
  if (!value) return '•••• •••••• ••••';
  
  switch (options.level) {
    case 'none':
      return value;
    case 'partial':
      return value.slice(0, 5) + '•'.repeat(Math.max(0, value.length - 5));
    case 'full':
    case 'vault':
      return '•••• •••••• ••••';
    default:
      return '•••• •••••• ••••';
  }
}

export function getMaskLevelForRole(role: string, isVaultField: boolean = false): MaskLevel {
  if (isVaultField) {
    if (role === 'owner' || role === 'legal') return 'none';
    return 'vault';
  }
  
  switch (role) {
    case 'owner':
    case 'legal':
      return 'none';
    case 'tenant_admin':
    case 'admin':
      return 'partial';
    default:
      return 'full';
  }
}
