import type { AppRole } from "@/lib/permissions";

export function canViewRawPii(roles: AppRole[]): boolean {
  // Keep this helper runtime-dependency-free to avoid circular import risks
  // (type-only import from permissions is erased at build time).
  return roles.includes("owner") || roles.includes("super_owner");
}

export function maskPhone(raw?: string | null): string {
  if (!raw) return "Missing";
  const digits = raw.replace(/\D/g, "");
  if (digits.length < 4) return "***";
  const last4 = digits.slice(-4);
  return `***-***-${last4}`;
}

export function maskEmail(raw?: string | null): string {
  if (!raw) return "Missing";
  const at = raw.indexOf("@");
  if (at <= 0) return "***";
  const user = raw.slice(0, at);
  const domain = raw.slice(at + 1);
  const first = user.slice(0, 1);
  const maskedUser = `${first}***`;
  const maskedDomain = domain.length > 0 ? domain : "***";
  return `${maskedUser}@${maskedDomain}`;
}

