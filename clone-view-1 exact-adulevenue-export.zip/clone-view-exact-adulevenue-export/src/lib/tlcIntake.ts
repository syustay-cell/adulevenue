export const TLC_INTENT_VALUES = [
  "donor",
  "family_help",
  "partner",
  "legislation",
  "volunteer",
] as const;

export type TlcIntent = (typeof TLC_INTENT_VALUES)[number];
export type TlcProgram = "national" | "nj_pilot" | "internal_preview";

export interface TlcIntakeTags {
  source_domain: string;
  source_site: "tlc";
  program: TlcProgram;
  intent: TlcIntent;
}

const NATIONAL_DOMAIN = "thelefkowitzcenter.org";
const NJ_DOMAIN = "tlc-nj.com";

function normalizeHostname(hostname: string): string {
  return hostname.trim().toLowerCase().replace(/^www\./, "");
}

export function getTlcIntakeTags(intent: TlcIntent): TlcIntakeTags {
  if (typeof window === "undefined" || !window.location?.hostname) {
    throw new Error("Unable to determine source domain for intake tagging");
  }

  const sourceDomain = window.location.hostname;
  const normalizedHost = normalizeHostname(sourceDomain);

  let program: TlcProgram = "internal_preview";
  if (normalizedHost === NATIONAL_DOMAIN) {
    program = "national";
  } else if (normalizedHost === NJ_DOMAIN) {
    program = "nj_pilot";
  }

  return {
    source_domain: sourceDomain,
    source_site: "tlc",
    program,
    intent,
  };
}

