// src/lib/autopilotActions.ts - Phase 5: Autopilot action helpers

import { supabase } from "@/integrations/supabase/client";

export interface AutopilotRunResult {
  ok: boolean;
  run_id?: string;
  total_insights?: number;
  total_actions?: number;
  total_tags?: number;
  error?: string;
}

/**
 * Trigger the AI Autopilot Engine for a specific tenant
 */
export async function runAiAutopilotEngine(tenantId: string): Promise<AutopilotRunResult> {
  try {
    const { data, error } = await supabase.functions.invoke("ai-autopilot-engine", {
      body: { tenantId, mode: "manual" },
    });

    if (error) {
      console.error("[runAiAutopilotEngine] Function error:", error);
      return { ok: false, error: error.message };
    }

    return {
      ok: data?.ok ?? false,
      run_id: data?.run_id,
      total_insights: data?.total_insights,
      total_actions: data?.total_actions,
      total_tags: data?.total_tags,
      error: data?.message,
    };
  } catch (err) {
    console.error("[runAiAutopilotEngine] Error:", err);
    return { ok: false, error: err instanceof Error ? err.message : "Unknown error" };
  }
}
