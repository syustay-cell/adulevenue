import { supabase } from "@/integrations/supabase/client";
import type { ResearchResult } from "@/types/research-intel";

export async function runResearchIntel(leadId: string): Promise<ResearchResult> {
  if (!leadId) {
    throw new Error("lead_id is required for research intel");
  }

  const { data, error } = await supabase.functions.invoke("wolf-research-intel", {
    body: { lead_id: leadId },
  });

  // Network error or edge function threw (should be rare now)
  if (error) {
    console.error("[researchIntel] Network/invoke error:", error);
    throw new Error("Research service temporarily unavailable. Please try again.");
  }

  // Safe response pattern: check ok field
  if (!data?.ok) {
    const message = data?.message || "Research failed";
    console.warn("[researchIntel] Soft error:", data?.error_code, message);
    throw new Error(message);
  }

  return data as ResearchResult;
}

// Re-export types for convenience
export type { ResearchResult, ResearchProfile, EnrichedContact, FundingRecommendation, RiskLevel } from "@/types/research-intel";
