import { supabase } from "@/integrations/supabase/client";

export interface EmailLead {
  id: string;
  email: string | null;
  full_name: string | null;
  business_name: string | null;
  email_status: string | null;
  email_attempts: number | null;
  last_emailed_at: string | null;
  ai_score: number | null;
}

export async function fetchNextEmailLead(): Promise<EmailLead | null> {
  const { data, error } = await supabase.rpc("get_next_email_lead", { p_user_id: null });
  if (error) {
    console.error("[smartEmailer] fetchNextEmailLead error:", error);
    throw error;
  }
  return data as EmailLead | null;
}

export async function sendSmartEmail(leadId: string, templateId?: string): Promise<{ success: boolean; email?: string }> {
  const { data, error } = await supabase.functions.invoke("send-smart-email", {
    body: { lead_id: leadId, template_id: templateId },
  });
  if (error) {
    console.error("[smartEmailer] sendSmartEmail error:", error);
    throw error;
  }
  return data;
}

export async function getEmailQueueCount(): Promise<number> {
  const { count, error } = await supabase
    .from("leads")
    .select("*", { count: "exact", head: true })
    .or("route.eq.email,and(email.not.is.null,phone.is.null)")
    .not("email", "is", null)
    .or("email_status.is.null,email_status.eq.not_sent")
    .eq("status", "new");

  if (error) {
    console.error("[smartEmailer] getEmailQueueCount error:", error);
    return 0;
  }
  return count || 0;
}
