import { supabase } from "@/integrations/supabase/client";
import type { LeadLane, FundingPath } from "@/types/leadEngine";

type RawLeadLane = {
  id: string;
  lead_id: string | null;
  business_name: string | null;
  ai_funding_path: string | null;
  ai_funding_score: number | null;
  ai_credit_risk: string | null;
  stage: string | null;
  leads?: {
    id: string;
    ai_priority: string | null;
    status: string | null;
  } | null;
};

const FUNDING_PATH_MAP: Record<string, FundingPath> = {
  funding_first: "FUNDING_FIRST",
  credit_first: "CREDIT_FIRST",
  needs_more_info: "NEEDS_MORE_INFO",
};

function normalizeFundingPath(path: string | null): FundingPath {
  if (!path) return "NEEDS_MORE_INFO";
  const normalized = path.toLowerCase();
  return FUNDING_PATH_MAP[normalized] ?? "NEEDS_MORE_INFO";
}

function normalizePriority(
  priority: string | null | undefined,
): LeadLane["priorityBand"] {
  if (!priority) return null;
  const value = priority.toUpperCase();
  return ["A", "B", "C", "D", "F"].includes(value) ? (value as LeadLane["priorityBand"]) : null;
}

function normalizeCreditRisk(
  risk: string | null | undefined,
): LeadLane["creditRisk"] {
  if (!risk) return "unknown";
  const normalized = risk.toLowerCase();
  if (["low", "medium", "high"].includes(normalized)) {
    return normalized as LeadLane["creditRisk"];
  }
  return "unknown";
}

function normalizeStatus(stage: string | null | undefined): LeadLane["status"] {
  if (!stage) return "new";
  const normalized = stage.toLowerCase();
  if (normalized.includes("await")) return "awaiting_client";
  if (normalized.includes("closed") || normalized.includes("funded")) return "closed";
  if (normalized.includes("work") || normalized.includes("queue") || normalized.includes("research")) {
    return "working";
  }
  return "new";
}

export async function fetchLeadLanes(): Promise<LeadLane[]> {
  const { data, error } = await supabase
    .from("intake_clients")
    .select(
      "id, lead_id, business_name, ai_funding_path, ai_funding_score, ai_credit_risk, stage, leads:lead_id ( id, ai_priority, status )",
    )
    .order("ai_funding_score", { ascending: false, nullsFirst: false })
    .limit(150);

  if (error) {
    throw new Error(error.message);
  }

  return (data as RawLeadLane[] | null)?.map((row) => {
    const leadRef = row.leads;
    return {
      id: row.lead_id ?? row.id,
      businessName: row.business_name ?? "Unnamed business",
      fundingPath: normalizeFundingPath(row.ai_funding_path),
      fundingScore: row.ai_funding_score,
      priorityBand: normalizePriority(leadRef?.ai_priority),
      creditRisk: normalizeCreditRisk(row.ai_credit_risk),
      status: normalizeStatus(row.stage ?? leadRef?.status ?? null),
    };
  }) ?? [];
}
