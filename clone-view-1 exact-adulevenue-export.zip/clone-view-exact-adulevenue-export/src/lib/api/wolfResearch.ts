import { supabase } from "@/integrations/supabase/client";
import type { ResearchResult, ResearchProfile, EnrichedContact } from "@/types/research-intel";

export type OCMIntel = {
  license_status: string;
  expiration_date: string | null;
  expiration_window: "urgent" | "soon" | "normal" | "unknown";
  municipality: string | null;
  license_type: string | null;
  owner_name: string | null;
  owner_first_name: string | null;
  owner_last_name: string | null;
  location_address: string | null;
  zoning_risk: "green" | "yellow" | "red";
  transferable: boolean;
  property_owner: string | null;
};

export type WolfResearchResult = ResearchResult & {
  ocm_intel: OCMIntel | null;
};

export async function runResearchQ(leadId: string): Promise<WolfResearchResult> {
  const { data, error } = await supabase.functions.invoke("wolf-research-intel", {
    body: { lead_id: leadId },
  });

  // Network error or edge function threw (should be rare now)
  if (error) {
    console.error("[runResearchQ] Network/invoke error:", error);
    throw new Error("Research service temporarily unavailable. Please try again.");
  }

  // Safe response pattern: check ok field
  if (!data?.ok) {
    const message = data?.message || "Unknown research error";
    console.warn("[runResearchQ] Soft error:", data?.error_code, message);
    throw new Error(message);
  }

  return {
    success: true,
    promoted: data.promoted,
    new_bucket: data.new_bucket,
    profile: data.profile as ResearchProfile,
    ocm_intel: data.ocm_intel as OCMIntel | null,
  };
}

// Re-export types for convenience
export type { ResearchResult, ResearchProfile, EnrichedContact } from "@/types/research-intel";
