import { supabase } from "@/integrations/supabase/client";
import type { Json } from "@/integrations/supabase/types";

export type ClientActivity = {
  id: string;
  lead_id: string;
  type: string;
  channel: string | null;
  direction: string | null;
  subject: string | null;
  body: string | null;
  meta: Json | null;
  worker_id: string | null;
  created_at: string;
};

export async function fetchClientActivity(leadId: string): Promise<ClientActivity[]> {
  const { data, error } = await supabase
    .from("client_activity")
    .select("*")
    .eq("lead_id", leadId)
    .order("created_at", { ascending: false });

  if (error) throw error;
  return (data ?? []) as ClientActivity[];
}

export async function logClientActivity(params: {
  lead_id: string;
  worker_id?: string | null;
  type: string;
  channel?: string | null;
  direction?: string | null;
  subject?: string | null;
  body?: string | null;
  meta?: Record<string, unknown>;
}): Promise<void> {
  const { error } = await supabase.from("client_activity").insert([{
    lead_id: params.lead_id,
    worker_id: params.worker_id ?? null,
    type: params.type,
    channel: params.channel ?? null,
    direction: params.direction ?? null,
    subject: params.subject ?? null,
    body: params.body ?? null,
    meta: (params.meta ?? {}) as Json,
  }]);

  if (error) {
    console.error("[logClientActivity] failed:", error);
    throw error;
  }
}

/**
 * Persist an AI output artifact as a Puzzle draft item.
 *
 * Stores into `client_activity` so it is reload-safe and Timeline-visible.
 * Does NOT route, does NOT change lead status/lane, does NOT create intake_clients rows.
 */
export async function persistAiArtifact(params: {
  lead_id: string;
  type: string;
  subject: string;
  body: string;
  meta?: Record<string, unknown>;
}): Promise<void> {
  // Best-effort: attach actor without requiring callers to pass it.
  let workerId: string | null = null;
  try {
    const { data } = await supabase.auth.getUser();
    workerId = data.user?.id ?? null;
  } catch {
    workerId = null;
  }

  return logClientActivity({
    lead_id: params.lead_id,
    worker_id: workerId,
    type: params.type,
    channel: "system",
    direction: "internal",
    subject: params.subject,
    body: params.body,
    meta: params.meta ?? {},
  });
}
