import { supabase } from "@/integrations/supabase/client";

export type SmartOutreachChannel = "sms" | "email";

interface SendSmartPayload {
  lead_id: string;
  template_name?: string;
  body?: string;
  to_phone?: string;
  case_id?: string;
  client_id?: string;
  reply_in_hours?: number;
  sent_by_user_id?: string;
  subject?: string; // for email only
}

interface SendSmartResponse {
  success: boolean;
  message_id?: string;
  to?: string;
  status?: string;
  reply_due_at?: string;
  error?: string;
}

/**
 * Send SMS via the send-smart-sms edge function
 * Logs to messages_sent + client_activity, supports reply tracking
 */
export async function sendSmartSms(payload: SendSmartPayload): Promise<SendSmartResponse> {
  const { data, error } = await supabase.functions.invoke("send-smart-sms", {
    body: payload,
  });

  if (error) throw error;
  if (!data?.success) throw new Error(data?.error || "send_sms_failed");
  return data;
}

/**
 * Send Email via the send-smart-email edge function
 * Logs to messages_sent + client_activity, supports reply tracking
 */
export async function sendSmartEmail(payload: SendSmartPayload): Promise<SendSmartResponse> {
  const { data, error } = await supabase.functions.invoke("send-smart-email", {
    body: payload,
  });

  if (error) throw error;
  if (!data?.success) throw new Error(data?.error || "send_email_failed");
  return data;
}

/**
 * Generic send function that routes to SMS or Email based on channel
 */
export async function sendSmartOutreach(
  channel: SmartOutreachChannel,
  payload: SendSmartPayload
): Promise<SendSmartResponse> {
  if (channel === "sms") {
    return sendSmartSms(payload);
  } else {
    return sendSmartEmail(payload);
  }
}

/**
 * Lock a lead for 7 days after outreach
 */
export async function lockLeadAfterOutreach(
  leadId: string,
  workerId: string,
  reason: string = "outreach_sent"
): Promise<void> {
  try {
    await supabase.rpc("lock_lead_for_client_work", {
      p_lead_id: leadId,
      p_worker_id: workerId,
      p_reason: reason,
    });
  } catch (error) {
    console.log("[smartOutreach] Lead lock skipped:", error);
  }
}
