// MCA Blueprint Module 4: Renewal Engine
import { supabase } from "@/integrations/supabase/client";
import { getSystemModeState, isAutopilot, isEco, isAggressive, type SystemModeState } from "./systemMode";
import { getStrategyConfigFromState, canAutoExecuteFromState } from "./systemMode/strategyConfig";
import { logActivityEvent } from "./activity";

export interface RenewalRule {
  id: string;
  min_paid_pct: number;
  max_paid_pct: number;
  min_days_since_fund: number;
  allow_stack: boolean;
  is_active: boolean;
}

export interface RenewalOffer {
  id: string;
  original_deal_id: string;
  lead_id: string;
  iso_id: string | null;
  created_by: string | null;
  status: 'draft' | 'sent' | 'accepted' | 'declined' | 'expired';
  offer_json: RenewalOfferDetails;
  triggered_at: string;
  sent_at: string | null;
  responded_at: string | null;
  notes: string | null;
}

export interface RenewalOfferDetails {
  amount: number;
  factor: number;
  term_days: number;
  payoff_existing: number;
  net_to_merchant: number;
  daily_payment: number;
  product_code: string;
}

export interface RenewalEligibility {
  eligible: boolean;
  reasons: string[];
  paidPct: number;
  daysSinceFund: number;
  suggestedAmount?: number;
  suggestedFactor?: number;
}

export async function getActiveRenewalRule(): Promise<RenewalRule | null> {
  const { data, error } = await supabase
    .from('renewal_rules')
    .select('*')
    .eq('is_active', true)
    .single();

  if (error || !data) {
    // Return default rule
    return {
      id: '',
      min_paid_pct: 0.35,
      max_paid_pct: 0.60,
      min_days_since_fund: 45,
      allow_stack: false,
      is_active: true,
    };
  }
  return data as RenewalRule;
}

export async function getRenewalOffers(dealId: string): Promise<RenewalOffer[]> {
  const { data, error } = await supabase
    .from('renewal_offers')
    .select('*')
    .eq('original_deal_id', dealId)
    .order('created_at', { ascending: false });

  if (error) return [];
  return (data || []).map(d => ({
    ...d,
    offer_json: d.offer_json as unknown as RenewalOfferDetails,
  })) as RenewalOffer[];
}

export async function getAllRenewalOffers(statusFilter?: string): Promise<RenewalOffer[]> {
  let query = supabase
    .from('renewal_offers')
    .select('*')
    .order('triggered_at', { ascending: false });

  if (statusFilter) {
    query = query.eq('status', statusFilter);
  }

  const { data, error } = await query;
  if (error) return [];
  return (data || []).map(d => ({
    ...d,
    offer_json: d.offer_json as unknown as RenewalOfferDetails,
  })) as RenewalOffer[];
}

export async function computeRenewalEligibility(deal: {
  id: string;
  funded_at?: string | null;
  purchased_amount?: number | null;
  paid_to_date?: number | null;
  status?: string | null;
}): Promise<RenewalEligibility> {
  const reasons: string[] = [];
  
  // Get active rule
  const rule = await getActiveRenewalRule();
  if (!rule) {
    return { eligible: false, reasons: ['No renewal rules configured'], paidPct: 0, daysSinceFund: 0 };
  }

  // Check deal status
  if (deal.status && deal.status !== 'performing' && deal.status !== 'funded') {
    reasons.push(`Deal status is "${deal.status}" - must be performing`);
  }

  // Calculate paid percentage
  const paidToDate = deal.paid_to_date || 0;
  const purchasedAmount = deal.purchased_amount || 0;
  const paidPct = purchasedAmount > 0 ? paidToDate / purchasedAmount : 0;

  // Check paid percentage range
  if (paidPct < rule.min_paid_pct) {
    reasons.push(`Paid ${(paidPct * 100).toFixed(1)}% - minimum required is ${(rule.min_paid_pct * 100).toFixed(0)}%`);
  }
  if (paidPct > rule.max_paid_pct) {
    reasons.push(`Paid ${(paidPct * 100).toFixed(1)}% - maximum for renewal is ${(rule.max_paid_pct * 100).toFixed(0)}%`);
  }

  // Calculate days since funding
  let daysSinceFund = 0;
  if (deal.funded_at) {
    const fundedDate = new Date(deal.funded_at);
    const today = new Date();
    daysSinceFund = Math.floor((today.getTime() - fundedDate.getTime()) / (1000 * 60 * 60 * 24));
  }

  // Check minimum days
  if (daysSinceFund < rule.min_days_since_fund) {
    reasons.push(`Only ${daysSinceFund} days since funding - minimum is ${rule.min_days_since_fund} days`);
  }

  const eligible = reasons.length === 0;

  // Calculate suggested renewal terms if eligible
  let suggestedAmount: number | undefined;
  let suggestedFactor: number | undefined;

  if (eligible && purchasedAmount > 0) {
    // Suggest 80-100% of original amount
    suggestedAmount = Math.round(purchasedAmount * 0.9);
    suggestedFactor = 1.30; // Conservative factor for renewals
  }

  return {
    eligible,
    reasons: eligible ? ['Eligible for renewal'] : reasons,
    paidPct,
    daysSinceFund,
    suggestedAmount,
    suggestedFactor,
  };
}

export async function createRenewalOffer(
  originalDealId: string,
  leadId: string,
  isoId: string | null,
  offerDetails: RenewalOfferDetails,
  createdBy?: string
): Promise<{ offer: RenewalOffer | null; error?: string }> {
  const insertData = {
    original_deal_id: originalDealId,
    lead_id: leadId,
    iso_id: isoId || null,
    created_by: createdBy || null,
    status: 'draft',
    offer_json: offerDetails as unknown as Record<string, unknown>,
    triggered_at: new Date().toISOString(),
  };

  const { data, error } = await supabase
    .from('renewal_offers')
    .insert(insertData as any)
    .select()
    .single();

  if (error) return { offer: null, error: error.message };
  return {
    offer: {
      ...data,
      offer_json: data.offer_json as unknown as RenewalOfferDetails,
    } as RenewalOffer,
  };
}

export async function updateRenewalOfferStatus(
  offerId: string,
  status: 'sent' | 'accepted' | 'declined' | 'expired',
  notes?: string
): Promise<{ success: boolean; error?: string }> {
  const updateData: Record<string, any> = {
    status,
    updated_at: new Date().toISOString(),
  };

  if (status === 'sent') {
    updateData.sent_at = new Date().toISOString();
  }
  if (status === 'accepted' || status === 'declined') {
    updateData.responded_at = new Date().toISOString();
  }
  if (notes) {
    updateData.notes = notes;
  }

  const { error } = await supabase
    .from('renewal_offers')
    .update(updateData)
    .eq('id', offerId);

  if (error) return { success: false, error: error.message };
  return { success: true };
}

export function calculateNetToMerchant(amount: number, payoffExisting: number): number {
  return amount - payoffExisting;
}

export function calculateDailyPayment(amount: number, factor: number, termDays: number): number {
  const totalOwed = amount * factor;
  return Math.round((totalOwed / termDays) * 100) / 100;
}

export function formatRenewalStatus(status: string): string {
  const labels: Record<string, string> = {
    draft: 'Draft',
    sent: 'Sent to Merchant',
    accepted: 'Accepted',
    declined: 'Declined',
    expired: 'Expired',
  };
  return labels[status] || status;
}

export function getRenewalStatusColor(status: string): string {
  switch (status) {
    case 'accepted': return 'text-green-600';
    case 'declined': return 'text-red-600';
    case 'expired': return 'text-gray-500';
    case 'sent': return 'text-blue-600';
    case 'draft': return 'text-yellow-600';
    default: return 'text-muted-foreground';
  }
}

export interface DealForRenewalScan {
  id: string;
  lead_id: string;
  iso_id?: string | null;
  funded_at?: string;
  purchased_amount?: number;
  paid_to_date?: number;
}

/**
 * Strategy-aware daily renewal scan
 * Uses STRATEGY_CONFIG for multipliers and auto-send rules
 * ECO: lower amounts (renewalAmountMultiplier), only draft (no auto-send)
 * STANDARD: normal amounts, auto-create and send
 * AGGRESSIVE: higher amounts (+15%), auto-create and send
 * MANUAL: only logs suggestions
 */
export async function dailyRenewalScan(deals: DealForRenewalScan[]): Promise<{
  scanned: number;
  eligible: number;
  offersCreated: number;
  offersSent: number;
  suggestions: { dealId: string; eligibility: RenewalEligibility }[];
}> {
  const modeState = await getSystemModeState();
  const strategy = getStrategyConfigFromState(modeState);
  const canAuto = canAutoExecuteFromState(modeState);
  
  const suggestions: { dealId: string; eligibility: RenewalEligibility }[] = [];
  let eligible = 0;
  let offersCreated = 0;
  let offersSent = 0;

  const modeLabel = `${modeState.executionMode} · ${modeState.strategyProfile}`;

  // Limit processing based on strategy
  const maxToProcess = strategy.maxRenewalDraftsPerDay;
  const dealsToScan = deals.slice(0, maxToProcess);

  for (const deal of dealsToScan) {
    const eligibility = await computeRenewalEligibility({
      id: deal.id,
      funded_at: deal.funded_at,
      purchased_amount: deal.purchased_amount,
      paid_to_date: deal.paid_to_date,
    });

    if (!eligibility.eligible) continue;
    eligible++;

    // Apply strategy multiplier to suggested amount
    const baseAmount = eligibility.suggestedAmount || (deal.purchased_amount || 0);
    const adjustedAmount = Math.round(baseAmount * strategy.renewalAmountMultiplier);
    const adjustedFactor = Math.min(eligibility.suggestedFactor || 1.3, strategy.renewalMaxFactor);

    suggestions.push({ dealId: deal.id, eligibility: { ...eligibility, suggestedAmount: adjustedAmount } });

    if (canAuto) {
      const offerDetails: RenewalOfferDetails = {
        amount: adjustedAmount,
        factor: adjustedFactor,
        term_days: 180,
        payoff_existing: (deal.purchased_amount || 0) - (deal.paid_to_date || 0),
        net_to_merchant: adjustedAmount - ((deal.purchased_amount || 0) - (deal.paid_to_date || 0)),
        daily_payment: (adjustedAmount * adjustedFactor) / 180,
        product_code: modeState.strategyProfile === 'ECO' ? 'RENEWAL_ECO' : 
                      modeState.strategyProfile === 'AGGRESSIVE' ? 'RENEWAL_AGG' : 'RENEWAL_STD',
      };

      const { offer, error } = await createRenewalOffer(deal.id, deal.lead_id, deal.iso_id || null, offerDetails);
      
      if (!error && offer) {
        offersCreated++;
        
        // Check if auto-send is allowed by strategy
        const shouldAutoSend = strategy.autoSendRenewalStatuses.includes('sent');
        
        if (shouldAutoSend) {
          const sendResult = await updateRenewalOfferStatus(offer.id, 'sent');
          if (sendResult.success) {
            offersSent++;
          }
        }
        
        await logActivityEvent({
          actorType: 'AI',
          scope: 'RENEWALS',
          eventType: 'ACTION',
          decision: 'AUTO_ACTION',
          severity: 'LOW',
          dealId: deal.id,
          summary: `Renewal offer ${shouldAutoSend ? 'created and sent' : 'drafted'} for Deal ${deal.id.slice(0, 8)} - $${offerDetails.amount.toLocaleString()}`,
          details: { 
            deal_id: deal.id, 
            offer_id: offer.id, 
            amount: offerDetails.amount, 
            factor: offerDetails.factor,
            mode: modeLabel,
            auto_sent: shouldAutoSend,
            multiplier: strategy.renewalAmountMultiplier,
          },
        });
      }
    } else {
      // Manual mode - log proposal only
      await logActivityEvent({
        actorType: 'AI',
        scope: 'RENEWALS',
        eventType: 'DECISION',
        decision: 'INFO',
        severity: 'LOW',
        dealId: deal.id,
        summary: `Renewal opportunity identified for Deal ${deal.id.slice(0, 8)} - ${(eligibility.paidPct * 100).toFixed(1)}% paid, suggested $${adjustedAmount.toLocaleString()}`,
        details: { deal_id: deal.id, eligibility, adjustedAmount, mode: 'MANUAL' },
      });
    }
  }

  return {
    scanned: dealsToScan.length,
    eligible,
    offersCreated,
    offersSent,
    suggestions,
  };
}
