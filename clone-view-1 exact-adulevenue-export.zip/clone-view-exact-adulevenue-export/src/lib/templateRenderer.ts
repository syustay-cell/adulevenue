import { supabase } from "@/integrations/supabase/client";

export interface TemplateRenderData {
  ownerName?: string;
  businessName?: string;
  amount?: string | number;
  dpd?: string | number;
  phone?: string;
  email?: string;
  address?: string;
  city?: string;
  state?: string;
  zip?: string;
  fundingAmount?: string | number;
  dailyPayment?: string | number;
  termLength?: string | number;
  factorRate?: string | number;
  creditScore?: string | number;
  monthlyRevenue?: string | number;
  bureauName?: string;
  accountNumber?: string;
  creditorName?: string;
  disputeReason?: string;
  [key: string]: string | number | undefined;
}

export async function renderTemplateById(
  templateId: string,
  data: TemplateRenderData
): Promise<{ subject?: string; body: string; error?: string }> {
  const { data: template, error } = await supabase
    .from("templates_master_library")
    .select("*")
    .eq("id", templateId)
    .single();

  if (error || !template) {
    return { body: "", error: error?.message || "Template not found" };
  }

  let text = template.body || "";
  let subject = template.subject || "";

  for (const key of Object.keys(data)) {
    const value = data[key]?.toString() || "";
    const regex = new RegExp(`{{${key}}}`, "g");
    text = text.replace(regex, value);
    subject = subject.replace(regex, value);
  }

  return { subject, body: text };
}

export async function generateDocument(
  templateId: string,
  leadId: string
): Promise<{ subject?: string; body: string; error?: string }> {
  // Fetch lead data
  const { data: lead, error: leadError } = await supabase
    .from("leads")
    .select("*")
    .eq("id", leadId)
    .single();

  if (leadError || !lead) {
    return { body: "", error: leadError?.message || "Lead not found" };
  }

  // Build render data from lead
  const renderData: TemplateRenderData = {
    ownerName: lead.owner_name || "",
    businessName: lead.business_name || "",
    phone: lead.phone || "",
    email: lead.email || "",
    address: lead.address || "",
    city: lead.city || "",
    state: lead.state || "",
    zip: lead.zip || "",
    fundingAmount: lead.requested_amount || "",
    creditScore: lead.est_credit_score || "",
    monthlyRevenue: "",
  };

  // Render the template
  const result = await renderTemplateById(templateId, renderData);

  if (!result.error) {
    // Save generated document to storage
    const fileName = `${leadId}/${templateId}_${Date.now()}.txt`;
    const blob = new Blob([result.body], { type: "text/plain" });

    await supabase.storage
      .from("generated-documents")
      .upload(fileName, blob, { upsert: true });
  }

  return result;
}

export function extractPlaceholders(text: string): string[] {
  const regex = /{{(\w+)}}/g;
  const matches: string[] = [];
  let match;

  while ((match = regex.exec(text)) !== null) {
    if (!matches.includes(match[1])) {
      matches.push(match[1]);
    }
  }

  return matches;
}
