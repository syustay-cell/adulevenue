// src/lib/controlTowerActions.ts - Phase 6: Control Tower action helpers

import { supabase } from "@/integrations/supabase/client";
import type { WfAutopilotPolicy, WfAlertEvent, SlaStatus } from "@/types/controlTower";

/**
 * Get autopilot policy for a tenant
 */
export async function getAutopilotPolicy(tenantId: string): Promise<WfAutopilotPolicy | null> {
  const { data, error } = await supabase
    .from("wf_autopilot_policies")
    .select("*")
    .eq("tenant_id", tenantId)
    .maybeSingle();

  if (error) {
    console.error("[getAutopilotPolicy] Error:", error);
    return null;
  }

  return data as WfAutopilotPolicy | null;
}

/**
 * Upsert autopilot policy for a tenant
 */
export async function upsertAutopilotPolicy(
  tenantId: string,
  payload: {
    autopilot_enabled?: boolean;
    schedule_type?: string;
    schedule_time?: string | null;
    schedule_timezone?: string | null;
    max_open_actions?: number | null;
    max_critical_insights?: number | null;
    max_hours_since_last_run?: number | null;
  }
): Promise<{ ok: boolean; policy?: WfAutopilotPolicy; error?: string }> {
  // Check if policy exists
  const { data: existing } = await supabase
    .from("wf_autopilot_policies")
    .select("id")
    .eq("tenant_id", tenantId)
    .maybeSingle();

  if (existing) {
    // Update existing
    const { data, error } = await supabase
      .from("wf_autopilot_policies")
      .update({
        autopilot_enabled: payload.autopilot_enabled,
        schedule_type: payload.schedule_type,
        schedule_time: payload.schedule_time,
        schedule_timezone: payload.schedule_timezone,
        max_open_actions: payload.max_open_actions,
        max_critical_insights: payload.max_critical_insights,
        max_hours_since_last_run: payload.max_hours_since_last_run,
      })
      .eq("tenant_id", tenantId)
      .select("*")
      .single();

    if (error) {
      console.error("[upsertAutopilotPolicy] Error:", error);
      return { ok: false, error: error.message };
    }
    return { ok: true, policy: data as unknown as WfAutopilotPolicy };
  } else {
    // Insert new
    const { data, error } = await supabase
      .from("wf_autopilot_policies")
      .insert({
        tenant_id: tenantId,
        autopilot_enabled: payload.autopilot_enabled ?? true,
        schedule_type: payload.schedule_type ?? "daily",
        schedule_time: payload.schedule_time ?? "09:00",
        schedule_timezone: payload.schedule_timezone ?? "America/New_York",
        max_open_actions: payload.max_open_actions ?? 50,
        max_critical_insights: payload.max_critical_insights ?? 5,
        max_hours_since_last_run: payload.max_hours_since_last_run ?? 48,
      })
      .select("*")
      .single();

    if (error) {
      console.error("[upsertAutopilotPolicy] Error:", error);
      return { ok: false, error: error.message };
    }
    return { ok: true, policy: data as unknown as WfAutopilotPolicy };
  }
}

/**
 * Get alert events for a tenant
 */
export async function getAlertEvents(
  tenantId: string,
  options: { limit?: number } = {}
): Promise<WfAlertEvent[]> {
  const { limit = 10 } = options;

  const { data, error } = await supabase
    .from("wf_alert_events")
    .select("*")
    .eq("tenant_id", tenantId)
    .order("created_at", { ascending: false })
    .limit(limit);

  if (error) {
    console.error("[getAlertEvents] Error:", error);
    return [];
  }

  return (data || []) as WfAlertEvent[];
}

/**
 * Calculate SLA status for a tenant
 */
export async function getSlaStatus(tenantId: string): Promise<SlaStatus> {
  // Get open actions count
  const { count: openActionsCount } = await supabase
    .from("wf_autopilot_actions")
    .select("*", { count: "exact", head: true })
    .eq("tenant_id", tenantId)
    .eq("status", "open");

  // Get critical insights count
  const { count: criticalInsightsCount } = await supabase
    .from("wf_insights")
    .select("*", { count: "exact", head: true })
    .eq("tenant_id", tenantId)
    .eq("status", "open")
    .eq("severity", "critical");

  // Get last successful run
  const { data: lastRuns } = await supabase
    .from("wf_autopilot_runs")
    .select("started_at")
    .eq("tenant_id", tenantId)
    .eq("status", "success")
    .order("started_at", { ascending: false })
    .limit(1);

  let hoursSinceLastRun: number | null = null;
  if (lastRuns && lastRuns.length > 0) {
    const lastRunTime = new Date(lastRuns[0].started_at);
    hoursSinceLastRun = Math.round(
      (Date.now() - lastRunTime.getTime()) / (1000 * 60 * 60)
    );
  }

  // Get last alert
  const { data: lastAlerts } = await supabase
    .from("wf_alert_events")
    .select("*")
    .eq("tenant_id", tenantId)
    .order("created_at", { ascending: false })
    .limit(1);

  const lastAlert = (lastAlerts?.[0] as WfAlertEvent) || null;

  // Determine overall status
  let status: "ok" | "warning" | "critical" = "ok";
  if (lastAlert) {
    if (lastAlert.severity === "critical" || lastAlert.severity === "high") {
      status = "critical";
    } else if (lastAlert.severity === "warning") {
      status = "warning";
    }
  }

  return {
    status,
    open_actions: openActionsCount || 0,
    critical_insights: criticalInsightsCount || 0,
    hours_since_last_run: hoursSinceLastRun,
    last_alert: lastAlert,
  };
}
