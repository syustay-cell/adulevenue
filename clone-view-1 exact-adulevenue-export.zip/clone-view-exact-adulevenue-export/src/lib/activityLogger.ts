import { supabase } from "@/integrations/supabase/client";

interface LogActivityParams {
  actor_user_id?: string;
  actor_email?: string;
  actor_role?: string;
  target_user_id?: string;
  target_email?: string;
  event_type: string;
  context_type: string;
  context_id?: string;
  decision?: 'approved' | 'denied' | 'pending' | 'n/a';
  decision_reason?: string;
  summary: string;
  details?: Record<string, any>;
}

/**
 * Log an activity event to the live activity feed
 * This will appear in real-time in the Admin Activity Command Center
 */
export async function logActivity(params: LogActivityParams) {
  try {
    const { error } = await supabase.functions.invoke('log-activity', {
      body: params,
    });

    if (error) {
      console.error('Failed to log activity:', error);
    }
  } catch (err) {
    console.error('Error logging activity:', err);
  }
}

/**
 * Helper functions for common activity types
 */
export const ActivityLogger = {
  /**
   * Log a new application submission
   */
  newApplication: async (params: {
    actor_user_id?: string;
    actor_email: string;
    actor_role?: string;
    target_user_id?: string;
    target_email: string;
    application_type: 'fast_track' | 'loan' | 'credit_repair';
    application_id: string;
    business_name?: string;
    amount?: string;
  }) => {
    await logActivity({
      actor_user_id: params.actor_user_id,
      actor_email: params.actor_email,
      actor_role: params.actor_role || 'user',
      target_user_id: params.target_user_id,
      target_email: params.target_email,
      event_type: 'new_application',
      context_type: 'funding_case',
      context_id: params.application_id,
      decision: 'pending',
      summary: `New ${params.application_type.replace('_', ' ')} application submitted${params.business_name ? ` – ${params.business_name}` : ''}${params.amount ? ` – $${params.amount}` : ''}`,
      details: {
        application_type: params.application_type,
        business_name: params.business_name,
        amount: params.amount,
      },
    });
  },

  /**
   * Log an application status change
   */
  statusChange: async (params: {
    actor_email: string;
    actor_role?: string;
    target_email: string;
    application_id: string;
    from_status: string;
    to_status: string;
    application_type?: string;
  }) => {
    await logActivity({
      actor_email: params.actor_email,
      actor_role: params.actor_role || 'admin',
      target_email: params.target_email,
      event_type: 'status_change',
      context_type: 'funding_case',
      context_id: params.application_id,
      decision: 'n/a',
      summary: `Application status changed: ${params.from_status} → ${params.to_status}`,
      details: {
        from_status: params.from_status,
        to_status: params.to_status,
        application_type: params.application_type,
      },
    });
  },

  /**
   * Log a worker/ISO approval decision
   */
  workerApproval: async (params: {
    admin_email: string;
    admin_role?: string;
    worker_email: string;
    worker_user_id: string;
    approved: boolean;
    reason?: string;
    worker_type: 'worker' | 'iso';
  }) => {
    await logActivity({
      actor_email: params.admin_email,
      actor_role: params.admin_role || 'admin',
      target_email: params.worker_email,
      target_user_id: params.worker_user_id,
      event_type: params.worker_type === 'iso' ? 'iso_approval' : 'worker_approval',
      context_type: 'user',
      context_id: params.worker_user_id,
      decision: params.approved ? 'approved' : 'denied',
      decision_reason: params.reason,
      summary: `${params.worker_type.toUpperCase()} partner ${params.approved ? 'approved' : 'denied'}${!params.approved && params.reason ? ` – ${params.reason}` : ''}`,
      details: {
        worker_type: params.worker_type,
      },
    });
  },

  /**
   * Log a permission decision
   */
  permissionDecision: async (params: {
    admin_email: string;
    admin_role?: string;
    user_email: string;
    user_id: string;
    permission_type: string;
    approved: boolean;
    reason?: string;
  }) => {
    await logActivity({
      actor_email: params.admin_email,
      actor_role: params.admin_role || 'admin',
      target_email: params.user_email,
      target_user_id: params.user_id,
      event_type: 'permission_decision',
      context_type: 'user',
      context_id: params.user_id,
      decision: params.approved ? 'approved' : 'denied',
      decision_reason: params.reason,
      summary: `Permission request ${params.approved ? 'approved' : 'denied'}: ${params.permission_type}`,
      details: {
        permission_type: params.permission_type,
      },
    });
  },

  /**
   * Log a credit repair case update
   */
  creditCaseUpdate: async (params: {
    actor_email: string;
    actor_role?: string;
    target_email: string;
    case_id: string;
    from_status?: string;
    to_status?: string;
    update_type: string;
    details?: Record<string, any>;
  }) => {
    await logActivity({
      actor_email: params.actor_email,
      actor_role: params.actor_role || 'credit_repair_specialist',
      target_email: params.target_email,
      event_type: 'credit_case_update',
      context_type: 'credit_case',
      context_id: params.case_id,
      decision: 'n/a',
      summary: params.from_status && params.to_status 
        ? `Credit case moved: ${params.from_status} → ${params.to_status}`
        : `Credit case update: ${params.update_type}`,
      details: params.details || {},
    });
  },

  /**
   * Log a document upload
   */
  documentUpload: async (params: {
    actor_email: string;
    target_email: string;
    application_id: string;
    document_type: string;
  }) => {
    await logActivity({
      actor_email: params.actor_email,
      target_email: params.target_email,
      event_type: 'document_upload',
      context_type: 'funding_case',
      context_id: params.application_id,
      decision: 'n/a',
      summary: `Document uploaded: ${params.document_type}`,
      details: {
        document_type: params.document_type,
      },
    });
  },

  /**
   * Log a call/communication event
   */
  callLog: async (params: {
    actor_email: string;
    target_email: string;
    call_type: 'outbound' | 'inbound';
    duration?: string;
    outcome?: string;
    notes?: string;
  }) => {
    await logActivity({
      actor_email: params.actor_email,
      target_email: params.target_email,
      event_type: 'call_log',
      context_type: 'lead',
      decision: 'n/a',
      summary: `${params.call_type === 'outbound' ? 'Called' : 'Received call from'} client${params.outcome ? ` – ${params.outcome}` : ''}`,
      details: {
        call_type: params.call_type,
        duration: params.duration,
        outcome: params.outcome,
        notes: params.notes,
      },
    });
  },
};
