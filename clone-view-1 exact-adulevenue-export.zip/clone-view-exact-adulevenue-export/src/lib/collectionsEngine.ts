// MCA Blueprint Module 3: Collections Engine
import { supabase } from "@/integrations/supabase/client";
import { getSystemModeState, isAutopilot, isEco, isAggressive, type SystemModeState } from "./systemMode";
import { getStrategyConfigFromState, canAutoExecuteFromState, isSeverityAllowed } from "./systemMode/strategyConfig";
import { logActivityEvent } from "./activity";

export type CollectionStatus = 'soft' | 'hard' | 'legal' | 'closed';
export type CollectionEventType = 'call' | 'sms' | 'email' | 'promise' | 'note' | 'status_change' | 'payment' | 'settlement';
export type ActorType = 'AI' | 'WORKER' | 'SYSTEM';

export interface CollectionCase {
  id: string;
  deal_id: string;
  status: CollectionStatus;
  reason: string | null;
  dpd: number;
  assigned_to: string | null;
  strategy: string | null;
  notes: string | null;
  created_at: string;
  updated_at: string;
}

export interface CollectionEvent {
  id: string;
  case_id: string;
  event_type: CollectionEventType;
  channel: string | null;
  actor_type: ActorType;
  actor_id: string | null;
  payload: Record<string, any> | null;
  created_at: string;
}

export interface Settlement {
  id: string;
  deal_id: string;
  case_id: string | null;
  settlement_amount: number;
  original_balance: number;
  discount_pct: number;
  payment_plan_json: Record<string, any> | null;
  status: 'pending' | 'active' | 'completed' | 'defaulted';
  created_by: string | null;
  created_at: string;
}

// DPD thresholds for status transitions
export const DPD_THRESHOLDS = {
  SOFT_MAX: 14,
  HARD_MAX: 29,
  LEGAL_MIN: 30,
} as const;

export function deriveCollectionStatus(dpd: number): CollectionStatus {
  if (dpd <= 0) return 'closed';
  if (dpd <= DPD_THRESHOLDS.SOFT_MAX) return 'soft';
  if (dpd <= DPD_THRESHOLDS.HARD_MAX) return 'hard';
  return 'legal';
}

export function getCollectionStatusColor(status: CollectionStatus): string {
  switch (status) {
    case 'soft': return 'text-yellow-600';
    case 'hard': return 'text-orange-600';
    case 'legal': return 'text-red-600';
    case 'closed': return 'text-green-600';
    default: return 'text-muted-foreground';
  }
}

export function getCollectionStatusBadge(status: CollectionStatus): 'default' | 'destructive' | 'secondary' | 'outline' {
  switch (status) {
    case 'soft': return 'secondary';
    case 'hard': return 'outline';
    case 'legal': return 'destructive';
    case 'closed': return 'default';
    default: return 'secondary';
  }
}

export async function getCollectionCase(dealId: string): Promise<CollectionCase | null> {
  const { data, error } = await supabase
    .from('collection_cases')
    .select('*')
    .eq('deal_id', dealId)
    .single();

  if (error || !data) return null;
  return data as CollectionCase;
}

export async function getAllCollectionCases(statusFilter?: CollectionStatus): Promise<CollectionCase[]> {
  let query = supabase
    .from('collection_cases')
    .select('*')
    .order('dpd', { ascending: false });

  if (statusFilter) {
    query = query.eq('status', statusFilter);
  }

  const { data, error } = await query;
  if (error) return [];
  return (data || []) as CollectionCase[];
}

export async function getCollectionEvents(caseId: string): Promise<CollectionEvent[]> {
  const { data, error } = await supabase
    .from('collection_events')
    .select('*')
    .eq('case_id', caseId)
    .order('created_at', { ascending: false });

  if (error) return [];
  return (data || []) as CollectionEvent[];
}

export async function upsertCollectionCase(
  dealId: string,
  dpd: number,
  reason?: string
): Promise<{ case: CollectionCase | null; created: boolean; error?: string }> {
  const status = deriveCollectionStatus(dpd);

  // Check if case exists
  const existing = await getCollectionCase(dealId);

  if (existing) {
    const oldStatus = existing.status;
    const { data, error } = await supabase
      .from('collection_cases')
      .update({
        dpd,
        status,
        reason: reason || existing.reason,
        updated_at: new Date().toISOString(),
      })
      .eq('id', existing.id)
      .select()
      .single();

    if (error) return { case: null, created: false, error: error.message };

    // Log status change if different
    if (oldStatus !== status) {
      await logCollectionEvent(existing.id, 'status_change', 'SYSTEM', null, null, {
        old_status: oldStatus,
        new_status: status,
        dpd,
      });
    }

    return { case: data as CollectionCase, created: false };
  } else {
    const { data, error } = await supabase
      .from('collection_cases')
      .insert({
        deal_id: dealId,
        dpd,
        status,
        reason,
      })
      .select()
      .single();

    if (error) return { case: null, created: true, error: error.message };
    return { case: data as CollectionCase, created: true };
  }
}

export async function logCollectionEvent(
  caseId: string,
  eventType: CollectionEventType,
  actorType: ActorType,
  actorId: string | null,
  channel: string | null,
  payload: Record<string, any> | null
): Promise<{ success: boolean; error?: string }> {
  const { error } = await supabase
    .from('collection_events')
    .insert({
      case_id: caseId,
      event_type: eventType,
      actor_type: actorType,
      actor_id: actorId,
      channel,
      payload,
    });

  if (error) return { success: false, error: error.message };
  return { success: true };
}

export async function getSettlements(dealId: string): Promise<Settlement[]> {
  const { data, error } = await supabase
    .from('settlements')
    .select('*')
    .eq('deal_id', dealId)
    .order('created_at', { ascending: false });

  if (error) return [];
  return (data || []) as Settlement[];
}

export async function createSettlement(
  dealId: string,
  caseId: string | null,
  settlementAmount: number,
  originalBalance: number,
  paymentPlan?: Record<string, any>,
  createdBy?: string
): Promise<{ settlement: Settlement | null; error?: string }> {
  const discountPct = ((originalBalance - settlementAmount) / originalBalance) * 100;

  const { data, error } = await supabase
    .from('settlements')
    .insert({
      deal_id: dealId,
      case_id: caseId,
      settlement_amount: settlementAmount,
      original_balance: originalBalance,
      discount_pct: discountPct,
      payment_plan_json: paymentPlan || null,
      created_by: createdBy || null,
      status: 'pending',
    })
    .select()
    .single();

  if (error) return { settlement: null, error: error.message };

  // Log settlement creation
  if (caseId) {
    await logCollectionEvent(caseId, 'settlement', 'WORKER', createdBy || null, null, {
      settlement_amount: settlementAmount,
      discount_pct: discountPct,
    });
  }

  return { settlement: data as Settlement };
}

export async function updateSettlementStatus(
  settlementId: string,
  status: 'active' | 'completed' | 'defaulted'
): Promise<{ success: boolean; error?: string }> {
  const { error } = await supabase
    .from('settlements')
    .update({ status, updated_at: new Date().toISOString() })
    .eq('id', settlementId);

  if (error) return { success: false, error: error.message };
  return { success: true };
}

export function getSeverityLevel(dpd: number): 'low' | 'medium' | 'high' | 'critical' {
  if (dpd <= 7) return 'low';
  if (dpd <= 14) return 'medium';
  if (dpd <= 29) return 'high';
  return 'critical';
}

export function getRecommendedActions(dpd: number, lastContactDays: number): string[] {
  const actions: string[] = [];
  const severity = getSeverityLevel(dpd);

  if (lastContactDays > 2) {
    actions.push('Contact merchant - no recent activity');
  }

  switch (severity) {
    case 'low':
      actions.push('Send friendly reminder SMS');
      actions.push('Schedule courtesy call');
      break;
    case 'medium':
      actions.push('Escalate outreach frequency');
      actions.push('Request payment plan discussion');
      break;
    case 'high':
      actions.push('Issue formal demand letter');
      actions.push('Consider settlement options');
      break;
    case 'critical':
      actions.push('Initiate legal review');
      actions.push('Prepare legal demand');
      actions.push('Evaluate asset recovery');
      break;
  }

  return actions;
}

export function formatDPD(dpd: number): string {
  if (dpd === 0) return 'Current';
  if (dpd === 1) return '1 day past due';
  return `${dpd} days past due`;
}

/**
 * Strategy-aware collections tick handler
 * Uses STRATEGY_CONFIG for all limits and severities
 * ECO: only LOW severity, reduced volume (~50%)
 * STANDARD: LOW + MEDIUM severity auto-actions
 * AGGRESSIVE: LOW + MEDIUM + HIGH, full volume
 * MANUAL: only logs recommendations
 */
export async function handleCollectionsTick(deals: { id: string; dpd: number; last_contact_days?: number; merchant_name?: string }[]): Promise<{
  processed: number;
  autoActions: number;
  recommendations: { dealId: string; severity: string; actions: string[] }[];
}> {
  const modeState = await getSystemModeState();
  const strategy = getStrategyConfigFromState(modeState);
  const canAuto = canAutoExecuteFromState(modeState);
  const eco = isEco(modeState);
  
  const recommendations: { dealId: string; severity: string; actions: string[] }[] = [];
  let autoActions = 0;

  // ECO mode: reduce volume by ~50% (process every other deal)
  const dealsToProcess = eco ? deals.filter((_, i) => i % 2 === 0) : deals;

  for (const deal of dealsToProcess) {
    // Check daily cap
    if (autoActions >= strategy.maxAutoCollectionsPerDay) break;

    const severity = getSeverityLevel(deal.dpd);
    const recommended = getRecommendedActions(deal.dpd, deal.last_contact_days || 99);

    // Always log recommendations
    recommendations.push({
      dealId: deal.id,
      severity,
      actions: recommended,
    });

    // Ensure case exists
    await upsertCollectionCase(deal.id, deal.dpd);

    const merchantName = deal.merchant_name || `Deal ${deal.id.slice(0, 8)}`;
    const modeLabel = `${modeState.executionMode} · ${modeState.strategyProfile}`;

    if (canAuto) {
      // Check if this severity is allowed by strategy config
      const severityAllowed = isSeverityAllowed(modeState.strategyProfile, severity);

      if (severityAllowed) {
        autoActions++;
        const collCase = await getCollectionCase(deal.id);
        if (collCase) {
          const channel = severity === 'low' ? 'sms' : 'email';
          const eventType = severity === 'low' ? 'friendly_reminder' : 
                           severity === 'medium' ? 'escalation_notice' : 'high_severity_notice';

          await logCollectionEvent(collCase.id, channel as any, 'AI', null, channel, {
            type: eventType,
            automated: true,
            severity,
            strategy: modeState.strategyProfile,
          });
          
          await logActivityEvent({
            actorType: 'AI',
            scope: 'COLLECTIONS',
            eventType: 'ACTION',
            decision: 'AUTO_ACTION',
            severity: severity.toUpperCase() as 'LOW' | 'MEDIUM' | 'HIGH',
            dealId: deal.id,
            summary: `${eventType.replace(/_/g, ' ')} sent to ${merchantName} (${deal.dpd} DPD)`,
            details: { deal_id: deal.id, dpd: deal.dpd, case_id: collCase.id, mode: modeLabel, channel },
          });
        }
      } else {
        // Severity not allowed by strategy - escalate for human review
        await logActivityEvent({
          actorType: 'AI',
          scope: 'COLLECTIONS',
          eventType: 'DECISION',
          decision: 'ESCALATED',
          severity: severity.toUpperCase() as 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL',
          dealId: deal.id,
          summary: `Collection action proposed for ${merchantName}: ${recommended[0] || 'Review case'}`,
          details: { deal_id: deal.id, dpd: deal.dpd, recommended, mode: modeLabel, reason: `${severity} severity not auto-allowed in ${modeState.strategyProfile}` },
        });
      }
    } else {
      // Manual/Optimization mode - log proposal only
      await logActivityEvent({
        actorType: 'AI',
        scope: 'COLLECTIONS',
        eventType: 'DECISION',
        decision: 'INFO',
        severity: severity.toUpperCase() as 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL',
        dealId: deal.id,
        summary: `Collection action proposed for ${merchantName}: ${recommended[0] || 'Review case'}`,
        details: { deal_id: deal.id, dpd: deal.dpd, recommended, mode: 'MANUAL' },
      });
    }
  }

  return {
    processed: dealsToProcess.length,
    autoActions,
    recommendations,
  };
}
