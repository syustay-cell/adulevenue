// MCA Blueprint Module 6: Rule Engine
import { supabase } from "@/integrations/supabase/client";
import { getSystemMode, isAutopilotEnabled, type SystemMode } from "./systemMode";
import { logActivityEvent } from "./activityLogClient";

export type RuleScope = 'UNDERWRITING' | 'COLLECTIONS' | 'RENEWALS';
export type RuleOperator = '>' | '>=' | '<' | '<=' | '=' | '!=' | 'in' | 'not_in' | 'between';
export type RuleAction = 'DECLINE' | 'FLAG' | 'LIMIT_AMOUNT' | 'ROUTE_TO_SENIOR' | 'REQUIRE_DOCS' | 'ESCALATE' | 'BLOCK_RENEWAL';

export interface UwRuleSet {
  id: string;
  name: string;
  description: string | null;
  version: number;
  is_active: boolean;
}

export interface UwRule {
  id: string;
  rule_set_id: string;
  scope: RuleScope;
  field: string;
  operator: RuleOperator;
  value_json: any;
  action: RuleAction;
  params_json: Record<string, any> | null;
  priority: number;
  is_active: boolean;
}

export interface RuleOutcome {
  decisions: RuleAction[];
  flags: string[];
  limits: Record<string, any>;
  triggered_rules: { rule_id: string; field: string; action: RuleAction; reason: string }[];
}

// Common field mappings for display
export const RULE_FIELD_LABELS: Record<string, string> = {
  nsf_last_30: 'NSF (Last 30 Days)',
  nsf_last_90: 'NSF (Last 90 Days)',
  avg_daily_balance: 'Average Daily Balance',
  avg_monthly_revenue: 'Average Monthly Revenue',
  time_in_business_months: 'Time in Business (Months)',
  fico: 'FICO Score',
  risk_score: 'Risk Score',
  stack_count: 'Existing Positions',
  dpd: 'Days Past Due',
  paid_pct: 'Paid Percentage',
  last_contact_days: 'Days Since Last Contact',
  deal_balance: 'Outstanding Balance',
  negative_balance_days: 'Negative Balance Days',
  avg_ending_balance: 'Average Ending Balance',
};

export const RULE_OPERATOR_LABELS: Record<RuleOperator, string> = {
  '>': 'greater than',
  '>=': 'greater than or equal to',
  '<': 'less than',
  '<=': 'less than or equal to',
  '=': 'equals',
  '!=': 'not equals',
  'in': 'in list',
  'not_in': 'not in list',
  'between': 'between',
};

export const RULE_ACTION_LABELS: Record<RuleAction, string> = {
  DECLINE: 'Auto-Decline',
  FLAG: 'Flag for Review',
  LIMIT_AMOUNT: 'Limit Approval Amount',
  ROUTE_TO_SENIOR: 'Route to Senior UW',
  REQUIRE_DOCS: 'Require Additional Docs',
  ESCALATE: 'Escalate Case',
  BLOCK_RENEWAL: 'Block Renewal',
};

export async function getActiveRuleSet(): Promise<UwRuleSet | null> {
  const { data, error } = await supabase
    .from('uw_rule_sets')
    .select('*')
    .eq('is_active', true)
    .order('version', { ascending: false })
    .limit(1)
    .single();

  if (error || !data) {
    // Return default rule set
    return {
      id: 'default',
      name: 'Standard MCA v1',
      description: 'Default underwriting rules',
      version: 1,
      is_active: true,
    };
  }
  return data as UwRuleSet;
}

export async function getAllRuleSets(): Promise<UwRuleSet[]> {
  const { data, error } = await supabase
    .from('uw_rule_sets')
    .select('*')
    .order('version', { ascending: false });

  if (error) return [];
  return (data || []) as UwRuleSet[];
}

export async function getRulesForScope(ruleSetId: string, scope: RuleScope): Promise<UwRule[]> {
  const { data, error } = await supabase
    .from('uw_rules')
    .select('*')
    .eq('rule_set_id', ruleSetId)
    .eq('scope', scope)
    .eq('is_active', true)
    .order('priority');

  if (error) return [];
  return (data || []) as UwRule[];
}

export async function getAllRules(ruleSetId: string): Promise<UwRule[]> {
  const { data, error } = await supabase
    .from('uw_rules')
    .select('*')
    .eq('rule_set_id', ruleSetId)
    .order('priority');

  if (error) return [];
  return (data || []) as UwRule[];
}

function evaluateCondition(
  fieldValue: any,
  operator: RuleOperator,
  ruleValue: any
): boolean {
  if (fieldValue === null || fieldValue === undefined) {
    return false;
  }

  switch (operator) {
    case '>':
      return Number(fieldValue) > Number(ruleValue);
    case '>=':
      return Number(fieldValue) >= Number(ruleValue);
    case '<':
      return Number(fieldValue) < Number(ruleValue);
    case '<=':
      return Number(fieldValue) <= Number(ruleValue);
    case '=':
      return fieldValue === ruleValue;
    case '!=':
      return fieldValue !== ruleValue;
    case 'in':
      return Array.isArray(ruleValue) && ruleValue.includes(fieldValue);
    case 'not_in':
      return Array.isArray(ruleValue) && !ruleValue.includes(fieldValue);
    case 'between':
      if (Array.isArray(ruleValue) && ruleValue.length === 2) {
        const num = Number(fieldValue);
        return num >= Number(ruleValue[0]) && num <= Number(ruleValue[1]);
      }
      return false;
    default:
      return false;
  }
}

export function evaluateRules(
  scope: RuleScope,
  context: Record<string, any>,
  rules: UwRule[]
): RuleOutcome {
  const outcome: RuleOutcome = {
    decisions: [],
    flags: [],
    limits: {},
    triggered_rules: [],
  };

  // Filter rules by scope and sort by priority
  const scopeRules = rules
    .filter(r => r.scope === scope && r.is_active)
    .sort((a, b) => a.priority - b.priority);

  for (const rule of scopeRules) {
    const fieldValue = context[rule.field];
    const triggered = evaluateCondition(fieldValue, rule.operator, rule.value_json);

    if (triggered) {
      const fieldLabel = RULE_FIELD_LABELS[rule.field] || rule.field;
      const operatorLabel = RULE_OPERATOR_LABELS[rule.operator];
      const reason = `${fieldLabel} (${fieldValue}) ${operatorLabel} ${JSON.stringify(rule.value_json)}`;

      outcome.triggered_rules.push({
        rule_id: rule.id,
        field: rule.field,
        action: rule.action,
        reason,
      });

      // Apply action
      switch (rule.action) {
        case 'DECLINE':
        case 'ROUTE_TO_SENIOR':
        case 'ESCALATE':
        case 'BLOCK_RENEWAL':
          if (!outcome.decisions.includes(rule.action)) {
            outcome.decisions.push(rule.action);
          }
          break;
        case 'FLAG':
        case 'REQUIRE_DOCS':
          outcome.flags.push(reason);
          break;
        case 'LIMIT_AMOUNT':
          if (rule.params_json?.limit_pct) {
            outcome.limits.max_amount_pct = Math.min(
              outcome.limits.max_amount_pct || 1,
              rule.params_json.limit_pct
            );
          }
          if (rule.params_json?.max_amount) {
            outcome.limits.max_amount = Math.min(
              outcome.limits.max_amount || Infinity,
              rule.params_json.max_amount
            );
          }
          break;
      }
    }
  }

  return outcome;
}

export async function evaluateUnderwritingRules(context: Record<string, any>): Promise<RuleOutcome> {
  const ruleSet = await getActiveRuleSet();
  if (!ruleSet || ruleSet.id === 'default') {
    return { decisions: [], flags: [], limits: {}, triggered_rules: [] };
  }

  const rules = await getRulesForScope(ruleSet.id, 'UNDERWRITING');
  return evaluateRules('UNDERWRITING', context, rules);
}

export async function evaluateCollectionsRules(context: Record<string, any>): Promise<RuleOutcome> {
  const ruleSet = await getActiveRuleSet();
  if (!ruleSet || ruleSet.id === 'default') {
    return { decisions: [], flags: [], limits: {}, triggered_rules: [] };
  }

  const rules = await getRulesForScope(ruleSet.id, 'COLLECTIONS');
  return evaluateRules('COLLECTIONS', context, rules);
}

export async function evaluateRenewalRules(context: Record<string, any>): Promise<RuleOutcome> {
  const ruleSet = await getActiveRuleSet();
  if (!ruleSet || ruleSet.id === 'default') {
    return { decisions: [], flags: [], limits: {}, triggered_rules: [] };
  }

  const rules = await getRulesForScope(ruleSet.id, 'RENEWALS');
  return evaluateRules('RENEWALS', context, rules);
}

export function hasDeclineDecision(outcome: RuleOutcome): boolean {
  return outcome.decisions.includes('DECLINE');
}

export function requiresSeniorReview(outcome: RuleOutcome): boolean {
  return outcome.decisions.includes('ROUTE_TO_SENIOR');
}

export function isRenewalBlocked(outcome: RuleOutcome): boolean {
  return outcome.decisions.includes('BLOCK_RENEWAL');
}

export function getActionColor(action: RuleAction): string {
  switch (action) {
    case 'DECLINE': return 'text-red-600';
    case 'ROUTE_TO_SENIOR': return 'text-orange-600';
    case 'ESCALATE': return 'text-orange-600';
    case 'FLAG': return 'text-yellow-600';
    case 'REQUIRE_DOCS': return 'text-blue-600';
    case 'LIMIT_AMOUNT': return 'text-purple-600';
    case 'BLOCK_RENEWAL': return 'text-red-600';
    default: return 'text-muted-foreground';
  }
}

export type AutoDecision = 'DECLINE' | 'ROUTE_TO_SENIOR' | 'APPROVE_OR_COUNTER' | null;

/**
 * Autopilot-aware underwriting decision processor
 * In MANUAL mode: no auto decisions, just returns outcome for human review
 * In AUTOPILOT: applies DECLINE/ROUTE/BLOCK automatically
 * In OPTIMIZATION: same as manual (owner is tuning the system)
 */
export async function processUnderwritingDecision(
  context: Record<string, any>,
  merchantName?: string
): Promise<{ outcome: RuleOutcome; autoDecision: AutoDecision; mode: SystemMode }> {
  const mode = await getSystemMode();
  const outcome = await evaluateUnderwritingRules(context);
  const name = merchantName || `Application`;

  // Log to activity feed
  if (outcome.triggered_rules.length > 0) {
    const isAuto = isAutopilotEnabled(mode);
    const firstTriggered = outcome.triggered_rules[0];
    
    await logActivityEvent({
      module: 'UNDERWRITING',
      actor: 'AI_AUTOPILOT',
      mode,
      severity: hasDeclineDecision(outcome) ? 'high' : requiresSeniorReview(outcome) ? 'medium' : 'low',
      title: `Underwriting rules triggered for ${name}`,
      summary: `${outcome.triggered_rules.length} rule(s) triggered. Primary: ${firstTriggered.reason}`,
      proposed_action: firstTriggered.action,
      auto_executed: isAuto && (hasDeclineDecision(outcome) || requiresSeniorReview(outcome)),
      context: { triggered_rules: outcome.triggered_rules, decisions: outcome.decisions },
    });
  }

  if (mode === 'MANUAL' || mode === 'OPTIMIZATION_PILOT') {
    return { outcome, autoDecision: null, mode };
  }

  // AUTOPILOT mode - apply automatic decisions
  if (hasDeclineDecision(outcome)) {
    return { outcome, autoDecision: 'DECLINE', mode };
  }

  if (requiresSeniorReview(outcome)) {
    return { outcome, autoDecision: 'ROUTE_TO_SENIOR', mode };
  }

  return { outcome, autoDecision: 'APPROVE_OR_COUNTER', mode };
}

/**
 * Autopilot-aware collections decision processor
 */
export async function processCollectionsDecision(
  context: Record<string, any>
): Promise<{ outcome: RuleOutcome; autoEscalate: boolean; mode: SystemMode }> {
  const mode = await getSystemMode();
  const outcome = await evaluateCollectionsRules(context);

  const autoEscalate = isAutopilotEnabled(mode) && outcome.decisions.includes('ESCALATE');

  return { outcome, autoEscalate, mode };
}

/**
 * Autopilot-aware renewal decision processor
 */
export async function processRenewalDecision(
  context: Record<string, any>
): Promise<{ outcome: RuleOutcome; blocked: boolean; mode: SystemMode }> {
  const mode = await getSystemMode();
  const outcome = await evaluateRenewalRules(context);

  // Renewals are blocked if rule says so, regardless of mode
  const blocked = isRenewalBlocked(outcome);

  return { outcome, blocked, mode };
}
