// MCA Blueprint Module 1: Compliance OS
import { supabase } from "@/integrations/supabase/client";

export type ComplianceDealStatus = 'pending' | 'pass' | 'fail';

export interface ComplianceStateRule {
  id: string;
  state_code: string;
  product_type: string;
  requires_apr_disclosure: boolean;
  prohibits_coj: boolean;
  broker_license_required: boolean;
  disclosure_template_id: string | null;
  notes: string | null;
}

export interface ComplianceDealCheck {
  id: string;
  deal_id: string;
  check_key: string;
  status: 'pending' | 'pass' | 'fail' | 'waived';
  checked_by: string | null;
  checked_at: string | null;
  notes: string | null;
}

export interface ComplianceSnapshot {
  overall_status: ComplianceDealStatus;
  checks: ComplianceDealCheck[];
  state_rules: ComplianceStateRule | null;
  template: { id: string; name: string; body_markdown: string } | null;
  missing_checks: string[];
}

export const STANDARD_COMPLIANCE_CHECKS = [
  'kyc_passed',
  'bank_login_verified',
  'sos_check',
  'identity_verified',
  'business_verified',
  'disclosure_signed',
  'ach_authorized',
  'contract_signed',
] as const;

export const CHECK_LABELS: Record<string, string> = {
  kyc_passed: 'KYC Verification',
  bank_login_verified: 'Bank Login Verified',
  sos_check: 'Secretary of State Check',
  identity_verified: 'Identity Verified',
  business_verified: 'Business Verified',
  disclosure_signed: 'Disclosure Signed',
  ach_authorized: 'ACH Authorization',
  contract_signed: 'Contract Signed',
};

export async function getStateRules(stateCode: string, productType: string = 'MCA'): Promise<ComplianceStateRule | null> {
  const { data, error } = await supabase
    .from('compliance_states')
    .select('*')
    .eq('state_code', stateCode)
    .eq('product_type', productType)
    .eq('is_active', true)
    .single();

  if (error || !data) return null;
  return data as ComplianceStateRule;
}

export async function getAllStateRules(): Promise<ComplianceStateRule[]> {
  const { data, error } = await supabase
    .from('compliance_states')
    .select('*')
    .eq('is_active', true)
    .order('state_code');

  if (error) return [];
  return (data || []) as ComplianceStateRule[];
}

export async function getDisclosureTemplate(templateId: string): Promise<{ id: string; name: string; body_markdown: string } | null> {
  const { data, error } = await supabase
    .from('compliance_disclosure_templates')
    .select('id, name, body_markdown')
    .eq('id', templateId)
    .eq('is_active', true)
    .single();

  if (error || !data) return null;
  return data;
}

export async function getDealChecks(dealId: string): Promise<ComplianceDealCheck[]> {
  const { data, error } = await supabase
    .from('compliance_deal_checks')
    .select('*')
    .eq('deal_id', dealId)
    .order('created_at');

  if (error) return [];
  return (data || []) as ComplianceDealCheck[];
}

export async function getDealComplianceSnapshot(dealId: string, stateCode?: string, productType?: string): Promise<ComplianceSnapshot> {
  // Get all checks for this deal
  const checks = await getDealChecks(dealId);
  
  // Get state rules if state is provided
  let stateRules: ComplianceStateRule | null = null;
  let template: { id: string; name: string; body_markdown: string } | null = null;
  
  if (stateCode) {
    stateRules = await getStateRules(stateCode, productType || 'MCA');
    if (stateRules?.disclosure_template_id) {
      template = await getDisclosureTemplate(stateRules.disclosure_template_id);
    }
  }

  // Determine which checks are missing
  const existingCheckKeys = new Set(checks.map(c => c.check_key));
  const missing_checks = STANDARD_COMPLIANCE_CHECKS.filter(key => !existingCheckKeys.has(key));

  // Calculate overall status
  const hasFailed = checks.some(c => c.status === 'fail');
  const hasPending = checks.some(c => c.status === 'pending') || missing_checks.length > 0;
  
  let overall_status: ComplianceDealStatus;
  if (hasFailed) {
    overall_status = 'fail';
  } else if (hasPending) {
    overall_status = 'pending';
  } else {
    overall_status = 'pass';
  }

  return {
    overall_status,
    checks,
    state_rules: stateRules,
    template,
    missing_checks,
  };
}

export async function upsertDealCheck(
  dealId: string,
  checkKey: string,
  status: 'pending' | 'pass' | 'fail' | 'waived',
  notes?: string,
  checkedBy?: string
): Promise<{ success: boolean; error?: string }> {
  // Check if existing
  const { data: existing } = await supabase
    .from('compliance_deal_checks')
    .select('id')
    .eq('deal_id', dealId)
    .eq('check_key', checkKey)
    .single();

  if (existing) {
    const { error } = await supabase
      .from('compliance_deal_checks')
      .update({
        status,
        notes,
        checked_by: checkedBy || null,
        checked_at: status !== 'pending' ? new Date().toISOString() : null,
        updated_at: new Date().toISOString(),
      })
      .eq('id', existing.id);

    if (error) return { success: false, error: error.message };
  } else {
    const { error } = await supabase
      .from('compliance_deal_checks')
      .insert({
        deal_id: dealId,
        check_key: checkKey,
        status,
        notes,
        checked_by: checkedBy || null,
        checked_at: status !== 'pending' ? new Date().toISOString() : null,
      });

    if (error) return { success: false, error: error.message };
  }

  return { success: true };
}

export async function initializeDealChecks(dealId: string): Promise<{ success: boolean; error?: string }> {
  // Insert all standard checks as pending
  const checks = STANDARD_COMPLIANCE_CHECKS.map(key => ({
    deal_id: dealId,
    check_key: key,
    status: 'pending',
  }));

  const { error } = await supabase
    .from('compliance_deal_checks')
    .insert(checks);

  if (error) return { success: false, error: error.message };
  return { success: true };
}

export function getComplianceStatusColor(status: ComplianceDealStatus): string {
  switch (status) {
    case 'pass': return 'text-green-600';
    case 'fail': return 'text-red-600';
    case 'pending': return 'text-yellow-600';
    default: return 'text-muted-foreground';
  }
}

export function getComplianceStatusBadge(status: ComplianceDealStatus): 'default' | 'destructive' | 'secondary' {
  switch (status) {
    case 'pass': return 'default';
    case 'fail': return 'destructive';
    case 'pending': return 'secondary';
    default: return 'secondary';
  }
}

export function getCheckStatusColor(status: string): string {
  switch (status) {
    case 'pass': return 'text-green-600';
    case 'fail': return 'text-red-600';
    case 'waived': return 'text-blue-600';
    case 'pending': return 'text-yellow-600';
    default: return 'text-muted-foreground';
  }
}
