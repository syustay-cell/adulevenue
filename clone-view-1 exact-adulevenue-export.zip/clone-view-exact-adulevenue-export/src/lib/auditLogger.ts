/**
 * Phase 2 Audit Logger
 * Central audit logging service for Wolf Fund Universal File System
 * 
 * ALL audit logging MUST go through this single function.
 * Direct inserts to audit_logs from components are NOT allowed.
 */

import { supabase } from '@/integrations/supabase/client';
import type { Database } from '@/integrations/supabase/types';

type AuditLogInsert = Database['public']['Tables']['audit_logs']['Insert'];
type Json = Database['public']['Tables']['audit_logs']['Row']['changes'];

/**
 * Allowed action types for audit logging
 */
export type AuditActionType = 
  | 'vault_access'    // Opening client_vault (PII)
  | 'panel_open'      // Opening Puzzle Panel for a client
  | 'view'            // Generic read (matches DB constraint if present)
  | 'create'          // Generic create (matches DB constraint if present)
  | 'update'          // Generic update (matches DB constraint if present)
  | 'delete'          // Generic delete (matches DB constraint if present)
  | 'export'          // Exporting data (CSV, Excel, PDF)
  | 'approve'         // Generic approve (matches DB constraint if present)
  | 'reject'          // Generic reject (matches DB constraint if present)
  | 'send'            // Generic send (matches DB constraint if present)
  | 'sign'            // Generic sign (matches DB constraint if present)
  | 'download'        // Downloading a document
  | 'status_change';  // Changing case/deal status

/**
 * Parameters for logging an audit event
 */
export interface AuditEventParams {
  /** Type of action being logged */
  actionType: AuditActionType;
  /** Type of resource being accessed (e.g., 'client_vault', 'intake_clients', 'document') */
  resourceType: string;
  /** ID of the resource being accessed */
  resourceId: string;
  /** Optional: ID of the intake_client this action relates to */
  intakeClientId?: string;
  /** Optional: Name of the database table being affected */
  tableName?: string;
  /** Optional: New values after the change (for status_change) */
  changes?: Record<string, unknown>;
  /** Optional: Previous values before the change (for status_change) */
  previousValues?: Record<string, unknown>;
}

/**
 * Log an audit event to the audit_logs table
 * 
 * This is the ONLY function that should insert into audit_logs.
 * All components must import and use this function.
 * 
 * @param params - The audit event parameters
 * @returns Promise<void> - Resolves when logging is complete (or fails silently)
 * 
 * @example
 * // Log vault access
 * await logAuditEvent({
 *   actionType: 'vault_access',
 *   resourceType: 'client_vault',
 *   resourceId: intakeClientId,
 *   intakeClientId: intakeClientId,
 *   tableName: 'client_vault'
 * });
 * 
 * @example
 * // Log status change
 * await logAuditEvent({
 *   actionType: 'status_change',
 *   resourceType: 'credit_repair_cases',
 *   resourceId: caseId,
 *   intakeClientId: intakeClientId,
 *   tableName: 'credit_repair_cases',
 *   previousValues: { status: 'intake' },
 *   changes: { status: 'in_progress' }
 * });
 */
export async function logAuditEvent(params: AuditEventParams): Promise<void> {
  try {
    // Get current authenticated user
    const { data: { user }, error: userError } = await supabase.auth.getUser();
    
    if (userError || !user) {
      console.error('[AuditLogger] Failed to get current user:', userError?.message || 'No user');
      return; // Silent fail - don't break UI
    }

    // Attempt to get user agent and prepare audit record
    const userAgent = typeof window !== 'undefined' ? window.navigator.userAgent : null;

    // Build the audit log record with proper typing
    const auditRecord: AuditLogInsert = {
      user_id: user.id,
      action_type: params.actionType,
      resource_type: params.resourceType,
      resource_id: params.resourceId,
      intake_client_id: params.intakeClientId ?? null,
      table_name: params.tableName ?? null,
      changes: (params.changes ?? null) as Json,
      previous_values: (params.previousValues ?? null) as Json,
      user_agent: userAgent,
    };

    // Insert audit log entry
    const { error: insertError } = await supabase
      .from('audit_logs')
      .insert([auditRecord]);

    if (insertError) {
      console.error('[AuditLogger] Failed to insert audit log:', insertError.message);
      return; // Silent fail - don't break UI
    }

    // Success - no console log in production to avoid noise
  } catch (err) {
    // Catch-all for any unexpected errors
    console.error('[AuditLogger] Unexpected error:', err instanceof Error ? err.message : 'Unknown error');
    // Silent fail - audit logging should NEVER break the UI
  }
}

/**
 * Helper to log vault access specifically
 * Convenience wrapper for the common vault_access action
 */
export async function logVaultAccess(intakeClientId: string): Promise<void> {
  return logAuditEvent({
    actionType: 'vault_access',
    resourceType: 'client_vault',
    resourceId: intakeClientId,
    intakeClientId,
    tableName: 'client_vault',
  });
}

/**
 * Helper to log panel open specifically
 * Convenience wrapper for the common panel_open action
 */
export async function logPanelOpen(intakeClientId: string): Promise<void> {
  return logAuditEvent({
    actionType: 'panel_open',
    resourceType: 'intake_clients',
    resourceId: intakeClientId,
    intakeClientId,
    tableName: 'intake_clients',
  });
}

/**
 * Helper to log export actions
 * Convenience wrapper for export logging
 */
export async function logExport(params: {
  exportType: string;
  tableName: string;
  rowCount?: number;
  format?: string;
}): Promise<void> {
  return logAuditEvent({
    actionType: 'export',
    resourceType: 'export',
    resourceId: params.exportType,
    tableName: params.tableName,
    changes: {
      format: params.format,
      rowCount: params.rowCount,
    },
  });
}

/**
 * Helper to log document downloads
 * Convenience wrapper for download logging
 */
export async function logDownload(params: {
  documentId: string;
  documentName?: string;
  intakeClientId?: string;
}): Promise<void> {
  return logAuditEvent({
    actionType: 'download',
    resourceType: 'document',
    resourceId: params.documentId,
    intakeClientId: params.intakeClientId,
    changes: {
      documentName: params.documentName,
    },
  });
}

/**
 * Helper to log status changes
 * Convenience wrapper for status_change logging
 */
export async function logStatusChange(params: {
  tableName: string;
  recordId: string;
  intakeClientId?: string;
  previousStatus: string;
  newStatus: string;
}): Promise<void> {
  return logAuditEvent({
    actionType: 'status_change',
    resourceType: params.tableName,
    resourceId: params.recordId,
    intakeClientId: params.intakeClientId,
    tableName: params.tableName,
    previousValues: { status: params.previousStatus },
    changes: { status: params.newStatus },
  });
}
