/**
 * Phase 2 Permissions Layer - Extended for Multi-Tenant Ecosystem
 * Central permission helpers for Wolf Fund Universal File System
 */

export type AppRole =
  | 'super_owner'
  | 'owner'
  | 'ceo'
  | 'cfo'
  | 'clo'
  | 'tenant_owner'
  | 'tenant_admin'
  | 'tenant_worker'
  | 'partner_owner'
  | 'partner_worker'
  | 'partner_factory'
  | 'admin'
  | 'win_director'
  | 'underwriter'
  | 'credit_repair_specialist'
  | 'legal'
  | 'legal_worker'
  | 'wolf_worker'
  | 'worker'
  | 'merchant_services_partner'
  | 'funder'
  | 'investor'
  | 'gov_donor'
  | 'iso'
  | 'iso_partner'
  | 'merchant'
  | 'client'
  | 'user';

/**
 * Role hierarchy from highest to lowest privilege
 */
const ROLE_HIERARCHY: AppRole[] = [
  'super_owner',
  'owner',
  'ceo',
  'cfo',
  'clo',
  'tenant_owner',
  'tenant_admin',
  'partner_owner',
  'admin',
  'win_director',
  'underwriter',
  'legal',
  'legal_worker',
  'credit_repair_specialist',
  'wolf_worker',
  'worker',
  'tenant_worker',
  'partner_worker',
  'partner_factory',
  'merchant_services_partner',
  'funder',
  'investor',
  'gov_donor',
  'iso',
  'iso_partner',
  'merchant',
  'client',
  'user',
];

/**
 * Tab visibility map for Puzzle Panel
 */
const TAB_VISIBILITY: Record<string, AppRole[]> = {
  Timeline: ['super_owner', 'owner', 'ceo', 'cfo', 'clo', 'legal', 'legal_worker', 'tenant_admin', 'admin', 'worker', 'wolf_worker', 'tenant_worker', 'partner_worker', 'win_director', 'iso_partner'],
  Notes: ['super_owner', 'owner', 'ceo', 'cfo', 'clo', 'legal', 'legal_worker', 'tenant_admin', 'admin', 'worker', 'wolf_worker', 'tenant_worker', 'win_director'],
  Funding: ['super_owner', 'owner', 'ceo', 'cfo', 'clo', 'legal', 'legal_worker', 'tenant_admin', 'admin', 'worker', 'wolf_worker', 'tenant_worker', 'partner_worker', 'win_director', 'iso_partner', 'funder', 'investor'],
  Credit: ['super_owner', 'owner', 'ceo', 'cfo', 'clo', 'legal', 'legal_worker', 'tenant_admin', 'admin', 'worker', 'wolf_worker', 'credit_repair_specialist'],
  Collections: ['super_owner', 'owner', 'ceo', 'cfo', 'clo', 'legal', 'legal_worker', 'tenant_admin', 'admin', 'worker', 'wolf_worker'],
  Merchant: ['super_owner', 'owner', 'ceo', 'cfo', 'clo', 'legal', 'legal_worker', 'tenant_admin', 'admin', 'worker', 'wolf_worker', 'merchant_services_partner'],
  Tasks: ['super_owner', 'owner', 'ceo', 'cfo', 'clo', 'legal', 'legal_worker', 'tenant_admin', 'admin', 'worker', 'wolf_worker', 'tenant_worker', 'win_director'],
};

/**
 * Dashboard routing map based on highest role
 */
const DASHBOARD_ROUTES: Record<AppRole, string> = {
  super_owner: '/owner/motherboard',
  owner: '/owner/events',
  ceo: '/ceo',
  cfo: '/cfo',
  clo: '/clo',
  tenant_owner: '/partner/dashboard',
  tenant_admin: '/partner/dashboard',
  partner_owner: '/partner/dashboard',
  admin: '/admin-dashboard',
  win_director: '/win-director',
  legal: '/legal/dashboard',
  legal_worker: '/legal/dashboard',
  underwriter: '/underwriting',
  credit_repair_specialist: '/credit-specialist-dashboard',
  wolf_worker: '/worker-dashboard',
  worker: '/worker-dashboard',
  tenant_worker: '/partner/dashboard',
  partner_worker: '/partner/dashboard',
  partner_factory: '/partner/factory',
  merchant_services_partner: '/ms/dashboard',
  funder: '/funder/portal',
  investor: '/investor',
  gov_donor: '/donors',
  iso: '/iso-portal',
  iso_partner: '/iso-portal',
  merchant: '/client-dashboard',
  client: '/client-dashboard',
  user: '/',
};

/**
 * Check if user has any of the required roles
 */
export function hasRole(userRoles: AppRole[], needed: AppRole | AppRole[]): boolean {
  const requiredRoles = Array.isArray(needed) ? needed : [needed];
  return userRoles.some((role) => requiredRoles.includes(role));
}

/**
 * Check if user can access the client vault (PII data)
 */
export function canAccessVault(userRoles: AppRole[]): boolean {
  return hasRole(userRoles, ['super_owner', 'owner', 'legal', 'legal_worker']);
}

/**
 * Check if user can access the Owner Motherboard
 */
export function canAccessMotherboard(userRoles: AppRole[]): boolean {
  return hasRole(userRoles, ['super_owner']);
}

/**
 * Check if user can view a specific Puzzle Panel tab
 */
export function canViewTab(tabName: string, userRoles: AppRole[]): boolean {
  const allowedRoles = TAB_VISIBILITY[tabName];
  if (!allowedRoles) return false;
  return userRoles.some((role) => allowedRoles.includes(role));
}

/**
 * Get the highest privilege role from user's roles
 */
export function getHighestRole(userRoles: AppRole[]): AppRole {
  for (const role of ROLE_HIERARCHY) {
    if (userRoles.includes(role)) {
      return role;
    }
  }
  return 'user';
}

/**
 * Get the default dashboard route for a user based on their highest role
 */
export function getDefaultDashboard(userRoles: AppRole[]): string {
  const highestRole = getHighestRole(userRoles);
  return DASHBOARD_ROUTES[highestRole] || '/';
}

/**
 * Get list of visible tabs for Puzzle Panel based on user roles
 */
export function getVisibleTabs(userRoles: AppRole[]): string[] {
  return Object.keys(TAB_VISIBILITY).filter((tabName) => canViewTab(tabName, userRoles));
}

/**
 * Check if user is a tenant/partner role
 */
export function isTenantRole(userRoles: AppRole[]): boolean {
  return hasRole(userRoles, ['tenant_owner', 'tenant_admin', 'tenant_worker', 'partner_owner', 'partner_worker', 'partner_factory']);
}

/**
 * Check if user is a funder
 */
export function isFunder(userRoles: AppRole[]): boolean {
  return hasRole(userRoles, 'funder');
}

export { TAB_VISIBILITY, ROLE_HIERARCHY, DASHBOARD_ROUTES };
