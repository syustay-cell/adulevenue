/**
 * Text-to-Speech Utility
 * Multi-provider with remote-first, browser-fallback approach
 */

import { supabase } from "@/integrations/supabase/client";

type TTSState = {
  speaking: boolean;
  paused: boolean;
  loading: boolean;
  audio: HTMLAudioElement | null;
  utterance: SpeechSynthesisUtterance | null;
};

const state: TTSState = {
  speaking: false,
  paused: false,
  loading: false,
  audio: null,
  utterance: null,
};

const listeners = new Set<() => void>();

function notify() {
  listeners.forEach((fn) => fn());
}

export function subscribe(callback: () => void) {
  listeners.add(callback);
  return () => listeners.delete(callback);
}

export function getState() {
  return {
    speaking: state.speaking,
    paused: state.paused,
    loading: state.loading,
  };
}

export function isSupported(): boolean {
  return typeof window !== "undefined";
}

function isBrowserTtsSupported(): boolean {
  return typeof window !== "undefined" && "speechSynthesis" in window;
}

// Voice options for OpenAI: nova (warm female), shimmer (expressive female)
let currentVoice = "nova";

export function setVoice(voice: "nova" | "shimmer" | "alloy" | "echo" | "fable" | "onyx") {
  currentVoice = voice;
}

/**
 * Get preferred voice for browser TTS - tries to find a more natural voice
 */
function getPreferredVoice(): SpeechSynthesisVoice | null {
  if (!isBrowserTtsSupported()) return null;
  
  const voices = window.speechSynthesis.getVoices();
  if (!voices || !voices.length) return null;

  // Priority order for natural-sounding voices:
  // 1. Google/Microsoft premium voices
  // 2. Any voice with "female" or "woman" in name
  // 3. US English voices
  // 4. Any English voice
  // 5. Default
  const preferred =
    voices.find((v) => /Google US English|Microsoft .* English/i.test(v.name)) ||
    voices.find((v) => /female|woman|samantha|zira|jenny/i.test(v.name) && v.lang.startsWith("en")) ||
    voices.find((v) => v.lang.startsWith("en-US")) ||
    voices.find((v) => v.lang.startsWith("en")) ||
    voices[0];

  return preferred || null;
}

/**
 * Browser TTS fallback - only used when cloud TTS fails
 * Now with improved voice selection and tuned rate/pitch
 */
function playBrowserFallback(text: string, rate = 1.0): void {
  if (!isBrowserTtsSupported()) return;

  const utterance = new SpeechSynthesisUtterance(text);
  
  // Tuned to sound less robotic than default
  utterance.rate = rate * 0.9; // Slightly slower for clarity
  utterance.pitch = 1.05; // Slightly higher for warmth
  utterance.volume = 1.0;
  utterance.lang = "en-US";

  // Use improved voice selection
  const voice = getPreferredVoice();
  if (voice) utterance.voice = voice;

  utterance.onstart = () => {
    state.speaking = true;
    state.paused = false;
    state.loading = false;
    state.utterance = utterance;
    notify();
  };

  utterance.onend = () => {
    state.speaking = false;
    state.paused = false;
    state.utterance = null;
    notify();
  };

  utterance.onerror = () => {
    state.speaking = false;
    state.paused = false;
    state.loading = false;
    state.utterance = null;
    notify();
  };

  window.speechSynthesis.speak(utterance);
}

// Ensure voices are loaded (some browsers load them async)
if (typeof window !== "undefined" && "speechSynthesis" in window) {
  window.speechSynthesis.getVoices();
  window.speechSynthesis.onvoiceschanged = () => {
    window.speechSynthesis.getVoices();
  };
}

/**
 * Play via remote cloud TTS (OpenAI neural voice)
 */
async function playRemote(text: string, rate = 1.0): Promise<boolean> {
  try {
    const { data, error } = await supabase.functions.invoke("text-to-speech", {
      body: { text, voice: currentVoice },
    });

    if (error || !data?.audio) {
      console.warn("[TTS] Remote provider failed:", error);
      return false;
    }

    const audioSrc = `data:audio/mp3;base64,${data.audio}`;
    const audio = new Audio(audioSrc);
    audio.playbackRate = rate;

    audio.onplay = () => {
      state.speaking = true;
      state.paused = false;
      state.loading = false;
      notify();
    };

    audio.onended = () => {
      state.speaking = false;
      state.paused = false;
      state.audio = null;
      notify();
    };

    audio.onerror = () => {
      state.speaking = false;
      state.paused = false;
      state.loading = false;
      state.audio = null;
      notify();
    };

    state.audio = audio;
    await audio.play();
    return true;
  } catch (err) {
    console.warn("[TTS] Remote play error:", err);
    return false;
  }
}

export async function play(text: string, rate = 1.0): Promise<void> {
  if (!isSupported() || !text?.trim()) return;

  stop();

  state.loading = true;
  notify();

  // Try remote cloud TTS first (OpenAI neural voice)
  const success = await playRemote(text, rate);

  if (!success) {
    // Fallback to browser TTS
    console.info("[TTS] Falling back to browser voice");
    state.loading = false;
    notify();
    playBrowserFallback(text, rate);
  }
}

export function pause(): void {
  if (state.audio && state.speaking) {
    state.audio.pause();
    state.paused = true;
    notify();
  } else if (state.utterance && isBrowserTtsSupported()) {
    window.speechSynthesis.pause();
    state.paused = true;
    notify();
  }
}

export function resume(): void {
  if (state.audio && state.paused) {
    state.audio.play();
    state.paused = false;
    notify();
  } else if (state.utterance && isBrowserTtsSupported()) {
    window.speechSynthesis.resume();
    state.paused = false;
    notify();
  }
}

export function stop(): void {
  if (state.audio) {
    state.audio.pause();
    state.audio.currentTime = 0;
    state.audio = null;
  }
  if (isBrowserTtsSupported()) {
    window.speechSynthesis.cancel();
  }
  state.speaking = false;
  state.paused = false;
  state.loading = false;
  state.utterance = null;
  notify();
}

export function toggle(text: string, rate = 1.0): void {
  if (state.speaking && !state.paused) {
    pause();
  } else if (state.paused) {
    resume();
  } else {
    void play(text, rate);
  }
}

// Cleanup on page unload
if (typeof window !== "undefined") {
  window.addEventListener("beforeunload", stop);
}
