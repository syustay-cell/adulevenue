// src/lib/wolfAnalytics.ts
// V11 / B200: Wolf session analytics helpers

export type WolfRiskLevel = "none" | "low" | "medium" | "high";

export function scoreToRiskLevel(score: number): WolfRiskLevel {
  if (score >= 70) return "high";
  if (score >= 40) return "medium";
  if (score > 0) return "low";
  return "none";
}

export function riskLabel(level: WolfRiskLevel): string {
  switch (level) {
    case "high":
      return "High risk";
    case "medium":
      return "Medium risk";
    case "low":
      return "Low risk";
    default:
      return "No risk";
  }
}

export function formatDuration(seconds: number | null): string {
  if (seconds == null) return "–";
  const m = Math.floor(seconds / 60);
  const s = seconds % 60;
  return `${m}m ${s}s`;
}
