// MCA Blueprint Module 7: ISO Knowledge Hub
import { supabase } from "@/integrations/supabase/client";

export interface ISOTrainingModule {
  id: string;
  slug: string;
  title: string;
  description: string | null;
  content_md: string;
  is_required: boolean;
  order_index: number;
}

export interface ISOTrainingCompletion {
  id: string;
  iso_id: string;
  module_id: string;
  completed_at: string;
  score: number | null;
}

export interface ISOStatistics {
  id: string;
  iso_id: string;
  deals_submitted: number;
  deals_funded: number;
  approval_rate: number | null;
  avg_commission: number | null;
  last_updated: string;
}

export interface ISOScoreboardEntry {
  iso_id: string;
  iso_name: string;
  deals_submitted: number;
  deals_funded: number;
  approval_rate: number;
  avg_commission: number;
  total_volume: number;
  training_complete: boolean;
  badges: string[];
}

// Badge definitions
export const ISO_BADGES = {
  WOLF_CLOSER: {
    id: 'WOLF_CLOSER',
    name: 'Wolf Closer',
    description: '>$500k funded + >60% approval rate',
    icon: '🐺',
  },
  CLEAN_FILE_KING: {
    id: 'CLEAN_FILE_KING',
    name: 'Clean File King',
    description: '<5% decline rate for file quality',
    icon: '👑',
  },
  RENEWAL_MASTER: {
    id: 'RENEWAL_MASTER',
    name: 'Renewal Master',
    description: '>10 renewals generated',
    icon: '🔄',
  },
  TRAINING_COMPLETE: {
    id: 'TRAINING_COMPLETE',
    name: 'Fully Trained',
    description: 'Completed all required training',
    icon: '🎓',
  },
  TOP_PRODUCER: {
    id: 'TOP_PRODUCER',
    name: 'Top Producer',
    description: 'Top 10% by funded volume this month',
    icon: '⭐',
  },
} as const;

export async function getTrainingModules(): Promise<ISOTrainingModule[]> {
  const { data, error } = await supabase
    .from('iso_training_modules')
    .select('*')
    .order('order_index');

  if (error) return [];
  return (data || []) as ISOTrainingModule[];
}

export async function getTrainingCompletions(isoId: string): Promise<ISOTrainingCompletion[]> {
  const { data, error } = await supabase
    .from('iso_training_completions')
    .select('*')
    .eq('iso_id', isoId);

  if (error) return [];
  return (data || []) as ISOTrainingCompletion[];
}

export async function getISOTrainingProgress(isoId: string): Promise<{
  modules: ISOTrainingModule[];
  completions: ISOTrainingCompletion[];
  completedCount: number;
  requiredCount: number;
  isComplete: boolean;
}> {
  const modules = await getTrainingModules();
  const completions = await getTrainingCompletions(isoId);

  const completedModuleIds = new Set(completions.map(c => c.module_id));
  const requiredModules = modules.filter(m => m.is_required);
  const completedRequired = requiredModules.filter(m => completedModuleIds.has(m.id));

  return {
    modules,
    completions,
    completedCount: completedRequired.length,
    requiredCount: requiredModules.length,
    isComplete: completedRequired.length >= requiredModules.length,
  };
}

export async function completeTrainingModule(
  isoId: string,
  moduleId: string,
  score?: number
): Promise<{ success: boolean; error?: string }> {
  // Check if already completed
  const { data: existing } = await supabase
    .from('iso_training_completions')
    .select('id')
    .eq('iso_id', isoId)
    .eq('module_id', moduleId)
    .single();

  if (existing) {
    return { success: true }; // Already completed
  }

  const { error } = await supabase
    .from('iso_training_completions')
    .insert({
      iso_id: isoId,
      module_id: moduleId,
      score: score || null,
      completed_at: new Date().toISOString(),
    });

  if (error) return { success: false, error: error.message };
  return { success: true };
}

export async function getISOStatistics(isoId: string): Promise<ISOStatistics | null> {
  const { data, error } = await supabase
    .from('iso_statistics')
    .select('*')
    .eq('iso_id', isoId)
    .single();

  if (error || !data) return null;
  return data as ISOStatistics;
}

export async function getAllISOStatistics(): Promise<ISOStatistics[]> {
  const { data, error } = await supabase
    .from('iso_statistics')
    .select('*')
    .order('deals_funded', { ascending: false });

  if (error) return [];
  return (data || []) as ISOStatistics[];
}

export async function refreshISOStats(isoId: string): Promise<{ success: boolean; error?: string }> {
  // Aggregate from funded_deals table
  const { data: deals } = await supabase
    .from('funded_deals')
    .select('id, status, funded_amount, commission_amount')
    .eq('iso_partner_id', isoId);

  const dealsList = deals || [];
  const dealsSubmitted = dealsList.length;
  const fundedDeals = dealsList.filter((d: any) => d.status === 'funded' || d.status === 'active');
  const dealsFunded = fundedDeals.length;
  const approvalRate = dealsSubmitted > 0 ? (dealsFunded / dealsSubmitted) * 100 : null;

  const totalCommission = fundedDeals.reduce((sum: number, d: any) => sum + (d.commission_amount || 0), 0);
  const avgCommission = dealsFunded > 0 ? totalCommission / dealsFunded : null;

  // Upsert stats
  const { data: existing } = await supabase
    .from('iso_statistics')
    .select('id')
    .eq('iso_id', isoId)
    .single();

  if (existing) {
    const { error } = await supabase
      .from('iso_statistics')
      .update({
        deals_submitted: dealsSubmitted,
        deals_funded: dealsFunded,
        approval_rate: approvalRate,
        avg_commission: avgCommission,
        last_updated: new Date().toISOString(),
      })
      .eq('id', existing.id);

    if (error) return { success: false, error: error.message };
  } else {
    const { error } = await supabase
      .from('iso_statistics')
      .insert({
        iso_id: isoId,
        deals_submitted: dealsSubmitted,
        deals_funded: dealsFunded,
        approval_rate: approvalRate,
        avg_commission: avgCommission,
      });

    if (error) return { success: false, error: error.message };
  }

  return { success: true };
}

export function computeISOBadges(
  stats: ISOStatistics | null,
  trainingComplete: boolean,
  totalVolume: number = 0
): string[] {
  const badges: string[] = [];

  if (trainingComplete) {
    badges.push(ISO_BADGES.TRAINING_COMPLETE.id);
  }

  if (stats) {
    // Wolf Closer: >$500k funded + >60% approval
    if (totalVolume > 500000 && (stats.approval_rate || 0) > 60) {
      badges.push(ISO_BADGES.WOLF_CLOSER.id);
    }

    // Clean File King: <5% decline rate (>95% approval with >20 deals)
    if (stats.deals_submitted > 20 && (stats.approval_rate || 0) > 95) {
      badges.push(ISO_BADGES.CLEAN_FILE_KING.id);
    }
  }

  return badges;
}

export function getBadgeInfo(badgeId: string): typeof ISO_BADGES[keyof typeof ISO_BADGES] | null {
  return (ISO_BADGES as Record<string, typeof ISO_BADGES[keyof typeof ISO_BADGES]>)[badgeId] || null;
}

export function formatApprovalRate(rate: number | null): string {
  if (rate === null) return 'N/A';
  return `${rate.toFixed(1)}%`;
}

export function formatCommission(amount: number | null): string {
  if (amount === null) return 'N/A';
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(amount);
}
