import { supabase } from '@/integrations/supabase/client';
import type { SystemMode } from './systemMode';
import type { Json } from '@/integrations/supabase/types';

export type ActivityModule = 'UNDERWRITING' | 'COLLECTIONS' | 'RENEWALS' | 'LEADS' | 'SYSTEM' | 'CREDIT_FIX' | 'ISO';
export type ActivityActor = 'AI_AUTOPILOT' | 'USER' | 'OWNER' | 'SYSTEM';
export type ActivitySeverity = 'info' | 'low' | 'medium' | 'high' | 'critical';

export interface ActivityEvent {
  module: ActivityModule;
  actor: ActivityActor;
  mode: SystemMode;
  severity: ActivitySeverity;
  title: string;
  summary: string;
  proposed_action?: string;
  auto_executed?: boolean;
  context?: Record<string, unknown>;
}

export interface ActivityLogEntry {
  id: string;
  created_at: string;
  module: string;
  actor: string;
  mode: string;
  severity: string;
  title: string;
  summary: string;
  proposed_action: string | null;
  auto_executed: boolean;
  metadata: Record<string, unknown>;
}

/**
 * Log an activity event to the database
 */
export async function logActivityEvent(evt: ActivityEvent): Promise<void> {
  const { module, actor, mode, severity, title, summary, proposed_action, auto_executed, context } = evt;

  const { error } = await supabase.from('activity_log').insert([{
    module,
    actor,
    mode,
    severity,
    title,
    summary,
    proposed_action: proposed_action || null,
    auto_executed: !!auto_executed,
    metadata: (context || {}) as Json,
  }]);

  if (error) {
    console.error('Failed to log activity event:', error);
  }
}

/**
 * Get recent activity log entries
 */
export async function getRecentActivity(limit = 50): Promise<ActivityLogEntry[]> {
  const { data, error } = await supabase
    .from('activity_log')
    .select('*')
    .order('created_at', { ascending: false })
    .limit(limit);

  if (error) {
    console.error('Failed to fetch activity log:', error);
    return [];
  }

  return (data || []) as ActivityLogEntry[];
}

/**
 * Get activity log entries filtered by module
 */
export async function getActivityByModule(module: ActivityModule, limit = 50): Promise<ActivityLogEntry[]> {
  const { data, error } = await supabase
    .from('activity_log')
    .select('*')
    .eq('module', module)
    .order('created_at', { ascending: false })
    .limit(limit);

  if (error) {
    console.error('Failed to fetch activity log by module:', error);
    return [];
  }

  return (data || []) as ActivityLogEntry[];
}

/**
 * Get activity log entries filtered by severity
 */
export async function getActivityBySeverity(severity: ActivitySeverity, limit = 50): Promise<ActivityLogEntry[]> {
  const { data, error } = await supabase
    .from('activity_log')
    .select('*')
    .eq('severity', severity)
    .order('created_at', { ascending: false })
    .limit(limit);

  if (error) {
    console.error('Failed to fetch activity log by severity:', error);
    return [];
  }

  return (data || []) as ActivityLogEntry[];
}

/**
 * Get count of recent activity by module
 */
export async function getActivityCounts(): Promise<Record<ActivityModule, number>> {
  const counts: Record<ActivityModule, number> = {
    UNDERWRITING: 0,
    COLLECTIONS: 0,
    RENEWALS: 0,
    LEADS: 0,
    SYSTEM: 0,
    CREDIT_FIX: 0,
    ISO: 0,
  };

  const { data, error } = await supabase
    .from('activity_log')
    .select('module')
    .gte('created_at', new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString());

  if (error) {
    console.error('Failed to fetch activity counts:', error);
    return counts;
  }

  for (const row of data || []) {
    const module = row.module as ActivityModule;
    if (module in counts) {
      counts[module]++;
    }
  }

  return counts;
}
