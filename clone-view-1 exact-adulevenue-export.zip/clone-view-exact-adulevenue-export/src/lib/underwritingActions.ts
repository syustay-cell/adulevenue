import { SupabaseClient } from '@supabase/supabase-js';
import { UnderwritingStatus } from '@/types/underwriting';

type ActivityPayload = {
  actor_email?: string | null;
  actor_role?: string | null;
};

async function logActivity(
  supabase: SupabaseClient,
  applicationId: string,
  summary: string,
  extras: Partial<ActivityPayload> & {
    decision?: string | null;
  } = {}
) {
  const { actor_email, actor_role, decision } = extras;

  await supabase.from('activity_feed').insert({
    actor_email: actor_email ?? null,
    actor_role: actor_role ?? 'underwriter',
    target_email: null,
    event_type: 'funding',
    decision: decision ?? null,
    summary,
    context_type: 'application',
    context_id: applicationId,
  });
}

/**
 * RUN FILE
 * - creates or updates underwriting_files
 * - sets application.status = 'in_underwriting'
 */
export async function runFile(
  supabase: SupabaseClient,
  params: {
    applicationId: string;
    underwriterId: string;
    numbers: {
      monthly_revenue?: number;
      nsfs_last_90_days?: number;
      avg_daily_balance?: number;
      time_in_business_months?: number;
      recommended_amount?: number;
      recommended_term_months?: number;
      recommended_factor_rate?: number;
    };
    notes?: string;
    actor?: ActivityPayload;
  }
) {
  const { applicationId, underwriterId, numbers, notes, actor } = params;

  // upsert underwriting_files
  const { data: existing, error: loadErr } = await supabase
    .from('underwriting_files')
    .select('*')
    .eq('application_id', applicationId)
    .maybeSingle();

  if (loadErr) throw loadErr;

  const summary_json = {
    ...numbers,
    notes: notes ?? null,
  };

  let error;

  if (existing) {
    ({ error } = await supabase
      .from('underwriting_files')
      .update({
        underwriter_id: underwriterId,
        status: 'running' as UnderwritingStatus,
        summary_json,
        updated_at: new Date().toISOString(),
      })
      .eq('id', existing.id));
  } else {
    ({ error } = await supabase.from('underwriting_files').insert({
      application_id: applicationId,
      underwriter_id: underwriterId,
      status: 'running',
      summary_json,
    }));
  }

  if (error) throw error;

  // update application status
  const { error: appErr } = await supabase
    .from('fast_track_applications')
    .update({
      status: 'in_underwriting',
      updated_at: new Date().toISOString(),
    })
    .eq('id', applicationId);

  if (appErr) throw appErr;

  await logActivity(
    supabase,
    applicationId,
    'Underwriter ran file and saved underwriting summary',
    { ...actor, decision: null }
  );
}

/**
 * NEED MORE DOCS
 * - sets underwriting_files.status = 'needs_more_docs'
 * - application.status = 'needs_more_docs'
 */
export async function markNeedsMoreDocs(
  supabase: SupabaseClient,
  params: {
    applicationId: string;
    reason: string;
    actor?: ActivityPayload;
  }
) {
  const { applicationId, reason, actor } = params;

  // update/insert underwriting_files
  const { data: existing, error: loadErr } = await supabase
    .from('underwriting_files')
    .select('id')
    .eq('application_id', applicationId)
    .maybeSingle();

  if (loadErr) throw loadErr;

  let error;

  if (existing) {
    ({ error } = await supabase
      .from('underwriting_files')
      .update({
        status: 'needs_more_docs' as UnderwritingStatus,
        updated_at: new Date().toISOString(),
      })
      .eq('id', existing.id));
  } else {
    ({ error } = await supabase.from('underwriting_files').insert({
      application_id: applicationId,
      status: 'needs_more_docs',
      summary_json: { reason },
    }));
  }

  if (error) throw error;

  // update application status
  const { error: appErr } = await supabase
    .from('fast_track_applications')
    .update({
      status: 'needs_more_docs',
      updated_at: new Date().toISOString(),
    })
    .eq('id', applicationId);

  if (appErr) throw appErr;

  await logActivity(
    supabase,
    applicationId,
    `Underwriter requested more docs: ${reason}`,
    { ...actor, decision: 'pending' }
  );
}

/**
 * SEND TO FUNDER
 * - marks underwriting_files.status = 'ready_for_funding'
 * - application.status = 'ready_for_funding_call'
 */
export async function sendToFunder(
  supabase: SupabaseClient,
  params: {
    applicationId: string;
    funderName?: string;
    packetUrl?: string; // optional link to doc packet or portal
    actor?: ActivityPayload;
  }
) {
  const { applicationId, funderName, packetUrl, actor } = params;

  const { data: existing, error: loadErr } = await supabase
    .from('underwriting_files')
    .select('id, summary_json')
    .eq('application_id', applicationId)
    .maybeSingle();

  if (loadErr) throw loadErr;

  const baseSummary = existing?.summary_json ?? {};
  const summary_json = {
    ...baseSummary,
    funderName: funderName ?? baseSummary.funderName ?? null,
    packetUrl: packetUrl ?? baseSummary.packetUrl ?? null,
  };

  let error;

  if (existing) {
    ({ error } = await supabase
      .from('underwriting_files')
      .update({
        status: 'ready_for_funding' as UnderwritingStatus,
        summary_json,
        updated_at: new Date().toISOString(),
      })
      .eq('id', existing.id));
  } else {
    ({ error } = await supabase.from('underwriting_files').insert({
      application_id: applicationId,
      status: 'ready_for_funding',
      summary_json,
    }));
  }

  if (error) throw error;

  const { error: appErr } = await supabase
    .from('fast_track_applications')
    .update({
      status: 'ready_for_funding_call',
      updated_at: new Date().toISOString(),
    })
    .eq('id', applicationId);

  if (appErr) throw appErr;

  await logActivity(
    supabase,
    applicationId,
    `Underwriting sent file to funder${funderName ? ` ${funderName}` : ''}`,
    { ...actor, decision: 'pending' }
  );
}

/**
 * CREATE FUNDING CALL
 * - inserts row in funding_calls
 */
export async function createFundingCall(
  supabase: SupabaseClient,
  params: {
    applicationId: string;
    scheduledFor: string; // ISO timestamp
    dialMethod: 'phone' | 'zoom' | 'teams' | 'other';
    notes?: string;
    createdBy: string; // auth user id
    actor?: ActivityPayload;
  }
) {
  const { applicationId, scheduledFor, dialMethod, notes, createdBy, actor } =
    params;

  const { error } = await supabase.from('funding_calls').insert({
    application_id: applicationId,
    scheduled_for: scheduledFor,
    dial_method: dialMethod,
    status: 'scheduled',
    notes: notes ?? null,
    created_by: createdBy,
  });

  if (error) throw error;

  await logActivity(
    supabase,
    applicationId,
    `Funding call scheduled for ${scheduledFor} via ${dialMethod}`,
    { ...actor, decision: 'pending' }
  );
}
