// Wolf Assistant context builder for all dashboards

export type WolfEntityContext =
  | { type: 'lead'; id: string }
  | { type: 'application'; id: string }
  | { type: 'credit_case'; id: string }
  | null;

export interface WolfAssistantContext {
  role: string;
  email: string;
  page: string;
  entity: WolfEntityContext;
}

export function buildWolfContext(options: {
  userRole: string;
  userEmail: string;
  pathname: string;
  leadId?: string;
  applicationId?: string;
  caseId?: string;
}): WolfAssistantContext {
  let entity: WolfEntityContext = null;

  if (options.leadId) {
    entity = { type: 'lead', id: options.leadId };
  } else if (options.applicationId) {
    entity = { type: 'application', id: options.applicationId };
  } else if (options.caseId) {
    entity = { type: 'credit_case', id: options.caseId };
  }

  return {
    role: options.userRole,
    email: options.userEmail,
    page: options.pathname,
    entity,
  };
}
