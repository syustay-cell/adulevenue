// src/lib/insightActions.ts - Phase 4: AI Insight Engine client actions

import { supabase } from '@/integrations/supabase/client';

export interface InsightEngineResult {
  ok: boolean;
  found: number;
  inserted: number;
  run_id?: string;
  error?: string;
}

/**
 * Invoke the ai-insight-engine edge function
 * Requires owner/admin role for the given tenant
 */
export async function runAiInsightEngine(tenantId: string): Promise<InsightEngineResult> {
  const { data, error } = await supabase.functions.invoke('ai-insight-engine', {
    body: { tenantId },
  });

  if (error) {
    console.error('[runAiInsightEngine] error:', error);
    throw error;
  }

  return data as InsightEngineResult;
}
