/**
 * Wolf Fund – Deal Events Logging Helper
 * Logs events to deal_events table for audit trail and timeline
 */

import { supabase } from "@/integrations/supabase/client";

export interface DealEventParams {
  dealId: string;
  tenantId: string;
  eventType: string;
  metadata?: Record<string, any>;
  createdBy?: string;
}

export async function logDealEvent(params: DealEventParams): Promise<void> {
  const { dealId, tenantId, eventType, metadata = {}, createdBy } = params;

  const { error } = await supabase.from("deal_events").insert({
    deal_id: dealId,
    tenant_id: tenantId,
    event_type: eventType,
    metadata,
    created_by: createdBy || null,
  });

  if (error) {
    console.error("Failed to log deal event:", error);
  }
}

// Common event type constants
export const DEAL_EVENT_TYPES = {
  DEAL_CREATED: "deal_created",
  DEAL_CREATED_FROM_CREDIT: "deal_created_from_credit",
  CREDIT_CASE_COMPLETED: "credit_case_completed",
  STATUS_CHANGED: "status_changed",
  OFFER_SUBMITTED: "offer_submitted",
  OFFER_ACCEPTED: "offer_accepted",
  OFFER_DECLINED: "offer_declined",
  DEAL_FUNDED: "deal_funded",
  COMMISSION_CALCULATED: "commission_calculated",
  DOCUMENT_UPLOADED: "document_uploaded",
  NOTE_ADDED: "note_added",
  ASSIGNED_TO_UNDERWRITING: "assigned_to_underwriting",
  READY_FOR_FUNDERS: "ready_for_funders",
} as const;
