/**
 * Wolf Fund – Mark Deal as Funded
 * Updates deal status, calls commission engine, logs events
 */

import { supabase } from "@/integrations/supabase/client";

export interface MarkDealFundedParams {
  dealId: string;
  fundedAmount: number;
  grossCommissionPool?: number;
}

export interface MarkDealFundedResult {
  ok: boolean;
  error?: string;
  commissions?: any;
}

export async function markDealFunded(params: MarkDealFundedParams): Promise<MarkDealFundedResult> {
  const { dealId, fundedAmount, grossCommissionPool } = params;

  try {
    // 1) Update deal status + funded_amount + funded_at
    const updateData: Record<string, any> = {
      status: "funded",
      funded_amount: fundedAmount,
      funded_at: new Date().toISOString(),
    };

    // If gross commission pool provided, update it
    if (grossCommissionPool !== undefined) {
      updateData.gross_commission_pool = grossCommissionPool;
    }

    const { data: deal, error: updateError } = await supabase
      .from("deals")
      .update(updateData)
      .eq("id", dealId)
      .select("id, tenant_id")
      .single();

    if (updateError || !deal) {
      throw updateError || new Error("Failed to update deal as funded");
    }

    // 2) Call calculate-deal-commissions edge function
    const { data: commissionResult, error: commissionError } = await supabase.functions.invoke(
      "calculate-deal-commissions",
      {
        body: { dealId },
      }
    );

    if (commissionError) {
      console.error("calculate-deal-commissions failed:", commissionError);
      // Don't throw - commission failure shouldn't block funding
    }

    // 3) Log deal_funded event
    await supabase.from("deal_events").insert({
      deal_id: dealId,
      tenant_id: deal.tenant_id,
      event_type: "deal_funded",
      metadata: { 
        funded_amount: fundedAmount,
        gross_commission_pool: grossCommissionPool,
        commission_result: commissionResult?.ok ? "success" : "failed",
      },
    });

    // 4) Log commission_calculated event if successful
    if (commissionResult?.ok) {
      await supabase.from("deal_events").insert({
        deal_id: dealId,
        tenant_id: deal.tenant_id,
        event_type: "commission_calculated",
        metadata: {
          payouts_count: commissionResult.payouts?.length || 0,
          version: commissionResult.debug?.version,
        },
      });
    }

    return { 
      ok: true, 
      commissions: commissionResult,
    };
  } catch (error) {
    console.error("markDealFunded error:", error);
    return {
      ok: false,
      error: error instanceof Error ? error.message : "Unknown error",
    };
  }
}
