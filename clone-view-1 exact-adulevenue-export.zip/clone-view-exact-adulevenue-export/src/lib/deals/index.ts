/**
 * Wolf Fund – Deals Library
 * Central exports for deal-related functions
 * 444 STEP 2: Complete Ecosystem Wiring
 */

// Event logging
export { logDealEvent, DEAL_EVENT_TYPES } from "./logDealEvent";
export type { DealEventParams } from "./logDealEvent";

// Deal funded + commission trigger
export { markDealFunded } from "./markDealFunded";
export type { MarkDealFundedParams, MarkDealFundedResult } from "./markDealFunded";
