/**
 * WOLF FUND – COMMISSION ENGINE v1.1
 * 
 * Full commission calculation system for MCA deals with:
 * - Opener / Closer workers
 * - Worker referrals vs external referral partners
 * - ISO Partners
 * - House (Wolf)
 * - AI Autopilot mode
 */

// ============================================================================
// ENUMS & TYPES
// ============================================================================

export type ParticipantRole =
  | "OPENER"
  | "CLOSER"
  | "REFERRAL_PARTNER"   // External referral partners (affiliates, influencers, etc.)
  | "WORKER_REFERRAL"    // Internal Wolf worker referred the deal
  | "ISO_PARTNER"
  | "HOUSE"
  | "AI_AUTOPILOT";      // reporting-only logical role, not a payout row

export type LeadSource =
  | "APP"      // Application (direct link / web app)
  | "IG"       // Instagram
  | "FB"       // Facebook
  | "TT"       // TikTok
  | "YT"       // YouTube
  | "WEB"      // Generic website
  | "MANUAL"   // manually entered lead
  | "OTHER";

export type DealStatus =
  | "PENDING"
  | "SIGNED"
  | "FUNDED"
  | "DECLINED"
  | "CANCELLED";

export type ReferralOwnerType =
  | "WORKER"           // referral code belongs to a Wolf worker/user
  | "REFERRAL_PARTNER" // external referral partner
  | "ISO_PARTNER"      // ISO that owns the referral code
  | "UNKNOWN";

/**
 * Commission calculation context passed into the engine.
 */
export interface CommissionContext {
  dealId: string;

  // Money base
  fundedAmount: number;
  grossCommissionPool: number;

  // Actors (all optional except house)
  openerUserId?: string | null;
  closerUserId?: string | null;
  isoPartnerId?: string | null;
  referralCode?: string | null;
  autopilot: boolean;

  // Derived / resolved
  referralOwnerType?: ReferralOwnerType;
  referralEntityId?: string | null;

  // Lead metadata
  leadId?: string | null;
  leadSource: LeadSource;
  leadSourceLabel: string;

  status: DealStatus;
}

/**
 * Final result per participant.
 */
export interface CommissionPayout {
  dealId: string;
  participantRole: ParticipantRole;
  participantId: string | null;
  amount: number;
  percentOfPool: number;
}

/**
 * Commission rules configuration.
 */
export interface CommissionRules {
  id: string;
  default_referral_pct: number;
  default_iso_pct: number;
  opener_pct_of_worker_pool: number;
  closer_pct_of_worker_pool: number;
  min_house_pct: number;
  autopilot_house_multiplier: number;
  allow_negotiated_overrides: boolean;
}

/**
 * Commission debug snapshot for audit trail.
 */
export interface CommissionDebugSnapshot {
  context: CommissionContext;
  rules: CommissionRules;
  payouts: CommissionPayout[];
  calculated_at: string;
  version: string;
}

// ============================================================================
// HELPERS
// ============================================================================

function roundToCents(value: number): number {
  return Math.round(value * 100) / 100;
}

/**
 * Normalize payouts to ensure sum equals pool (adjusts house for rounding).
 */
function normalizePayouts(
  pool: number,
  payouts: CommissionPayout[]
): CommissionPayout[] {
  const total = payouts.reduce((sum, p) => sum + p.amount, 0);
  const diff = roundToCents(pool - total);

  if (Math.abs(diff) < 0.01) {
    return payouts.map((p) => ({
      ...p,
      percentOfPool: pool > 0 ? p.amount / pool : 0,
    }));
  }

  // Adjust HOUSE by diff if possible
  const house = payouts.find((p) => p.participantRole === "HOUSE");
  if (house) {
    house.amount = roundToCents(house.amount + diff);
  }

  return payouts.map((p) => ({
    ...p,
    percentOfPool: pool > 0 ? p.amount / pool : 0,
  }));
}

/**
 * Build Wolf folder label from date.
 * @example buildWolfFolderLabel(new Date()) → "Wolf January 2026"
 */
export function buildWolfFolderLabel(date: Date): string {
  const month = date.toLocaleString("en-US", { month: "long" });
  const year = date.getFullYear();
  return `Wolf ${month} ${year}`;
}

/**
 * Get human-readable platform label from source code.
 */
export function getSourcePlatformLabel(source: LeadSource): string {
  const labels: Record<LeadSource, string> = {
    APP: "Application",
    IG: "Instagram",
    FB: "Facebook",
    TT: "TikTok",
    YT: "YouTube",
    WEB: "Website",
    MANUAL: "Manual Entry",
    OTHER: "Other",
  };
  return labels[source] || "Unknown";
}

// ============================================================================
// COMMISSION ENGINE
// ============================================================================

/**
 * Calculate commissions for a deal based on context and rules.
 */
export function commissionEngine(
  ctx: CommissionContext,
  rules: CommissionRules
): CommissionPayout[] {
  const results: CommissionPayout[] = [];
  const pool = ctx.grossCommissionPool;

  if (pool <= 0) {
    return [];
  }

  // --------------------- ISO SECTION -----------------------
  let isoAmount = 0;
  const isoId =
    ctx.isoPartnerId ||
    (ctx.referralOwnerType === "ISO_PARTNER" ? ctx.referralEntityId : null);

  if (isoId) {
    const isoPct = rules.default_iso_pct;
    isoAmount = roundToCents(pool * isoPct);

    results.push({
      dealId: ctx.dealId,
      participantRole: "ISO_PARTNER",
      participantId: isoId,
      amount: isoAmount,
      percentOfPool: isoAmount / pool,
    });
  }

  // --------------------- REFERRAL SECTION (v1.1 patched) ---------------------
  let referralAmount = 0;
  let referralRole: ParticipantRole | null = null;
  let referralRecipientId: string | null = null;

  if (
    ctx.referralOwnerType === "WORKER" ||
    ctx.referralOwnerType === "REFERRAL_PARTNER"
  ) {
    referralRecipientId = ctx.referralEntityId || null;

    if (referralRecipientId) {
      // v1.1: Distinguish WORKER_REFERRAL from REFERRAL_PARTNER
      referralRole =
        ctx.referralOwnerType === "WORKER"
          ? "WORKER_REFERRAL"
          : "REFERRAL_PARTNER";

      const referralPct = rules.default_referral_pct;
      referralAmount = roundToCents(pool * referralPct);

      results.push({
        dealId: ctx.dealId,
        participantRole: referralRole,
        participantId: referralRecipientId,
        amount: referralAmount,
        percentOfPool: referralAmount / pool,
      });
    }
  }

  // --------------------- REMAINING POOL -----------------------
  const poolAfterIsoReferral = pool - isoAmount - referralAmount;
  if (poolAfterIsoReferral <= 0) {
    return normalizePayouts(pool, results);
  }

  // --------------------- WORKER POOL -----------------------
  let openerAmount = 0;
  let closerAmount = 0;

  const hasOpener = !!ctx.openerUserId;
  const hasCloser = !!ctx.closerUserId && ctx.closerUserId !== ctx.openerUserId;
  const workerPool = ctx.autopilot ? 0 : poolAfterIsoReferral;

  if (!ctx.autopilot && workerPool > 0) {
    if (hasOpener && !hasCloser) {
      // Opener closes their own deal - full worker pool
      openerAmount = roundToCents(workerPool);

      results.push({
        dealId: ctx.dealId,
        participantRole: "OPENER",
        participantId: ctx.openerUserId!,
        amount: openerAmount,
        percentOfPool: openerAmount / pool,
      });
    } else if (hasOpener && hasCloser) {
      // Opener + Closer split
      const openerShare = rules.opener_pct_of_worker_pool;
      const closerShare = rules.closer_pct_of_worker_pool;
      const totalShare = openerShare + closerShare || 1;

      const normalizedOpenerShare = openerShare / totalShare;
      const normalizedCloserShare = closerShare / totalShare;

      openerAmount = roundToCents(workerPool * normalizedOpenerShare);
      closerAmount = roundToCents(workerPool * normalizedCloserShare);

      results.push({
        dealId: ctx.dealId,
        participantRole: "OPENER",
        participantId: ctx.openerUserId!,
        amount: openerAmount,
        percentOfPool: openerAmount / pool,
      });

      results.push({
        dealId: ctx.dealId,
        participantRole: "CLOSER",
        participantId: ctx.closerUserId!,
        amount: closerAmount,
        percentOfPool: closerAmount / pool,
      });
    }
  }

  // --------------------- HOUSE CUT -----------------------
  const totalWorkers = openerAmount + closerAmount;
  let houseAmount = poolAfterIsoReferral - totalWorkers;

  if (ctx.autopilot) {
    houseAmount = poolAfterIsoReferral * rules.autopilot_house_multiplier;
    if (houseAmount > pool) houseAmount = pool;
  }

  // Enforce house minimum
  const minHouse = pool * rules.min_house_pct;
  if (houseAmount < minHouse) {
    const diff = minHouse - houseAmount;
    const adjustable = openerAmount + closerAmount;
    
    if (adjustable > 0 && diff > 0) {
      const scale = Math.max(0, (adjustable - diff) / adjustable);
      openerAmount = roundToCents(openerAmount * scale);
      closerAmount = roundToCents(closerAmount * scale);
      houseAmount = poolAfterIsoReferral - openerAmount - closerAmount;

      // Update worker entries in results
      for (const r of results) {
        if (r.participantRole === "OPENER") {
          r.amount = openerAmount;
          r.percentOfPool = openerAmount / pool;
        }
        if (r.participantRole === "CLOSER") {
          r.amount = closerAmount;
          r.percentOfPool = closerAmount / pool;
        }
      }
    } else {
      houseAmount = poolAfterIsoReferral;
    }
  }

  houseAmount = roundToCents(houseAmount);

  results.push({
    dealId: ctx.dealId,
    participantRole: "HOUSE",
    participantId: null,
    amount: houseAmount,
    percentOfPool: houseAmount / pool,
  });

  return normalizePayouts(pool, results);
}

/**
 * Create a debug snapshot for audit purposes.
 */
export function createCommissionSnapshot(
  ctx: CommissionContext,
  rules: CommissionRules,
  payouts: CommissionPayout[]
): CommissionDebugSnapshot {
  return {
    context: ctx,
    rules,
    payouts,
    calculated_at: new Date().toISOString(),
    version: "commission_engine_v1.1",
  };
}

// ============================================================================
// DEFAULT RULES
// ============================================================================

export const DEFAULT_COMMISSION_RULES: CommissionRules = {
  id: "default",
  default_referral_pct: 0.03,
  default_iso_pct: 0.05,
  opener_pct_of_worker_pool: 0.5,
  closer_pct_of_worker_pool: 0.5,
  min_house_pct: 0.3,
  autopilot_house_multiplier: 1.2,
  allow_negotiated_overrides: true,
};
