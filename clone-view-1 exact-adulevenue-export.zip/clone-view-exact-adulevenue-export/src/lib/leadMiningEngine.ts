// Lead Mining Engine - AI lead discovery and insertion with mode awareness
import { supabase } from "@/integrations/supabase/client";
import { getSystemModeState } from "./systemMode";
import { getStrategyConfigFromState, canAutoExecuteFromState } from "./systemMode/strategyConfig";
import { logActivityEvent } from "./activity";

export interface LeadCandidate {
  email: string;
  business_name?: string;
  owner_name?: string;
  phone?: string;
  source_meta?: Record<string, any>;
}

export interface LeadMiningResult {
  inserted: number;
  skippedExisting: number;
  mode: string;
}

/**
 * Process a batch of mined lead candidates
 * MANUAL: Only logs proposals, doesn't insert
 * AUTOPILOT + ECO: Conservative volume (25 max)
 * AUTOPILOT + STANDARD: Normal volume (75 max)
 * AUTOPILOT + AGGRESSIVE: High volume (200 max)
 */
export async function processLeadMiningBatch(
  candidates: LeadCandidate[]
): Promise<LeadMiningResult> {
  const modeState = await getSystemModeState();
  const strategy = getStrategyConfigFromState(modeState);
  const allowAuto = canAutoExecuteFromState(modeState);
  const modeLabel = `${modeState.executionMode} · ${modeState.strategyProfile}`;

  // Manual mode: only propose, do not insert
  if (!allowAuto) {
    await logActivityEvent({
      actorType: 'AI',
      scope: 'LEADS',
      eventType: 'DECISION',
      decision: 'INFO',
      severity: 'LOW',
      summary: `AI mined ${candidates.length} leads (Manual mode – not auto-inserting)`,
      details: { mode: 'MANUAL', candidatesCount: candidates.length },
    });

    return { inserted: 0, skippedExisting: 0, mode: modeLabel };
  }

  // Strategy-based volume limits
  const maxLeadsToInsert = 
    modeState.strategyProfile === 'ECO' ? 25 
    : modeState.strategyProfile === 'AGGRESSIVE' ? 200 
    : 75;

  const slice = candidates.slice(0, maxLeadsToInsert);
  let inserted = 0;
  let skippedExisting = 0;

  for (const c of slice) {
    if (!c.email) continue;

    // Check for existing lead by email
    const { data: existing } = await supabase
      .from('leads')
      .select('id')
      .eq('email', c.email)
      .maybeSingle();

    if (existing) {
      skippedExisting++;
      continue;
    }

    const { error } = await supabase.from('leads').insert({
      email: c.email,
      business_name: c.business_name,
      owner_name: c.owner_name,
      phone: c.phone,
      source: 'AI_MINED',
      status: 'new',
    } as any);

    if (!error) {
      inserted++;
    }
  }

  await logActivityEvent({
    actorType: 'AI',
    scope: 'LEADS',
    eventType: 'ACTION',
    decision: 'AUTO_ACTION',
    severity: 'LOW',
    summary: `AI mined and inserted ${inserted} new leads (skipped ${skippedExisting} existing)`,
    details: { 
      mode: modeLabel, 
      attempted: slice.length, 
      inserted, 
      skippedExisting,
      strategyProfile: modeState.strategyProfile,
    },
  });

  return { inserted, skippedExisting, mode: modeLabel };
}

/**
 * Get lead mining statistics
 */
export async function getLeadMiningStats(): Promise<{
  todayMined: number;
  weekMined: number;
  totalLeads: number;
  pendingLeads: number;
}> {
  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const weekAgo = new Date();
  weekAgo.setDate(weekAgo.getDate() - 7);

  // Count AI-mined leads today
  const { count: todayMined } = await supabase
    .from('activity_events')
    .select('*', { count: 'exact', head: true })
    .eq('scope', 'LEADS')
    .eq('actor_type', 'AI')
    .ilike('summary', '%mined%')
    .gte('created_at', today.toISOString());

  // Count AI-mined leads this week
  const { count: weekMined } = await supabase
    .from('activity_events')
    .select('*', { count: 'exact', head: true })
    .eq('scope', 'LEADS')
    .eq('actor_type', 'AI')
    .ilike('summary', '%mined%')
    .gte('created_at', weekAgo.toISOString());

  // Total leads count
  const { count: totalLeads } = await supabase
    .from('leads')
    .select('*', { count: 'exact', head: true });

  // Pending (new) leads count
  const { count: pendingLeads } = await supabase
    .from('leads')
    .select('*', { count: 'exact', head: true })
    .eq('status', 'new');

  return {
    todayMined: todayMined || 0,
    weekMined: weekMined || 0,
    totalLeads: totalLeads || 0,
    pendingLeads: pendingLeads || 0,
  };
}
