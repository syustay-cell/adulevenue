// src/lib/wolfSession.ts
// V10 / B100: Session heartbeat helper

import { supabase } from "@/integrations/supabase/client";

export async function heartbeatSession(sessionId: string, extendMinutes = 30) {
  const { data, error } = await supabase.functions.invoke(
    "wolf-session-heartbeat",
    {
      body: {
        session_id: sessionId,
        extend_minutes: extendMinutes,
      },
    }
  );

  if (error) throw error;
  if (!data?.ok) throw new Error(data?.error || "Heartbeat failed");

  return data;
}

export async function startWolfSession(portal: string) {
  const { data, error } = await supabase.functions.invoke(
    "wolf-session-start",
    {
      body: { portal },
    }
  );

  if (error) throw error;
  if (!data?.ok) throw new Error(data?.error || "Session start failed");

  return data.session_id as string;
}

export async function endWolfSession(sessionId: string, reason?: string) {
  const { data, error } = await supabase.functions.invoke(
    "wolf-session-end",
    {
      body: { session_id: sessionId, reason },
    }
  );

  if (error) throw error;
  if (!data?.ok) throw new Error(data?.error || "Session end failed");

  return data;
}
