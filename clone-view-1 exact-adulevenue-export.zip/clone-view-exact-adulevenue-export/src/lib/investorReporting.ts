// MCA Blueprint Module 5: Investor & SPV Layer
import { supabase } from "@/integrations/supabase/client";

export interface Fund {
  id: string;
  code: string;
  name: string;
  description: string | null;
  status: 'open' | 'closed' | 'liquidating';
  created_at: string;
}

export interface SPV {
  id: string;
  fund_id: string;
  code: string;
  name: string;
  description: string | null;
  status: 'open' | 'closed';
}

export interface Investor {
  id: string;
  name: string;
  email: string | null;
  phone: string | null;
  entity_type: 'individual' | 'entity';
  notes: string | null;
}

export interface InvestorPosition {
  id: string;
  investor_id: string;
  fund_id: string | null;
  spv_id: string | null;
  committed: number;
  contributed: number;
  returned: number;
  preferred_return_pct: number | null;
}

export interface FundDealAllocation {
  id: string;
  deal_id: string;
  fund_id: string | null;
  spv_id: string | null;
  allocated_principal: number;
  participation_pct: number | null;
}

export interface FundPerformance {
  fund: Fund;
  total_committed: number;
  total_contributed: number;
  total_returned: number;
  total_deployed: number;
  deal_count: number;
  weighted_return_pct: number;
}

export interface InvestorStatement {
  investor: Investor;
  positions: (InvestorPosition & { fund?: Fund; spv?: SPV })[];
  total_committed: number;
  total_contributed: number;
  total_returned: number;
  net_position: number;
}

export async function getAllFunds(): Promise<Fund[]> {
  const { data, error } = await supabase
    .from('funds')
    .select('*')
    .order('created_at', { ascending: false });

  if (error) return [];
  return (data || []) as Fund[];
}

export async function getFund(fundId: string): Promise<Fund | null> {
  const { data, error } = await supabase
    .from('funds')
    .select('*')
    .eq('id', fundId)
    .single();

  if (error || !data) return null;
  return data as Fund;
}

export async function getSPVsForFund(fundId: string): Promise<SPV[]> {
  const { data, error } = await supabase
    .from('spvs')
    .select('*')
    .eq('fund_id', fundId)
    .order('created_at');

  if (error) return [];
  return (data || []) as SPV[];
}

export async function getAllSPVs(): Promise<SPV[]> {
  const { data, error } = await supabase
    .from('spvs')
    .select('*')
    .order('created_at');

  if (error) return [];
  return (data || []) as SPV[];
}

export async function getAllInvestors(): Promise<Investor[]> {
  const { data, error } = await supabase
    .from('investors')
    .select('*')
    .order('name');

  if (error) return [];
  return (data || []) as Investor[];
}

export async function getInvestor(investorId: string): Promise<Investor | null> {
  const { data, error } = await supabase
    .from('investors')
    .select('*')
    .eq('id', investorId)
    .single();

  if (error || !data) return null;
  return data as Investor;
}

export async function getInvestorPositions(investorId: string): Promise<InvestorPosition[]> {
  const { data, error } = await supabase
    .from('investor_positions')
    .select('*')
    .eq('investor_id', investorId);

  if (error) return [];
  return (data || []) as InvestorPosition[];
}

export async function getFundDealAllocations(fundId: string): Promise<FundDealAllocation[]> {
  const { data, error } = await supabase
    .from('fund_deal_allocations')
    .select('*')
    .eq('fund_id', fundId);

  if (error) return [];
  return (data || []) as FundDealAllocation[];
}

export async function getFundPerformance(fundId: string): Promise<FundPerformance | null> {
  // Get the fund
  const fund = await getFund(fundId);
  if (!fund) return null;

  // Get all investor positions for this fund
  const { data: positions } = await supabase
    .from('investor_positions')
    .select('*')
    .eq('fund_id', fundId);

  const positionsList = (positions || []) as InvestorPosition[];

  // Calculate totals from positions
  const total_committed = positionsList.reduce((sum, p) => sum + (p.committed || 0), 0);
  const total_contributed = positionsList.reduce((sum, p) => sum + (p.contributed || 0), 0);
  const total_returned = positionsList.reduce((sum, p) => sum + (p.returned || 0), 0);

  // Get deal allocations
  const allocations = await getFundDealAllocations(fundId);
  const total_deployed = allocations.reduce((sum, a) => sum + (a.allocated_principal || 0), 0);
  const deal_count = allocations.length;

  // Calculate weighted return
  const weighted_return_pct = total_contributed > 0 
    ? ((total_returned - total_contributed) / total_contributed) * 100 
    : 0;

  return {
    fund,
    total_committed,
    total_contributed,
    total_returned,
    total_deployed,
    deal_count,
    weighted_return_pct,
  };
}

export async function getInvestorStatement(investorId: string): Promise<InvestorStatement | null> {
  // Get investor
  const investor = await getInvestor(investorId);
  if (!investor) return null;

  // Get positions
  const positionsRaw = await getInvestorPositions(investorId);
  
  // Enrich with fund/spv data
  const positions = await Promise.all(
    positionsRaw.map(async (p) => {
      let fund: Fund | undefined;
      let spv: SPV | undefined;
      
      if (p.fund_id) {
        const f = await getFund(p.fund_id);
        if (f) fund = f;
      }
      if (p.spv_id) {
        const { data } = await supabase.from('spvs').select('*').eq('id', p.spv_id).single();
        if (data) spv = data as SPV;
      }
      
      return { ...p, fund, spv };
    })
  );

  // Calculate totals
  const total_committed = positions.reduce((sum, p) => sum + (p.committed || 0), 0);
  const total_contributed = positions.reduce((sum, p) => sum + (p.contributed || 0), 0);
  const total_returned = positions.reduce((sum, p) => sum + (p.returned || 0), 0);
  const net_position = total_contributed - total_returned;

  return {
    investor,
    positions,
    total_committed,
    total_contributed,
    total_returned,
    net_position,
  };
}

export async function createFundDealAllocation(
  dealId: string,
  fundId: string | null,
  spvId: string | null,
  allocatedPrincipal: number,
  participationPct?: number
): Promise<{ allocation: FundDealAllocation | null; error?: string }> {
  const { data, error } = await supabase
    .from('fund_deal_allocations')
    .insert({
      deal_id: dealId,
      fund_id: fundId,
      spv_id: spvId,
      allocated_principal: allocatedPrincipal,
      participation_pct: participationPct || null,
    })
    .select()
    .single();

  if (error) return { allocation: null, error: error.message };
  return { allocation: data as FundDealAllocation };
}

export function formatCurrency(amount: number): string {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(amount);
}

export function formatPercent(value: number): string {
  return `${value >= 0 ? '+' : ''}${value.toFixed(2)}%`;
}

export function getFundStatusColor(status: string): string {
  switch (status) {
    case 'open': return 'text-green-600';
    case 'closed': return 'text-gray-600';
    case 'liquidating': return 'text-orange-600';
    default: return 'text-muted-foreground';
  }
}
