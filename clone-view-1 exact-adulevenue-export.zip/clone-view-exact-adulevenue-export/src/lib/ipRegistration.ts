// V15 - Client-side IP Registration Helper
import { supabase } from "@/integrations/supabase/client";

export interface RegisterIPParams {
  tenant_id?: string;
  asset_type: "code" | "ui" | "workflow" | "prompt" | "brand" | "document" | "model" | "config";
  name: string;
  description?: string;
  source_path?: string;
  content?: string;
  tags?: string[];
  legal_priority?: "low" | "medium" | "high" | "critical";
  brand_key?: string;
  version_tag?: string;
  change_type?: "create" | "update" | "refactor" | "branch" | "deprecate";
  metadata?: Record<string, unknown>;
  ai_generated?: boolean;
}

/**
 * Register an IP asset from the frontend
 * Non-blocking - logs errors but doesn't throw
 */
export async function registerIPAsset(params: RegisterIPParams): Promise<{
  success: boolean;
  asset_id?: string;
  error?: string;
}> {
  try {
    const { data, error } = await supabase.functions.invoke("wf-ip-auto-register", {
      body: {
        tenant_id: params.tenant_id || "wolf-fund",
        ...params,
      },
    });

    if (error) {
      console.error("[registerIPAsset] Error:", error);
      return { success: false, error: error.message };
    }

    return { success: true, asset_id: data?.asset_id };
  } catch (err: any) {
    console.error("[registerIPAsset] Exception:", err);
    return { success: false, error: err.message };
  }
}

/**
 * Register core Wolf Fund assets (call once on app init for coverage)
 */
export async function registerCoreAssets(): Promise<void> {
  const coreAssets: RegisterIPParams[] = [
    // Wolf Fund Core Workflows
    {
      asset_type: "workflow",
      name: "Credit Repair Engine",
      description: "AI-powered credit repair dispute generation and tracking system",
      source_path: "supabase/functions/wf-credit-dispute-generate",
      legal_priority: "critical",
      brand_key: "wolf-fund",
      tags: ["core", "credit-repair", "ai-powered"],
    },
    {
      asset_type: "workflow",
      name: "Wolf Motherboard",
      description: "Central governance and configuration system for Wolf Fund ecosystem",
      source_path: "src/pages/WolfMotherboard.tsx",
      legal_priority: "critical",
      brand_key: "wolf-fund",
      tags: ["core", "governance", "admin"],
    },
    {
      asset_type: "workflow",
      name: "Billing & Usage Spine",
      description: "Multi-tenant usage tracking and billing system",
      source_path: "supabase/functions/wf-billing-log-usage",
      legal_priority: "high",
      brand_key: "wolf-fund",
      tags: ["core", "billing", "usage"],
    },
    {
      asset_type: "workflow",
      name: "Client Portal Exchange",
      description: "Secure document exchange portal for clients",
      source_path: "supabase/functions/wf-client-portal-exchange",
      legal_priority: "high",
      brand_key: "wolf-fund",
      tags: ["core", "client-portal"],
    },
    {
      asset_type: "config",
      name: "Governance Scanner",
      description: "Automated governance checks for billing, IP, and AI changes",
      source_path: "supabase/functions/wf-governance-scan",
      legal_priority: "high",
      brand_key: "wolf-fund",
      tags: ["core", "governance"],
    },
    // ABG Brand Assets
    {
      asset_type: "brand",
      name: "ABG Brand Package",
      description: "Advance Builders Group brand identity and theming",
      source_path: "src/brands/abg",
      legal_priority: "critical",
      brand_key: "abg",
      tags: ["brand", "abg", "construction"],
    },
    {
      asset_type: "ui",
      name: "ABG Home Page",
      description: "ABG landing page and hero section",
      source_path: "src/brands/abg/pages/ABGHome.tsx",
      legal_priority: "high",
      brand_key: "abg",
      tags: ["ui", "abg", "landing"],
    },
    {
      asset_type: "ui",
      name: "ABG Application Form",
      description: "ABG funding application intake form",
      source_path: "src/brands/abg/pages/ABGApply.tsx",
      legal_priority: "high",
      brand_key: "abg",
      tags: ["ui", "abg", "application"],
    },
    {
      asset_type: "ui",
      name: "ABG Dashboard",
      description: "ABG client dashboard for application tracking",
      source_path: "src/brands/abg/pages/ABGDashboard.tsx",
      legal_priority: "medium",
      brand_key: "abg",
      tags: ["ui", "abg", "dashboard"],
    },
    {
      asset_type: "ui",
      name: "ABG Services Page",
      description: "ABG services and funding options page",
      source_path: "src/brands/abg/pages/ABGServices.tsx",
      legal_priority: "medium",
      brand_key: "abg",
      tags: ["ui", "abg", "services"],
    },
    // IP Guardian
    {
      asset_type: "workflow",
      name: "IP Guardian System",
      description: "Intellectual property tracking and legal documentation system",
      source_path: "src/core/ip-guardian",
      legal_priority: "critical",
      brand_key: "wolf-fund",
      tags: ["core", "ip", "legal"],
    },
  ];

  // Register in background (non-blocking)
  for (const asset of coreAssets) {
    registerIPAsset(asset).catch(() => {
      // Silently fail - this is just for coverage tracking
    });
  }
}
