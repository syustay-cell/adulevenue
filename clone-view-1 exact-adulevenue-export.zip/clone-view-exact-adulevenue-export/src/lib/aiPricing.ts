// AI Provider Pricing Configuration
// Used to estimate costs based on usage logs

export const AI_PRICING = {
  openai: {
    name: 'OpenAI',
    input_per_1k: 0.005,   // GPT-4 turbo pricing
    output_per_1k: 0.015,
    models: {
      'gpt-4-turbo': { input: 0.01, output: 0.03 },
      'gpt-4o': { input: 0.005, output: 0.015 },
      'gpt-4o-mini': { input: 0.00015, output: 0.0006 },
      'gpt-3.5-turbo': { input: 0.0005, output: 0.0015 },
    }
  },
  gateway: {
    name: 'AI Gateway',
    input_per_1k: 0.004,
    output_per_1k: 0.012,
    models: {
      'google/gemini-2.5-flash': { input: 0.0001, output: 0.0004 },
      'google/gemini-2.5-pro': { input: 0.00125, output: 0.005 },
      'google/gemini-3-pro-preview': { input: 0.00125, output: 0.005 },
    }
  },
  google: {
    name: 'Google (Direct)',
    input_per_1k: 0.00125,
    output_per_1k: 0.005,
    models: {
      'gemini-1.5-flash': { input: 0.0001, output: 0.0004 },
      'gemini-1.5-pro': { input: 0.00125, output: 0.005 },
    }
  },
  anthropic: {
    name: 'Anthropic',
    input_per_1k: 0.008,
    output_per_1k: 0.024,
    models: {
      'claude-3-opus': { input: 0.015, output: 0.075 },
      'claude-3-sonnet': { input: 0.003, output: 0.015 },
      'claude-3-haiku': { input: 0.00025, output: 0.00125 },
    }
  }
} as const;

export type ProviderKey = keyof typeof AI_PRICING;

export function estimateCost(
  provider: string,
  inputChars: number,
  outputChars: number,
  model?: string
): number {
  const providerConfig = AI_PRICING[provider as ProviderKey];
  if (!providerConfig) return 0;

  // Convert chars to approximate tokens (1 token ≈ 4 chars)
  const inputTokens = inputChars / 4;
  const outputTokens = outputChars / 4;

  // Use model-specific pricing if available
  if (model && providerConfig.models) {
    const models = providerConfig.models as Record<string, { input: number; output: number }>;
    if (model in models) {
      const modelPricing = models[model];
      return (
        (inputTokens / 1000) * modelPricing.input +
        (outputTokens / 1000) * modelPricing.output
      );
    }
  }

  // Fall back to provider default pricing
  const inputK = inputChars / 1000;
  const outputK = outputChars / 1000;
  return inputK * providerConfig.input_per_1k + outputK * providerConfig.output_per_1k;
}
