import { supabase } from '@/integrations/supabase/client';

export type ExecutionMode = 'MANUAL' | 'AUTOPILOT';
export type StrategyProfile = 'STANDARD' | 'ECO' | 'AGGRESSIVE';
export type OwnerMode = 'LOCKED' | 'OPTIMIZATION';

// Legacy compatibility type
export type SystemMode = 'MANUAL' | 'AUTOPILOT' | 'OPTIMIZATION_PILOT';

export interface SystemModeState {
  executionMode: ExecutionMode;
  strategyProfile: StrategyProfile;
  ownerMode: OwnerMode;
}

/**
 * Internal helper to read a system_settings key as JSON.
 */
async function getSetting<T = Record<string, unknown>>(key: string, fallback: T): Promise<T> {
  const { data, error } = await supabase
    .from('system_settings')
    .select('value_json')
    .eq('key', key)
    .maybeSingle();

  if (error || !data) {
    console.warn(`[SystemMode] failed to read ${key}`, error);
    return fallback;
  }

  return (data.value_json as T) ?? fallback;
}

/**
 * Internal helper to upsert a system_settings key.
 */
async function setSetting(key: string, value: Record<string, unknown>): Promise<void> {
  // First try update
  const { data: existing } = await supabase
    .from('system_settings')
    .select('key')
    .eq('key', key)
    .maybeSingle();
    
  if (existing) {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const { error } = await supabase
      .from('system_settings')
      .update({ value_json: value } as any)
      .eq('key', key);

    if (error) {
      console.error(`[SystemMode] failed to update ${key}`, error);
      throw new Error(error.message);
    }
  } else {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const { error } = await supabase
      .from('system_settings')
      .insert({ key, value_json: value } as any);

    if (error) {
      console.error(`[SystemMode] failed to insert ${key}`, error);
      throw new Error(error.message);
    }
  }
}

/**
 * Read the full composed mode state.
 */
export async function getSystemModeState(): Promise<SystemModeState> {
  const execution = await getSetting<{ mode?: ExecutionMode }>('execution_mode', {
    mode: 'AUTOPILOT',
  });

  const strategy = await getSetting<{ profile?: StrategyProfile }>('strategy_profile', {
    profile: 'STANDARD',
  });

  const owner = await getSetting<{ status?: OwnerMode }>('owner_mode', {
    status: 'LOCKED',
  });

  return {
    executionMode: execution.mode ?? 'AUTOPILOT',
    strategyProfile: strategy.profile ?? 'STANDARD',
    ownerMode: owner.status ?? 'LOCKED',
  };
}

/**
 * Legacy function for backward compatibility
 */
export async function getSystemMode(): Promise<SystemMode> {
  const state = await getSystemModeState();
  if (state.executionMode === 'MANUAL') return 'MANUAL';
  if (state.ownerMode === 'OPTIMIZATION') return 'OPTIMIZATION_PILOT';
  return 'AUTOPILOT';
}

/**
 * Legacy function for backward compatibility
 */
export async function setSystemMode(mode: SystemMode): Promise<{ success: boolean; error?: string }> {
  try {
    if (mode === 'MANUAL') {
      await setExecutionMode('MANUAL');
    } else if (mode === 'AUTOPILOT') {
      await setExecutionMode('AUTOPILOT');
      await setOwnerMode('LOCKED');
    } else if (mode === 'OPTIMIZATION_PILOT') {
      await setExecutionMode('AUTOPILOT');
      await setOwnerMode('OPTIMIZATION');
    }
    return { success: true };
  } catch (error) {
    return { success: false, error: error instanceof Error ? error.message : 'Unknown error' };
  }
}

/**
 * Write individual knobs.
 */
export async function setExecutionMode(mode: ExecutionMode): Promise<void> {
  await setSetting('execution_mode', { mode });
}

export async function setStrategyProfile(profile: StrategyProfile): Promise<void> {
  await setSetting('strategy_profile', { profile });
}

export async function setOwnerMode(status: OwnerMode): Promise<void> {
  await setSetting('owner_mode', { status });
}

/**
 * Verify 555 optimization PIN.
 */
export async function verifyOptimizationPin(pin: string): Promise<boolean> {
  const data = await getSetting<{ pin?: string } | null>('optimization_pin', null);
  if (!data?.pin) return false;
  return data.pin === pin;
}

/**
 * Convenience helpers for other modules.
 */

// execution
export function isAutopilot(state: SystemModeState): boolean {
  return state.executionMode === 'AUTOPILOT';
}

export function isManual(state: SystemModeState): boolean {
  return state.executionMode === 'MANUAL';
}

// strategy
export function isEco(state: SystemModeState): boolean {
  return state.strategyProfile === 'ECO';
}

export function isAggressive(state: SystemModeState): boolean {
  return state.strategyProfile === 'AGGRESSIVE';
}

export function isStandard(state: SystemModeState): boolean {
  return state.strategyProfile === 'STANDARD';
}

// owner
export function isOptimization(state: SystemModeState): boolean {
  return state.ownerMode === 'OPTIMIZATION';
}

/**
 * Check if current mode allows automatic actions
 */
export function isAutopilotEnabled(mode: SystemMode): boolean {
  return mode === 'AUTOPILOT';
}

/**
 * Check if optimization features are available
 */
export function isOptimizationMode(mode: SystemMode): boolean {
  return mode === 'OPTIMIZATION_PILOT';
}

/**
 * Friendly label / description for UI.
 */
export function getModeDisplayInfo(
  state: SystemModeState | SystemMode,
): { label: string; description: string; chip: string; color: string } {
  // Handle legacy SystemMode type
  if (typeof state === 'string') {
    switch (state) {
      case 'MANUAL':
        return {
          label: 'Manual',
          description: 'No automatic actions. All decisions require human approval.',
          chip: 'Manual',
          color: 'text-yellow-600',
        };
      case 'AUTOPILOT':
        return {
          label: 'Autopilot',
          description: 'Safe automation enabled. System handles routine tasks with guardrails.',
          chip: 'Autopilot',
          color: 'text-green-600',
        };
      case 'OPTIMIZATION_PILOT':
        return {
          label: 'Optimization (555)',
          description: 'Owner mode. Tune the machine itself—rules, pricing, caps.',
          chip: 'Optimization 555',
          color: 'text-blue-600',
        };
    }
  }

  const { executionMode, strategyProfile } = state;

  const execLabel = executionMode === 'MANUAL' ? 'Manual' : 'Autopilot';

  const strategyLabel =
    strategyProfile === 'ECO'
      ? 'Eco'
      : strategyProfile === 'AGGRESSIVE'
      ? 'Aggressive'
      : 'Standard';

  const label = `${execLabel} · ${strategyLabel}`;

  let description = '';
  let color = 'text-muted-foreground';
  
  if (executionMode === 'MANUAL') {
    description = 'AI suggests, humans approve. No automatic actions are executed.';
    color = 'text-yellow-600';
  } else {
    if (strategyProfile === 'ECO') {
      description = 'Safe, conservative Autopilot. Lower risk, smaller moves, minimal spending.';
      color = 'text-emerald-600';
    } else if (strategyProfile === 'AGGRESSIVE') {
      description = 'High-octane Autopilot. Faster outreach, bolder offers, within guardrails.';
      color = 'text-orange-600';
    } else {
      description = 'Balanced Autopilot. Normal volume, standard risk/return targeting.';
      color = 'text-green-600';
    }
  }

  const chip =
    executionMode === 'MANUAL'
      ? 'Manual'
      : strategyProfile === 'ECO'
      ? 'Autopilot · Eco'
      : strategyProfile === 'AGGRESSIVE'
      ? 'Autopilot · Aggressive'
      : 'Autopilot · Standard';

  return { label, description, chip, color };
}
