// Global activity logging helper for all dashboards
import { supabase } from '@/integrations/supabase/client';
import { getSystemModeState, type SystemModeState } from './systemMode';

// Legacy types (kept for backward compatibility)
export type ActivityEventTypeLegacy =
  | 'lead'
  | 'funding'
  | 'credit_repair'
  | 'permission'
  | 'system';

export type ActivityDecisionLegacy = 'approved' | 'denied' | 'pending' | null;

interface LogActivityParams {
  actorId: string;
  actorEmail: string;
  actorRole: string;
  eventType: ActivityEventTypeLegacy;
  decision?: ActivityDecisionLegacy;
  summary: string;
  contextType: 'lead' | 'application' | 'credit_case' | 'user' | 'batch';
  contextId?: string | null;
}

export async function logActivity(params: LogActivityParams) {
  const { error } = await supabase.from('activity_feed').insert({
    actor_user_id: params.actorId,
    actor_email: params.actorEmail,
    actor_role: params.actorRole,
    event_type: params.eventType,
    decision: params.decision ?? null,
    summary: params.summary,
    context_type: params.contextType,
    context_id: params.contextId ?? null,
  });

  if (error) {
    console.error('[activity] logActivity error', error);
  }
}

// ============================================================================
// NEW Activity Events System (with mode metadata)
// ============================================================================

export type ActivityScope =
  | 'UNDERWRITING'
  | 'COLLECTIONS'
  | 'RENEWALS'
  | 'CREDIT_REPAIR'
  | 'SYSTEM_MODE'
  | 'LEADS'
  | 'GENERAL';

export type ActivityEventType =
  | 'DECISION'
  | 'ACTION'
  | 'MODE_CHANGE'
  | 'SUMMARY'
  | 'JOB_RUN';

export type ActivityDecision =
  | 'APPROVED'
  | 'DECLINED'
  | 'ESCALATED'
  | 'AUTO_ACTION'
  | 'INFO';

export type ActivitySeverity = 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';

export interface ActivityEvent {
  id: string;
  created_at: string;
  actor_type: string;
  actor_id: string | null;
  scope: ActivityScope;
  event_type: ActivityEventType;
  decision: ActivityDecision | null;
  severity: ActivitySeverity | null;
  lead_id: string | null;
  deal_id: string | null;
  iso_id: string | null;
  execution_mode: string;
  strategy_profile: string;
  owner_mode: string;
  summary: string;
  details_json: Record<string, unknown> | null;
}

export interface ActivityFilters {
  scope?: ActivityScope | 'ALL';
  decision?: ActivityDecision | 'ALL';
  mode?: 'ALL' | 'MANUAL' | 'AUTOPILOT_STANDARD' | 'AUTOPILOT_ECO' | 'AUTOPILOT_AGGRESSIVE';
  limit?: number;
}

/**
 * Log an event with the *current* mode snapshot baked in.
 */
export async function logActivityEvent(params: {
  actorType: 'ADMIN' | 'WORKER' | 'AI' | 'SYSTEM';
  actorId?: string | null;
  scope: ActivityScope;
  eventType: ActivityEventType;
  decision?: ActivityDecision | null;
  severity?: ActivitySeverity | null;
  leadId?: string | null;
  dealId?: string | null;
  isoId?: string | null;
  summary: string;
  details?: Record<string, unknown> | null;
}): Promise<{ success: boolean; error?: string }> {
  const mode: SystemModeState = await getSystemModeState();

  const payload = {
    actor_type: params.actorType,
    actor_id: params.actorId ?? null,
    scope: params.scope,
    event_type: params.eventType,
    decision: params.decision ?? null,
    severity: params.severity ?? null,
    lead_id: params.leadId ?? null,
    deal_id: params.dealId ?? null,
    iso_id: params.isoId ?? null,
    execution_mode: mode.executionMode,
    strategy_profile: mode.strategyProfile,
    owner_mode: mode.ownerMode,
    summary: params.summary,
    details_json: params.details ?? null,
  };

  const { error } = await supabase.from('activity_events').insert(payload as never);

  if (error) {
    console.error('[ActivityLog] Failed to insert event', error);
    return { success: false, error: error.message };
  }

  return { success: true };
}

/**
 * Query events for the Live Activity Command Center.
 */
export async function getActivityEvents(filters: ActivityFilters): Promise<ActivityEvent[]> {
  const { scope = 'ALL', decision = 'ALL', mode = 'ALL', limit = 50 } = filters;

  let query = supabase
    .from('activity_events')
    .select('*')
    .order('created_at', { ascending: false })
    .limit(limit);

  if (scope !== 'ALL') {
    query = query.eq('scope', scope);
  }

  if (decision !== 'ALL') {
    query = query.eq('decision', decision);
  }

  if (mode !== 'ALL') {
    switch (mode) {
      case 'MANUAL':
        query = query.eq('execution_mode', 'MANUAL');
        break;
      case 'AUTOPILOT_STANDARD':
        query = query
          .eq('execution_mode', 'AUTOPILOT')
          .eq('strategy_profile', 'STANDARD');
        break;
      case 'AUTOPILOT_ECO':
        query = query
          .eq('execution_mode', 'AUTOPILOT')
          .eq('strategy_profile', 'ECO');
        break;
      case 'AUTOPILOT_AGGRESSIVE':
        query = query
          .eq('execution_mode', 'AUTOPILOT')
          .eq('strategy_profile', 'AGGRESSIVE');
        break;
    }
  }

  const { data, error } = await query;

  if (error) {
    console.error('[ActivityLog] Failed to load events', error);
    return [];
  }

  return (data || []) as ActivityEvent[];
}

/**
 * Convert mode filter to human-readable label for narrator
 */
export function getModeFilterLabel(mode: ActivityFilters['mode']): string | null {
  switch (mode) {
    case 'MANUAL':
      return 'Manual';
    case 'AUTOPILOT_STANDARD':
      return 'Autopilot · Standard';
    case 'AUTOPILOT_ECO':
      return 'Autopilot · Eco';
    case 'AUTOPILOT_AGGRESSIVE':
      return 'Autopilot · Aggressive';
    default:
      return null;
  }
}

/**
 * Build a short spoken summary of the last N minutes of activity.
 * Optionally include mode label for filtered views.
 */
export function summarizeEventsForSpeech(
  events: ActivityEvent[],
  windowMinutes: number,
  modeLabel?: string | null
): string {
  const modeContext = modeLabel ? `, in ${modeLabel} mode,` : '';

  if (!events.length) {
    return `In the last ${windowMinutes} minutes${modeContext} there were no tracked actions.`;
  }

  const now = Date.now();
  const cut = now - windowMinutes * 60 * 1000;

  const recent = events.filter((e) => {
    const t = new Date(e.created_at).getTime();
    return t >= cut;
  });

  if (!recent.length) {
    return `In the last ${windowMinutes} minutes${modeContext} there were no tracked actions.`;
  }

  const total = recent.length;
  const autoActions = recent.filter((e) => e.actor_type === 'AI').length;
  const approvals = recent.filter((e) => e.decision === 'APPROVED').length;
  const declines = recent.filter((e) => e.decision === 'DECLINED').length;
  const escalations = recent.filter((e) => e.decision === 'ESCALATED').length;

  const byScope: Record<string, number> = {};
  for (const e of recent) {
    byScope[e.scope] = (byScope[e.scope] || 0) + 1;
  }

  const scopeParts = Object.entries(byScope).map(
    ([scope, count]) => `${count} in ${scope.toLowerCase().replace('_', ' ')}`,
  );

  const scopeSentence = scopeParts.length
    ? `Activity split: ${scopeParts.join(', ')}.`
    : '';

  return [
    `In the last ${windowMinutes} minutes${modeContext} there were ${total} tracked events.`,
    `${autoActions} were AI-driven actions, ${approvals} approvals, ${declines} declines, and ${escalations} escalations.`,
    scopeSentence,
  ]
    .filter(Boolean)
    .join(' ');
}
