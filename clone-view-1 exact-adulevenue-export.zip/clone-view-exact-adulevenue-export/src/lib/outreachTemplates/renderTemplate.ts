import { OutreachTemplate } from "./templateRegistry";

interface RenderData {
  ownerName?: string;
  businessName?: string;
}

export function renderTemplate(
  template: OutreachTemplate,
  data: RenderData
): { subject?: string; body: string } {
  const interpolate = (text?: string) => {
    if (!text) return undefined;

    return text
      .replace(/{{ownerName}}/g, data.ownerName || "")
      .replace(/{{businessName}}/g, data.businessName || "");
  };

  return {
    subject: interpolate(template.subject),
    body: interpolate(template.body),
  };
}
