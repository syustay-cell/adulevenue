import { TEMPLATE_REGISTRY, OutreachChannel, OutreachMode } from "./templateRegistry";

export function getTemplateForMode(
  mode: OutreachMode,
  channel: OutreachChannel
) {
  // Always select highest version
  const candidates = TEMPLATE_REGISTRY.filter(
    (t) => t.mode === mode && t.channel === channel
  );

  if (candidates.length === 0) return null;

  return candidates.sort((a, b) => b.version - a.version)[0];
}
