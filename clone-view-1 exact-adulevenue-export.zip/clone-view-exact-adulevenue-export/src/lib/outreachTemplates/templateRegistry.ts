// Master template registry for all outreach modes and channels

export type OutreachMode = "ECO" | "STANDARD" | "AGGRESSIVE";
export type OutreachChannel = "email" | "sms";

export interface OutreachTemplate {
  id: string;
  version: number;
  mode: OutreachMode;
  channel: OutreachChannel;
  subject?: string;
  body: string;
  previewText?: string;
  requiresBusinessName?: boolean;
  requiresOwnerName?: boolean;
}

// =======================
// TEMPLATE REGISTRY
// =======================

export const TEMPLATE_REGISTRY: OutreachTemplate[] = [
  // ========================
  // ECO — Soft Touch
  // ========================
  {
    id: "eco_email_v1",
    version: 1,
    mode: "ECO",
    channel: "email",
    subject: "Quick Question — Funding Options",
    previewText: "A soft intro meant to drive curiosity.",
    body: `
Hi {{ownerName}},

Hope you're doing well. I just wanted to quickly share that we have a few gentle, no-pressure funding options available that may help {{businessName}} with cash flow.

If you'd like, I can run numbers and send a simple breakdown — no commitment.

Would you like me to send options?

Best,
Funding Desk
    `,
    requiresOwnerName: true,
    requiresBusinessName: true,
  },

  {
    id: "eco_sms_v1",
    version: 1,
    mode: "ECO",
    channel: "sms",
    body: `Hi {{ownerName}}, quick note — we can check soft funding options for {{businessName}} (no impact, no commitment). Want details?`,
    requiresOwnerName: true,
    requiresBusinessName: true,
  },

  // ========================
  // STANDARD — Neutral
  // ========================
  {
    id: "std_email_v1",
    version: 1,
    mode: "STANDARD",
    channel: "email",
    subject: "Funding Availability for {{businessName}}",
    previewText: "Balanced outreach, most used template.",
    body: `
Hi {{ownerName}},

We reviewed some updated programs and {{businessName}} qualifies for new funding offers that may improve cash flow or reduce daily payments.

Would you like me to prepare a few options for review?

Best,
Funding Desk
    `,
    requiresOwnerName: true,
    requiresBusinessName: true,
  },

  {
    id: "std_sms_v1",
    version: 1,
    mode: "STANDARD",
    channel: "sms",
    body: `Hi {{ownerName}}, we have updated funding terms for {{businessName}}. Want me to send options?`,
    requiresOwnerName: true,
    requiresBusinessName: true,
  },

  // ========================
  // AGGRESSIVE — High Intent
  // ========================
  {
    id: "agg_email_v1",
    version: 1,
    mode: "AGGRESSIVE",
    channel: "email",
    subject: "Urgent: Immediate Funding Opportunity for {{businessName}}",
    previewText: "Strong CTA, intended for high-intent leads.",
    body: `
Hi {{ownerName}},

We have a **priority funding window** open for {{businessName}}.

If timing or cash flow is tight, I can lock in an approval and send a breakdown immediately.  
Response window is short — want me to prepare terms?

Best,
Senior Funding Desk
    `,
    requiresOwnerName: true,
    requiresBusinessName: true,
  },

  {
    id: "agg_sms_v1",
    version: 1,
    mode: "AGGRESSIVE",
    channel: "sms",
    body: `{{ownerName}}, urgent funding availability for {{businessName}}. Want terms now?`,
    requiresOwnerName: true,
    requiresBusinessName: true,
  },
];
