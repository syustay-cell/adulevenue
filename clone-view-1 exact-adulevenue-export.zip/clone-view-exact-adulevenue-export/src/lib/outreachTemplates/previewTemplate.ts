import { getTemplateForMode } from "./getTemplate";
import { renderTemplate } from "./renderTemplate";

export function previewOutreachTemplate(mode: "ECO" | "STANDARD" | "AGGRESSIVE") {
  const email = getTemplateForMode(mode, "email");
  const sms = getTemplateForMode(mode, "sms");

  return {
    email: email ? renderTemplate(email, { ownerName: "John", businessName: "Sample Corp" }) : null,
    sms: sms ? renderTemplate(sms, { ownerName: "John", businessName: "Sample Corp" }) : null,
  };
}
