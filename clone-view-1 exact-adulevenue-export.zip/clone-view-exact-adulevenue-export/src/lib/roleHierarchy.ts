// V28: Role hierarchy utilities - extended for multi-tenant ecosystem

import type { AppRole } from './permissions';

export const ROLE_LEVELS: Record<string, number> = {
  // Super Owner (Platform Owner)
  super_owner: 110,
  owner: 100,

  // Tenant hierarchy
  tenant_owner: 85,
  tenant_admin: 82,
  partner_owner: 81,

  // Internal Wolf roles
  admin: 80,
  underwriter: 70,
  legal_worker: 68,
  credit_repair_specialist: 65,
  legal: 60,
  wolf_worker: 55,
  worker: 50,

  // Tenant/Partner workers
  tenant_worker: 48,
  partner_worker: 46,

  // External partners
  merchant_services_partner: 44,
  funder: 42,
  iso: 40,
  iso_partner: 35,

  // End users
  merchant: 25,
  client: 20,
  user: 10,
};

export function getRoleLevel(role: string): number {
  return ROLE_LEVELS[role] ?? 0;
}

export function getHighestRole(roles: string[]): string {
  if (!roles.length) return 'user';
  return roles.reduce((highest, current) => 
    getRoleLevel(current) > getRoleLevel(highest) ? current : highest
  , roles[0]);
}

export function hasRoleOrHigher(userRoles: string[], minRole: string): boolean {
  const minLevel = getRoleLevel(minRole);
  return userRoles.some(role => getRoleLevel(role) >= minLevel);
}

export function canAccessVault(userRoles: string[]): boolean {
  return userRoles.some(role => role === 'owner' || role === 'super_owner' || role === 'legal' || role === 'legal_worker');
}

export function canAccessMotherboard(userRoles: string[]): boolean {
  return userRoles.some(role => role === 'super_owner');
}

export function isInternalRole(role: string): boolean {
  const internalRoles = ['owner', 'super_owner', 'tenant_admin', 'admin', 'underwriter', 'credit_repair_specialist', 'legal', 'legal_worker', 'worker', 'wolf_worker'];
  return internalRoles.includes(role);
}

export function isExternalRole(role: string): boolean {
  const externalRoles = ['iso', 'iso_partner', 'funder', 'merchant', 'client', 'user', 'partner_owner', 'partner_worker', 'tenant_owner', 'tenant_worker'];
  return externalRoles.includes(role);
}

export function isTenantRole(role: string): boolean {
  return ['tenant_owner', 'tenant_admin', 'tenant_worker', 'partner_owner', 'partner_worker'].includes(role);
}

export function isFunderRole(role: string): boolean {
  return role === 'funder';
}

export function isLegalRole(role: string): boolean {
  return role === 'legal' || role === 'legal_worker';
}
