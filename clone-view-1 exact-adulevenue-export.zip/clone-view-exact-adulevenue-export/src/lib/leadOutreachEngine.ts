// Lead Outreach Engine - Strategy-aware email/SMS outreach
import { supabase } from "@/integrations/supabase/client";
import { getSystemModeState, type SystemModeState } from "./systemMode";
import { getStrategyConfigFromState, canAutoExecuteFromState } from "./systemMode/strategyConfig";
import { logActivityEvent } from "./activity";
import { getTemplateForMode } from "./outreachTemplates/getTemplate";
import { renderTemplate } from "./outreachTemplates/renderTemplate";
import type { OutreachMode } from "./outreachTemplates/templateRegistry";

export interface LeadForOutreach {
  id: string;
  email?: string | null;
  phone?: string | null;
  business_name?: string | null;
  owner_name?: string | null;
}

export interface OutreachResult {
  attempted: number;
  sent: number;
  skipped: number;
  mode: string;
}

// Map strategy aggressiveness to OutreachMode
function getOutreachMode(aggressiveness: 'LOW' | 'MEDIUM' | 'HIGH'): OutreachMode {
  switch (aggressiveness) {
    case 'LOW': return 'ECO';
    case 'HIGH': return 'AGGRESSIVE';
    default: return 'STANDARD';
  }
}

/**
 * Run lead outreach batch - strategy-aware
 * ECO: Lower volume, soft templates
 * STANDARD: Normal volume, balanced templates
 * AGGRESSIVE: High volume, direct templates
 * MANUAL: Only proposes, doesn't send
 */
export async function runLeadOutreachBatch(leads?: LeadForOutreach[]): Promise<OutreachResult> {
  const modeState = await getSystemModeState();
  const strategy = getStrategyConfigFromState(modeState);
  const allowAuto = canAutoExecuteFromState(modeState);
  const modeLabel = `${modeState.executionMode} · ${modeState.strategyProfile}`;

  if (!allowAuto) {
    // Manual mode – AI only proposes messaging
    await logActivityEvent({
      actorType: 'AI',
      scope: 'LEADS',
      eventType: 'DECISION',
      decision: 'INFO',
      severity: 'LOW',
      summary: `Lead outreach batch prepared (Manual mode – awaiting approval)`,
      details: { mode: 'MANUAL', leadsCount: leads?.length || 0 },
    });
    return { attempted: 0, sent: 0, skipped: leads?.length || 0, mode: modeLabel };
  }

  // Get leads if not provided
  let targetLeads = leads;
  if (!targetLeads) {
    const { data } = await supabase
      .from('leads')
      .select('id, email, phone, business_name, owner_name')
      .eq('status', 'new')
      .not('email', 'is', null)
      .limit(strategy.maxColdOutreachPerDay);
    targetLeads = (data || []) as LeadForOutreach[];
  }

  let sent = 0;
  let skipped = 0;
  const outreachMode = getOutreachMode(strategy.outreachAggressiveness);

  for (const lead of targetLeads) {
    if (sent >= strategy.maxColdOutreachPerDay) {
      skipped++;
      continue;
    }

    if (!lead.email) {
      skipped++;
      continue;
    }

    // Use new template system for email
    const emailTemplate = getTemplateForMode(outreachMode, "email");
    let emailBody = '';
    let emailSubject = '';
    
    if (emailTemplate) {
      const rendered = renderTemplate(emailTemplate, {
        ownerName: lead.owner_name || undefined,
        businessName: lead.business_name || undefined,
      });
      emailBody = rendered.body;
      emailSubject = rendered.subject || '';
    }

    // Use new template system for SMS (if phone available)
    let smsBody = '';
    if (lead.phone) {
      const smsTemplate = getTemplateForMode(outreachMode, "sms");
      if (smsTemplate) {
        const smsRendered = renderTemplate(smsTemplate, {
          ownerName: lead.owner_name || undefined,
          businessName: lead.business_name || undefined,
        });
        smsBody = smsRendered.body;
      }
    }

    // In production, this would call send-smart-email edge function
    // For now, we log the outreach attempt
    sent++;

    await logActivityEvent({
      actorType: 'AI',
      scope: 'LEADS',
      eventType: 'ACTION',
      decision: 'AUTO_ACTION',
      severity: 'LOW',
      leadId: lead.id,
      summary: `Autopilot sent ${outreachMode} email to ${lead.business_name || lead.email}`,
      details: { 
        leadId: lead.id, 
        outreachMode, 
        templateId: emailTemplate?.id,
        aggressiveness: strategy.outreachAggressiveness,
        mode: modeLabel,
        hasPhone: !!lead.phone,
      },
    });
  }

  return { 
    attempted: targetLeads.length, 
    sent, 
    skipped,
    mode: modeLabel,
  };
}

/**
 * Get outreach statistics for display
 */
export async function getOutreachStats(): Promise<{
  todaySent: number;
  weekSent: number;
  maxPerDay: number;
  remaining: number;
}> {
  const modeState = await getSystemModeState();
  const strategy = getStrategyConfigFromState(modeState);

  // Count today's outreach from activity_events
  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const { count: todaySent } = await supabase
    .from('activity_events')
    .select('*', { count: 'exact', head: true })
    .eq('scope', 'LEADS')
    .eq('decision', 'AUTO_ACTION')
    .gte('created_at', today.toISOString());

  const weekAgo = new Date();
  weekAgo.setDate(weekAgo.getDate() - 7);

  const { count: weekSent } = await supabase
    .from('activity_events')
    .select('*', { count: 'exact', head: true })
    .eq('scope', 'LEADS')
    .eq('decision', 'AUTO_ACTION')
    .gte('created_at', weekAgo.toISOString());

  return {
    todaySent: todaySent || 0,
    weekSent: weekSent || 0,
    maxPerDay: strategy.maxColdOutreachPerDay,
    remaining: Math.max(0, strategy.maxColdOutreachPerDay - (todaySent || 0)),
  };
}

/**
 * Get lead mining statistics for display
 */
export async function getLeadMiningStats(): Promise<{
  todayMined: number;
  weekMined: number;
  totalLeads: number;
  pendingLeads: number;
}> {
  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const weekAgo = new Date();
  weekAgo.setDate(weekAgo.getDate() - 7);

  // Count leads mined today (source = AI_MINED)
  const { count: todayMined } = await supabase
    .from('leads')
    .select('*', { count: 'exact', head: true })
    .eq('source', 'AI_MINED')
    .gte('created_at', today.toISOString());

  // Count leads mined this week
  const { count: weekMined } = await supabase
    .from('leads')
    .select('*', { count: 'exact', head: true })
    .eq('source', 'AI_MINED')
    .gte('created_at', weekAgo.toISOString());

  // Total leads count
  const { count: totalLeads } = await supabase
    .from('leads')
    .select('*', { count: 'exact', head: true });

  // Pending (new) leads count
  const { count: pendingLeads } = await supabase
    .from('leads')
    .select('*', { count: 'exact', head: true })
    .eq('status', 'new');

  return {
    todayMined: todayMined || 0,
    weekMined: weekMined || 0,
    totalLeads: totalLeads || 0,
    pendingLeads: pendingLeads || 0,
  };
}
