// src/lib/playbookActions.ts

import { supabase } from "@/integrations/supabase/client";
import type {
  WfPlaybook,
  WfPlaybookStep,
  WfPlaybookTrigger,
  WfPlaybookRun,
  PlaybookSuggestion,
} from "@/types/playbooks";

/**
 * Get all playbooks for a tenant
 */
export async function getPlaybooks(tenantId: string): Promise<WfPlaybook[]> {
  const { data, error } = await supabase
    .from("wf_playbooks")
    .select("*")
    .eq("tenant_id", tenantId)
    .order("created_at", { ascending: true });

  if (error) {
    console.error("[getPlaybooks] Error:", error);
    return [];
  }
  return (data || []) as WfPlaybook[];
}

/**
 * Get steps for a playbook
 */
export async function getPlaybookSteps(playbookId: string): Promise<WfPlaybookStep[]> {
  const { data, error } = await supabase
    .from("wf_playbook_steps")
    .select("*")
    .eq("playbook_id", playbookId)
    .order("order_index", { ascending: true });

  if (error) {
    console.error("[getPlaybookSteps] Error:", error);
    return [];
  }
  return (data || []) as WfPlaybookStep[];
}

/**
 * Get triggers for a playbook
 */
export async function getPlaybookTriggers(playbookId: string): Promise<WfPlaybookTrigger[]> {
  const { data, error } = await supabase
    .from("wf_playbook_triggers")
    .select("*")
    .eq("playbook_id", playbookId);

  if (error) {
    console.error("[getPlaybookTriggers] Error:", error);
    return [];
  }
  return (data || []) as WfPlaybookTrigger[];
}

/**
 * Get recent playbook runs for a tenant
 */
export async function getPlaybookRuns(
  tenantId: string,
  options: { limit?: number } = {},
): Promise<WfPlaybookRun[]> {
  const { limit = 20 } = options;

  const { data, error } = await supabase
    .from("wf_playbook_runs")
    .select("*")
    .eq("tenant_id", tenantId)
    .order("started_at", { ascending: false })
    .limit(limit);

  if (error) {
    console.error("[getPlaybookRuns] Error:", error);
    return [];
  }
  return (data || []) as WfPlaybookRun[];
}

/**
 * Request playbook suggestions from ai-playbook-engine
 */
export async function suggestPlaybooks(params: {
  tenantId: string;
  sourceType?: "alert" | "insight" | "manual";
  alertId?: string;
  insightId?: string;
}): Promise<{ ok: boolean; suggestions: PlaybookSuggestion[]; error?: string }> {
  const { data, error } = await supabase.functions.invoke("ai-playbook-engine", {
    body: { ...params, mode: "suggest" },
  });

  if (error) {
    console.error("[suggestPlaybooks] Error:", error);
    return { ok: false, suggestions: [], error: error.message };
  }
  return {
    ok: data?.ok ?? true,
    suggestions: (data?.suggestions || []) as PlaybookSuggestion[],
    error: data?.message,
  };
}

/**
 * Run a playbook manually from UI
 */
export async function runPlaybookManually(params: {
  tenantId: string;
  playbookId: string;
  alertId?: string;
  insightId?: string;
}): Promise<{ ok: boolean; runId?: string; error?: string }> {
  const { data, error } = await supabase.functions.invoke("ai-playbook-engine", {
    body: {
      tenantId: params.tenantId,
      mode: "run_single",
      playbookId: params.playbookId,
      sourceType: "manual",
      alertId: params.alertId,
      insightId: params.insightId,
    },
  });

  if (error) {
    console.error("[runPlaybookManually] Error:", error);
    return { ok: false, error: error.message };
  }
  return {
    ok: data?.ok ?? true,
    runId: data?.run_id,
    error: data?.message,
  };
}

/**
 * Toggle playbook enabled status
 */
export async function togglePlaybookEnabled(
  playbookId: string,
  enabled: boolean,
): Promise<{ ok: boolean; error?: string }> {
  const { error } = await supabase
    .from("wf_playbooks")
    .update({ enabled })
    .eq("id", playbookId);

  if (error) {
    console.error("[togglePlaybookEnabled] Error:", error);
    return { ok: false, error: error.message };
  }
  return { ok: true };
}

/**
 * Create a new playbook
 */
export async function createPlaybook(params: {
  tenantId: string;
  name: string;
  slug: string;
  description?: string;
  scope?: string;
  trigger_mode?: string;
  createdBy?: string;
}): Promise<{ ok: boolean; playbook?: WfPlaybook; error?: string }> {
  const { data, error } = await supabase
    .from("wf_playbooks")
    .insert({
      tenant_id: params.tenantId,
      name: params.name,
      slug: params.slug,
      description: params.description || null,
      scope: params.scope || "admin",
      trigger_mode: params.trigger_mode || "manual",
      created_by: params.createdBy || null,
      enabled: true,
    })
    .select("*")
    .single();

  if (error) {
    console.error("[createPlaybook] Error:", error);
    return { ok: false, error: error.message };
  }

  return { ok: true, playbook: data as WfPlaybook };
}
