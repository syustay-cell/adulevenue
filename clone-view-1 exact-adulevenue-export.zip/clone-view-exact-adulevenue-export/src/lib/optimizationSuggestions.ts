// Optimization Suggestions - 555 Mode Loop Closure
import { supabase } from "@/integrations/supabase/client";
import { getActivityEvents } from "./activity";
import { logActivityEvent } from "./activity";

export interface OptimizationSuggestion {
  id: string;
  created_at: string;
  scope: 'COLLECTIONS' | 'RENEWALS' | 'LEADS' | 'CREDIT_REPAIR';
  suggestion_type: string;
  current_value: Record<string, unknown> | null;
  proposed_value: Record<string, unknown> | null;
  rationale: string | null;
  status: 'pending' | 'applied' | 'rejected';
  applied_at: string | null;
  applied_by: string | null;
}

/**
 * Get pending optimization suggestions
 */
export async function getPendingSuggestions(): Promise<OptimizationSuggestion[]> {
  const { data, error } = await supabase
    .from('system_optimization_suggestions')
    .select('*')
    .eq('status', 'pending')
    .order('created_at', { ascending: false })
    .limit(10);

  if (error) {
    console.error('[OptimizationSuggestions] Failed to load:', error);
    return [];
  }

  return (data || []) as OptimizationSuggestion[];
}

/**
 * Apply a suggestion - updates system_settings and marks suggestion as applied
 */
export async function applySuggestion(
  suggestionId: string, 
  userId: string
): Promise<{ success: boolean; error?: string }> {
  const { data: suggestion, error: fetchError } = await supabase
    .from('system_optimization_suggestions')
    .select('*')
    .eq('id', suggestionId)
    .single();

  if (fetchError || !suggestion) {
    return { success: false, error: 'Suggestion not found' };
  }

  // Apply the proposed value to system_settings based on suggestion type
  // This would update the relevant config in wolf_master_config or system_settings
  // For now, we just mark it as applied

  const { error: updateError } = await supabase
    .from('system_optimization_suggestions')
    .update({
      status: 'applied',
      applied_at: new Date().toISOString(),
      applied_by: userId,
    })
    .eq('id', suggestionId);

  if (updateError) {
    return { success: false, error: updateError.message };
  }

  await logActivityEvent({
    actorType: 'ADMIN',
    scope: 'SYSTEM_MODE',
    eventType: 'ACTION',
    decision: 'APPROVED',
    severity: 'HIGH',
    summary: `Applied optimization suggestion: ${suggestion.suggestion_type} for ${suggestion.scope}`,
    details: { 
      suggestionId, 
      scope: suggestion.scope,
      currentValue: suggestion.current_value,
      proposedValue: suggestion.proposed_value,
    },
  });

  return { success: true };
}

/**
 * Reject a suggestion
 */
export async function rejectSuggestion(
  suggestionId: string,
  userId: string
): Promise<{ success: boolean; error?: string }> {
  const { data: suggestion } = await supabase
    .from('system_optimization_suggestions')
    .select('*')
    .eq('id', suggestionId)
    .single();

  const { error } = await supabase
    .from('system_optimization_suggestions')
    .update({
      status: 'rejected',
      applied_at: new Date().toISOString(),
      applied_by: userId,
    })
    .eq('id', suggestionId);

  if (error) {
    return { success: false, error: error.message };
  }

  await logActivityEvent({
    actorType: 'ADMIN',
    scope: 'SYSTEM_MODE',
    eventType: 'ACTION',
    decision: 'DECLINED',
    severity: 'MEDIUM',
    summary: `Rejected optimization suggestion: ${suggestion?.suggestion_type || 'Unknown'} for ${suggestion?.scope || 'Unknown'}`,
    details: { suggestionId },
  });

  return { success: true };
}

/**
 * Generate optimization suggestions based on recent activity
 * This would typically run as a nightly cron job
 */
export async function generateOptimizationSuggestions(): Promise<{
  generated: number;
  suggestions: Partial<OptimizationSuggestion>[];
}> {
  const events = await getActivityEvents({
    scope: 'ALL',
    decision: 'ALL',
    mode: 'ALL',
    limit: 500,
  });

  const suggestions: Partial<OptimizationSuggestion>[] = [];

  // Analyze renewals - if declines >> approvals, suggest lowering factor
  const renewalEvents = events.filter((e) => e.scope === 'RENEWALS');
  const renewalApprovals = renewalEvents.filter((e) => e.decision === 'APPROVED').length;
  const renewalDeclines = renewalEvents.filter((e) => e.decision === 'DECLINED').length;

  if (renewalDeclines > renewalApprovals * 2 && renewalDeclines > 5) {
    const suggestion = {
      scope: 'RENEWALS' as const,
      suggestion_type: 'ADJUST_RENEWAL_FACTOR',
      current_value: { factor: 'STANDARD <= 1.35' },
      proposed_value: { factor: 'STANDARD <= 1.30', ecoFactor: '1.20' },
      rationale: `Renewal declines (${renewalDeclines}) are more than 2x approvals (${renewalApprovals}) in recent activity. Consider lowering renewal factor to improve acceptance rate.`,
      status: 'pending' as const,
    };
    suggestions.push(suggestion);

    await supabase.from('system_optimization_suggestions').insert(suggestion as any);
  }

  // Analyze collections - if too few auto-actions in ECO mode, suggest increasing
  const collectionEvents = events.filter((e) => e.scope === 'COLLECTIONS');
  const collectionAutoActions = collectionEvents.filter((e) => e.decision === 'AUTO_ACTION').length;
  const collectionEscalations = collectionEvents.filter((e) => e.decision === 'ESCALATED').length;

  if (collectionEscalations > collectionAutoActions * 3 && collectionEscalations > 10) {
    const suggestion = {
      scope: 'COLLECTIONS' as const,
      suggestion_type: 'INCREASE_AUTO_VOLUME',
      current_value: { autoActions: collectionAutoActions },
      proposed_value: { recommendedIncrease: '50%' },
      rationale: `High escalation rate (${collectionEscalations} escalated vs ${collectionAutoActions} auto-handled). Consider switching from ECO to STANDARD profile or increasing auto-action thresholds.`,
      status: 'pending' as const,
    };
    suggestions.push(suggestion);

    await supabase.from('system_optimization_suggestions').insert(suggestion as any);
  }

  // Analyze leads - if low conversion, suggest different outreach approach
  const leadEvents = events.filter((e) => e.scope === 'LEADS');
  const leadAutoActions = leadEvents.filter((e) => e.decision === 'AUTO_ACTION').length;
  const leadApprovals = leadEvents.filter((e) => e.decision === 'APPROVED').length;

  if (leadAutoActions > 50 && leadApprovals < leadAutoActions * 0.05) {
    const suggestion = {
      scope: 'LEADS' as const,
      suggestion_type: 'ADJUST_OUTREACH_STRATEGY',
      current_value: { sent: leadAutoActions, converted: leadApprovals },
      proposed_value: { recommendedAction: 'Switch to SOFT templates in ECO mode' },
      rationale: `Very low lead conversion rate (${leadApprovals}/${leadAutoActions} = ${((leadApprovals/leadAutoActions)*100).toFixed(1)}%). Consider softer outreach templates or reducing volume.`,
      status: 'pending' as const,
    };
    suggestions.push(suggestion);

    await supabase.from('system_optimization_suggestions').insert(suggestion as any);
  }

  return {
    generated: suggestions.length,
    suggestions,
  };
}

/**
 * Get suggestion icon based on type
 */
export function getSuggestionIcon(type: string): string {
  switch (type) {
    case 'ADJUST_RENEWAL_FACTOR': return '📊';
    case 'INCREASE_AUTO_VOLUME': return '📈';
    case 'DECREASE_AUTO_VOLUME': return '📉';
    case 'ADJUST_OUTREACH_STRATEGY': return '✉️';
    default: return '💡';
  }
}

/**
 * Get suggestion severity based on scope
 */
export function getSuggestionSeverity(scope: string): 'low' | 'medium' | 'high' {
  switch (scope) {
    case 'RENEWALS':
    case 'COLLECTIONS':
      return 'high';
    case 'LEADS':
      return 'medium';
    default:
      return 'low';
  }
}
