// src/lib/creditCases.ts
import { supabase } from "@/integrations/supabase/client";

export type CreditCaseV2 = {
  id: string;
  tenant_id: string;
  client_full_name: string | null;
  client_email: string | null;
  client_phone: string | null;
  status: string;
  priority: string | null;
  bureaus?: string[] | null;
  has_identity_theft?: boolean | null;
  created_at?: string;
  updated_at?: string;
};

export type CreditDisputeItemV2 = {
  id: string;
  case_id: string;
  bureau: "transunion" | "experian" | "equifax" | string;
  creditor_name: string | null;
  account_number: string | null;
  account_type: string | null;
  balance: number | null;
  dispute_reason: string | null;
  dispute_status: string | null; // e.g. "pending" | "disputed" | "resolved"
};

export type CreditDisputeDraftV2 = {
  id: string;
  case_id: string;
  tenant_id: string;
  bureau: string;
  letter_type: string;
  subject: string | null;
  body: string | null;
  items_included: string[] | null;
  status: "draft" | "approved" | "sent";
  sent_at?: string | null;
  meta?: any;
};

export type WfTask = {
  id: string;
  tenant_id: string;
  case_id?: string | null;
  lead_id?: string | null;
  task_type: string;
  title: string;
  description: string | null;
  status: "pending" | "completed" | "cancelled";
  priority: "low" | "medium" | "high" | "urgent";
  due_date: string | null;
  auto_generated: boolean | null;
  source: string | null;
  created_at?: string;
};

export async function fetchCreditCase(caseId: string): Promise<CreditCaseV2 | null> {
  const { data, error } = await supabase
    .from("credit_cases_v2")
    .select("*")
    .eq("id", caseId)
    .single();

  if (error) {
    console.error("[fetchCreditCase] error", error);
    throw error;
  }
  return data as CreditCaseV2;
}

export async function fetchDisputeItems(caseId: string): Promise<CreditDisputeItemV2[]> {
  const { data, error } = await supabase
    .from("credit_dispute_items_v2")
    .select("*")
    .eq("case_id", caseId);

  if (error) {
    console.error("[fetchDisputeItems] error", error);
    throw error;
  }
  return (data || []) as CreditDisputeItemV2[];
}

export async function fetchDisputeDrafts(caseId: string): Promise<CreditDisputeDraftV2[]> {
  const { data, error } = await supabase
    .from("credit_dispute_drafts_v2")
    .select("*")
    .eq("case_id", caseId)
    .order("created_at", { ascending: false });

  if (error) {
    console.error("[fetchDisputeDrafts] error", error);
    throw error;
  }
  return (data || []) as CreditDisputeDraftV2[];
}

export async function fetchCaseTasks(caseId: string): Promise<WfTask[]> {
  const { data, error } = await supabase
    .from("wf_tasks")
    .select("*")
    .eq("case_id", caseId)
    .order("due_date", { ascending: true });

  if (error) {
    console.error("[fetchCaseTasks] error", error);
    throw error;
  }
  return (data || []) as WfTask[];
}

/**
 * Call V2.1: wf-credit-dispute-generate
 */
export async function generateDisputeLetters(params: {
  case_id: string;
  bureaus: string[];
  item_ids: string[];
  letter_type?: "dispute" | "validation" | string;
}) {
  const { data, error } = await supabase.functions.invoke("wf-credit-dispute-generate", {
    body: params,
  });

  if (error) {
    console.error("[generateDisputeLetters] error", error);
    throw error;
  }
  return data;
}

/**
 * Call V2.1: wf-credit-dispute-save (edit/approve)
 */
export async function saveDisputeDraft(params: {
  draft_id: string;
  subject?: string;
  body?: string;
  status?: "draft" | "approved" | "sent";
}) {
  const { data, error } = await supabase.functions.invoke("wf-credit-dispute-save", {
    body: params,
  });

  if (error) {
    console.error("[saveDisputeDraft] error", error);
    throw error;
  }
  return data;
}

/**
 * Call V2.1: wf-credit-dispute-mark-sent
 */
export async function markDisputeDraftSent(params: {
  draft_id: string;
  sent_method?: "mail" | "online" | "fax" | string;
  notes?: string;
}) {
  const { data, error } = await supabase.functions.invoke("wf-credit-dispute-mark-sent", {
    body: params,
  });

  if (error) {
    console.error("[markDisputeDraftSent] error", error);
    throw error;
  }
  return data;
}

/**
 * V2.2: wf-ai-worker
 */
export type AiWorkerAction =
  | "draft_email"
  | "summarize_timeline"
  | "suggest_next_step"
  | "explain_strategy";

export async function aiWorkerAction(params: {
  case_id: string;
  action: AiWorkerAction;
  context?: Record<string, any>;
}) {
  const { data, error } = await supabase.functions.invoke("wf-ai-worker", {
    body: params,
  });

  if (error) {
    console.error("[aiWorkerAction] error", error);
    throw error;
  }
  return data as {
    ok: boolean;
    action: string;
    output: string;
    case_context?: any;
    error?: string;
  };
}
