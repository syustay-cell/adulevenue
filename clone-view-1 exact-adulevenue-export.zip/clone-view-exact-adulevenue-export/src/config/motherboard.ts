// src/config/motherboard.ts
// WOLF-FUND.COM – MOTHERBOARD CONFIG – 444 LOCKED
// Single source of truth for role → dashboard → permissions

export type WolfRole =
  | 'owner'
  | 'ceo'
  | 'cfo'
  | 'clo'
  | 'admin'
  | 'win_director'
  | 'worker'
  | 'partner_factory'
  | 'iso'
  | 'funder'
  | 'investor'
  | 'gov_donor'
  | 'legal'
  | 'credit_repair_specialist'
  | 'public';

export interface DashboardRoute {
  path: string;
  label: string;
  icon?: string;
}

export interface RoleDashboardConfig {
  defaultRoute: string;
  menu: DashboardRoute[];
}

export const MOTHERBOARD_CONFIG: Record<WolfRole, RoleDashboardConfig> = {
  owner: {
    defaultRoute: '/owner/motherboard',
    menu: [
      { path: '/owner/motherboard', label: 'Motherboard' },
      { path: '/owner/underwriting', label: 'Underwriting' },
      { path: '/owner/creditfix', label: 'Credit Fix' },
      { path: '/owner/events', label: 'Events' },
      { path: '/owner/settings', label: 'Settings' },
    ],
  },
  ceo: {
    defaultRoute: '/ceo',
    menu: [
      { path: '/ceo', label: 'Command Center' },
      { path: '/lead-engine', label: 'Lead Engine' },
      { path: '/owner/motherboard', label: 'Owner Motherboard' },
    ],
  },
  cfo: {
    defaultRoute: '/cfo',
    menu: [
      { path: '/cfo', label: 'Finance & Escrow' },
      { path: '/admin/billing', label: 'Billing' },
      { path: '/admin/dashboard', label: 'Admin Dashboard' },
    ],
  },
  clo: {
    defaultRoute: '/clo',
    menu: [
      { path: '/clo', label: 'Contracts & Compliance' },
      { path: '/legal/dashboard', label: 'Legal Dashboard' },
      { path: '/legal/queue', label: 'Legal Queue' },
    ],
  },
  admin: {
    defaultRoute: '/admin/dashboard',
    menu: [
      { path: '/admin/dashboard', label: 'Dashboard' },
      { path: '/admin/underwriting', label: 'Underwriting' },
      { path: '/admin/users', label: 'Users' },
      { path: '/admin/settings', label: 'Settings' },
    ],
  },
  worker: {
    defaultRoute: '/worker/dashboard',
    menu: [
      { path: '/worker/dashboard', label: 'Dashboard' },
      { path: '/worker/queue', label: 'My Queue' },
      { path: '/worker/creditfix', label: 'Credit Fix' },
    ],
  },
  win_director: {
    defaultRoute: '/win-director',
    menu: [
      { path: '/win-director', label: 'WIN Director' },
      { path: '/worker/dashboard', label: 'Worker Dashboard' },
    ],
  },
  partner_factory: {
    defaultRoute: '/partner/factory',
    menu: [
      { path: '/partner/factory', label: 'Factory Queue' },
      { path: '/partner/dashboard', label: 'Partner Dashboard' },
    ],
  },
  iso: {
    defaultRoute: '/iso/dashboard',
    menu: [
      { path: '/iso/dashboard', label: 'Dashboard' },
      { path: '/iso/pipeline', label: 'Pipeline' },
      { path: '/iso/deals', label: 'Deals' },
      { path: '/iso/commissions', label: 'Commissions' },
    ],
  },
  funder: {
    defaultRoute: '/funder/portal',
    menu: [
      { path: '/funder/portal', label: 'Portal' },
      { path: '/funder/deals', label: 'Deals' },
    ],
  },
  investor: {
    defaultRoute: '/investor',
    menu: [
      { path: '/investor', label: 'Portfolio' },
      { path: '/funder/portal', label: 'Funder Portal' },
    ],
  },
  gov_donor: {
    defaultRoute: '/donors',
    menu: [
      { path: '/donors', label: 'Impact Projects' },
      { path: '/tlc/dashboard', label: 'TLC Dashboard' },
    ],
  },
  legal: {
    defaultRoute: '/legal/dashboard',
    menu: [
      { path: '/legal/dashboard', label: 'Dashboard' },
      { path: '/legal/cases', label: 'Cases' },
      { path: '/legal/settings', label: 'Settings' },
    ],
  },
  credit_repair_specialist: {
    defaultRoute: '/credit-specialist-dashboard',
    menu: [
      { path: '/credit-specialist-dashboard', label: 'Dashboard' },
      { path: '/credit-fix/studio', label: 'Studio' },
    ],
  },
  public: {
    defaultRoute: '/',
    menu: [
      { path: '/', label: 'Home' },
      { path: '/apply', label: 'Apply' },
      { path: '/contact', label: 'Contact' },
    ],
  },
};

export function getDashboardConfig(role: WolfRole): RoleDashboardConfig {
  return MOTHERBOARD_CONFIG[role] || MOTHERBOARD_CONFIG.public;
}

export function getDefaultRoute(role: WolfRole): string {
  return getDashboardConfig(role).defaultRoute;
}
