export interface AISuggestion {
  label: string;
  prompt: string;
}

export interface SuggestionsConfig {
  [role: string]: {
    [route: string]: AISuggestion[];
  };
}

export const AI_SUGGESTIONS: SuggestionsConfig = {
  public: {
    "/": [
      {
        label: "What does Wolf Fund do?",
        prompt: "Explain Wolf Fund services in simple terms and how I can get funding or credit help."
      },
      {
        label: "How do I apply?",
        prompt: "Explain how to start a Fast Track application on the site."
      },
      {
        label: "Tell me about credit optimization",
        prompt: "Explain Wolf Fund's credit optimization in high-level, client-safe language without revealing internal methods."
      }
    ],
    "/services": [
      {
        label: "Compare funding options",
        prompt: "Explain the differences between Fast Track, MCA, and traditional loans."
      },
      {
        label: "Credit repair overview",
        prompt: "Give me a high-level overview of Wolf Fund's credit optimization services without internal methods."
      }
    ]
  },

  user: {
    "/client-dashboard": [
      {
        label: "What's the status of my applications?",
        prompt: "Explain my current applications and their statuses in simple terms, without showing any internal methods."
      },
      {
        label: "What happens next in my process?",
        prompt: "Explain the next steps for my funding and/or credit repair process based on my current status."
      },
      {
        label: "Do you need more documents from me?",
        prompt: "Tell me if there are common documents clients are usually asked for at this stage, without referencing internal strategy."
      },
      {
        label: "How long can my credit case take?",
        prompt: "Explain typical timelines for credit improvement in general terms (30–90 days), based on bureau cycles."
      }
    ],
    "/": [
      {
        label: "Apply for funding",
        prompt: "Help me understand which funding application is right for my business."
      },
      {
        label: "Check my eligibility",
        prompt: "What do I need to qualify for Fast Track funding?"
      }
    ]
  },

  worker: {
    "/worker-dashboard": [
      {
        label: "Show today's follow-ups",
        prompt: "Explain how I can see which of my clients need a 20-day follow-up today on this dashboard."
      },
      {
        label: "Remind me of Fast Track requirements",
        prompt: "Explain the key requirements I should verify before submitting a Fast Track application for a client."
      },
      {
        label: "What should I do with declined deals?",
        prompt: "Explain, without internal tactics, what I should do when a deal is declined due to credit and how the credit improvement phase works."
      },
      {
        label: "Draft a message to a client",
        prompt: "Write a short, professional message I can send to a client to ask for updated bank statements. Do not include internal tactics."
      }
    ],
    "/": [
      {
        label: "Submit new client",
        prompt: "Guide me through submitting a new Fast Track application for a client."
      },
      {
        label: "Track commission",
        prompt: "How do I view my commission status and deal tracking?"
      }
    ]
  },

  admin: {
    "/admin": [
      {
        label: "Show me NEW applications",
        prompt: "List how I can identify new/unviewed applications and what the NEW badges mean on the Admin dashboard."
      },
      {
        label: "What are today's follow-ups?",
        prompt: "Explain how to see all follow-ups that are due today using the Follow-Ups tab or filters."
      },
      {
        label: "Summarize this client's history",
        prompt: "Explain how to open a client's full history (applications, status changes, credit track, and notes) in the Admin dashboard."
      }
    ],
    "/admin-reports": [
      {
        label: "Funding overview this month",
        prompt: "Explain how to read the core funding metrics in the Reports tab for the current month."
      },
      {
        label: "Application volume by type",
        prompt: "Explain how to interpret the application volume by type (Fast Track, Loan, Credit Repair, ISO) for the last 30 days."
      },
      {
        label: "Credit repair performance",
        prompt: "Explain how to interpret active vs completed credit repair cases in the Reports tab, without revealing internal dispute methods."
      }
    ],
    "/": [
      {
        label: "Platform overview",
        prompt: "Give me a quick overview of pending items across all dashboards."
      },
      {
        label: "User management",
        prompt: "How do I approve workers and manage user roles?"
      }
    ]
  },

  credit_repair_specialist: {
    "/credit-specialist-dashboard": [
      {
        label: "My cases due today",
        prompt: "Explain how I can see which of my assigned credit repair cases have tasks or actions due today."
      },
      {
        label: "Which cases are overdue?",
        prompt: "Explain how to identify overdue cases based on next_action_date or status."
      },
      {
        label: "Summarize a credit case",
        prompt: "Explain what information I should look at when reviewing a credit repair case, without revealing internal methods."
      },
      {
        label: "How to log activity correctly",
        prompt: "Explain how I should log notes, activity, and documents in a credit repair case in a compliant way."
      }
    ],
    "/": [
      {
        label: "My assigned cases",
        prompt: "Show me how to access my credit repair specialist dashboard."
      },
      {
        label: "Case management tips",
        prompt: "Give me best practices for managing credit repair cases."
      }
    ]
  }
} as const;

/**
 * Get AI suggestions for a specific role and route
 * Falls back to generic suggestions if no specific match found
 */
export const getSuggestions = (
  role: string | null,
  route: string
): AISuggestion[] => {
  const effectiveRole = role || 'public';
  
  // Try exact route match first
  const roleSuggestions = AI_SUGGESTIONS[effectiveRole];
  if (roleSuggestions && roleSuggestions[route]) {
    return roleSuggestions[route];
  }
  
  // Fall back to home route for this role
  if (roleSuggestions && roleSuggestions["/"]) {
    return roleSuggestions["/"];
  }
  
  // Ultimate fallback to public home
  return AI_SUGGESTIONS.public["/"] || [
    {
      label: "What can you help me with?",
      prompt: "Tell me what you can help me with on this page."
    }
  ];
};