// src/config/roleRoutes.ts
// V27: Centralized role-to-routes mapping for Wolf-Fund OS

import type { ReactNode } from 'react';

/**
 * All supported roles in Wolf-Fund OS
 */
export type WolfRole =
  | 'owner'
  | 'ceo'
  | 'cfo'
  | 'clo'
  | 'admin'
  | 'win_director'
  | 'worker'
  | 'partner_factory'
  | 'iso'
  | 'funder'
  | 'investor'
  | 'gov_donor'
  | 'legal'
  | 'credit_repair_specialist'
  | 'public';

/**
 * Layout types available in the system
 */
export type WolfLayout =
  | 'owner'
  | 'admin'
  | 'worker'
  | 'iso'
  | 'funder'
  | 'legal'
  | 'ops'
  | 'public'
  | 'protected';

/**
 * Route configuration interface
 */
export interface WolfRoute {
  path: string;
  element: ReactNode;
  layout?: WolfLayout;
  requiresAuth?: boolean;
  roles?: WolfRole[];
  label?: string;
}

/**
 * Default dashboard routes per role
 */
export const DEFAULT_DASHBOARDS: Record<WolfRole, string> = {
  owner: '/owner/motherboard',
  ceo: '/ceo',
  cfo: '/cfo',
  clo: '/clo',
  admin: '/admin/dashboard',
  win_director: '/win-director',
  worker: '/worker/dashboard',
  partner_factory: '/partner/factory',
  iso: '/iso/dashboard',
  funder: '/funder/portal',
  investor: '/investor',
  gov_donor: '/donors',
  legal: '/legal/dashboard',
  credit_repair_specialist: '/credit-specialist-dashboard',
  public: '/',
};

/**
 * Role hierarchy for permission checks (higher = more access)
 */
export const ROLE_HIERARCHY: Record<WolfRole, number> = {
  owner: 100,
  ceo: 95,
  cfo: 92,
  clo: 90,
  admin: 80,
  win_director: 68,
  legal: 70,
  credit_repair_specialist: 60,
  partner_factory: 55,
  worker: 50,
  iso: 40,
  funder: 35,
  investor: 32,
  gov_donor: 30,
  public: 0,
};

/**
 * Check if a role has sufficient permissions
 */
export function hasRoleOrHigher(userRole: WolfRole, requiredRole: WolfRole): boolean {
  return ROLE_HIERARCHY[userRole] >= ROLE_HIERARCHY[requiredRole];
}

/**
 * Get the default dashboard for a given role
 */
export function getDefaultDashboard(role: WolfRole): string {
  return DEFAULT_DASHBOARDS[role] || '/';
}
