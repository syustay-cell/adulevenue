// V27: App with cleaned up routing - TLC handled exclusively by lazy TLCRoutes

import { Toaster } from "@/components/ui/toaster";
import { WolfHubProvider } from "@/components/wolf-hub";
import { WolfSessionProvider } from "@/contexts/WolfSessionContext";
import { BrandProvider } from "@/contexts/BrandContext";
import { PuzzlePanelProvider } from "@/components/puzzle-panel";
import { AutoTtsProvider } from "@/context/AutoTtsProvider";
import GlobalChatBot from "@/components/GlobalChatBot";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, useLocation } from "react-router-dom";
import { HelpButton } from "@/components/help/HelpButton";
import { SessionTimeoutProvider } from "@/components/SessionTimeoutProvider";
import { lazy, Suspense } from "react";
import { AppErrorBoundary, RuntimeDebugTools } from "@/components/debug/RuntimeDebugTools";

// Lazy load brand routes for code splitting
const ABGRoutes = lazy(() => import("@/brands/abg/routes"));
const TLCRoutes = lazy(() => import("@/brands/tlc/routes"));

// Import route modules
import {
  ownerRoutes,
  adminRoutes,
  cSuiteRoutes,
  workerRoutes,
  creditFixRoutes,
  isoRoutes,
  clientRoutes,
  funderRoutes,
  leadEngineRoutes,
  outreachRoutes,
  publicRoutes,
  partnerRoutes,
  legalRoutes,
  merchantServicesRoutes,
  tenantRoutes,
  superRoutes,
} from "@/routes";

const queryClient = new QueryClient();

// Loading fallback for lazy-loaded routes
const BrandLoadingFallback = () => (
  <div className="w-full h-full flex items-center justify-center text-sm text-slate-400">
    Loading...
  </div>
);

// Suppress WolfHub and HelpButton on ABG and TLC portal routes
const ConditionalWolfWidgets = () => {
  const location = useLocation();
  const isABGRoute = location.pathname.startsWith("/abg");
  const isTLCRoute = location.pathname.startsWith("/tlc");
  if (isABGRoute || isTLCRoute) return null;
  return (
    <>
      <WolfHubProvider />
      <HelpButton />
    </>
  );
};

const ConditionalChatBot = () => {
  const location = useLocation();

  // ABG and TLC portals have their own branded shells — exclude Wolf Fund widgets
  const isABGRoute = location.pathname.startsWith("/abg");
  const isTLCRoute = location.pathname.startsWith("/tlc");

  const isInternalRoute = [
    "/admin",
    "/owner",
    "/worker",
    "/credit-fix",
    "/credit-specialist",
    "/lead-engine",
    "/lead-gen",
    "/outreach",
    "/funder",
    "/iso",
    "/underwriting",
    "/tenant",
    "/wolf-id",
    "/tasks",
    "/my-day",
    "/my-pipeline",
    "/follow-ups",
    "/dialer",
  ].some((route) => location.pathname.startsWith(route));

  // Never render Wolf Fund widgets inside ABG or TLC portals
  if (isABGRoute || isTLCRoute) return null;

  return <>{isInternalRoute && <GlobalChatBot />}</>;
};

const App = () => {
  return (
    <QueryClientProvider client={queryClient}>
      <WolfSessionProvider>
        <BrandProvider>
          <PuzzlePanelProvider>
            <AutoTtsProvider>
              <AppErrorBoundary>
                <BrowserRouter>
                  <TooltipProvider>
                    <SessionTimeoutProvider>
                      <RuntimeDebugTools />

                    <Routes>
                      {/* ABG Brand Routes - fully isolated, no Wolf Fund widgets */}
                      <Route
                        path="/abg/*"
                        element={
                          <Suspense fallback={<BrandLoadingFallback />}>
                            <ABGRoutes />
                          </Suspense>
                        }
                      />

                      {/* TLC Brand Routes - SOURCE OF TRUTH for /tlc/* */}
                      <Route
                        path="/tlc/*"
                        element={
                          <Suspense fallback={<BrandLoadingFallback />}>
                            <TLCRoutes />
                          </Suspense>
                        }
                      />

                      {/* Wolf Fund Core Routes */}
                      {ownerRoutes}
                      {cSuiteRoutes}
                      {partnerRoutes}
                      {legalRoutes}
                      {merchantServicesRoutes}
                      {adminRoutes}
                      {workerRoutes}
                      {creditFixRoutes}
                      {isoRoutes}
                      {clientRoutes}
                      {funderRoutes}
                      {leadEngineRoutes}
                      {outreachRoutes}
                      {tenantRoutes}
                      {superRoutes}

                      {/* Public routes - MUST be last (contains catch-all) */}
                      {publicRoutes}
                    </Routes>

                    <ConditionalChatBot />
                    <ConditionalWolfWidgets />
                    <Toaster />
                    <Sonner />
                    </SessionTimeoutProvider>
                  </TooltipProvider>
                </BrowserRouter>
              </AppErrorBoundary>
            </AutoTtsProvider>
          </PuzzlePanelProvider>
        </BrandProvider>
      </WolfSessionProvider>
    </QueryClientProvider>
  );
};

export default App;
