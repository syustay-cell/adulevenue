import { supabase } from "@/integrations/supabase/client";

export interface IPAsset {
  id: string;
  tenant_id: string;
  asset_type: string;
  name: string;
  description?: string;
  source_path?: string;
  hash_signature?: string;
  tags: string[];
  legal_priority: string;
  brand_key?: string;
  metadata: Record<string, unknown>;
  created_at: string;
  updated_at: string;
}

export interface IPVersion {
  id: string;
  asset_id: string;
  version_tag: string;
  change_type: string;
  snapshot_hash?: string;
  diff_summary?: string;
  created_at: string;
}

export interface IPEvent {
  id: string;
  tenant_id: string;
  asset_id?: string;
  event_type: string;
  source: string;
  description?: string;
  payload: Record<string, unknown>;
  created_at: string;
}

export interface IPLegalDraft {
  id: string;
  tenant_id: string;
  asset_id?: string;
  doc_type: string;
  title: string;
  body: string;
  status: string;
  ai_model?: string;
  metadata: Record<string, unknown>;
  reviewed_by?: string;
  reviewed_at?: string;
  created_at: string;
}

export interface RegisterAssetParams {
  tenant_id: string;
  asset_type: "code" | "ui" | "workflow" | "prompt" | "brand" | "document" | "model" | "config";
  name: string;
  description?: string;
  source_path?: string;
  content?: string;
  tags?: string[];
  legal_priority?: "low" | "medium" | "high" | "critical";
  brand_key?: string;
  version_tag?: string;
  change_type?: "create" | "update" | "refactor" | "branch" | "deprecate";
  metadata?: Record<string, unknown>;
}

export interface GenerateLegalParams {
  tenant_id: string;
  asset_ids?: string[];
  tags?: string[];
  doc_types?: Array<"copyright_summary" | "trademark_summary" | "patent_description" | "ownership_statement" | "cease_desist_draft" | "evidence_pack">;
}

/**
 * Register or update an IP asset
 */
export async function registerIPAsset(params: RegisterAssetParams) {
  const { data, error } = await supabase.functions.invoke("wf-ip-auto-register", {
    body: params,
  });

  if (error) throw error;
  return data;
}

/**
 * Generate legal documentation for IP assets
 */
export async function generateLegalDrafts(params: GenerateLegalParams) {
  const { data, error } = await supabase.functions.invoke("wf-ip-legal-generate", {
    body: params,
  });

  if (error) throw error;
  return data;
}

/**
 * Fetch IP assets for a tenant
 */
export async function fetchIPAssets(tenantId: string, filters?: {
  asset_type?: string;
  brand_key?: string;
  tags?: string[];
}) {
  let query = supabase
    .from("wf_ip_assets")
    .select("*")
    .eq("tenant_id", tenantId)
    .order("created_at", { ascending: false });

  if (filters?.asset_type) {
    query = query.eq("asset_type", filters.asset_type);
  }
  if (filters?.brand_key) {
    query = query.eq("brand_key", filters.brand_key);
  }
  if (filters?.tags && filters.tags.length > 0) {
    query = query.overlaps("tags", filters.tags);
  }

  const { data, error } = await query;
  if (error) throw error;
  return data as IPAsset[];
}

/**
 * Fetch version history for an asset
 */
export async function fetchAssetVersions(assetId: string) {
  const { data, error } = await supabase
    .from("wf_ip_versions")
    .select("*")
    .eq("asset_id", assetId)
    .order("created_at", { ascending: false });

  if (error) throw error;
  return data as IPVersion[];
}

/**
 * Fetch IP events for a tenant
 */
export async function fetchIPEvents(tenantId: string, limit = 50) {
  const { data, error } = await supabase
    .from("wf_ip_events")
    .select("*")
    .eq("tenant_id", tenantId)
    .order("created_at", { ascending: false })
    .limit(limit);

  if (error) throw error;
  return data as IPEvent[];
}

/**
 * Fetch legal drafts for a tenant
 */
export async function fetchLegalDrafts(tenantId: string, filters?: {
  status?: string;
  doc_type?: string;
  asset_id?: string;
}) {
  let query = supabase
    .from("wf_ip_legal_drafts")
    .select("*")
    .eq("tenant_id", tenantId)
    .order("created_at", { ascending: false });

  if (filters?.status) {
    query = query.eq("status", filters.status);
  }
  if (filters?.doc_type) {
    query = query.eq("doc_type", filters.doc_type);
  }
  if (filters?.asset_id) {
    query = query.eq("asset_id", filters.asset_id);
  }

  const { data, error } = await query;
  if (error) throw error;
  return data as IPLegalDraft[];
}

/**
 * Update draft status
 */
export async function updateDraftStatus(draftId: string, status: string, reviewedBy?: string) {
  const updateData: Record<string, unknown> = { status };
  if (reviewedBy) {
    updateData.reviewed_by = reviewedBy;
    updateData.reviewed_at = new Date().toISOString();
  }

  const { error } = await supabase
    .from("wf_ip_legal_drafts")
    .update(updateData)
    .eq("id", draftId);

  if (error) throw error;
}
