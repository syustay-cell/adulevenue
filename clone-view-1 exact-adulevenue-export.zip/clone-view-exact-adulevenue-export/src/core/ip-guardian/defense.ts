// V18 - IP Defense War Room + Evidence Locker API
import { supabase } from "@/integrations/supabase/client";

export type DefenseStatus = "draft" | "prepped" | "attorney_reviewed" | "filed_externally";

export interface BrandDefenseReadiness {
  brand_key: string;
  score: number;
  status: "defense_ready" | "prepped_gaps" | "high_risk";
  high_or_critical_assets_total: number;
  with_legal_drafts: number;
  with_filing_packets: number;
  attorney_reviewed_assets: number;
  externally_filed_assets: number;
  high_critical_no_packet: number;
  ai_generated_no_draft: number;
}

export interface EvidenceLockerData {
  asset: any;
  versions: any[];
  events: any[];
  drafts: any[];
  packets: any[];
  bundles: any[];
}

export interface AttorneyFlags {
  attorney_reviewed?: boolean;
  attorney_name?: string;
  externally_filed?: boolean;
  external_filing_ref?: string;
}

/**
 * Fetch defense readiness metrics per brand
 */
export async function fetchDefenseReadiness(tenantId: string): Promise<BrandDefenseReadiness[]> {
  // Fetch all high/critical assets
  const { data: assets } = await supabase
    .from("wf_ip_assets")
    .select("id, brand_key, legal_priority, defense_status, tags")
    .eq("tenant_id", tenantId);

  // Fetch legal drafts
  const { data: drafts } = await supabase
    .from("wf_ip_legal_drafts")
    .select("asset_id, status")
    .eq("tenant_id", tenantId);

  // Fetch filing packets
  const { data: packets } = await supabase
    .from("wf_ip_filing_packets")
    .select("asset_id, status, attorney_reviewed, externally_filed")
    .eq("tenant_id", tenantId);

  if (!assets) return [];

  // Group by brand
  const brandMap = new Map<string, {
    total: number;
    highCritical: number;
    withDrafts: Set<string>;
    withPackets: Set<string>;
    attorneyReviewed: Set<string>;
    externallyFiled: Set<string>;
    aiGenerated: Set<string>;
  }>();

  assets.forEach((asset) => {
    const brand = asset.brand_key || "wolf-fund";
    if (!brandMap.has(brand)) {
      brandMap.set(brand, {
        total: 0,
        highCritical: 0,
        withDrafts: new Set(),
        withPackets: new Set(),
        attorneyReviewed: new Set(),
        externallyFiled: new Set(),
        aiGenerated: new Set(),
      });
    }
    const stats = brandMap.get(brand)!;
    stats.total++;

    if (asset.legal_priority === "high" || asset.legal_priority === "critical") {
      stats.highCritical++;
    }

    // Check if AI-generated
    const tags = Array.isArray(asset.tags) ? asset.tags : [];
    if (tags.includes("ai-generated") || tags.includes("auto-registered")) {
      stats.aiGenerated.add(asset.id);
    }
  });

  // Process drafts
  drafts?.forEach((draft) => {
    assets.forEach((asset) => {
      if (draft.asset_id === asset.id) {
        const brand = asset.brand_key || "wolf-fund";
        const stats = brandMap.get(brand);
        if (stats) {
          stats.withDrafts.add(asset.id);
        }
      }
    });
  });

  // Process packets
  packets?.forEach((packet) => {
    assets.forEach((asset) => {
      if (packet.asset_id === asset.id) {
        const brand = asset.brand_key || "wolf-fund";
        const stats = brandMap.get(brand);
        if (stats) {
          stats.withPackets.add(asset.id);
          if (packet.attorney_reviewed) {
            stats.attorneyReviewed.add(asset.id);
          }
          if (packet.externally_filed) {
            stats.externallyFiled.add(asset.id);
          }
        }
      }
    });
  });

  // Calculate readiness for each brand
  const results: BrandDefenseReadiness[] = [];

  brandMap.forEach((stats, brand) => {
    const highCriticalNoPacket = assets.filter(
      (a) =>
        (a.brand_key || "wolf-fund") === brand &&
        (a.legal_priority === "high" || a.legal_priority === "critical") &&
        !stats.withPackets.has(a.id)
    ).length;

    const aiGeneratedNoDraft = [...stats.aiGenerated].filter(
      (id) => !stats.withDrafts.has(id)
    ).length;

    // Calculate score (simple formula)
    let score = 100;
    if (stats.highCritical > 0) {
      const packetCoverage = stats.withPackets.size / stats.highCritical;
      const reviewCoverage = stats.attorneyReviewed.size / stats.highCritical;
      score = Math.round((packetCoverage * 50) + (reviewCoverage * 50));
    }
    score = Math.max(0, score - (highCriticalNoPacket * 10) - (aiGeneratedNoDraft * 5));

    let status: BrandDefenseReadiness["status"] = "defense_ready";
    if (score < 50) status = "high_risk";
    else if (score < 80) status = "prepped_gaps";

    results.push({
      brand_key: brand,
      score,
      status,
      high_or_critical_assets_total: stats.highCritical,
      with_legal_drafts: stats.withDrafts.size,
      with_filing_packets: stats.withPackets.size,
      attorney_reviewed_assets: stats.attorneyReviewed.size,
      externally_filed_assets: stats.externallyFiled.size,
      high_critical_no_packet: highCriticalNoPacket,
      ai_generated_no_draft: aiGeneratedNoDraft,
    });
  });

  return results;
}

/**
 * Fetch evidence locker data for a specific asset
 */
export async function fetchEvidenceLocker(assetId: string): Promise<EvidenceLockerData> {
  const [assetRes, versionsRes, eventsRes, draftsRes, packetsRes, bundlesRes] = await Promise.all([
    supabase.from("wf_ip_assets").select("*").eq("id", assetId).single(),
    supabase.from("wf_ip_versions").select("*").eq("asset_id", assetId).order("created_at", { ascending: true }),
    supabase.from("wf_ip_events").select("*").eq("asset_id", assetId).order("created_at", { ascending: true }),
    supabase.from("wf_ip_legal_drafts").select("*").eq("asset_id", assetId).order("created_at", { ascending: false }),
    supabase.from("wf_ip_filing_packets").select("*").eq("asset_id", assetId).order("created_at", { ascending: false }),
    supabase.from("wf_ip_evidence_bundles").select("*").eq("asset_id", assetId).order("generated_at", { ascending: false }),
  ]);

  return {
    asset: assetRes.data,
    versions: versionsRes.data || [],
    events: eventsRes.data || [],
    drafts: draftsRes.data || [],
    packets: packetsRes.data || [],
    bundles: bundlesRes.data || [],
  };
}

/**
 * Generate an evidence bundle for an asset
 */
export async function generateEvidenceBundle(params: {
  tenant_id: string;
  asset_id: string;
  bundle_type?: string;
  notes_for_attorney?: string;
  generated_by?: string;
}): Promise<{ bundle_html: string; bundle_id?: string; generated_at: string }> {
  const { data, error } = await supabase.functions.invoke("wf-ip-evidence-bundle-generate", {
    body: params,
  });

  if (error) throw error;
  return data;
}

/**
 * Update defense status on an asset
 */
export async function updateAssetDefenseStatus(
  assetId: string,
  status: DefenseStatus,
  notes?: string
): Promise<void> {
  const updateData: any = {
    defense_status: status,
    updated_at: new Date().toISOString(),
  };
  if (notes !== undefined) {
    updateData.defense_notes = notes;
  }

  const { error } = await supabase
    .from("wf_ip_assets")
    .update(updateData)
    .eq("id", assetId);

  if (error) throw error;
}

/**
 * Update attorney flags on a filing packet
 */
export async function updatePacketAttorneyFlags(
  packetId: string,
  flags: AttorneyFlags
): Promise<void> {
  const { error } = await supabase
    .from("wf_ip_filing_packets")
    .update({
      ...flags,
      updated_at: new Date().toISOString(),
    })
    .eq("id", packetId);

  if (error) throw error;
}

/**
 * Fetch all evidence bundles for a tenant
 */
export async function fetchEvidenceBundles(tenantId: string, assetId?: string) {
  let query = supabase
    .from("wf_ip_evidence_bundles")
    .select("*")
    .eq("tenant_id", tenantId)
    .order("generated_at", { ascending: false });

  if (assetId) {
    query = query.eq("asset_id", assetId);
  }

  const { data, error } = await query;
  if (error) throw error;
  return data || [];
}
