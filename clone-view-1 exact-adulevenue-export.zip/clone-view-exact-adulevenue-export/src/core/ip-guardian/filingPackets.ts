// V16 - Filing Packets API
import { supabase } from "@/integrations/supabase/client";

export interface IPFilingPacket {
  id: string;
  tenant_id: string;
  asset_id?: string;
  packet_type: "copyright" | "trademark" | "patent_brief";
  status: "draft" | "ready_for_review" | "shared_with_attorney" | "archived";
  title: string;
  body: string;
  checklist: ChecklistItem[];
  filing_region: string;
  filing_notes?: string;
  metadata: Record<string, unknown>;
  created_by?: string;
  created_at: string;
  updated_at: string;
}

export interface ChecklistItem {
  id: string;
  label: string;
  status: "pending" | "completed";
}

export interface GenerateFilingPacketParams {
  tenant_id: string;
  asset_ids: string[];
  packet_type: "copyright" | "trademark" | "patent_brief";
  filing_region?: string;
  notes_for_ai?: string;
}

/**
 * Generate a filing prep packet for IP assets
 */
export async function generateFilingPacket(params: GenerateFilingPacketParams) {
  const { data, error } = await supabase.functions.invoke("wf-ip-filing-generate", {
    body: params,
  });

  if (error) throw error;
  return data;
}

/**
 * Fetch filing packets for a tenant
 */
export async function fetchFilingPackets(tenantId: string, filters?: {
  status?: string;
  packet_type?: string;
  asset_id?: string;
}) {
  let query = supabase
    .from("wf_ip_filing_packets")
    .select("*")
    .eq("tenant_id", tenantId)
    .order("created_at", { ascending: false });

  if (filters?.status) {
    query = query.eq("status", filters.status);
  }
  if (filters?.packet_type) {
    query = query.eq("packet_type", filters.packet_type);
  }
  if (filters?.asset_id) {
    query = query.eq("asset_id", filters.asset_id);
  }

  const { data, error } = await query;
  if (error) throw error;
  return (data || []).map(d => ({
    ...d,
    checklist: (d.checklist || []) as unknown as ChecklistItem[],
    metadata: (d.metadata || {}) as Record<string, unknown>,
  })) as IPFilingPacket[];
}

/**
 * Update filing packet status
 */
export async function updateFilingPacketStatus(
  packetId: string, 
  status: IPFilingPacket["status"]
) {
  const { error } = await supabase
    .from("wf_ip_filing_packets")
    .update({ status, updated_at: new Date().toISOString() })
    .eq("id", packetId);

  if (error) throw error;
}

/**
 * Update filing packet checklist
 */
export async function updateFilingPacketChecklist(
  packetId: string,
  checklist: ChecklistItem[]
) {
  const { error } = await supabase
    .from("wf_ip_filing_packets")
    .update({ 
      checklist: JSON.parse(JSON.stringify(checklist)), 
      updated_at: new Date().toISOString() 
    })
    .eq("id", packetId);

  if (error) throw error;
}

/**
 * Update filing packet notes
 */
export async function updateFilingPacketNotes(
  packetId: string,
  filing_notes: string
) {
  const { error } = await supabase
    .from("wf_ip_filing_packets")
    .update({ filing_notes, updated_at: new Date().toISOString() })
    .eq("id", packetId);

  if (error) throw error;
}
