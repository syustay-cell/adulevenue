// V14.1 - Usage Logging Helper (expanded event types)
import { supabase } from "@/integrations/supabase/client";

export type UsageEventType =
  // Core Wolf Fund events
  | "case_created"
  | "case_closed"
  | "dispute_generated"
  | "dispute_sent"
  | "lead_created"
  | "email_sent"
  | "portal_link_sent"
  | "ai_call"
  | "ai_research"
  | "asset_deployed"
  | "ip_registered"
  // ABG brand events
  | "abg_application_created"
  | "abg_application_submitted"
  | "abg_funding_decision"
  // Generic cross-brand events
  | "sms_sent"
  | "document_uploaded";

export interface LogUsageParams {
  tenant_slug?: string;
  tenant_id?: string;
  event_type: UsageEventType;
  case_id?: string;
  lead_id?: string;
  iso_id?: string;
  brand_key?: string;
  meta?: Record<string, unknown>;
  idempotency_key?: string;
}

/**
 * Log a usage event to wf_usage_events via the billing edge function.
 * Non-blocking: errors are logged but don't throw.
 */
export async function logUsage(params: LogUsageParams): Promise<void> {
  try {
    const body = {
      tenant_slug: params.tenant_slug ?? "wolf-fund",
      tenant_id: params.tenant_id ?? null,
      event_type: params.event_type,
      case_id: params.case_id ?? null,
      lead_id: params.lead_id ?? null,
      iso_id: params.iso_id ?? null,
      brand_key: params.brand_key ?? "wolf-fund",
      meta: params.meta ?? {},
      idempotency_key: params.idempotency_key ?? null,
    };

    const { error } = await supabase.functions.invoke("wf-billing-log-usage", { body });

    if (error) {
      console.error("[logUsage] Failed to log usage event:", error);
    }
  } catch (err) {
    console.error("[logUsage] Error logging usage:", err);
  }
}

/**
 * Get usage summary for a tenant
 */
export async function getUsageSummary(params: {
  tenant_slug?: string;
  period?: string;
  days?: number;
}) {
  const { data, error } = await supabase.functions.invoke("wf-billing-usage-summary", {
    body: params,
  });

  if (error) throw error;
  return data;
}

/**
 * Get invoice preview for a tenant
 */
export async function getInvoicePreview(params: {
  tenant_slug?: string;
  billing_period?: string;
}) {
  const { data, error } = await supabase.functions.invoke("wf-billing-invoice-preview", {
    body: params,
  });

  if (error) throw error;
  return data;
}
