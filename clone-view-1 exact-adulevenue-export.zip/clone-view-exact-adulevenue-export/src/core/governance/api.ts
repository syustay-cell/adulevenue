import { supabase } from "@/integrations/supabase/client";

// Types
export type AlertStatus = "open" | "acknowledged" | "resolved";

export interface GovernanceReport {
  id: string;
  tenant_id: string;
  run_id: string | null;
  run_type: string;
  summary: Record<string, any>;
  checks: Array<Record<string, any>>;
  signals: Record<string, any>;
  created_at: string;
}

export interface GovernanceAction {
  id: string;
  tenant_id: string;
  action_type: string;
  source_check_id: string | null;
  source_suggestion_id: string | null;
  brand_key: string | null;
  related_asset_id: string | null;
  related_event_type: string | null;
  previous_state: Record<string, any> | null;
  new_state: Record<string, any> | null;
  performed_by: string | null;
  performed_at: string;
  notes: string | null;
  metadata: Record<string, any>;
}

export interface GovernanceAlert {
  id: string;
  tenant_id: string;
  alert_type: string;
  brand_key: string | null;
  metric_key: string | null;
  current_value: number | null;
  threshold_value: number | null;
  status: AlertStatus;
  acknowledged_by: string | null;
  acknowledged_at: string | null;
  resolved_by: string | null;
  resolved_at: string | null;
  last_triggered_at: string;
  metadata: Record<string, any>;
}

// Fetch governance reports
export async function fetchGovernanceReports(
  tenantId: string,
  limit = 20
): Promise<GovernanceReport[]> {
  const { data, error } = await supabase
    .from("wf_governance_reports")
    .select("*")
    .eq("tenant_id", tenantId)
    .order("created_at", { ascending: false })
    .limit(limit);

  if (error) throw error;
  return (data || []) as GovernanceReport[];
}

// Fetch governance actions
export async function fetchGovernanceActions(
  tenantId: string,
  limit = 50
): Promise<GovernanceAction[]> {
  const { data, error } = await supabase
    .from("wf_governance_actions")
    .select("*")
    .eq("tenant_id", tenantId)
    .order("performed_at", { ascending: false })
    .limit(limit);

  if (error) throw error;
  return (data || []) as GovernanceAction[];
}

// Fetch governance alerts
export async function fetchGovernanceAlerts(
  tenantId: string,
  status?: AlertStatus | "all"
): Promise<GovernanceAlert[]> {
  let query = supabase
    .from("wf_governance_alerts")
    .select("*")
    .eq("tenant_id", tenantId)
    .order("last_triggered_at", { ascending: false });

  if (status && status !== "all") {
    query = query.eq("status", status);
  }

  const { data, error } = await query;
  if (error) throw error;
  return (data || []) as GovernanceAlert[];
}

// Log governance action
export async function logGovernanceAction(params: {
  tenant_id: string;
  action_type: string;
  source_check_id?: string;
  source_suggestion_id?: string;
  brand_key?: string;
  related_asset_id?: string;
  previous_state?: Record<string, any>;
  new_state?: Record<string, any>;
  performed_by?: string;
  notes?: string;
  metadata?: Record<string, any>;
}): Promise<GovernanceAction> {
  const { data, error } = await supabase
    .from("wf_governance_actions")
    .insert({
      tenant_id: params.tenant_id,
      action_type: params.action_type,
      source_check_id: params.source_check_id || null,
      source_suggestion_id: params.source_suggestion_id || null,
      brand_key: params.brand_key || null,
      related_asset_id: params.related_asset_id || null,
      previous_state: params.previous_state || null,
      new_state: params.new_state || null,
      performed_by: params.performed_by || null,
      notes: params.notes || null,
      metadata: params.metadata || {},
    })
    .select()
    .single();

  if (error) throw error;
  return data as GovernanceAction;
}

// Update alert status
export async function updateAlertStatus(
  alertId: string,
  status: AlertStatus,
  userId?: string
): Promise<GovernanceAlert> {
  const updates: Record<string, any> = { status };

  if (status === "acknowledged") {
    updates.acknowledged_by = userId || null;
    updates.acknowledged_at = new Date().toISOString();
  } else if (status === "resolved") {
    updates.resolved_by = userId || null;
    updates.resolved_at = new Date().toISOString();
  }

  const { data, error } = await supabase
    .from("wf_governance_alerts")
    .update(updates)
    .eq("id", alertId)
    .select()
    .single();

  if (error) throw error;
  return data as GovernanceAlert;
}

// Run scheduled governance scan
export async function runScheduledGovernanceScan(
  tenantId?: string
): Promise<{
  success: boolean;
  scanned_tenants: number;
  results: Array<{ tenant_id: string; report_id: string; alerts_created: number }>;
}> {
  const { data, error } = await supabase.functions.invoke("wf-governance-scan-cron", {
    body: {
      tenant_id: tenantId,
      run_type: "manual",
    },
  });

  if (error) throw error;
  return data;
}

// Get alert counts for summary
export async function getAlertCounts(tenantId: string): Promise<{
  open: number;
  acknowledged: number;
  resolved: number;
  high_severity_open: number;
}> {
  const { data, error } = await supabase
    .from("wf_governance_alerts")
    .select("status, alert_type")
    .eq("tenant_id", tenantId);

  if (error) throw error;

  const alerts = data || [];
  const highSeverityTypes = ["ip_defense_low", "unpriced_events", "legal_backlog_high"];

  return {
    open: alerts.filter((a) => a.status === "open").length,
    acknowledged: alerts.filter((a) => a.status === "acknowledged").length,
    resolved: alerts.filter((a) => a.status === "resolved").length,
    high_severity_open: alerts.filter(
      (a) => a.status === "open" && highSeverityTypes.includes(a.alert_type)
    ).length,
  };
}

// V20: Dev Suggestion Event Types
export type DevSuggestionAction = "opened" | "applied" | "ignored";
export type DevSuggestionArea = "billing" | "ip" | "playbook" | "defense" | "ai_change";

export interface DevSuggestionEvent {
  id: string;
  tenant_id: string;
  suggestion_id: string;
  action: DevSuggestionAction;
  area: DevSuggestionArea;
  source_check_id: string | null;
  performed_by: string | null;
  performed_at: string;
  metadata: Record<string, any>;
}

// V20: Log dev suggestion event
export async function logDevSuggestionEvent(params: {
  tenant_id: string;
  suggestion_id: string;
  action: DevSuggestionAction;
  area: DevSuggestionArea;
  source_check_id?: string;
  performed_by?: string;
  metadata?: Record<string, any>;
}): Promise<DevSuggestionEvent> {
  const { data, error } = await supabase
    .from("wf_dev_suggestion_events")
    .insert({
      tenant_id: params.tenant_id,
      suggestion_id: params.suggestion_id,
      action: params.action,
      area: params.area,
      source_check_id: params.source_check_id || null,
      performed_by: params.performed_by || null,
      metadata: params.metadata || {},
    })
    .select()
    .single();

  if (error) throw error;
  return data as DevSuggestionEvent;
}

// V20: Fetch dev suggestion events
export async function fetchDevSuggestionEvents(
  tenantId: string,
  limit = 50
): Promise<DevSuggestionEvent[]> {
  const { data, error } = await supabase
    .from("wf_dev_suggestion_events")
    .select("*")
    .eq("tenant_id", tenantId)
    .order("performed_at", { ascending: false })
    .limit(limit);

  if (error) throw error;
  return (data || []) as DevSuggestionEvent[];
}

// Export governance report as HTML
export function generateGovernanceReportHTML(report: GovernanceReport): string {
  const summary = report.summary || {};
  const checks = report.checks || [];
  const signals = report.signals || {};

  const passCount = checks.filter((c) => c.status === "pass").length;
  const warnCount = checks.filter((c) => c.status === "warn").length;
  const failCount = checks.filter((c) => c.status === "fail").length;

  return `
<!DOCTYPE html>
<html>
<head>
  <title>Governance Report - ${new Date(report.created_at).toLocaleDateString()}</title>
  <style>
    body { font-family: system-ui, sans-serif; max-width: 900px; margin: 40px auto; padding: 20px; }
    .header { border-bottom: 2px solid #1a1a2e; padding-bottom: 20px; margin-bottom: 30px; }
    .header h1 { margin: 0 0 10px 0; color: #1a1a2e; }
    .disclaimer { background: #fff3cd; border: 1px solid #ffc107; padding: 12px; margin: 20px 0; border-radius: 4px; font-size: 14px; }
    .summary { display: grid; grid-template-columns: repeat(4, 1fr); gap: 16px; margin: 20px 0; }
    .summary-card { background: #f8f9fa; padding: 16px; border-radius: 8px; text-align: center; }
    .summary-card .value { font-size: 32px; font-weight: bold; }
    .summary-card .label { font-size: 12px; color: #666; text-transform: uppercase; }
    .pass { color: #28a745; }
    .warn { color: #ffc107; }
    .fail { color: #dc3545; }
    .section { margin: 30px 0; }
    .section h2 { border-bottom: 1px solid #ddd; padding-bottom: 10px; }
    table { width: 100%; border-collapse: collapse; }
    th, td { padding: 10px; text-align: left; border-bottom: 1px solid #eee; }
    th { background: #f8f9fa; font-weight: 600; }
    .badge { display: inline-block; padding: 2px 8px; border-radius: 4px; font-size: 12px; }
    .badge-pass { background: #d4edda; color: #155724; }
    .badge-warn { background: #fff3cd; color: #856404; }
    .badge-fail { background: #f8d7da; color: #721c24; }
    .footer { margin-top: 40px; padding-top: 20px; border-top: 1px solid #ddd; font-size: 12px; color: #666; }
    @media print { body { margin: 0; } .no-print { display: none; } }
  </style>
</head>
<body>
  <div class="header">
    <h1>Wolf Fund Governance Report</h1>
    <p>Generated: ${new Date(report.created_at).toLocaleString()}</p>
    <p>Run Type: ${report.run_type} | Run ID: ${report.run_id || "N/A"}</p>
  </div>

  <div class="disclaimer">
    <strong>INTERNAL DOCUMENT – NOT LEGAL ADVICE</strong><br>
    This report is for internal governance tracking only. All findings should be reviewed with appropriate counsel before any external action.
  </div>

  <div class="summary">
    <div class="summary-card">
      <div class="value">${checks.length}</div>
      <div class="label">Total Checks</div>
    </div>
    <div class="summary-card">
      <div class="value pass">${passCount}</div>
      <div class="label">Passing</div>
    </div>
    <div class="summary-card">
      <div class="value warn">${warnCount}</div>
      <div class="label">Warnings</div>
    </div>
    <div class="summary-card">
      <div class="value fail">${failCount}</div>
      <div class="label">Failures</div>
    </div>
  </div>

  <div class="section">
    <h2>Summary Status</h2>
    <table>
      <tr><th>Area</th><th>Status</th></tr>
      <tr><td>Billing</td><td>${summary.billing_status || "unknown"}</td></tr>
      <tr><td>IP Coverage</td><td>${summary.ip_status || "unknown"}</td></tr>
      <tr><td>AI Changes</td><td>${summary.ai_status || "unknown"}</td></tr>
      <tr><td>Defense</td><td>${summary.defense_status || "unknown"}</td></tr>
      <tr><td>Playbooks</td><td>${summary.playbook_status || "unknown"}</td></tr>
      <tr><td>Automation</td><td>${summary.automation_status || "unknown"}</td></tr>
    </table>
  </div>

  <div class="section">
    <h2>Governance Checks</h2>
    <table>
      <tr><th>Check</th><th>Area</th><th>Status</th><th>Message</th></tr>
      ${checks
        .map(
          (c) => `
        <tr>
          <td>${c.id || "—"}</td>
          <td>${c.area || "—"}</td>
          <td><span class="badge badge-${c.status}">${c.status}</span></td>
          <td>${c.message || "—"}</td>
        </tr>
      `
        )
        .join("")}
    </table>
  </div>

  <div class="footer">
    <p>Wolf Fund Governance Engine V19 | Report ID: ${report.id}</p>
    <p>This is internal documentation only. Review with your team before taking action.</p>
  </div>
</body>
</html>
  `.trim();
}
