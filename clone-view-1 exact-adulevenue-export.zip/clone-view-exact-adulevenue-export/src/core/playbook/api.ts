// V17 - Playbook Drift & SOP Awareness API
import { supabase } from "@/integrations/supabase/client";

export interface PlaybookDriftItem {
  id: string;
  tenant_id: string;
  brand_key: string;
  drift_type: "usage_event" | "ip_asset" | "ui_route" | "workflow";
  item_key: string;
  item_label?: string;
  detected_at: string;
  status: "detected" | "approved" | "ignored";
  resolved_at?: string;
  resolved_by?: string;
  notes?: string;
  metadata: Record<string, unknown>;
  created_at: string;
  updated_at: string;
}

export interface BrandPlaybook {
  label: string;
  required_usage_events: string[];
  expected_ip_assets: string[];
  expected_ui_routes: string[];
  expected_workflows?: string[];
  billing_rules?: Record<string, unknown>;
  sop_links?: Record<string, string>;
}

export interface PlaybookCompliance {
  brand_key: string;
  label: string;
  usage_events: { expected: number; found: number; missing: string[] };
  ip_assets: { expected: number; found: number; missing: string[] };
  ui_routes: { expected: number; found: number; missing: string[] };
  overall_compliance: number;
  sop_links: Record<string, string>;
}

/**
 * Fetch drift items for a tenant
 */
export async function fetchDriftItems(tenantId: string, filters?: {
  brand_key?: string;
  status?: string;
  drift_type?: string;
}) {
  let query = supabase
    .from("wf_playbook_drift_items")
    .select("*")
    .eq("tenant_id", tenantId)
    .order("detected_at", { ascending: false });

  if (filters?.brand_key) {
    query = query.eq("brand_key", filters.brand_key);
  }
  if (filters?.status) {
    query = query.eq("status", filters.status);
  }
  if (filters?.drift_type) {
    query = query.eq("drift_type", filters.drift_type);
  }

  const { data, error } = await query;
  if (error) throw error;
  return (data || []) as PlaybookDriftItem[];
}

/**
 * Resolve a drift item (approve or ignore)
 */
export async function resolveDriftItem(
  driftItemId: string,
  action: "approve" | "ignore",
  notes?: string
) {
  const { data, error } = await supabase.functions.invoke("wf-playbook-drift-resolve", {
    body: { drift_item_id: driftItemId, action, notes },
  });

  if (error) throw error;
  return data;
}

/**
 * Create a drift item manually (for testing or manual detection)
 */
export async function createDriftItem(params: {
  tenant_id: string;
  brand_key: string;
  drift_type: PlaybookDriftItem["drift_type"];
  item_key: string;
  item_label?: string;
  metadata?: Record<string, unknown>;
}) {
  const insertData = {
    tenant_id: params.tenant_id,
    brand_key: params.brand_key,
    drift_type: params.drift_type,
    item_key: params.item_key,
    item_label: params.item_label || null,
    metadata: params.metadata || {},
  };
  
  const { data, error } = await supabase
    .from("wf_playbook_drift_items")
    .insert(insertData as any)
    .select()
    .single();

  if (error) throw error;
  return data as PlaybookDriftItem;
}

/**
 * Fetch brand playbooks from config
 */
export async function fetchBrandPlaybooks(): Promise<Record<string, BrandPlaybook>> {
  const { data, error } = await supabase
    .from("wolf_master_config")
    .select("value")
    .eq("category", "brand")
    .eq("key", "brand_playbooks")
    .single();

  if (error) {
    console.error("Error fetching brand playbooks:", error);
    return {};
  }

  // Safely cast through unknown
  const value = data?.value as unknown;
  return (value as Record<string, BrandPlaybook>) || {};
}

/**
 * Calculate playbook compliance for all brands
 */
export async function calculatePlaybookCompliance(
  tenantId: string
): Promise<PlaybookCompliance[]> {
  const playbooks = await fetchBrandPlaybooks();
  const results: PlaybookCompliance[] = [];

  // Fetch actual usage events from last 30 days
  const thirtyDaysAgo = new Date();
  thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);

  const { data: usageEvents } = await supabase
    .from("wf_usage_events")
    .select("event_type, meta")
    .eq("tenant_id", tenantId)
    .gte("created_at", thirtyDaysAgo.toISOString());

  // Fetch IP assets
  const { data: ipAssets } = await supabase
    .from("wf_ip_assets")
    .select("asset_type, brand_key")
    .eq("tenant_id", tenantId);

  for (const [brandKey, playbook] of Object.entries(playbooks)) {
    // Filter events by brand
    const brandEvents = (usageEvents || [])
      .filter((e) => {
        const meta = e.meta as Record<string, unknown> | null;
        return meta?.brand_key === brandKey || !meta?.brand_key;
      })
      .map((e) => e.event_type);
    const uniqueEvents = [...new Set(brandEvents)];

    // Filter IP assets by brand
    const brandAssets = (ipAssets || [])
      .filter((a) => a.brand_key === brandKey || !a.brand_key)
      .map((a) => a.asset_type);
    const uniqueAssets = [...new Set(brandAssets)];

    // Calculate compliance
    const expectedEvents = playbook.required_usage_events || [];
    const expectedAssets = playbook.expected_ip_assets || [];
    const expectedRoutes = playbook.expected_ui_routes || [];

    const foundEvents = expectedEvents.filter((e) => uniqueEvents.includes(e));
    const foundAssets = expectedAssets.filter((a) => uniqueAssets.includes(a));

    const missingEvents = expectedEvents.filter((e) => !uniqueEvents.includes(e));
    const missingAssets = expectedAssets.filter((a) => !uniqueAssets.includes(a));

    // Calculate overall compliance percentage
    const totalExpected = expectedEvents.length + expectedAssets.length + expectedRoutes.length;
    const totalFound = foundEvents.length + foundAssets.length + expectedRoutes.length; // Routes assumed present
    const compliance = totalExpected > 0 ? Math.round((totalFound / totalExpected) * 100) : 100;

    results.push({
      brand_key: brandKey,
      label: playbook.label || brandKey,
      usage_events: {
        expected: expectedEvents.length,
        found: foundEvents.length,
        missing: missingEvents,
      },
      ip_assets: {
        expected: expectedAssets.length,
        found: foundAssets.length,
        missing: missingAssets,
      },
      ui_routes: {
        expected: expectedRoutes.length,
        found: expectedRoutes.length, // Assume all routes exist
        missing: [],
      },
      overall_compliance: compliance,
      sop_links: playbook.sop_links || {},
    });
  }

  return results;
}
