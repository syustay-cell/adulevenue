import { lazy, Suspense } from "react";
import { Routes, Route } from "react-router-dom";

// Wolf Fund pages - lazy loaded for performance
// These are the existing Wolf Fund pages, imported from the main pages directory
const Index = lazy(() => import("@/pages/Index"));
const Auth = lazy(() => import("@/pages/Auth"));
const Admin = lazy(() => import("@/pages/Admin"));
const AdminReports = lazy(() => import("@/pages/AdminReports"));
const AdminUsers = lazy(() => import("@/pages/AdminUsers"));
const Apply = lazy(() => import("@/pages/Apply"));
const Services = lazy(() => import("@/pages/Services"));
const HowItWorks = lazy(() => import("@/pages/HowItWorks"));
const Contact = lazy(() => import("@/pages/Contact"));
const Terms = lazy(() => import("@/pages/Terms"));
const FastTrack = lazy(() => import("@/pages/FastTrack"));
const LoanApplication = lazy(() => import("@/pages/LoanApplication"));
const ClientDashboard = lazy(() => import("@/pages/ClientDashboard"));
const WorkerDashboard = lazy(() => import("@/pages/WorkerDashboard"));
const OwnerDashboard = lazy(() => import("@/pages/OwnerDashboard"));
const CreditRepairApplication = lazy(() => import("@/pages/CreditRepairApplication"));
const CreditRepairApplicationSteps = lazy(() => import("@/pages/CreditRepairApplicationSteps"));
const CreditSpecialistDashboard = lazy(() => import("@/pages/CreditSpecialistDashboard"));
const LeadGenDashboard = lazy(() => import("@/pages/LeadGenDashboard"));
const LeadEngine = lazy(() => import("@/pages/LeadEngine"));
const LeadEnginePage = lazy(() => import("@/pages/LeadEnginePage"));
const LeadDialer = lazy(() => import("@/pages/LeadDialer"));
const LeadDialerV3 = lazy(() => import("@/pages/LeadDialerV3"));
const DialerV3 = lazy(() => import("@/pages/DialerV3"));
const Underwriting = lazy(() => import("@/pages/Underwriting"));
const UnderwritingCase = lazy(() => import("@/pages/UnderwritingCase"));
const FunderPortal = lazy(() => import("@/pages/FunderPortal"));
const ISOPartnerApplication = lazy(() => import("@/pages/ISOPartnerApplication"));
const ISOAgreementSuccess = lazy(() => import("@/pages/ISOAgreementSuccess"));
const CreditFixLanding = lazy(() => import("@/pages/CreditFixLanding"));
const CreditFixDashboard = lazy(() => import("@/pages/CreditFixDashboard"));
const CreditFixOverview = lazy(() => import("@/pages/CreditFixOverview"));
const CreditFixStudio = lazy(() => import("@/pages/CreditFixStudio"));
const CreditFixStudioV2 = lazy(() => import("@/pages/CreditFixStudioV2"));
const CreditCleanDesk = lazy(() => import("@/pages/CreditCleanDesk"));
const MyPipeline = lazy(() => import("@/pages/MyPipeline"));
const Tasks = lazy(() => import("@/pages/Tasks"));
const FollowUpDashboard = lazy(() => import("@/pages/FollowUpDashboard"));
const WolfMotherboard = lazy(() => import("@/pages/WolfMotherboard"));
const TestNotifications = lazy(() => import("@/pages/TestNotifications"));
const NotFound = lazy(() => import("@/pages/NotFound"));

// Loading fallback
const PageLoader = () => (
  <div className="min-h-screen flex items-center justify-center bg-background">
    <div className="animate-pulse text-primary font-semibold">Loading...</div>
  </div>
);

export function WolfFundRoutes() {
  return (
    <Suspense fallback={<PageLoader />}>
      <Routes>
        {/* Public routes */}
        <Route path="/" element={<Index />} />
        <Route path="/auth" element={<Auth />} />
        <Route path="/services" element={<Services />} />
        <Route path="/how-it-works" element={<HowItWorks />} />
        <Route path="/contact" element={<Contact />} />
        <Route path="/terms" element={<Terms />} />
        <Route path="/apply" element={<Apply />} />
        <Route path="/fast-track" element={<FastTrack />} />
        <Route path="/loan-application" element={<LoanApplication />} />
        <Route path="/credit-repair-application" element={<CreditRepairApplication />} />
        <Route path="/credit-repair-application-steps" element={<CreditRepairApplicationSteps />} />
        <Route path="/iso-partner-application" element={<ISOPartnerApplication />} />
        <Route path="/iso-agreement-success" element={<ISOAgreementSuccess />} />
        <Route path="/credit-fix" element={<CreditFixLanding />} />

        {/* Protected routes */}
        <Route path="/admin" element={<Admin />} />
        <Route path="/admin-reports" element={<AdminReports />} />
        <Route path="/admin-users" element={<AdminUsers />} />
        <Route path="/client-dashboard" element={<ClientDashboard />} />
        <Route path="/worker-dashboard" element={<WorkerDashboard />} />
        <Route path="/owner-dashboard" element={<OwnerDashboard />} />
        <Route path="/credit-specialist-dashboard" element={<CreditSpecialistDashboard />} />
        <Route path="/lead-gen-dashboard" element={<LeadGenDashboard />} />
        <Route path="/lead-engine" element={<LeadEngine />} />
        <Route path="/lead-engine-v3" element={<LeadEnginePage />} />
        <Route path="/lead-dialer" element={<LeadDialer />} />
        <Route path="/lead-dialer-v3" element={<LeadDialerV3 />} />
        <Route path="/dialer-v3" element={<DialerV3 />} />
        <Route path="/underwriting" element={<Underwriting />} />
        <Route path="/underwriting/:applicationId" element={<UnderwritingCase />} />
        <Route path="/funder-portal" element={<FunderPortal />} />
        <Route path="/funder-portal/deal/:dealRoomId" element={<FunderPortal />} />
        <Route path="/credit-fix-dashboard" element={<CreditFixDashboard />} />
        <Route path="/credit-fix-overview" element={<CreditFixOverview />} />
        <Route path="/credit-fix-studio" element={<CreditFixStudio />} />
        <Route path="/credit-fix-studio-v2" element={<CreditFixStudioV2 />} />
        <Route path="/credit-clean-desk" element={<CreditCleanDesk />} />
        <Route path="/my-pipeline" element={<MyPipeline />} />
        <Route path="/tasks" element={<Tasks />} />
        <Route path="/follow-up-dashboard" element={<FollowUpDashboard />} />
        <Route path="/wolf-motherboard" element={<WolfMotherboard />} />
        <Route path="/test-notifications" element={<TestNotifications />} />

        {/* 404 */}
        <Route path="*" element={<NotFound />} />
      </Routes>
    </Suspense>
  );
}

export default WolfFundRoutes;
