// Wolf Fund Brand Theme Configuration
// This is the master brand - all other brands extend from this base

export const wolfFundTheme = {
  key: "wolf-fund",
  name: "Wolf Fund",
  
  // Brand Identity
  logo: "/wolf-fund-logo.svg",
  favicon: "/favicon.ico",
  
  // Color Palette (HSL values)
  colors: {
    primary: "220 70% 45%",          // Navy blue
    primaryForeground: "0 0% 100%",   // White
    accent: "45 93% 47%",             // Gold
    accentForeground: "220 20% 10%",  // Dark navy
    background: "220 20% 96%",        // Light gray-blue
    foreground: "220 30% 15%",        // Dark navy text
    muted: "220 15% 90%",
    mutedForeground: "220 10% 40%",
    card: "0 0% 100%",
    cardForeground: "220 30% 15%",
    border: "220 15% 85%",
    ring: "220 70% 45%",
    destructive: "0 84% 60%",
    destructiveForeground: "0 0% 100%",
    success: "142 76% 36%",
    successForeground: "0 0% 100%",
    warning: "45 93% 47%",
    warningForeground: "220 20% 10%",
  },
  
  // Typography
  fonts: {
    heading: "'Inter', sans-serif",
    body: "'Inter', sans-serif",
    mono: "'JetBrains Mono', monospace",
  },
  
  // Border Radius
  radius: {
    sm: "0.25rem",
    md: "0.5rem",
    lg: "0.75rem",
    xl: "1rem",
  },
  
  // Shadows
  shadows: {
    sm: "0 1px 2px 0 rgb(0 0 0 / 0.05)",
    md: "0 4px 6px -1px rgb(0 0 0 / 0.1)",
    lg: "0 10px 15px -3px rgb(0 0 0 / 0.1)",
  },
};

export default wolfFundTheme;
