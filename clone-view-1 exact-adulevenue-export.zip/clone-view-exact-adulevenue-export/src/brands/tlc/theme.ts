// TLC Brand Theme - Clinical / Recovery styling
export const tlcTheme = {
  colors: {
    primary: 'hsl(200, 80%, 45%)',      // Clinical blue
    primaryForeground: 'hsl(0, 0%, 100%)',
    secondary: 'hsl(160, 60%, 40%)',    // Healing green
    secondaryForeground: 'hsl(0, 0%, 100%)',
    accent: 'hsl(280, 50%, 55%)',       // Calm purple
    accentForeground: 'hsl(0, 0%, 100%)',
    background: 'hsl(200, 20%, 98%)',
    foreground: 'hsl(200, 30%, 15%)',
    muted: 'hsl(200, 15%, 92%)',
    mutedForeground: 'hsl(200, 20%, 45%)',
    border: 'hsl(200, 15%, 85%)',
    destructive: 'hsl(0, 70%, 55%)',
    destructiveForeground: 'hsl(0, 0%, 100%)',
  },
  fonts: {
    heading: '"Inter", system-ui, sans-serif',
    body: '"Inter", system-ui, sans-serif',
  },
  borderRadius: '0.5rem',
} as const;

export default tlcTheme;
