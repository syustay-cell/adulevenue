// V27: TLC Brand Routes with TLCLayout - mounted at /tlc/*
// SOURCE OF TRUTH for all /tlc routes
import React from "react";
import { Routes, Route } from "react-router-dom";
import { ProtectedRoute } from "@/components/ProtectedRoute";
import { TLCLayout } from "@/layouts";
import TLCDashboardPage from "@/pages/tlc/TLCDashboardPage";
import TLCCasesPage from "@/pages/tlc/TLCCasesPage";
import TLCFamiliesPage from "@/pages/tlc/TLCFamiliesPage";
import TLCIntakePage from "@/pages/tlc/TLCIntakePage";

const TLCRoutes: React.FC = () => {
  return (
    <Routes>
      {/* Default /tlc -> Dashboard */}
      <Route
        index
        element={
          <ProtectedRoute minRole="worker">
            <TLCLayout title="TLC Dashboard">
              <TLCDashboardPage />
            </TLCLayout>
          </ProtectedRoute>
        }
      />

      <Route
        path="dashboard"
        element={
          <ProtectedRoute minRole="worker">
            <TLCLayout title="TLC Dashboard">
              <TLCDashboardPage />
            </TLCLayout>
          </ProtectedRoute>
        }
      />

      <Route
        path="cases"
        element={
          <ProtectedRoute minRole="worker">
            <TLCLayout title="TLC Cases">
              <TLCCasesPage />
            </TLCLayout>
          </ProtectedRoute>
        }
      />

      <Route
        path="families"
        element={
          <ProtectedRoute minRole="worker">
            <TLCLayout title="TLC Families">
              <TLCFamiliesPage />
            </TLCLayout>
          </ProtectedRoute>
        }
      />

      <Route
        path="intake"
        element={
          <ProtectedRoute minRole="worker">
            <TLCLayout title="TLC Intake">
              <TLCIntakePage />
            </TLCLayout>
          </ProtectedRoute>
        }
      />
    </Routes>
  );
};

export { TLCRoutes };
export default TLCRoutes;
