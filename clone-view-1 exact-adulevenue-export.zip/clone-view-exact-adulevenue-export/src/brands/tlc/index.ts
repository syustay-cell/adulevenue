// TLC Brand - Clinical / Recovery OS
export const TLC_BRAND = {
  key: 'tlc',
  name: 'TLC',
  fullName: 'TLC Clinical Services',
  routePrefix: '/tlc',
  description: 'Clinical and Recovery Operations System',
} as const;

export { TLCRoutes } from './routes';
export { tlcTheme } from './theme';
