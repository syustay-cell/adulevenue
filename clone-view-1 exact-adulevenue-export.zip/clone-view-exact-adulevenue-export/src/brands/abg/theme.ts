// Advance Builders Group (ABG) Brand Theme Configuration
// Construction industry focused brand under Wolf Fund ecosystem

export const abgTheme = {
  key: "abg",
  name: "Advanced Builders Group",

  // Brand Identity — confirmed from letterhead
  logo: "/abg-logo.svg",
  favicon: "/abg-favicon.ico",

  // Color palette — charcoal (#2B2B2B) primary, steel blue (#4A8DB7) accent
  colors: {
    primary: "207 43% 49%",           // Steel blue #4A8DB7
    primaryForeground: "0 0% 100%",
    accent: "0 0% 17%",              // Charcoal #2B2B2B
    accentForeground: "0 0% 100%",
    background: "220 14% 96%",        // Light gray surface #F5F6F8
    foreground: "0 0% 10%",           // Near black #1A1A1A
    muted: "220 13% 95%",
    mutedForeground: "220 9% 46%",
    card: "0 0% 100%",
    cardForeground: "0 0% 10%",
    border: "220 13% 91%",            // #E2E4E8
    ring: "207 43% 49%",
    destructive: "0 84% 60%",
    destructiveForeground: "0 0% 100%",
    success: "142 76% 36%",
    successForeground: "0 0% 100%",
    warning: "45 93% 47%",
    warningForeground: "0 0% 10%",
  },
  
  // Typography - More industrial feel
  fonts: {
    heading: "'Inter', sans-serif",
    body: "'Inter', sans-serif",
    mono: "'JetBrains Mono', monospace",
  },
  
  // Border Radius - Slightly more angular for industrial feel
  radius: {
    sm: "0.25rem",
    md: "0.375rem",
    lg: "0.5rem",
    xl: "0.75rem",
  },
  
  // Shadows
  shadows: {
    sm: "0 1px 2px 0 rgb(0 0 0 / 0.05)",
    md: "0 4px 6px -1px rgb(0 0 0 / 0.1)",
    lg: "0 10px 15px -3px rgb(0 0 0 / 0.1)",
  },
  
  // ABG-specific configuration — confirmed from letterhead
  config: {
    industry: "construction",
    companyName: "Advanced Builders Group",
    presidentName: "Michael Yustayev",
    officePhone: "833.NYC.BUILD",
    officePhoneFormatted: "(833) 692-2845",
    email: "michaelusto@gmail.com",
    address: "4 Evergreen Place, Deer Park, NY 11729",
    domain: "advancebuildersgroup.com",
    portalPath: "/abg",
  },
};

export default abgTheme;
