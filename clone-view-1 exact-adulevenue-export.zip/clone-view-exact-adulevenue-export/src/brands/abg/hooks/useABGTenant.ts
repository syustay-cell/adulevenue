/**
 * MVP SCOPE — ABG Tenant Hook
 *
 * Resolves the ABG tenant ID by slug ('abg') from wf_tenants,
 * then confirms the current user is a member of that tenant.
 *
 * Does NOT rely on is_primary — works correctly regardless of
 * how many tenant memberships the user has or which is marked primary.
 *
 * Replaces useTenant() for all ABG portal screens.
 */
import { useEffect, useState } from 'react';
import { supabase } from '@/integrations/supabase/client';

interface UseABGTenantState {
  tenantId: string | null;
  loading: boolean;
  error: string | null;
}

const ABG_SLUG = 'abg';

export function useABGTenant(): UseABGTenantState {
  const [state, setState] = useState<UseABGTenantState>({
    tenantId: null,
    loading: true,
    error: null,
  });

  useEffect(() => {
    let cancelled = false;

    const load = async () => {
      setState({ tenantId: null, loading: true, error: null });

      try {
        const { data: { user }, error: authError } = await supabase.auth.getUser();

        if (authError || !user) {
          if (!cancelled) setState({ tenantId: null, loading: false, error: authError?.message ?? null });
          return;
        }

        /**
         * Resolve ABG tenant via wf_tenant_users JOIN wf_tenants.
         *
         * This avoids querying wf_tenants directly (which has admin-only RLS).
         * The self-select policy on wf_tenant_users allows users to see their
         * own rows. The PostgREST foreign-key embed resolves the tenant slug
         * server-side within the user's row context.
         *
         * Result: deterministic — always finds the row where slug = 'abg',
         * regardless of how many tenant memberships the user has.
         */
        const { data, error: memberError } = await supabase
          .from('wf_tenant_users')
          .select('tenant_id, wf_tenants!inner(id, slug)')
          .eq('user_id', user.id)
          .eq('wf_tenants.slug', ABG_SLUG)
          .maybeSingle();

        if (memberError) {
          if (!cancelled) setState({ tenantId: null, loading: false, error: memberError.message });
          return;
        }

        if (!data) {
          if (!cancelled) setState({ tenantId: null, loading: false, error: 'Not a member of ABG tenant' });
          return;
        }

        if (!cancelled) setState({ tenantId: data.tenant_id, loading: false, error: null });
      } catch (err) {
        if (!cancelled) setState({
          tenantId: null,
          loading: false,
          error: err instanceof Error ? err.message : 'Unknown error',
        });
      }
    };

    load();
    return () => { cancelled = true; };
  }, []);

  return state;
}
