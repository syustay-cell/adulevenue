/**
 * Resolves the current user's sub account from abg_sub_accounts.
 * Used in all sub portal pages to get sub_id and tenant_id.
 */
import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';

export interface SubAccountState {
  subId: string | null;
  tenantId: string | null;
  loading: boolean;
  error: string | null;
}

export function useSubAccount(): SubAccountState {
  const navigate = useNavigate();
  const [state, setState] = useState<SubAccountState>({
    subId: null,
    tenantId: null,
    loading: true,
    error: null,
  });

  useEffect(() => {
    let cancelled = false;
    const load = async () => {
      try {
        const { data: { user }, error: authError } = await supabase.auth.getUser();
        if (authError || !user) {
          if (!cancelled) { setState({ subId: null, tenantId: null, loading: false, error: null }); }
          navigate('/abg/subs/login');
          return;
        }

        const { data: account, error: accountError } = await supabase
          .from('abg_sub_accounts')
          .select('sub_id, tenant_id')
          .eq('user_id', user.id)
          .maybeSingle();

        if (accountError) throw new Error(accountError.message);

        if (!account) {
          // Logged in but not a sub — redirect to login with error
          await supabase.auth.signOut();
          navigate('/abg/subs/login');
          return;
        }

        if (!cancelled) {
          setState({ subId: account.sub_id, tenantId: account.tenant_id, loading: false, error: null });
        }
      } catch (err) {
        if (!cancelled) {
          setState({ subId: null, tenantId: null, loading: false, error: err instanceof Error ? err.message : 'Error' });
        }
      }
    };

    load();
    return () => { cancelled = true; };
  }, [navigate]);

  return state;
}
