import { useEffect, useState, useCallback } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { useABGTenant } from '../hooks/useABGTenant';
import { ABGShell } from '../components/ABGShell';
import { InlineNextAction } from '../components/InlineNextAction';
import { PreliminaryBudgetModal } from '../components/PreliminaryBudgetModal';
import { formatCurrency, timeAgo, formatDate } from '../lib/time';
import type {
  ABGJob, ABGJobTrade, ABGSubcontractor, ABGSubLastPrice,
  ABGSubQuote, ABGJobDocument, TradeType, TradeStatus, DocType,
} from '../types';
import {
  ChevronLeft, Plus, Loader2, AlertCircle, Check,
  User, DollarSign, FileText, Trash2, CheckCircle2, Calculator,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle,
} from '@/components/ui/dialog';
import { cn } from '@/lib/utils';

// ─── Trade type options ───────────────────────────────────────────────────────

const TRADE_TYPES: TradeType[] = [
  'framing','electrical','plumbing','hvac','drywall',
  'flooring','roofing','concrete','insulation','painting',
  'windows','doors','excavation','landscaping','general','other',
];

const TRADE_STATUS_CONFIG: Record<TradeStatus, { label: string; className: string }> = {
  pending:     { label: 'Pending',     className: 'bg-gray-100 text-gray-500 border-gray-200' },
  quoted:      { label: 'Quoted',      className: 'bg-amber-100 text-amber-700 border-amber-200' },
  accepted:    { label: 'Accepted',    className: 'bg-[#4A8DB7]/15 text-[#4A8DB7] border-[#4A8DB7]/30' },
  in_progress: { label: 'In Progress', className: 'bg-orange-100 text-orange-700 border-orange-200' },
  completed:   { label: 'Completed',   className: 'bg-green-100 text-green-700 border-green-200' },
};

const JOB_STATUS_OPTIONS = ['planning','bidding','active','delayed','completed'];

// ─── Trade row ────────────────────────────────────────────────────────────────

interface TradeRowProps {
  trade: ABGJobTrade;
  subs: ABGSubcontractor[];
  lastPrices: ABGSubLastPrice[];
  onUpdate: (tradeId: string, updates: Partial<ABGJobTrade>) => void;
  onSavePrice: (tradeId: string, subId: string, price: number, notes: string) => void;
  onDelete: (tradeId: string) => void;
}

function TradeRow({ trade, subs, lastPrices, onUpdate, onSavePrice, onDelete }: TradeRowProps) {
  const [estimateInput, setEstimateInput] = useState(trade.estimated_cost ? String(trade.estimated_cost) : '');
  const [agreedInput, setAgreedInput]     = useState(trade.agreed_price ? String(trade.agreed_price) : '');
  const [priceNotes, setPriceNotes]       = useState('');
  const [saving, setSaving]               = useState(false);

  // Only show subs whose trade_type matches — enforced in DB too
  const tradeSubs = subs.filter((s) => s.trade_type === trade.trade_type && s.is_active);

  const lastPrice = trade.assigned_sub_id
    ? lastPrices.find((lp) => lp.sub_id === trade.assigned_sub_id && lp.trade_type === trade.trade_type)
    : null;

  const handleSavePrice = async () => {
    if (!trade.assigned_sub_id || !agreedInput) return;
    setSaving(true);
    await onSavePrice(trade.id, trade.assigned_sub_id, parseFloat(agreedInput), priceNotes);
    setSaving(false);
  };

  const config = TRADE_STATUS_CONFIG[trade.status] ?? TRADE_STATUS_CONFIG.pending;

  return (
    <div className="bg-white border border-[#E2E4E8] rounded-lg p-4">
      {/* Trade header */}
      <div className="flex items-start justify-between gap-3 mb-3">
        <div className="flex items-center gap-2 flex-wrap">
          <p className="font-semibold text-[#2B2B2B] capitalize">{trade.trade_type}</p>
          <span className={cn(
            'inline-flex items-center px-2 py-0.5 rounded text-xs font-medium border',
            config.className
          )}>
            {config.label}
          </span>
        </div>
        <button
          onClick={() => onDelete(trade.id)}
          className="text-gray-300 hover:text-red-500 transition-colors shrink-0"
        >
          <Trash2 className="h-4 w-4" />
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mb-3">
        {/* Scope of work */}
        <div className="md:col-span-2">
          <Label className="text-xs text-gray-400 uppercase tracking-wide mb-1 block">Scope of Work</Label>
          <Textarea
            value={trade.scope_of_work ?? ''}
            onChange={(e) => onUpdate(trade.id, { scope_of_work: e.target.value })}
            onBlur={(e) => onUpdate(trade.id, { scope_of_work: e.target.value })}
            placeholder="Describe exactly what this trade covers..."
            rows={2}
            className="text-sm resize-none"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
        {/* Assign sub */}
        <div>
          <Label className="text-xs text-gray-400 uppercase tracking-wide mb-1 block">
            Subcontractor
          </Label>
          <Select
            value={trade.assigned_sub_id ?? '__none__'}
            onValueChange={(v) => onUpdate(trade.id, {
              assigned_sub_id: v === '__none__' ? null : v,
              status: v !== '__none__' && trade.status === 'pending' ? 'quoted' : trade.status,
            })}
          >
            <SelectTrigger className="h-8 text-sm">
              <SelectValue placeholder="Assign sub..." />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="__none__">Unassigned</SelectItem>
              {tradeSubs.map((s) => (
                <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>
              ))}
              {tradeSubs.length === 0 && (
                <SelectItem value="__no_subs__" disabled>No {trade.trade_type} subs on file</SelectItem>
              )}
            </SelectContent>
          </Select>
          {lastPrice && (
            <p className="text-xs text-[#4A8DB7] mt-1 flex items-center gap-1">
              <DollarSign className="h-3 w-3" />
              Last price: {formatCurrency(lastPrice.last_price)}
              {lastPrice.last_price_notes && ` — ${lastPrice.last_price_notes}`}
            </p>
          )}
        </div>

        {/* Estimated cost */}
        <div>
          <Label className="text-xs text-gray-400 uppercase tracking-wide mb-1 block">Estimate</Label>
          <div className="relative">
            <span className="absolute left-2.5 top-1/2 -translate-y-1/2 text-gray-400 text-sm">$</span>
            <Input
              type="number"
              value={estimateInput}
              onChange={(e) => setEstimateInput(e.target.value)}
              onBlur={() => onUpdate(trade.id, {
                estimated_cost: estimateInput ? parseFloat(estimateInput) : null,
              })}
              placeholder="Your estimate"
              className="pl-6 h-8 text-sm"
            />
          </div>
          <p className="text-xs text-gray-400 mt-0.5">Your internal estimate</p>
        </div>

        {/* Agreed price — what sub commits to */}
        <div>
          <Label className="text-xs text-gray-400 uppercase tracking-wide mb-1 block">Agreed Price</Label>
          <div className="flex gap-2">
            <div className="relative flex-1">
              <span className="absolute left-2.5 top-1/2 -translate-y-1/2 text-gray-400 text-sm">$</span>
              <Input
                type="number"
                value={agreedInput}
                onChange={(e) => setAgreedInput(e.target.value)}
                onBlur={() => onUpdate(trade.id, {
                  agreed_price: agreedInput ? parseFloat(agreedInput) : null,
                  // DB trigger auto-advances to 'accepted' when agreed_price is set
                })}
                placeholder="Sub's locked price"
                className="pl-6 h-8 text-sm"
              />
            </div>
            {trade.assigned_sub_id && agreedInput && (
              <Button
                size="sm"
                onClick={handleSavePrice}
                disabled={saving}
                className="bg-green-600 hover:bg-green-700 text-white h-8 px-2 shrink-0"
                title="Save to pricing memory"
              >
                {saving ? <Loader2 className="h-3 w-3 animate-spin" /> : <Check className="h-3 w-3" />}
              </Button>
            )}
          </div>
          {trade.assigned_sub_id && agreedInput && (
            <Input
              value={priceNotes}
              onChange={(e) => setPriceNotes(e.target.value)}
              placeholder="Notes for memory"
              className="mt-1 h-7 text-xs"
            />
          )}
          <p className="text-xs text-gray-400 mt-0.5">Sub's committed price</p>
        </div>
      </div>

      {/* Status + dates + next action */}
      <div className="mt-3 grid grid-cols-1 md:grid-cols-3 gap-3">
        <div className="flex items-center gap-2">
          <Label className="text-xs text-gray-400 uppercase tracking-wide shrink-0">Status</Label>
          <Select
            value={trade.status}
            onValueChange={(v) => onUpdate(trade.id, { status: v as TradeStatus })}
          >
            <SelectTrigger className="h-7 text-xs flex-1">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="pending">Pending</SelectItem>
              <SelectItem value="quoted">Quoted</SelectItem>
              <SelectItem value="accepted">Accepted</SelectItem>
              <SelectItem value="in_progress">In Progress</SelectItem>
              <SelectItem value="completed">Completed</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div>
          <Label className="text-xs text-gray-400 uppercase tracking-wide mb-0.5 block">Start</Label>
          <input
            type="date"
            defaultValue={trade.start_date ?? ''}
            onBlur={(e) => onUpdate(trade.id, { start_date: e.target.value || null })}
            className="text-xs text-gray-500 border border-[#E2E4E8] rounded px-2 py-1 w-full"
          />
        </div>
        <div>
          <Label className="text-xs text-gray-400 uppercase tracking-wide mb-0.5 block">Est. Done</Label>
          <input
            type="date"
            defaultValue={trade.expected_completion_date ?? ''}
            onBlur={(e) => onUpdate(trade.id, { expected_completion_date: e.target.value || null })}
            className="text-xs text-gray-500 border border-[#E2E4E8] rounded px-2 py-1 w-full"
          />
        </div>
      </div>

      <div className="mt-2 border-t border-[#F0F0F0] pt-2">
        <Label className="text-xs text-gray-400 uppercase tracking-wide mb-0.5 block">Trade Next Action</Label>
        <InlineNextAction
          value={trade.next_action}
          dueAt={trade.next_action_due}
          onSave={(action, due) => onUpdate(trade.id, { next_action: action, next_action_due: due })}
          placeholder="Set next action for this trade…"
          compact
        />
      </div>
    </div>
  );
}

// ─── Main component ───────────────────────────────────────────────────────────

export default function ABGJobDetail() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { tenantId } = useABGTenant();

  const [job, setJob]           = useState<ABGJob | null>(null);
  const [trades, setTrades]     = useState<ABGJobTrade[]>([]);
  const [subs, setSubs]         = useState<ABGSubcontractor[]>([]);
  const [lastPrices, setLastPrices] = useState<ABGSubLastPrice[]>([]);
  const [quotes, setQuotes]     = useState<ABGSubQuote[]>([]);
  const [documents, setDocuments] = useState<ABGJobDocument[]>([]);
  const [loading, setLoading]   = useState(true);
  const [error, setError]       = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'trades' | 'documents'>('trades');
  const [docName, setDocName]   = useState('');
  const [docType, setDocType]   = useState<DocType>('other');
  const [docNotes, setDocNotes] = useState('');
  const [addDocOpen, setAddDocOpen]     = useState(false);
  const [budgetOpen, setBudgetOpen]     = useState(false);

  // Modals
  const [addTradeOpen, setAddTradeOpen] = useState(false);
  const [newTradeType, setNewTradeType] = useState<TradeType>('framing');
  const [addSubOpen, setAddSubOpen]     = useState(false);
  const [newSubName, setNewSubName]     = useState('');
  const [newSubTrade, setNewSubTrade]   = useState<TradeType>('framing');
  const [newSubPhone, setNewSubPhone]   = useState('');
  const [newSubEmail, setNewSubEmail]   = useState('');
  const [submitting, setSubmitting]     = useState(false);

  const loadData = useCallback(async () => {
    if (!id || !tenantId) return;
    setLoading(true);
    try {
      const [jobRes, tradesRes, subsRes, pricesRes, quotesRes, docsRes] = await Promise.all([
        supabase.from('abg_jobs').select('*').eq('id', id).single(),
        supabase.from('abg_job_trades').select('*').eq('job_id', id).order('trade_type'),
        supabase.from('abg_subcontractors').select('*').eq('tenant_id', tenantId).eq('is_active', true).order('name'),
        supabase.from('abg_sub_last_price').select('*').eq('tenant_id', tenantId),
        supabase.from('abg_sub_quotes').select('*').eq('job_id', id).order('submitted_at', { ascending: false }),
        supabase.from('abg_job_documents').select('*').eq('job_id', id).order('created_at', { ascending: false }),
      ]);
      if (jobRes.error) throw new Error(jobRes.error.message);
      setJob(jobRes.data as ABGJob);
      setTrades((tradesRes.data ?? []) as ABGJobTrade[]);
      setSubs((subsRes.data ?? []) as ABGSubcontractor[]);
      setLastPrices((pricesRes.data ?? []) as ABGSubLastPrice[]);
      setQuotes((quotesRes.data ?? []) as ABGSubQuote[]);
      setDocuments((docsRes.data ?? []) as ABGJobDocument[]);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Failed to load job');
    } finally {
      setLoading(false);
    }
  }, [id, tenantId]);

  useEffect(() => { loadData(); }, [loadData]);

  // ── Update trade inline ────────────────────────────────────────────────────

  const updateTrade = async (tradeId: string, updates: Partial<ABGJobTrade>) => {
    await supabase.from('abg_job_trades').update({ ...updates, updated_at: new Date().toISOString() }).eq('id', tradeId);
    setTrades((prev) => prev.map((t) => t.id === tradeId ? { ...t, ...updates } : t));
  };

  // ── Save price to memory ───────────────────────────────────────────────────

  // Save agreed price to pricing memory — called when worker clicks ✓
  const savePrice = async (tradeId: string, subId: string, price: number, notes: string) => {
    if (!tenantId || !job) return;
    const trade = trades.find((t) => t.id === tradeId);
    if (!trade) return;
    // Write to pricing memory
    await supabase.from('abg_sub_pricing').insert({
      tenant_id: tenantId,
      sub_id: subId,
      trade_type: trade.trade_type,
      job_id: job.id,
      price,
      notes: notes || null,
    });
    // Also write agreed_price to the trade row
    await supabase.from('abg_job_trades').update({
      agreed_price: price,
      updated_at: new Date().toISOString(),
    }).eq('id', tradeId);
    // Update the sub's last_price_notes summary
    await supabase.from('abg_subcontractors').update({
      last_price_notes: `${formatCurrency(price)}${notes ? ' — ' + notes : ''}`,
    }).eq('id', subId);
    await loadData();
  };

  // ── Accept quote (Mike side) ───────────────────────────────────────────────

  const acceptQuote = async (quoteId: string) => {
    if (!tenantId) return;
    await supabase
      .from('abg_sub_quotes')
      .update({ status: 'accepted', reviewed_at: new Date().toISOString() })
      .eq('id', quoteId);
    // DB trigger handles: agreed_price, trade status, reject other quotes, pricing memory
    await loadData();
  };

  // ── Delete trade ───────────────────────────────────────────────────────────

  const deleteTrade = async (tradeId: string) => {
    await supabase.from('abg_job_trades').delete().eq('id', tradeId);
    setTrades((prev) => prev.filter((t) => t.id !== tradeId));
  };

  // ── Add trade ──────────────────────────────────────────────────────────────

  const addTrade = async () => {
    if (!job || !tenantId) return;
    setSubmitting(true);
    try {
      const { data } = await supabase.from('abg_job_trades').insert({
        tenant_id: tenantId,
        job_id: job.id,
        trade_type: newTradeType,
        status: 'pending_bid',
      }).select().single();
      if (data) setTrades((prev) => [...prev, data as ABGJobTrade]);
      setAddTradeOpen(false);
    } finally {
      setSubmitting(false);
    }
  };

  // ── Add subcontractor ──────────────────────────────────────────────────────

  const addSub = async () => {
    if (!tenantId || !newSubName.trim()) return;
    setSubmitting(true);
    try {
      const { data } = await supabase.from('abg_subcontractors').insert({
        tenant_id: tenantId,
        name: newSubName.trim(),
        trade_type: newSubTrade,
        phone: newSubPhone.trim() || null,
        email: newSubEmail.trim() || null,
      }).select().single();
      if (data) setSubs((prev) => [...prev, data as ABGSubcontractor]);
      setNewSubName(''); setNewSubPhone(''); setNewSubEmail('');
      setAddSubOpen(false);
    } finally {
      setSubmitting(false);
    }
  };

  // ── Update job status ──────────────────────────────────────────────────────

  const updateJobStatus = async (status: string) => {
    if (!job) return;
    await supabase.from('abg_jobs').update({ status, updated_at: new Date().toISOString() }).eq('id', job.id);
    setJob((prev) => prev ? { ...prev, status: status as ABGJob['status'] } : prev);
  };

  // ── Totals ─────────────────────────────────────────────────────────────────

  // Use agreed_price when locked, fall back to estimated_cost
  const totalEstimated = trades.reduce((sum, t) => sum + (t.agreed_price ?? t.estimated_cost ?? 0), 0);
  const tradeDone = trades.filter((t) => t.status === 'completed').length;
  const tradesAccepted = trades.filter((t) => ['accepted','in_progress','completed'].includes(t.status)).length;

  // ─── Render ────────────────────────────────────────────────────────────────

  if (loading) {
    return (
      <ABGShell>
        <div className="flex items-center justify-center h-64 gap-2 text-muted-foreground">
          <Loader2 className="h-5 w-5 animate-spin" />
          Loading job…
        </div>
      </ABGShell>
    );
  }

  if (error || !job) {
    return (
      <ABGShell>
        <div className="flex items-center gap-2 text-red-600 bg-red-50 border border-red-200 rounded-lg p-4">
          <AlertCircle className="h-4 w-4 shrink-0" />
          {error ?? 'Job not found'}
        </div>
      </ABGShell>
    );
  }

  return (
    <ABGShell>
      {/* Header */}
      <div className="flex items-start justify-between mb-4">
        <div>
          <button
            onClick={() => navigate('/abg/portal/jobs')}
            className="flex items-center gap-1 text-gray-400 hover:text-[#2B2B2B] text-sm mb-1 transition-colors"
          >
            <ChevronLeft className="h-4 w-4" />
            Jobs
          </button>
          <h1 className="text-2xl font-bold text-[#2B2B2B]">{job.job_name}</h1>
          <p className="text-sm text-gray-400 mt-0.5">
            {job.address ?? 'No address'} · Created {timeAgo(job.created_at)}
          </p>
        </div>
        <Select value={job.status} onValueChange={updateJobStatus}>
          <SelectTrigger className="w-36 h-8 text-sm border-[#E2E4E8]">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {JOB_STATUS_OPTIONS.map((s) => (
              <SelectItem key={s} value={s} className="capitalize">{s}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Summary bar */}
      {trades.length > 0 && (
        <div className="bg-white border border-[#E2E4E8] rounded-lg px-4 py-3 mb-4 flex flex-wrap gap-6">
          <div>
            <p className="text-xs text-gray-400 uppercase tracking-wide">Total Estimated</p>
            <p className="text-lg font-bold text-[#2B2B2B]">{formatCurrency(totalEstimated)}</p>
          </div>
          <div>
            <p className="text-xs text-gray-400 uppercase tracking-wide">Trades</p>
            <p className="text-lg font-bold text-[#2B2B2B]">{trades.length}</p>
          </div>
          <div>
            <p className="text-xs text-gray-400 uppercase tracking-wide">Accepted</p>
            <p className="text-lg font-bold text-[#4A8DB7]">{tradesAccepted} / {trades.length}</p>
          </div>
          <div>
            <p className="text-xs text-gray-400 uppercase tracking-wide">Complete</p>
            <p className="text-lg font-bold text-green-600">{tradeDone} / {trades.length}</p>
          </div>
        </div>
      )}

      {/* Job next action + dates */}
      <div className="bg-white border border-[#E2E4E8] rounded-lg p-4 mb-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="md:col-span-1">
            <p className="text-xs text-gray-400 uppercase tracking-wide mb-1">Next Action</p>
            <InlineNextAction
              value={job.next_action}
              dueAt={job.next_action_due}
              onSave={async (action, due) => {
                await supabase.from('abg_jobs').update({
                  next_action: action,
                  next_action_due: due,
                  updated_at: new Date().toISOString(),
                }).eq('id', job.id);
                setJob((prev) => prev ? { ...prev, next_action: action, next_action_due: due } : prev);
              }}
              placeholder="Set next action for this job…"
              compact
            />
          </div>
          <div>
            <p className="text-xs text-gray-400 uppercase tracking-wide mb-1">Start Date</p>
            <input
              type="date"
              defaultValue={job.start_date ?? ''}
              onBlur={async (e) => {
                const val = e.target.value || null;
                await supabase.from('abg_jobs').update({ start_date: val, updated_at: new Date().toISOString() }).eq('id', job.id);
                setJob((prev) => prev ? { ...prev, start_date: val } : prev);
              }}
              className="text-sm text-gray-600 border border-[#E2E4E8] rounded px-2 py-1 w-full"
            />
          </div>
          <div>
            <p className="text-xs text-gray-400 uppercase tracking-wide mb-1">Est. Completion</p>
            <input
              type="date"
              defaultValue={job.expected_completion_date ?? ''}
              onBlur={async (e) => {
                const val = e.target.value || null;
                await supabase.from('abg_jobs').update({ expected_completion_date: val, updated_at: new Date().toISOString() }).eq('id', job.id);
                setJob((prev) => prev ? { ...prev, expected_completion_date: val } : prev);
              }}
              className="text-sm text-gray-600 border border-[#E2E4E8] rounded px-2 py-1 w-full"
            />
          </div>
        </div>
      </div>

      {/* Action buttons */}
      <div className="flex gap-2 mb-4 flex-wrap">
        <Button
          onClick={() => setBudgetOpen(true)}
          className="bg-[#2B2B2B] hover:bg-[#4A8DB7] text-white"
        >
          <Calculator className="h-4 w-4 mr-1.5" />
          Generate Budget
        </Button>
        <Button
          onClick={() => setAddTradeOpen(true)}
          className="bg-[#4A8DB7] hover:bg-[#4A8DB7]/90 text-white"
        >
          <Plus className="h-4 w-4 mr-1.5" />
          Add Trade
        </Button>
        <Button
          onClick={() => setAddSubOpen(true)}
          variant="outline"
          className="border-[#E2E4E8] hover:border-[#4A8DB7] hover:text-[#4A8DB7]"
        >
          <User className="h-4 w-4 mr-1.5" />
          Add Subcontractor
        </Button>
        <Button
          onClick={() => setActiveTab('documents')}
          variant="outline"
          className={cn(
            'border-[#E2E4E8] hover:border-[#4A8DB7] hover:text-[#4A8DB7]',
            activeTab === 'documents' && 'border-[#4A8DB7] text-[#4A8DB7]'
          )}
        >
          <FileText className="h-4 w-4 mr-1.5" />
          Documents {documents.length > 0 && `(${documents.length})`}
        </Button>
      </div>

      {/* Tab selector */}
      <div className="flex gap-1 border-b border-[#E2E4E8] mb-4">
        {(['trades', 'documents'] as const).map((tab) => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={cn(
              'px-4 py-1.5 text-sm font-medium capitalize border-b-2 -mb-px transition-colors',
              activeTab === tab
                ? 'border-[#4A8DB7] text-[#4A8DB7]'
                : 'border-transparent text-gray-400 hover:text-[#2B2B2B]'
            )}
          >
            {tab === 'trades' ? `Trades (${trades.length})` : `Documents (${documents.length})`}
          </button>
        ))}
      </div>

      {/* Documents tab */}
      {activeTab === 'documents' && (
        <div className="space-y-3">
          <div className="bg-white border border-[#E2E4E8] rounded-lg p-4">
            <p className="text-sm font-semibold text-[#2B2B2B] mb-3">Add Document Entry</p>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label className="text-xs text-gray-400 uppercase tracking-wide mb-1 block">Name</Label>
                <Input
                  value={docName}
                  onChange={(e) => setDocName(e.target.value)}
                  placeholder="e.g. Building Permit"
                  className="text-sm h-8"
                />
              </div>
              <div>
                <Label className="text-xs text-gray-400 uppercase tracking-wide mb-1 block">Type</Label>
                <Select value={docType} onValueChange={(v) => setDocType(v as DocType)}>
                  <SelectTrigger className="h-8 text-sm"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {(['permit','plan','contract','photo','inspection','other'] as DocType[]).map((t) => (
                      <SelectItem key={t} value={t} className="capitalize">{t}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="col-span-2">
                <Label className="text-xs text-gray-400 uppercase tracking-wide mb-1 block">Notes</Label>
                <Input
                  value={docNotes}
                  onChange={(e) => setDocNotes(e.target.value)}
                  placeholder="Optional notes"
                  className="text-sm h-8"
                />
              </div>
            </div>
            <Button
              onClick={async () => {
                if (!docName.trim() || !tenantId) return;
                const { data: { user } } = await supabase.auth.getUser();
                const { data } = await supabase.from('abg_job_documents').insert({
                  tenant_id: tenantId,
                  job_id: job.id,
                  name: docName.trim(),
                  doc_type: docType,
                  notes: docNotes.trim() || null,
                  uploaded_by: user?.id ?? null,
                }).select().single();
                if (data) setDocuments((prev) => [data as ABGJobDocument, ...prev]);
                setDocName(''); setDocNotes('');
              }}
              disabled={!docName.trim()}
              className="mt-3 bg-[#4A8DB7] hover:bg-[#4A8DB7]/90 text-white"
              size="sm"
            >
              Add Entry
            </Button>
          </div>

          {documents.length === 0 ? (
            <div className="bg-white border border-[#E2E4E8] rounded-lg p-8 text-center">
              <FileText className="h-8 w-8 text-gray-300 mx-auto mb-2" />
              <p className="text-sm font-medium text-[#2B2B2B]">No documents yet</p>
              <p className="text-sm text-gray-400 mt-1">Add document entries above. File upload coming later.</p>
            </div>
          ) : (
            <div className="space-y-2">
              {documents.map((doc) => (
                <div key={doc.id} className="bg-white border border-[#E2E4E8] rounded-lg px-4 py-3 flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-[#1A1A1A]">{doc.name}</p>
                    <div className="flex items-center gap-2 mt-0.5">
                      <span className="text-xs bg-gray-100 text-gray-600 px-2 py-0.5 rounded capitalize">{doc.doc_type}</span>
                      {doc.notes && <span className="text-xs text-gray-400">{doc.notes}</span>}
                    </div>
                  </div>
                  <p className="text-xs text-gray-400 shrink-0">{formatDate(doc.created_at)}</p>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Trade list — only shown when trades tab is active */}
      {activeTab === 'trades' && <>{/* Trade list */}
      {trades.length === 0 ? (
        <div className="bg-white border border-[#E2E4E8] rounded-lg p-8 text-center">
          <FileText className="h-8 w-8 text-gray-300 mx-auto mb-2" />
          <p className="text-sm font-medium text-[#2B2B2B]">No trades added yet</p>
          <p className="text-sm text-gray-400 mt-1">Add trades to break down the job by scope.</p>
        </div>
      ) : (
        <div className="space-y-3">
          {trades.map((trade) => (
            <TradeRow
              key={trade.id}
              trade={trade}
              subs={subs}
              lastPrices={lastPrices}
              onUpdate={updateTrade}
              onSavePrice={savePrice}
              onDelete={deleteTrade}
            />
          ))}
        </div>
      )}

      {/* ── Submitted Quotes Panel (Mike's view) ───────────────────────── */}
      {quotes.length > 0 && (
        <div className="bg-white border border-[#E2E4E8] rounded-lg overflow-hidden">
          <div className="px-4 py-3 border-b border-[#E2E4E8] bg-[#F5F6F8]">
            <p className="text-sm font-semibold text-[#2B2B2B]">
              Submitted Quotes ({quotes.filter(q => q.status === 'submitted').length} pending)
            </p>
          </div>
          <div className="divide-y divide-[#E2E4E8]">
            {quotes.map((quote) => {
              const trade = trades.find(t => t.id === quote.trade_id);
              const sub   = subs.find(s => s.id === quote.sub_id);
              const lastP = lastPrices.find(lp => lp.sub_id === quote.sub_id && lp.trade_type === trade?.trade_type);

              return (
                <div key={quote.id} className="px-4 py-3">
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="text-xs bg-[#2B2B2B] text-white px-2 py-0.5 rounded capitalize">
                          {trade?.trade_type ?? 'trade'}
                        </span>
                        <span className="font-semibold text-[#1A1A1A]">{formatCurrency(quote.quoted_price)}</span>
                        {lastP && (
                          <span className="text-xs text-gray-400">
                            Last: {formatCurrency(lastP.last_price)}
                            {quote.quoted_price < lastP.last_price
                              ? <span className="text-green-600 ml-1">↓ lower</span>
                              : quote.quoted_price > lastP.last_price
                                ? <span className="text-red-500 ml-1">↑ higher</span>
                                : <span className="text-gray-400 ml-1">= same</span>
                            }
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-gray-500 mt-0.5">
                        {sub?.name ?? 'Sub'} · {new Date(quote.submitted_at).toLocaleString()}
                      </p>
                      {quote.notes && <p className="text-xs text-gray-400 mt-0.5 italic">"{quote.notes}"</p>}
                    </div>
                    <div className="shrink-0">
                      {quote.status === 'submitted' ? (
                        <Button
                          size="sm"
                          onClick={() => acceptQuote(quote.id)}
                          className="bg-green-600 hover:bg-green-700 text-white h-8"
                        >
                          <CheckCircle2 className="h-3.5 w-3.5 mr-1" />
                          Accept
                        </Button>
                      ) : (
                        <span className={cn(
                          'text-xs px-2 py-1 rounded border',
                          quote.status === 'accepted'
                            ? 'bg-green-100 text-green-700 border-green-200'
                            : 'bg-gray-100 text-gray-400 border-gray-200'
                        )}>
                          {quote.status === 'accepted' ? 'Accepted ✓' : 'Not selected'}
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      </>}

      {/* Preliminary Budget modal */}
      {tenantId && job && (
        <PreliminaryBudgetModal
          open={budgetOpen}
          onOpenChange={setBudgetOpen}
          jobId={job.id}
          tenantId={tenantId}
          existingTradeTypes={trades.map((t) => t.trade_type)}
          onSaved={loadData}
        />
      )}

      {/* Add Trade modal */}
      <Dialog open={addTradeOpen} onOpenChange={setAddTradeOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>Add Trade</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <div>
              <Label>Trade Type</Label>
              <Select value={newTradeType} onValueChange={(v) => setNewTradeType(v as TradeType)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {TRADE_TYPES.map((t) => (
                    <SelectItem key={t} value={t} className="capitalize">{t}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <Button
              onClick={addTrade}
              disabled={submitting}
              className="w-full bg-[#4A8DB7] hover:bg-[#4A8DB7]/90 text-white"
            >
              {submitting ? <Loader2 className="h-4 w-4 animate-spin mr-1" /> : null}
              Add Trade
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Add Subcontractor modal */}
      <Dialog open={addSubOpen} onOpenChange={setAddSubOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>Add Subcontractor</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <div>
              <Label>Name</Label>
              <Input value={newSubName} onChange={(e) => setNewSubName(e.target.value)} placeholder="Company or person name" className="text-sm" />
            </div>
            <div>
              <Label>Trade</Label>
              <Select value={newSubTrade} onValueChange={(v) => setNewSubTrade(v as TradeType)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {TRADE_TYPES.map((t) => (
                    <SelectItem key={t} value={t} className="capitalize">{t}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Phone</Label>
              <Input value={newSubPhone} onChange={(e) => setNewSubPhone(e.target.value)} placeholder="(555) 000-0000" className="text-sm" />
            </div>
            <div>
              <Label>Email</Label>
              <Input value={newSubEmail} onChange={(e) => setNewSubEmail(e.target.value)} placeholder="sub@example.com" className="text-sm" />
            </div>
            <Button
              onClick={addSub}
              disabled={submitting || !newSubName.trim()}
              className="w-full bg-[#4A8DB7] hover:bg-[#4A8DB7]/90 text-white"
            >
              {submitting ? <Loader2 className="h-4 w-4 animate-spin mr-1" /> : null}
              Save Subcontractor
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </ABGShell>
  );
}
