import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { useABGTenant } from '../hooks/useABGTenant';
import { ABGShell } from '../components/ABGShell';
import { timeAgo } from '../lib/time';
import type { ABGJob } from '../types';
import { Loader2, AlertCircle, HardHat, Plus } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

// ─── Status badge ─────────────────────────────────────────────────────────────

const JOB_STATUS_CONFIG: Record<string, { label: string; className: string }> = {
  planning:   { label: 'Planning',   className: 'bg-gray-100 text-gray-600 border-gray-200' },
  bidding:    { label: 'Bidding',    className: 'bg-amber-100 text-amber-700 border-amber-200' },
  active:     { label: 'Active',     className: 'bg-[#4A8DB7]/15 text-[#4A8DB7] border-[#4A8DB7]/30' },
  delayed:    { label: 'Delayed',    className: 'bg-red-100 text-red-700 border-red-200' },
  completed:  { label: 'Completed',  className: 'bg-green-100 text-green-700 border-green-200' },
  // legacy alias from before hardening migration
  complete:   { label: 'Complete',   className: 'bg-green-100 text-green-700 border-green-200' },
};

function JobStatusBadge({ status }: { status: string }) {
  const config = JOB_STATUS_CONFIG[status] ?? JOB_STATUS_CONFIG.planning;
  return (
    <span className={cn(
      'inline-flex items-center px-2 py-0.5 rounded text-xs font-medium border',
      config.className
    )}>
      {config.label}
    </span>
  );
}

// ─── Job row with lead name ───────────────────────────────────────────────────

interface JobWithDeal extends ABGJob {
  client_name: string;
  deal_stage: string;
}

async function fetchJobs(tenantId: string): Promise<JobWithDeal[]> {
  const { data: jobs, error } = await supabase
    .from('abg_jobs')
    .select('*')
    .eq('tenant_id', tenantId)
    .order('created_at', { ascending: false });

  if (error) throw new Error(error.message);
  if (!jobs?.length) return [];

  // Resolve deal → lead names
  const dealIds = jobs.map((j) => j.deal_id);
  const { data: deals } = await supabase
    .from('abg_deals')
    .select('id, lead_id, stage')
    .in('id', dealIds);

  const leadIds = (deals ?? []).map((d) => d.lead_id);
  const { data: leads } = await supabase
    .from('wf_leads')
    .select('id, first_name, last_name')
    .in('id', leadIds);

  const leadMap: Record<string, string> = {};
  (leads ?? []).forEach((l) => {
    leadMap[l.id] = [l.first_name, l.last_name].filter(Boolean).join(' ') || 'Unknown';
  });

  const dealMap: Record<string, { leadId: string; stage: string }> = {};
  (deals ?? []).forEach((d) => {
    dealMap[d.id] = { leadId: d.lead_id, stage: d.stage };
  });

  return jobs.map((j) => ({
    ...j,
    client_name: leadMap[dealMap[j.deal_id]?.leadId ?? ''] ?? 'Unknown',
    deal_stage: dealMap[j.deal_id]?.stage ?? '',
  })) as JobWithDeal[];
}

// ─── Component ────────────────────────────────────────────────────────────────

export default function ABGJobList() {
  const navigate = useNavigate();
  const { tenantId, loading: tenantLoading } = useABGTenant();

  const [jobs, setJobs] = useState<JobWithDeal[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (tenantLoading) return;
    if (!tenantId) { setLoading(false); return; }
    setLoading(true);
    fetchJobs(tenantId)
      .then(setJobs)
      .catch((e) => setError(e.message))
      .finally(() => setLoading(false));
  }, [tenantId, tenantLoading]);

  if (loading) {
    return (
      <ABGShell>
        <div className="flex items-center justify-center h-64 gap-2 text-muted-foreground">
          <Loader2 className="h-5 w-5 animate-spin" />
          Loading jobs…
        </div>
      </ABGShell>
    );
  }

  if (error) {
    return (
      <ABGShell>
        <div className="flex items-center gap-2 text-red-600 bg-red-50 border border-red-200 rounded-lg p-4">
          <AlertCircle className="h-4 w-4 shrink-0" />
          {error}
        </div>
      </ABGShell>
    );
  }

  return (
    <ABGShell>
      <div className="flex items-center justify-between mb-5">
        <div>
          <h1 className="text-2xl font-bold text-[#2B2B2B]">Jobs</h1>
          <p className="text-sm text-gray-500 mt-0.5">
            {jobs.length} job{jobs.length !== 1 ? 's' : ''}
          </p>
        </div>
        <Button
          onClick={() => navigate('/abg/portal/deals')}
          variant="outline"
          className="border-[#4A8DB7] text-[#4A8DB7] hover:bg-[#4A8DB7]/10"
        >
          <Plus className="h-4 w-4 mr-1.5" />
          Create from Deal
        </Button>
      </div>

      {/* Desktop table */}
      <div className="hidden md:block bg-white border border-[#E2E4E8] rounded-lg overflow-hidden">
        {jobs.length === 0 ? (
          <div className="p-12 text-center">
            <HardHat className="h-10 w-10 text-gray-300 mx-auto mb-3" />
            <p className="text-sm font-medium text-[#2B2B2B]">No jobs yet</p>
            <p className="text-sm text-gray-400 mt-1">
              Open a signed deal and click "Create Job" to start.
            </p>
            <Button
              className="mt-4 bg-[#4A8DB7] hover:bg-[#4A8DB7]/90 text-white"
              onClick={() => navigate('/abg/portal/deals')}
            >
              View Deals
            </Button>
          </div>
        ) : (
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-[#E2E4E8] bg-[#F5F6F8]">
                <th className="text-left px-4 py-2.5 text-xs font-semibold text-gray-500 uppercase tracking-wide">Job</th>
                <th className="text-left px-4 py-2.5 text-xs font-semibold text-gray-500 uppercase tracking-wide">Client</th>
                <th className="text-left px-4 py-2.5 text-xs font-semibold text-gray-500 uppercase tracking-wide">Address</th>
                <th className="text-left px-4 py-2.5 text-xs font-semibold text-gray-500 uppercase tracking-wide">Status</th>
                <th className="text-left px-4 py-2.5 text-xs font-semibold text-gray-500 uppercase tracking-wide">Created</th>
              </tr>
            </thead>
            <tbody>
              {jobs.map((job, i) => (
                <tr
                  key={job.id}
                  onClick={() => navigate(`/abg/portal/jobs/${job.id}`)}
                  className={cn(
                    'border-b border-[#E2E4E8] cursor-pointer hover:bg-[#4A8DB7]/5 transition-colors',
                    i === jobs.length - 1 ? 'border-b-0' : ''
                  )}
                >
                  <td className="px-4 py-3 font-medium text-[#1A1A1A]">{job.job_name}</td>
                  <td className="px-4 py-3 text-gray-500">{job.client_name}</td>
                  <td className="px-4 py-3 text-gray-500">{job.address ?? '—'}</td>
                  <td className="px-4 py-3"><JobStatusBadge status={job.status} /></td>
                  <td className="px-4 py-3 text-gray-400 text-xs">{timeAgo(job.created_at)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {/* Mobile cards */}
      <div className="md:hidden space-y-2">
        {jobs.length === 0 ? (
          <div className="bg-white border border-[#E2E4E8] rounded-lg p-8 text-center">
            <HardHat className="h-8 w-8 text-gray-300 mx-auto mb-2" />
            <p className="text-sm font-medium text-[#2B2B2B]">No jobs yet</p>
            <p className="text-sm text-gray-400 mt-1">Open a signed deal to create one.</p>
          </div>
        ) : (
          jobs.map((job) => (
            <button
              key={job.id}
              onClick={() => navigate(`/abg/portal/jobs/${job.id}`)}
              className="w-full text-left bg-white border border-[#E2E4E8] rounded-lg p-4"
            >
              <div className="flex items-start justify-between">
                <p className="font-semibold text-[#1A1A1A] text-sm">{job.job_name}</p>
                <JobStatusBadge status={job.status} />
              </div>
              <p className="text-xs text-gray-400 mt-1">{job.client_name} · {job.address ?? 'No address'}</p>
              <p className="text-xs text-gray-300 mt-1">{timeAgo(job.created_at)}</p>
            </button>
          ))
        )}
      </div>
    </ABGShell>
  );
}
