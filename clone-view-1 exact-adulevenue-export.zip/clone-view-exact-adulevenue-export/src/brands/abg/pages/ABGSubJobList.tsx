/**
 * Sub Job List — /abg/subs/jobs
 * Shows only jobs where at least one trade is assigned to this sub.
 * No visibility into other subs, other jobs, or any Wolf Fund data.
 */
import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { useSubAccount } from '../hooks/useSubAccount';
import { HardHat, Loader2, AlertCircle, LogOut } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

interface SubJobSummary {
  job_id: string;
  job_name: string;
  address: string | null;
  job_status: string;
  trade_type: string;
  trade_status: string;
  scope_of_work: string | null;
  trade_id: string;
}

const TRADE_STATUS_COLOR: Record<string, string> = {
  pending:     'bg-gray-100 text-gray-500',
  quoted:      'bg-amber-100 text-amber-700',
  accepted:    'bg-[#4A8DB7]/15 text-[#4A8DB7]',
  in_progress: 'bg-orange-100 text-orange-700',
  completed:   'bg-green-100 text-green-700',
};

export default function ABGSubJobList() {
  const navigate = useNavigate();
  const { subId, loading: accountLoading, error: accountError } = useSubAccount();

  const [jobs, setJobs]     = useState<SubJobSummary[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError]   = useState<string | null>(null);

  useEffect(() => {
    if (accountLoading || !subId) return;

    const load = async () => {
      setLoading(true);
      try {
        // Fetch trades assigned to this sub + their job info
        const { data, error: qErr } = await supabase
          .from('abg_job_trades')
          .select(`
            id,
            trade_type,
            status,
            scope_of_work,
            abg_jobs!inner(id, job_name, address, status)
          `)
          .eq('assigned_sub_id', subId);

        if (qErr) throw new Error(qErr.message);

        const rows: SubJobSummary[] = (data ?? []).map((t: any) => ({
          trade_id:      t.id,
          trade_type:    t.trade_type,
          trade_status:  t.status,
          scope_of_work: t.scope_of_work,
          job_id:        t.abg_jobs.id,
          job_name:      t.abg_jobs.job_name,
          address:       t.abg_jobs.address,
          job_status:    t.abg_jobs.status,
        }));

        setJobs(rows);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Failed to load jobs');
      } finally {
        setLoading(false);
      }
    };

    load();
  }, [subId, accountLoading]);

  const handleSignOut = async () => {
    await supabase.auth.signOut();
    navigate('/abg/subs/login');
  };

  if (accountLoading || loading) {
    return (
      <div className="min-h-screen bg-[#F5F6F8] flex items-center justify-center">
        <Loader2 className="h-6 w-6 animate-spin text-[#4A8DB7]" />
      </div>
    );
  }

  if (accountError || error) {
    return (
      <div className="min-h-screen bg-[#F5F6F8] flex items-center justify-center px-4">
        <div className="flex items-center gap-2 text-red-600 bg-red-50 border border-red-200 rounded-lg p-4 max-w-sm w-full">
          <AlertCircle className="h-4 w-4 shrink-0" />
          {accountError ?? error}
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#F5F6F8]">
      {/* Header */}
      <header className="bg-[#2B2B2B] text-white h-14 flex items-center px-4 sticky top-0 z-50">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded bg-[#4A8DB7] flex items-center justify-center">
            <HardHat className="h-4 w-4 text-white" />
          </div>
          <span className="font-semibold text-sm tracking-wide">ABG Sub Portal</span>
        </div>
        <button
          onClick={handleSignOut}
          className="ml-auto flex items-center gap-1 text-gray-400 hover:text-white text-sm px-2 py-1 rounded hover:bg-white/10 transition-colors"
        >
          <LogOut className="h-3.5 w-3.5" />
          Sign out
        </button>
      </header>

      <main className="max-w-2xl mx-auto px-4 py-6">
        <h1 className="text-xl font-bold text-[#2B2B2B] mb-1">Your Assigned Trades</h1>
        <p className="text-sm text-gray-400 mb-5">
          {jobs.length} trade{jobs.length !== 1 ? 's' : ''} assigned to you
        </p>

        {jobs.length === 0 ? (
          <div className="bg-white border border-[#E2E4E8] rounded-xl p-10 text-center">
            <HardHat className="h-10 w-10 text-gray-300 mx-auto mb-3" />
            <p className="text-sm font-medium text-[#2B2B2B]">No trades assigned yet</p>
            <p className="text-sm text-gray-400 mt-1">Check back when ABG assigns work to you.</p>
          </div>
        ) : (
          <div className="space-y-3">
            {jobs.map((job) => (
              <button
                key={job.trade_id}
                onClick={() => navigate(`/abg/subs/jobs/${job.job_id}?trade=${job.trade_id}`)}
                className="w-full text-left bg-white border border-[#E2E4E8] rounded-xl p-4 hover:border-[#4A8DB7]/50 transition-colors"
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="flex-1 min-w-0">
                    <p className="font-semibold text-[#1A1A1A] text-sm">{job.job_name}</p>
                    {job.address && (
                      <p className="text-xs text-gray-400 mt-0.5 truncate">{job.address}</p>
                    )}
                  </div>
                  <span className={cn(
                    'inline-flex items-center px-2 py-0.5 rounded text-xs font-medium shrink-0 capitalize',
                    TRADE_STATUS_COLOR[job.trade_status] ?? 'bg-gray-100 text-gray-500'
                  )}>
                    {job.trade_status.replace('_', ' ')}
                  </span>
                </div>
                <div className="mt-2 flex items-center gap-2">
                  <span className="text-xs bg-[#2B2B2B] text-white px-2 py-0.5 rounded capitalize">
                    {job.trade_type}
                  </span>
                  {job.scope_of_work && (
                    <span className="text-xs text-gray-400 truncate">{job.scope_of_work}</span>
                  )}
                </div>
              </button>
            ))}
          </div>
        )}
      </main>
    </div>
  );
}
