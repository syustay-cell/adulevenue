import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { useABGTenant } from '../hooks/useABGTenant';
import { ABGShell } from '../components/ABGShell';
import { SourceBadge, actionTypeLabel } from '../components/ABGBadges';
import { timeAgo, formatDateTime } from '../lib/time';
import type { ABGTodayWorkItem, ABGLead } from '../types';
import { Loader2, AlertCircle, Zap, Phone } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

// ─── Data sources — all queries map to DB tables/views exactly ────────────────

// Source: abg_today_work view (JOIN of abg_next_actions + wf_leads/abg_deals)
// Returns urgency, entity_name, deal_lead_id resolved server-side in the view.
async function fetchTodayWork(tenantId: string): Promise<ABGTodayWorkItem[]> {
  const { data, error } = await supabase
    .from('abg_today_work')
    .select('*')
    .eq('tenant_id', tenantId);

  if (error) throw new Error(error.message);
  return (data ?? []) as ABGTodayWorkItem[];
}

// Source: wf_leads — new leads with no last_touch_at older than 10 minutes
async function fetchUntouchedLeads(tenantId: string): Promise<ABGLead[]> {
  const cutoff = new Date(Date.now() - 10 * 60 * 1000).toISOString();
  const { data } = await supabase
    .from('wf_leads')
    .select('*')
    .eq('tenant_id', tenantId)
    .eq('status', 'new')
    .is('last_touch_at', null)
    .lte('created_at', cutoff)
    .order('created_at', { ascending: false });
  return (data ?? []) as ABGLead[];
}

// Source: abg_activity — count of distinct lead events today per actor
interface MomentumScore {
  calls: number;
  texts: number;
  emails: number;
  deals_moved: number;
  total: number;
}

async function fetchMomentum(tenantId: string, userId: string): Promise<MomentumScore> {
  const todayStart = new Date();
  todayStart.setHours(0, 0, 0, 0);

  const { data } = await supabase
    .from('abg_activity')
    .select('event_type')
    .eq('tenant_id', tenantId)
    .eq('actor_id', userId)
    .gte('created_at', todayStart.toISOString());

  const events = data ?? [];
  const calls       = events.filter((e) => e.event_type === 'call_logged').length;
  const texts       = events.filter((e) => e.event_type === 'text_sent').length;
  const emails      = events.filter((e) => e.event_type === 'email_sent').length;
  const deals_moved = events.filter((e) => e.event_type === 'stage_changed').length;
  return { calls, texts, emails, deals_moved, total: calls + texts + emails + deals_moved };
}

// Source: abg_activity — count of unique leads touched today (any event type)
async function fetchTouchedTodayCount(tenantId: string): Promise<number> {
  const todayStart = new Date();
  todayStart.setHours(0, 0, 0, 0);
  const { count } = await supabase
    .from('abg_activity')
    .select('entity_id', { count: 'exact', head: true })
    .eq('tenant_id', tenantId)
    .eq('entity_type', 'lead')
    .gte('created_at', todayStart.toISOString());
  return count ?? 0;
}

// ─── Component ────────────────────────────────────────────────────────────────

export default function ABGTodaysWork() {
  const navigate = useNavigate();

  const { tenantId: currentTenantId, loading: tenantLoading } = useABGTenant();
  const [workItems, setWorkItems]       = useState<ABGTodayWorkItem[]>([]);
  const [untouched, setUntouched]       = useState<ABGLead[]>([]);
  const [touchedCount, setTouchedCount] = useState(0);
  const [momentum, setMomentum]         = useState<MomentumScore | null>(null);
  const [loading, setLoading]           = useState(true);
  const [error, setError]               = useState<string | null>(null);

  useEffect(() => {
    // Wait for tenant to finish loading
    if (tenantLoading) return;
    // Tenant loaded but no membership found — stop spinner, show empty state
    if (!currentTenantId) {
      setLoading(false);
      return;
    }

    const load = async () => {
      setLoading(true);
      try {
        const { data: { user } } = await supabase.auth.getUser();
        const userId = user?.id ?? '';

        const [work, untouch, touched, mom] = await Promise.all([
          fetchTodayWork(currentTenantId),       // abg_today_work view
          fetchUntouchedLeads(currentTenantId),  // wf_leads
          fetchTouchedTodayCount(currentTenantId), // abg_activity
          fetchMomentum(currentTenantId, userId),  // abg_activity
        ]);

        setWorkItems(work);
        setUntouched(untouch);
        setTouchedCount(touched);
        setMomentum(mom);
      } catch (e) {
        setError(e instanceof Error ? e.message : 'Failed to load');
      } finally {
        setLoading(false);
      }
    };

    load();
  }, [currentTenantId, tenantLoading]);

  // view returns urgency already — filter client-side only for section grouping
  const overdue  = workItems.filter((i) => i.urgency === 'overdue');
  const dueToday = workItems.filter((i) => i.urgency === 'due_today');

  // Navigation: entity_name and deal_lead_id come from the view — no resolution needed
  const goToEntity = (item: ABGTodayWorkItem) => {
    if (item.entity_type === 'lead') navigate(`/abg/portal/leads/${item.entity_id}`);
    if (item.entity_type === 'deal') navigate(`/abg/portal/deals/${item.entity_id}`);
  };

  if (loading) {
    return (
      <ABGShell>
        <div className="flex items-center justify-center h-64 gap-2 text-muted-foreground">
          <Loader2 className="h-5 w-5 animate-spin" />
          Loading today's work…
        </div>
      </ABGShell>
    );
  }

  if (error) {
    return (
      <ABGShell>
        <div className="flex items-center gap-2 text-red-600 bg-red-50 border border-red-200 rounded-lg p-4">
          <AlertCircle className="h-4 w-4 shrink-0" />
          {error}
        </div>
      </ABGShell>
    );
  }

  return (
    <ABGShell>
      {/* Header + Momentum */}
      <div className="flex items-start justify-between mb-5">
        <div>
          <h1 className="text-2xl font-bold text-[#2B2B2B]">Today's Work</h1>
          <p className="text-sm text-gray-400 mt-0.5">
            {new Date().toLocaleDateString('en-US', {
              weekday: 'long', month: 'long', day: 'numeric',
            })}
          </p>
        </div>

        {momentum && (
          <div className="hidden md:flex items-center gap-2 bg-white border border-[#E2E4E8] rounded-lg px-4 py-2">
            <Zap className="h-4 w-4 text-[#4A8DB7]" />
            <div className="text-sm">
              <span className="font-semibold text-[#2B2B2B]">{momentum.total}</span>
              <span className="text-gray-400 ml-1">momentum today</span>
            </div>
            <div className="text-xs text-gray-400 hidden lg:flex gap-2 ml-2 pl-2 border-l border-[#E2E4E8]">
              <span>📞 {momentum.calls}</span>
              <span>💬 {momentum.texts}</span>
              <span>📧 {momentum.emails}</span>
              <span>🏗️ {momentum.deals_moved}</span>
            </div>
          </div>
        )}
      </div>

      <div className="space-y-4">

        {/* Untouched leads (source: wf_leads) */}
        {untouched.length > 0 && (
          <WorkSection
            label={`🚨 UNTOUCHED (${untouched.length})`}
            labelClass="text-red-600"
            borderClass="border-red-200"
          >
            {untouched.map((lead) => (
              <WorkRow
                key={lead.id}
                name={[lead.first_name, lead.last_name].filter(Boolean).join(' ') || 'Lead'}
                actionLabel="New lead — no contact yet"
                meta={`${timeAgo(lead.created_at)} ago`}
                urgency="overdue"
                onOpen={() => navigate(`/abg/portal/leads/${lead.id}`)}
                callNow
              >
                <SourceBadge source={lead.source} />
              </WorkRow>
            ))}
          </WorkSection>
        )}

        {/* Overdue (source: abg_today_work view — urgency='overdue') */}
        {overdue.length > 0 && (
          <WorkSection
            label={`🔴 OVERDUE (${overdue.length})`}
            labelClass="text-red-600"
            borderClass="border-red-200"
          >
            {overdue.map((item) => (
              <WorkRow
                key={item.next_action_id}
                name={item.entity_name}
                actionLabel={actionTypeLabel(item.action_type, item.custom_label)}
                meta={`${timeAgo(item.due_at)} late`}
                urgency="overdue"
                entityType={item.entity_type}
                isManual={item.source === 'manual'}
                onOpen={() => goToEntity(item)}
              />
            ))}
          </WorkSection>
        )}

        {/* Due today (source: abg_today_work view — urgency='due_today') */}
        {dueToday.length > 0 && (
          <WorkSection
            label={`🟡 DUE TODAY (${dueToday.length})`}
            labelClass="text-amber-600"
            borderClass="border-amber-200"
          >
            {dueToday.map((item) => (
              <WorkRow
                key={item.next_action_id}
                name={item.entity_name}
                actionLabel={actionTypeLabel(item.action_type, item.custom_label)}
                meta={formatDateTime(item.due_at)}
                urgency="due_today"
                entityType={item.entity_type}
                isManual={item.source === 'manual'}
                onOpen={() => goToEntity(item)}
              />
            ))}
          </WorkSection>
        )}

        {/* Touched today (source: abg_activity) */}
        <div className="bg-white border border-[#E2E4E8] rounded-lg px-4 py-3">
          <p className="text-sm text-gray-500">
            🟢 <span className="font-medium text-[#2B2B2B]">{touchedCount}</span> leads touched today
          </p>
        </div>

        {/* Empty state */}
        {untouched.length === 0 && overdue.length === 0 && dueToday.length === 0 && (
          <div className="bg-white border border-[#E2E4E8] rounded-lg p-12 text-center">
            <p className="text-2xl mb-2">✅</p>
            <p className="text-sm font-medium text-[#2B2B2B]">You're all caught up</p>
            <p className="text-sm text-gray-400 mt-1">
              No overdue actions or new untouched leads.
            </p>
            <Button
              className="mt-4 bg-[#4A8DB7] hover:bg-[#4A8DB7]/90 text-white"
              onClick={() => navigate('/abg/portal/leads')}
            >
              View All Leads
            </Button>
          </div>
        )}
      </div>
    </ABGShell>
  );
}

// ─── Sub-components ───────────────────────────────────────────────────────────

function WorkSection({
  label, labelClass, borderClass, children,
}: {
  label: string;
  labelClass: string;
  borderClass: string;
  children: React.ReactNode;
}) {
  return (
    <div className={cn('bg-white border rounded-lg overflow-hidden', borderClass)}>
      <p className={cn(
        'text-xs font-bold uppercase tracking-wide px-4 py-2 border-b',
        borderClass, labelClass,
      )}>
        {label}
      </p>
      <div className="divide-y divide-[#E2E4E8]">{children}</div>
    </div>
  );
}

function WorkRow({
  name, actionLabel, meta, urgency, entityType, isManual, onOpen, callNow, children,
}: {
  name: string;
  actionLabel: string;
  meta: string;
  urgency: 'overdue' | 'due_today';
  entityType?: string;
  isManual?: boolean;
  onOpen: () => void;
  callNow?: boolean;
  children?: React.ReactNode;
}) {
  return (
    <div className="flex items-center justify-between px-4 py-3 gap-4">
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2 flex-wrap">
          <span className="font-medium text-[#1A1A1A] text-sm truncate">{name}</span>
          {children}
          {entityType && (
            <span className="text-xs text-gray-400 capitalize">{entityType}</span>
          )}
          {isManual && (
            <span className="text-[10px] px-1.5 py-0.5 rounded bg-gray-100 text-gray-400 font-medium uppercase tracking-wide">
              Manual
            </span>
          )}
        </div>
        <div className="flex items-center gap-2 mt-0.5">
          <span className="text-xs text-[#4A8DB7] font-medium">{actionLabel}</span>
          <span className="text-xs text-gray-400">·</span>
          <span className={cn(
            'text-xs font-medium',
            urgency === 'overdue' ? 'text-red-500' : 'text-amber-600',
          )}>
            {meta}
          </span>
        </div>
      </div>
      <Button
        size="sm"
        onClick={onOpen}
        className={cn(
          'shrink-0 text-white',
          callNow ? 'bg-red-600 hover:bg-red-700' : 'bg-[#4A8DB7] hover:bg-[#4A8DB7]/90',
        )}
      >
        {callNow && <Phone className="h-3.5 w-3.5 mr-1" />}
        {callNow ? 'Call Now' : 'Open'}
      </Button>
    </div>
  );
}
