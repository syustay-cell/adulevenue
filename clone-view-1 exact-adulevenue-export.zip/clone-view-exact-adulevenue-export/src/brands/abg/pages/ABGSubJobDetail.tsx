/**
 * Sub Job Detail — /abg/subs/jobs/:jobId?trade=:tradeId
 * Sub sees their assigned trade for a job and submits a quote.
 * No other trades, no other subs, no pricing history from other vendors.
 */
import { useEffect, useState } from 'react';
import { useParams, useSearchParams, useNavigate } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { useSubAccount } from '../hooks/useSubAccount';
import { formatCurrency } from '../lib/time';
import type { ABGJob, ABGJobTrade, ABGSubQuote } from '../types';
import {
  ChevronLeft, HardHat, Loader2, AlertCircle, Send, LogOut,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { cn } from '@/lib/utils';

const QUOTE_STATUS_CONFIG = {
  submitted: { label: 'Submitted — awaiting review', className: 'bg-amber-50 text-amber-700 border-amber-200' },
  accepted:  { label: 'Accepted ✓',                  className: 'bg-green-50 text-green-700 border-green-200' },
  rejected:  { label: 'Not selected',                className: 'bg-gray-50 text-gray-500 border-gray-200' },
};

export default function ABGSubJobDetail() {
  const { jobId }               = useParams<{ jobId: string }>();
  const [searchParams]          = useSearchParams();
  const tradeId                 = searchParams.get('trade');
  const navigate                = useNavigate();
  const { subId, tenantId, loading: accountLoading } = useSubAccount();

  const [job, setJob]           = useState<ABGJob | null>(null);
  const [trade, setTrade]       = useState<ABGJobTrade | null>(null);
  const [quotes, setQuotes]     = useState<ABGSubQuote[]>([]);
  const [loading, setLoading]   = useState(true);
  const [error, setError]       = useState<string | null>(null);

  // Quote form
  const [price, setPrice]       = useState('');
  const [notes, setNotes]       = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted]   = useState(false);

  useEffect(() => {
    if (accountLoading || !subId || !jobId || !tradeId) return;

    const load = async () => {
      setLoading(true);
      try {
        const [jobRes, tradeRes, quotesRes] = await Promise.all([
          supabase.from('abg_jobs').select('*').eq('id', jobId).single(),
          supabase.from('abg_job_trades').select('*')
            .eq('id', tradeId)
            .eq('assigned_sub_id', subId) // RLS + explicit check
            .single(),
          supabase.from('abg_sub_quotes').select('*')
            .eq('trade_id', tradeId)
            .eq('sub_id', subId)
            .order('submitted_at', { ascending: false }),
        ]);

        if (jobRes.error) throw new Error('Job not found');
        if (tradeRes.error) throw new Error('Trade not assigned to you');

        setJob(jobRes.data as ABGJob);
        setTrade(tradeRes.data as ABGJobTrade);
        setQuotes((quotesRes.data ?? []) as ABGSubQuote[]);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Failed to load');
      } finally {
        setLoading(false);
      }
    };

    load();
  }, [subId, tenantId, jobId, tradeId, accountLoading]);

  const handleSubmitQuote = async () => {
    if (!subId || !tenantId || !trade || !job || !price) return;
    setSubmitting(true);
    try {
      const { error: insertError } = await supabase.from('abg_sub_quotes').insert({
        tenant_id:    tenantId,
        job_id:       job.id,
        trade_id:     trade.id,
        sub_id:       subId,
        quoted_price: parseFloat(price),
        notes:        notes.trim() || null,
        status:       'submitted',
      });

      if (insertError) throw new Error(insertError.message);

      // Reload quotes and trade status
      const [newQuotes, newTrade] = await Promise.all([
        supabase.from('abg_sub_quotes').select('*')
          .eq('trade_id', trade.id).eq('sub_id', subId)
          .order('submitted_at', { ascending: false }),
        supabase.from('abg_job_trades').select('*').eq('id', trade.id).single(),
      ]);

      setQuotes((newQuotes.data ?? []) as ABGSubQuote[]);
      if (newTrade.data) setTrade(newTrade.data as ABGJobTrade);
      setPrice('');
      setNotes('');
      setSubmitted(true);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to submit quote');
    } finally {
      setSubmitting(false);
    }
  };

  const handleSignOut = async () => {
    await supabase.auth.signOut();
    navigate('/abg/subs/login');
  };

  if (accountLoading || loading) {
    return (
      <div className="min-h-screen bg-[#F5F6F8] flex items-center justify-center">
        <Loader2 className="h-6 w-6 animate-spin text-[#4A8DB7]" />
      </div>
    );
  }

  if (error || !job || !trade) {
    return (
      <div className="min-h-screen bg-[#F5F6F8] flex items-center justify-center px-4">
        <div className="flex items-center gap-2 text-red-600 bg-red-50 border border-red-200 rounded-lg p-4 max-w-sm w-full">
          <AlertCircle className="h-4 w-4 shrink-0" />
          {error ?? 'Trade not found'}
        </div>
      </div>
    );
  }

  const hasAcceptedQuote = quotes.some((q) => q.status === 'accepted');
  const canSubmit = !hasAcceptedQuote && trade.status !== 'accepted' && trade.status !== 'completed';

  return (
    <div className="min-h-screen bg-[#F5F6F8]">
      {/* Header */}
      <header className="bg-[#2B2B2B] text-white h-14 flex items-center px-4 sticky top-0 z-50">
        <button
          onClick={() => navigate('/abg/subs/jobs')}
          className="flex items-center gap-1 text-gray-400 hover:text-white text-sm mr-3 transition-colors"
        >
          <ChevronLeft className="h-4 w-4" />
        </button>
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded bg-[#4A8DB7] flex items-center justify-center">
            <HardHat className="h-4 w-4 text-white" />
          </div>
          <span className="font-semibold text-sm tracking-wide truncate">ABG Sub Portal</span>
        </div>
        <button
          onClick={handleSignOut}
          className="ml-auto text-gray-400 hover:text-white p-1 transition-colors"
        >
          <LogOut className="h-4 w-4" />
        </button>
      </header>

      <main className="max-w-xl mx-auto px-4 py-6 space-y-4">

        {/* Job info */}
        <div className="bg-white border border-[#E2E4E8] rounded-xl p-4">
          <p className="text-xs text-gray-400 uppercase tracking-wide mb-1">Job</p>
          <p className="font-bold text-[#1A1A1A]">{job.job_name}</p>
          {job.address && <p className="text-sm text-gray-400 mt-0.5">{job.address}</p>}
        </div>

        {/* Trade info */}
        <div className="bg-white border border-[#E2E4E8] rounded-xl p-4 space-y-3">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs text-gray-400 uppercase tracking-wide mb-0.5">Your Trade</p>
              <p className="font-bold text-[#1A1A1A] capitalize">{trade.trade_type}</p>
            </div>
            <span className={cn(
              'text-xs font-medium px-2 py-1 rounded capitalize border',
              {
                pending:     'bg-gray-100 text-gray-500 border-gray-200',
                quoted:      'bg-amber-100 text-amber-700 border-amber-200',
                accepted:    'bg-green-100 text-green-700 border-green-200',
                in_progress: 'bg-orange-100 text-orange-700 border-orange-200',
                completed:   'bg-green-100 text-green-700 border-green-200',
              }[trade.status] ?? 'bg-gray-100 text-gray-500 border-gray-200'
            )}>
              {trade.status.replace('_', ' ')}
            </span>
          </div>
          {trade.scope_of_work && (
            <div>
              <p className="text-xs text-gray-400 uppercase tracking-wide mb-1">Scope of Work</p>
              <p className="text-sm text-[#1A1A1A] leading-relaxed">{trade.scope_of_work}</p>
            </div>
          )}
          {trade.agreed_price && (
            <div className="bg-green-50 border border-green-200 rounded-lg p-3">
              <p className="text-xs text-green-600 font-semibold">Agreed Price</p>
              <p className="text-lg font-bold text-green-700 mt-0.5">{formatCurrency(trade.agreed_price)}</p>
            </div>
          )}
        </div>

        {/* Submit quote */}
        {canSubmit ? (
          <div className="bg-white border border-[#E2E4E8] rounded-xl p-4 space-y-3">
            <p className="font-semibold text-[#2B2B2B] text-sm">Submit Your Quote</p>

            {submitted && (
              <div className="bg-green-50 border border-green-200 rounded-lg p-3 text-sm text-green-700">
                Quote submitted. ABG will review and respond.
              </div>
            )}

            <div>
              <Label className="text-xs text-gray-400 uppercase tracking-wide mb-1 block">Your Price</Label>
              <div className="relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 text-sm">$</span>
                <Input
                  type="number"
                  value={price}
                  onChange={(e) => setPrice(e.target.value)}
                  placeholder="Enter your price"
                  className="pl-7"
                />
              </div>
            </div>
            <div>
              <Label className="text-xs text-gray-400 uppercase tracking-wide mb-1 block">
                Notes (optional)
              </Label>
              <Textarea
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Any conditions, timeline, or scope notes..."
                rows={3}
                className="text-sm resize-none"
              />
            </div>
            <Button
              onClick={handleSubmitQuote}
              disabled={submitting || !price}
              className="w-full bg-[#2B2B2B] hover:bg-[#4A8DB7] text-white"
            >
              {submitting
                ? <Loader2 className="h-4 w-4 animate-spin mr-2" />
                : <Send className="h-4 w-4 mr-2" />}
              Submit Quote
            </Button>
          </div>
        ) : hasAcceptedQuote ? (
          <div className="bg-green-50 border border-green-200 rounded-xl p-4 text-center">
            <p className="text-sm font-semibold text-green-700">Your quote was accepted</p>
            <p className="text-xs text-green-600 mt-1">ABG will be in touch with next steps.</p>
          </div>
        ) : null}

        {/* Quote history — sub sees only their own */}
        {quotes.length > 0 && (
          <div className="bg-white border border-[#E2E4E8] rounded-xl p-4">
            <p className="font-semibold text-[#2B2B2B] text-sm mb-3">Your Quote History</p>
            <div className="space-y-2">
              {quotes.map((q) => {
                const cfg = QUOTE_STATUS_CONFIG[q.status] ?? QUOTE_STATUS_CONFIG.submitted;
                return (
                  <div key={q.id} className={cn('border rounded-lg p-3', cfg.className)}>
                    <div className="flex items-center justify-between">
                      <p className="font-semibold text-sm">{formatCurrency(q.quoted_price)}</p>
                      <p className="text-xs">{cfg.label}</p>
                    </div>
                    {q.notes && <p className="text-xs mt-1 opacity-80">{q.notes}</p>}
                    <p className="text-xs opacity-60 mt-1">
                      {new Date(q.submitted_at).toLocaleString()}
                    </p>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
