import { useEffect, useState, useCallback } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { useABGTenant } from '../hooks/useABGTenant';
import { ABGShell } from '../components/ABGShell';
import { InlineNextAction } from '../components/InlineNextAction';
import { PreliminaryBudgetModal } from '../components/PreliminaryBudgetModal';
import {
  StageBadge, FinancingBadge, actionTypeLabel,
} from '../components/ABGBadges';
import { timeAgo, formatDateTime, formatDate, formatCurrency, daysInStage, velocityStatus } from '../lib/time';
import type {
  ABGDeal, ABGLead, ABGActivity, ABGNote, ABGNextAction,
  DealStage, FinancingStatus, ActivityEventType,
  ABGLane, FundingPrecheckStatus, ContractStatus,
} from '../types';
import {
  ChevronLeft, ChevronRight, Clock, CheckCircle2,
  Loader2, AlertCircle, Edit2, PauseCircle, XCircle,
  ExternalLink, HardHat, Calculator,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle,
} from '@/components/ui/dialog';
import { cn } from '@/lib/utils';

// ─── Stage order ──────────────────────────────────────────────────────────────

const STAGE_ORDER: DealStage[] = [
  'active', 'proposal', 'signed', 'permit', 'build', 'complete',
];

function prevStage(stage: DealStage): DealStage | null {
  const idx = STAGE_ORDER.indexOf(stage);
  return idx > 0 ? STAGE_ORDER[idx - 1] : null;
}

function nextStage(stage: DealStage): DealStage | null {
  const idx = STAGE_ORDER.indexOf(stage);
  return idx >= 0 && idx < STAGE_ORDER.length - 1 ? STAGE_ORDER[idx + 1] : null;
}

// ─── Activity helper ──────────────────────────────────────────────────────────

function eventLabel(eventType: string, oldVal?: string | null, newVal?: string | null): string {
  const map: Record<string, string> = {
    deal_created:              'Deal created',
    stage_changed:             `Stage: ${oldVal} → ${newVal}`,
    project_value_set:         `Project value set: ${newVal}`,
    estimated_profit_set:      `Estimated profit set: ${newVal}`,
    financing_status_changed:  `Financing: ${oldVal} → ${newVal}`,
    note_added:                'Note added',
    next_action_set:           'Next action set',
    next_action_completed:     'Next action completed',
    call_logged:               'Call logged',
    text_sent:                 'Text sent (log only)',
    email_sent:                'Email sent (log only)',
    wolf_fund_handoff_triggered: 'Routed to Wolf Fund',
    wolf_fund_handoff_failed:  'Wolf Fund handoff failed',
    ownership_changed:         'Ownership changed',
  };
  return map[eventType] ?? eventType;
}

async function logActivity(
  tenantId: string,
  dealId: string,
  eventType: ActivityEventType,
  payload: {
    oldValue?: string | null;
    newValue?: string | null;
    note?: string | null;
    correlationId?: string | null;
    relatedEntityType?: 'lead' | 'deal' | null;
    relatedEntityId?: string | null;
    meta?: Record<string, unknown>;
  },
) {
  const { data: { user } } = await supabase.auth.getUser();
  await supabase.from('abg_activity').insert({
    tenant_id:           tenantId,
    entity_type:         'deal',
    entity_id:           dealId,
    actor_id:            user?.id ?? null,
    actor_type:          'worker',
    event_type:          eventType,
    old_value:           payload.oldValue ?? null,
    new_value:           payload.newValue ?? null,
    note:                payload.note ?? null,
    correlation_id:      payload.correlationId ?? null,
    related_entity_type: payload.relatedEntityType ?? null,
    related_entity_id:   payload.relatedEntityId ?? null,
    meta:                payload.meta ?? {},
  });
}

// ─── Section card ─────────────────────────────────────────────────────────────

function SectionCard({ title, children, className }: {
  title?: string;
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <div className={cn('bg-white border border-[#E2E4E8] rounded-lg p-4', className)}>
      {title && <h3 className="text-sm font-semibold text-[#2B2B2B] mb-3">{title}</h3>}
      {children}
    </div>
  );
}

function Field({ label, value }: { label: string; value: React.ReactNode }) {
  return (
    <div>
      <p className="text-xs text-gray-400 uppercase tracking-wide mb-0.5">{label}</p>
      <p className="text-sm text-[#1A1A1A] font-medium">{value ?? '—'}</p>
    </div>
  );
}

// ─── Create Job Button ────────────────────────────────────────────────────────

function CreateJobButton({
  dealId, tenantId, onCreated,
}: {
  dealId: string;
  tenantId: string | null;
  onCreated: (jobId: string) => void;
}) {
  const [open, setOpen] = useState(false);
  const [budgetOpen, setBudgetOpen] = useState(false);
  const [jobName, setJobName] = useState('');
  const [address, setAddress] = useState('');
  const [creating, setCreating] = useState(false);

  // Check if a job already exists for this deal
  const [hasJob, setHasJob] = useState(false);
  const [existingJobId, setExistingJobId] = useState<string | null>(null);
  const [existingTradeTypes, setExistingTradeTypes] = useState<string[]>([]);

  useEffect(() => {
    if (!dealId) return;
    supabase.from('abg_jobs').select('id').eq('deal_id', dealId).maybeSingle().then(({ data }) => {
      if (data) {
        setHasJob(true);
        setExistingJobId(data.id);
        // Load existing trade types so budget modal can skip them
        supabase.from('abg_job_trades').select('trade_type').eq('job_id', data.id).then(({ data: trades }) => {
          setExistingTradeTypes((trades ?? []).map((t: { trade_type: string }) => t.trade_type));
        });
      }
    });
  }, [dealId]);

  const navigate = useNavigate();

  const handleCreate = async () => {
    if (!tenantId || !jobName.trim()) return;
    setCreating(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      const { data } = await supabase.from('abg_jobs').insert({
        tenant_id: tenantId,
        deal_id: dealId,
        job_name: jobName.trim(),
        address: address.trim() || null,
        status: 'planning',
        created_by: user?.id ?? null,
      }).select().single();
      if (data) { setOpen(false); onCreated(data.id); }
    } finally {
      setCreating(false);
    }
  };

  if (hasJob && existingJobId) {
    return (
      <div className="flex gap-2">
        <Button
          variant="outline"
          onClick={() => navigate(`/abg/portal/jobs/${existingJobId}`)}
          className="border-green-200 text-green-700 hover:bg-green-50"
        >
          <HardHat className="h-3.5 w-3.5 mr-1.5" />
          View Job
        </Button>
        <Button
          variant="outline"
          onClick={() => setBudgetOpen(true)}
          className="border-[#4A8DB7] text-[#4A8DB7] hover:bg-[#4A8DB7]/10"
        >
          <Calculator className="h-3.5 w-3.5 mr-1.5" />
          Generate Budget
        </Button>
        {tenantId && (
          <PreliminaryBudgetModal
            open={budgetOpen}
            onOpenChange={setBudgetOpen}
            jobId={existingJobId}
            tenantId={tenantId}
            existingTradeTypes={existingTradeTypes}
            onSaved={() => navigate(`/abg/portal/jobs/${existingJobId}`)}
          />
        )}
      </div>
    );
  }

  return (
    <>
      <Button
        onClick={() => setOpen(true)}
        className="bg-[#2B2B2B] hover:bg-[#4A8DB7] text-white"
      >
        <HardHat className="h-3.5 w-3.5 mr-1.5" />
        Create Job
      </Button>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>Create Job</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <p className="text-sm text-gray-500">
              This deal is signed. Create a job to start assigning trades and subcontractors.
            </p>
            <div>
              <Label>Job Name</Label>
              <Input
                value={jobName}
                onChange={(e) => setJobName(e.target.value)}
                placeholder="e.g. ADU Build — 4421 Oleander Dr"
                className="text-sm"
              />
            </div>
            <div>
              <Label>Address (optional)</Label>
              <Input
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                placeholder="Site address"
                className="text-sm"
              />
            </div>
            <Button
              onClick={handleCreate}
              disabled={creating || !jobName.trim()}
              className="w-full bg-[#2B2B2B] hover:bg-[#4A8DB7] text-white"
            >
              {creating ? <Loader2 className="h-4 w-4 animate-spin mr-1" /> : null}
              Create Job
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}

// ─── Main component ───────────────────────────────────────────────────────────

export default function ABGDealDetail() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { tenantId: currentTenantId } = useABGTenant();

  const [deal, setDeal]           = useState<ABGDeal | null>(null);
  const [lead, setLead]           = useState<ABGLead | null>(null);
  const [activity, setActivity]   = useState<ABGActivity[]>([]);
  const [notes, setNotes]         = useState<ABGNote[]>([]);
  const [nextAction, setNextAction] = useState<ABGNextAction | null>(null);
  const [loading, setLoading]     = useState(true);
  const [error, setError]         = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'activity' | 'notes'>('activity');

  // Edit modals
  const [valueModal, setValueModal]   = useState(false);
  const [profitModal, setProfitModal] = useState(false);
  const [holdModal, setHoldModal]     = useState(false);
  const [cancelModal, setCancelModal] = useState(false);
  const [updateModal, setUpdateModal] = useState(false);
  const [newNote, setNewNote]         = useState('');
  const [holdReason, setHoldReason]   = useState('');
  const [cancelReason, setCancelReason] = useState('');
  const [editValue, setEditValue]     = useState('');
  const [editProfit, setEditProfit]   = useState('');
  const [updateNote, setUpdateNote]   = useState('');
  const [savingNote, setSavingNote]   = useState(false);
  const [submitting, setSubmitting]   = useState(false);

  const loadData = useCallback(async () => {
    if (!id || !currentTenantId) return;
    setLoading(true);
    try {
      const [dealRes, activityRes, notesRes, naRes] = await Promise.all([
        supabase.from('abg_deals').select('*').eq('id', id).eq('tenant_id', currentTenantId).single(),
        supabase.from('abg_activity').select('*').eq('entity_type', 'deal').eq('entity_id', id).order('created_at', { ascending: false }),
        supabase.from('abg_notes').select('*').eq('entity_type', 'deal').eq('entity_id', id).order('created_at', { ascending: false }),
        supabase.from('abg_next_actions').select('*').eq('entity_type', 'deal').eq('entity_id', id).eq('status', 'active').maybeSingle(),
      ]);

      if (dealRes.error) throw new Error(dealRes.error.message);
      const dealData = dealRes.data as ABGDeal;
      setDeal(dealData);
      setActivity((activityRes.data ?? []) as ABGActivity[]);
      setNotes((notesRes.data ?? []) as ABGNote[]);
      setNextAction(naRes.data as ABGNextAction | null);

      // Fetch linked lead
      const { data: leadData } = await supabase
        .from('wf_leads')
        .select('*')
        .eq('id', dealData.lead_id)
        .single();
      setLead(leadData as ABGLead | null);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Failed to load deal');
    } finally {
      setLoading(false);
    }
  }, [id, currentTenantId]);

  useEffect(() => { loadData(); }, [loadData]);

  // ── Stage movement ─────────────────────────────────────────────────────────

  const moveStage = async (newStage: DealStage, reason?: string) => {
    if (!deal || !currentTenantId) return;
    setSubmitting(true);
    try {
      const oldStage = deal.stage;
      const update: Partial<ABGDeal> & { updated_at: string } = {
        stage: newStage,
        updated_at: new Date().toISOString(),
      };
      if (newStage === 'on_hold')   update.on_hold_reason  = reason ?? null;
      if (newStage === 'cancelled') update.cancelled_reason = reason ?? null;

      await supabase.from('abg_deals').update(update).eq('id', deal.id);
      await logActivity(currentTenantId, deal.id, 'stage_changed', {
        oldValue: oldStage,
        newValue: newStage,
        note: reason ?? null,
      });
      setHoldModal(false);
      setCancelModal(false);
      await loadData();
    } finally {
      setSubmitting(false);
    }
  };

  // ── Money edits ────────────────────────────────────────────────────────────

  const saveProjectValue = async () => {
    if (!deal || !currentTenantId || !editValue) return;
    setSubmitting(true);
    try {
      const val = parseFloat(editValue);
      await supabase.from('abg_deals').update({ project_value: val, updated_at: new Date().toISOString() }).eq('id', deal.id);
      await logActivity(currentTenantId, deal.id, 'project_value_set', {
        oldValue: deal.project_value ? String(deal.project_value) : null,
        newValue: formatCurrency(val),
      });
      setValueModal(false);
      await loadData();
    } finally {
      setSubmitting(false);
    }
  };

  const saveEstimatedProfit = async () => {
    if (!deal || !currentTenantId || !editProfit) return;
    setSubmitting(true);
    try {
      const val = parseFloat(editProfit);
      await supabase.from('abg_deals').update({ estimated_profit: val, updated_at: new Date().toISOString() }).eq('id', deal.id);
      await logActivity(currentTenantId, deal.id, 'estimated_profit_set', {
        oldValue: deal.estimated_profit ? String(deal.estimated_profit) : null,
        newValue: formatCurrency(val),
      });
      setProfitModal(false);
      await loadData();
    } finally {
      setSubmitting(false);
    }
  };

  // ── Lane ──────────────────────────────────────────────────────────────────

  const updateLane = async (newLane: ABGLane) => {
    if (!deal || !currentTenantId) return;
    const old = deal.lane;
    await supabase.from('abg_deals').update({ lane: newLane, updated_at: new Date().toISOString() }).eq('id', deal.id);
    await logActivity(currentTenantId, deal.id, 'lane_set', { oldValue: old ?? null, newValue: newLane });
    setDeal((prev) => prev ? { ...prev, lane: newLane } : prev);
  };

  // ── Funding precheck ───────────────────────────────────────────────────────

  const updateFundingPrecheck = async (newStatus: FundingPrecheckStatus) => {
    if (!deal || !currentTenantId) return;
    const old = deal.funding_precheck_status;
    await supabase.from('abg_deals').update({ funding_precheck_status: newStatus, updated_at: new Date().toISOString() }).eq('id', deal.id);
    await logActivity(currentTenantId, deal.id, 'funding_precheck_changed', { oldValue: old, newValue: newStatus });
    setDeal((prev) => prev ? { ...prev, funding_precheck_status: newStatus } : prev);
  };

  // ── Contract status ────────────────────────────────────────────────────────

  const updateContractStatus = async (newStatus: ContractStatus) => {
    if (!deal || !currentTenantId) return;
    const old = deal.contract_status;
    await supabase.from('abg_deals').update({ contract_status: newStatus, updated_at: new Date().toISOString() }).eq('id', deal.id);
    await logActivity(currentTenantId, deal.id, 'contract_status_changed', { oldValue: old, newValue: newStatus });
    setDeal((prev) => prev ? { ...prev, contract_status: newStatus } : prev);
  };

  // ── Margin calculation ─────────────────────────────────────────────────────

  const computedMargin = deal && deal.project_value && deal.estimated_profit && deal.project_value > 0
    ? Number(deal.estimated_profit) / Number(deal.project_value)
    : null;

  const marginBelowFloor = computedMargin !== null && deal?.margin_floor
    ? computedMargin < Number(deal.margin_floor)
    : false;

  // ── Financing status ───────────────────────────────────────────────────────

  const updateFinancing = async (newStatus: FinancingStatus) => {
    if (!deal || !currentTenantId) return;
    const old = deal.financing_status;
    await supabase.from('abg_deals').update({ financing_status: newStatus, updated_at: new Date().toISOString() }).eq('id', deal.id);
    await logActivity(currentTenantId, deal.id, 'financing_status_changed', {
      oldValue: old, newValue: newStatus,
    });
    setDeal((prev) => prev ? { ...prev, financing_status: newStatus } : prev);
  };

  const handleWolfFundHandoff = async () => {
    if (!deal || !currentTenantId) return;
    try {
      await updateFinancing('wolf_fund_working');
      await logActivity(currentTenantId, deal.id, 'wolf_fund_handoff_triggered', {
        oldValue: deal.financing_status,
        newValue: 'wolf_fund_working',
        relatedEntityType: 'lead',
        relatedEntityId: deal.lead_id,
      });
    } catch {
      await logActivity(currentTenantId, deal.id, 'wolf_fund_handoff_failed', {});
    }
  };

  // ── Next action complete ───────────────────────────────────────────────────

  const completeNextAction = async () => {
    if (!deal || !currentTenantId || !nextAction) return;
    await supabase.from('abg_next_actions').update({
      status: 'completed',
      completed_at: new Date().toISOString(),
    }).eq('id', nextAction.id);
    await logActivity(currentTenantId, deal.id, 'next_action_completed', {
      newValue: nextAction.action_type,
    });
    await loadData();
  };

  // ── Notes ──────────────────────────────────────────────────────────────────

  const saveNote = async (body: string) => {
    if (!deal || !currentTenantId || !body.trim()) return;
    setSavingNote(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      await supabase.from('abg_notes').insert({
        tenant_id: currentTenantId,
        entity_type: 'deal',
        entity_id: deal.id,
        author_id: user?.id ?? '',
        body: body.trim(),
      });
      await logActivity(currentTenantId, deal.id, 'note_added', {});
      await loadData();
    } finally {
      setSavingNote(false);
    }
  };

  // ── Log update ─────────────────────────────────────────────────────────────

  const logUpdate = async () => {
    if (!deal || !currentTenantId || !updateNote.trim()) return;
    setSubmitting(true);
    try {
      await saveNote(updateNote);
      setUpdateNote('');
      setUpdateModal(false);
    } finally {
      setSubmitting(false);
    }
  };

  // ─── Render ────────────────────────────────────────────────────────────────

  if (loading) {
    return (
      <ABGShell>
        <div className="flex items-center justify-center h-64 gap-2 text-muted-foreground">
          <Loader2 className="h-5 w-5 animate-spin" />
          Loading deal…
        </div>
      </ABGShell>
    );
  }

  if (error || !deal) {
    return (
      <ABGShell>
        <div className="flex items-center gap-2 text-red-600 bg-red-50 border border-red-200 rounded-lg p-4">
          <AlertCircle className="h-4 w-4 shrink-0" />
          {error ?? 'Deal not found'}
        </div>
      </ABGShell>
    );
  }

  const clientName = lead
    ? [lead.first_name, lead.last_name].filter(Boolean).join(' ') || 'Unnamed'
    : '…';
  const days = daysInStage(deal.stage_entered_at);
  const velocity = velocityStatus(deal.stage, days);
  const prev = prevStage(deal.stage);
  const next = nextStage(deal.stage);
  const isTerminal = ['complete', 'cancelled'].includes(deal.stage);

  return (
    <ABGShell>
      {/* Back + header */}
      <div className="flex items-start justify-between mb-4">
        <div>
          <button
            onClick={() => navigate('/abg/portal/deals')}
            className="flex items-center gap-1 text-gray-400 hover:text-[#2B2B2B] text-sm mb-1 transition-colors"
          >
            <ChevronLeft className="h-4 w-4" />
            Deals
          </button>
          <h1 className="text-2xl font-bold text-[#2B2B2B]">{clientName}</h1>
          <div className="flex items-center gap-2 mt-1.5 flex-wrap">
            <StageBadge stage={deal.stage} />
            <span className={cn(
              'text-sm font-medium',
              velocity === 'on_track' ? 'text-green-600' :
              velocity === 'slowing'  ? 'text-amber-600' :
                                        'text-red-600'
            )}>
              {velocity === 'on_track' ? '🟢' : velocity === 'slowing' ? '🟡' : '🔴'} {days}d in stage
            </span>
          </div>
        </div>
      </div>

      {/* Body grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">

        {/* Left — main content */}
        <div className="lg:col-span-2 space-y-4">

          {/* Overview */}
          {/* Inline next action */}
          <SectionCard title="Next Action">
            <InlineNextAction
              value={deal.next_action}
              dueAt={deal.next_action_due}
              onSave={async (action, due) => {
                await supabase.from('abg_deals').update({
                  next_action: action,
                  next_action_due: due,
                  updated_at: new Date().toISOString(),
                }).eq('id', deal.id);
                setDeal((prev) => prev ? { ...prev, next_action: action, next_action_due: due } : prev);
              }}
              placeholder="Set next action for this deal…"
            />
          </SectionCard>

          <SectionCard title="Overview">
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              <Field label="Client"   value={clientName} />
              <Field label="Address"  value={lead ? [lead.address, lead.city, lead.state, lead.zip].filter(Boolean).join(', ') : null} />
              <Field label="Source"   value={lead?.source} />
              <Field label="Financing" value={<FinancingBadge status={deal.financing_status} />} />
              <Field label="Created"  value={formatDate(deal.created_at)} />
              <Field label="Linked Lead"
                value={
                  <button
                    onClick={() => navigate(`/abg/portal/leads/${deal.lead_id}`)}
                    className="flex items-center gap-1 text-[#4A8DB7] hover:underline text-sm"
                  >
                    View lead <ExternalLink className="h-3 w-3" />
                  </button>
                }
              />
            </div>
          </SectionCard>

          {/* Stage */}
          <SectionCard title="Stage">
            <div className="flex items-start justify-between flex-wrap gap-3">
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <StageBadge stage={deal.stage} />
                  <span className="text-xs text-gray-400">
                    since {formatDateTime(deal.stage_entered_at)}
                  </span>
                </div>
                <p className="text-xs text-gray-400">
                  {days} day{days !== 1 ? 's' : ''} in current stage
                </p>
              </div>

              {!isTerminal && (
                <div className="flex flex-wrap gap-2">
                  {prev && (
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => moveStage(prev)}
                      disabled={submitting}
                      className="border-[#E2E4E8] text-gray-600 hover:border-[#4A8DB7]"
                    >
                      <ChevronLeft className="h-3.5 w-3.5 mr-1" />
                      {prev.charAt(0).toUpperCase() + prev.slice(1)}
                    </Button>
                  )}
                  {next && (
                    <Button
                      size="sm"
                      onClick={() => moveStage(next)}
                      disabled={submitting}
                      className="bg-[#4A8DB7] hover:bg-[#4A8DB7]/90 text-white"
                    >
                      {next.charAt(0).toUpperCase() + next.slice(1)}
                      <ChevronRight className="h-3.5 w-3.5 ml-1" />
                    </Button>
                  )}
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => setHoldModal(true)}
                    disabled={submitting}
                    className="border-amber-200 text-amber-700 hover:bg-amber-50"
                  >
                    <PauseCircle className="h-3.5 w-3.5 mr-1" />
                    On Hold
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => setCancelModal(true)}
                    disabled={submitting}
                    className="border-red-200 text-red-600 hover:bg-red-50"
                  >
                    <XCircle className="h-3.5 w-3.5 mr-1" />
                    Cancel
                  </Button>
                </div>
              )}

              {deal.stage === 'on_hold' && (
                <Button
                  size="sm"
                  onClick={() => moveStage('active')}
                  disabled={submitting}
                  className="bg-[#4A8DB7] hover:bg-[#4A8DB7]/90 text-white"
                >
                  Resume → Active
                </Button>
              )}
            </div>
          </SectionCard>

          {/* Money */}
          <SectionCard title="Money">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-xs text-gray-400 uppercase tracking-wide mb-0.5">Project Value</p>
                <div className="flex items-center gap-2">
                  <p className="text-lg font-bold text-[#2B2B2B]">
                    {formatCurrency(deal.project_value)}
                  </p>
                  <button
                    onClick={() => { setEditValue(String(deal.project_value ?? '')); setValueModal(true); }}
                    className="text-gray-300 hover:text-[#4A8DB7] transition-colors"
                  >
                    <Edit2 className="h-3.5 w-3.5" />
                  </button>
                </div>
              </div>
              <div>
                <p className="text-xs text-gray-400 uppercase tracking-wide mb-0.5">Est. Profit</p>
                <div className="flex items-center gap-2">
                  <p className="text-lg font-bold text-[#2B2B2B]">
                    {formatCurrency(deal.estimated_profit)}
                  </p>
                  <button
                    onClick={() => { setEditProfit(String(deal.estimated_profit ?? '')); setProfitModal(true); }}
                    className="text-gray-300 hover:text-[#4A8DB7] transition-colors"
                  >
                    <Edit2 className="h-3.5 w-3.5" />
                  </button>
                </div>
              </div>
            </div>
          </SectionCard>

          {/* Financing */}
          <SectionCard title="Financing">
            <div className="flex items-center gap-3 flex-wrap">
              <div>
                <Label className="text-xs text-gray-400 uppercase tracking-wide mb-1 block">Status</Label>
                <Select
                  value={deal.financing_status}
                  onValueChange={(v) => updateFinancing(v as FinancingStatus)}
                >
                  <SelectTrigger className="h-8 text-sm w-52">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="unknown">Unknown / Not discussed</SelectItem>
                    <SelectItem value="already_covered">Already covered</SelectItem>
                    <SelectItem value="needs_financing">Needs financing</SelectItem>
                    <SelectItem value="wolf_fund_working">Wolf Fund working it</SelectItem>
                    <SelectItem value="confirmed">Financing confirmed</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              {deal.financing_status === 'needs_financing' && (
                <Button
                  size="sm"
                  variant="outline"
                  onClick={handleWolfFundHandoff}
                  className="border-[#4A8DB7] text-[#4A8DB7] hover:bg-[#4A8DB7]/10 mt-4"
                >
                  Route to Wolf Fund →
                </Button>
              )}
            </div>
          </SectionCard>

          {/* Lane + Project Controls */}
          <SectionCard title="Project Controls">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">

              {/* Lane */}
              <div>
                <Label className="text-xs text-gray-400 uppercase tracking-wide mb-1 block">Lane</Label>
                <Select
                  value={deal.lane ?? ''}
                  onValueChange={(v) => updateLane(v as ABGLane)}
                >
                  <SelectTrigger className="h-8 text-sm">
                    <SelectValue placeholder="Select lane" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="ABG_PRIVATE_RESIDENTIAL">Private / Residential</SelectItem>
                    <SelectItem value="ABG_COMMERCIAL_FRANCHISE">Commercial / Franchise</SelectItem>
                    <SelectItem value="ABG_GOVERNMENT_MUNICIPAL">Government / Municipal</SelectItem>
                  </SelectContent>
                </Select>
                {deal.lane && (
                  <p className="text-xs text-gray-400 mt-1">
                    Margin floor: {deal.margin_floor ? `${(Number(deal.margin_floor) * 100).toFixed(0)}%` : '—'}
                  </p>
                )}
              </div>

              {/* Funding precheck */}
              <div>
                <Label className="text-xs text-gray-400 uppercase tracking-wide mb-1 block">Funding Precheck</Label>
                <Select
                  value={deal.funding_precheck_status}
                  onValueChange={(v) => updateFundingPrecheck(v as FundingPrecheckStatus)}
                >
                  <SelectTrigger className="h-8 text-sm">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="pending">Pending</SelectItem>
                    <SelectItem value="passed">Passed</SelectItem>
                    <SelectItem value="failed">Failed</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Contract status */}
              <div>
                <Label className="text-xs text-gray-400 uppercase tracking-wide mb-1 block">Contract</Label>
                <Select
                  value={deal.contract_status}
                  onValueChange={(v) => updateContractStatus(v as ContractStatus)}
                >
                  <SelectTrigger className="h-8 text-sm">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="pending">Pending</SelectItem>
                    <SelectItem value="sent">Sent</SelectItem>
                    <SelectItem value="signed">Signed</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Margin warning — soft blocker, UI flag only */}
            {marginBelowFloor && (
              <div className="mt-3 flex items-start gap-2 bg-amber-50 border border-amber-200 rounded p-3">
                <AlertCircle className="h-4 w-4 text-amber-600 shrink-0 mt-0.5" />
                <div>
                  <p className="text-sm font-medium text-amber-700">Margin below floor</p>
                  <p className="text-xs text-amber-600 mt-0.5">
                    Current margin:{' '}
                    <span className="font-semibold">
                      {computedMargin !== null ? `${(computedMargin * 100).toFixed(1)}%` : '—'}
                    </span>
                    {' '}· Floor:{' '}
                    <span className="font-semibold">
                      {deal.margin_floor ? `${(Number(deal.margin_floor) * 100).toFixed(0)}%` : '—'}
                    </span>
                    . Review pricing before proceeding.
                  </p>
                </div>
              </div>
            )}

            {/* Computed margin display when above floor */}
            {computedMargin !== null && !marginBelowFloor && (
              <p className="text-xs text-gray-400 mt-3">
                Current margin:{' '}
                <span className="font-medium text-green-600">
                  {(computedMargin * 100).toFixed(1)}%
                </span>
                {deal.margin_floor && (
                  <> · Floor: {(Number(deal.margin_floor) * 100).toFixed(0)}% ✓</>
                )}
              </p>
            )}
          </SectionCard>

          {/* Action bar */}
          <div className="flex gap-2 flex-wrap">
            <Button
              variant="outline"
              onClick={() => setUpdateModal(true)}
              className="border-[#E2E4E8] hover:border-[#4A8DB7] hover:text-[#4A8DB7]"
            >
              Log Update
            </Button>
            <Button
              variant="outline"
              onClick={() => navigate(`/abg/portal/leads/${deal.lead_id}`)}
              className="border-[#E2E4E8] hover:border-[#4A8DB7] hover:text-[#4A8DB7]"
            >
              <ExternalLink className="h-3.5 w-3.5 mr-1.5" />
              View Original Lead
            </Button>
            {/* Create Job — only available on signed deals */}
            {deal.stage === 'signed' && (
              <CreateJobButton dealId={deal.id} tenantId={currentTenantId} onCreated={(jobId) => navigate(`/abg/portal/jobs/${jobId}`)} />
            )}
          </div>

          {/* Activity / Notes tabs */}
          <SectionCard>
            <div className="flex gap-1 mb-4 border-b border-[#E2E4E8]">
              {(['activity', 'notes'] as const).map((tab) => (
                <button
                  key={tab}
                  onClick={() => setActiveTab(tab)}
                  className={cn(
                    'px-4 py-1.5 text-sm font-medium capitalize border-b-2 -mb-px transition-colors',
                    activeTab === tab
                      ? 'border-[#4A8DB7] text-[#4A8DB7]'
                      : 'border-transparent text-gray-400 hover:text-[#2B2B2B]',
                  )}
                >
                  {tab === 'activity' ? 'Activity Timeline' : 'Notes'}
                </button>
              ))}
            </div>

            {/* Activity timeline — source: abg_activity, entity_type='deal' */}
            {activeTab === 'activity' && (
              <div className="space-y-3">
                {activity.length === 0 ? (
                  <p className="text-sm text-gray-400">No activity yet.</p>
                ) : (
                  activity.map((ev) => (
                    <div key={ev.id} className="flex gap-3 text-sm">
                      <div className="shrink-0 w-1.5 h-1.5 rounded-full bg-[#4A8DB7] mt-2" />
                      <div className="flex-1">
                        <p className="text-[#1A1A1A]">
                          {eventLabel(ev.event_type, ev.old_value, ev.new_value)}
                        </p>
                        {ev.note && (
                          <p className="text-gray-400 text-xs mt-0.5 italic">"{ev.note}"</p>
                        )}
                        <p className="text-gray-300 text-xs mt-0.5">
                          {formatDateTime(ev.created_at)} ·{' '}
                          {ev.actor_type === 'system' ? 'System' : 'Worker'}
                        </p>
                      </div>
                    </div>
                  ))
                )}
              </div>
            )}

            {/* Notes — source: abg_notes, entity_type='deal' */}
            {activeTab === 'notes' && (
              <div className="space-y-4">
                <div className="space-y-2">
                  <Textarea
                    placeholder="Add a note…"
                    value={newNote}
                    onChange={(e) => setNewNote(e.target.value)}
                    className="text-sm resize-none"
                    rows={3}
                  />
                  <Button
                    size="sm"
                    onClick={() => { saveNote(newNote); setNewNote(''); }}
                    disabled={savingNote || !newNote.trim()}
                    className="bg-[#4A8DB7] hover:bg-[#4A8DB7]/90 text-white"
                  >
                    {savingNote ? <Loader2 className="h-3 w-3 animate-spin mr-1" /> : null}
                    Save Note
                  </Button>
                </div>
                {notes.length === 0 ? (
                  <p className="text-sm text-gray-400">No notes yet.</p>
                ) : (
                  notes.map((note) => (
                    <div key={note.id} className="border border-[#E2E4E8] rounded p-3 text-sm">
                      <p className="text-[#1A1A1A]">{note.body}</p>
                      <p className="text-gray-300 text-xs mt-1">{formatDateTime(note.created_at)}</p>
                    </div>
                  ))
                )}
              </div>
            )}
          </SectionCard>
        </div>

        {/* Right column */}
        <div className="space-y-4">

          {/* Next action — source: abg_next_actions, entity_type='deal' */}
          {nextAction ? (
            <SectionCard title="Next Action">
              <div className="space-y-2">
                <p className="text-sm font-medium text-[#1A1A1A]">
                  {actionTypeLabel(nextAction.action_type, nextAction.custom_label)}
                </p>
                <p className="text-xs text-gray-400 flex items-center gap-1">
                  <Clock className="h-3.5 w-3.5" />
                  Due: {formatDateTime(nextAction.due_at)}
                </p>
                <Button
                  size="sm"
                  onClick={completeNextAction}
                  className="w-full bg-green-600 hover:bg-green-700 text-white"
                >
                  <CheckCircle2 className="h-4 w-4 mr-1.5" />
                  Mark Complete
                </Button>
              </div>
            </SectionCard>
          ) : (
            <SectionCard title="Next Action">
              <p className="text-sm text-gray-400">No active next action.</p>
            </SectionCard>
          )}

          {/* Deal meta */}
          <SectionCard>
            <div className="space-y-2 text-xs text-gray-400">
              {deal.completed_at && <p>Completed: {formatDateTime(deal.completed_at)}</p>}
              {deal.cancelled_at && <p>Cancelled: {formatDateTime(deal.cancelled_at)}</p>}
              {deal.on_hold_at   && <p>On hold since: {formatDateTime(deal.on_hold_at)}</p>}
              <p>Created: {formatDateTime(deal.created_at)}</p>
              <p>Updated: {timeAgo(deal.updated_at)}</p>
            </div>
          </SectionCard>
        </div>
      </div>

      {/* ── Modals ─────────────────────────────────────────────────────────── */}

      {/* Put On Hold */}
      <Dialog open={holdModal} onOpenChange={setHoldModal}>
        <DialogContent>
          <DialogHeader><DialogTitle>Put On Hold</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <p className="text-sm text-gray-500">
              The deal will be paused. All history is preserved. You can resume it at any time.
            </p>
            <div>
              <Label>Reason (required)</Label>
              <Textarea
                value={holdReason}
                onChange={(e) => setHoldReason(e.target.value)}
                placeholder="Why is this deal being put on hold?"
                rows={3}
                className="text-sm"
              />
            </div>
            <Button
              onClick={() => moveStage('on_hold', holdReason)}
              disabled={submitting || !holdReason.trim()}
              className="w-full bg-amber-600 hover:bg-amber-700 text-white"
            >
              {submitting ? <Loader2 className="h-4 w-4 animate-spin mr-1" /> : null}
              Put On Hold
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Cancel Deal */}
      <Dialog open={cancelModal} onOpenChange={setCancelModal}>
        <DialogContent>
          <DialogHeader><DialogTitle>Cancel Deal</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <p className="text-sm text-gray-500">
              The deal will be cancelled. This does not delete the deal or the original lead.
              All history is preserved.
            </p>
            <div>
              <Label>Reason (required)</Label>
              <Textarea
                value={cancelReason}
                onChange={(e) => setCancelReason(e.target.value)}
                placeholder="Why is this deal being cancelled?"
                rows={3}
                className="text-sm"
              />
            </div>
            <Button
              onClick={() => moveStage('cancelled', cancelReason)}
              disabled={submitting || !cancelReason.trim()}
              className="w-full bg-red-600 hover:bg-red-700 text-white"
            >
              {submitting ? <Loader2 className="h-4 w-4 animate-spin mr-1" /> : null}
              Cancel Deal
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Edit Project Value */}
      <Dialog open={valueModal} onOpenChange={setValueModal}>
        <DialogContent>
          <DialogHeader><DialogTitle>Edit Project Value</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <div className="relative">
              <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 text-sm">$</span>
              <Input
                type="number"
                value={editValue}
                onChange={(e) => setEditValue(e.target.value)}
                placeholder="e.g. 85000"
                className="pl-7 text-sm"
              />
            </div>
            <Button
              onClick={saveProjectValue}
              disabled={submitting || !editValue}
              className="w-full bg-[#4A8DB7] hover:bg-[#4A8DB7]/90 text-white"
            >
              {submitting ? <Loader2 className="h-4 w-4 animate-spin mr-1" /> : null}
              Save Value
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Edit Estimated Profit */}
      <Dialog open={profitModal} onOpenChange={setProfitModal}>
        <DialogContent>
          <DialogHeader><DialogTitle>Edit Estimated Profit</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <div className="relative">
              <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 text-sm">$</span>
              <Input
                type="number"
                value={editProfit}
                onChange={(e) => setEditProfit(e.target.value)}
                placeholder="e.g. 22000"
                className="pl-7 text-sm"
              />
            </div>
            <Button
              onClick={saveEstimatedProfit}
              disabled={submitting || !editProfit}
              className="w-full bg-[#4A8DB7] hover:bg-[#4A8DB7]/90 text-white"
            >
              {submitting ? <Loader2 className="h-4 w-4 animate-spin mr-1" /> : null}
              Save Profit
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Log Update */}
      <Dialog open={updateModal} onOpenChange={setUpdateModal}>
        <DialogContent>
          <DialogHeader><DialogTitle>Log Update</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <Textarea
              value={updateNote}
              onChange={(e) => setUpdateNote(e.target.value)}
              placeholder="What happened? What's the status?"
              rows={4}
              className="text-sm"
            />
            <Button
              onClick={logUpdate}
              disabled={submitting || !updateNote.trim()}
              className="w-full bg-[#4A8DB7] hover:bg-[#4A8DB7]/90 text-white"
            >
              {submitting ? <Loader2 className="h-4 w-4 animate-spin mr-1" /> : null}
              Log Update
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </ABGShell>
  );
}
