import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { useABGTenant } from '../hooks/useABGTenant';
import { ABGShell } from '../components/ABGShell';
import { StageBadge } from '../components/ABGBadges';
import { timeAgo, formatCurrency } from '../lib/time';
import type { ABGStuckDeal } from '../types';
import { Loader2, AlertCircle, DollarSign } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';

async function fetchStuckDeals(tenantId: string): Promise<ABGStuckDeal[]> {
  const { data, error } = await supabase
    .from('abg_stuck_deals')
    .select('*')
    .eq('tenant_id', tenantId)
    .order('days_in_stage', { ascending: false });

  if (error) throw new Error(error.message);
  return (data ?? []) as ABGStuckDeal[];
}

function stuckBorderClass(days: number): string {
  if (days >= 10) return 'border-l-4 border-l-red-500';
  if (days >= 6)  return 'border-l-4 border-l-red-400';
  return 'border-l-4 border-l-amber-400';
}

export default function ABGStuckMoney() {
  const navigate = useNavigate();
  const { tenantId: currentTenantId, loading: tenantLoading } = useABGTenant();

  const [deals, setDeals] = useState<ABGStuckDeal[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError]     = useState<string | null>(null);

  useEffect(() => {
    if (tenantLoading) return;
    if (!currentTenantId) { setLoading(false); return; }
    setLoading(true);
    fetchStuckDeals(currentTenantId)
      .then(setDeals)
      .catch((e) => setError(e.message))
      .finally(() => setLoading(false));
  }, [currentTenantId, tenantLoading]);

  const totalStuck = deals.reduce((acc, d) => acc + (d.project_value ?? 0), 0);

  if (loading) {
    return (
      <ABGShell>
        <div className="flex items-center justify-center h-64 gap-2 text-muted-foreground">
          <Loader2 className="h-5 w-5 animate-spin" />
          Loading stuck money…
        </div>
      </ABGShell>
    );
  }

  if (error) {
    return (
      <ABGShell>
        <div className="flex items-center gap-2 text-red-600 bg-red-50 border border-red-200 rounded-lg p-4">
          <AlertCircle className="h-4 w-4 shrink-0" />
          {error}
        </div>
      </ABGShell>
    );
  }

  return (
    <ABGShell>
      {/* Header */}
      <div className="mb-5">
        <h1 className="text-2xl font-bold text-[#2B2B2B]">Stuck Money</h1>
        <p className="text-sm text-gray-400 mt-0.5">
          Deals with no activity in 3+ days
        </p>
      </div>

      {/* Summary */}
      {deals.length > 0 && (
        <div className="bg-red-50 border border-red-200 rounded-lg p-4 mb-4 flex items-center gap-3">
          <DollarSign className="h-5 w-5 text-red-500 shrink-0" />
          <div>
            <p className="text-sm font-semibold text-red-700">
              {formatCurrency(totalStuck)} is stuck in the pipeline
            </p>
            <p className="text-xs text-red-500 mt-0.5">
              {deals.length} deal{deals.length !== 1 ? 's' : ''} need attention today
            </p>
          </div>
        </div>
      )}

      {/* Desktop table */}
      <div className="hidden md:block bg-white border border-[#E2E4E8] rounded-lg overflow-hidden">
        {deals.length === 0 ? (
          <div className="p-12 text-center">
            <p className="text-2xl mb-2">💰</p>
            <p className="text-sm font-medium text-[#2B2B2B]">No stuck deals</p>
            <p className="text-sm text-gray-400 mt-1">All active deals have been touched in the last 3 days.</p>
          </div>
        ) : (
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-[#E2E4E8] bg-[#F5F6F8]">
                <th className="text-left px-4 py-2.5 text-xs font-semibold text-gray-500 uppercase tracking-wide">Name</th>
                <th className="text-left px-4 py-2.5 text-xs font-semibold text-gray-500 uppercase tracking-wide">Value</th>
                <th className="text-left px-4 py-2.5 text-xs font-semibold text-gray-500 uppercase tracking-wide">Stage</th>
                <th className="text-left px-4 py-2.5 text-xs font-semibold text-gray-500 uppercase tracking-wide">Days Stuck</th>
                <th className="text-left px-4 py-2.5 text-xs font-semibold text-gray-500 uppercase tracking-wide">Last Touch</th>
                <th className="px-4 py-2.5" />
              </tr>
            </thead>
            <tbody>
              {deals.map((deal, i) => (
                <tr
                  key={deal.id}
                  className={cn(
                    'border-b border-[#E2E4E8] hover:bg-[#4A8DB7]/5 transition-colors',
                    i === deals.length - 1 ? 'border-b-0' : '',
                    stuckBorderClass(Number(deal.days_in_stage))
                  )}
                >
                  <td className="px-4 py-3">
                    <p className="font-medium text-[#1A1A1A]">
                      {[deal.first_name, deal.last_name].filter(Boolean).join(' ') || '—'}
                    </p>
                  </td>
                  <td className="px-4 py-3 font-semibold text-[#4A8DB7]">
                    {formatCurrency(deal.project_value)}
                  </td>
                  <td className="px-4 py-3">
                    <StageBadge stage={deal.stage} />
                  </td>
                  <td className="px-4 py-3">
                    <span className={cn(
                      'font-semibold text-sm',
                      Number(deal.days_in_stage) >= 10 ? 'text-red-600' :
                      Number(deal.days_in_stage) >= 6  ? 'text-red-500' :
                                                         'text-amber-600'
                    )}>
                      {Number(deal.days_in_stage)} days
                    </span>
                  </td>
                  <td className="px-4 py-3 text-gray-400 text-sm">
                    {deal.last_touch_at ? timeAgo(deal.last_touch_at) : (
                      <span className="text-red-500 font-medium">Never touched</span>
                    )}
                  </td>
                  <td className="px-4 py-3 text-right">
                    <Button
                      size="sm"
                      onClick={() => navigate(`/abg/portal/deals/${deal.id}`)}
                      className="bg-[#4A8DB7] hover:bg-[#4A8DB7]/90 text-white"
                    >
                      Open
                    </Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {/* Mobile cards */}
      <div className="md:hidden space-y-2">
        {deals.length === 0 ? (
          <div className="bg-white border border-[#E2E4E8] rounded-lg p-8 text-center">
            <p className="text-2xl mb-2">💰</p>
            <p className="text-sm font-medium text-[#2B2B2B]">No stuck deals</p>
            <p className="text-sm text-gray-400 mt-1">All deals have been touched recently.</p>
          </div>
        ) : (
          deals.map((deal) => (
            <button
              key={deal.id}
              onClick={() => navigate(`/abg/portal/deals/${deal.id}`)}
              className={cn(
                'w-full text-left bg-white border border-[#E2E4E8] rounded-lg p-4',
                stuckBorderClass(Number(deal.days_in_stage))
              )}
            >
              <div className="flex items-start justify-between">
                <p className="font-semibold text-[#1A1A1A] text-sm">
                  {[deal.first_name, deal.last_name].filter(Boolean).join(' ') || '—'}
                </p>
                <StageBadge stage={deal.stage} />
              </div>
              <div className="flex items-center justify-between mt-2 text-xs">
                <span className="font-semibold text-[#4A8DB7]">{formatCurrency(deal.project_value)}</span>
                <span className={cn(
                  'font-semibold',
                  Number(deal.days_in_stage) >= 10 ? 'text-red-600' :
                  Number(deal.days_in_stage) >= 6  ? 'text-red-500' :
                                                     'text-amber-600'
                )}>
                  {Number(deal.days_in_stage)} days stuck
                </span>
              </div>
              <p className="text-xs text-gray-400 mt-1">
                Last touch: {deal.last_touch_at ? timeAgo(deal.last_touch_at) : (
                  <span className="text-red-500 font-medium">Never</span>
                )}
              </p>
            </button>
          ))
        )}
      </div>
    </ABGShell>
  );
}
