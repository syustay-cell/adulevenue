import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { useABGTenant } from '../hooks/useABGTenant';
import { ABGShell } from '../components/ABGShell';
import { StageBadge, LaneBadge } from '../components/ABGBadges';
import { formatCurrency, daysInStage, velocityStatus } from '../lib/time';
import type { ABGDeal, ABGPipelineSummary, DealStage } from '../types';
import { Loader2, AlertCircle, AlertTriangle } from 'lucide-react';
import { cn } from '@/lib/utils';

const STAGES: DealStage[] = ['active','proposal','signed','permit','build','complete'];

interface DealWithLead extends ABGDeal {
  lead_name: string;
}

async function fetchDealsWithLeads(tenantId: string): Promise<DealWithLead[]> {
  const { data: deals, error } = await supabase
    .from('abg_deals')
    .select('*')
    .eq('tenant_id', tenantId)
    .not('stage', 'in', '("cancelled")')
    .order('stage_entered_at', { ascending: false });

  if (error) throw new Error(error.message);
  if (!deals?.length) return [];

  // Resolve lead names
  const leadIds = [...new Set(deals.map((d) => d.lead_id))];
  const { data: leads } = await supabase
    .from('wf_leads')
    .select('id, first_name, last_name')
    .in('id', leadIds);

  const nameMap: Record<string, string> = {};
  (leads ?? []).forEach((l) => {
    nameMap[l.id] = [l.first_name, l.last_name].filter(Boolean).join(' ') || 'Unknown';
  });

  return deals.map((d) => ({
    ...d,
    lead_name: nameMap[d.lead_id] ?? 'Unknown',
  })) as DealWithLead[];
}

async function fetchPipelineSummary(tenantId: string): Promise<ABGPipelineSummary[]> {
  const { data } = await supabase
    .from('abg_pipeline_summary')
    .select('*')
    .eq('tenant_id', tenantId);
  return (data ?? []) as ABGPipelineSummary[];
}

export default function ABGDealPipeline() {
  const navigate = useNavigate();
  const { tenantId: currentTenantId, loading: tenantLoading } = useABGTenant();

  const [deals, setDeals]     = useState<DealWithLead[]>([]);
  const [summary, setSummary] = useState<ABGPipelineSummary[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError]     = useState<string | null>(null);

  useEffect(() => {
    if (tenantLoading) return;
    if (!currentTenantId) { setLoading(false); return; }
    setLoading(true);
    Promise.all([
      fetchDealsWithLeads(currentTenantId),
      fetchPipelineSummary(currentTenantId),
    ])
      .then(([d, s]) => { setDeals(d); setSummary(s); })
      .catch((e) => setError(e.message))
      .finally(() => setLoading(false));
  }, [currentTenantId, tenantLoading]);

  const totalPipeline = summary.reduce((acc, s) => acc + Number(s.pipeline_value), 0);
  const totalProfit   = summary.reduce((acc, s) => acc + Number(s.profit_value), 0);
  const totalDeals    = summary.reduce((acc, s) => acc + Number(s.deal_count), 0);

  const summaryByStage = Object.fromEntries(
    summary.map((s) => [s.stage, s])
  ) as Record<string, ABGPipelineSummary>;

  if (loading) {
    return (
      <ABGShell>
        <div className="flex items-center justify-center h-64 gap-2 text-muted-foreground">
          <Loader2 className="h-5 w-5 animate-spin" />
          Loading pipeline…
        </div>
      </ABGShell>
    );
  }

  if (error) {
    return (
      <ABGShell>
        <div className="flex items-center gap-2 text-red-600 bg-red-50 border border-red-200 rounded-lg p-4">
          <AlertCircle className="h-4 w-4 shrink-0" />
          {error}
        </div>
      </ABGShell>
    );
  }

  return (
    <ABGShell>
      {/* Header */}
      <div className="mb-5">
        <h1 className="text-2xl font-bold text-[#2B2B2B]">Deal Pipeline</h1>

        {/* Summary bar */}
        <div className="flex flex-wrap gap-6 mt-3">
          <Stat label="Pipeline Value"   value={formatCurrency(totalPipeline)} />
          <Stat label="Est. Profit"      value={formatCurrency(totalProfit)} />
          <Stat label="Active Deals"     value={String(totalDeals)} />
        </div>
      </div>

      {/* Desktop Kanban */}
      <div className="hidden lg:flex gap-3 overflow-x-auto pb-4">
        {STAGES.map((stage) => {
          const stageDeals = deals.filter((d) => d.stage === stage);
          const stageSummary = summaryByStage[stage];
          return (
            <div key={stage} className="flex-1 min-w-[180px] max-w-[220px]">
              {/* Column header */}
              <div className="mb-2">
                <StageBadge stage={stage} />
                <div className="text-xs text-gray-400 mt-1">
                  {stageDeals.length} deal{stageDeals.length !== 1 ? 's' : ''}
                  {stageSummary?.pipeline_value ? ` · ${formatCurrency(Number(stageSummary.pipeline_value))}` : ''}
                </div>
              </div>

              {/* Cards */}
              <div className="space-y-2">
                {stageDeals.length === 0 ? (
                  <div className="border-2 border-dashed border-[#E2E4E8] rounded-lg h-20 flex items-center justify-center text-xs text-gray-300">
                    Empty
                  </div>
                ) : (
                  stageDeals.map((deal) => (
                    <DealCard
                      key={deal.id}
                      deal={deal}
                      onClick={() => navigate(`/abg/portal/deals/${deal.id}`)}
                    />
                  ))
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Mobile list */}
      <div className="lg:hidden space-y-2">
        {deals.length === 0 ? (
          <div className="bg-white border border-[#E2E4E8] rounded-lg p-8 text-center text-gray-400 text-sm">
            No active deals yet. Convert a lead to create a deal.
          </div>
        ) : (
          deals.map((deal) => (
            <button
              key={deal.id}
              onClick={() => navigate(`/abg/portal/deals/${deal.id}`)}
              className="w-full text-left bg-white border border-[#E2E4E8] rounded-lg p-4"
            >
              <div className="flex items-center justify-between">
                <p className="font-medium text-[#1A1A1A] text-sm">{deal.lead_name}</p>
                <StageBadge stage={deal.stage} />
              </div>
              <div className="flex items-center gap-2 mt-2 text-xs text-gray-400">
                <span>{formatCurrency(deal.project_value)}</span>
                <span>·</span>
                <span>{daysInStage(deal.stage_entered_at)}d in stage</span>
              </div>
            </button>
          ))
        )}
      </div>
    </ABGShell>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <p className="text-xs text-gray-400 uppercase tracking-wide">{label}</p>
      <p className="text-xl font-bold text-[#2B2B2B]">{value}</p>
    </div>
  );
}

function DealCard({ deal, onClick }: { deal: DealWithLead; onClick: () => void }) {
  const days     = daysInStage(deal.stage_entered_at);
  const velocity = velocityStatus(deal.stage, days);

  return (
    <button
      onClick={onClick}
      className={cn(
        'w-full text-left bg-white border rounded-lg p-3 hover:border-[#4A8DB7]/50 transition-colors',
        velocity === 'stalled'   ? 'border-red-300'    :
        velocity === 'slowing'   ? 'border-amber-300'  :
                                   'border-[#E2E4E8]'
      )}
    >
      <div className="flex items-start justify-between gap-1">
        <p className="font-medium text-[#1A1A1A] text-sm leading-tight truncate">
          {deal.lead_name}
        </p>
        {velocity === 'stalled' && (
          <AlertTriangle className="h-3.5 w-3.5 text-red-500 shrink-0 mt-0.5" />
        )}
        {velocity === 'slowing' && (
          <AlertTriangle className="h-3.5 w-3.5 text-amber-500 shrink-0 mt-0.5" />
        )}
      </div>
      {deal.lane && <LaneBadge lane={deal.lane} />}

      {deal.project_value && (
        <p className="text-xs font-semibold text-[#4A8DB7] mt-1">
          {formatCurrency(deal.project_value)}
        </p>
      )}

      <div className="flex items-center justify-between mt-1.5">
        <span className={cn(
          'text-xs font-medium',
          velocity === 'stalled' ? 'text-red-500' :
          velocity === 'slowing' ? 'text-amber-500' :
                                   'text-gray-400'
        )}>
          {days}d in stage
        </span>
        <span className={cn(
          'text-xs',
          velocity === 'on_track' ? 'text-green-500' :
          velocity === 'slowing'  ? 'text-amber-500' :
                                    'text-red-500'
        )}>
          {velocity === 'on_track' ? '🟢' : velocity === 'slowing' ? '🟡' : '🔴'}
        </span>
      </div>
    </button>
  );
}
