/**
 * ABG Sub Login — /abg/subs/login
 * Subcontractor-specific login screen.
 * After login, user is validated against abg_sub_accounts.
 * If no sub account exists → shows "access not set up" message.
 */
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Loader2, HardHat, AlertCircle } from 'lucide-react';

export default function ABGSubLogin() {
  const navigate = useNavigate();
  const [email, setEmail]       = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading]   = useState(false);
  const [error, setError]       = useState<string | null>(null);

  const handleLogin = async () => {
    if (!email.trim() || !password.trim()) return;
    setLoading(true);
    setError(null);

    try {
      const { data: authData, error: authError } = await supabase.auth.signInWithPassword({
        email: email.trim(),
        password,
      });

      if (authError) throw new Error(authError.message);
      const userId = authData.user?.id;
      if (!userId) throw new Error('Login failed — no user returned');

      // Verify this user has a sub account
      const { data: subAccount } = await supabase
        .from('abg_sub_accounts')
        .select('sub_id')
        .eq('user_id', userId)
        .maybeSingle();

      if (!subAccount) {
        await supabase.auth.signOut();
        throw new Error(
          'This account is not linked to a subcontractor record. Contact ABG to set up your access.'
        );
      }

      // Sub portal only — subs never see Wolf Fund or ABG staff portal
      navigate('/abg/subs/jobs', { replace: true });
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Login failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#F5F6F8] flex items-center justify-center px-4">
      <div className="w-full max-w-sm">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-14 h-14 rounded-xl bg-[#2B2B2B] mb-4">
            <HardHat className="h-7 w-7 text-[#4A8DB7]" />
          </div>
          <h1 className="text-2xl font-bold text-[#2B2B2B]">Subcontractor Portal</h1>
          <p className="text-sm text-gray-400 mt-1">Advanced Builders Group</p>
        </div>

        {/* Form */}
        <div className="bg-white border border-[#E2E4E8] rounded-xl p-6 space-y-4">
          <div>
            <Label className="text-sm text-gray-600">Email</Label>
            <Input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleLogin()}
              placeholder="your@email.com"
              className="mt-1"
              autoComplete="email"
            />
          </div>
          <div>
            <Label className="text-sm text-gray-600">Password</Label>
            <Input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleLogin()}
              placeholder="••••••••"
              className="mt-1"
              autoComplete="current-password"
            />
          </div>

          {error && (
            <div className="flex items-start gap-2 bg-red-50 border border-red-200 rounded-lg p-3">
              <AlertCircle className="h-4 w-4 text-red-500 shrink-0 mt-0.5" />
              <p className="text-sm text-red-600">{error}</p>
            </div>
          )}

          <Button
            onClick={handleLogin}
            disabled={loading || !email.trim() || !password.trim()}
            className="w-full bg-[#2B2B2B] hover:bg-[#4A8DB7] text-white h-10"
          >
            {loading ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : null}
            Sign In
          </Button>
        </div>

        <p className="text-center text-xs text-gray-400 mt-6">
          Access issues? Contact your ABG project manager.
        </p>
      </div>
    </div>
  );
}
