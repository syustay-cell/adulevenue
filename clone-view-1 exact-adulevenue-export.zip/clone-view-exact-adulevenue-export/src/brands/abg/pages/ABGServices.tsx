import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Building2, Truck, Wrench, Briefcase, ArrowRight, ArrowLeft, CheckCircle2 } from "lucide-react";
import { useBrand } from "@/contexts/BrandContext";

const services = [
  {
    icon: Truck,
    title: "Equipment Financing",
    description: "Get the heavy machinery and tools your projects demand",
    features: [
      "Excavators, loaders, and cranes",
      "Trucks and fleet vehicles",
      "Power tools and specialty equipment",
      "Same-day approval available",
    ],
    amount: "Up to $250,000",
  },
  {
    icon: Building2,
    title: "Project Financing",
    description: "Bridge funding to mobilize and complete construction projects",
    features: [
      "Material procurement",
      "Labor and subcontractor payments",
      "Permit and licensing fees",
      "Project mobilization costs",
    ],
    amount: "Up to $500,000",
  },
  {
    icon: Wrench,
    title: "Working Capital",
    description: "Keep cash flowing between project payments",
    features: [
      "Payroll coverage",
      "Operational expenses",
      "Seasonal cash flow gaps",
      "Growth opportunities",
    ],
    amount: "Up to $150,000",
  },
  {
    icon: Briefcase,
    title: "Business Expansion",
    description: "Scale your construction business to the next level",
    features: [
      "New market entry",
      "Additional crews",
      "Office and yard expansion",
      "License and certification",
    ],
    amount: "Up to $500,000",
  },
];

const ABGServices = () => {
  const { brand } = useBrand();

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Building2 className="h-8 w-8 text-primary" />
            <span className="text-xl font-bold text-foreground">{brand.name}</span>
          </div>
          <nav className="flex items-center gap-4">
            <Button variant="ghost" asChild>
              <Link to="/abg">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back
              </Link>
            </Button>
            <Button asChild>
              <Link to="/abg/apply">Apply Now</Link>
            </Button>
          </nav>
        </div>
      </header>

      {/* Hero */}
      <section className="py-16 px-4 text-center">
        <h1 className="text-4xl font-bold text-foreground mb-4">
          Funding Solutions for Builders
        </h1>
        <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
          Specialized financing programs designed for the unique needs of construction businesses
        </p>
      </section>

      {/* Services Grid */}
      <section className="py-8 px-4">
        <div className="container mx-auto">
          <div className="grid md:grid-cols-2 gap-8">
            {services.map((service, index) => (
              <Card key={index} className="relative overflow-hidden">
                <div className="absolute top-0 right-0 p-4">
                  <span className="text-sm font-semibold text-primary bg-primary/10 px-3 py-1 rounded-full">
                    {service.amount}
                  </span>
                </div>
                <CardHeader>
                  <service.icon className="h-12 w-12 text-primary mb-4" />
                  <CardTitle className="text-2xl">{service.title}</CardTitle>
                  <CardDescription className="text-base">
                    {service.description}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-3 mb-6">
                    {service.features.map((feature, i) => (
                      <li key={i} className="flex items-center gap-3 text-muted-foreground">
                        <CheckCircle2 className="h-5 w-5 text-primary flex-shrink-0" />
                        {feature}
                      </li>
                    ))}
                  </ul>
                  <Button className="w-full" asChild>
                    <Link to="/abg/apply">
                      Apply for {service.title}
                      <ArrowRight className="h-4 w-4 ml-2" />
                    </Link>
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 px-4">
        <div className="container mx-auto">
          <Card className="bg-primary text-primary-foreground p-8 text-center">
            <h2 className="text-3xl font-bold mb-4">Not Sure Which Option?</h2>
            <p className="text-primary-foreground/80 mb-6 max-w-xl mx-auto">
              Our funding specialists can help you find the perfect solution for your 
              construction business needs.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" variant="secondary" asChild>
                <Link to="/abg/apply">
                  Start Application <ArrowRight className="h-4 w-4 ml-2" />
                </Link>
              </Button>
              <Button size="lg" variant="outline" className="bg-transparent border-primary-foreground text-primary-foreground hover:bg-primary-foreground/10">
                Call (888) ABG-FUND
              </Button>
            </div>
          </Card>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border py-8 px-4">
        <div className="container mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <Building2 className="h-5 w-5 text-primary" />
            <span className="font-semibold text-foreground">{brand.name}</span>
          </div>
          <p className="text-sm text-muted-foreground">
            Powered by Wolf Fund • © {new Date().getFullYear()} All rights reserved
          </p>
        </div>
      </footer>
    </div>
  );
};

export default ABGServices;
