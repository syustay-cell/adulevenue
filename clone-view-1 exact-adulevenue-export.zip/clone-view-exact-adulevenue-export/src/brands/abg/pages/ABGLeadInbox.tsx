import { useEffect, useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { useABGTenant } from '../hooks/useABGTenant';
import { ABGShell } from '../components/ABGShell';
import { StatusBadge, HeatBadge, SourceBadge } from '../components/ABGBadges';
import { timeAgo } from '../lib/time';
import type { ABGLead, LeadStatus, LeadHeat } from '../types';
import { Search, ChevronDown, Loader2, AlertCircle } from 'lucide-react';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

// ─── Data fetching ─────────────────────────────────────────────────────────────

async function fetchLeads(tenantId: string): Promise<ABGLead[]> {
  const { data, error } = await supabase
    .from('wf_leads')
    .select('*')
    .eq('tenant_id', tenantId)
    .order('created_at', { ascending: false });

  if (error) throw new Error(error.message);
  return (data ?? []) as ABGLead[];
}

// ─── Component ─────────────────────────────────────────────────────────────────

export default function ABGLeadInbox() {
  const navigate = useNavigate();
  const { tenantId: currentTenantId, loading: tenantLoading } = useABGTenant();

  const [leads, setLeads] = useState<ABGLead[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Filters
  const [search, setSearch] = useState('');
  const [filterStatus, setFilterStatus] = useState<LeadStatus | 'all'>('all');
  const [filterHeat, setFilterHeat] = useState<LeadHeat | 'all'>('all');
  const [filterSource, setFilterSource] = useState<string>('all');

  useEffect(() => {
    if (tenantLoading) return;
    if (!currentTenantId) { setLoading(false); return; }
    setLoading(true);
    fetchLeads(currentTenantId)
      .then(setLeads)
      .catch((e) => setError(e.message))
      .finally(() => setLoading(false));
  }, [currentTenantId, tenantLoading]);

  // Derived unique sources for filter dropdown
  const sources = useMemo(() => {
    const set = new Set(leads.map((l) => l.source).filter(Boolean));
    return Array.from(set) as string[];
  }, [leads]);

  // Filtered + searched leads
  const filtered = useMemo(() => {
    return leads.filter((lead) => {
      if (filterStatus !== 'all' && lead.status !== filterStatus) return false;
      if (filterHeat   !== 'all' && lead.heat   !== filterHeat)   return false;
      if (filterSource !== 'all' && lead.source  !== filterSource) return false;
      if (search) {
        const q = search.toLowerCase();
        const name = `${lead.first_name ?? ''} ${lead.last_name ?? ''}`.toLowerCase();
        const phone = (lead.phone ?? '').toLowerCase();
        const addr  = `${lead.address ?? ''} ${lead.city ?? ''} ${lead.zip ?? ''}`.toLowerCase();
        if (!name.includes(q) && !phone.includes(q) && !addr.includes(q)) return false;
      }
      return true;
    });
  }, [leads, filterStatus, filterHeat, filterSource, search]);

  if (tenantLoading || loading) {
    return (
      <ABGShell>
        <div className="flex items-center justify-center h-64 gap-2 text-muted-foreground">
          <Loader2 className="h-5 w-5 animate-spin" />
          Loading leads…
        </div>
      </ABGShell>
    );
  }

  if (error) {
    return (
      <ABGShell>
        <div className="flex items-center gap-2 text-red-600 bg-red-50 border border-red-200 rounded-lg p-4">
          <AlertCircle className="h-4 w-4 shrink-0" />
          {error}
        </div>
      </ABGShell>
    );
  }

  return (
    <ABGShell>
      {/* Page header */}
      <div className="flex items-center justify-between mb-5">
        <div>
          <h1 className="text-2xl font-bold text-[#2B2B2B]">Leads</h1>
          <p className="text-sm text-gray-500 mt-0.5">
            {filtered.length} of {leads.length} leads
          </p>
        </div>
      </div>

      {/* Filter bar */}
      <div className="bg-white border border-[#E2E4E8] rounded-lg p-3 mb-4 flex flex-wrap gap-3">
        {/* Search */}
        <div className="relative flex-1 min-w-[200px]">
          <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
          <Input
            placeholder="Name, phone, address…"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-8 h-8 text-sm border-gray-200"
          />
        </div>

        {/* Status filter */}
        <Select
          value={filterStatus}
          onValueChange={(v) => setFilterStatus(v as LeadStatus | 'all')}
        >
          <SelectTrigger className="w-36 h-8 text-sm border-gray-200">
            <SelectValue placeholder="All Status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Status</SelectItem>
            <SelectItem value="new">New</SelectItem>
            <SelectItem value="contacted">Contacted</SelectItem>
            <SelectItem value="in_progress">In Progress</SelectItem>
            <SelectItem value="qualified">Qualified</SelectItem>
            <SelectItem value="converted">Converted</SelectItem>
            <SelectItem value="on_hold">On Hold</SelectItem>
            <SelectItem value="closed_lost">Closed Lost</SelectItem>
          </SelectContent>
        </Select>

        {/* Heat filter */}
        <Select
          value={filterHeat}
          onValueChange={(v) => setFilterHeat(v as LeadHeat | 'all')}
        >
          <SelectTrigger className="w-32 h-8 text-sm border-gray-200">
            <SelectValue placeholder="All Heat" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Heat</SelectItem>
            <SelectItem value="hot">🔥 Hot</SelectItem>
            <SelectItem value="warm">🟡 Warm</SelectItem>
            <SelectItem value="cold">❄️ Cold</SelectItem>
          </SelectContent>
        </Select>

        {/* Source filter */}
        {sources.length > 0 && (
          <Select value={filterSource} onValueChange={setFilterSource}>
            <SelectTrigger className="w-40 h-8 text-sm border-gray-200">
              <SelectValue placeholder="All Sources" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Sources</SelectItem>
              {sources.map((s) => (
                <SelectItem key={s} value={s}>
                  {s === 'adu-levenue' ? 'ADU Levenue' : s === 'abg-direct' ? 'ABG Direct' : s}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        )}
      </div>

      {/* Desktop table */}
      <div className="hidden md:block bg-white border border-[#E2E4E8] rounded-lg overflow-hidden">
        {filtered.length === 0 ? (
          <div className="p-12 text-center text-gray-400 text-sm">
            No leads match your filters.
          </div>
        ) : (
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-[#E2E4E8] bg-[#F5F6F8]">
                <th className="text-left px-4 py-2.5 text-xs font-semibold text-gray-500 uppercase tracking-wide">Name</th>
                <th className="text-left px-4 py-2.5 text-xs font-semibold text-gray-500 uppercase tracking-wide">Source</th>
                <th className="text-left px-4 py-2.5 text-xs font-semibold text-gray-500 uppercase tracking-wide">Status</th>
                <th className="text-left px-4 py-2.5 text-xs font-semibold text-gray-500 uppercase tracking-wide">Heat</th>
                <th className="text-left px-4 py-2.5 text-xs font-semibold text-gray-500 uppercase tracking-wide">Last Touch</th>
                <th className="text-left px-4 py-2.5 text-xs font-semibold text-gray-500 uppercase tracking-wide">Age</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((lead, i) => (
                <tr
                  key={lead.id}
                  onClick={() => navigate(`/abg/portal/leads/${lead.id}`)}
                  className={`border-b border-[#E2E4E8] cursor-pointer hover:bg-[#4A8DB7]/5 transition-colors ${
                    i === filtered.length - 1 ? 'border-b-0' : ''
                  }`}
                >
                  <td className="px-4 py-3">
                    <p className="font-medium text-[#1A1A1A]">
                      {[lead.first_name, lead.last_name].filter(Boolean).join(' ') || '—'}
                    </p>
                    {lead.phone && (
                      <p className="text-xs text-gray-400 mt-0.5">{lead.phone}</p>
                    )}
                  </td>
                  <td className="px-4 py-3">
                    <SourceBadge source={lead.source} />
                  </td>
                  <td className="px-4 py-3">
                    <StatusBadge status={lead.status} />
                  </td>
                  <td className="px-4 py-3">
                    <HeatBadge heat={lead.heat} />
                  </td>
                  <td className="px-4 py-3 text-gray-500">
                    {lead.last_touch_at ? timeAgo(lead.last_touch_at) : (
                      <span className="text-amber-600 font-medium text-xs">Never touched</span>
                    )}
                  </td>
                  <td className="px-4 py-3 text-gray-400 text-xs">
                    {timeAgo(lead.created_at)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {/* Mobile card list */}
      <div className="md:hidden space-y-2">
        {filtered.length === 0 ? (
          <div className="bg-white border border-[#E2E4E8] rounded-lg p-8 text-center text-gray-400 text-sm">
            No leads match your filters.
          </div>
        ) : (
          filtered.map((lead) => (
            <button
              key={lead.id}
              onClick={() => navigate(`/abg/portal/leads/${lead.id}`)}
              className="w-full text-left bg-white border border-[#E2E4E8] rounded-lg p-4 hover:border-[#4A8DB7]/50 transition-colors"
            >
              <div className="flex items-start justify-between gap-2">
                <p className="font-semibold text-[#1A1A1A] text-sm">
                  {[lead.first_name, lead.last_name].filter(Boolean).join(' ') || '—'}
                </p>
                <SourceBadge source={lead.source} />
              </div>
              <div className="flex items-center gap-2 mt-2">
                <StatusBadge status={lead.status} />
                <HeatBadge heat={lead.heat} />
              </div>
              <div className="flex items-center justify-between mt-2 text-xs text-gray-400">
                <span>
                  Last touch:{' '}
                  {lead.last_touch_at ? timeAgo(lead.last_touch_at) : (
                    <span className="text-amber-600 font-medium">Never</span>
                  )}
                </span>
                <span>{timeAgo(lead.created_at)}</span>
              </div>
            </button>
          ))
        )}
      </div>
    </ABGShell>
  );
}
