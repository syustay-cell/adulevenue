import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Building2, FileText, DollarSign, Clock, ArrowRight, Plus } from "lucide-react";
import { useBrand } from "@/contexts/BrandContext";

const ABGDashboard = () => {
  const { brand } = useBrand();

  // Placeholder data - will connect to Wolf Fund backend
  const stats = [
    { label: "Active Applications", value: "2", icon: FileText },
    { label: "Total Funded", value: "$125,000", icon: DollarSign },
    { label: "Pending Review", value: "1", icon: Clock },
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Building2 className="h-8 w-8 text-primary" />
            <span className="text-xl font-bold text-foreground">{brand.name}</span>
          </div>
          <nav className="flex items-center gap-4">
            <Link to="/abg" className="text-muted-foreground hover:text-foreground transition-colors">
              Home
            </Link>
            <Button variant="outline" size="sm">
              Log Out
            </Button>
          </nav>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-foreground">Dashboard</h1>
            <p className="text-muted-foreground">Welcome back to your ABG portal</p>
          </div>
          <Button asChild>
            <Link to="/abg/apply">
              <Plus className="h-4 w-4 mr-2" />
              New Application
            </Link>
          </Button>
        </div>

        {/* Stats */}
        <div className="grid md:grid-cols-3 gap-6 mb-8">
          {stats.map((stat, index) => (
            <Card key={index}>
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">
                  {stat.label}
                </CardTitle>
                <stat.icon className="h-4 w-4 text-primary" />
              </CardHeader>
              <CardContent>
                <p className="text-2xl font-bold text-foreground">{stat.value}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Recent Applications */}
        <Card>
          <CardHeader>
            <CardTitle>Recent Applications</CardTitle>
            <CardDescription>Your latest funding applications</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {/* Placeholder applications */}
              <div className="flex items-center justify-between p-4 border border-border rounded-lg">
                <div>
                  <p className="font-medium text-foreground">Equipment Financing</p>
                  <p className="text-sm text-muted-foreground">Applied Dec 1, 2024</p>
                </div>
                <div className="flex items-center gap-4">
                  <span className="px-2 py-1 text-xs bg-primary/10 text-primary rounded-full">
                    In Review
                  </span>
                  <Button variant="ghost" size="sm">
                    View <ArrowRight className="h-4 w-4 ml-1" />
                  </Button>
                </div>
              </div>

              <div className="flex items-center justify-between p-4 border border-border rounded-lg">
                <div>
                  <p className="font-medium text-foreground">Working Capital</p>
                  <p className="text-sm text-muted-foreground">Funded Nov 15, 2024</p>
                </div>
                <div className="flex items-center gap-4">
                  <span className="px-2 py-1 text-xs bg-green-500/10 text-green-600 rounded-full">
                    Funded
                  </span>
                  <Button variant="ghost" size="sm">
                    View <ArrowRight className="h-4 w-4 ml-1" />
                  </Button>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Info Banner */}
        <Card className="mt-8 bg-muted">
          <CardContent className="p-6">
            <div className="flex items-start gap-4">
              <div className="p-2 bg-primary/10 rounded-lg">
                <Building2 className="h-6 w-6 text-primary" />
              </div>
              <div>
                <h3 className="font-semibold text-foreground mb-1">
                  Connected to Wolf Fund
                </h3>
                <p className="text-sm text-muted-foreground">
                  Your ABG account is powered by Wolf Fund's advanced funding infrastructure. 
                  All your applications, documents, and funding history are securely managed.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  );
};

export default ABGDashboard;
