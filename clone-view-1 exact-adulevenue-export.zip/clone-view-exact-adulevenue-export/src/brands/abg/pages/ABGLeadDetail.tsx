import { useEffect, useState, useCallback } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { useABGTenant } from '../hooks/useABGTenant';
import { ABGShell } from '../components/ABGShell';
import { InlineNextAction } from '../components/InlineNextAction';
import {
  StatusBadge, HeatBadge, SourceBadge,
  FinancingBadge, SpeedBadge, actionTypeLabel,
} from '../components/ABGBadges';
import { timeAgo, formatDateTime, formatDate } from '../lib/time';
import type {
  ABGLead, ABGActivity, ABGNote, ABGNextAction, ABGSequence,
  LeadStatus, LeadHeat, FinancingStatus, NextActionType,
} from '../types';
import {
  ChevronLeft, Phone, MessageSquare, Mail, ArrowRight,
  Loader2, AlertCircle, CheckCircle2, Clock, Edit2,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { cn } from '@/lib/utils';

// ─── Helpers ──────────────────────────────────────────────────────────────────

function actorLabel(actorType: string): string {
  if (actorType === 'system') return 'System';
  if (actorType === 'public_intake') return 'Homeowner (intake)';
  return 'You';
}

function eventLabel(eventType: string, oldVal?: string | null, newVal?: string | null): string {
  const map: Record<string, string> = {
    lead_created:              'Lead created',
    status_changed:            `Status: ${oldVal} → ${newVal}`,
    heat_changed:              `Heat: ${oldVal} → ${newVal}`,
    ownership_changed:         'Ownership changed',
    financing_status_changed:  `Financing: ${oldVal} → ${newVal}`,
    call_logged:               'Call logged',
    text_sent:                 'Text sent',
    email_sent:                'Email sent',
    note_added:                'Note added',
    next_action_set:           'Next action set',
    next_action_completed:     'Next action completed',
    deal_created:              'Converted to deal',
    stage_changed:             `Stage: ${oldVal} → ${newVal}`,
    project_value_set:         `Project value set: ${newVal}`,
    estimated_profit_set:      `Estimated profit set: ${newVal}`,
    wolf_fund_handoff_triggered: 'Routed to Wolf Fund',
    wolf_fund_handoff_failed:  'Wolf Fund handoff failed',
    notification_sent:         'Notification sent',
    notification_failed:       'Notification failed',
    converted_to_deal:         'Converted to deal',
  };
  return map[eventType] ?? eventType;
}

// ─── Supabase helpers ─────────────────────────────────────────────────────────

async function logActivity(
  tenantId: string,
  entityId: string,
  eventType: string,
  payload: {
    actorId?: string | null;
    actorType?: 'worker' | 'system' | 'public_intake';
    oldValue?: string | null;
    newValue?: string | null;
    note?: string | null;
    meta?: Record<string, unknown>;
  }
) {
  const { data: { user } } = await supabase.auth.getUser();
  await supabase.from('abg_activity').insert({
    tenant_id:   tenantId,
    entity_type: 'lead',
    entity_id:   entityId,
    actor_id:    payload.actorId ?? user?.id ?? null,
    actor_type:  payload.actorType ?? 'worker',
    event_type:  eventType,
    old_value:   payload.oldValue ?? null,
    new_value:   payload.newValue ?? null,
    note:        payload.note ?? null,
    meta:        payload.meta ?? {},
  });
}

// ─── Sub-components ───────────────────────────────────────────────────────────

function SectionCard({ title, children, className }: {
  title?: string;
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <div className={cn('bg-white border border-[#E2E4E8] rounded-lg p-4', className)}>
      {title && <h3 className="text-sm font-semibold text-[#2B2B2B] mb-3">{title}</h3>}
      {children}
    </div>
  );
}

function Field({ label, value }: { label: string; value: React.ReactNode }) {
  return (
    <div>
      <p className="text-xs text-gray-400 uppercase tracking-wide mb-0.5">{label}</p>
      <p className="text-sm text-[#1A1A1A] font-medium">{value ?? '—'}</p>
    </div>
  );
}

// ─── Main component ───────────────────────────────────────────────────────────

export default function ABGLeadDetail() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { tenantId: currentTenantId } = useABGTenant();

  const [lead, setLead] = useState<ABGLead | null>(null);
  const [activity, setActivity] = useState<ABGActivity[]>([]);
  const [notes, setNotes] = useState<ABGNote[]>([]);
  const [nextAction, setNextAction] = useState<ABGNextAction | null>(null);
  const [sequence, setSequence] = useState<ABGSequence | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'activity' | 'notes'>('activity');

  // Modal states
  const [callModal, setCallModal]         = useState(false);
  const [textModal, setTextModal]         = useState(false);
  const [emailModal, setEmailModal]       = useState(false);
  const [dealModal, setDealModal]         = useState(false);
  const [newNote, setNewNote]             = useState('');
  const [savingNote, setSavingNote]       = useState(false);
  const [callNote, setCallNote]           = useState('');
  const [callOutcome, setCallOutcome]     = useState('answered');
  const [textBody, setTextBody]           = useState('');
  const [emailSubject, setEmailSubject]   = useState('');
  const [emailBody, setEmailBody]         = useState('');
  const [dealValue, setDealValue]         = useState('');
  const [submitting, setSubmitting]       = useState(false);

  const loadData = useCallback(async () => {
    if (!id || !currentTenantId) return;
    setLoading(true);
    try {
      const [leadRes, activityRes, notesRes, naRes, seqRes] = await Promise.all([
        supabase.from('wf_leads').select('*').eq('id', id).eq('tenant_id', currentTenantId).single(),
        supabase.from('abg_activity').select('*').eq('entity_type', 'lead').eq('entity_id', id).order('created_at', { ascending: false }),
        supabase.from('abg_notes').select('*').eq('entity_type', 'lead').eq('entity_id', id).order('created_at', { ascending: false }),
        supabase.from('abg_next_actions').select('*').eq('entity_type', 'lead').eq('entity_id', id).eq('is_active', true).maybeSingle(),
        supabase.from('abg_follow_up_sequences').select('*').eq('lead_id', id).maybeSingle(),
      ]);
      if (leadRes.error) throw new Error(leadRes.error.message);
      setLead(leadRes.data as ABGLead);
      setActivity((activityRes.data ?? []) as ABGActivity[]);
      setNotes((notesRes.data ?? []) as ABGNote[]);
      setNextAction(naRes.data as ABGNextAction | null);
      setSequence(seqRes.data as ABGSequence | null);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Failed to load lead');
    } finally {
      setLoading(false);
    }
  }, [id, currentTenantId]);

  useEffect(() => { loadData(); }, [loadData]);

  // Pre-fill text/email templates
  useEffect(() => {
    if (!lead) return;
    const name = lead.first_name ?? 'there';
    setTextBody(`Hey ${name}, just following up on your ADU project — let me know a good time to connect.`);
    setEmailSubject(`Following up on your ADU project`);
    setEmailBody(`Hi ${name},\n\nI wanted to follow up on your ADU project at ${lead.address ?? 'your property'}.\n\nLet me know a good time to connect.\n\nBest,\nAdvanced Builders Group\n833.NYC.BUILD`);
  }, [lead]);

  // ── Field updaters ─────────────────────────────────────────────────────────

  const updateField = async (
    field: string,
    value: string,
    eventType: string,
    oldValue?: string,
  ) => {
    if (!lead || !currentTenantId) return;
    await supabase.from('wf_leads').update({ [field]: value, updated_at: new Date().toISOString() }).eq('id', lead.id);
    await logActivity(currentTenantId, lead.id, eventType, { oldValue, newValue: value });
    setLead((prev) => prev ? { ...prev, [field]: value } : prev);
    await loadData();
  };

  // ── Action handlers ────────────────────────────────────────────────────────

  const handleLogCall = async () => {
    if (!lead || !currentTenantId) return;
    setSubmitting(true);
    try {
      const now = new Date().toISOString();
      await supabase.from('wf_leads').update({ last_touch_at: now, updated_at: now }).eq('id', lead.id);
      await logActivity(currentTenantId, lead.id, 'call_logged', {
        note: `Outcome: ${callOutcome}${callNote ? ' — ' + callNote : ''}`,
      });
      setCallModal(false);
      setCallNote('');
      await loadData();
    } finally {
      setSubmitting(false);
    }
  };

  const handleSendText = async () => {
    if (!lead || !currentTenantId) return;
    setSubmitting(true);
    try {
      const now = new Date().toISOString();
      await supabase.from('wf_leads').update({ last_touch_at: now, updated_at: now }).eq('id', lead.id);
      await logActivity(currentTenantId, lead.id, 'text_sent', { note: textBody });
      setTextModal(false);
      await loadData();
    } finally {
      setSubmitting(false);
    }
  };

  const handleSendEmail = async () => {
    if (!lead || !currentTenantId) return;
    setSubmitting(true);
    try {
      const now = new Date().toISOString();
      await supabase.from('wf_leads').update({ last_touch_at: now, updated_at: now }).eq('id', lead.id);
      await logActivity(currentTenantId, lead.id, 'email_sent', {
        note: `Subject: ${emailSubject}`,
        meta: { subject: emailSubject, body: emailBody },
      });
      setEmailModal(false);
      await loadData();
    } finally {
      setSubmitting(false);
    }
  };

  const handleAddNote = async () => {
    if (!lead || !currentTenantId || !newNote.trim()) return;
    setSavingNote(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      await supabase.from('abg_notes').insert({
        tenant_id:   currentTenantId,
        entity_type: 'lead',
        entity_id:   lead.id,
        author_id:   user?.id ?? '',
        body:        newNote.trim(),
      });
      await logActivity(currentTenantId, lead.id, 'note_added', {});
      setNewNote('');
      await loadData();
    } finally {
      setSavingNote(false);
    }
  };

  const handleConvertToDeal = async () => {
    if (!lead || !currentTenantId) return;
    setSubmitting(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      const { data: deal, error: dealError } = await supabase
        .from('abg_deals')
        .insert({
          tenant_id:   currentTenantId,
          lead_id:     lead.id,
          owner_id:    user?.id,
          stage:       'active',
          project_value: dealValue ? parseFloat(dealValue) : null,
          financing_status: lead.financing_status,
        })
        .select()
        .single();

      if (dealError) throw new Error(dealError.message);

      const now = new Date().toISOString();
      await supabase.from('wf_leads').update({
        status: 'converted',
        converted_to_deal_at: now,
        updated_at: now,
      }).eq('id', lead.id);

      await logActivity(currentTenantId, lead.id, 'converted_to_deal', {
        newValue: deal.id,
        meta: { deal_id: deal.id },
      });

      setDealModal(false);
      navigate(`/abg/portal/deals/${deal.id}`);
    } finally {
      setSubmitting(false);
    }
  };

  const handleWolfFundHandoff = async () => {
    if (!lead || !currentTenantId) return;
    try {
      await supabase.from('wf_leads').update({ financing_status: 'wolf_fund_working', updated_at: new Date().toISOString() }).eq('id', lead.id);
      await logActivity(currentTenantId, lead.id, 'wolf_fund_handoff_triggered', {
        oldValue: lead.financing_status,
        newValue: 'wolf_fund_working',
      });
      setLead((prev) => prev ? { ...prev, financing_status: 'wolf_fund_working' } : prev);
    } catch {
      await logActivity(currentTenantId, lead.id, 'wolf_fund_handoff_failed', {});
    }
  };

  // ─── Render ────────────────────────────────────────────────────────────────

  if (loading) {
    return (
      <ABGShell>
        <div className="flex items-center justify-center h-64 gap-2 text-muted-foreground">
          <Loader2 className="h-5 w-5 animate-spin" />
          Loading lead…
        </div>
      </ABGShell>
    );
  }

  if (error || !lead) {
    return (
      <ABGShell>
        <div className="flex items-center gap-2 text-red-600 bg-red-50 border border-red-200 rounded-lg p-4">
          <AlertCircle className="h-4 w-4 shrink-0" />
          {error ?? 'Lead not found'}
        </div>
      </ABGShell>
    );
  }

  const fullName = [lead.first_name, lead.last_name].filter(Boolean).join(' ') || 'Unnamed Lead';
  const fullAddress = [lead.address, lead.city, lead.state, lead.zip].filter(Boolean).join(', ');

  return (
    <ABGShell>
      {/* Back + header */}
      <div className="flex items-start justify-between mb-4">
        <div>
          <button
            onClick={() => navigate('/abg/portal/leads')}
            className="flex items-center gap-1 text-gray-400 hover:text-[#2B2B2B] text-sm mb-1 transition-colors"
          >
            <ChevronLeft className="h-4 w-4" />
            Leads
          </button>
          <h1 className="text-2xl font-bold text-[#2B2B2B]">{fullName}</h1>
          <div className="flex items-center gap-2 mt-1.5 flex-wrap">
            <StatusBadge status={lead.status} />
            <HeatBadge heat={lead.heat} />
            <SourceBadge source={lead.source} />
            {lead.response_time_seconds !== null && (
              <SpeedBadge seconds={lead.response_time_seconds} />
            )}
          </div>
        </div>

        {/* Convert to deal (if not already) */}
        {lead.status !== 'converted' && (
          <Button
            onClick={() => setDealModal(true)}
            className="bg-[#2B2B2B] hover:bg-[#4A8DB7] text-white shrink-0 hidden md:flex"
          >
            Convert to Deal
            <ArrowRight className="h-4 w-4 ml-1.5" />
          </Button>
        )}
      </div>

      {/* Body grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">

        {/* Left column */}
        <div className="lg:col-span-2 space-y-4">

          {/* Overview */}
          <SectionCard title="Overview">
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              <Field label="Phone"    value={lead.phone} />
              <Field label="Email"    value={lead.email} />
              <Field label="Address"  value={fullAddress || null} />
              <Field label="Intended Use"    value={lead.intended_use} />
              <Field label="Referral Source" value={lead.referral_source} />
              <Field label="Arrived"         value={formatDateTime(lead.created_at)} />
              <Field label="Last Touch"      value={lead.last_touch_at ? timeAgo(lead.last_touch_at) : 'Never touched'} />
              <Field label="Homeowner Notes" value={lead.notes} />
            </div>
          </SectionCard>

          {/* Inline next action */}
          <SectionCard title="Next Action">
            <InlineNextAction
              value={lead.next_action}
              dueAt={lead.next_action_due}
              onSave={async (action, due) => {
                await supabase.from('wf_leads').update({
                  next_action: action,
                  next_action_due: due,
                  updated_at: new Date().toISOString(),
                }).eq('id', lead.id);
                setLead((prev) => prev ? { ...prev, next_action: action, next_action_due: due } : prev);
              }}
              placeholder="Set next action for this lead…"
            />
          </SectionCard>

          {/* Status + Heat editors */}
          <SectionCard title="Lead Controls">
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              <div>
                <Label className="text-xs text-gray-400 uppercase tracking-wide mb-1 block">Status</Label>
                <Select
                  value={lead.status}
                  onValueChange={(v) => updateField('status', v, 'status_changed', lead.status)}
                >
                  <SelectTrigger className="h-8 text-sm">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {(['new','contacted','in_progress','qualified','on_hold','closed_lost'] as LeadStatus[]).map((s) => (
                      <SelectItem key={s} value={s}>{s.replace(/_/g, ' ')}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label className="text-xs text-gray-400 uppercase tracking-wide mb-1 block">Heat</Label>
                <Select
                  value={lead.heat}
                  onValueChange={(v) => updateField('heat', v, 'heat_changed', lead.heat)}
                >
                  <SelectTrigger className="h-8 text-sm">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="hot">🔥 Hot</SelectItem>
                    <SelectItem value="warm">🟡 Warm</SelectItem>
                    <SelectItem value="cold">❄️ Cold</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </SectionCard>

          {/* Financing */}
          <SectionCard title="Financing">
            <div className="flex items-center gap-3 flex-wrap">
              <div>
                <Label className="text-xs text-gray-400 uppercase tracking-wide mb-1 block">Status</Label>
                <Select
                  value={lead.financing_status}
                  onValueChange={(v) => updateField('financing_status', v, 'financing_status_changed', lead.financing_status)}
                >
                  <SelectTrigger className="h-8 text-sm w-52">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="unknown">Unknown / Not discussed</SelectItem>
                    <SelectItem value="already_covered">Already covered</SelectItem>
                    <SelectItem value="needs_financing">Needs financing</SelectItem>
                    <SelectItem value="wolf_fund_working">Wolf Fund working it</SelectItem>
                    <SelectItem value="confirmed">Financing confirmed</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              {lead.financing_status === 'needs_financing' && (
                <Button
                  size="sm"
                  variant="outline"
                  onClick={handleWolfFundHandoff}
                  className="border-[#4A8DB7] text-[#4A8DB7] hover:bg-[#4A8DB7]/10 mt-4"
                >
                  Route to Wolf Fund →
                </Button>
              )}
            </div>
          </SectionCard>

          {/* Action bar — mobile */}
          <div className="md:hidden">
            {lead.status !== 'converted' && (
              <Button
                onClick={() => setDealModal(true)}
                className="w-full bg-[#2B2B2B] hover:bg-[#4A8DB7] text-white"
              >
                Convert to Deal <ArrowRight className="h-4 w-4 ml-1.5" />
              </Button>
            )}
          </div>

          {/* Activity / Notes tabs */}
          <SectionCard>
            <div className="flex gap-1 mb-4 border-b border-[#E2E4E8]">
              {(['activity', 'notes'] as const).map((tab) => (
                <button
                  key={tab}
                  onClick={() => setActiveTab(tab)}
                  className={cn(
                    'px-4 py-1.5 text-sm font-medium capitalize border-b-2 -mb-px transition-colors',
                    activeTab === tab
                      ? 'border-[#4A8DB7] text-[#4A8DB7]'
                      : 'border-transparent text-gray-400 hover:text-[#2B2B2B]'
                  )}
                >
                  {tab === 'activity' ? 'Activity Timeline' : 'Notes'}
                </button>
              ))}
            </div>

            {/* Activity timeline */}
            {activeTab === 'activity' && (
              <div className="space-y-3">
                {activity.length === 0 ? (
                  <p className="text-sm text-gray-400">No activity yet.</p>
                ) : (
                  activity.map((ev) => (
                    <div key={ev.id} className="flex gap-3 text-sm">
                      <div className="shrink-0 w-1.5 h-1.5 rounded-full bg-[#4A8DB7] mt-2" />
                      <div className="flex-1">
                        <p className="text-[#1A1A1A]">
                          {eventLabel(ev.event_type, ev.old_value, ev.new_value)}
                        </p>
                        {ev.note && (
                          <p className="text-gray-400 text-xs mt-0.5 italic">"{ev.note}"</p>
                        )}
                        <p className="text-gray-300 text-xs mt-0.5">
                          {formatDateTime(ev.created_at)} · {actorLabel(ev.actor_type)}
                        </p>
                      </div>
                    </div>
                  ))
                )}
              </div>
            )}

            {/* Notes */}
            {activeTab === 'notes' && (
              <div className="space-y-4">
                <div className="space-y-2">
                  <Textarea
                    placeholder="Add a note…"
                    value={newNote}
                    onChange={(e) => setNewNote(e.target.value)}
                    className="text-sm resize-none"
                    rows={3}
                  />
                  <Button
                    size="sm"
                    onClick={handleAddNote}
                    disabled={savingNote || !newNote.trim()}
                    className="bg-[#4A8DB7] hover:bg-[#4A8DB7]/90 text-white"
                  >
                    {savingNote ? <Loader2 className="h-3 w-3 animate-spin mr-1" /> : null}
                    Save Note
                  </Button>
                </div>
                {notes.length === 0 ? (
                  <p className="text-sm text-gray-400">No notes yet.</p>
                ) : (
                  notes.map((note) => (
                    <div key={note.id} className="border border-[#E2E4E8] rounded p-3 text-sm">
                      <p className="text-[#1A1A1A]">{note.body}</p>
                      <p className="text-gray-300 text-xs mt-1">{formatDateTime(note.created_at)}</p>
                    </div>
                  ))
                )}
              </div>
            )}
          </SectionCard>
        </div>

        {/* Right column */}
        <div className="space-y-4">

          {/* Action bar */}
          <SectionCard title="Actions">
            <div className="space-y-2">
              <Button
                variant="outline"
                className="w-full justify-start border-[#E2E4E8] hover:border-[#4A8DB7] hover:text-[#4A8DB7]"
                onClick={() => setCallModal(true)}
              >
                <Phone className="h-4 w-4 mr-2" />
                Log Call
              </Button>
              <Button
                variant="outline"
                className="w-full justify-start border-[#E2E4E8] hover:border-[#4A8DB7] hover:text-[#4A8DB7]"
                onClick={() => setTextModal(true)}
              >
                <MessageSquare className="h-4 w-4 mr-2" />
                Send Text
              </Button>
              <Button
                variant="outline"
                className="w-full justify-start border-[#E2E4E8] hover:border-[#4A8DB7] hover:text-[#4A8DB7]"
                onClick={() => setEmailModal(true)}
              >
                <Mail className="h-4 w-4 mr-2" />
                Send Email
              </Button>
            </div>
          </SectionCard>

          {/* Next action */}
          {nextAction && (
            <SectionCard title="Next Action">
              <div className="space-y-2">
                <p className="text-sm font-medium text-[#1A1A1A]">
                  {actionTypeLabel(nextAction.action_type, nextAction.custom_label)}
                </p>
                <p className="text-xs text-gray-400 flex items-center gap-1">
                  <Clock className="h-3.5 w-3.5" />
                  Due: {formatDateTime(nextAction.due_at)}
                </p>
                <Button
                  size="sm"
                  onClick={async () => {
                    if (!currentTenantId) return;
                    await supabase.from('abg_next_actions').update({
                      is_active: false,
                      completed_at: new Date().toISOString(),
                    }).eq('id', nextAction.id);
                    await logActivity(currentTenantId, lead.id, 'next_action_completed', {
                      newValue: nextAction.action_type,
                    });
                    await loadData();
                  }}
                  className="w-full bg-green-600 hover:bg-green-700 text-white"
                >
                  <CheckCircle2 className="h-4 w-4 mr-1.5" />
                  Mark Complete
                </Button>
              </div>
            </SectionCard>
          )}

          {/* Follow-up sequence */}
          {sequence && (
            <SectionCard title="Follow-Up Sequence">
              <p className="text-sm text-gray-500">
                Step {sequence.sequence_step + 1} · {sequence.status}
              </p>
              <p className="text-xs text-gray-400 mt-1">
                Next: {formatDate(sequence.next_due_at)}
              </p>
            </SectionCard>
          )}

          {/* Meta */}
          <SectionCard>
            <div className="space-y-2 text-xs text-gray-400">
              <p>Source locked: {formatDateTime(lead.source_locked_at)}</p>
              <p>Created: {formatDateTime(lead.created_at)}</p>
              <p>Last updated: {timeAgo(lead.updated_at)}</p>
            </div>
          </SectionCard>
        </div>
      </div>

      {/* ── Modals ─────────────────────────────────────────────────────────── */}

      {/* Log Call */}
      <Dialog open={callModal} onOpenChange={setCallModal}>
        <DialogContent>
          <DialogHeader><DialogTitle>Log Call</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <div>
              <Label>Outcome</Label>
              <Select value={callOutcome} onValueChange={setCallOutcome}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="answered">Answered</SelectItem>
                  <SelectItem value="voicemail">Voicemail</SelectItem>
                  <SelectItem value="no_answer">No answer</SelectItem>
                  <SelectItem value="bad_number">Bad number</SelectItem>
                  <SelectItem value="callback_scheduled">Callback scheduled</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Note (optional)</Label>
              <Textarea
                value={callNote}
                onChange={(e) => setCallNote(e.target.value)}
                placeholder="What happened on the call…"
                rows={3}
                className="text-sm"
              />
            </div>
            <Button onClick={handleLogCall} disabled={submitting} className="w-full bg-[#4A8DB7] hover:bg-[#4A8DB7]/90 text-white">
              {submitting ? <Loader2 className="h-4 w-4 animate-spin mr-1" /> : null}
              Log Call
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Send Text */}
      <Dialog open={textModal} onOpenChange={setTextModal}>
        <DialogContent>
          <DialogHeader><DialogTitle>Send Text</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <div>
              <Label>Message</Label>
              <Textarea
                value={textBody}
                onChange={(e) => setTextBody(e.target.value)}
                rows={4}
                className="text-sm"
              />
            </div>
            <p className="text-xs text-gray-400">To: {lead.phone ?? '(no phone on file)'}</p>
            <Button onClick={handleSendText} disabled={submitting || !textBody.trim()} className="w-full bg-[#4A8DB7] hover:bg-[#4A8DB7]/90 text-white">
              {submitting ? <Loader2 className="h-4 w-4 animate-spin mr-1" /> : null}
              Send Text
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Send Email */}
      <Dialog open={emailModal} onOpenChange={setEmailModal}>
        <DialogContent>
          <DialogHeader><DialogTitle>Send Email</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <div>
              <Label>Subject</Label>
              <Input value={emailSubject} onChange={(e) => setEmailSubject(e.target.value)} className="text-sm" />
            </div>
            <div>
              <Label>Body</Label>
              <Textarea value={emailBody} onChange={(e) => setEmailBody(e.target.value)} rows={6} className="text-sm" />
            </div>
            <p className="text-xs text-gray-400">To: {lead.email ?? '(no email on file)'}</p>
            <Button onClick={handleSendEmail} disabled={submitting || !emailBody.trim()} className="w-full bg-[#4A8DB7] hover:bg-[#4A8DB7]/90 text-white">
              {submitting ? <Loader2 className="h-4 w-4 animate-spin mr-1" /> : null}
              Send Email
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Convert to Deal */}
      <Dialog open={dealModal} onOpenChange={setDealModal}>
        <DialogContent>
          <DialogHeader><DialogTitle>Convert to Deal</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <p className="text-sm text-gray-500">
              This will create a new deal linked to {fullName}. The lead remains visible and linked.
            </p>
            <div>
              <Label>Project Value (optional)</Label>
              <div className="relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 text-sm">$</span>
                <Input
                  type="number"
                  value={dealValue}
                  onChange={(e) => setDealValue(e.target.value)}
                  placeholder="e.g. 85000"
                  className="pl-7 text-sm"
                />
              </div>
            </div>
            <Button onClick={handleConvertToDeal} disabled={submitting} className="w-full bg-[#2B2B2B] hover:bg-[#4A8DB7] text-white">
              {submitting ? <Loader2 className="h-4 w-4 animate-spin mr-1" /> : null}
              Create Deal
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </ABGShell>
  );
}
