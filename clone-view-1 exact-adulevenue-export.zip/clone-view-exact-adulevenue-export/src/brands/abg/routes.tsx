import { lazy, Suspense } from "react";
import { Routes, Route, Navigate } from "react-router-dom";
import { Loader2 } from "lucide-react";

// ABG public pages
const ABGHome     = lazy(() => import("./pages/ABGHome"));
const ABGServices = lazy(() => import("./pages/ABGServices"));
const ABGApply    = lazy(() => import("./pages/ABGApply"));

// ABG portal — operating system screens + execution lite
const ABGLeadInbox    = lazy(() => import("./pages/ABGLeadInbox"));
const ABGLeadDetail   = lazy(() => import("./pages/ABGLeadDetail"));
const ABGTodaysWork   = lazy(() => import("./pages/ABGTodaysWork"));
const ABGDealPipeline = lazy(() => import("./pages/ABGDealPipeline"));
const ABGDealDetail   = lazy(() => import("./pages/ABGDealDetail"));
const ABGStuckMoney   = lazy(() => import("./pages/ABGStuckMoney"));
const ABGJobList      = lazy(() => import("./pages/ABGJobList"));
const ABGJobDetail    = lazy(() => import("./pages/ABGJobDetail"));

// ABG Subcontractor portal — separate login + isolated views
const ABGSubLogin     = lazy(() => import("./pages/ABGSubLogin"));
const ABGSubJobList   = lazy(() => import("./pages/ABGSubJobList"));
const ABGSubJobDetail = lazy(() => import("./pages/ABGSubJobDetail"));

const ABGLoader = () => (
  <div className="min-h-screen flex items-center justify-center bg-[#F5F6F8]">
    <div className="flex items-center gap-2 text-[#4A8DB7]">
      <Loader2 className="h-5 w-5 animate-spin" />
      <span className="text-sm font-medium">Advanced Builders Group</span>
    </div>
  </div>
);

/**
 * ROUTING ARCHITECTURE
 *
 * Development / internal (current):
 *   app.wolf-fund.com/abg/*
 *
 * Production target (advancebuildersgroup.com):
 *   advancebuildersgroup.com/          → public marketing site (ABGHome)
 *   advancebuildersgroup.com/portal    → redirect to /portal/today
 *   advancebuildersgroup.com/portal/*  → ABG authenticated portal
 *
 * How the transition works:
 *   When deployed to advancebuildersgroup.com via Cloudflare Pages, the
 *   App.tsx root route for /abg/* still serves these components. The Cloudflare
 *   Pages _redirects file at the domain level rewrites:
 *     /portal/*  →  /abg/portal/*  (200 rewrite, not redirect)
 *   so the user sees /portal/* in the address bar while the SPA serves /abg/*.
 *
 *   ABGShell nav links use PORTAL_BASE (defined below) so they emit the correct
 *   URLs whether the app is on wolf-fund.com/abg or advancebuildersgroup.com/portal.
 *
 * /abg/* is the permanent INTERNAL route prefix used by the SPA router.
 * /portal/* is the permanent EXTERNAL route prefix seen by the user on the ABG domain.
 * These two are equivalent via Cloudflare rewrite — no code duplication.
 */
export const PORTAL_BASE = "/abg";

export function ABGRoutes() {
  return (
    <Suspense fallback={<ABGLoader />}>
      <Routes>
        {/* ── Public marketing routes ──────────────────────────── */}
        <Route path="/"         element={<ABGHome />} />
        <Route path="/services" element={<ABGServices />} />
        <Route path="/apply"    element={<ABGApply />} />

        {/* ── Portal entry redirect ─────────────────────────────
            /abg/portal → /abg/portal/today
            On advancebuildersgroup.com, Cloudflare rewrites
            /portal → /abg/portal which then hits this redirect. */}
        <Route path="/portal" element={<Navigate to="/abg/portal/today" replace />} />

        {/* ── Authenticated portal screens ─────────────────────
            Internal SPA routes: /abg/portal/*
            External user-facing (ABG domain): /portal/* */}
        <Route path="/portal/today"        element={<ABGTodaysWork />} />
        <Route path="/portal/leads"        element={<ABGLeadInbox />} />
        <Route path="/portal/leads/:id"    element={<ABGLeadDetail />} />
        <Route path="/portal/deals"        element={<ABGDealPipeline />} />
        <Route path="/portal/deals/:id"    element={<ABGDealDetail />} />
        <Route path="/portal/stuck-money"  element={<ABGStuckMoney />} />
        <Route path="/portal/jobs"         element={<ABGJobList />} />
        <Route path="/portal/jobs/:id"     element={<ABGJobDetail />} />

        {/* ── Sub portal (separate auth, no ABGShell) ──── */}
        <Route path="/subs/login"          element={<ABGSubLogin />} />
        <Route path="/subs/jobs"           element={<ABGSubJobList />} />
        <Route path="/subs/jobs/:jobId"    element={<ABGSubJobDetail />} />

        {/* ── Legacy /abg/today etc. redirects (dev convenience) */}
        <Route path="/today"       element={<Navigate to="/abg/portal/today" replace />} />
        <Route path="/leads"       element={<Navigate to="/abg/portal/leads" replace />} />
        <Route path="/leads/:id"   element={<Navigate to="/abg/portal/leads/:id" replace />} />
        <Route path="/deals"       element={<Navigate to="/abg/portal/deals" replace />} />
        <Route path="/deals/:id"   element={<Navigate to="/abg/portal/deals/:id" replace />} />
        <Route path="/stuck-money" element={<Navigate to="/abg/portal/stuck-money" replace />} />
        <Route path="/dashboard"   element={<Navigate to="/abg/portal/today" replace />} />

        {/* ── Catch-all ─────────────────────────────────────── */}
        <Route path="*" element={<Navigate to="/abg/portal/today" replace />} />
      </Routes>
    </Suspense>
  );
}

export default ABGRoutes;
