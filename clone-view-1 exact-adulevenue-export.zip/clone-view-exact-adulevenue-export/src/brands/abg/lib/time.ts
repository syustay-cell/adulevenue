// ABG time formatting utilities

export function timeAgo(dateStr: string | null): string {
  if (!dateStr) return 'Never';
  const diff = Date.now() - new Date(dateStr).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 1)  return 'Just now';
  if (mins < 60) return `${mins} min ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24)  return `${hrs}h ago`;
  const days = Math.floor(hrs / 24);
  return `${days}d ago`;
}

export function formatDateTime(dateStr: string | null): string {
  if (!dateStr) return '—';
  return new Date(dateStr).toLocaleString('en-US', {
    month: 'short', day: 'numeric',
    hour: 'numeric', minute: '2-digit', hour12: true,
  });
}

export function formatDate(dateStr: string | null): string {
  if (!dateStr) return '—';
  return new Date(dateStr).toLocaleDateString('en-US', {
    month: 'short', day: 'numeric', year: 'numeric',
  });
}

export function daysAgo(dateStr: string | null): number {
  if (!dateStr) return 0;
  return Math.floor((Date.now() - new Date(dateStr).getTime()) / 86400000);
}

export function daysInStage(stageEnteredAt: string): number {
  return Math.floor((Date.now() - new Date(stageEnteredAt).getTime()) / 86400000);
}

export function velocityStatus(
  stage: string,
  days: number
): 'on_track' | 'slowing' | 'stalled' {
  const thresholds: Record<string, [number, number]> = {
    active:   [2, 4],
    proposal: [5, 8],
    signed:   [10, 15],
  };
  const [green, red] = thresholds[stage] ?? [999, 999];
  if (days <= green) return 'on_track';
  if (days <= red)   return 'slowing';
  return 'stalled';
}

export function formatCurrency(value: number | null): string {
  if (value === null || value === undefined) return '—';
  if (value >= 1000000) return `$${(value / 1000000).toFixed(1)}M`;
  if (value >= 1000)    return `$${Math.round(value / 1000)}K`;
  return `$${value.toLocaleString()}`;
}

export function minutesAgoLabel(seconds: number | null): string {
  if (seconds === null) return '';
  const mins = Math.round(seconds / 60);
  return mins < 60 ? `${mins} min` : `${Math.round(mins / 60)}h`;
}
