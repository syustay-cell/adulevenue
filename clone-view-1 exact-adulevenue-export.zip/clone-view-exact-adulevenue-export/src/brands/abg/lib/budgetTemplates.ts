/**
 * ABG Preliminary Budget Templates
 *
 * Static trade cost ranges per job type.
 * No AI. No external APIs. Instant response.
 *
 * Ranges are per-unit costs. If square_footage is provided,
 * costs scale proportionally within the range.
 * If no square_footage, the midpoint of the range is used.
 *
 * All values in USD.
 */

import type { TradeType } from '../types';

export type JobType =
  | 'adu_studio'
  | 'adu_1br'
  | 'adu_2br'
  | 'garage_conversion'
  | 'renovation_kitchen'
  | 'renovation_bathroom'
  | 'addition'
  | 'ground_up';

export interface TradeEstimate {
  trade_type: TradeType;
  label: string;
  low: number;
  high: number;
  scope_of_work: string;
}

export interface BudgetTemplate {
  job_type: JobType;
  label: string;
  base_sqft: number;           // reference square footage for the ranges
  trades: TradeEstimate[];
}

const TEMPLATES: Record<JobType, BudgetTemplate> = {

  adu_studio: {
    job_type: 'adu_studio',
    label: 'ADU — Studio (up to 400 sqft)',
    base_sqft: 350,
    trades: [
      { trade_type: 'framing',     label: 'Framing & Structure',   low: 12000, high: 18000, scope_of_work: 'Wall framing, roof structure, sheathing' },
      { trade_type: 'electrical',  label: 'Electrical',            low: 8000,  high: 12000, scope_of_work: 'Rough-in, panel, fixtures, final' },
      { trade_type: 'plumbing',    label: 'Plumbing',              low: 9000,  high: 14000, scope_of_work: 'Rough-in, fixtures, water heater' },
      { trade_type: 'hvac',        label: 'HVAC / Mini-split',     low: 4000,  high: 7000,  scope_of_work: 'Mini-split installation, ventilation' },
      { trade_type: 'drywall',     label: 'Drywall',               low: 5000,  high: 8000,  scope_of_work: 'Hang, tape, mud, prime' },
      { trade_type: 'flooring',    label: 'Flooring',              low: 3500,  high: 6000,  scope_of_work: 'LVP or tile throughout' },
      { trade_type: 'painting',    label: 'Painting',              low: 2500,  high: 4000,  scope_of_work: 'Interior walls, trim, doors' },
      { trade_type: 'windows',     label: 'Windows & Doors',       low: 4000,  high: 7000,  scope_of_work: 'Windows, exterior door, interior doors' },
      { trade_type: 'concrete',    label: 'Foundation / Slab',     low: 8000,  high: 14000, scope_of_work: 'Slab foundation with rebar' },
      { trade_type: 'insulation',  label: 'Insulation',            low: 2500,  high: 4000,  scope_of_work: 'Walls, ceiling, vapor barrier' },
      { trade_type: 'roofing',     label: 'Roofing',               low: 5000,  high: 9000,  scope_of_work: 'Shingles, underlayment, flashing' },
      { trade_type: 'general',     label: 'GC / Permits / Misc',   low: 8000,  high: 14000, scope_of_work: 'Permits, inspections, GC overhead, cleanup' },
    ],
  },

  adu_1br: {
    job_type: 'adu_1br',
    label: 'ADU — 1 Bedroom (400–650 sqft)',
    base_sqft: 500,
    trades: [
      { trade_type: 'framing',     label: 'Framing & Structure',   low: 18000, high: 26000, scope_of_work: 'Wall framing, roof structure, sheathing' },
      { trade_type: 'electrical',  label: 'Electrical',            low: 11000, high: 16000, scope_of_work: 'Rough-in, panel, fixtures, final' },
      { trade_type: 'plumbing',    label: 'Plumbing',              low: 12000, high: 18000, scope_of_work: 'Rough-in, fixtures, water heater' },
      { trade_type: 'hvac',        label: 'HVAC / Mini-split',     low: 5000,  high: 9000,  scope_of_work: 'Mini-split installation, ventilation' },
      { trade_type: 'drywall',     label: 'Drywall',               low: 7000,  high: 11000, scope_of_work: 'Hang, tape, mud, prime' },
      { trade_type: 'flooring',    label: 'Flooring',              low: 5000,  high: 8500,  scope_of_work: 'LVP or tile throughout' },
      { trade_type: 'painting',    label: 'Painting',              low: 3500,  high: 5500,  scope_of_work: 'Interior walls, trim, doors' },
      { trade_type: 'windows',     label: 'Windows & Doors',       low: 5500,  high: 9000,  scope_of_work: 'Windows, exterior door, interior doors' },
      { trade_type: 'concrete',    label: 'Foundation / Slab',     low: 11000, high: 18000, scope_of_work: 'Slab foundation with rebar' },
      { trade_type: 'insulation',  label: 'Insulation',            low: 3500,  high: 5500,  scope_of_work: 'Walls, ceiling, vapor barrier' },
      { trade_type: 'roofing',     label: 'Roofing',               low: 7000,  high: 12000, scope_of_work: 'Shingles, underlayment, flashing' },
      { trade_type: 'general',     label: 'GC / Permits / Misc',   low: 12000, high: 20000, scope_of_work: 'Permits, inspections, GC overhead, cleanup' },
    ],
  },

  adu_2br: {
    job_type: 'adu_2br',
    label: 'ADU — 2 Bedroom (650–1200 sqft)',
    base_sqft: 850,
    trades: [
      { trade_type: 'framing',     label: 'Framing & Structure',   low: 26000, high: 40000, scope_of_work: 'Wall framing, roof structure, sheathing' },
      { trade_type: 'electrical',  label: 'Electrical',            low: 16000, high: 24000, scope_of_work: 'Rough-in, panel, fixtures, final' },
      { trade_type: 'plumbing',    label: 'Plumbing',              low: 18000, high: 28000, scope_of_work: 'Rough-in, fixtures, 2 baths, water heater' },
      { trade_type: 'hvac',        label: 'HVAC',                  low: 8000,  high: 14000, scope_of_work: 'Mini-split system, ventilation' },
      { trade_type: 'drywall',     label: 'Drywall',               low: 11000, high: 17000, scope_of_work: 'Hang, tape, mud, prime' },
      { trade_type: 'flooring',    label: 'Flooring',              low: 8000,  high: 13000, scope_of_work: 'LVP or tile throughout' },
      { trade_type: 'painting',    label: 'Painting',              low: 5000,  high: 8000,  scope_of_work: 'Interior walls, trim, doors' },
      { trade_type: 'windows',     label: 'Windows & Doors',       low: 8000,  high: 13000, scope_of_work: 'Windows, exterior door, interior doors' },
      { trade_type: 'concrete',    label: 'Foundation / Slab',     low: 16000, high: 28000, scope_of_work: 'Slab foundation with rebar' },
      { trade_type: 'insulation',  label: 'Insulation',            low: 5500,  high: 8500,  scope_of_work: 'Walls, ceiling, vapor barrier' },
      { trade_type: 'roofing',     label: 'Roofing',               low: 11000, high: 18000, scope_of_work: 'Shingles, underlayment, flashing' },
      { trade_type: 'general',     label: 'GC / Permits / Misc',   low: 18000, high: 30000, scope_of_work: 'Permits, inspections, GC overhead, cleanup' },
    ],
  },

  garage_conversion: {
    job_type: 'garage_conversion',
    label: 'Garage Conversion',
    base_sqft: 400,
    trades: [
      { trade_type: 'framing',     label: 'Framing & Insulation',  low: 8000,  high: 14000, scope_of_work: 'Stud walls, door/window framing' },
      { trade_type: 'electrical',  label: 'Electrical',            low: 6000,  high: 10000, scope_of_work: 'Panel upgrade, rough-in, fixtures' },
      { trade_type: 'plumbing',    label: 'Plumbing',              low: 7000,  high: 12000, scope_of_work: 'Rough-in, bathroom fixtures' },
      { trade_type: 'hvac',        label: 'HVAC / Mini-split',     low: 3500,  high: 6000,  scope_of_work: 'Mini-split installation' },
      { trade_type: 'drywall',     label: 'Drywall',               low: 4000,  high: 7000,  scope_of_work: 'Hang, tape, mud, prime' },
      { trade_type: 'flooring',    label: 'Flooring',              low: 3000,  high: 5500,  scope_of_work: 'LVP over slab' },
      { trade_type: 'painting',    label: 'Painting',              low: 2000,  high: 3500,  scope_of_work: 'Interior walls, trim' },
      { trade_type: 'windows',     label: 'Windows & Doors',       low: 3500,  high: 6000,  scope_of_work: 'Windows, new entry door, garage door infill' },
      { trade_type: 'concrete',    label: 'Slab Prep',             low: 2000,  high: 4000,  scope_of_work: 'Slab leveling, moisture barrier' },
      { trade_type: 'insulation',  label: 'Insulation',            low: 2000,  high: 3500,  scope_of_work: 'Walls, ceiling, vapor barrier' },
      { trade_type: 'general',     label: 'GC / Permits / Misc',   low: 6000,  high: 11000, scope_of_work: 'Permits, inspections, GC overhead, cleanup' },
    ],
  },

  renovation_kitchen: {
    job_type: 'renovation_kitchen',
    label: 'Kitchen Renovation',
    base_sqft: 200,
    trades: [
      { trade_type: 'electrical',  label: 'Electrical',            low: 4000,  high: 7000,  scope_of_work: 'Circuits, outlets, under-cabinet lighting' },
      { trade_type: 'plumbing',    label: 'Plumbing',              low: 3500,  high: 6000,  scope_of_work: 'Sink, dishwasher, garbage disposal' },
      { trade_type: 'drywall',     label: 'Drywall / Patching',    low: 1500,  high: 3000,  scope_of_work: 'Patch and repair after demo' },
      { trade_type: 'flooring',    label: 'Flooring',              low: 2500,  high: 5000,  scope_of_work: 'Tile or LVP' },
      { trade_type: 'painting',    label: 'Painting',              low: 1500,  high: 3000,  scope_of_work: 'Walls, trim, ceiling' },
      { trade_type: 'general',     label: 'Cabinets / Counters / GC', low: 15000, high: 35000, scope_of_work: 'Cabinets, countertops, backsplash, demo, GC, permits' },
    ],
  },

  renovation_bathroom: {
    job_type: 'renovation_bathroom',
    label: 'Bathroom Renovation',
    base_sqft: 80,
    trades: [
      { trade_type: 'electrical',  label: 'Electrical',            low: 2000,  high: 4000,  scope_of_work: 'GFCI, exhaust fan, lighting' },
      { trade_type: 'plumbing',    label: 'Plumbing',              low: 4000,  high: 8000,  scope_of_work: 'Shower, tub, vanity, toilet rough-in and finish' },
      { trade_type: 'drywall',     label: 'Drywall / Cement Board', low: 1500, high: 3000,  scope_of_work: 'Moisture-resistant drywall, cement board' },
      { trade_type: 'flooring',    label: 'Tile',                  low: 2000,  high: 4500,  scope_of_work: 'Floor tile, shower tile' },
      { trade_type: 'painting',    label: 'Painting',              low: 800,   high: 1800,  scope_of_work: 'Walls, trim' },
      { trade_type: 'general',     label: 'Fixtures / Vanity / GC', low: 5000, high: 12000, scope_of_work: 'Vanity, toilet, shower fixtures, demo, permits, GC' },
    ],
  },

  addition: {
    job_type: 'addition',
    label: 'Room Addition',
    base_sqft: 400,
    trades: [
      { trade_type: 'framing',     label: 'Framing & Structure',   low: 20000, high: 35000, scope_of_work: 'Foundation, framing, roof tie-in' },
      { trade_type: 'electrical',  label: 'Electrical',            low: 8000,  high: 14000, scope_of_work: 'Panel, rough-in, fixtures' },
      { trade_type: 'plumbing',    label: 'Plumbing',              low: 6000,  high: 12000, scope_of_work: 'If bath included: rough-in and finish' },
      { trade_type: 'hvac',        label: 'HVAC Extension',        low: 4000,  high: 8000,  scope_of_work: 'Extend existing system or mini-split' },
      { trade_type: 'drywall',     label: 'Drywall',               low: 6000,  high: 10000, scope_of_work: 'Hang, tape, mud, prime' },
      { trade_type: 'flooring',    label: 'Flooring',              low: 4000,  high: 8000,  scope_of_work: 'Match or update existing' },
      { trade_type: 'painting',    label: 'Painting',              low: 3000,  high: 5000,  scope_of_work: 'Interior walls and trim' },
      { trade_type: 'windows',     label: 'Windows & Doors',       low: 4000,  high: 8000,  scope_of_work: 'New windows, entry if applicable' },
      { trade_type: 'roofing',     label: 'Roofing',               low: 6000,  high: 12000, scope_of_work: 'New section + integration with existing' },
      { trade_type: 'concrete',    label: 'Foundation',            low: 10000, high: 20000, scope_of_work: 'Footings and foundation' },
      { trade_type: 'insulation',  label: 'Insulation',            low: 3000,  high: 5500,  scope_of_work: 'Walls, ceiling, vapor barrier' },
      { trade_type: 'general',     label: 'GC / Permits / Misc',   low: 15000, high: 25000, scope_of_work: 'Permits, inspections, GC overhead, cleanup' },
    ],
  },

  ground_up: {
    job_type: 'ground_up',
    label: 'Ground-Up Construction',
    base_sqft: 1200,
    trades: [
      { trade_type: 'excavation',  label: 'Excavation & Site Prep', low: 15000, high: 30000, scope_of_work: 'Grading, excavation, utilities rough-in' },
      { trade_type: 'concrete',    label: 'Foundation',             low: 25000, high: 50000, scope_of_work: 'Footings, slab or stem wall' },
      { trade_type: 'framing',     label: 'Framing & Structure',    low: 40000, high: 70000, scope_of_work: 'Full framing, sheathing, roof' },
      { trade_type: 'roofing',     label: 'Roofing',                low: 15000, high: 28000, scope_of_work: 'Shingles, underlayment, flashing, gutters' },
      { trade_type: 'electrical',  label: 'Electrical',             low: 18000, high: 32000, scope_of_work: 'Service, rough-in, panel, fixtures' },
      { trade_type: 'plumbing',    label: 'Plumbing',               low: 20000, high: 38000, scope_of_work: 'All rough-in, fixtures, water heater' },
      { trade_type: 'hvac',        label: 'HVAC',                   low: 12000, high: 22000, scope_of_work: 'Full system: ducts, equipment, install' },
      { trade_type: 'insulation',  label: 'Insulation',             low: 8000,  high: 14000, scope_of_work: 'Walls, ceiling, vapor barrier' },
      { trade_type: 'drywall',     label: 'Drywall',                low: 14000, high: 24000, scope_of_work: 'Hang, tape, mud, prime' },
      { trade_type: 'windows',     label: 'Windows & Doors',        low: 12000, high: 22000, scope_of_work: 'All windows, exterior doors, interior doors' },
      { trade_type: 'flooring',    label: 'Flooring',               low: 12000, high: 22000, scope_of_work: 'LVP, tile, or hardwood throughout' },
      { trade_type: 'painting',    label: 'Painting',               low: 8000,  high: 14000, scope_of_work: 'Interior and exterior' },
      { trade_type: 'landscaping', label: 'Landscaping / Final',    low: 5000,  high: 12000, scope_of_work: 'Grading, seed, walkways, driveway' },
      { trade_type: 'general',     label: 'GC / Permits / Misc',    low: 25000, high: 45000, scope_of_work: 'Permits, inspections, GC overhead, cleanup' },
    ],
  },
};

export interface GeneratedBudget {
  job_type: JobType;
  label: string;
  sqft: number | null;
  trades: Array<{
    trade_type: TradeType;
    label: string;
    estimated_cost: number;   // midpoint of range, scaled by sqft if provided
    low: number;
    high: number;
    scope_of_work: string;
  }>;
  total_low: number;
  total_high: number;
  total_estimate: number;
}

/**
 * Generate a preliminary budget from a static template.
 * Returns instantly — no API calls, no AI.
 *
 * If sqft is provided, costs scale proportionally to the template's base_sqft.
 * Scale is capped at 2x to prevent extreme outliers.
 */
export function generateBudget(job_type: JobType, sqft?: number | null): GeneratedBudget {
  const template = TEMPLATES[job_type];
  const scale = sqft && sqft > 0
    ? Math.min(sqft / template.base_sqft, 2.0)  // cap at 2x
    : 1.0;

  let total_low = 0;
  let total_high = 0;

  const trades = template.trades.map((t) => {
    const low  = Math.round(t.low  * scale / 100) * 100;  // round to nearest $100
    const high = Math.round(t.high * scale / 100) * 100;
    const estimated_cost = Math.round((low + high) / 2 / 100) * 100;
    total_low  += low;
    total_high += high;
    return { ...t, low, high, estimated_cost };
  });

  return {
    job_type,
    label: template.label,
    sqft: sqft ?? null,
    trades,
    total_low,
    total_high,
    total_estimate: Math.round((total_low + total_high) / 2 / 100) * 100,
  };
}

export const JOB_TYPE_OPTIONS: Array<{ value: JobType; label: string }> = [
  { value: 'adu_studio',        label: 'ADU — Studio (up to 400 sqft)' },
  { value: 'adu_1br',           label: 'ADU — 1 Bedroom (400–650 sqft)' },
  { value: 'adu_2br',           label: 'ADU — 2 Bedroom (650–1200 sqft)' },
  { value: 'garage_conversion', label: 'Garage Conversion' },
  { value: 'renovation_kitchen',label: 'Kitchen Renovation' },
  { value: 'renovation_bathroom',label: 'Bathroom Renovation' },
  { value: 'addition',          label: 'Room Addition' },
  { value: 'ground_up',         label: 'Ground-Up Construction' },
];
