/**
 * InlineNextAction — shared component for next_action + next_action_due inline editing.
 * Used in Lead Detail, Deal Detail, Job Detail, and Trade rows.
 *
 * Design rules:
 * - Fast edit: click text to edit, save on blur — no modal friction
 * - Due date: native date/time input, saves on change
 * - Visual: compact, fits in existing card layouts
 * - Overdue: amber/red highlight on the due date
 */
import { useState, useCallback } from 'react';
import { Clock, Edit2 } from 'lucide-react';
import { cn } from '@/lib/utils';

interface InlineNextActionProps {
  value: string | null;
  dueAt: string | null;
  onSave: (action: string | null, due: string | null) => void;
  placeholder?: string;
  compact?: boolean;
}

function isDue(dueAt: string | null): 'overdue' | 'due_today' | 'upcoming' | null {
  if (!dueAt) return null;
  const d = new Date(dueAt);
  const now = new Date();
  if (d < now) return 'overdue';
  if (d.toDateString() === now.toDateString()) return 'due_today';
  return 'upcoming';
}

const DUE_COLORS = {
  overdue:   'text-red-600 bg-red-50 border-red-200',
  due_today: 'text-amber-600 bg-amber-50 border-amber-200',
  upcoming:  'text-gray-400',
};

export function InlineNextAction({
  value,
  dueAt,
  onSave,
  placeholder = 'Set next action…',
  compact = false,
}: InlineNextActionProps) {
  const [editing, setEditing] = useState(false);
  const [text, setText]       = useState(value ?? '');
  const [due, setDue]         = useState(dueAt ? dueAt.slice(0, 16) : ''); // datetime-local format

  const status = isDue(dueAt);

  const handleBlur = useCallback(() => {
    setEditing(false);
    const newAction = text.trim() || null;
    const newDue = due
      ? new Date(due).toISOString()
      : null;
    onSave(newAction, newDue);
  }, [text, due, onSave]);

  if (!editing) {
    return (
      <button
        onClick={() => { setText(value ?? ''); setDue(dueAt ? dueAt.slice(0, 16) : ''); setEditing(true); }}
        className={cn(
          'w-full text-left group flex items-start gap-2 rounded p-1.5 -mx-1.5 transition-colors hover:bg-black/5',
          compact ? 'min-h-[28px]' : 'min-h-[36px]'
        )}
      >
        <div className="flex-1 min-w-0">
          {value ? (
            <>
              <p className={cn('text-sm', compact ? 'text-xs' : 'text-sm')}>{value}</p>
              {dueAt && (
                <p className={cn(
                  'text-xs mt-0.5 flex items-center gap-1 font-medium',
                  status ? DUE_COLORS[status] : 'text-gray-400'
                )}>
                  <Clock className="h-3 w-3 shrink-0" />
                  {status === 'overdue' ? 'Overdue · ' : status === 'due_today' ? 'Due today · ' : ''}
                  {new Date(dueAt).toLocaleDateString('en-US', {
                    month: 'short', day: 'numeric',
                    hour: 'numeric', minute: '2-digit', hour12: true,
                  })}
                </p>
              )}
            </>
          ) : (
            <p className="text-sm text-gray-300 italic">{placeholder}</p>
          )}
        </div>
        <Edit2 className="h-3 w-3 text-gray-300 opacity-0 group-hover:opacity-100 shrink-0 mt-0.5 transition-opacity" />
      </button>
    );
  }

  return (
    <div className="space-y-1.5 p-1.5 -mx-1.5 bg-white border border-[#4A8DB7]/30 rounded-lg">
      <input
        autoFocus
        type="text"
        value={text}
        onChange={(e) => setText(e.target.value)}
        onBlur={handleBlur}
        onKeyDown={(e) => { if (e.key === 'Enter') handleBlur(); if (e.key === 'Escape') setEditing(false); }}
        placeholder={placeholder}
        className="w-full text-sm px-2 py-1 border-0 outline-none bg-transparent placeholder-gray-300"
      />
      <input
        type="datetime-local"
        value={due}
        onChange={(e) => setDue(e.target.value)}
        onBlur={handleBlur}
        className="w-full text-xs px-2 py-0.5 text-gray-500 border-0 outline-none bg-transparent"
      />
      <p className="text-[10px] text-gray-300 px-2">Enter or click away to save</p>
    </div>
  );
}
