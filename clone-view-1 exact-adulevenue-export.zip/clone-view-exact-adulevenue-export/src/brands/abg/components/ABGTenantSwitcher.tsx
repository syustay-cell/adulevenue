/**
 * MVP SCOPE — Tenant Switcher
 *
 * Appears in ABGShell for users who belong to more than one tenant.
 * Reads wf_tenant_users + wf_tenants to list available tenants.
 * Switches by navigating to the target tenant's portal path.
 *
 * Portal path map:
 *   abg  → /abg/portal/today
 *   wolf-fund / wolffund → /
 *   tlc_org / tlc-org → /tlc/dashboard   (when built)
 *   tlc_ops / tlc-ops → /tlc/dashboard   (when built)
 */
import { useEffect, useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { ArrowLeftRight, Loader2 } from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { cn } from '@/lib/utils';

interface TenantOption {
  id: string;
  name: string;
  slug: string;
}

function portalPathForSlug(slug: string): string {
  if (slug === 'abg')                        return '/abg/portal/today';
  if (slug === 'wolf-fund' || slug === 'wolffund') return '/';
  if (slug.startsWith('tlc'))                return '/tlc/dashboard';
  return '/';
}

function isCurrentTenant(slug: string, pathname: string): boolean {
  if (slug === 'abg' && pathname.startsWith('/abg')) return true;
  if ((slug === 'wolf-fund' || slug === 'wolffund') && !pathname.startsWith('/abg') && !pathname.startsWith('/tlc')) return true;
  if (slug.startsWith('tlc') && pathname.startsWith('/tlc')) return true;
  return false;
}

export function ABGTenantSwitcher() {
  const navigate = useNavigate();
  const { pathname } = useLocation();
  const [tenants, setTenants] = useState<TenantOption[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const load = async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) { setLoading(false); return; }

      // Read all tenant memberships for this user from wf_tenant_users
      const { data } = await supabase
        .from('wf_tenant_users')
        .select('tenant_id, wf_tenants!inner(id, name, slug)')
        .eq('user_id', user.id);

      if (data) {
        const opts: TenantOption[] = data
          .map((row: any) => row.wf_tenants)
          .filter(Boolean)
          .map((t: any) => ({ id: t.id, name: t.name, slug: t.slug }));
        setTenants(opts);
      }
      setLoading(false);
    };
    load();
  }, []);

  // Only show if user belongs to more than one tenant
  if (loading || tenants.length <= 1) return null;

  const current = tenants.find((t) => isCurrentTenant(t.slug, pathname));

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <button className="hidden md:flex items-center gap-1.5 text-gray-300 hover:text-white text-xs px-2 py-1 rounded hover:bg-white/10 transition-colors border border-white/10">
          <ArrowLeftRight className="h-3 w-3" />
          {current?.name ?? 'Switch'}
        </button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-48">
        <DropdownMenuLabel className="text-xs text-gray-400">Switch Portal</DropdownMenuLabel>
        <DropdownMenuSeparator />
        {tenants.map((tenant) => {
          const active = isCurrentTenant(tenant.slug, pathname);
          return (
            <DropdownMenuItem
              key={tenant.id}
              onClick={() => navigate(portalPathForSlug(tenant.slug))}
              className={cn(
                'text-sm cursor-pointer',
                active && 'font-semibold text-[#4A8DB7]'
              )}
            >
              {active && <span className="mr-1.5">✓</span>}
              {tenant.name}
            </DropdownMenuItem>
          );
        })}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
