import { Link, useLocation } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Building2, Menu, X } from "lucide-react";
import { useBrand } from "@/contexts/BrandContext";
import { useState } from "react";
import { cn } from "@/lib/utils";

interface ABGNavigationProps {
  showDashboardLink?: boolean;
}

export function ABGNavigation({ showDashboardLink = true }: ABGNavigationProps) {
  const { brand } = useBrand();
  const location = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navLinks = [
    { href: "/abg", label: "Home" },
    { href: "/abg/services", label: "Services" },
    { href: "/abg/apply", label: "Apply Now" },
  ];

  const isActive = (href: string) => location.pathname === href;

  return (
    <header className="border-b border-border bg-card sticky top-0 z-50">
      <div className="container mx-auto px-4 py-4 flex items-center justify-between">
        {/* Logo */}
        <Link to="/abg" className="flex items-center gap-3">
          <Building2 className="h-8 w-8 text-primary" />
          <span className="text-xl font-bold text-foreground">{brand.name}</span>
        </Link>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center gap-6">
          {navLinks.map((link) => (
            <Link
              key={link.href}
              to={link.href}
              className={cn(
                "text-sm font-medium transition-colors hover:text-primary",
                isActive(link.href)
                  ? "text-primary"
                  : "text-muted-foreground"
              )}
            >
              {link.label}
            </Link>
          ))}
          {showDashboardLink && (
            <Button asChild>
              <Link to="/abg/dashboard">Dashboard</Link>
            </Button>
          )}
        </nav>

        {/* Mobile Menu Button */}
        <Button
          variant="ghost"
          size="icon"
          className="md:hidden"
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
        >
          {mobileMenuOpen ? (
            <X className="h-5 w-5" />
          ) : (
            <Menu className="h-5 w-5" />
          )}
        </Button>
      </div>

      {/* Mobile Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden border-t border-border bg-card">
          <nav className="container mx-auto px-4 py-4 flex flex-col gap-2">
            {navLinks.map((link) => (
              <Link
                key={link.href}
                to={link.href}
                onClick={() => setMobileMenuOpen(false)}
                className={cn(
                  "py-2 px-4 rounded-md text-sm font-medium transition-colors",
                  isActive(link.href)
                    ? "bg-primary/10 text-primary"
                    : "text-muted-foreground hover:bg-muted"
                )}
              >
                {link.label}
              </Link>
            ))}
            {showDashboardLink && (
              <Button asChild className="mt-2">
                <Link to="/abg/dashboard" onClick={() => setMobileMenuOpen(false)}>
                  Dashboard
                </Link>
              </Button>
            )}
          </nav>
        </div>
      )}
    </header>
  );
}

export default ABGNavigation;
