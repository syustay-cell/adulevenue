import { cn } from '@/lib/utils';
import type { LeadStatus, LeadHeat, FinancingStatus, DealStage, NextActionType } from '../types';

// ─── STATUS BADGE ────────────────────────────────────────────────────────────

const STATUS_CONFIG: Record<LeadStatus, { label: string; className: string }> = {
  new:         { label: 'New',         className: 'bg-[#4A8DB7]/15 text-[#4A8DB7] border-[#4A8DB7]/30' },
  contacted:   { label: 'Contacted',   className: 'bg-amber-100 text-amber-700 border-amber-200' },
  in_progress: { label: 'In Progress', className: 'bg-orange-100 text-orange-700 border-orange-200' },
  qualified:   { label: 'Qualified',   className: 'bg-green-100 text-green-700 border-green-200' },
  converted:   { label: 'Converted',   className: 'bg-purple-100 text-purple-700 border-purple-200' },
  on_hold:     { label: 'On Hold',     className: 'bg-gray-100 text-gray-600 border-gray-200' },
  closed_lost: { label: 'Closed Lost', className: 'bg-red-100 text-red-600 border-red-200' },
};

export function StatusBadge({ status }: { status: LeadStatus }) {
  const config = STATUS_CONFIG[status] ?? STATUS_CONFIG.new;
  return (
    <span className={cn(
      'inline-flex items-center px-2 py-0.5 rounded text-xs font-medium border',
      config.className
    )}>
      {config.label}
    </span>
  );
}

// ─── HEAT BADGE ──────────────────────────────────────────────────────────────

const HEAT_CONFIG: Record<LeadHeat, { label: string; icon: string; className: string }> = {
  hot:  { label: 'Hot',  icon: '🔥', className: 'bg-orange-100 text-orange-700 border-orange-200' },
  warm: { label: 'Warm', icon: '🟡', className: 'bg-amber-50 text-amber-600 border-amber-200' },
  cold: { label: 'Cold', icon: '❄️', className: 'bg-slate-100 text-slate-500 border-slate-200' },
};

export function HeatBadge({ heat }: { heat: LeadHeat }) {
  const config = HEAT_CONFIG[heat] ?? HEAT_CONFIG.warm;
  return (
    <span className={cn(
      'inline-flex items-center gap-1 px-2 py-0.5 rounded text-xs font-medium border',
      config.className
    )}>
      <span>{config.icon}</span>
      {config.label}
    </span>
  );
}

// ─── SOURCE BADGE ─────────────────────────────────────────────────────────────

const SOURCE_LABELS: Record<string, string> = {
  'adu-levenue': 'ADU Levenue',
  'abg-direct':  'ABG Direct',
};

export function SourceBadge({ source }: { source: string }) {
  const label = SOURCE_LABELS[source] ?? source;
  const isADU = source === 'adu-levenue';
  return (
    <span className={cn(
      'inline-flex items-center px-2 py-0.5 rounded text-xs font-medium border',
      isADU
        ? 'bg-[#4A8DB7]/15 text-[#4A8DB7] border-[#4A8DB7]/30'
        : 'bg-[#2B2B2B]/10 text-[#2B2B2B] border-[#2B2B2B]/20'
    )}>
      {label}
    </span>
  );
}

// ─── DEAL STAGE BADGE ─────────────────────────────────────────────────────────

const STAGE_CONFIG: Record<DealStage, { label: string; className: string }> = {
  active:    { label: 'Active',    className: 'bg-[#4A8DB7]/15 text-[#4A8DB7] border-[#4A8DB7]/30' },
  proposal:  { label: 'Proposal',  className: 'bg-amber-100 text-amber-700 border-amber-200' },
  signed:    { label: 'Signed',    className: 'bg-green-100 text-green-700 border-green-200' },
  permit:    { label: 'Permit',    className: 'bg-purple-100 text-purple-700 border-purple-200' },
  build:     { label: 'Build',     className: 'bg-orange-100 text-orange-700 border-orange-200' },
  complete:  { label: 'Complete',  className: 'bg-emerald-100 text-emerald-700 border-emerald-200' },
  on_hold:   { label: 'On Hold',   className: 'bg-gray-100 text-gray-600 border-gray-200' },
  cancelled: { label: 'Cancelled', className: 'bg-red-100 text-red-500 border-red-200' },
};

export function StageBadge({ stage }: { stage: DealStage }) {
  const config = STAGE_CONFIG[stage] ?? STAGE_CONFIG.active;
  return (
    <span className={cn(
      'inline-flex items-center px-2 py-0.5 rounded text-xs font-medium border',
      config.className
    )}>
      {config.label}
    </span>
  );
}

// ─── FINANCING STATUS BADGE ───────────────────────────────────────────────────

const FINANCING_CONFIG: Record<FinancingStatus, { label: string; className: string }> = {
  unknown:          { label: 'Unknown',             className: 'bg-gray-100 text-gray-500 border-gray-200' },
  already_covered:  { label: 'Already Covered',     className: 'bg-green-100 text-green-700 border-green-200' },
  needs_financing:  { label: 'Needs Financing',     className: 'bg-amber-100 text-amber-700 border-amber-200' },
  wolf_fund_working:{ label: 'Wolf Fund Working',   className: 'bg-[#4A8DB7]/15 text-[#4A8DB7] border-[#4A8DB7]/30' },
  confirmed:        { label: 'Financing Confirmed', className: 'bg-emerald-100 text-emerald-700 border-emerald-200' },
};

export function FinancingBadge({ status }: { status: FinancingStatus }) {
  const config = FINANCING_CONFIG[status] ?? FINANCING_CONFIG.unknown;
  return (
    <span className={cn(
      'inline-flex items-center px-2 py-0.5 rounded text-xs font-medium border',
      config.className
    )}>
      {config.label}
    </span>
  );
}

// ─── SPEED BADGE ──────────────────────────────────────────────────────────────

export function SpeedBadge({ seconds }: { seconds: number | null }) {
  if (seconds === null) return null;
  const mins = Math.round(seconds / 60);
  const label = mins < 60 ? `${mins} min` : `${Math.round(mins / 60)}h`;
  const config =
    seconds <= 300  ? { icon: '🟢', text: 'Elite',  className: 'text-green-600' } :
    seconds <= 1800 ? { icon: '🟡', text: 'Good',   className: 'text-amber-600' } :
                      { icon: '🔴', text: 'Slow',   className: 'text-red-600' };
  return (
    <span className={cn('text-xs font-medium', config.className)}>
      {config.icon} {label}
    </span>
  );
}

// ─── URGENCY BADGE ────────────────────────────────────────────────────────────

export function UrgencyBadge({ urgency }: { urgency: 'overdue' | 'due_today' | 'upcoming' }) {
  const config = {
    overdue:   { label: 'Overdue',   className: 'bg-red-100 text-red-700 border-red-200' },
    due_today: { label: 'Due Today', className: 'bg-amber-100 text-amber-700 border-amber-200' },
    upcoming:  { label: 'Upcoming',  className: 'bg-gray-100 text-gray-500 border-gray-200' },
  }[urgency];
  return (
    <span className={cn(
      'inline-flex items-center px-2 py-0.5 rounded text-xs font-medium border',
      config.className
    )}>
      {config.label}
    </span>
  );
}

// ─── LANE BADGE ───────────────────────────────────────────────────────────────

const LANE_CONFIG: Record<string, { label: string; className: string }> = {
  ABG_PRIVATE_RESIDENTIAL:  { label: 'Residential',  className: 'bg-emerald-100 text-emerald-700 border-emerald-200' },
  ABG_COMMERCIAL_FRANCHISE: { label: 'Commercial',   className: 'bg-indigo-100 text-indigo-700 border-indigo-200' },
  ABG_GOVERNMENT_MUNICIPAL: { label: 'Government',   className: 'bg-slate-100 text-slate-600 border-slate-200' },
};

export function LaneBadge({ lane }: { lane: string | null }) {
  if (!lane) return null;
  const config = LANE_CONFIG[lane] ?? { label: lane, className: 'bg-gray-100 text-gray-500 border-gray-200' };
  return (
    <span className={cn(
      'inline-flex items-center px-2 py-0.5 rounded text-xs font-medium border',
      config.className
    )}>
      {config.label}
    </span>
  );
}

// ─── FUNDING PRECHECK BADGE ───────────────────────────────────────────────────

const PRECHECK_CONFIG: Record<string, { label: string; className: string }> = {
  pending: { label: 'Precheck Pending', className: 'bg-gray-100 text-gray-500 border-gray-200' },
  passed:  { label: 'Precheck Passed',  className: 'bg-green-100 text-green-700 border-green-200' },
  failed:  { label: 'Precheck Failed',  className: 'bg-red-100 text-red-600 border-red-200' },
};

export function FundingPrecheckBadge({ status }: { status: string }) {
  const config = PRECHECK_CONFIG[status] ?? PRECHECK_CONFIG.pending;
  return (
    <span className={cn(
      'inline-flex items-center px-2 py-0.5 rounded text-xs font-medium border',
      config.className
    )}>
      {config.label}
    </span>
  );
}

// ─── CONTRACT STATUS BADGE ────────────────────────────────────────────────────

const CONTRACT_CONFIG: Record<string, { label: string; className: string }> = {
  pending: { label: 'Contract Pending', className: 'bg-gray-100 text-gray-500 border-gray-200' },
  sent:    { label: 'Contract Sent',    className: 'bg-amber-100 text-amber-700 border-amber-200' },
  signed:  { label: 'Contract Signed',  className: 'bg-green-100 text-green-700 border-green-200' },
};

export function ContractStatusBadge({ status }: { status: string }) {
  const config = CONTRACT_CONFIG[status] ?? CONTRACT_CONFIG.pending;
  return (
    <span className={cn(
      'inline-flex items-center px-2 py-0.5 rounded text-xs font-medium border',
      config.className
    )}>
      {config.label}
    </span>
  );
}

// ─── ACTION TYPE LABEL ────────────────────────────────────────────────────────

const ACTION_LABELS: Record<string, string> = {
  call:                'Call',
  text:                'Send Text',
  email:               'Send Email',
  follow_up:           'Follow Up',
  send_estimate:       'Send Estimate',
  send_proposal:       'Send Proposal',
  schedule_visit:      'Schedule Visit',
  push_to_proposal:    'Push to Proposal',
  check_permit:        'Check Permit',
  check_build_progress:'Check Build Progress',
  custom:              'Custom',
};

export function actionTypeLabel(type: NextActionType, customLabel?: string | null): string {
  if (type === 'custom' && customLabel) return customLabel;
  return ACTION_LABELS[type] ?? type;
}
