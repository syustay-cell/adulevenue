import { NavLink, useNavigate } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { cn } from '@/lib/utils';
import {
  ClipboardList,
  Users,
  Briefcase,
  AlertTriangle,
  HardHat,
  LogOut,
  Menu,
  X,
} from 'lucide-react';
import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { ModeSwitcher } from '@/components/ModeSwitcher';

const NAV_ITEMS = [
  { to: '/abg/portal/today',       label: "Today's Work", icon: ClipboardList },
  { to: '/abg/portal/leads',       label: 'Leads',        icon: Users },
  { to: '/abg/portal/deals',       label: 'Deals',        icon: Briefcase },
  { to: '/abg/portal/jobs',        label: 'Jobs',         icon: HardHat },
  { to: '/abg/portal/stuck-money', label: 'Stuck Money',  icon: AlertTriangle },
];

interface ABGShellProps {
  children: React.ReactNode;
}

export function ABGShell({ children }: ABGShellProps) {
  const navigate = useNavigate();
  const [mobileOpen, setMobileOpen] = useState(false);

  const handleLogout = async () => {
    await supabase.auth.signOut();
    navigate('/auth');
  };

  return (
    <div className="min-h-screen bg-[#F5F6F8]">
      {/* Top nav */}
      <header className="bg-[#2B2B2B] text-white h-14 flex items-center px-4 gap-4 sticky top-0 z-50">

        {/* Logo */}
        <div className="flex items-center gap-2 shrink-0">
          <div className="w-7 h-7 rounded bg-[#4A8DB7] flex items-center justify-center font-bold text-white text-sm">
            ABG
          </div>
          <span className="font-semibold text-sm hidden sm:block tracking-wide">
            ADVANCED BUILDERS GROUP
          </span>
        </div>

        {/* Desktop nav links */}
        <nav className="hidden md:flex items-center gap-1 ml-4">
          {NAV_ITEMS.map(({ to, label, icon: Icon }) => (
            <NavLink
              key={to}
              to={to}
              className={({ isActive }) =>
                cn(
                  'flex items-center gap-1.5 px-3 py-1.5 rounded text-sm transition-colors',
                  isActive
                    ? 'bg-[#4A8DB7] text-white'
                    : 'text-gray-300 hover:bg-white/10 hover:text-white'
                )
              }
            >
              <Icon className="h-3.5 w-3.5" />
              {label}
            </NavLink>
          ))}
        </nav>

        {/* Right side — desktop only */}
        <div className="ml-auto flex items-center gap-2">
          {/* Shared mode switcher — desktop dropdown */}
          <ModeSwitcher />

          <button
            onClick={handleLogout}
            className="hidden md:flex items-center gap-1 text-gray-400 hover:text-white text-sm px-2 py-1 rounded hover:bg-white/10 transition-colors"
          >
            <LogOut className="h-3.5 w-3.5" />
            Sign out
          </button>

          {/* Mobile hamburger */}
          <button
            className="md:hidden text-gray-300 hover:text-white p-1"
            onClick={() => setMobileOpen(!mobileOpen)}
          >
            {mobileOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>
      </header>

      {/* Mobile nav drawer */}
      {mobileOpen && (
        <div className="md:hidden bg-[#2B2B2B] border-t border-white/10 px-4 pt-3 pb-4">

          {/* Mode switcher — mobile flat layout — FIRST item, always visible */}
          <ModeSwitcher mobile onNavigate={() => setMobileOpen(false)} />

          {/* Nav links */}
          {NAV_ITEMS.map(({ to, label, icon: Icon }) => (
            <NavLink
              key={to}
              to={to}
              onClick={() => setMobileOpen(false)}
              className={({ isActive }) =>
                cn(
                  'flex items-center gap-2 px-3 py-2.5 rounded text-sm mt-1 transition-colors',
                  isActive
                    ? 'bg-[#4A8DB7] text-white'
                    : 'text-gray-300 hover:bg-white/10 hover:text-white'
                )
              }
            >
              <Icon className="h-4 w-4" />
              {label}
            </NavLink>
          ))}

          <Button
            variant="ghost"
            size="sm"
            onClick={handleLogout}
            className="mt-3 text-gray-400 hover:text-white w-full justify-start"
          >
            <LogOut className="h-4 w-4 mr-2" />
            Sign out
          </Button>
        </div>
      )}

      {/* Page content */}
      <main className="p-4 md:p-6 max-w-7xl mx-auto">
        {children}
      </main>
    </div>
  );
}
