/**
 * PreliminaryBudgetModal
 *
 * No AI. No external APIs. Static templates. Instant response.
 *
 * Flow:
 * 1. Worker selects job type + optional sqft
 * 2. Instant budget table appears (client-side calculation)
 * 3. Worker clicks "Save to Job" → creates abg_job_trades rows
 * 4. Existing trades are NOT overwritten — only missing trade types are added
 */

import { useState, useMemo } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { generateBudget, JOB_TYPE_OPTIONS } from '../lib/budgetTemplates';
import type { JobType, GeneratedBudget } from '../lib/budgetTemplates';
import { formatCurrency } from '../lib/time';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import { Loader2, Calculator, CheckCircle2 } from 'lucide-react';
import { cn } from '@/lib/utils';

interface PreliminaryBudgetModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  jobId: string;
  tenantId: string;
  existingTradeTypes: string[];   // already-created trade types to skip
  onSaved: () => void;            // reload job detail
}

export function PreliminaryBudgetModal({
  open,
  onOpenChange,
  jobId,
  tenantId,
  existingTradeTypes,
  onSaved,
}: PreliminaryBudgetModalProps) {
  const [jobType, setJobType]     = useState<JobType | ''>('');
  const [sqft, setSqft]           = useState('');
  const [saving, setSaving]       = useState(false);
  const [saved, setSaved]         = useState(false);

  // Instant calculation — no API call
  const budget: GeneratedBudget | null = useMemo(() => {
    if (!jobType) return null;
    return generateBudget(jobType, sqft ? parseFloat(sqft) : null);
  }, [jobType, sqft]);

  const newTrades = useMemo(() => {
    if (!budget) return [];
    return budget.trades.filter((t) => !existingTradeTypes.includes(t.trade_type));
  }, [budget, existingTradeTypes]);

  const skippedTrades = useMemo(() => {
    if (!budget) return [];
    return budget.trades.filter((t) => existingTradeTypes.includes(t.trade_type));
  }, [budget, existingTradeTypes]);

  const handleSave = async () => {
    if (!budget || newTrades.length === 0) return;
    setSaving(true);
    try {
      await supabase.from('abg_job_trades').insert(
        newTrades.map((t) => ({
          tenant_id:      tenantId,
          job_id:         jobId,
          trade_type:     t.trade_type,
          estimated_cost: t.estimated_cost,
          scope_of_work:  t.scope_of_work,
          status:         'pending',
        }))
      );
      setSaved(true);
      setTimeout(() => {
        onSaved();
        onOpenChange(false);
        setSaved(false);
        setJobType('');
        setSqft('');
      }, 1200);
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Calculator className="h-5 w-5 text-[#4A8DB7]" />
            Preliminary Budget
          </DialogTitle>
        </DialogHeader>

        <p className="text-sm text-gray-500 -mt-2">
          Static ranges based on job type. Instant estimate — no AI required.
        </p>

        {/* Inputs */}
        <div className="grid grid-cols-2 gap-4 mt-2">
          <div>
            <Label className="text-xs text-gray-400 uppercase tracking-wide mb-1 block">
              Job Type *
            </Label>
            <Select value={jobType} onValueChange={(v) => { setJobType(v as JobType); setSaved(false); }}>
              <SelectTrigger>
                <SelectValue placeholder="Select job type…" />
              </SelectTrigger>
              <SelectContent>
                {JOB_TYPE_OPTIONS.map((o) => (
                  <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label className="text-xs text-gray-400 uppercase tracking-wide mb-1 block">
              Square Footage (optional)
            </Label>
            <div className="relative">
              <Input
                type="number"
                value={sqft}
                onChange={(e) => { setSqft(e.target.value); setSaved(false); }}
                placeholder="e.g. 450"
                className="pr-12"
              />
              <span className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-gray-400">sqft</span>
            </div>
          </div>
        </div>

        {/* Budget table — instant render */}
        {budget && (
          <div className="mt-4 space-y-3">
            {/* Summary */}
            <div className="bg-[#F5F6F8] border border-[#E2E4E8] rounded-lg px-4 py-3 flex flex-wrap gap-6">
              <div>
                <p className="text-xs text-gray-400 uppercase tracking-wide">Low Estimate</p>
                <p className="text-lg font-bold text-[#2B2B2B]">{formatCurrency(budget.total_low)}</p>
              </div>
              <div>
                <p className="text-xs text-gray-400 uppercase tracking-wide">High Estimate</p>
                <p className="text-lg font-bold text-[#2B2B2B]">{formatCurrency(budget.total_high)}</p>
              </div>
              <div>
                <p className="text-xs text-gray-400 uppercase tracking-wide">Midpoint</p>
                <p className="text-lg font-bold text-[#4A8DB7]">{formatCurrency(budget.total_estimate)}</p>
              </div>
              {sqft && (
                <div>
                  <p className="text-xs text-gray-400 uppercase tracking-wide">Per Sqft</p>
                  <p className="text-lg font-bold text-gray-600">
                    {formatCurrency(Math.round(budget.total_estimate / parseFloat(sqft)))}
                  </p>
                </div>
              )}
            </div>

            {/* Trade breakdown */}
            <div className="border border-[#E2E4E8] rounded-lg overflow-hidden">
              <div className="bg-[#F5F6F8] px-4 py-2 border-b border-[#E2E4E8]">
                <div className="grid grid-cols-12 gap-2 text-xs font-semibold text-gray-400 uppercase tracking-wide">
                  <div className="col-span-4">Trade</div>
                  <div className="col-span-3">Low</div>
                  <div className="col-span-3">High</div>
                  <div className="col-span-2 text-right">Est.</div>
                </div>
              </div>
              {budget.trades.map((t) => {
                const exists = existingTradeTypes.includes(t.trade_type);
                return (
                  <div
                    key={t.trade_type}
                    className={cn(
                      'grid grid-cols-12 gap-2 px-4 py-2.5 border-b border-[#E2E4E8] text-sm last:border-b-0',
                      exists ? 'opacity-40' : ''
                    )}
                  >
                    <div className="col-span-4">
                      <p className="font-medium text-[#1A1A1A]">{t.label}</p>
                      {exists && (
                        <p className="text-xs text-gray-400">Already in job</p>
                      )}
                    </div>
                    <div className="col-span-3 text-gray-500">{formatCurrency(t.low)}</div>
                    <div className="col-span-3 text-gray-500">{formatCurrency(t.high)}</div>
                    <div className="col-span-2 text-right font-semibold text-[#4A8DB7]">
                      {formatCurrency(t.estimated_cost)}
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Scope notes toggle (collapsed by default) */}
            <p className="text-xs text-gray-400">
              Estimates are midpoints of typical ranges for the NYC metro area.
              Actual costs vary by site conditions, material selection, and subcontractor availability.
            </p>

            {skippedTrades.length > 0 && (
              <p className="text-xs text-amber-600 bg-amber-50 border border-amber-200 rounded px-3 py-2">
                {skippedTrades.length} trade{skippedTrades.length !== 1 ? 's' : ''} already exist in this job and will be skipped:{' '}
                {skippedTrades.map((t) => t.label).join(', ')}.
              </p>
            )}

            {newTrades.length === 0 && (
              <p className="text-sm text-gray-500 bg-gray-50 border border-gray-200 rounded px-3 py-2">
                All trades from this template already exist in the job.
              </p>
            )}
          </div>
        )}

        {/* Actions */}
        <div className="flex gap-3 mt-2">
          <Button
            variant="outline"
            onClick={() => onOpenChange(false)}
            className="flex-1 border-[#E2E4E8]"
          >
            Cancel
          </Button>
          <Button
            onClick={handleSave}
            disabled={!budget || saving || saved || newTrades.length === 0}
            className="flex-1 bg-[#2B2B2B] hover:bg-[#4A8DB7] text-white"
          >
            {saved ? (
              <><CheckCircle2 className="h-4 w-4 mr-2" /> Saved!</>
            ) : saving ? (
              <><Loader2 className="h-4 w-4 animate-spin mr-2" /> Saving…</>
            ) : (
              `Save ${newTrades.length} Trade${newTrades.length !== 1 ? 's' : ''} to Job`
            )}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
