// ABG Operating System — TypeScript types
// All fields map directly to locked schema columns

export type LeadStatus =
  | 'new'
  | 'contacted'
  | 'in_progress'
  | 'qualified'
  | 'converted'
  | 'on_hold'
  | 'closed_lost';

export type LeadHeat = 'hot' | 'warm' | 'cold';

export type FinancingStatus =
  | 'unknown'
  | 'already_covered'
  | 'needs_financing'
  | 'wolf_fund_working'
  | 'confirmed';

export type DealStage =
  | 'active'
  | 'proposal'
  | 'signed'
  | 'permit'
  | 'build'
  | 'complete'
  | 'on_hold'
  | 'cancelled';

export type ABGLane =
  | 'ABG_PRIVATE_RESIDENTIAL'
  | 'ABG_COMMERCIAL_FRANCHISE'
  | 'ABG_GOVERNMENT_MUNICIPAL';

export type FundingPrecheckStatus = 'pending' | 'passed' | 'failed';

export type ContractStatus = 'pending' | 'sent' | 'signed';

export type NextActionType =
  | 'call'
  | 'text'
  | 'email'
  | 'follow_up'
  | 'send_estimate'
  | 'send_proposal'
  | 'schedule_visit'
  | 'push_to_proposal'
  | 'check_permit'
  | 'check_build_progress'
  | 'custom';

export type ActivityEventType =
  | 'lead_created'
  | 'status_changed'
  | 'heat_changed'
  | 'ownership_changed'
  | 'financing_status_changed'
  | 'call_logged'
  | 'text_sent'
  | 'email_sent'
  | 'note_added'
  | 'next_action_set'
  | 'next_action_completed'
  | 'deal_created'
  | 'stage_changed'
  | 'project_value_set'
  | 'estimated_profit_set'
  | 'wolf_fund_handoff_triggered'
  | 'wolf_fund_handoff_failed'
  | 'notification_sent'
  | 'notification_failed'
  | 'sequence_started'
  | 'sequence_paused'
  | 'sequence_completed'
  | 'converted_to_deal'
  | 'lane_set'
  | 'funding_precheck_changed'
  | 'contract_status_changed'
  | 'margin_warning_flagged';

// wf_leads row (ABG extended)
export interface ABGLead {
  id: string;
  tenant_id: string;
  source: string;
  source_locked_at: string | null;
  first_name: string | null;
  last_name: string | null;
  full_name: string | null;
  email: string | null;
  phone: string | null;
  address: string | null;
  city: string | null;
  state: string | null;
  zip: string | null;
  intended_use: string | null;
  referral_source: string | null;
  notes: string | null;
  status: LeadStatus;
  heat: LeadHeat;
  financing_status: FinancingStatus;
  assigned_to: string | null;
  last_touch_at: string | null;
  response_time_seconds: number | null;
  converted_to_deal_at: string | null;
  next_action: string | null;
  next_action_due: string | null;
  created_at: string;
  updated_at: string;
}

export type DocType = 'permit' | 'plan' | 'contract' | 'photo' | 'inspection' | 'other';

// abg_job_documents row
export interface ABGJobDocument {
  id: string;
  tenant_id: string;
  job_id: string;
  name: string;
  doc_type: DocType;
  storage_path: string | null;
  uploaded_by: string | null;
  notes: string | null;
  created_at: string;
}

// abg_deals row
export interface ABGDeal {
  id: string;
  tenant_id: string;
  lead_id: string;
  owner_id: string | null;
  stage: DealStage;
  lane: ABGLane | null;
  margin_floor: number | null;
  project_value: number | null;
  estimated_profit: number | null;
  funding_precheck_status: FundingPrecheckStatus;
  contract_status: ContractStatus;
  stage_entered_at: string;
  financing_status: FinancingStatus;
  wolf_fund_ref_id: string | null;
  on_hold_reason: string | null;
  cancelled_reason: string | null;
  completed_at: string | null;
  cancelled_at: string | null;
  on_hold_at: string | null;
  next_action: string | null;
  next_action_due: string | null;
  meta: Record<string, unknown>;
  created_at: string;
  updated_at: string;
}

// abg_next_actions row
export interface ABGNextAction {
  id: string;
  tenant_id: string;
  entity_type: 'lead' | 'deal';
  entity_id: string;
  owner_id: string | null;
  action_type: NextActionType;
  custom_label: string | null;
  due_at: string;
  completed_at: string | null;
  completed_by: string | null;
  is_active: boolean;
  status: NextActionStatus;
  created_at: string;
}

// abg_activity row
export interface ABGActivity {
  id: string;
  tenant_id: string;
  entity_type: 'lead' | 'deal';
  entity_id: string;
  actor_id: string | null;
  actor_type: 'worker' | 'system' | 'public_intake';
  event_type: ActivityEventType;
  old_value: string | null;
  new_value: string | null;
  note: string | null;
  meta: Record<string, unknown>;
  created_at: string;
}

// abg_notes row
export interface ABGNote {
  id: string;
  tenant_id: string;
  entity_type: 'lead' | 'deal';
  entity_id: string;
  author_id: string;
  body: string;
  created_at: string;
}

// ─── EXECUTION LITE TYPES ─────────────────────────────────────────────────────

export type JobStatus = 'planning' | 'bidding' | 'active' | 'delayed' | 'completed';

export type TradeType =
  | 'framing' | 'electrical' | 'plumbing' | 'hvac' | 'drywall'
  | 'flooring' | 'roofing' | 'concrete' | 'insulation' | 'painting'
  | 'windows' | 'doors' | 'excavation' | 'landscaping' | 'general' | 'other';

export type TradeStatus = 'pending' | 'quoted' | 'accepted' | 'in_progress' | 'completed';

// abg_subcontractors row
export interface ABGSubcontractor {
  id: string;
  tenant_id: string;
  name: string;
  trade_type: TradeType;
  phone: string | null;
  email: string | null;
  last_price_notes: string | null;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

// abg_jobs row
export interface ABGJob {
  id: string;
  tenant_id: string;
  deal_id: string;
  job_name: string;
  address: string | null;
  status: JobStatus;
  notes: string | null;
  next_action: string | null;
  next_action_due: string | null;
  start_date: string | null;
  expected_completion_date: string | null;
  created_by: string | null;
  created_at: string;
  updated_at: string;
}

// abg_job_trades row
export interface ABGJobTrade {
  id: string;
  tenant_id: string;
  job_id: string;
  trade_type: TradeType;
  scope_of_work: string | null;
  estimated_cost: number | null;
  agreed_price: number | null;
  assigned_sub_id: string | null;
  status: TradeStatus;
  next_action: string | null;
  next_action_due: string | null;
  start_date: string | null;
  expected_completion_date: string | null;
  created_at: string;
  updated_at: string;
}

// abg_sub_pricing row
export interface ABGSubPricing {
  id: string;
  tenant_id: string;
  sub_id: string;
  trade_type: TradeType;
  job_id: string | null;
  price: number;
  notes: string | null;
  created_at: string;
}

// abg_sub_last_price view
export interface ABGSubLastPrice {
  id: string;
  tenant_id: string;
  sub_id: string;
  trade_type: TradeType;
  last_price: number;
  last_price_notes: string | null;
  last_job_id: string | null;
  last_priced_at: string;
  sub_name: string;
}

// ─── SUB PORTAL TYPES ─────────────────────────────────────────────────────────

// abg_sub_accounts row
export interface ABGSubAccount {
  id: string;
  tenant_id: string;
  sub_id: string;
  user_id: string;
  created_at: string;
}

export type QuoteStatus = 'submitted' | 'accepted' | 'rejected';

// abg_sub_quotes row
export interface ABGSubQuote {
  id: string;
  tenant_id: string;
  job_id: string;
  trade_id: string;
  sub_id: string;
  quoted_price: number;
  notes: string | null;
  status: QuoteStatus;
  submitted_at: string;
  reviewed_at: string | null;
  reviewed_by: string | null;
}

// ─── END SUB PORTAL TYPES ─────────────────────────────────────────────────────

// ─── END EXECUTION LITE TYPES ─────────────────────────────────────────────────

// abg_follow_up_sequences row
export interface ABGSequence {
  id: string;
  tenant_id: string;
  lead_id: string;
  sequence_step: number;
  next_due_at: string;
  status: 'active' | 'paused' | 'completed';
  paused_reason: string | null;
  created_at: string;
  updated_at: string;
}

// abg_pipeline_summary view
export interface ABGPipelineSummary {
  tenant_id: string;
  stage: DealStage;
  deal_count: number;
  pipeline_value: number;
  profit_value: number;
  avg_days_in_stage: number;
}

// abg_stuck_deals view
export interface ABGStuckDeal {
  id: string;
  tenant_id: string;
  lead_id: string;
  stage: DealStage;
  project_value: number | null;
  estimated_profit: number | null;
  owner_id: string | null;
  stage_entered_at: string;
  days_in_stage: number;
  first_name: string | null;
  last_name: string | null;
  last_touch_at: string | null;
  assigned_to: string | null;
}

// abg_today_work view (enriched — includes resolved entity_name + source)
export interface ABGTodayWorkItem {
  next_action_id: string;
  owner_id: string | null;
  tenant_id: string;
  entity_type: 'lead' | 'deal';
  entity_id: string;
  action_type: NextActionType;
  custom_label: string | null;
  due_at: string;
  action_status: string;
  urgency: 'overdue' | 'due_today' | 'upcoming';
  entity_name: string;
  deal_lead_id: string | null;
  source: 'structured' | 'manual';
  source_table: 'abg_next_actions' | 'wf_leads' | 'abg_deals';
}

// abg_next_actions — updated to include status column
export type NextActionStatus = 'active' | 'completed' | 'cancelled' | 'skipped';
