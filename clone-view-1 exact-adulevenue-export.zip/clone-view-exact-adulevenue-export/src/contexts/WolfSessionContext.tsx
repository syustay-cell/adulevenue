// src/contexts/WolfSessionContext.tsx
// V10 / B100: Context for storing and managing wolf session ID

import React, { createContext, useContext, useState, useEffect, ReactNode } from "react";
import { supabase } from "@/integrations/supabase/client";
import { startWolfSession, endWolfSession } from "@/lib/wolfSession";
import { useWolfSessionHeartbeat } from "@/hooks/useWolfSessionHeartbeat";

interface WolfSessionContextValue {
  sessionId: string | null;
  portal: string | null;
  isSessionActive: boolean;
  startSession: (portal: string) => Promise<void>;
  endSession: (reason?: string) => Promise<void>;
}

const WolfSessionContext = createContext<WolfSessionContextValue | undefined>(undefined);

const SESSION_STORAGE_KEY = "wolf_session_id";
const PORTAL_STORAGE_KEY = "wolf_session_portal";

export function WolfSessionProvider({ children }: { children: ReactNode }) {
  const [sessionId, setSessionId] = useState<string | null>(() => {
    // Initialize from localStorage if available
    if (typeof window !== "undefined") {
      return localStorage.getItem(SESSION_STORAGE_KEY);
    }
    return null;
  });
  
  const [portal, setPortal] = useState<string | null>(() => {
    if (typeof window !== "undefined") {
      return localStorage.getItem(PORTAL_STORAGE_KEY);
    }
    return null;
  });

  // Wire up heartbeat for active sessions
  useWolfSessionHeartbeat(sessionId);

  // Listen for auth state changes to end session on logout
  useEffect(() => {
    const { data: { subscription } } = supabase.auth.onAuthStateChange((event) => {
      if (event === "SIGNED_OUT" && sessionId) {
        // End session on logout
        endWolfSession(sessionId, "logout").catch(console.error);
        setSessionId(null);
        setPortal(null);
        localStorage.removeItem(SESSION_STORAGE_KEY);
        localStorage.removeItem(PORTAL_STORAGE_KEY);
      }
    });

    return () => subscription.unsubscribe();
  }, [sessionId]);

  const startSession = async (portalName: string) => {
    try {
      const newSessionId = await startWolfSession(portalName);
      setSessionId(newSessionId);
      setPortal(portalName);
      localStorage.setItem(SESSION_STORAGE_KEY, newSessionId);
      localStorage.setItem(PORTAL_STORAGE_KEY, portalName);
    } catch (err) {
      console.error("Failed to start wolf session:", err);
      throw err;
    }
  };

  const endSession = async (reason?: string) => {
    if (!sessionId) return;
    
    try {
      await endWolfSession(sessionId, reason);
    } catch (err) {
      console.error("Failed to end wolf session:", err);
    } finally {
      setSessionId(null);
      setPortal(null);
      localStorage.removeItem(SESSION_STORAGE_KEY);
      localStorage.removeItem(PORTAL_STORAGE_KEY);
    }
  };

  return (
    <WolfSessionContext.Provider
      value={{
        sessionId,
        portal,
        isSessionActive: !!sessionId,
        startSession,
        endSession,
      }}
    >
      {children}
    </WolfSessionContext.Provider>
  );
}

export function useWolfSession() {
  const context = useContext(WolfSessionContext);
  if (context === undefined) {
    throw new Error("useWolfSession must be used within a WolfSessionProvider");
  }
  return context;
}
