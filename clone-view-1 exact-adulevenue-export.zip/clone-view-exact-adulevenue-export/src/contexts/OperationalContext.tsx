import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { ModeSwitcher } from "@/components/ModeSwitcher";

export type OperationalMode = "GOD" | "WOLF_FUND_CAPITAL";

export const OP_MODE_KEY = "wolf_os_mode";
export const OP_MODE_SOURCE_KEY = "wolf_os_mode_source";

export function parseMode(v: string | null): OperationalMode | null {
  if (v === "GOD" || v === "WOLF_FUND_CAPITAL") return v;
  return null;
}

export function getStoredMode(): OperationalMode | null {
  try {
    return parseMode(window.localStorage.getItem(OP_MODE_KEY));
  } catch {
    return null;
  }
}

export function setStoredMode(mode: OperationalMode, source: string) {
  try {
    window.localStorage.setItem(OP_MODE_KEY, mode);
    window.localStorage.setItem(OP_MODE_SOURCE_KEY, source);
  } catch {
    // ignore
  }
}

/**
 * ModeDropdown — now delegates to shared ModeSwitcher component.
 * Kept as a named export for backward compatibility with existing usages
 * in Wolf Fund shell layouts that render <ModeDropdown />.
 */
export function ModeDropdown() {
  return <ModeSwitcher />;
}

