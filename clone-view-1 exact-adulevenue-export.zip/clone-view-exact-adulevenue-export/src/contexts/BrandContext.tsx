import { createContext, useContext, useEffect, useState, ReactNode } from "react";

export type BrandKey = "wolf-fund" | "abg" | "tlc" | string;

export interface BrandConfig {
  key: BrandKey;
  name: string;
  logo?: string;
  routePrefix: string;
  subdomain?: string;
  theme: {
    primary: string;
    primaryForeground: string;
    accent: string;
    accentForeground: string;
    background: string;
    foreground: string;
    muted: string;
    mutedForeground: string;
    card: string;
    cardForeground: string;
    border: string;
    ring: string;
  };
}

// Brand registry - add new brands here
export const BRAND_REGISTRY: Record<BrandKey, BrandConfig> = {
  "wolf-fund": {
    key: "wolf-fund",
    name: "Wolf Fund",
    routePrefix: "",
    subdomain: "www",
    theme: {
      primary: "220 70% 45%",
      primaryForeground: "0 0% 100%",
      accent: "45 93% 47%",
      accentForeground: "220 20% 10%",
      background: "220 20% 96%",
      foreground: "220 30% 15%",
      muted: "220 15% 90%",
      mutedForeground: "220 10% 40%",
      card: "0 0% 100%",
      cardForeground: "220 30% 15%",
      border: "220 15% 85%",
      ring: "220 70% 45%",
    },
  },
  abg: {
    key: "abg",
    name: "Advance Builders Group",
    routePrefix: "/abg",
    subdomain: "abg",
    theme: {
      primary: "25 95% 50%",
      primaryForeground: "0 0% 100%",
      accent: "220 70% 45%",
      accentForeground: "0 0% 100%",
      background: "30 20% 96%",
      foreground: "25 30% 15%",
      muted: "30 15% 90%",
      mutedForeground: "25 10% 40%",
      card: "0 0% 100%",
      cardForeground: "25 30% 15%",
      border: "30 15% 85%",
      ring: "25 95% 50%",
    },
  },
  tlc: {
    key: "tlc",
    name: "TLC Clinical Services",
    routePrefix: "/tlc",
    subdomain: "tlc",
    theme: {
      primary: "200 80% 45%",
      primaryForeground: "0 0% 100%",
      accent: "280 50% 55%",
      accentForeground: "0 0% 100%",
      background: "200 20% 98%",
      foreground: "200 30% 15%",
      muted: "200 15% 92%",
      mutedForeground: "200 20% 45%",
      card: "0 0% 100%",
      cardForeground: "200 30% 15%",
      border: "200 15% 85%",
      ring: "200 80% 45%",
    },
  },
};

interface BrandContextValue {
  brand: BrandConfig;
  setBrand: (key: BrandKey) => void;
  isLoading: boolean;
}

const BrandContext = createContext<BrandContextValue | null>(null);

function detectBrandFromEnvironment(): BrandKey {
  const hostname = window.location.hostname;
  const pathname = window.location.pathname;

  // Check subdomain first (e.g., abg.wolffund.com)
  const subdomain = hostname.split(".")[0];
  for (const [key, config] of Object.entries(BRAND_REGISTRY)) {
    if (config.subdomain === subdomain && subdomain !== "www") {
      return key as BrandKey;
    }
  }

  // Check route prefix (e.g., /abg/*)
  for (const [key, config] of Object.entries(BRAND_REGISTRY)) {
    if (config.routePrefix && pathname.startsWith(config.routePrefix)) {
      return key as BrandKey;
    }
  }

  // Default to wolf-fund
  return "wolf-fund";
}

function applyBrandTheme(brand: BrandConfig) {
  const root = document.documentElement;
  
  // Apply theme CSS variables
  Object.entries(brand.theme).forEach(([key, value]) => {
    const cssVarName = `--${key.replace(/([A-Z])/g, "-$1").toLowerCase()}`;
    root.style.setProperty(cssVarName, value);
  });

  // Set brand-specific class for additional styling
  root.setAttribute("data-brand", brand.key);
}

export function BrandProvider({ children }: { children: ReactNode }) {
  const [brandKey, setBrandKey] = useState<BrandKey>("wolf-fund");
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const detectedBrand = detectBrandFromEnvironment();
    setBrandKey(detectedBrand);
    setIsLoading(false);
  }, []);

  useEffect(() => {
    const brand = BRAND_REGISTRY[brandKey] || BRAND_REGISTRY["wolf-fund"];
    applyBrandTheme(brand);
  }, [brandKey]);

  const brand = BRAND_REGISTRY[brandKey] || BRAND_REGISTRY["wolf-fund"];

  const setBrand = (key: BrandKey) => {
    if (BRAND_REGISTRY[key]) {
      setBrandKey(key);
    }
  };

  return (
    <BrandContext.Provider value={{ brand, setBrand, isLoading }}>
      {children}
    </BrandContext.Provider>
  );
}

export function useBrand() {
  const context = useContext(BrandContext);
  if (!context) {
    throw new Error("useBrand must be used within a BrandProvider");
  }
  return context;
}

// Helper to get brand-specific route
export function getBrandRoute(path: string, brandKey?: BrandKey): string {
  const brand = brandKey ? BRAND_REGISTRY[brandKey] : BRAND_REGISTRY["wolf-fund"];
  return `${brand.routePrefix}${path}`;
}
