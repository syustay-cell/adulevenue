// src/motherboard/ai/intel/trendExtractor.ts
// WOLF-FUND.COM – TREND EXTRACTION ENGINE

export type TrendDirection = 'up' | 'down' | 'stable';
export type TrendTimeframe = 'hourly' | 'daily' | 'weekly' | 'monthly';

export interface TrendData {
  metric: string;
  timeframe: TrendTimeframe;
  direction: TrendDirection;
  changePercent: number;
  dataPoints: { timestamp: string; value: number }[];
}

export interface TrendInsight {
  metric: string;
  insight: string;
  confidence: number;
  actionable: boolean;
  suggestedAction?: string;
}

export const TrendExtractor = {
  analyze(dataPoints: { timestamp: string; value: number }[], metric: string): TrendData {
    if (dataPoints.length < 2) {
      return {
        metric,
        timeframe: 'daily',
        direction: 'stable',
        changePercent: 0,
        dataPoints,
      };
    }

    const sorted = [...dataPoints].sort(
      (a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime()
    );

    const first = sorted[0].value;
    const last = sorted[sorted.length - 1].value;
    const changePercent = first !== 0 ? ((last - first) / first) * 100 : 0;

    let direction: TrendDirection = 'stable';
    if (changePercent > 5) direction = 'up';
    else if (changePercent < -5) direction = 'down';

    const timespan = new Date(sorted[sorted.length - 1].timestamp).getTime() - 
                     new Date(sorted[0].timestamp).getTime();
    const hours = timespan / (1000 * 60 * 60);
    
    let timeframe: TrendTimeframe = 'hourly';
    if (hours > 24 * 7) timeframe = 'weekly';
    else if (hours > 24) timeframe = 'daily';

    return {
      metric,
      timeframe,
      direction,
      changePercent: Math.round(changePercent * 10) / 10,
      dataPoints: sorted,
    };
  },

  generateInsights(trends: TrendData[]): TrendInsight[] {
    return trends.map(trend => {
      let insight = '';
      let suggestedAction: string | undefined;
      let actionable = false;

      if (trend.direction === 'up' && trend.changePercent > 20) {
        insight = `${trend.metric} has increased significantly by ${trend.changePercent}%`;
        actionable = true;
        suggestedAction = 'Review capacity and scaling needs';
      } else if (trend.direction === 'down' && trend.changePercent < -20) {
        insight = `${trend.metric} has dropped significantly by ${Math.abs(trend.changePercent)}%`;
        actionable = true;
        suggestedAction = 'Investigate root cause';
      } else {
        insight = `${trend.metric} is ${trend.direction} (${trend.changePercent}% change)`;
      }

      return {
        metric: trend.metric,
        insight,
        confidence: Math.min(100, 50 + trend.dataPoints.length * 2),
        actionable,
        suggestedAction,
      };
    });
  },
};
