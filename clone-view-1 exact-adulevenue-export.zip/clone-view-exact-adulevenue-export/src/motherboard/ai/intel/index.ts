// src/motherboard/ai/intel/index.ts
// Re-export 411/412 intelligence modules

export * from './eventsLogger';
export * from './suggestionEngine';
export * from './anomalyDetector';
export * from './trendExtractor';
