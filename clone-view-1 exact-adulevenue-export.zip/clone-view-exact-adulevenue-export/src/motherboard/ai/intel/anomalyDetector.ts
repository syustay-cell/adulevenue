// src/motherboard/ai/intel/anomalyDetector.ts
// WOLF-FUND.COM – ANOMALY DETECTION ENGINE

export type AnomalyType =
  | 'volume_spike'
  | 'volume_drop'
  | 'error_rate_increase'
  | 'unusual_pattern'
  | 'threshold_breach';

export interface Anomaly {
  id: string;
  type: AnomalyType;
  severity: 'low' | 'medium' | 'high' | 'critical';
  metric: string;
  expected: number;
  actual: number;
  deviation: number;
  detected_at: string;
  description: string;
}

export interface AnomalyRule {
  metric: string;
  threshold: number;
  direction: 'above' | 'below' | 'both';
  severity: 'low' | 'medium' | 'high' | 'critical';
}

const DEFAULT_RULES: AnomalyRule[] = [
  { metric: 'applications_per_hour', threshold: 50, direction: 'above', severity: 'medium' },
  { metric: 'error_rate', threshold: 0.05, direction: 'above', severity: 'high' },
  { metric: 'approval_rate', threshold: 0.3, direction: 'below', severity: 'medium' },
  { metric: 'avg_processing_time', threshold: 300, direction: 'above', severity: 'low' },
];

export const AnomalyDetector = {
  rules: [...DEFAULT_RULES],

  detect(metrics: Record<string, number>): Anomaly[] {
    const anomalies: Anomaly[] = [];
    const now = new Date().toISOString();

    for (const rule of this.rules) {
      const actual = metrics[rule.metric];
      if (actual === undefined) continue;

      const isAnomaly =
        (rule.direction === 'above' && actual > rule.threshold) ||
        (rule.direction === 'below' && actual < rule.threshold) ||
        (rule.direction === 'both' && Math.abs(actual - rule.threshold) > rule.threshold * 0.5);

      if (isAnomaly) {
        const deviation = ((actual - rule.threshold) / rule.threshold) * 100;
        anomalies.push({
          id: `${rule.metric}-${Date.now()}`,
          type: actual > rule.threshold ? 'threshold_breach' : 'unusual_pattern',
          severity: rule.severity,
          metric: rule.metric,
          expected: rule.threshold,
          actual,
          deviation: Math.round(deviation),
          detected_at: now,
          description: `${rule.metric} is ${Math.abs(deviation).toFixed(1)}% ${actual > rule.threshold ? 'above' : 'below'} threshold`,
        });
      }
    }

    return anomalies;
  },

  addRule(rule: AnomalyRule): void {
    this.rules.push(rule);
  },

  removeRule(metric: string): void {
    this.rules = this.rules.filter(r => r.metric !== metric);
  },
};
