// src/motherboard/ai/intel/suggestionEngine.ts
// WOLF-FUND.COM – 412 SUGGESTION ENGINE

import { supabase } from '@/integrations/supabase/client';

export type SuggestionCategory = 
  | 'routing'
  | 'risk'
  | 'performance'
  | 'compliance'
  | 'automation';

export type SuggestionPriority = 'low' | 'medium' | 'high' | 'critical';
export type SuggestionStatus = 'open' | 'applied' | 'dismissed' | 'expired';

export interface Suggestion {
  id: string;
  category: SuggestionCategory;
  priority: SuggestionPriority;
  status: SuggestionStatus;
  title: string;
  description: string;
  action?: string;
  created_at: string;
}

export const SuggestionEngine = {
  async listOpen(): Promise<Suggestion[]> {
    const { data, error } = await supabase
      .from('wolf_suggestions')
      .select('*')
      .eq('status', 'open')
      .order('created_at', { ascending: false });

    if (error) {
      console.warn('[SuggestionEngine] Failed to load:', error);
      return [];
    }

    // Map database fields to Suggestion interface
    // wolf_suggestions table has: id, type, status, reason, suggested_value, current_value, created_at
    return (data || []).map(row => ({
      id: row.id,
      category: (row.type || 'performance') as SuggestionCategory,
      priority: 'medium' as SuggestionPriority,
      status: (row.status || 'open') as SuggestionStatus,
      title: row.reason?.slice(0, 50) || 'Suggestion',
      description: row.reason || '',
      action: row.suggested_value ? JSON.stringify(row.suggested_value) : undefined,
      created_at: row.created_at,
    }));
  },

  async apply(id: string): Promise<void> {
    const { error } = await supabase
      .from('wolf_suggestions')
      .update({ status: 'applied' })
      .eq('id', id);

    if (error) throw error;
  },

  async dismiss(id: string): Promise<void> {
    const { error } = await supabase
      .from('wolf_suggestions')
      .update({ status: 'dismissed' })
      .eq('id', id);

    if (error) throw error;
  },

  async generate(): Promise<Suggestion[]> {
    // Placeholder - would call AI to analyze events and generate suggestions
    return [];
  },
};
