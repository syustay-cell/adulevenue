// src/motherboard/ai/intel/eventsLogger.ts
// WOLF-FUND.COM – 411 INTELLIGENCE EVENTS LOGGER

import { supabase } from '@/integrations/supabase/client';
import type { Json } from '@/integrations/supabase/types';

export type IntelEventType = 'system_start' | 'system_stop' | 'user_action' | 'ai_decision' | 'rule_triggered' | 'anomaly_detected' | 'error';
export type IntelEventSeverity = 'info' | 'warning' | 'error' | 'critical';

export interface IntelEvent {
  type: IntelEventType;
  severity: IntelEventSeverity;
  source: string;
  message: string;
  data?: Json;
  timestamp?: string;
}

export const IntelEventsLogger = {
  async log(event: IntelEvent): Promise<void> {
    try {
      await supabase.from('activity_log').insert([{
        actor: event.source,
        mode: 'INTEL',
        module: 'ai_intel',
        severity: event.severity,
        title: event.type,
        summary: event.message,
        metadata: event.data ?? null,
      }]);
    } catch (err) {
      console.warn('[IntelEventsLogger] Failed:', err);
    }
  },

  async getRecentEvents(limit = 100): Promise<IntelEvent[]> {
    const { data, error } = await supabase
      .from('activity_log')
      .select('*')
      .eq('module', 'ai_intel')
      .order('created_at', { ascending: false })
      .limit(limit);

    if (error) throw error;

    return (data || []).map(row => ({
      type: row.title as IntelEventType,
      severity: row.severity as IntelEventSeverity,
      source: row.actor,
      message: row.summary,
      data: row.metadata as Json,
      timestamp: row.created_at,
    }));
  },
};
