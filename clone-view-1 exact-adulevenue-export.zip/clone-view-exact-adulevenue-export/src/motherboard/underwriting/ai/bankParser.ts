// src/motherboard/underwriting/ai/bankParser.ts
// WOLF-FUND.COM – BANK STATEMENT PARSER

export interface Transaction {
  date: string;
  description: string;
  amount: number;
  type: 'credit' | 'debit';
  category?: string;
}

export interface BankStatementData {
  accountHolder: string;
  bankName: string;
  accountNumber: string;
  periodStart: string;
  periodEnd: string;
  openingBalance: number;
  closingBalance: number;
  transactions: Transaction[];
}

export interface BankSummary {
  totalDeposits: number;
  totalWithdrawals: number;
  averageDailyBalance: number;
  lowestBalance: number;
  negativeDays: number;
  nsfCount: number;
  mcaPayments: { vendor: string; amount: number; frequency: string }[];
  suspiciousDeposits: { date: string; amount: number; description: string }[];
}

export const BankParser = {
  parseTransactions(raw: string): Transaction[] {
    // Placeholder - actual parsing done by AI/OCR
    return [];
  },

  isFundingRelated(description: string): boolean {
    const keywords = [
      'capital', 'funding', 'merchant', 'advance', 'holdings',
      'investments', 'finance', 'credit', 'lending', 'factor', 'receivables'
    ];
    const lower = description.toLowerCase();
    return keywords.some(k => lower.includes(k));
  },

  calculateSummary(data: BankStatementData): BankSummary {
    const { transactions } = data;
    
    let totalDeposits = 0;
    let totalWithdrawals = 0;
    let nsfCount = 0;
    
    transactions.forEach(t => {
      if (t.type === 'credit') totalDeposits += t.amount;
      else totalWithdrawals += Math.abs(t.amount);
      
      if (t.description.toLowerCase().includes('nsf') || 
          t.description.toLowerCase().includes('insufficient')) {
        nsfCount++;
      }
    });

    return {
      totalDeposits,
      totalWithdrawals,
      averageDailyBalance: (data.openingBalance + data.closingBalance) / 2,
      lowestBalance: Math.min(data.openingBalance, data.closingBalance),
      negativeDays: 0,
      nsfCount,
      mcaPayments: this.detectMcaPayments(transactions),
      suspiciousDeposits: this.detectSuspiciousDeposits(transactions),
    };
  },

  detectMcaPayments(transactions: Transaction[]): { vendor: string; amount: number; frequency: string }[] {
    const fundingDebits = transactions.filter(
      t => t.type === 'debit' && this.isFundingRelated(t.description)
    );
    
    const grouped: Record<string, number[]> = {};
    fundingDebits.forEach(t => {
      const key = t.description.slice(0, 20);
      if (!grouped[key]) grouped[key] = [];
      grouped[key].push(Math.abs(t.amount));
    });

    return Object.entries(grouped).map(([vendor, amounts]) => ({
      vendor,
      amount: amounts.reduce((a, b) => a + b, 0) / amounts.length,
      frequency: amounts.length > 20 ? 'daily' : amounts.length > 4 ? 'weekly' : 'monthly',
    }));
  },

  detectSuspiciousDeposits(transactions: Transaction[]): { date: string; amount: number; description: string }[] {
    const avgDeposit = transactions
      .filter(t => t.type === 'credit')
      .reduce((sum, t, _, arr) => sum + t.amount / arr.length, 0);

    return transactions
      .filter(t => t.type === 'credit' && t.amount > avgDeposit * 3)
      .map(t => ({ date: t.date, amount: t.amount, description: t.description }));
  },
};
