// src/motherboard/creditfix/api.ts
// WOLF-FUND.COM – CREDIT FIX API LAYER

import { supabase } from '@/integrations/supabase/client';

export interface CreditClient {
  id: string;
  full_name: string;
  email: string;
  phone: string;
  status: string;
  created_at: string;
  updated_at: string;
}

export interface CreditDispute {
  id: string;
  credit_case_id: string;
  bureau: string;
  status: string;
  reason_code: string | null;
  creditor_name: string | null;
  created_at: string;
}

export const CreditFixAPI = {
  async listClients(): Promise<CreditClient[]> {
    const { data, error } = await supabase
      .from('credit_repair_applications')
      .select('id, full_name, email, phone, status, created_at, updated_at')
      .order('created_at', { ascending: false });
    if (error) throw error;
    return data || [];
  },

  async getClient(id: string): Promise<CreditClient | null> {
    const { data, error } = await supabase
      .from('credit_repair_applications')
      .select('*')
      .eq('id', id)
      .single();
    if (error) throw error;
    return data;
  },

  async listDisputesForClient(caseId: string): Promise<CreditDispute[]> {
    const { data, error } = await supabase
      .from('credit_disputes')
      .select('id, credit_case_id, bureau, status, reason_code, creditor_name, created_at')
      .eq('credit_case_id', caseId)
      .order('created_at', { ascending: false });
    if (error) throw error;
    return data || [];
  },

  async listCases() {
    const { data, error } = await supabase
      .from('credit_repair_cases')
      .select('*')
      .order('created_at', { ascending: false });
    if (error) throw error;
    return data || [];
  },

  async getCaseStats() {
    const { data, error } = await supabase
      .from('credit_repair_cases')
      .select('status');
    if (error) throw error;
    
    const stats = {
      total: data?.length || 0,
      intake: 0,
      docs_pending: 0,
      investigation: 0,
      completed: 0,
    };
    
    data?.forEach(c => {
      if (c.status === 'intake') stats.intake++;
      else if (c.status === 'docs_pending') stats.docs_pending++;
      else if (c.status === 'investigation') stats.investigation++;
      else if (c.status === 'completed') stats.completed++;
    });
    
    return stats;
  },
};
