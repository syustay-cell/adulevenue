// src/motherboard/creditfix/ai/disputeGenerator.ts
// WOLF-FUND.COM – AI DISPUTE LETTER GENERATOR

import { supabase } from '@/integrations/supabase/client';

export interface DisputeGenerationRequest {
  clientId: string;
  bureau: 'experian' | 'equifax' | 'transunion';
  violationType: string;
  creditorName?: string;
  accountNumber?: string;
}

export interface GeneratedDispute {
  subject: string;
  body: string;
  bureau: string;
  fcra_section?: string;
  fdcpa_section?: string;
}

export const DisputeGenerator = {
  async generateDispute(request: DisputeGenerationRequest): Promise<GeneratedDispute> {
    const { data, error } = await supabase.functions.invoke('generate-dispute-letter', {
      body: request,
    });

    if (error) throw error;
    if (!data?.ok) throw new Error(data?.message || 'Failed to generate dispute');

    return data.data as GeneratedDispute;
  },

  getTemplates(): string[] {
    return [
      'fcra_609_inquiry_removal',
      'fcra_611_investigation_demand',
      'fdcpa_807_false_representation',
      'fdcpa_812_furnisher_violation',
      'metro2_inaccurate_reporting',
      'identity_theft_affidavit',
    ];
  },

  analyzeCompliance(disputeText: string): { fcra: string[]; fdcpa: string[] } {
    // Placeholder for AI compliance analysis
    return {
      fcra: ['§609', '§611'],
      fdcpa: ['§807', '§812'],
    };
  },
};
