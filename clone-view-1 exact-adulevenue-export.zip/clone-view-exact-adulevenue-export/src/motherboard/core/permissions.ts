// src/motherboard/core/permissions.ts
// WOLF-FUND.COM – PERMISSIONS LAYER
// Role-based permission checks

export type WolfPermission =
  | 'view_motherboard'
  | 'view_underwriting'
  | 'view_creditfix'
  | 'view_events'
  | 'view_legal'
  | 'view_funder_portal'
  | 'view_iso_portal'
  | 'manage_users'
  | 'manage_settings'
  | 'manage_rules'
  | 'execute_funding'
  | 'approve_disputes'
  | 'access_vault'
  | 'export_data';

export const ROLE_PERMISSIONS: Record<string, WolfPermission[]> = {
  owner: [
    'view_motherboard',
    'view_underwriting',
    'view_creditfix',
    'view_events',
    'view_legal',
    'view_funder_portal',
    'view_iso_portal',
    'manage_users',
    'manage_settings',
    'manage_rules',
    'execute_funding',
    'approve_disputes',
    'access_vault',
    'export_data',
  ],
  admin: [
    'view_underwriting',
    'view_creditfix',
    'view_events',
    'manage_users',
    'manage_settings',
    'execute_funding',
    'approve_disputes',
    'export_data',
  ],
  underwriter: [
    'view_underwriting',
    'execute_funding',
  ],
  credit_repair_specialist: [
    'view_creditfix',
    'approve_disputes',
  ],
  legal: [
    'view_legal',
    'access_vault',
  ],
  legal_worker: [
    'view_legal',
    'access_vault',
  ],
  worker: [
    'view_creditfix',
  ],
  iso: [
    'view_iso_portal',
  ],
  funder: [
    'view_funder_portal',
  ],
};

export function hasPermission(role: string, permission: WolfPermission): boolean {
  const perms = ROLE_PERMISSIONS[role] || [];
  return perms.includes(permission);
}

export function hasAllPermissions(role: string, permissions: WolfPermission[]): boolean {
  return permissions.every(p => hasPermission(role, p));
}

export function hasAnyPermission(role: string, permissions: WolfPermission[]): boolean {
  return permissions.some(p => hasPermission(role, p));
}
