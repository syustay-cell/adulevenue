// src/motherboard/core/motherConfig.ts
// WOLF-FUND.COM – MOTHERBOARD CORE CONFIGURATION
// Single source of truth for role → dashboard → permissions

export type WolfRole =
  | 'super_owner'
  | 'owner'
  | 'ceo'
  | 'cfo'
  | 'clo'
  | 'tenant_owner'
  | 'tenant_admin'
  | 'admin'
  | 'win_director'
  | 'underwriter'
  | 'legal_worker'
  | 'credit_repair_specialist'
  | 'legal'
  | 'wolf_worker'
  | 'worker'
  | 'partner_factory'
  | 'tenant_worker'
  | 'partner_worker'
  | 'merchant_services_partner'
  | 'funder'
  | 'investor'
  | 'gov_donor'
  | 'iso'
  | 'iso_partner'
  | 'merchant'
  | 'client'
  | 'user';

export interface DashboardRoute {
  path: string;
  label: string;
  icon?: string;
}

export interface RoleDashboardConfig {
  defaultRoute: string;
  menu: DashboardRoute[];
}

export const MOTHERBOARD_CONFIG: Record<string, RoleDashboardConfig> = {
  owner: {
    defaultRoute: '/owner/motherboard',
    menu: [
      { path: '/owner/motherboard', label: 'Motherboard' },
      { path: '/owner/underwriting', label: 'Underwriting' },
      { path: '/owner/creditfix', label: 'Credit Fix' },
      { path: '/owner/events', label: 'Events' },
      { path: '/owner/settings', label: 'Settings' },
    ],
  },
  ceo: {
    defaultRoute: '/ceo',
    menu: [
      { path: '/ceo', label: 'Command Center' },
      { path: '/lead-engine', label: 'Lead Engine' },
      { path: '/owner/motherboard', label: 'Motherboard' },
    ],
  },
  cfo: {
    defaultRoute: '/cfo',
    menu: [
      { path: '/cfo', label: 'Finance & Escrow' },
      { path: '/admin/billing', label: 'Billing' },
      { path: '/admin/dashboard', label: 'Admin Dashboard' },
    ],
  },
  clo: {
    defaultRoute: '/clo',
    menu: [
      { path: '/clo', label: 'Contracts & Compliance' },
      { path: '/legal/dashboard', label: 'Legal Dashboard' },
      { path: '/legal/queue', label: 'Legal Queue' },
    ],
  },
  admin: {
    defaultRoute: '/admin/dashboard',
    menu: [
      { path: '/admin/dashboard', label: 'Dashboard' },
      { path: '/admin/underwriting', label: 'Underwriting' },
      { path: '/admin/users', label: 'Users' },
      { path: '/admin/settings', label: 'Settings' },
    ],
  },
  worker: {
    defaultRoute: '/worker/dashboard',
    menu: [
      { path: '/worker/dashboard', label: 'Dashboard' },
      { path: '/worker/queue', label: 'My Queue' },
      { path: '/worker/creditfix', label: 'Credit Fix' },
    ],
  },
  win_director: {
    defaultRoute: '/win-director',
    menu: [
      { path: '/win-director', label: 'WIN Director' },
      { path: '/worker/dashboard', label: 'Worker Dashboard' },
    ],
  },
  partner_factory: {
    defaultRoute: '/partner/factory',
    menu: [
      { path: '/partner/factory', label: 'Factory Queue' },
      { path: '/partner/dashboard', label: 'Partner Dashboard' },
    ],
  },
  iso: {
    defaultRoute: '/iso/dashboard',
    menu: [
      { path: '/iso/dashboard', label: 'Dashboard' },
      { path: '/iso/pipeline', label: 'Pipeline' },
      { path: '/iso/deals', label: 'Deals' },
      { path: '/iso/commissions', label: 'Commissions' },
    ],
  },
  funder: {
    defaultRoute: '/funder/portal',
    menu: [
      { path: '/funder/portal', label: 'Portal' },
      { path: '/funder/deals', label: 'Deals' },
    ],
  },
  investor: {
    defaultRoute: '/investor',
    menu: [
      { path: '/investor', label: 'Portfolio' },
      { path: '/funder/portal', label: 'Funder Portal' },
    ],
  },
  gov_donor: {
    defaultRoute: '/donors',
    menu: [
      { path: '/donors', label: 'Impact Projects' },
      { path: '/tlc/dashboard', label: 'TLC Dashboard' },
    ],
  },
  legal: {
    defaultRoute: '/legal/dashboard',
    menu: [
      { path: '/legal/dashboard', label: 'Dashboard' },
      { path: '/legal/cases', label: 'Cases' },
      { path: '/legal/settings', label: 'Settings' },
    ],
  },
  credit_repair_specialist: {
    defaultRoute: '/credit-specialist-dashboard',
    menu: [
      { path: '/credit-specialist-dashboard', label: 'Dashboard' },
      { path: '/credit-fix/studio', label: 'Studio' },
    ],
  },
};

export function getDashboardConfig(role: string): RoleDashboardConfig {
  return MOTHERBOARD_CONFIG[role] || MOTHERBOARD_CONFIG.worker;
}

export function getDefaultRoute(role: string): string {
  return getDashboardConfig(role).defaultRoute;
}
