// src/motherboard/core/motherEvents.ts
// WOLF-FUND.COM – MOTHERBOARD EVENT LOGGING

import { supabase } from '@/integrations/supabase/client';
import type { Json } from '@/integrations/supabase/types';

export type WolfEventType = 'login' | 'logout' | 'case_created' | 'case_updated' | 'dispute_created' | 'offer_generated' | 'error' | 'system';
export type WolfEventSeverity = 'info' | 'warning' | 'error' | 'critical';

export interface WolfEventPayload {
  type: WolfEventType;
  severity?: WolfEventSeverity;
  actor_id?: string;
  entity_type?: string;
  summary: string;
  meta?: Json;
}

export const WolfEvents = {
  async log(event: WolfEventPayload): Promise<void> {
    try {
      await supabase.from('activity_log').insert([{
        actor: event.actor_id || 'system',
        mode: 'SYSTEM',
        module: event.entity_type || 'motherboard',
        severity: event.severity || 'info',
        title: event.type,
        summary: event.summary,
        metadata: event.meta ?? null,
      }]);
    } catch (err) {
      console.warn('[WolfEvents] Log failed:', err);
    }
  },

  async info(summary: string, meta?: Json): Promise<void> {
    await this.log({ type: 'system', severity: 'info', summary, meta });
  },

  async warn(summary: string, meta?: Json): Promise<void> {
    await this.log({ type: 'system', severity: 'warning', summary, meta });
  },

  async error(summary: string, meta?: Json): Promise<void> {
    await this.log({ type: 'error', severity: 'error', summary, meta });
  },
};
