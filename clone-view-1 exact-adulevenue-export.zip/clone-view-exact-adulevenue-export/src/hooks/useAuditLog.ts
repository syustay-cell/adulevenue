// V25: Audit logging hook for security events

import { useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';

export type AuditAction = 
  | 'route_access'
  | 'vault_access'
  | 'vault_reveal'
  | 'document_download'
  | 'document_view'
  | 'case_status_change'
  | 'puzzle_panel_open'
  | 'export_data'
  | 'sensitive_field_reveal';

interface AuditMeta {
  resource_type?: string;
  resource_id?: string;
  route?: string;
  field_name?: string;
  [key: string]: unknown;
}

export function useAuditLog() {
  const logAction = useCallback(async (
    actionType: AuditAction,
    meta: AuditMeta = {}
  ) => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      await supabase.from('audit_logs').insert([{
        user_id: user.id,
        action_type: actionType,
        resource_type: meta.resource_type || 'unknown',
        resource_id: meta.resource_id || 'unknown',
        changes: JSON.parse(JSON.stringify(meta)),
        user_agent: navigator.userAgent,
      }]);
    } catch (err) {
      console.error('Audit log failed:', err);
    }
  }, []);

  const logRouteAccess = useCallback((route: string) => {
    return logAction('route_access', { route, resource_type: 'route' });
  }, [logAction]);

  const logVaultAccess = useCallback((resourceType: string, resourceId: string) => {
    return logAction('vault_access', { resource_type: resourceType, resource_id: resourceId });
  }, [logAction]);

  const logFieldReveal = useCallback((fieldName: string, resourceType: string, resourceId: string) => {
    return logAction('sensitive_field_reveal', { 
      field_name: fieldName, 
      resource_type: resourceType, 
      resource_id: resourceId 
    });
  }, [logAction]);

  return {
    logAction,
    logRouteAccess,
    logVaultAccess,
    logFieldReveal,
  };
}
