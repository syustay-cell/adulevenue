import { useState, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

export type Lead = {
  id: string;
  full_name: string | null;
  email: string | null;
  phone: string | null;
  business_name: string | null;
  ai_score: number | null;
  dialer_status: string;
  current_owner_id: string | null;
  current_owner_email: string | null;
  lock_expires_at: string | null;
  lock_reason: string | null;
  [key: string]: any;
};

export function useDialerSession(workerId: string) {
  const { toast } = useToast();
  const [sessionActive, setSessionActive] = useState(false);
  const [currentLead, setCurrentLead] = useState<Lead | null>(null);
  const [loadingNext, setLoadingNext] = useState(false);

  const loadNextLead = useCallback(async () => {
    setLoadingNext(true);
    try {
      const { data, error } = await supabase.rpc('get_next_lead_for_worker', {
        p_worker_id: workerId,
      });

      if (error) throw error;

      if (!data) {
        toast({
          title: 'No more leads',
          description: 'Queue is empty. Great work!',
        });
        setCurrentLead(null);
        return;
      }

      setCurrentLead(data as Lead);
    } catch (e: any) {
      console.error('Failed to load next lead:', e);
      toast({
        variant: 'destructive',
        title: 'Failed to load next lead',
        description: e.message || 'Please try again',
      });
      setCurrentLead(null);
    } finally {
      setLoadingNext(false);
    }
  }, [workerId, toast]);

  const startSession = useCallback(async () => {
    setSessionActive(true);
    await loadNextLead();
  }, [loadNextLead]);

  const stopSession = useCallback(() => {
    setSessionActive(false);
    setCurrentLead(null);
  }, []);

  const markOutcome = useCallback(
    async (
      outcome: 'no_answer' | 'left_voicemail' | 'connected',
      nextAction: 'next' | 'schedule_callback' | 'convert_to_application' | 'not_interested' | 'dead',
      callbackAt?: string
    ) => {
      if (!currentLead) return;

      try {
        const { error } = await supabase.rpc('mark_call_outcome', {
          p_lead_id: currentLead.id,
          p_worker_id: workerId,
          p_outcome: outcome,
          p_next_action: nextAction,
          p_callback_at: callbackAt ?? null,
        });

        if (error) throw error;

        toast({
          title: 'Outcome saved',
          description: 'Call result recorded successfully',
        });

        // Auto-next if session is active and action is "next"
        if (nextAction === 'next' && sessionActive) {
          await loadNextLead();
        } else {
          setCurrentLead(null);
        }
      } catch (e: any) {
        console.error('Failed to mark outcome:', e);
        toast({
          variant: 'destructive',
          title: 'Failed to save outcome',
          description: e.message || 'Please try again',
        });
      }
    },
    [currentLead, workerId, sessionActive, loadNextLead, toast]
  );

  return {
    sessionActive,
    currentLead,
    loadingNext,
    startSession,
    stopSession,
    loadNextLead,
    markOutcome,
  };
}
