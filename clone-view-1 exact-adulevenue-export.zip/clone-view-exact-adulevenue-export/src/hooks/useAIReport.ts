import { useCallback, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "@/hooks/use-toast";

export type AIReportType =
  | "underwriting"
  | "legal_search"
  | "lien_bankruptcy"
  | "credit_analysis"
  | "lead_enrichment"
  | "research_summary";

export interface AIReport {
  id: string;
  entity_type: string;
  entity_id: string;
  report_type: AIReportType | string;
  title: string | null;
  report_json: Record<string, unknown>;
  report_text: string | null;
  ai_model: string | null;
  provider: string | null;
  first_run_at: string;
  last_run_at: string;
  first_run_cost: number | null;
  last_run_cost: number | null;
  run_count: number;
  created_by: string | null;
  updated_by: string | null;
  created_at: string;
  updated_at: string;
}

interface UseAIReportReturn {
  loading: "view" | "refresh" | null;
  report: AIReport | null;
  error: string | null;
  viewReport: (promptContext?: Record<string, unknown>) => Promise<void>;
  refreshReport: (promptContext?: Record<string, unknown>) => Promise<void>;
  clearReport: () => void;
}

export function useAIReport(
  entityType: string,
  entityId: string,
  reportType: AIReportType | string
): UseAIReportReturn {
  const [loading, setLoading] = useState<"view" | "refresh" | null>(null);
  const [report, setReport] = useState<AIReport | null>(null);
  const [error, setError] = useState<string | null>(null);

  const callApi = useCallback(
    async (mode: "view" | "refresh", promptContext?: Record<string, unknown>) => {
      if (!entityId) {
        setError("No entity ID provided");
        return;
      }

      setLoading(mode);
      setError(null);

      try {
        const { data, error: invokeError } = await supabase.functions.invoke(
          "ai-report-get-or-refresh",
          {
            body: {
              entity_type: entityType,
              entity_id: entityId,
              report_type: reportType,
              mode,
              prompt_context: promptContext || {},
            },
          }
        );

        if (invokeError) {
          console.error("Function invoke error:", invokeError);
          setError("Connection error. Please try again.");
          toast({
            title: "Connection error",
            description: "Please try again",
            variant: "destructive",
          });
          return;
        }

        if (!data?.ok) {
          if (data?.error_code === "NOT_FOUND" && mode === "view") {
            setError("No saved report. Run a new report first.");
            return;
          }

          const errorMsg = data?.message || "AI report failed";
          setError(errorMsg);
          toast({
            title: "Error",
            description: errorMsg,
            variant: "destructive",
          });
          return;
        }

        setReport(data.report);
        setError(null);

        if (mode === "refresh") {
          toast({
            title: "Report updated",
            description: "AI refresh complete.",
          });
        }
      } catch (err) {
        console.error("useAIReport error:", err);
        setError("Something went wrong");
        toast({
          title: "Error",
          description: "Something went wrong",
          variant: "destructive",
        });
      } finally {
        setLoading(null);
      }
    },
    [entityType, entityId, reportType]
  );

  const viewReport = useCallback(
    (promptContext?: Record<string, unknown>) => callApi("view", promptContext),
    [callApi]
  );

  const refreshReport = useCallback(
    (promptContext?: Record<string, unknown>) => callApi("refresh", promptContext),
    [callApi]
  );

  const clearReport = useCallback(() => {
    setReport(null);
    setError(null);
  }, []);

  return {
    loading,
    report,
    error,
    viewReport,
    refreshReport,
    clearReport,
  };
}
