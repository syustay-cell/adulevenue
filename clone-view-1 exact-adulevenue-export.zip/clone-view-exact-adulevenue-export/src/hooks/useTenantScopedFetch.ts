// Hook for tenant-scoped API fetches with super_owner override
import { useCallback } from "react";
import { useUserRoles } from "@/hooks/useUserRoles";
import { useTenant } from "@/hooks/useTenant";
import { getHighestRole } from "@/lib/roleHierarchy";
import { getStoredMode } from "@/contexts/OperationalContext";

interface TenantScopedFetchOptions {
  viewAsTenantId?: string | null;
}

export function useTenantScopedFetch(options: TenantScopedFetchOptions = {}) {
  const { roles } = useUserRoles();
  const { currentTenantId } = useTenant();
  const { viewAsTenantId } = options;

  const highestRole = getHighestRole(roles || []);
  const isSuperOwner = highestRole === 'owner' || highestRole === 'super_owner';
  const isGodModeEnabled = getStoredMode() === "GOD";

  // Get effective tenant ID for queries
  const getEffectiveTenantId = useCallback((): string | null => {
    // Super owner viewing as a specific tenant
    if (isSuperOwner && viewAsTenantId) {
      return viewAsTenantId;
    }
    // Super owner without view-as: cross-tenant ONLY when God mode is explicitly ON
    if (isSuperOwner) return isGodModeEnabled ? null : currentTenantId;
    // Regular user: use their tenant
    return currentTenantId;
  }, [isSuperOwner, viewAsTenantId, currentTenantId, isGodModeEnabled]);

  return {
    isSuperOwner,
    isGodModeEnabled,
    currentTenantId,
    effectiveTenantId: getEffectiveTenantId(),
    getEffectiveTenantId,
  };
}
