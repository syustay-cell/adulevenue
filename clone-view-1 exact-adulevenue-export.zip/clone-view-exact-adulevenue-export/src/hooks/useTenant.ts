// src/hooks/useTenant.ts - Phase 4: Get current user's tenant_id from wf_tenant_users

import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";

interface UseTenantState {
  loading: boolean;
  currentTenantId: string | null;
  error: string | null;
}

/**
 * Hook to fetch the current user's tenant_id from wf_tenant_users
 * Returns the first tenant_id found (preferring is_primary=true)
 */
export function useTenant(): UseTenantState {
  const [state, setState] = useState<UseTenantState>({
    loading: true,
    currentTenantId: null,
    error: null,
  });

  useEffect(() => {
    let cancelled = false;

    const load = async () => {
      setState((prev) => ({ ...prev, loading: true, error: null }));
      try {
        const {
          data: { user },
          error: userError,
        } = await supabase.auth.getUser();

        if (userError || !user) {
          if (cancelled) return;
          setState({
            loading: false,
            currentTenantId: null,
            error: userError ? userError.message : null,
          });
          return;
        }

        // Try to get primary tenant first
        const { data: primaryData, error: primaryError } = await supabase
          .from("wf_tenant_users")
          .select("tenant_id")
          .eq("user_id", user.id)
          .eq("is_primary", true)
          .limit(1)
          .maybeSingle();

        if (cancelled) return;

        if (primaryData?.tenant_id) {
          setState({
            loading: false,
            currentTenantId: primaryData.tenant_id,
            error: null,
          });
          return;
        }

        // Fallback: get any tenant
        const { data: anyData, error: anyError } = await supabase
          .from("wf_tenant_users")
          .select("tenant_id")
          .eq("user_id", user.id)
          .limit(1)
          .maybeSingle();

        if (cancelled) return;

        if (anyError) {
          setState({
            loading: false,
            currentTenantId: null,
            error: anyError.message,
          });
          return;
        }

        setState({
          loading: false,
          currentTenantId: anyData?.tenant_id ?? null,
          error: null,
        });
      } catch (err) {
        if (cancelled) return;
        setState({
          loading: false,
          currentTenantId: null,
          error: err instanceof Error ? err.message : "Unknown error",
        });
      }
    };

    load();
    return () => {
      cancelled = true;
    };
  }, []);

  return state;
}
