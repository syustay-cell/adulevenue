import { useState, useEffect, useCallback } from 'react';
import { 
  getPendingSuggestions, 
  applySuggestion, 
  rejectSuggestion,
  type OptimizationSuggestion 
} from '@/lib/optimizationSuggestions';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

export function useOptimizationSuggestions() {
  const [suggestions, setSuggestions] = useState<OptimizationSuggestion[]>([]);
  const [loading, setLoading] = useState(true);
  const [processing, setProcessing] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const data = await getPendingSuggestions();
      setSuggestions(data);
    } catch (err) {
      console.error('[useOptimizationSuggestions] Failed to load:', err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const handleApply = useCallback(async (suggestionId: string) => {
    setProcessing(suggestionId);
    try {
      const { data: userData } = await supabase.auth.getUser();
      if (!userData?.user?.id) {
        toast.error('Not authenticated');
        return;
      }

      const result = await applySuggestion(suggestionId, userData.user.id);
      if (result.success) {
        toast.success('Suggestion applied successfully');
        setSuggestions(prev => prev.filter(s => s.id !== suggestionId));
      } else {
        toast.error(result.error || 'Failed to apply suggestion');
      }
    } catch (err) {
      toast.error('Failed to apply suggestion');
    } finally {
      setProcessing(null);
    }
  }, []);

  const handleReject = useCallback(async (suggestionId: string) => {
    setProcessing(suggestionId);
    try {
      const { data: userData } = await supabase.auth.getUser();
      if (!userData?.user?.id) {
        toast.error('Not authenticated');
        return;
      }

      const result = await rejectSuggestion(suggestionId, userData.user.id);
      if (result.success) {
        toast.success('Suggestion rejected');
        setSuggestions(prev => prev.filter(s => s.id !== suggestionId));
      } else {
        toast.error(result.error || 'Failed to reject suggestion');
      }
    } catch (err) {
      toast.error('Failed to reject suggestion');
    } finally {
      setProcessing(null);
    }
  }, []);

  return {
    suggestions,
    loading,
    processing,
    refresh: load,
    apply: handleApply,
    reject: handleReject,
  };
}
