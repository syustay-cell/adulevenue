import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";

export function useFeatureFlag(flagKey: string) {
  const [enabled, setEnabled] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let active = true;

    async function loadFlag() {
      try {
        setLoading(true);
        const { data, error: queryError } = await supabase
          .from("wolf_feature_flags")
          .select("is_enabled")
          .eq("feature_key", flagKey)
          .maybeSingle();

        if (!active) return;

        if (queryError) {
          console.error("[useFeatureFlag] query error", queryError);
          setError(queryError.message);
          setEnabled(false);
        } else {
          setEnabled(Boolean(data?.is_enabled));
          setError(null);
        }
      } catch (err: any) {
        if (!active) return;
        console.error("[useFeatureFlag] runtime error", err);
        setError(err?.message ?? "Unknown error");
        setEnabled(false);
      } finally {
        if (active) {
          setLoading(false);
        }
      }
    }

    loadFlag();
    return () => {
      active = false;
    };
  }, [flagKey]);

  return { enabled, loading, error };
}
