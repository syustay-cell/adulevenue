/**
 * Card TTS Hook - Per-tile audio summaries for Wolf Motherboard
 * Provides cleaner voice with better rate/pitch for short card summaries
 */

/**
 * Get preferred voice for TTS - tries to find a more natural voice
 */
function getPreferredVoice(): SpeechSynthesisVoice | null {
  if (typeof window === "undefined" || !("speechSynthesis" in window)) return null;
  
  const voices = window.speechSynthesis.getVoices();
  if (!voices || !voices.length) return null;

  // Try to pick a good English voice (browser-dependent)
  const preferred =
    voices.find((v) => /Google US English|Microsoft .* English/i.test(v.name)) ||
    voices.find((v) => v.lang.startsWith("en-US")) ||
    voices[0];

  return preferred || null;
}

/**
 * Play a short summary for a card/tile
 * @param text - The text to speak
 * @param options - Optional rate and pitch overrides
 */
export function playCardSummary(
  text: string, 
  options?: { rate?: number; pitch?: number }
) {
  if (typeof window === "undefined" || !("speechSynthesis" in window)) return;

  const synth = window.speechSynthesis;
  synth.cancel(); // Stop any current speech

  const utterance = new SpeechSynthesisUtterance(text);
  
  const voice = getPreferredVoice();
  if (voice) {
    utterance.voice = voice;
  }

  // Slightly faster + crisp for short card summaries
  utterance.rate = options?.rate ?? 1.0;
  utterance.pitch = options?.pitch ?? 1.02;
  utterance.volume = 1.0;
  utterance.lang = "en-US";

  synth.speak(utterance);
}

/**
 * Stop any current speech
 */
export function stopCardSummary() {
  if (typeof window === "undefined" || !("speechSynthesis" in window)) return;
  window.speechSynthesis.cancel();
}

/**
 * Speak text with better voice selection for longer content
 * @param text - The text to speak
 */
export function speakText(text: string) {
  if (typeof window === "undefined" || !("speechSynthesis" in window)) return;

  const synth = window.speechSynthesis;
  synth.cancel();

  const utterance = new SpeechSynthesisUtterance(text);

  const voice = getPreferredVoice();
  if (voice) {
    utterance.voice = voice;
  }

  // Tuned to sound less robotic than default
  utterance.rate = 0.9;
  utterance.pitch = 1.05;
  utterance.volume = 1.0;
  utterance.lang = "en-US";

  synth.speak(utterance);
}
