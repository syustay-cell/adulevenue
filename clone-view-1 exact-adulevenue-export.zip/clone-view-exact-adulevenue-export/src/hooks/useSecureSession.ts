// V25: Secure session validation hook

import { useEffect, useState, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { generateDeviceFingerprint, getCachedFingerprint } from '@/lib/sessionFingerprint';
import { useToast } from '@/hooks/use-toast';

interface SecureSessionState {
  isValid: boolean;
  isLoading: boolean;
  riskScore: number;
  sessionId: string | null;
}

export function useSecureSession() {
  const [state, setState] = useState<SecureSessionState>({
    isValid: true,
    isLoading: true,
    riskScore: 0,
    sessionId: null,
  });
  const { toast } = useToast();

  const validateSession = useCallback(async () => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        setState({ isValid: false, isLoading: false, riskScore: 0, sessionId: null });
        return;
      }

      const fingerprint = getCachedFingerprint() || await generateDeviceFingerprint();
      const storedSessionId = sessionStorage.getItem('wolf_session_id');

      if (!storedSessionId) {
        setState({ isValid: true, isLoading: false, riskScore: 0, sessionId: null });
        return;
      }

      const { data, error } = await supabase.functions.invoke('wolf-session-validate', {
        body: {
          session_id: storedSessionId,
          device_fingerprint: fingerprint,
        },
      });

      if (error || !data?.ok) {
        if (data?.error_code === 'SESSION_REVOKED' || data?.error_code === 'HIGH_RISK_SESSION') {
          toast({
            title: 'Session Terminated',
            description: data?.message || 'Your session has been terminated for security reasons.',
            variant: 'destructive',
          });
          await supabase.auth.signOut();
          setState({ isValid: false, isLoading: false, riskScore: 100, sessionId: null });
          return;
        }
      }

      setState({
        isValid: data?.ok ?? true,
        isLoading: false,
        riskScore: data?.risk_score ?? 0,
        sessionId: storedSessionId,
      });
    } catch (err) {
      console.error('Session validation error:', err);
      setState(prev => ({ ...prev, isLoading: false }));
    }
  }, [toast]);

  useEffect(() => {
    validateSession();

    // Validate periodically (every 5 minutes)
    const interval = setInterval(validateSession, 5 * 60 * 1000);
    return () => clearInterval(interval);
  }, [validateSession]);

  return {
    ...state,
    revalidate: validateSession,
  };
}
