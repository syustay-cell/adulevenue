import { useState, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import type { Database } from '@/integrations/supabase/types';

type Lead = Database['public']['Tables']['leads']['Row'];

export type DialOutcome = 
  | 'no_answer' 
  | 'voicemail' 
  | 'answered' 
  | 'bad_number' 
  | 'wrong_number' 
  | 'disconnected' 
  | 'interested' 
  | 'not_interested';

// Outcomes that should bounce lead back to Research queue
const BOUNCE_BACK_OUTCOMES: DialOutcome[] = ['bad_number', 'wrong_number', 'disconnected'];

export function useCallSession(workerId: string | null) {
  const { toast } = useToast();
  const [active, setActive] = useState(false);
  const [currentLead, setCurrentLead] = useState<Lead | null>(null);
  const [loading, setLoading] = useState(false);
  const [callStartTime, setCallStartTime] = useState<number | null>(null);

  const fetchNextLead = useCallback(async () => {
    if (!workerId) return;
    
    setLoading(true);
    try {
      const { data, error } = await supabase.rpc('get_next_lead_for_agent', {
        p_agent_id: workerId
      });

      if (error) throw error;

      const leads = data as Lead[] | null;
      
      if (!leads || leads.length === 0) {
        setCurrentLead(null);
        if (active) {
          toast({
            title: "No more leads",
            description: "You've completed all leads in the queue.",
          });
        }
        return;
      }

      setCurrentLead(leads[0]);
    } catch (error: any) {
      console.error('Error fetching lead:', error);
      toast({
        variant: "destructive",
        title: "Failed to load lead",
        description: error.message,
      });
    } finally {
      setLoading(false);
    }
  }, [workerId, active, toast]);

  const start = useCallback(async () => {
    setActive(true);
    await fetchNextLead();
  }, [fetchNextLead]);

  const stop = useCallback(() => {
    setActive(false);
    setCurrentLead(null);
    setCallStartTime(null);
  }, []);

  const startCall = useCallback(() => {
    if (!currentLead?.phone) {
      toast({
        variant: "destructive",
        title: "No phone number",
        description: "This lead has no phone number.",
      });
      return;
    }
    setCallStartTime(Date.now());
    window.location.href = `tel:${currentLead.phone.replace(/[^0-9+]/g, '')}`;
  }, [currentLead, toast]);

  const recordOutcome = useCallback(async (outcome: DialOutcome) => {
    if (!currentLead) return;

    setLoading(true);
    try {
      const duration = callStartTime ? Math.round((Date.now() - callStartTime) / 1000) : null;
      const isBounceBack = BOUNCE_BACK_OUTCOMES.includes(outcome);

      // Record call attempt via RPC
      const { error } = await supabase.rpc('record_call_attempt', {
        p_lead_id: currentLead.id,
        p_outcome: outcome,
        p_duration_seconds: duration,
        p_notes: null
      });

      if (error) throw error;

      // If bounce-back outcome, route lead back to Research
      if (isBounceBack) {
        const { error: updateError } = await supabase
          .from('leads')
          .update({
            phone_invalid: true,
            missing_phone: true,
            import_bucket: 'research',
            route: 'research',
            research_status: 'pending',
            research_completed_at: null,
            last_dial_disposition: outcome,
            dial_attempts: ((currentLead as any).dial_attempts || 0) + 1,
            updated_at: new Date().toISOString(),
          })
          .eq('id', currentLead.id);

        if (updateError) throw updateError;

        toast({
          title: "Sent to Research",
          description: "Phone marked invalid. Lead returned to Research Queue for cleanup.",
        });
      } else {
        // Update dial tracking for non-bounce outcomes
        await supabase
          .from('leads')
          .update({
            last_dial_disposition: outcome,
            dial_attempts: ((currentLead as any).dial_attempts || 0) + 1,
            updated_at: new Date().toISOString(),
          })
          .eq('id', currentLead.id);

        // Lock lead if interested (7 days)
        if (outcome === 'interested' && workerId) {
          await supabase.rpc('lock_lead_for_agent', {
            p_lead_id: currentLead.id,
            p_days: 7
          });
        }

        toast({
          title: "Call recorded",
          description: `Outcome: ${outcome.replace(/_/g, ' ')}`,
        });
      }

      setCallStartTime(null);

      // Auto-advance to next lead if dialer is still active
      if (active) {
        await fetchNextLead();
      }
    } catch (error: any) {
      console.error('Error recording outcome:', error);
      toast({
        variant: "destructive",
        title: "Failed to record call",
        description: error.message,
      });
    } finally {
      setLoading(false);
    }
  }, [currentLead, active, workerId, callStartTime, fetchNextLead, toast]);

  const lockLead = useCallback(async (days: number = 7) => {
    if (!currentLead) return;

    try {
      const { error } = await supabase.rpc('lock_lead_for_agent', {
        p_lead_id: currentLead.id,
        p_days: days
      });

      if (error) throw error;

      toast({
        title: "Lead locked",
        description: `You have exclusive rights to this lead for ${days} days.`,
      });

      await fetchNextLead();
    } catch (error: any) {
      console.error('Error locking lead:', error);
      toast({
        variant: "destructive",
        title: "Failed to lock lead",
        description: error.message,
      });
    }
  }, [currentLead, fetchNextLead, toast]);

  return {
    active,
    currentLead,
    loading,
    start,
    stop,
    startCall,
    recordOutcome,
    lockLead,
    callStartTime
  };
}

export default useCallSession;
