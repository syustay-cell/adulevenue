// src/hooks/useWolfSessionHeartbeat.ts
// V10 / B100: Hook to keep wolf sessions alive via heartbeat

import { useEffect, useRef } from "react";
import { heartbeatSession } from "@/lib/wolfSession";

export function useWolfSessionHeartbeat(sessionId?: string | null) {
  const timerRef = useRef<number | null>(null);

  useEffect(() => {
    if (!sessionId) return;

    const run = async () => {
      try {
        // 30 minute sliding TTL
        await heartbeatSession(sessionId, 30);
      } catch (err) {
        console.error("wolf heartbeat failed:", err);
      }
    };

    // run once immediately
    run();

    // then every 5 minutes
    const id = window.setInterval(run, 5 * 60 * 1000);
    timerRef.current = id;

    return () => {
      if (timerRef.current) {
        window.clearInterval(timerRef.current);
      }
    };
  }, [sessionId]);
}
