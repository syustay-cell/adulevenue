import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "@/hooks/use-toast";
import { logDealEvent, DEAL_EVENT_TYPES } from "@/lib/deals/logDealEvent";

interface OfferData {
  dealId: string;
  funderId: string;
  approvedAmount: number;
  factorRate: number;
  termDays: number;
  paymentFrequency: string;
  tenantId?: string;
}

export function useSubmitOffer() {
  const qc = useQueryClient();

  return useMutation({
    mutationFn: async (offer: OfferData) => {
      const paybackAmount = offer.approvedAmount * offer.factorRate;
      const dailyPayment = paybackAmount / offer.termDays;

      // Insert offer into deal_offers
      const { error: offerError } = await supabase
        .from("deal_offers")
        .insert({
          deal_id: offer.dealId,
          funder_id: offer.funderId,
          tenant_id: offer.tenantId,
          approved_amount: offer.approvedAmount,
          factor_rate: offer.factorRate,
          payback_amount: paybackAmount,
          term_days: offer.termDays,
          payment_frequency: offer.paymentFrequency,
          daily_payment: dailyPayment,
          status: "pending",
          expires_at: new Date(
            Date.now() + 7 * 24 * 60 * 60 * 1000
          ).toISOString(),
        });

      if (offerError) throw offerError;

      // Update deal_funder_assignments status
      await supabase
        .from("deal_funder_assignments")
        .update({
          status: "offer_submitted",
          offer_amount: offer.approvedAmount,
          offer_factor_rate: offer.factorRate,
        })
        .eq("deal_id", offer.dealId)
        .eq("funder_user_id", offer.funderId);

      // Log event to deal_events using helper
      if (offer.tenantId) {
        await logDealEvent({
          dealId: offer.dealId,
          tenantId: offer.tenantId,
          eventType: DEAL_EVENT_TYPES.OFFER_SUBMITTED,
          metadata: {
            funder_id: offer.funderId,
            approved_amount: offer.approvedAmount,
            factor_rate: offer.factorRate,
            term_days: offer.termDays,
            payback_amount: paybackAmount,
            daily_payment: dailyPayment,
          },
        });
      }
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["funder-deals"] });
      qc.invalidateQueries({ queryKey: ["deal-offers"] });
      toast({ title: "Offer submitted successfully" });
    },
    onError: (error: any) => {
      toast({
        title: "Failed to submit offer",
        description: error.message,
        variant: "destructive",
      });
    },
  });
}

export function useFunderOffers(dealId?: string) {
  return useQuery({
    queryKey: ["deal-offers", dealId],
    queryFn: async () => {
      if (!dealId) return [];
      
      const { data } = await supabase
        .from("deal_offers")
        .select("*")
        .eq("deal_id", dealId)
        .order("created_at", { ascending: false });

      return data || [];
    },
    enabled: !!dealId,
  });
}

// Hook to accept an offer
export function useAcceptOffer() {
  const qc = useQueryClient();

  return useMutation({
    mutationFn: async ({ offerId, dealId, tenantId }: { offerId: string; dealId: string; tenantId?: string }) => {
      // Update offer status to accepted
      const { error: offerError } = await supabase
        .from("deal_offers")
        .update({ status: "accepted" })
        .eq("id", offerId);

      if (offerError) throw offerError;

      // Update deal status to offers_received or approved
      await supabase
        .from("deals")
        .update({ status: "approved" })
        .eq("id", dealId);

      // Log event
      if (tenantId) {
        await logDealEvent({
          dealId,
          tenantId,
          eventType: DEAL_EVENT_TYPES.OFFER_ACCEPTED,
          metadata: { offer_id: offerId },
        });
      }
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["deal-offers"] });
      qc.invalidateQueries({ queryKey: ["funder-deals"] });
      toast({ title: "Offer accepted" });
    },
    onError: (error: any) => {
      toast({
        title: "Failed to accept offer",
        description: error.message,
        variant: "destructive",
      });
    },
  });
}
