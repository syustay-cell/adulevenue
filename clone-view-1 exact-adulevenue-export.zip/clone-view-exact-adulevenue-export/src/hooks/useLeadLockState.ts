import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';

export type LeadLock = {
  id: string;
  lead_id: string;
  primary_agent_id: string;
  primary_agent_email: string;
  co_agent_id: string | null;
  co_agent_email: string | null;
  lock_status: string;
  lock_expires_at: string;
  created_at: string;
  updated_at: string;
} | null;

export type LeadLockRequest = {
  id: string;
  lead_id: string;
  from_agent_id: string;
  from_agent_email: string;
  to_agent_id: string;
  to_agent_email: string;
  request_type: 'release' | 'split_50_50';
  status: 'pending' | 'approved' | 'rejected';
  message: string | null;
  created_at: string;
  resolved_at: string | null;
};

export type LeadLockState = {
  lock: LeadLock;
  pending_requests: LeadLockRequest[];
};

export function useLeadLockState(leadId: string | null) {
  const [state, setState] = useState<LeadLockState | null>(null);
  const [loading, setLoading] = useState(false);

  const load = useCallback(async () => {
    if (!leadId) {
      setState(null);
      return;
    }

    setLoading(true);
    try {
      const { data, error } = await supabase.rpc('get_lead_lock_state', {
        p_lead_id: leadId
      });

      if (error) throw error;
      setState(data as LeadLockState);
    } catch (error) {
      console.error('Failed to load lead lock state:', error);
      setState(null);
    } finally {
      setLoading(false);
    }
  }, [leadId]);

  useEffect(() => {
    load();
  }, [load]);

  return { state, loading, reload: load };
}
