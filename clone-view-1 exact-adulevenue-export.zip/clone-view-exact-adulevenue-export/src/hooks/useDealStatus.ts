/**
 * Wolf Fund – Deal Status Management Hooks
 * 444 STEP 2: Funding → Commissions Loop
 */

import { useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "@/hooks/use-toast";
import { logDealEvent, DEAL_EVENT_TYPES } from "@/lib/deals/logDealEvent";
import { markDealFunded } from "@/lib/deals/markDealFunded";

interface UpdateDealStatusParams {
  dealId: string;
  tenantId: string;
  fromStatus: string;
  toStatus: string;
}

interface MarkDealFundedParams {
  dealId: string;
  tenantId: string;
  fundedAmount: number;
  grossCommissionPool?: number;
}

/**
 * Hook for updating deal status with event logging
 */
export function useUpdateDealStatus() {
  const qc = useQueryClient();

  return useMutation({
    mutationFn: async ({ dealId, tenantId, fromStatus, toStatus }: UpdateDealStatusParams) => {
      // Update deal status
      const { error: updateError } = await supabase
        .from("deals")
        .update({ status: toStatus })
        .eq("id", dealId);

      if (updateError) throw updateError;

      // Log status change event
      await logDealEvent({
        dealId,
        tenantId,
        eventType: DEAL_EVENT_TYPES.STATUS_CHANGED,
        metadata: {
          from_status: fromStatus,
          to_status: toStatus,
        },
      });

      return { dealId, toStatus };
    },
    onSuccess: (data) => {
      qc.invalidateQueries({ queryKey: ["deals"] });
      qc.invalidateQueries({ queryKey: ["partner-deals"] });
      qc.invalidateQueries({ queryKey: ["funder-deals"] });
      toast({ title: `Deal status updated to ${data.toStatus}` });
    },
    onError: (error: any) => {
      toast({
        title: "Failed to update deal status",
        description: error.message,
        variant: "destructive",
      });
    },
  });
}

/**
 * Hook for marking a deal as funded and triggering commission calculation
 */
export function useMarkDealFunded() {
  const qc = useQueryClient();

  return useMutation({
    mutationFn: async ({ dealId, fundedAmount, grossCommissionPool }: MarkDealFundedParams) => {
      const result = await markDealFunded({
        dealId,
        fundedAmount,
        grossCommissionPool,
      });

      if (!result.ok) {
        throw new Error(result.error || "Failed to mark deal as funded");
      }

      return result;
    },
    onSuccess: (data) => {
      qc.invalidateQueries({ queryKey: ["deals"] });
      qc.invalidateQueries({ queryKey: ["partner-deals"] });
      qc.invalidateQueries({ queryKey: ["partner-commissions"] });
      qc.invalidateQueries({ queryKey: ["funder-deals"] });
      
      const commissionsCalculated = data.commissions?.ok;
      toast({ 
        title: "Deal marked as funded",
        description: commissionsCalculated 
          ? "Commissions calculated successfully" 
          : "Note: Commission calculation may have failed",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Failed to mark deal as funded",
        description: error.message,
        variant: "destructive",
      });
    },
  });
}

/**
 * Hook for moving a deal to underwriting
 */
export function useMoveToUnderwriting() {
  const qc = useQueryClient();

  return useMutation({
    mutationFn: async ({ dealId, tenantId }: { dealId: string; tenantId: string }) => {
      // Update deal status
      const { error: updateError } = await supabase
        .from("deals")
        .update({ status: "underwriting" })
        .eq("id", dealId);

      if (updateError) throw updateError;

      // Log event
      await logDealEvent({
        dealId,
        tenantId,
        eventType: DEAL_EVENT_TYPES.ASSIGNED_TO_UNDERWRITING,
        metadata: {},
      });

      return { dealId };
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["deals"] });
      toast({ title: "Deal moved to underwriting" });
    },
    onError: (error: any) => {
      toast({
        title: "Failed to move to underwriting",
        description: error.message,
        variant: "destructive",
      });
    },
  });
}

/**
 * Hook for marking a deal as ready for funders
 */
export function useMarkReadyForFunders() {
  const qc = useQueryClient();

  return useMutation({
    mutationFn: async ({ dealId, tenantId }: { dealId: string; tenantId: string }) => {
      // Update deal status
      const { error: updateError } = await supabase
        .from("deals")
        .update({ status: "ready_for_funders" })
        .eq("id", dealId);

      if (updateError) throw updateError;

      // Log event
      await logDealEvent({
        dealId,
        tenantId,
        eventType: DEAL_EVENT_TYPES.READY_FOR_FUNDERS,
        metadata: {},
      });

      return { dealId };
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["deals"] });
      qc.invalidateQueries({ queryKey: ["funder-deals"] });
      toast({ title: "Deal ready for funders" });
    },
    onError: (error: any) => {
      toast({
        title: "Failed to mark ready for funders",
        description: error.message,
        variant: "destructive",
      });
    },
  });
}
