import { useState, useEffect, useCallback } from "react";
import * as tts from "@/lib/tts";

export function useTextToSpeech() {
  const [speaking, setSpeaking] = useState(false);
  const [paused, setPaused] = useState(false);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const unsubscribe = tts.subscribe(() => {
      const state = tts.getState();
      setSpeaking(state.speaking);
      setPaused(state.paused);
      setLoading(state.loading);
    });
    return () => {
      unsubscribe();
    };
  }, []);

  const play = useCallback((text: string, rate = 1.0) => {
    tts.play(text, rate);
  }, []);

  const pause = useCallback(() => {
    tts.pause();
  }, []);

  const resume = useCallback(() => {
    tts.resume();
  }, []);

  const stop = useCallback(() => {
    tts.stop();
  }, []);

  const toggle = useCallback((text: string, rate = 1.0) => {
    tts.toggle(text, rate);
  }, []);

  return {
    speaking,
    paused,
    loading,
    isSupported: tts.isSupported(),
    play,
    pause,
    resume,
    stop,
    toggle,
  };
}
