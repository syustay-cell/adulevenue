import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

// Helper: get current user's tenant
async function getCurrentTenant() {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return null;

  const { data, error } = await supabase
    .from("wf_tenant_users")
    .select("tenant_id, wf_tenants ( id, name )")
    .eq("user_id", user.id)
    .single();

  if (error) {
    // Truthful UI: partner screens depend on tenant membership; surface RLS/config problems
    // instead of silently returning empty dashboards.
    throw new Error(
      error.message ||
        "Unable to load tenant membership. Likely RLS/tenant membership configuration issue."
    );
  }
  return (data as any)?.wf_tenants || null;
}

export function usePartnerStats() {
  return useQuery({
    queryKey: ["partner-stats"],
    queryFn: async () => {
      const tenant = await getCurrentTenant();
      if (!tenant) return null;

      const { data: deals } = await supabase
        .from("deals")
        .select("id, status, funded_amount")
        .eq("tenant_id", tenant.id);

      const total = deals?.length || 0;
      const funded = deals?.filter((d: any) => d.status === "funded").length || 0;
      const volume =
        deals?.reduce(
          (sum: number, d: any) => sum + (d.funded_amount || 0),
          0
        ) || 0;
      const pending =
        deals?.filter(
          (d: any) => !["funded", "declined"].includes(d.status)
        ).length || 0;

      return {
        tenantId: tenant.id,
        tenantName: tenant.name,
        total,
        funded,
        volume,
        pending,
      };
    },
  });
}

export function usePartnerDeals() {
  return useQuery({
    queryKey: ["partner-deals"],
    queryFn: async () => {
      const tenant = await getCurrentTenant();
      if (!tenant) return [];

      const { data } = await supabase
        .from("deals")
        .select(`
          *,
          intake_clients ( full_name, business_name ),
          deal_commissions ( computed_amount, status )
        `)
        .eq("tenant_id", tenant.id)
        .order("created_at", { ascending: false });

      return data || [];
    },
  });
}

export function usePartnerCommissions() {
  return useQuery({
    queryKey: ["partner-commissions"],
    queryFn: async () => {
      const tenant = await getCurrentTenant();
      if (!tenant) return [];

      const { data } = await supabase
        .from("deal_commissions")
        .select(`
          *,
          deals ( status, funded_amount, funded_at )
        `)
        .eq("beneficiary_tenant_id", tenant.id)
        .order("created_at", { ascending: false });

      return data || [];
    },
  });
}

export function usePartnerTeam() {
  return useQuery({
    queryKey: ["partner-team"],
    queryFn: async () => {
      const tenant = await getCurrentTenant();
      if (!tenant) return [];

      const { data } = await supabase
        .from("wf_tenant_users")
        .select("*, profiles(email)")
        .eq("tenant_id", tenant.id);

      return data || [];
    },
  });
}
