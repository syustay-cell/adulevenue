// V25: Anti-screenshot detection and blocking hook

import { useEffect, useCallback, useRef } from 'react';
import { supabase } from '@/integrations/supabase/client';

interface AntiScreenshotOptions {
  enabled?: boolean;
  onAttempt?: (type: string) => void;
}

export function useAntiScreenshot(options: AntiScreenshotOptions = { enabled: true }) {
  const blackoutRef = useRef<HTMLDivElement | null>(null);
  const { enabled = true, onAttempt } = options;

  const logAttempt = useCallback(async (attemptType: string) => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      const sessionId = sessionStorage.getItem('wolf_session_id');

      await supabase.from('wolf_screenshot_attempts').insert({
        user_id: user?.id || null,
        session_id: sessionId || null,
        attempt_type: attemptType,
        page_url: window.location.pathname,
        user_agent: navigator.userAgent,
      });

      onAttempt?.(attemptType);
    } catch (err) {
      console.error('Failed to log screenshot attempt:', err);
    }
  }, [onAttempt]);

  const showBlackout = useCallback(() => {
    if (blackoutRef.current) return;

    const blackout = document.createElement('div');
    blackout.id = 'wolf-security-blackout';
    blackout.style.cssText = `
      position: fixed;
      top: 0;
      left: 0;
      width: 100vw;
      height: 100vh;
      background: #000;
      z-index: 999999;
      display: flex;
      align-items: center;
      justify-content: center;
      color: #fff;
      font-size: 24px;
      font-family: system-ui, sans-serif;
    `;
    blackout.innerHTML = '<span>🔒 Screen capture blocked</span>';
    document.body.appendChild(blackout);
    blackoutRef.current = blackout;

    setTimeout(() => {
      blackout.remove();
      blackoutRef.current = null;
    }, 2000);
  }, []);

  useEffect(() => {
    if (!enabled) return;

    // Keyboard shortcuts detection
    const handleKeyDown = (e: KeyboardEvent) => {
      const isPrintScreen = e.key === 'PrintScreen';
      const isMacScreenshot = e.metaKey && e.shiftKey && (e.key === '3' || e.key === '4' || e.key === '5');
      const isWinSnipping = e.metaKey && e.shiftKey && e.key === 's';
      const isCtrlPrintScreen = e.ctrlKey && e.key === 'PrintScreen';

      if (isPrintScreen || isMacScreenshot || isWinSnipping || isCtrlPrintScreen) {
        e.preventDefault();
        e.stopPropagation();
        showBlackout();
        logAttempt('keyboard_shortcut');
        return false;
      }
    };

    // Visibility change detection (tab switching for screenshot)
    const handleVisibilityChange = () => {
      if (document.hidden) {
        // Blur sensitive content when tab is hidden
        document.querySelectorAll('[data-sensitive]').forEach(el => {
          (el as HTMLElement).style.filter = 'blur(10px)';
        });
      } else {
        document.querySelectorAll('[data-sensitive]').forEach(el => {
          (el as HTMLElement).style.filter = '';
        });
      }
    };

    // Context menu prevention on sensitive elements
    const handleContextMenu = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      if (target.closest('[data-sensitive]')) {
        e.preventDefault();
        logAttempt('context_menu');
      }
    };

    document.addEventListener('keydown', handleKeyDown, true);
    document.addEventListener('visibilitychange', handleVisibilityChange);
    document.addEventListener('contextmenu', handleContextMenu);

    return () => {
      document.removeEventListener('keydown', handleKeyDown, true);
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      document.removeEventListener('contextmenu', handleContextMenu);
    };
  }, [enabled, showBlackout, logAttempt]);

  return { showBlackout, logAttempt };
}
