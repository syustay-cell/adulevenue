import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import type { AppRole } from "@/lib/permissions";

// Re-export AppRole for backward compatibility
export type { AppRole } from "@/lib/permissions";

type UseUserRolesState = {
  loading: boolean;
  user: { id: string; email?: string | null } | null;
  roles: AppRole[];
  error: string | null;
};

/**
 * All valid roles in the Wolf Fund system
 * Extended in Phase 2 to include: owner, legal, tenant_admin, iso_partner
 */
const VALID_ROLES: AppRole[] = [
  'super_owner',
  'owner',
  'ceo',
  'cfo',
  'clo',
  'legal',
  'tenant_admin',
  'admin',
  'win_director',
  'credit_repair_specialist',
  'underwriter',
  'worker',
  'partner_factory',
  'investor',
  'gov_donor',
  'iso_partner',
  'user',
];

/**
 * Hook to fetch and cache user roles from Supabase
 * Only returns approved roles from user_roles table
 * 
 * CRITICAL: Uses getSession() first to ensure session is available,
 * then fetches roles. This prevents race conditions.
 */
export function useUserRoles(): UseUserRolesState {
  const [state, setState] = useState<UseUserRolesState>({
    loading: true,
    user: null,
    roles: [],
    error: null,
  });

  useEffect(() => {
    let cancelled = false;

    const load = async () => {
      setState((prev) => ({ ...prev, loading: true, error: null }));
      
      try {
        // Step 1: Get session first (more reliable than getUser)
        const { data: { session }, error: sessionError } = await supabase.auth.getSession();

        if (cancelled) return;

        if (sessionError || !session) {
          console.log("useUserRoles: No session found", { sessionError });
          setState({
            loading: false,
            user: null,
            roles: [],
            error: sessionError ? sessionError.message : null,
          });
          return;
        }

        const user = session.user;
        console.log("useUserRoles: Session found for", user.email);

        // Step 2: Fetch ALL approved roles for this user
        const { data: rolesData, error: rolesError } = await supabase
          .from("user_roles")
          .select("role, approved")
          .eq("user_id", user.id)
          .eq("approved", true);

        if (cancelled) return;

        if (rolesError) {
          console.error("useUserRoles: Error fetching roles", rolesError);
          setState({
            loading: false,
            user: { id: user.id, email: user.email },
            roles: [],
            error: rolesError.message,
          });
          return;
        }

        // Step 3: Filter to only valid roles
        const roles = (rolesData ?? [])
          .map((r) => r.role as string)
          .filter((r) => VALID_ROLES.includes(r as AppRole)) as AppRole[];

        console.log("useUserRoles: Loaded roles", {
          email: user.email,
          userId: user.id,
          roles,
          rawData: rolesData,
        });

        setState({
          loading: false,
          user: { id: user.id, email: user.email },
          roles,
          error: null,
        });
      } catch (err) {
        if (cancelled) return;
        console.error("useUserRoles: Fatal error", err);
        setState({
          loading: false,
          user: null,
          roles: [],
          error: err instanceof Error ? err.message : "Unknown error",
        });
      }
    };

    load();
    
    return () => {
      cancelled = true;
    };
  }, []);

  return state;
}

/**
 * Utility function to check if user has any of the needed roles
 * @deprecated Use hasRole from @/lib/permissions instead
 */
export function userHasRole(roles: AppRole[], needed: AppRole | AppRole[]) {
  const list = Array.isArray(needed) ? needed : [needed];
  return roles.some((r) => list.includes(r));
}
