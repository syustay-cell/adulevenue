// Hook for Super Owner to "view as" a specific tenant (read-only mirror)
import { useState, useCallback } from "react";
import { useQuery } from "@tanstack/react-query";
import { useUserRoles } from "@/hooks/useUserRoles";
import { getHighestRole } from "@/lib/roleHierarchy";
import { supabase } from "@/integrations/supabase/client";
import { getStoredMode } from "@/contexts/OperationalContext";

export interface ViewAsTenantState {
  viewAsTenantId: string | null;
  viewAsTenantName: string | null;
  isSuperOwner: boolean;
  isGodModeEnabled: boolean;
  isViewingAsTenant: boolean;
  enableViewAs: (tenantId: string, tenantName?: string) => void;
  clearViewAs: () => void;
  allTenants: { id: string; name: string; status: string }[];
  tenantsLoading: boolean;
}

export function useViewAsTenant(): ViewAsTenantState {
  const { roles } = useUserRoles();
  const highestRole = getHighestRole(roles || []);

  const [viewAsTenantId, setViewAsTenantId] = useState<string | null>(null);
  const [viewAsTenantName, setViewAsTenantName] = useState<string | null>(null);

  const isSuperOwner = highestRole === "owner" || highestRole === "super_owner";
  const isGodModeEnabled = getStoredMode() === "GOD";

  const { data: allTenants = [], isLoading: tenantsLoading } = useQuery({
    queryKey: ["all-tenants"],
    queryFn: async () => {
      const { data } = await supabase
        .from("wf_tenants")
        .select("id, name, status")
        .order("name");
      return (data || []) as { id: string; name: string; status: string }[];
    },
    enabled: isSuperOwner && isGodModeEnabled,
  });

  const enableViewAs = useCallback(
    (tenantId: string, tenantName?: string) => {
      if (!isSuperOwner || !isGodModeEnabled) return;
      setViewAsTenantId(tenantId);
      setViewAsTenantName(tenantName || null);
    },
    [isSuperOwner, isGodModeEnabled]
  );

  const clearViewAs = useCallback(() => {
    setViewAsTenantId(null);
    setViewAsTenantName(null);
  }, []);

  return {
    viewAsTenantId,
    viewAsTenantName,
    isSuperOwner,
    isGodModeEnabled,
    isViewingAsTenant: !!viewAsTenantId,
    enableViewAs,
    clearViewAs,
    allTenants,
    tenantsLoading,
  };
}
