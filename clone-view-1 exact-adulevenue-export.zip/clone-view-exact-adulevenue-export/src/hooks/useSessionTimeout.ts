import { useEffect, useCallback, useRef } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useNavigate } from 'react-router-dom';
import { toast } from 'sonner';

interface SessionTimeoutConfig {
  idleTimeoutMinutes: number;
  maxSessionHours: number;
}

const DEFAULT_CONFIG: SessionTimeoutConfig = {
  idleTimeoutMinutes: 30,
  maxSessionHours: 24,
};

export function useSessionTimeout() {
  const navigate = useNavigate();
  const lastActivityRef = useRef<number>(Date.now());
  const sessionStartRef = useRef<number>(Date.now());
  const configRef = useRef<SessionTimeoutConfig>(DEFAULT_CONFIG);
  const timeoutRef = useRef<NodeJS.Timeout | null>(null);

  // Load session settings from database
  const loadConfig = useCallback(async () => {
    try {
      const { data } = await supabase
        .from('wolf_session_settings')
        .select('setting_key, setting_value')
        .in('setting_key', ['idle_timeout_minutes', 'max_session_duration_hours']);

      if (data) {
        data.forEach(row => {
          const value = typeof row.setting_value === 'string' ? row.setting_value : String(row.setting_value);
          if (row.setting_key === 'idle_timeout_minutes') {
            configRef.current.idleTimeoutMinutes = parseInt(value) || 30;
          }
          if (row.setting_key === 'max_session_duration_hours') {
            configRef.current.maxSessionHours = parseInt(value) || 24;
          }
        });
      }
    } catch (err) {
      console.warn('Failed to load session settings, using defaults');
    }
  }, []);

  // Handle logout
  const handleLogout = useCallback(async (reason: string) => {
    try {
      // End session in database
      await supabase.functions.invoke('wolf-session-end', {
        body: { reason }
      });
    } catch (err) {
      console.warn('Failed to end session:', err);
    }

    await supabase.auth.signOut();
    toast.warning(`Session ended: ${reason}`);
    navigate('/auth');
  }, [navigate]);

  // Check session validity
  const checkSession = useCallback(async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    const now = Date.now();
    const idleTime = (now - lastActivityRef.current) / 1000 / 60; // in minutes
    const sessionDuration = (now - sessionStartRef.current) / 1000 / 60 / 60; // in hours

    // Check idle timeout
    if (idleTime >= configRef.current.idleTimeoutMinutes) {
      await handleLogout('Idle timeout');
      return;
    }

    // Check max session duration
    if (sessionDuration >= configRef.current.maxSessionHours) {
      await handleLogout('Session expired');
      return;
    }

    // Schedule next check
    const nextCheckMs = Math.min(
      (configRef.current.idleTimeoutMinutes - idleTime) * 60 * 1000,
      60 * 1000 // Check at least every minute
    );
    
    timeoutRef.current = setTimeout(checkSession, nextCheckMs);
  }, [handleLogout]);

  // Reset activity timer on user interaction
  const resetActivity = useCallback(() => {
    lastActivityRef.current = Date.now();
  }, []);

  useEffect(() => {
    // Load config
    loadConfig();

    // Set session start time
    sessionStartRef.current = Date.now();
    lastActivityRef.current = Date.now();

    // Start checking
    checkSession();

    // Listen for user activity
    const events = ['mousedown', 'keydown', 'touchstart', 'scroll'];
    events.forEach(event => {
      window.addEventListener(event, resetActivity, { passive: true });
    });

    return () => {
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current);
      }
      events.forEach(event => {
        window.removeEventListener(event, resetActivity);
      });
    };
  }, [loadConfig, checkSession, resetActivity]);

  return {
    resetActivity,
    forceLogout: (reason: string) => handleLogout(reason),
  };
}