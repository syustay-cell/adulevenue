import { useCallback, useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";

export interface TenantMembership {
  id: string;
  role: string;
  status: string;
  tenant: {
    id: string;
    name: string;
    slug: string;
    status: string;
    tenant_type: string;
  };
}

export function useTenantMemberships() {
  const [memberships, setMemberships] = useState<TenantMembership[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchMemberships = useCallback(async () => {
    setLoading(true);
    setError(null);

    try {
      const {
        data: { user },
        error: authError,
      } = await supabase.auth.getUser();

      if (authError) throw authError;
      if (!user) {
        setMemberships([]);
        return;
      }

      const { data, error: queryError } = await (supabase as any)
        .from("wolf_tenant_users")
        .select(
          `
            id,
            role,
            status,
            tenant:tenant_id (
              id,
              name,
              slug,
              status,
              tenant_type
            )
          `,
        )
        .eq("user_id", user.id);

      if (queryError) throw queryError;

      const rows = data as Array<{
        id: string;
        role: string;
        status: string;
        tenant: { id: string; name: string; slug: string; status: string; tenant_type: string } | null;
      }> | null;

      setMemberships(
        (rows ?? [])
          .filter((row) => row.tenant !== null)
          .map((row) => ({
            id: row.id,
            role: row.role,
            status: row.status,
            tenant: row.tenant!,
          })),
      );
    } catch (err: any) {
      console.error("[useTenantMemberships] error", err);
      setError(err?.message ?? "Unknown error");
      setMemberships([]);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchMemberships();
  }, [fetchMemberships]);

  return {
    memberships,
    loading,
    error,
    refresh: fetchMemberships,
  };
}
