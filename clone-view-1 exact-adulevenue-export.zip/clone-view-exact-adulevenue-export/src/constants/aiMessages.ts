// Centralized AI error messages for Wolf Fund platform
// Keep all client-facing AI messages here for easy updates

export const AI_OUT_OF_CREDITS_MESSAGE =
  "Error: Wolf AI engines are temporarily paused because internal AI credits are exhausted. Please contact an admin to refill AI usage in the Wolf Fund workspace to resume.";

export const AI_CREDITS_LOW_MESSAGE =
  "AI credits low - some functions may fail. Please contact an admin.";

export const AI_CREDITS_CRITICAL_MESSAGE =
  "AI credits critical - functions may fail.";

export const AI_CREDITS_OK_MESSAGE =
  "AI credits OK";
