// V27: Owner Layout - Owner-only OS shell with sidebar navigation
import React, { ReactNode, useState } from "react";
import { NavLink, useLocation } from "react-router-dom";
import {
  LayoutDashboard,
  Shield,
  Settings,
  Zap,
  FileCheck,
  CreditCard,
  Users,
  ChevronLeft,
  ChevronRight,
  Volume2,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { ProtectedLayout } from "./ProtectedLayout";

interface OwnerLayoutProps {
  title: string;
  children: ReactNode;
}

const ownerNavItems = [
  { to: "/owner/motherboard", label: "Motherboard", icon: LayoutDashboard },
  { to: "/owner/security", label: "Security", icon: Shield },
  { to: "/owner/settings", label: "Settings", icon: Settings },
  { to: "/owner/settings/voice", label: "Voice & TTS", icon: Volume2 },
  { to: "/lead-engine", label: "Lead Engine", icon: Zap },
  { to: "/admin/underwriting", label: "Underwriting", icon: FileCheck },
  { to: "/credit-fix/dashboard", label: "Credit Fix", icon: CreditCard },
  { to: "/funder/portal", label: "Funders", icon: Users },
];

const OwnerSidebar: React.FC<{ collapsed: boolean }> = ({ collapsed }) => {
  const location = useLocation();

  return (
    <nav className="flex-1 overflow-y-auto p-3 space-y-1 text-xs">
      {ownerNavItems.map(({ to, label, icon: Icon }) => {
        const active =
          location.pathname === to ||
          location.pathname.startsWith(to + "/");

        return (
          <NavLink
            key={to}
            to={to}
            className={({ isActive }) =>
              cn(
                "flex items-center gap-2 rounded-md px-3 py-2 transition-colors",
                (isActive || active)
                  ? "bg-slate-800 text-slate-50"
                  : "text-slate-400 hover:text-slate-100 hover:bg-slate-900"
              )
            }
          >
            <Icon className="h-3.5 w-3.5" />
            {!collapsed && <span>{label}</span>}
          </NavLink>
        );
      })}
    </nav>
  );
};

export const OwnerLayout: React.FC<OwnerLayoutProps> = ({ title, children }) => {
  const [collapsed, setCollapsed] = useState(false);

  return (
    <ProtectedLayout
      title={title}
      sidebar={
        <div className="h-full flex flex-col">
          <div className="h-16 border-b border-slate-800 flex items-center justify-between px-3">
            {!collapsed && (
              <span className="text-[11px] font-semibold uppercase tracking-wide text-slate-400">
                Owner Panel
              </span>
            )}
            <Button
              variant="ghost"
              size="icon"
              className="h-7 w-7 text-slate-500 hover:text-slate-100 hover:bg-slate-900"
              onClick={() => setCollapsed((v) => !v)}
            >
              {collapsed ? (
                <ChevronRight className="h-3 w-3" />
              ) : (
                <ChevronLeft className="h-3 w-3" />
              )}
            </Button>
          </div>
          <OwnerSidebar collapsed={collapsed} />
        </div>
      }
    >
      {children}
    </ProtectedLayout>
  );
};

export default OwnerLayout;
