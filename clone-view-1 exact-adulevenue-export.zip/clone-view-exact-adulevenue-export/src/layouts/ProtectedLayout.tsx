// V27: ProtectedLayout – universal OS shell wrapper
import { ReactNode } from "react";
import { ModeDropdown } from "@/contexts/OperationalContext";

interface ProtectedLayoutProps {
  title?: string;
  sidebar?: React.ReactNode;
  children: ReactNode;
}

export const ProtectedLayout = ({ title, sidebar, children }: ProtectedLayoutProps) => {
  return (
    <div className="min-h-screen w-full flex bg-slate-950 text-slate-50">

      {/* Sidebar (optional) */}
      {sidebar && (
        <aside className="hidden md:flex w-64 border-r border-slate-800 flex-col">
          {sidebar}
        </aside>
      )}

      {/* Main Layout */}
      <main className="flex-1 flex flex-col">
        
        {/* Header */}
        <header className="h-16 border-b border-slate-800 flex items-center px-4 md:px-6 gap-3">
          <h1 className="text-base md:text-lg font-semibold truncate">
            {title ?? "Dashboard"}
          </h1>
          <div className="ml-auto">
            <ModeDropdown />
          </div>
        </header>

        {/* Page content */}
        <section className="flex-1 p-4 md:p-6 overflow-auto">
          {children}
        </section>
      </main>

    </div>
  );
};

export default ProtectedLayout;
