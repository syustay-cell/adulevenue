// Funder Portal Layout - for funder role
import React, { ReactNode } from "react";
import { NavLink, useLocation } from "react-router-dom";
import { LayoutDashboard, Briefcase, BarChart3, Settings } from "lucide-react";
import { ProtectedLayout } from "@/layouts/ProtectedLayout";
import { cn } from "@/lib/utils";

interface FunderLayoutProps {
  title: string;
  children: ReactNode;
}

const funderNavItems = [
  { to: "/funder/portal", label: "Deals", icon: Briefcase },
  { to: "/funder/dashboard", label: "Overview", icon: LayoutDashboard },
  { to: "/funder/stats", label: "Performance", icon: BarChart3 },
  { to: "/funder/settings", label: "Settings", icon: Settings },
];

const FunderSidebar: React.FC = () => {
  const location = useLocation();

  return (
    <nav className="flex-1 overflow-y-auto p-3 space-y-1 text-xs">
      {funderNavItems.map(({ to, label, icon: Icon }) => {
        const active =
          location.pathname === to || location.pathname.startsWith(to + "/");

        return (
          <NavLink
            key={to}
            to={to}
            className={({ isActive }) =>
              cn(
                "flex items-center gap-2 rounded-md px-3 py-2 transition-colors",
                (isActive || active)
                  ? "bg-slate-800 text-slate-50"
                  : "text-slate-400 hover:text-slate-100 hover:bg-slate-900"
              )
            }
          >
            <Icon className="h-3.5 w-3.5" />
            <span>{label}</span>
          </NavLink>
        );
      })}
    </nav>
  );
};

export const FunderLayout: React.FC<FunderLayoutProps> = ({
  title,
  children,
}) => {
  return (
    <ProtectedLayout
      title={title}
      sidebar={
        <div className="h-full flex flex-col">
          <div className="h-16 border-b border-slate-800 flex items-center px-3">
            <span className="text-[11px] font-semibold uppercase tracking-wide text-slate-400">
              Funder Portal
            </span>
          </div>
          <FunderSidebar />
        </div>
      }
    >
      {children}
    </ProtectedLayout>
  );
};

export default FunderLayout;
