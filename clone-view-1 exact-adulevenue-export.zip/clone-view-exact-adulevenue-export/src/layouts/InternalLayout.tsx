import { useEffect, useState, ReactNode } from "react";
import { useLocation } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import Navigation from "@/components/Navigation";
import Footer from "@/components/Footer";
import { ModeDropdown } from "@/contexts/OperationalContext";
import { WolfHelpButton } from "@/components/help/WolfHelpButton";
import {
  WolfAssistantDrawer,
  WolfAssistantContext,
} from "@/components/help/WolfAssistantDrawer";

interface InternalLayoutProps {
  children: ReactNode;
  entityContext?: WolfAssistantContext["entity"];
}

export const InternalLayout = ({
  children,
  entityContext,
}: InternalLayoutProps) => {
  const location = useLocation();
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [context, setContext] = useState<WolfAssistantContext>({
    role: null,
    email: null,
    page: location.pathname,
    entity: entityContext ?? null,
  });

  useEffect(() => {
    const loadUserContext = async () => {
      const {
        data: { session },
      } = await supabase.auth.getSession();

      if (!session) {
        setContext((prev) => ({
          ...prev,
          role: null,
          email: null,
          page: location.pathname,
          entity: entityContext ?? null,
        }));
        return;
      }

      const userId = session.user.id;
      const userEmail = session.user.email ?? null;

      const { data: roles } = await supabase
        .from("user_roles")
        .select("role, approved")
        .eq("user_id", userId);

      const primaryRole =
        roles?.find((r) => r.approved)?.role ??
        roles?.[0]?.role ??
        "unknown";

      setContext({
        role: primaryRole,
        email: userEmail,
        page: location.pathname,
        entity: entityContext ?? null,
      });
    };

    loadUserContext();
  }, [location.pathname, entityContext]);

  const isInternal =
    location.pathname.startsWith("/admin") ||
    location.pathname.startsWith("/owner-dashboard") ||
    location.pathname.startsWith("/credit-clean-desk") ||
    location.pathname.startsWith("/credit-specialist-dashboard") ||
    location.pathname.startsWith("/credit-fix-dashboard") ||
    location.pathname.startsWith("/credit-fix-studio") ||
    location.pathname.startsWith("/lead-engine") ||
    location.pathname.startsWith("/worker-dashboard") ||
    location.pathname.startsWith("/lead-dialer") ||
    location.pathname.startsWith("/underwriting");

  return (
    <>
      <Navigation />

      <main className="pt-24 min-h-screen bg-slate-50">
        <div className="container mx-auto px-4 mb-4 flex justify-end">
          <ModeDropdown />
        </div>
        {children}
      </main>

      <Footer />

      {isInternal && (
        <>
          <WolfHelpButton onClick={() => setDrawerOpen(true)} />
          <WolfAssistantDrawer
            open={drawerOpen}
            onClose={() => setDrawerOpen(false)}
            context={context}
          />
        </>
      )}
    </>
  );
};
