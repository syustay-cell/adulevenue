// V27: TLC Layout - TLC OS shell with sidebar navigation
import React, { ReactNode, useState } from "react";
import { NavLink, useLocation } from "react-router-dom";
import { 
  LayoutDashboard, 
  FolderOpen, 
  Users, 
  ClipboardList,
  ChevronLeft,
  ChevronRight
} from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { ProtectedLayout } from "./ProtectedLayout";

interface TLCLayoutProps {
  title: string;
  children: ReactNode;
}

const tlcNavItems = [
  { to: "/tlc/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { to: "/tlc/cases", label: "Cases", icon: FolderOpen },
  { to: "/tlc/families", label: "Families", icon: Users },
  { to: "/tlc/intake", label: "Intake", icon: ClipboardList },
];

const TLCSidebar: React.FC<{ collapsed: boolean }> = ({ collapsed }) => {
  const location = useLocation();

  return (
    <nav className="flex-1 overflow-y-auto p-3 space-y-1 text-xs">
      {tlcNavItems.map(({ to, label, icon: Icon }) => {
        const active =
          location.pathname === to ||
          location.pathname.startsWith(to + "/");

        return (
          <NavLink
            key={to}
            to={to}
            className={({ isActive }) =>
              cn(
                "flex items-center gap-2 rounded-md px-3 py-2 transition-colors",
                (isActive || active)
                  ? "bg-primary/10 text-primary font-medium"
                  : "text-muted-foreground hover:text-foreground hover:bg-muted"
              )
            }
            title={collapsed ? label : undefined}
          >
            <Icon className="h-3.5 w-3.5" />
            {!collapsed && <span>{label}</span>}
          </NavLink>
        );
      })}
    </nav>
  );
};

export const TLCLayout: React.FC<TLCLayoutProps> = ({ title, children }) => {
  const [collapsed, setCollapsed] = useState(false);

  return (
    <ProtectedLayout
      title={title}
      sidebar={
        <div className="h-full flex flex-col">
          <div className="h-16 border-b border-border flex items-center justify-between px-3">
            {!collapsed && (
              <span className="text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">
                TLC Console
              </span>
            )}
            <Button
              variant="ghost"
              size="icon"
              className="h-7 w-7 text-muted-foreground hover:text-foreground hover:bg-muted"
              onClick={() => setCollapsed((v) => !v)}
            >
              {collapsed ? (
                <ChevronRight className="h-3 w-3" />
              ) : (
                <ChevronLeft className="h-3 w-3" />
              )}
            </Button>
          </div>
          <TLCSidebar collapsed={collapsed} />
        </div>
      }
    >
      {children}
    </ProtectedLayout>
  );
};

export default TLCLayout;
