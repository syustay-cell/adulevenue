import { ReactNode } from "react";
import { cn } from "@/lib/utils";

type DashboardLayoutProps = {
  title: string;
  description?: string;
  actions?: ReactNode;
  className?: string;
  children: ReactNode;
};

export default function DashboardLayout({
  title,
  description,
  actions,
  className,
  children,
}: DashboardLayoutProps) {
  return (
    <div className="min-h-screen bg-slate-50/60 dark:bg-slate-950">
      <div className="mx-auto w-full max-w-[1400px] px-4 py-8 sm:px-8 lg:px-10">
        <header className="mb-8 flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <p className="text-[11px] font-semibold uppercase tracking-[0.35em] text-muted-foreground">
              Wolf Command
            </p>
            <h1 className="text-3xl font-semibold text-foreground">
              {title}
            </h1>
            {description && (
              <p className="mt-1 text-sm text-muted-foreground">
                {description}
              </p>
            )}
          </div>
          {actions && <div className="flex flex-wrap gap-2">{actions}</div>}
        </header>

        <section className={cn("space-y-6", className)}>{children}</section>
      </div>
    </div>
  );
}
