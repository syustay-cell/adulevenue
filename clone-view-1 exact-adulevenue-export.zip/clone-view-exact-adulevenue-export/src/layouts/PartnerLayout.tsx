// Partner/Tenant Layout - for partner_owner, partner_worker, tenant_owner, tenant_worker
import React, { useState, ReactNode } from "react";
import { NavLink, useLocation } from "react-router-dom";
import {
  LayoutDashboard,
  Users,
  Briefcase,
  Settings,
  ChevronLeft,
  ChevronRight,
  DollarSign,
  UserPlus,
} from "lucide-react";
import { ProtectedLayout } from "@/layouts/ProtectedLayout";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";

interface PartnerLayoutProps {
  title: string;
  children: ReactNode;
}

const partnerNavItems = [
  { to: "/partner/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { to: "/partner/deals", label: "My Deals", icon: Briefcase },
  { to: "/partner/commissions", label: "Commissions", icon: DollarSign },
  { to: "/partner/team", label: "Team", icon: Users },
  { to: "/partner/invite", label: "Invite Worker", icon: UserPlus },
  { to: "/partner/settings", label: "Settings", icon: Settings },
];

const PartnerSidebar: React.FC<{ collapsed: boolean }> = ({ collapsed }) => {
  const location = useLocation();

  return (
    <nav className="flex-1 overflow-y-auto p-3 space-y-1 text-xs">
      {partnerNavItems.map(({ to, label, icon: Icon }) => {
        const active =
          location.pathname === to || location.pathname.startsWith(to + "/");

        return (
          <NavLink
            key={to}
            to={to}
            className={({ isActive }) =>
              cn(
                "flex items-center gap-2 rounded-md px-3 py-2 transition-colors",
                (isActive || active)
                  ? "bg-slate-800 text-slate-50"
                  : "text-slate-400 hover:text-slate-100 hover:bg-slate-900"
              )
            }
          >
            <Icon className="h-3.5 w-3.5" />
            {!collapsed && <span>{label}</span>}
          </NavLink>
        );
      })}
    </nav>
  );
};

export const PartnerLayout: React.FC<PartnerLayoutProps> = ({
  title,
  children,
}) => {
  const [collapsed, setCollapsed] = useState(false);

  return (
    <ProtectedLayout
      title={title}
      sidebar={
        <div className="h-full flex flex-col">
          <div className="h-16 border-b border-slate-800 flex items-center justify-between px-3">
            {!collapsed && (
              <span className="text-[11px] font-semibold uppercase tracking-wide text-slate-400">
                Partner Console
              </span>
            )}
            <Button
              variant="ghost"
              size="icon"
              className="h-7 w-7 text-slate-500 hover:text-slate-100 hover:bg-slate-900"
              onClick={() => setCollapsed((v) => !v)}
            >
              {collapsed ? (
                <ChevronRight className="h-3 w-3" />
              ) : (
                <ChevronLeft className="h-3 w-3" />
              )}
            </Button>
          </div>
          <PartnerSidebar collapsed={collapsed} />
        </div>
      }
    >
      {children}
    </ProtectedLayout>
  );
};

export default PartnerLayout;
