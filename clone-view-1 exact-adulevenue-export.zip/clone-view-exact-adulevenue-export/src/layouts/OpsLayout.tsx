// Operations Layout - for Legal, Credit, Merchant Services, Wolf Workers
import React, { ReactNode } from "react";
import { NavLink, useLocation } from "react-router-dom";
import { ProtectedLayout } from "@/layouts/ProtectedLayout";
import { cn } from "@/lib/utils";
import {
  Scale,
  FileText,
  ShieldCheck,
  Activity,
  CreditCard,
  Users,
  Settings,
  Briefcase,
} from "lucide-react";

type OpsLane = "legal" | "credit" | "merchant_services" | "wolf_worker";

interface OpsLayoutProps {
  title: string;
  children: ReactNode;
  lane: OpsLane;
}

const getNavItems = (lane: OpsLane) => {
  switch (lane) {
    case "legal":
      return [
        { to: "/legal/dashboard", label: "Cases", icon: Scale },
        { to: "/legal/queue", label: "Queue", icon: FileText },
        { to: "/legal/settings", label: "Settings", icon: ShieldCheck },
      ];
    case "credit":
      return [
        { to: "/credit/dashboard", label: "Credit Queue", icon: Activity },
        { to: "/credit/templates", label: "Templates", icon: FileText },
        { to: "/credit/settings", label: "Settings", icon: Settings },
      ];
    case "merchant_services":
      return [
        { to: "/ms/dashboard", label: "Merchants", icon: CreditCard },
        { to: "/ms/offers", label: "Offers", icon: FileText },
        { to: "/ms/settings", label: "Settings", icon: Settings },
      ];
    case "wolf_worker":
      return [
        { to: "/worker-dashboard", label: "My Tasks", icon: Activity },
        { to: "/worker/deals", label: "Deals", icon: Briefcase },
        { to: "/worker/team", label: "Team", icon: Users },
      ];
  }
};

const getLaneLabel = (lane: OpsLane): string => {
  switch (lane) {
    case "legal":
      return "Legal Ops";
    case "credit":
      return "Credit Ops";
    case "merchant_services":
      return "Merchant Services";
    case "wolf_worker":
      return "Wolf Worker";
  }
};

const OpsSidebar: React.FC<{ lane: OpsLane }> = ({ lane }) => {
  const location = useLocation();
  const items = getNavItems(lane);

  return (
    <nav className="flex-1 overflow-y-auto p-3 space-y-1 text-xs">
      {items.map(({ to, label, icon: Icon }) => {
        const active =
          location.pathname === to || location.pathname.startsWith(to + "/");

        return (
          <NavLink
            key={to}
            to={to}
            className={({ isActive }) =>
              cn(
                "flex items-center gap-2 rounded-md px-3 py-2 transition-colors",
                (isActive || active)
                  ? "bg-slate-800 text-slate-50"
                  : "text-slate-400 hover:text-slate-100 hover:bg-slate-900"
              )
            }
          >
            <Icon className="h-3.5 w-3.5" />
            <span>{label}</span>
          </NavLink>
        );
      })}
    </nav>
  );
};

export const OpsLayout: React.FC<OpsLayoutProps> = ({
  title,
  children,
  lane,
}) => {
  return (
    <ProtectedLayout
      title={title}
      sidebar={
        <div className="h-full flex flex-col">
          <div className="h-16 border-b border-slate-800 flex items-center px-3">
            <span className="text-[11px] font-semibold uppercase tracking-wide text-slate-400">
              {getLaneLabel(lane)}
            </span>
          </div>
          <OpsSidebar lane={lane} />
        </div>
      }
    >
      {children}
    </ProtectedLayout>
  );
};

export default OpsLayout;
