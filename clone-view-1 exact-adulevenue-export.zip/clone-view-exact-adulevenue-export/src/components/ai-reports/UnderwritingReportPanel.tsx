import { useAIReport } from "@/hooks/useAIReport";
import { useUserRoles, userHasRole } from "@/hooks/useUserRoles";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { FileText, RefreshCw, Eye } from "lucide-react";

type UnderwritingContext = {
  business_name?: string;
  owner_name?: string;
  monthly_revenue?: number;
  time_in_business_months?: number;
  time_in_business?: number;
  requested_amount?: number;
  credit_score?: number;
  bank_statements?: unknown;
  industry?: string;
  state?: string;
  existing_advances?: unknown;
};

type Props = {
  applicationId: string;
  contextForAI: UnderwritingContext;
};

const riskColorMap: Record<string, string> = {
  low: "bg-emerald-100 text-emerald-800 dark:bg-emerald-900/30 dark:text-emerald-300",
  medium: "bg-amber-100 text-amber-800 dark:bg-amber-900/30 dark:text-amber-300",
  high: "bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-300",
};

export function UnderwritingReportPanel({ applicationId, contextForAI }: Props) {
  const { loading, report, viewReport, refreshReport } = useAIReport(
    "application",
    applicationId,
    "underwriting"
  );

  const { roles } = useUserRoles();
  const canRefresh = userHasRole(roles, ["admin", "underwriter"]);

  const riskLevel = (report?.report_json?.risk_level || "unknown") as string;
  const riskClass = riskColorMap[riskLevel] || "bg-muted text-muted-foreground";

  const reasons = (report?.report_json?.reasons || []) as string[];
  const redFlags = (report?.report_json?.red_flags || []) as string[];
  const supportingSignals = (report?.report_json?.supporting_signals || []) as string[];

  return (
    <Card className="space-y-4 p-4">
      {/* Header */}
      <div className="flex items-start justify-between gap-4 flex-wrap">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <FileText className="h-5 w-5 text-primary" />
            <h3 className="font-semibold">AI Underwriting Report</h3>
          </div>
          <p className="text-sm text-muted-foreground">
            Pay once for the report, reuse it forever. Refresh only when needed.
          </p>
          {report?.last_run_at && (
            <p className="text-xs text-muted-foreground">
              Last run: {new Date(report.last_run_at).toLocaleString()} · 
              Model: {report.ai_model || "N/A"} · Provider: {report.provider || "N/A"}
            </p>
          )}
        </div>
        <div className="flex flex-col items-end gap-2">
          {riskLevel !== "unknown" && (
            <Badge className={riskClass}>
              Risk: {riskLevel.toUpperCase()}
            </Badge>
          )}
          <div className="flex flex-col items-end gap-1">
            <div className="flex gap-2">
              <Button
                variant="outline"
                size="sm"
                disabled={loading === "view"}
                onClick={() => viewReport(contextForAI)}
              >
                <Eye className="h-4 w-4 mr-1" />
                {loading === "view" ? "Loading..." : "View Last Report"}
              </Button>
              <Button
                size="sm"
                disabled={loading === "refresh" || !canRefresh}
                onClick={() => canRefresh && refreshReport(contextForAI)}
              >
                <RefreshCw className={`h-4 w-4 mr-1 ${loading === "refresh" ? "animate-spin" : ""}`} />
                {loading === "refresh" ? "Updating..." : "Refresh Report"}
              </Button>
            </div>
            <p className="text-[10px] text-muted-foreground text-right max-w-[220px]">
              View = free (uses saved data) · Refresh = new AI scan (may incur cost)
            </p>
            {!canRefresh && (
              <p className="text-[10px] text-amber-600 text-right max-w-[220px]">
                Only admins or underwriters can run new paid AI analyses.
              </p>
            )}
          </div>
        </div>
      </div>

      {/* No report yet */}
      {!report && (
        <div className="rounded-md border border-dashed border-muted-foreground/30 bg-muted/20 p-4 text-center">
          <p className="text-sm text-muted-foreground mb-1">
            No underwriting report has been run yet.
          </p>
          <p className="text-xs text-muted-foreground">
            Click <strong>Refresh Report</strong> to run the first paid AI analysis and save it permanently.
          </p>
        </div>
      )}

      {/* Report content */}
      {report && (
        <div className="space-y-4">
          {/* Summary */}
          <div className="rounded-md border bg-muted/40 p-3">
            <h4 className="mb-1 font-medium text-sm">Summary</h4>
            <p className="text-sm whitespace-pre-wrap">
              {(report.report_json?.summary as string) || report.report_text || "No summary available."}
            </p>
          </div>

          {/* Recommended Terms */}
          {report.report_json?.recommended_terms && (
            <div className="rounded-md border bg-background p-3">
              <h4 className="mb-2 font-medium text-sm">Recommended Terms</h4>
              <div className="grid grid-cols-3 gap-4 text-sm">
                <div>
                  <span className="text-muted-foreground">Amount:</span>
                  <p className="font-semibold">${Number(report.report_json.recommended_amount || 0).toLocaleString()}</p>
                </div>
                <div>
                  <span className="text-muted-foreground">Factor Rate:</span>
                  <p className="font-semibold">{String((report.report_json.recommended_terms as Record<string, unknown>)?.factor_rate || "N/A")}</p>
                </div>
                <div>
                  <span className="text-muted-foreground">Term:</span>
                  <p className="font-semibold">{String((report.report_json.recommended_terms as Record<string, unknown>)?.term_days || "N/A")} days</p>
                </div>
              </div>
            </div>
          )}

          {/* Two-column layout for lists */}
          <div className="grid gap-4 md:grid-cols-2">
            {reasons.length > 0 && (
              <div className="rounded-md border bg-background p-3 text-sm">
                <h4 className="mb-1 font-medium">Key Reasons</h4>
                <ul className="list-disc pl-4 space-y-1 text-xs">
                  {reasons.map((r, i) => <li key={i}>{String(r)}</li>)}
                </ul>
              </div>
            )}

            {supportingSignals.length > 0 && (
              <div className="rounded-md border bg-emerald-50 dark:bg-emerald-900/20 p-3 text-sm">
                <h4 className="mb-1 font-medium text-emerald-800 dark:text-emerald-300">Supporting Signals</h4>
                <ul className="list-disc pl-4 space-y-1 text-xs">
                  {supportingSignals.map((s, i) => <li key={i}>{String(s)}</li>)}
                </ul>
              </div>
            )}

            {redFlags.length > 0 && (
              <div className="rounded-md border bg-red-50 dark:bg-red-900/20 p-3 text-sm md:col-span-2">
                <h4 className="mb-1 font-medium text-red-800 dark:text-red-300">Red Flags</h4>
                <ul className="list-disc pl-4 space-y-1 text-xs">
                  {redFlags.map((f, i) => <li key={i}>{String(f)}</li>)}
                </ul>
              </div>
            )}
          </div>

          {/* Cost info */}
          {report.first_run_cost !== null && (
            <div className="text-xs text-muted-foreground">
              First run: ${Number(report.first_run_cost).toFixed(4)} · 
              Last refresh: ${Number(report.last_run_cost || 0).toFixed(4)} · 
              Total runs: {report.run_count}
            </div>
          )}
        </div>
      )}
    </Card>
  );
}
