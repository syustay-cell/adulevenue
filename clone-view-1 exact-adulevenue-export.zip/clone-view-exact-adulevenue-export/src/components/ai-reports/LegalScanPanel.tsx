import { useAIReport } from "@/hooks/useAIReport";
import { useUserRoles, userHasRole } from "@/hooks/useUserRoles";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Shield, RefreshCw, Eye } from "lucide-react";

type LegalContext = {
  business_name?: string;
  owner_name?: string;
  ein?: string;
  state?: string;
  city?: string;
  address_line1?: string;
  address_line2?: string;
  zip?: string;
};

type Props = {
  leadId: string;
  contextForAI: LegalContext;
};

const riskColorMap: Record<string, string> = {
  none: "bg-emerald-100 text-emerald-800 dark:bg-emerald-900/30 dark:text-emerald-300",
  low: "bg-emerald-100 text-emerald-800 dark:bg-emerald-900/30 dark:text-emerald-300",
  medium: "bg-amber-100 text-amber-800 dark:bg-amber-900/30 dark:text-amber-300",
  high: "bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-300",
};

export function LegalScanPanel({ leadId, contextForAI }: Props) {
  const { loading, report, viewReport, refreshReport } = useAIReport(
    "lead",
    leadId,
    "legal_search"
  );

  const { roles } = useUserRoles();
  const canRefresh = userHasRole(roles, ["admin", "credit_repair_specialist"]);

  const risk = (report?.report_json?.risk_level || "unknown") as string;
  const riskClass = riskColorMap[risk] || "bg-muted text-muted-foreground";

  const bankruptcies = (report?.report_json?.bankruptcies || []) as unknown[];
  const liens = (report?.report_json?.liens || []) as unknown[];
  const judgments = (report?.report_json?.judgments || []) as unknown[];
  const ucc = (report?.report_json?.ucc_filings || []) as unknown[];
  const notes = (report?.report_json?.notes || []) as string[];

  return (
    <Card className="space-y-4 p-4">
      {/* Header */}
      <div className="flex items-start justify-between gap-4 flex-wrap">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <Shield className="h-5 w-5 text-primary" />
            <h3 className="font-semibold">Legal / Lien / Bankruptcy Scan</h3>
          </div>
          <p className="text-sm text-muted-foreground">
            Run once, reuse forever. Refresh only when you want updated info.
          </p>
          {report?.last_run_at && (
            <p className="text-xs text-muted-foreground">
              Last run: {new Date(report.last_run_at).toLocaleString()} · 
              Model: {report.ai_model || "N/A"} · Provider: {report.provider || "N/A"}
            </p>
          )}
        </div>
        <div className="flex flex-col items-end gap-2">
          {risk !== "unknown" && (
            <Badge className={riskClass}>
              Risk: {risk.toUpperCase()}
            </Badge>
          )}
          <div className="flex flex-col items-end gap-1">
            <div className="flex gap-2">
              <Button
                variant="outline"
                size="sm"
                disabled={loading === "view"}
                onClick={() => viewReport(contextForAI)}
              >
                <Eye className="h-4 w-4 mr-1" />
                {loading === "view" ? "Loading..." : "View Saved"}
              </Button>
              <Button
                size="sm"
                disabled={loading === "refresh" || !canRefresh}
                onClick={() => canRefresh && refreshReport(contextForAI)}
              >
                <RefreshCw className={`h-4 w-4 mr-1 ${loading === "refresh" ? "animate-spin" : ""}`} />
                {loading === "refresh" ? "Refreshing..." : "Refresh Scan"}
              </Button>
            </div>
            <p className="text-[10px] text-muted-foreground text-right max-w-[220px]">
              View = free (uses saved data) · Refresh = new AI scan (may incur cost)
            </p>
            {!canRefresh && (
              <p className="text-[10px] text-amber-600 text-right max-w-[220px]">
                Only admins or credit specialists can run new paid scans.
              </p>
            )}
          </div>
        </div>
      </div>

      {/* No report yet */}
      {!report && (
        <div className="rounded-md border border-dashed border-muted-foreground/30 bg-muted/20 p-4 text-center">
          <p className="text-sm text-muted-foreground mb-1">
            No legal scan has been run yet.
          </p>
          <p className="text-xs text-muted-foreground">
            Click <strong>Refresh Scan</strong> to run the first paid scan and save it permanently.
          </p>
        </div>
      )}

      {/* Structured view when report exists */}
      {report && (
        <div className="grid gap-4 md:grid-cols-2">
          {/* Column 1: summary + notes */}
          <div className="space-y-3">
            <div className="rounded-md border bg-muted/40 p-3 text-sm">
              <h4 className="mb-1 font-medium">Summary</h4>
              <p className="text-sm whitespace-pre-wrap">
                {(report.report_json?.summary as string) || report.report_text || "No summary available."}
              </p>
            </div>

            {notes.length > 0 && (
              <div className="rounded-md border bg-muted/40 p-3 text-sm">
                <h4 className="mb-1 font-medium">Notes</h4>
                <ul className="list-disc pl-4 space-y-1">
                  {notes.map((n, i) => (
                    <li key={i}>{n}</li>
                  ))}
                </ul>
              </div>
            )}

            {report.first_run_cost !== null && (
              <div className="text-xs text-muted-foreground">
                First run: ${Number(report.first_run_cost).toFixed(4)} · 
                Last refresh: ${Number(report.last_run_cost || 0).toFixed(4)} · 
                Total runs: {report.run_count}
              </div>
            )}
          </div>

          {/* Column 2: items */}
          <div className="space-y-3">
            <LegalList title="Bankruptcies" items={bankruptcies} emptyLabel="No bankruptcies found." />
            <LegalList title="Liens" items={liens} emptyLabel="No liens found." />
            <LegalList title="Judgments" items={judgments} emptyLabel="No judgments found." />
            <LegalList title="UCC Filings" items={ucc} emptyLabel="No UCC filings found." />
          </div>
        </div>
      )}
    </Card>
  );
}

type LegalItemListProps = {
  title: string;
  items: unknown[];
  emptyLabel: string;
};

function LegalList({ title, items, emptyLabel }: LegalItemListProps) {
  return (
    <div className="rounded-md border bg-background p-3 text-sm">
      <div className="mb-1 flex items-center justify-between">
        <h4 className="font-medium">{title}</h4>
        <span className="text-xs text-muted-foreground">
          {items.length} record{items.length === 1 ? "" : "s"}
        </span>
      </div>
      {items.length === 0 ? (
        <p className="text-xs text-muted-foreground">{emptyLabel}</p>
      ) : (
        <ul className="space-y-1">
          {items.map((item, idx) => (
            <li key={idx} className="rounded bg-muted/60 px-2 py-1 text-xs">
              {renderLegalItem(item)}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

function renderLegalItem(item: unknown): string {
  if (typeof item === "string") return item;
  if (typeof item === "object" && item !== null) {
    const obj = item as Record<string, unknown>;
    if (obj.description) return String(obj.description);
    if (obj.case_number || obj.docket) {
      return `${obj.case_number || obj.docket} – ${obj.status || ""}`.trim();
    }
    return JSON.stringify(item);
  }
  return String(item);
}
