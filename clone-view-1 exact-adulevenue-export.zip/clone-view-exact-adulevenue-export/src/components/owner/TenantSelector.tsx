import { useViewAsTenant } from "@/hooks/useViewAsTenant";
import {
  Select,
  SelectTrigger,
  SelectValue,
  SelectContent,
  SelectItem,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Eye, X } from "lucide-react";

export function TenantSelector() {
  const {
    isSuperOwner,
    isGodModeEnabled,
    allTenants,
    tenantsLoading,
    viewAsTenantName,
    isViewingAsTenant,
    enableViewAs,
    clearViewAs,
  } = useViewAsTenant();

  if (!isSuperOwner || !isGodModeEnabled) return null;

  return (
    <div className="flex items-center gap-2 text-xs">
      <span className="text-muted-foreground flex items-center gap-1">
        <Eye className="h-3 w-3" /> View As:
      </span>

      {isViewingAsTenant ? (
        <div className="flex items-center gap-2">
          <Badge variant="outline" className="text-xs">
            {viewAsTenantName || "Unknown tenant"}
          </Badge>
          <Badge variant="secondary" className="text-[10px] bg-amber-500/20 text-amber-600 border-amber-500/40">
            READ-ONLY
          </Badge>
          <button
            onClick={clearViewAs}
            className="text-muted-foreground hover:text-foreground transition-colors"
          >
            <X className="h-3 w-3" />
          </button>
        </div>
      ) : (
        <Select
          onValueChange={(val) => {
            const t = allTenants.find((x) => x.id === val);
            if (t) enableViewAs(t.id, t.name);
          }}
        >
          <SelectTrigger className="h-7 w-52 text-xs">
            <SelectValue
              placeholder={
                tenantsLoading ? "Loading tenants..." : "Select tenant"
              }
            />
          </SelectTrigger>
          <SelectContent>
            {allTenants.map((t) => (
              <SelectItem key={t.id} value={t.id} className="text-xs">
                {t.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      )}
    </div>
  );
}
