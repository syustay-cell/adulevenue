import { useState, useRef, useEffect, useCallback } from "react";
import { Button } from "@/components/ui/button";
import { Send, Loader2, X, Sparkles, FileText } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { useNavigate, useLocation } from "react-router-dom";
import { getSuggestions } from "@/config/aiSuggestions";
import { ChatAudioControls, TextToSpeechButton } from "@/components/chat/ChatAudioControls";
import { ContractLibrary, matchContractCommand } from "@/components/chat/ContractLibrary";
import { useChatModeSwitch } from "@/components/chat/useChatModeSwitch";

interface ActionButton {
  label: string;
  path: string;
  icon: string;
}

interface Message {
  role: "user" | "assistant";
  content: string;
  actions?: ActionButton[];
}

interface GlobalChatBotProps {
  context?: "client" | "iso" | "admin";
}

export default function GlobalChatBot({ context = "client" }: GlobalChatBotProps) {
  const [isExpanded, setIsExpanded] = useState(false);
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [pulseAnimation, setPulseAnimation] = useState(true);
  const [userRole, setUserRole] = useState<string | null>(null);
  const [contractOpen, setContractOpen] = useState(false);
  const [preselectedContract, setPreselectedContract] = useState<string | undefined>();
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const sessionIdRef = useRef(`chat-${Date.now()}-${Math.random().toString(36).slice(2)}`);
  const { toast } = useToast();
  const navigate = useNavigate();
  const location = useLocation();

  const isAdmin = userRole === 'admin';
  
  const {
    currentMode,
    isModeCommand,
    processModeCommand,
    isComplexQuery,
    getUpgradePrompt
  } = useChatModeSwitch({ 
    isAdmin, 
    sessionId: sessionIdRef.current 
  });

  // Fetch user role on mount
  useEffect(() => {
    const fetchUserRole = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) return;

      const { data: roles } = await supabase
        .from('user_roles')
        .select('role, approved')
        .eq('user_id', session.user.id);

      if (roles && roles.length > 0) {
        const roleHierarchy = ['admin', 'credit_repair_specialist', 'worker', 'user'];
        const highestRole = roleHierarchy.find(r => 
          roles.some(role => role.role === r && role.approved)
        );
        setUserRole(highestRole || 'user');
      } else {
        setUserRole('user');
      }
    };

    fetchUserRole();
  }, []);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  // Pulse animation every 15 seconds
  useEffect(() => {
    const interval = setInterval(() => {
      setPulseAnimation(true);
      setTimeout(() => setPulseAnimation(false), 2000);
    }, 15000);
    return () => clearInterval(interval);
  }, []);

  const sendMessage = useCallback(async (messageText?: string) => {
    const textToSend = messageText || input.trim();
    if (!textToSend || isLoading) return;

    if (!messageText) setInput("");
    setMessages(prev => [...prev, { role: "user", content: textToSend }]);
    setIsLoading(true);

    try {
      // Check for mode switch commands (222, 333, 444)
      if (isModeCommand(textToSend)) {
        const response = await processModeCommand(textToSend);
        if (response) {
          setMessages(prev => [...prev, { role: "assistant", content: response }]);
          setIsLoading(false);
          return;
        }
      }

      // Check for contract commands (nda, iso_agreement, etc.)
      const contractMatch = matchContractCommand(textToSend);
      if (contractMatch) {
        setPreselectedContract(contractMatch.templateKey);
        setContractOpen(true);
        setMessages(prev => [...prev, { 
          role: "assistant", 
          content: `📄 Opening the ${contractMatch.templateKey.replace(/_/g, ' ').toUpperCase()} template form. Please fill in the required fields.` 
        }]);
        setIsLoading(false);
        return;
      }

      const { data: { session } } = await supabase.auth.getSession();
      
      const { data, error } = await supabase.functions.invoke("chat-assistant", {
        body: { 
          message: textToSend, 
          conversationHistory: messages,
          role: userRole || 'public',
          route: location.pathname,
          context: {
            currentUserId: session?.user?.id || null,
            selectedApplicationId: null,
            selectedCaseId: null,
            aiMode: currentMode
          }
        }
      });

      if (error) {
        console.error("Chat transport error:", error);
        toast({ title: "Connection Error", description: "Please try again.", variant: "destructive" });
        return;
      }

      if (!data?.ok && data?.error_code) {
        toast({ 
          title: data.error_code === 'AI_PAUSED' ? "AI Unavailable" : "Error", 
          description: data.message || "Failed to get response",
          variant: data.error_code === 'AI_PAUSED' ? "default" : "destructive"
        });
        return;
      }

      let responseContent = data.response;

      // Add upgrade prompt for complex queries in eco mode
      if (isComplexQuery(textToSend) && currentMode === 'eco') {
        const upgradePrompt = getUpgradePrompt(currentMode);
        if (upgradePrompt) {
          responseContent += upgradePrompt;
        }
      }

      setMessages(prev => [...prev, { 
        role: "assistant", 
        content: responseContent,
        actions: data.actions 
      }]);
    } catch (error) {
      console.error("Chat error:", error);
      toast({
        title: "Error",
        description: "Failed to get response. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  }, [input, isLoading, messages, userRole, location.pathname, currentMode, isModeCommand, processModeCommand, isComplexQuery, getUpgradePrompt, toast]);

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  const handleVoiceTranscript = useCallback((transcript: string) => {
    setInput(transcript);
    // Auto-send after short delay
    setTimeout(() => {
      sendMessage(transcript);
    }, 300);
  }, [sendMessage]);

  const getModeIndicator = () => {
    switch (currentMode) {
      case 'eco': return { emoji: '🌱', label: 'ECO' };
      case 'balanced': return { emoji: '⚡', label: 'BALANCED' };
      case 'pro': return { emoji: '👑', label: 'PRO' };
      default: return { emoji: '🌱', label: 'ECO' };
    }
  };

  const modeIndicator = getModeIndicator();

  return (
    <>
      {/* Contract Library Sheet */}
      <ContractLibrary 
        isOpen={contractOpen}
        onClose={() => {
          setContractOpen(false);
          setPreselectedContract(undefined);
        }}
        preselectedTemplate={preselectedContract}
      />

      {/* Collapsed Help Button - Left Side Vertical */}
      <AnimatePresence>
        {!isExpanded && (
          <motion.button
            initial={{ opacity: 0, x: -20 }}
            animate={{ 
              opacity: 1, 
              x: 0,
              y: [0, -3, 0]
            }}
            exit={{ opacity: 0, x: -20 }}
            transition={{
              y: {
                duration: 2,
                repeat: Infinity,
                ease: "easeInOut"
              }
            }}
            onClick={() => setIsExpanded(true)}
            className="fixed top-1/2 left-0 -translate-y-1/2 z-40 flex flex-col items-center gap-1 px-2 py-4 rounded-r-xl
              bg-primary/20 backdrop-blur-sm text-primary border border-primary/30 shadow-lg
              hover:bg-primary/30 hover:shadow-xl transition-all duration-300"
            style={{ writingMode: 'vertical-rl' }}
          >
            <span className="text-sm font-bold tracking-wider">HELP</span>
          </motion.button>
        )}
      </AnimatePresence>

      {/* Expanded Chat Panel - Left Side */}
      <AnimatePresence>
        {isExpanded && (
          <motion.div
            initial={{ opacity: 0, x: -450 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -450 }}
            transition={{ type: "spring", damping: 25, stiffness: 150 }}
            className="fixed top-[10vh] left-4 w-[95vw] max-w-[420px] h-[75vh] max-h-[620px] z-50 flex flex-col
              bg-background/95 backdrop-blur-xl border border-border shadow-2xl rounded-2xl overflow-hidden"
          >
            {/* Header */}
            <div className="bg-primary text-primary-foreground p-4 flex flex-col gap-1 shrink-0">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Sparkles className="w-5 h-5" />
                  <div>
                    <h3 className="font-bold text-base flex items-center gap-2">
                      Alpha
                      <span className={`text-xs px-1.5 py-0.5 rounded ${
                        currentMode === 'pro' ? 'bg-amber-500/30' :
                        currentMode === 'balanced' ? 'bg-blue-500/30' :
                        'bg-green-500/30'
                      }`}>
                        {modeIndicator.emoji} {modeIndicator.label}
                      </span>
                    </h3>
                    <p className="text-xs opacity-90">
                      {context === "iso" ? "ISO Partner Support" : "Wolf Fund Assistant"}
                    </p>
                  </div>
                </div>
              <div className="flex items-center gap-1">
                <Button
                  onClick={() => setContractOpen(true)}
                  variant="ghost"
                  size="icon"
                  className="text-primary-foreground hover:bg-primary-foreground/20 h-8 w-8"
                  title="Contract Library"
                >
                  <FileText size={16} />
                </Button>
                <Button
                  onClick={() => setIsExpanded(false)}
                  variant="ghost"
                  size="icon"
                  className="text-primary-foreground hover:bg-primary-foreground/20 h-8 w-8"
                >
                  <X size={18} />
                </Button>
              </div>
              </div>
              {/* PRO mode warning banner */}
              {currentMode === 'pro' && (
                <div className="text-[10px] opacity-80 bg-amber-500/20 px-2 py-0.5 rounded mt-1">
                  ⚠️ PRO mode uses more AI budget. Use for deep analysis only.
                </div>
              )}
            </div>

            {/* Messages Area */}
            <div className="flex-1 overflow-y-auto p-4 space-y-3">
              {messages.length === 0 && (
                <div className="text-center text-muted-foreground py-4">
                  <Sparkles className="w-12 h-12 mx-auto mb-2 text-primary" />
                  <h4 className="font-semibold text-foreground text-sm mb-1">Alpha - Wolf Fund Assistant</h4>
                  <p className="text-xs mb-2">Hi, my name is Alpha. I can help you with anything.</p>
                  <p className="text-xs text-muted-foreground mb-4">
                    💡 Type <strong>222</strong> for ECO, <strong>333</strong> for BALANCED, <strong>444</strong> for PRO mode
                  </p>
                  
                  {/* Suggestion Buttons */}
                  <div className="flex flex-col gap-2 mt-4">
                    {getSuggestions(userRole, location.pathname).map((suggestion, idx) => (
                      <Button
                        key={idx}
                        onClick={() => sendMessage(suggestion.prompt)}
                        variant="outline"
                        size="sm"
                        className="text-left h-auto py-2 px-3 justify-start hover:bg-primary/10 hover:border-primary text-xs"
                      >
                        {suggestion.label}
                      </Button>
                    ))}
                  </div>
                </div>
              )}
              
              {messages.map((msg, idx) => (
                <motion.div
                  key={idx}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className={`flex flex-col ${msg.role === "user" ? "items-end" : "items-start"}`}
                >
                  <div
                    className={`max-w-[85%] rounded-xl p-3 shadow-sm ${
                      msg.role === "user"
                        ? "bg-primary text-primary-foreground"
                        : "bg-muted text-foreground"
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2">
                      <p className="text-sm leading-relaxed whitespace-pre-wrap flex-1">{msg.content}</p>
                      {msg.role === "assistant" && (
                        <TextToSpeechButton text={msg.content} />
                      )}
                    </div>
                  </div>
                  
                  {msg.actions && msg.actions.length > 0 && (
                    <div className="flex flex-col gap-2 mt-2 w-full max-w-[85%]">
                      {msg.actions.map((action, actionIdx) => (
                        <Button
                          key={actionIdx}
                          onClick={() => {
                            navigate(action.path);
                            setIsExpanded(false);
                          }}
                          variant="outline"
                          size="sm"
                          className="justify-start text-left h-auto py-2 hover:bg-primary/10 hover:border-primary w-full"
                        >
                          <span className="mr-2">{action.icon}</span>
                          <span className="text-xs">{action.label}</span>
                        </Button>
                      ))}
                    </div>
                  )}
                </motion.div>
              ))}
              
              {isLoading && (
                <div className="flex justify-start">
                  <div className="bg-muted rounded-xl p-3">
                    <Loader2 className="h-4 w-4 animate-spin text-primary" />
                  </div>
                </div>
              )}
              <div ref={messagesEndRef} />
            </div>

            {/* Input Section */}
            <div className="p-3 border-t border-border bg-background shrink-0">
              <div className="flex gap-2 items-center">
                <ChatAudioControls onTranscript={handleVoiceTranscript} />
                <input
                  type="text"
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyDown={handleKeyDown}
                  placeholder="Type your message... (222/333/444 to switch mode)"
                  className="flex-1 px-3 py-2 rounded-xl border border-input bg-background
                    focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent
                    text-sm text-foreground placeholder:text-muted-foreground transition-all"
                  disabled={isLoading}
                />
                <Button
                  onClick={() => sendMessage()}
                  disabled={!input.trim() || isLoading}
                  size="icon"
                  className="bg-primary hover:bg-primary/90 h-9 w-9 rounded-xl shrink-0"
                >
                  <Send size={16} />
                </Button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
