import { useMemo } from "react";
import {
  Card,
  CardHeader,
  CardTitle,
  CardDescription,
  CardContent,
} from "@/components/ui/card";
import { Badge, type BadgeProps } from "@/components/ui/badge";

import type {
  CommissionPayout,
  CommissionContext,
  CommissionRules,
  CommissionDebugSnapshot,
  ParticipantRole,
} from "@/types/commission";

type DealWithDebug = {
  id: string;
  merchant_name?: string | null;
  gross_commission_pool?: number | null;
  commission_debug_json?: CommissionDebugSnapshot | null;
};

interface DealCommissionBreakdownProps {
  deal: DealWithDebug;
}

const ROLE_LABEL: Record<ParticipantRole, string> = {
  OPENER: "Opener",
  CLOSER: "Closer",
  REFERRAL_PARTNER: "Referral Partner",
  WORKER_REFERRAL: "Worker Referral",
  ISO_PARTNER: "ISO Partner",
  HOUSE: "House",
  AI_AUTOPILOT: "AI Autopilot",
};

const ROLE_BADGE_VARIANT: Partial<
  Record<ParticipantRole, BadgeProps["variant"]>
> = {
  OPENER: "default",
  CLOSER: "default",
  WORKER_REFERRAL: "outline",
  REFERRAL_PARTNER: "outline",
  ISO_PARTNER: "secondary",
  HOUSE: "secondary",
  AI_AUTOPILOT: "secondary",
};

function formatCurrency(amount: number | null | undefined): string {
  const n = Number(amount || 0);
  return n.toLocaleString("en-US", {
    style: "currency",
    currency: "USD",
  });
}

function formatPercent(value: number | null | undefined): string {
  const n = Number(value || 0) * 100;
  return `${n.toFixed(2)}%`;
}

export function DealCommissionBreakdown({ deal }: DealCommissionBreakdownProps) {
  const debug = deal.commission_debug_json as CommissionDebugSnapshot | null;

  const totalPool = useMemo(() => {
    if (!debug) return deal.gross_commission_pool || 0;
    return (
      debug.context.grossCommissionPool ??
      deal.gross_commission_pool ??
      0
    );
  }, [debug, deal.gross_commission_pool]);

  const payouts: CommissionPayout[] = debug?.payouts || [];

  const summary = useMemo(() => {
    let workerTotal = 0;
    let houseTotal = 0;
    let isoTotal = 0;
    let referralTotal = 0;

    for (const p of payouts) {
      switch (p.participantRole) {
        case "OPENER":
        case "CLOSER":
          workerTotal += p.amount;
          break;
        case "HOUSE":
          houseTotal += p.amount;
          break;
        case "ISO_PARTNER":
          isoTotal += p.amount;
          break;
        case "WORKER_REFERRAL":
        case "REFERRAL_PARTNER":
          referralTotal += p.amount;
          break;
        default:
          break;
      }
    }

    return {
      workerTotal,
      houseTotal,
      isoTotal,
      referralTotal,
    };
  }, [payouts]);

  if (!debug) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Commission Breakdown</CardTitle>
          <CardDescription>
            No commission snapshot saved yet for this deal.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-2 text-sm text-muted-foreground">
          <p>
            Once this deal is finalized and the commission engine runs, the full
            breakdown (House, Opener, Closer, Referral, ISO) will appear here.
          </p>
        </CardContent>
      </Card>
    );
  }

  const { context, rules } = debug as {
    context: CommissionContext;
    rules: CommissionRules;
  };

  const openerCloserMode =
    context.closerUserId && context.closerUserId !== context.openerUserId
      ? "Opener + Closer"
      : "Single Worker";

  return (
    <Card>
      <CardHeader className="space-y-2">
        <div className="flex items-center justify-between gap-2">
          <div>
            <CardTitle>Commission Breakdown</CardTitle>
            <CardDescription>
              {deal.merchant_name
                ? `Deal for ${deal.merchant_name}`
                : "Deal commission distribution"}
            </CardDescription>
          </div>

          <div className="flex flex-col items-end gap-1 text-xs text-muted-foreground">
            <div>
              <span className="font-medium text-foreground">Pool: </span>
              <span>{formatCurrency(totalPool)}</span>
            </div>
            <div>
              <span className="font-medium text-foreground">Engine: </span>
              <span>{debug.version || "commission_engine_v1.1"}</span>
            </div>
            <div>
              <span className="font-medium text-foreground">Calculated: </span>
              <span>
                {new Date(debug.calculated_at).toLocaleString()}
              </span>
            </div>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-3 text-xs">
          <div className="flex items-center gap-1">
            <span className="font-medium text-foreground">Mode:</span>
            <span className="rounded-full bg-muted px-2 py-0.5">
              {context.autopilot
                ? "Autopilot (AI + House)"
                : "Team Split"}
            </span>
          </div>
          <div className="flex items-center gap-1">
            <span className="font-medium text-foreground">
              Opener/Closer Mode:
            </span>
            <span className="rounded-full bg-muted px-2 py-0.5">
              {openerCloserMode}
            </span>
          </div>
          <div className="flex items-center gap-1">
            <span className="font-medium text-foreground">
              House Min:
            </span>
            <span className="rounded-full bg-muted px-2 py-0.5">
              {formatPercent(rules.min_house_pct)} min
            </span>
          </div>
        </div>
      </CardHeader>

      <CardContent className="space-y-6">
        {/* High-level summary */}
        <div className="grid gap-3 sm:grid-cols-4">
          <SummaryItem label="Workers (Opener + Closer)" value={summary.workerTotal} />
          <SummaryItem label="House (Wolf)" value={summary.houseTotal} />
          <SummaryItem label="ISO Partners" value={summary.isoTotal} />
          <SummaryItem label="Referrals (Worker + Partners)" value={summary.referralTotal} />
        </div>

        {/* Detailed rows */}
        <div className="space-y-2">
          <div className="flex items-center justify-between text-xs text-muted-foreground">
            <span className="font-medium">Line Items</span>
            <span>100% = {formatCurrency(totalPool)}</span>
          </div>

          <div className="divide-y rounded-md border">
            {payouts.map((p, idx) => (
              <div
                key={`${p.participantRole}-${idx}`}
                className="flex flex-col gap-2 p-3 text-sm sm:flex-row sm:items-center sm:justify-between"
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <Badge
                      variant={
                        ROLE_BADGE_VARIANT[p.participantRole] ?? "outline"
                      }
                    >
                      {ROLE_LABEL[p.participantRole]}
                    </Badge>
                    {p.participantId && (
                      <span className="text-xs text-muted-foreground">
                        ID: {p.participantId}
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-muted-foreground">
                    {describeLine(p, context)}
                  </p>
                </div>

                <div className="flex items-end justify-between gap-3 sm:flex-col sm:items-end sm:justify-center">
                  <div className="text-right">
                    <div className="text-xs text-muted-foreground">
                      Amount
                    </div>
                    <div className="font-medium">
                      {formatCurrency(p.amount)}
                    </div>
                  </div>
                  <div className="text-right text-xs text-muted-foreground">
                    {formatPercent(p.percentOfPool)} of pool
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Referral + ISO info debug */}
        <div className="grid gap-4 border-t pt-4 text-xs text-muted-foreground sm:grid-cols-2">
          <div className="space-y-1">
            <div className="font-medium text-foreground">
              Referral Code / Owner
            </div>
            <div>Owner Type: {context.referralOwnerType}</div>
            <div>
              Owner ID: {context.referralEntityId ?? "—"}
            </div>
            <div>
              Default Referral %:{" "}
              {formatPercent(rules.default_referral_pct)}
            </div>
          </div>
          <div className="space-y-1">
            <div className="font-medium text-foreground">
              ISO Partner
            </div>
            <div>ISO Partner ID: {context.isoPartnerId ?? "—"}</div>
            <div>
              Default ISO %:{" "}
              {formatPercent(rules.default_iso_pct)}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

function SummaryItem(props: { label: string; value: number }) {
  return (
    <div className="rounded-md border bg-muted/40 p-3">
      <div className="text-xs text-muted-foreground">{props.label}</div>
      <div className="text-sm font-semibold">
        {formatCurrency(props.value)}
      </div>
    </div>
  );
}

function describeLine(p: CommissionPayout, ctx: CommissionContext): string {
  switch (p.participantRole) {
    case "OPENER":
      if (ctx.autopilot) {
        return "Opener slot – in Autopilot this is effectively handled by AI + House.";
      }
      return "Opener – generated / warmed up the lead.";
    case "CLOSER":
      return "Closer – took over and finished the deal.";
    case "WORKER_REFERRAL":
      return "Internal worker referral – friend / contact sent directly by a Wolf worker.";
    case "REFERRAL_PARTNER":
      return "External referral partner – affiliate, influencer, or partner program.";
    case "ISO_PARTNER":
      return "ISO partner – upstream ISO that owns the relationship.";
    case "HOUSE":
      return "House – Wolf Fund share after all splits.";
    case "AI_AUTOPILOT":
      return "Autopilot – AI-driven opener/closer logic (reporting only, not paid).";
    default:
      return "";
  }
}
