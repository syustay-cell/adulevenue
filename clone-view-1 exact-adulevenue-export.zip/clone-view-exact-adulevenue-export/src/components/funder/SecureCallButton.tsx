import { useState } from "react";
import { Phone, PhoneCall, PhoneOff, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "@/hooks/use-toast";

interface SecureCallButtonProps {
  dealRoomId: string;
  funderId: string;
  disabled?: boolean;
}

type CallStatus = "idle" | "connecting" | "active" | "failed" | "ended";

export function SecureCallButton({ dealRoomId, funderId, disabled }: SecureCallButtonProps) {
  const [status, setStatus] = useState<CallStatus>("idle");
  const [conferenceId, setConferenceId] = useState<string | null>(null);

  const initiateCall = async () => {
    setStatus("connecting");
    
    try {
      const { data, error } = await supabase.functions.invoke("wolf-call-bridge", {
        body: { deal_room_id: dealRoomId, funder_id: funderId }
      });

      if (error) throw error;

      if (data?.success) {
        setStatus("active");
        // Edge function returns `conference_name` (not `conference_id`)
        setConferenceId(data.conference_name ?? data.conference_id ?? null);
        toast({
          title: "Call Bridge Active",
          description: "You are now connected to the client through Wolf secure bridge.",
        });
      } else {
        throw new Error(data?.error || "Failed to initiate call");
      }
    } catch (err: any) {
      setStatus("failed");
      toast({
        title: "Call Failed",
        description: err.message || "Unable to connect. Please try again.",
        variant: "destructive",
      });
      // Reset after 3 seconds
      setTimeout(() => setStatus("idle"), 3000);
    }
  };

  const endCall = () => {
    // NOTE: This is UI-only. There is no server endpoint wired to end the Twilio conference.
    setStatus("ended");
    setConferenceId(null);
    toast({
      title: "Call Ended",
      description: "End-call is not implemented here. This only clears the UI; please hang up to end the call.",
    });
    setTimeout(() => setStatus("idle"), 2000);
  };

  const getStatusDisplay = () => {
    switch (status) {
      case "connecting":
        return (
          <div className="flex items-center gap-2 text-amber-600">
            <Loader2 className="h-4 w-4 animate-spin" />
            <span>Connecting...</span>
          </div>
        );
      case "active":
        return (
          <div className="flex items-center gap-2 text-green-600">
            <PhoneCall className="h-4 w-4 animate-pulse" />
            <span>Bridge Active</span>
          </div>
        );
      case "failed":
        return (
          <div className="flex items-center gap-2 text-destructive">
            <PhoneOff className="h-4 w-4" />
            <span>Failed, try again</span>
          </div>
        );
      case "ended":
        return (
          <div className="flex items-center gap-2 text-muted-foreground">
            <PhoneOff className="h-4 w-4" />
            <span>Call Ended</span>
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <div className="space-y-2">
      {status === "active" ? (
        <Button
          onClick={endCall}
          variant="destructive"
          className="w-full"
        >
          <PhoneOff className="h-4 w-4 mr-2" />
          End Secure Call
        </Button>
      ) : (
        <Button
          onClick={initiateCall}
          disabled={disabled || status === "connecting"}
          className="w-full"
        >
          {status === "connecting" ? (
            <Loader2 className="h-4 w-4 mr-2 animate-spin" />
          ) : (
            <Phone className="h-4 w-4 mr-2" />
          )}
          Secure Call Client
        </Button>
      )}
      
      {status !== "idle" && (
        <div className="text-sm text-center">
          {getStatusDisplay()}
        </div>
      )}
      
      <p className="text-xs text-muted-foreground text-center">
        Client identity is protected. You will never see their real phone number.
      </p>
    </div>
  );
}
