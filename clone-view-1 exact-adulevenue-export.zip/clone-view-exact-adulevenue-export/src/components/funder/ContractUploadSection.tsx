import { useState } from "react";
import { Upload, FileText, AlertTriangle, CheckCircle2, Loader2, DollarSign } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "@/hooks/use-toast";

interface ContractUploadSectionProps {
  dealRoomId: string;
  funderId: string;
  onUploadComplete?: () => void;
}

interface RiskAssessment {
  score: number;
  flags: string[];
  requires_review: boolean;
}

export function ContractUploadSection({ dealRoomId, funderId, onUploadComplete }: ContractUploadSectionProps) {
  const [uploading, setUploading] = useState(false);
  const [file, setFile] = useState<File | null>(null);
  const [amount, setAmount] = useState("");
  const [factorRate, setFactorRate] = useState("");
  const [termMonths, setTermMonths] = useState("");
  const [paymentFrequency, setPaymentFrequency] = useState("daily");
  const [estimatedDailyPayment, setEstimatedDailyPayment] = useState("");
  const [riskAssessment, setRiskAssessment] = useState<RiskAssessment | null>(null);
  const [contractId, setContractId] = useState<string | null>(null);
  const [status, setStatus] = useState<string | null>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFile(e.target.files[0]);
    }
  };

  const handleUpload = async () => {
    if (!file) {
      toast({ title: "Please select a file", variant: "destructive" });
      return;
    }

    if (!amount || !factorRate || !termMonths) {
      toast({ title: "Please fill in all required fields", variant: "destructive" });
      return;
    }

    setUploading(true);
    setRiskAssessment(null);

    try {
      // Upload file to storage
      const fileExt = file.name.split(".").pop();
      const fileName = `${dealRoomId}/${Date.now()}.${fileExt}`;
      
      const { data: uploadData, error: uploadError } = await supabase.storage
        .from("deal-contracts")
        .upload(fileName, file);

      if (uploadError) {
        // If bucket doesn't exist, show helpful message
        if (uploadError.message?.includes("not found")) {
          throw new Error("Contract storage is not configured. Please contact admin.");
        }
        throw uploadError;
      }

      // Get public URL
      const { data: urlData } = supabase.storage
        .from("deal-contracts")
        .getPublicUrl(fileName);

      // Call upload-deal-contract edge function
      const { data, error } = await supabase.functions.invoke("upload-deal-contract", {
        body: {
          deal_room_id: dealRoomId,
          funder_id: funderId,
          document_url: urlData.publicUrl,
          amount: parseFloat(amount),
          factor_rate: parseFloat(factorRate),
          term_months: parseInt(termMonths),
          payment_frequency: paymentFrequency,
          estimated_daily_payment: estimatedDailyPayment ? parseFloat(estimatedDailyPayment) : null,
        }
      });

      if (error) throw error;

      if (data?.success) {
        setContractId(data.contract_id);
        setStatus(data.status);
        setRiskAssessment(data.risk_assessment);
        
        toast({
          title: "Contract Uploaded",
          description: data.message,
        });

        onUploadComplete?.();
      } else {
        throw new Error(data?.error || "Failed to upload contract");
      }
    } catch (err: any) {
      toast({
        title: "Upload Failed",
        description: err.message || "Failed to upload contract",
        variant: "destructive",
      });
    } finally {
      setUploading(false);
    }
  };

  const resetForm = () => {
    setFile(null);
    setAmount("");
    setFactorRate("");
    setTermMonths("");
    setPaymentFrequency("daily");
    setEstimatedDailyPayment("");
    setRiskAssessment(null);
    setContractId(null);
    setStatus(null);
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <FileText className="h-5 w-5" />
          Upload Offer / Contract
        </CardTitle>
        <CardDescription>
          Submit your offer for AI risk assessment before sending to client
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Risk Assessment Result */}
        {riskAssessment && (
          <div className={`p-4 rounded-lg border ${riskAssessment.requires_review ? "bg-amber-50 border-amber-200" : "bg-green-50 border-green-200"}`}>
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                {riskAssessment.requires_review ? (
                  <AlertTriangle className="h-5 w-5 text-amber-600" />
                ) : (
                  <CheckCircle2 className="h-5 w-5 text-green-600" />
                )}
                <span className="font-medium">
                  {riskAssessment.requires_review ? "Needs Admin Review" : "Ready to Send"}
                </span>
              </div>
              <Badge variant={riskAssessment.requires_review ? "outline" : "default"}>
                Risk Score: {riskAssessment.score}
              </Badge>
            </div>

            {riskAssessment.flags.length > 0 && (
              <div className="space-y-1">
                <p className="text-sm font-medium text-muted-foreground">Risk Flags:</p>
                <ul className="text-sm space-y-1">
                  {riskAssessment.flags.map((flag, i) => (
                    <li key={i} className="text-amber-700">• {flag}</li>
                  ))}
                </ul>
              </div>
            )}

            <div className="mt-3 pt-3 border-t">
              <p className="text-sm text-muted-foreground">
                Contract ID: <span className="font-mono">{contractId}</span>
              </p>
              <p className="text-sm text-muted-foreground">
                Status: <Badge variant="outline" className="ml-1">{status}</Badge>
              </p>
            </div>

            <Button onClick={resetForm} variant="outline" size="sm" className="mt-3">
              Upload Another
            </Button>
          </div>
        )}

        {/* Upload Form */}
        {!riskAssessment && (
          <>
            <div className="space-y-2">
              <Label htmlFor="contract-file">Contract Document *</Label>
              <Input
                id="contract-file"
                type="file"
                accept=".pdf,.doc,.docx"
                onChange={handleFileChange}
                disabled={uploading}
              />
              {file && (
                <p className="text-sm text-muted-foreground">
                  Selected: {file.name}
                </p>
              )}
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="amount">Amount *</Label>
                <div className="relative">
                  <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    id="amount"
                    type="number"
                    placeholder="50000"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    className="pl-9"
                    disabled={uploading}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="factor-rate">Factor Rate *</Label>
                <Input
                  id="factor-rate"
                  type="number"
                  step="0.01"
                  placeholder="1.35"
                  value={factorRate}
                  onChange={(e) => setFactorRate(e.target.value)}
                  disabled={uploading}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="term-months">Term (Months) *</Label>
                <Input
                  id="term-months"
                  type="number"
                  placeholder="12"
                  value={termMonths}
                  onChange={(e) => setTermMonths(e.target.value)}
                  disabled={uploading}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="payment-frequency">Payment Frequency</Label>
                <Select value={paymentFrequency} onValueChange={setPaymentFrequency} disabled={uploading}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="daily">Daily</SelectItem>
                    <SelectItem value="weekly">Weekly</SelectItem>
                    <SelectItem value="bi-weekly">Bi-Weekly</SelectItem>
                    <SelectItem value="monthly">Monthly</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="daily-payment">Estimated Daily Payment (Optional)</Label>
              <div className="relative">
                <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  id="daily-payment"
                  type="number"
                  placeholder="250"
                  value={estimatedDailyPayment}
                  onChange={(e) => setEstimatedDailyPayment(e.target.value)}
                  className="pl-9"
                  disabled={uploading}
                />
              </div>
            </div>

            <Button onClick={handleUpload} disabled={uploading || !file} className="w-full">
              {uploading ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Uploading & Analyzing...
                </>
              ) : (
                <>
                  <Upload className="h-4 w-4 mr-2" />
                  Upload for AI Review
                </>
              )}
            </Button>

            <p className="text-xs text-muted-foreground text-center">
              Your contract will be scanned for predatory terms and risk factors before being sent to the client.
            </p>
          </>
        )}
      </CardContent>
    </Card>
  );
}
