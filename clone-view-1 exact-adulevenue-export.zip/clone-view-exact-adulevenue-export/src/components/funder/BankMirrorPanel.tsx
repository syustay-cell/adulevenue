import { useState, useEffect } from "react";
import { Building2, TrendingUp, TrendingDown, AlertTriangle, RefreshCw, Ban } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "@/hooks/use-toast";

interface BankMirrorData {
  snapshot_date: string;
  metrics: {
    avg_daily_balance: number | null;
    avg_monthly_revenue: number | null;
    total_deposits_30d: number | null;
    total_withdrawals_30d: number | null;
    nsf_count_30d: number | null;
    negative_balance_days_30d: number | null;
    lowest_balance_30d: number | null;
    highest_balance_30d: number | null;
  };
  risk_assessment: {
    score: number | null;
    flags: string[];
  };
  analysis_info: {
    months_analyzed: number | null;
    last_statement_date: string | null;
    generated_at: string | null;
  };
}

interface BankMirrorPanelProps {
  dealRoomId: string;
  funderId: string;
}

export function BankMirrorPanel({ dealRoomId, funderId }: BankMirrorPanelProps) {
  const [loading, setLoading] = useState(true);
  const [data, setData] = useState<BankMirrorData | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [featureDisabled, setFeatureDisabled] = useState(false);

  const fetchBankMirror = async () => {
    setLoading(true);
    setError(null);

    try {
      const { data: response, error: err } = await supabase.functions.invoke("get-bank-mirror", {
        body: { deal_room_id: dealRoomId, funder_id: funderId }
      });

      if (err) throw err;

      if (response?.error === "Bank mirror view feature is currently disabled") {
        setFeatureDisabled(true);
        return;
      }

      if (!response?.success) {
        throw new Error(response?.error || "Failed to fetch bank mirror");
      }

      if (response.data_available && response.bank_mirror) {
        setData(response.bank_mirror);
      } else {
        setData(null);
      }
    } catch (err: any) {
      if (err.message?.includes("disabled")) {
        setFeatureDisabled(true);
      } else {
        setError(err.message || "Failed to load bank data");
        toast({
          title: "Error",
          description: err.message || "Failed to load bank mirror data",
          variant: "destructive",
        });
      }
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchBankMirror();
  }, [dealRoomId, funderId]);

  const formatCurrency = (val: number | null) => {
    if (val === null || val === undefined) return "—";
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(val);
  };

  const getRiskBadge = (score: number | null) => {
    if (score === null) return <Badge variant="outline">Unknown</Badge>;
    if (score <= 30) return <Badge className="bg-green-500">Low Risk</Badge>;
    if (score <= 60) return <Badge className="bg-amber-500">Medium Risk</Badge>;
    return <Badge variant="destructive">High Risk</Badge>;
  };

  if (featureDisabled) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Ban className="h-5 w-5 text-muted-foreground" />
            Bank Mirror
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8 text-muted-foreground">
            <p>Bank Mirror view is currently disabled by the platform administrator.</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (loading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Building2 className="h-5 w-5" />
            Bank Mirror
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <Skeleton className="h-20 w-full" />
          <Skeleton className="h-20 w-full" />
          <Skeleton className="h-20 w-full" />
        </CardContent>
      </Card>
    );
  }

  if (error) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Building2 className="h-5 w-5" />
            Bank Mirror
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8">
            <p className="text-destructive mb-4">{error}</p>
            <Button onClick={fetchBankMirror} variant="outline" size="sm">
              <RefreshCw className="h-4 w-4 mr-2" />
              Retry
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (!data) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Building2 className="h-5 w-5" />
            Bank Mirror
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8 text-muted-foreground">
            <p>No bank data available for this deal yet.</p>
            <p className="text-sm mt-2">Bank statements have not been processed.</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              <Building2 className="h-5 w-5" />
              Bank Mirror
            </CardTitle>
            <CardDescription>
              Sanitized financial metrics • No PII
            </CardDescription>
          </div>
          <Button onClick={fetchBankMirror} variant="ghost" size="sm">
            <RefreshCw className="h-4 w-4" />
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Risk Assessment */}
        <div className="flex items-center justify-between p-4 bg-muted/50 rounded-lg">
          <div>
            <p className="text-sm text-muted-foreground">Risk Score</p>
            <p className="text-2xl font-bold">{data.risk_assessment.score ?? "—"}</p>
          </div>
          {getRiskBadge(data.risk_assessment.score)}
        </div>

        {/* Key Metrics Grid */}
        <div className="grid grid-cols-2 gap-4">
          <div className="p-4 border rounded-lg">
            <div className="flex items-center gap-2 text-muted-foreground mb-1">
              <TrendingUp className="h-4 w-4" />
              <span className="text-xs">Avg Monthly Revenue</span>
            </div>
            <p className="text-xl font-semibold">{formatCurrency(data.metrics.avg_monthly_revenue)}</p>
          </div>

          <div className="p-4 border rounded-lg">
            <div className="flex items-center gap-2 text-muted-foreground mb-1">
              <Building2 className="h-4 w-4" />
              <span className="text-xs">Avg Daily Balance</span>
            </div>
            <p className="text-xl font-semibold">{formatCurrency(data.metrics.avg_daily_balance)}</p>
          </div>

          <div className="p-4 border rounded-lg">
            <div className="flex items-center gap-2 text-muted-foreground mb-1">
              <TrendingUp className="h-4 w-4 text-green-500" />
              <span className="text-xs">Deposits (30d)</span>
            </div>
            <p className="text-xl font-semibold">{formatCurrency(data.metrics.total_deposits_30d)}</p>
          </div>

          <div className="p-4 border rounded-lg">
            <div className="flex items-center gap-2 text-muted-foreground mb-1">
              <TrendingDown className="h-4 w-4 text-red-500" />
              <span className="text-xs">Withdrawals (30d)</span>
            </div>
            <p className="text-xl font-semibold">{formatCurrency(data.metrics.total_withdrawals_30d)}</p>
          </div>
        </div>

        {/* Warning Metrics */}
        <div className="grid grid-cols-3 gap-3">
          <div className="p-3 border rounded-lg text-center">
            <p className="text-2xl font-bold text-destructive">{data.metrics.nsf_count_30d ?? 0}</p>
            <p className="text-xs text-muted-foreground">NSFs (30d)</p>
          </div>
          <div className="p-3 border rounded-lg text-center">
            <p className="text-2xl font-bold text-amber-600">{data.metrics.negative_balance_days_30d ?? 0}</p>
            <p className="text-xs text-muted-foreground">Neg. Days</p>
          </div>
          <div className="p-3 border rounded-lg text-center">
            <p className="text-lg font-bold">{formatCurrency(data.metrics.lowest_balance_30d)}</p>
            <p className="text-xs text-muted-foreground">Lowest Bal.</p>
          </div>
        </div>

        {/* Risk Flags */}
        {data.risk_assessment.flags?.length > 0 && (
          <div className="p-4 bg-destructive/10 border border-destructive/20 rounded-lg">
            <div className="flex items-center gap-2 mb-2">
              <AlertTriangle className="h-4 w-4 text-destructive" />
              <span className="font-medium text-destructive">Risk Flags</span>
            </div>
            <ul className="text-sm space-y-1">
              {data.risk_assessment.flags.map((flag, i) => (
                <li key={i} className="text-muted-foreground">• {flag}</li>
              ))}
            </ul>
          </div>
        )}

        {/* Analysis Info */}
        <div className="text-xs text-muted-foreground border-t pt-4">
          <p>Months Analyzed: {data.analysis_info.months_analyzed ?? "—"}</p>
          <p>Last Statement: {data.analysis_info.last_statement_date || "—"}</p>
          <p>Generated: {data.analysis_info.generated_at ? new Date(data.analysis_info.generated_at).toLocaleString() : "—"}</p>
        </div>
      </CardContent>
    </Card>
  );
}
