import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useSubmitOffer } from "@/hooks/useFunderOffers";
import { Loader2 } from "lucide-react";

interface FunderOfferDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  dealId: string;
  funderId: string;
  tenantId?: string;
  vaultId: string;
}

export function FunderOfferDialog({
  open,
  onOpenChange,
  dealId,
  funderId,
  tenantId,
  vaultId,
}: FunderOfferDialogProps) {
  const [approvedAmount, setApprovedAmount] = useState("");
  const [factorRate, setFactorRate] = useState("");
  const [termDays, setTermDays] = useState("");
  const [paymentFrequency, setPaymentFrequency] = useState("daily");

  const submitOffer = useSubmitOffer();

  const handleSubmit = async () => {
    if (!approvedAmount || !factorRate || !termDays) return;

    await submitOffer.mutateAsync({
      dealId,
      funderId,
      tenantId,
      approvedAmount: parseFloat(approvedAmount),
      factorRate: parseFloat(factorRate),
      termDays: parseInt(termDays),
      paymentFrequency,
    });

    onOpenChange(false);
    setApprovedAmount("");
    setFactorRate("");
    setTermDays("");
    setPaymentFrequency("daily");
  };

  const paybackAmount =
    approvedAmount && factorRate
      ? parseFloat(approvedAmount) * parseFloat(factorRate)
      : 0;

  const dailyPayment =
    paybackAmount && termDays ? paybackAmount / parseInt(termDays) : 0;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Submit Offer</DialogTitle>
          <DialogDescription>
            Submit a funding offer for Client #{vaultId.slice(0, 8)}
          </DialogDescription>
        </DialogHeader>

        <div className="grid gap-4 py-4">
          <div className="grid gap-2">
            <Label htmlFor="amount">Approved Amount ($)</Label>
            <Input
              id="amount"
              type="number"
              placeholder="25000"
              value={approvedAmount}
              onChange={(e) => setApprovedAmount(e.target.value)}
            />
          </div>

          <div className="grid gap-2">
            <Label htmlFor="factor">Factor Rate</Label>
            <Input
              id="factor"
              type="number"
              step="0.01"
              placeholder="1.35"
              value={factorRate}
              onChange={(e) => setFactorRate(e.target.value)}
            />
          </div>

          <div className="grid gap-2">
            <Label htmlFor="term">Term (Days)</Label>
            <Input
              id="term"
              type="number"
              placeholder="120"
              value={termDays}
              onChange={(e) => setTermDays(e.target.value)}
            />
          </div>

          <div className="grid gap-2">
            <Label htmlFor="frequency">Payment Frequency</Label>
            <Select value={paymentFrequency} onValueChange={setPaymentFrequency}>
              <SelectTrigger>
                <SelectValue placeholder="Select frequency" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="daily">Daily</SelectItem>
                <SelectItem value="weekly">Weekly</SelectItem>
                <SelectItem value="bi-weekly">Bi-Weekly</SelectItem>
                <SelectItem value="monthly">Monthly</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Calculated values */}
          {paybackAmount > 0 && (
            <div className="rounded-lg border border-border bg-muted/50 p-3 space-y-1 text-sm">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Payback Amount:</span>
                <span className="font-medium">${paybackAmount.toLocaleString()}</span>
              </div>
              {dailyPayment > 0 && (
                <div className="flex justify-between">
                  <span className="text-muted-foreground">
                    {paymentFrequency === "daily" ? "Daily" : paymentFrequency} Payment:
                  </span>
                  <span className="font-medium">${dailyPayment.toFixed(2)}</span>
                </div>
              )}
            </div>
          )}
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button
            onClick={handleSubmit}
            disabled={
              !approvedAmount ||
              !factorRate ||
              !termDays ||
              submitOffer.isPending
            }
          >
            {submitOffer.isPending && (
              <Loader2 className="h-4 w-4 mr-2 animate-spin" />
            )}
            Submit Offer
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
