import { useState, useEffect } from "react";
import { useParams } from "react-router-dom";
import { Building2, Phone, FileText, Clock, Shield, User, Brain } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { SecureCallButton } from "./SecureCallButton";
import { BankMirrorPanel } from "./BankMirrorPanel";
import { ContractUploadSection } from "./ContractUploadSection";
import { UnderwritingPanel } from "./UnderwritingPanel";
import { supabase } from "@/integrations/supabase/client";

interface DealRoom {
  id: string;
  vault_id: string;
  status: string;
  can_view_bank_data: boolean;
  can_send_offer: boolean;
  can_send_contract: boolean;
  created_at: string;
  expires_at: string | null;
  funder_agreed_terms: boolean;
  no_backdoor_signed: boolean;
}

export function DealRoomView() {
  const { dealRoomId } = useParams<{ dealRoomId: string }>();
  const [loading, setLoading] = useState(true);
  const [dealRoom, setDealRoom] = useState<DealRoom | null>(null);
  const [funderId, setFunderId] = useState<string | null>(null);

  useEffect(() => {
    const loadData = async () => {
      try {
        // Get current user's funder ID
        const { data: { user } } = await supabase.auth.getUser();
        if (!user) return;

        const { data: funder } = await supabase
          .from("funders")
          .select("id")
          .eq("user_id", user.id)
          .single();

        if (funder) {
          setFunderId(funder.id);
        }

        // Get deal room
        if (dealRoomId) {
          const { data: room } = await supabase
            .from("deal_rooms")
            .select("*")
            .eq("id", dealRoomId)
            .single();

          if (room) {
            setDealRoom(room as DealRoom);
          }
        }
      } catch (error) {
        console.error("Error loading deal room:", error);
      } finally {
        setLoading(false);
      }
    };

    loadData();
  }, [dealRoomId]);

  const getStatusBadge = (status: string) => {
    const variants: Record<string, "default" | "secondary" | "outline" | "destructive"> = {
      active: "default",
      pending: "secondary",
      offer_sent: "default",
      contract_sent: "default",
      closed: "outline",
      expired: "destructive",
    };
    return <Badge variant={variants[status] || "outline"}>{status.replace("_", " ")}</Badge>;
  };

  if (loading) {
    return (
      <div className="container mx-auto py-8 space-y-6">
        <Skeleton className="h-32 w-full" />
        <Skeleton className="h-64 w-full" />
      </div>
    );
  }

  if (!dealRoom || !funderId) {
    return (
      <div className="container mx-auto py-8">
        <Card>
          <CardContent className="py-12 text-center">
            <p className="text-muted-foreground">Deal room not found or you don't have access.</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="container mx-auto py-8 space-y-6">
      {/* Header */}
      <Card>
        <CardHeader>
          <div className="flex items-start justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <Shield className="h-5 w-5 text-primary" />
                Deal Room
              </CardTitle>
              <CardDescription className="mt-1">
                Client #{dealRoom.vault_id.slice(0, 8)} • Secure Wolf Vault Protection
              </CardDescription>
            </div>
            {getStatusBadge(dealRoom.status)}
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="p-3 bg-muted/50 rounded-lg">
              <p className="text-xs text-muted-foreground">Created</p>
              <p className="font-medium">{new Date(dealRoom.created_at!).toLocaleDateString()}</p>
            </div>
            <div className="p-3 bg-muted/50 rounded-lg">
              <p className="text-xs text-muted-foreground">Expires</p>
              <p className="font-medium">
                {dealRoom.expires_at ? new Date(dealRoom.expires_at).toLocaleDateString() : "No expiry"}
              </p>
            </div>
            <div className="p-3 bg-muted/50 rounded-lg">
              <p className="text-xs text-muted-foreground">Bank Access</p>
              <p className="font-medium">{dealRoom.can_view_bank_data ? "✓ Enabled" : "✗ Disabled"}</p>
            </div>
            <div className="p-3 bg-muted/50 rounded-lg">
              <p className="text-xs text-muted-foreground">Contract Access</p>
              <p className="font-medium">{dealRoom.can_send_contract ? "✓ Enabled" : "✗ Disabled"}</p>
            </div>
          </div>

          {/* Secure Call Button */}
          <div className="mt-6">
            <SecureCallButton
              dealRoomId={dealRoom.id}
              funderId={funderId}
            />
          </div>
        </CardContent>
      </Card>

      {/* Underwriting Panel */}
      <UnderwritingPanel dealId={dealRoom.id} dealRoomId={dealRoom.id} />

      {/* Tabs */}
      <Tabs defaultValue="bank" className="space-y-4">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="underwriting" className="flex items-center gap-2">
            <Brain className="h-4 w-4" />
            Underwriting
          </TabsTrigger>
          <TabsTrigger value="bank" className="flex items-center gap-2">
            <Building2 className="h-4 w-4" />
            Bank Mirror
          </TabsTrigger>
          <TabsTrigger value="contract" className="flex items-center gap-2">
            <FileText className="h-4 w-4" />
            Contract
          </TabsTrigger>
          <TabsTrigger value="activity" className="flex items-center gap-2">
            <Clock className="h-4 w-4" />
            Activity
          </TabsTrigger>
        </TabsList>

        <TabsContent value="underwriting">
          <UnderwritingPanel dealId={dealRoom.id} dealRoomId={dealRoom.id} />
        </TabsContent>

        <TabsContent value="bank">
          {dealRoom.can_view_bank_data ? (
            <BankMirrorPanel dealRoomId={dealRoom.id} funderId={funderId} />
          ) : (
            <Card>
              <CardContent className="py-12 text-center text-muted-foreground">
                Bank data access is not granted for this deal.
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="contract">
          {dealRoom.can_send_contract ? (
            <ContractUploadSection dealRoomId={dealRoom.id} funderId={funderId} />
          ) : (
            <Card>
              <CardContent className="py-12 text-center text-muted-foreground">
                Contract access is not granted for this deal.
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="activity">
          <Card>
            <CardHeader>
              <CardTitle>Activity Log</CardTitle>
              <CardDescription>All interactions with this deal</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground text-center py-8">
                Activity log coming soon. All calls, messages, and contract events will be shown here.
              </p>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Wolf Vault Notice */}
      <Card className="bg-primary/5 border-primary/20">
        <CardContent className="py-4">
          <div className="flex items-center gap-3">
            <Shield className="h-8 w-8 text-primary" />
            <div>
              <p className="font-medium">Wolf Vault Protection Active</p>
              <p className="text-sm text-muted-foreground">
                Client identity is masked. All communication is logged and goes through Wolf.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
