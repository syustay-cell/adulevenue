import { useState, useEffect } from "react";
import { Brain, RefreshCw, AlertTriangle, CheckCircle2, HelpCircle, TrendingUp } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Skeleton } from "@/components/ui/skeleton";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "@/hooks/use-toast";

interface UnderwritingCase {
  id: string;
  deal_id: string;
  status: string;
  decision: string | null;
  decision_reason: string | null;
  risk_score: number | null;
  risk_buckets: Record<string, number> | null;
  flags: Array<{ code: string; severity: string; message: string }> | null;
  recommended_products: any[] | null;
  run_ts: string;
  engine_version: string | null;
}

interface UnderwritingPanelProps {
  dealId: string;
  dealRoomId?: string;
}

export function UnderwritingPanel({ dealId, dealRoomId }: UnderwritingPanelProps) {
  const [loading, setLoading] = useState(true);
  const [running, setRunning] = useState(false);
  const [latestCase, setLatestCase] = useState<UnderwritingCase | null>(null);

  const fetchLatestCase = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from("wolf_underwriting_cases" as any)
        .select("*")
        .eq("deal_id", dealId)
        .order("run_ts", { ascending: false })
        .limit(1)
        .single();

      if (error && error.code !== "PGRST116") {
        console.error("Error fetching underwriting case:", error);
      }
      setLatestCase(data as unknown as UnderwritingCase | null);
    } catch (err) {
      console.error("Error:", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchLatestCase();
  }, [dealId]);

  const runUnderwriting = async () => {
    setRunning(true);
    try {
      const { data, error } = await supabase.functions.invoke("wolf-underwriter-eval", {
        body: {
          deal_id: dealId,
          deal_room_id: dealRoomId,
          run_mode: "normal",
        },
      });

      // Transport error (network, function not found, etc.)
      if (error) {
        console.error("[UnderwritingPanel] Transport error:", error);
        toast({
          title: "Connection Error",
          description: "Unable to reach underwriting service. Please try again.",
          variant: "destructive",
        });
        return;
      }

      // Business logic error (ok: false)
      if (!data?.ok) {
        toast({
          title: "Underwriting Failed",
          description: data?.error || "Unable to complete underwriting. Please try again.",
          variant: "destructive",
        });
        return;
      }

      // Success
      toast({
        title: "Underwriting Complete",
        description: `Decision: ${String(data.decision).toUpperCase()} (Score: ${data.risk_score})`,
      });
      fetchLatestCase();
    } catch (err: any) {
      console.error("[UnderwritingPanel] Unexpected error:", err);
      toast({
        title: "Underwriting Failed",
        description: "An unexpected error occurred. Please try again.",
        variant: "destructive",
      });
    } finally {
      setRunning(false);
    }
  };

  const getDecisionBadge = (decision: string | null) => {
    switch (decision) {
      case "approve":
        return <Badge className="bg-green-500">Approve</Badge>;
      case "decline":
        return <Badge variant="destructive">Decline</Badge>;
      case "review":
        return <Badge className="bg-amber-500">Review</Badge>;
      default:
        return <Badge variant="outline">Unknown</Badge>;
    }
  };

  const getDecisionIcon = (decision: string | null) => {
    switch (decision) {
      case "approve":
        return <CheckCircle2 className="h-5 w-5 text-green-500" />;
      case "decline":
        return <AlertTriangle className="h-5 w-5 text-destructive" />;
      case "review":
        return <HelpCircle className="h-5 w-5 text-amber-500" />;
      default:
        return <Brain className="h-5 w-5 text-muted-foreground" />;
    }
  };

  const getRiskColor = (score: number) => {
    if (score <= 40) return "text-green-500";
    if (score <= 60) return "text-amber-500";
    return "text-destructive";
  };

  if (loading) {
    return (
      <Card>
        <CardHeader>
          <Skeleton className="h-6 w-40" />
        </CardHeader>
        <CardContent>
          <Skeleton className="h-32 w-full" />
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Brain className="h-5 w-5 text-primary" />
            <CardTitle className="text-lg">Underwriting</CardTitle>
          </div>
          <Button
            size="sm"
            onClick={runUnderwriting}
            disabled={running}
          >
            <RefreshCw className={`h-4 w-4 mr-2 ${running ? "animate-spin" : ""}`} />
            {running ? "Running..." : latestCase ? "Re-run" : "Run Underwriting"}
          </Button>
        </div>
        {latestCase && (
          <CardDescription>
            Last run: {new Date(latestCase.run_ts).toLocaleString()} • Engine: {latestCase.engine_version}
          </CardDescription>
        )}
      </CardHeader>
      <CardContent>
        {!latestCase ? (
          <div className="text-center py-8 text-muted-foreground">
            <Brain className="h-12 w-12 mx-auto mb-4 opacity-50" />
            <p>No underwriting run yet.</p>
            <p className="text-sm">Click "Run Underwriting" to evaluate this deal.</p>
          </div>
        ) : (
          <div className="space-y-4">
            {/* Decision Header */}
            <div className="flex items-center justify-between p-4 bg-muted/50 rounded-lg">
              <div className="flex items-center gap-3">
                {getDecisionIcon(latestCase.decision)}
                <div>
                  <div className="flex items-center gap-2">
                    {getDecisionBadge(latestCase.decision)}
                    <span className={`font-bold ${getRiskColor(latestCase.risk_score || 0)}`}>
                      Risk: {latestCase.risk_score}
                    </span>
                  </div>
                  <p className="text-sm text-muted-foreground mt-1">
                    {latestCase.decision_reason}
                  </p>
                </div>
              </div>
            </div>

            {/* Risk Score Bar */}
            <div>
              <div className="flex justify-between text-sm mb-1">
                <span className="text-muted-foreground">Risk Level</span>
                <span className={getRiskColor(latestCase.risk_score || 0)}>
                  {latestCase.risk_score}%
                </span>
              </div>
              <Progress 
                value={latestCase.risk_score || 0} 
                className="h-2"
              />
            </div>

            {/* Risk Buckets */}
            {latestCase.risk_buckets && Object.keys(latestCase.risk_buckets).length > 0 && (
              <div className="grid grid-cols-2 gap-2">
                {Object.entries(latestCase.risk_buckets).map(([key, value]) => (
                  <div key={key} className="p-2 bg-muted/30 rounded text-sm">
                    <span className="text-muted-foreground capitalize">{key.replace(/_/g, " ")}</span>
                    <span className="float-right font-medium">{Math.round((value as number) * 100)}%</span>
                  </div>
                ))}
              </div>
            )}

            {/* Flags */}
            {latestCase.flags && latestCase.flags.length > 0 && (
              <div className="space-y-2">
                <p className="text-sm font-medium text-muted-foreground">Risk Flags</p>
                <div className="space-y-1">
                  {latestCase.flags.slice(0, 5).map((flag, idx) => (
                    <div 
                      key={idx} 
                      className={`flex items-start gap-2 p-2 rounded text-sm ${
                        flag.severity === "error" ? "bg-destructive/10" :
                        flag.severity === "warn" ? "bg-amber-500/10" :
                        "bg-muted/50"
                      }`}
                    >
                      <AlertTriangle className={`h-4 w-4 mt-0.5 ${
                        flag.severity === "error" ? "text-destructive" :
                        flag.severity === "warn" ? "text-amber-500" :
                        "text-muted-foreground"
                      }`} />
                      <span>{flag.message}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Recommended Products */}
            {latestCase.recommended_products && latestCase.recommended_products.length > 0 && (
              <div>
                <p className="text-sm font-medium text-muted-foreground mb-2">Recommended Products</p>
                <div className="flex gap-2 flex-wrap">
                  {latestCase.recommended_products.map((product: any, idx) => (
                    <Badge key={idx} variant="outline">
                      <TrendingUp className="h-3 w-3 mr-1" />
                      {product.type?.toUpperCase()} - {product.tier}
                    </Badge>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
