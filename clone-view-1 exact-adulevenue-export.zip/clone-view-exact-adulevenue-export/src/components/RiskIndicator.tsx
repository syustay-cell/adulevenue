// src/components/RiskIndicator.tsx
// V11 / B200: Risk level badge component

import React from "react";
import { WolfRiskLevel, riskLabel, scoreToRiskLevel } from "@/lib/wolfAnalytics";

interface RiskIndicatorProps {
  score: number;
}

export const RiskIndicator: React.FC<RiskIndicatorProps> = ({ score }) => {
  const level: WolfRiskLevel = scoreToRiskLevel(score);
  const label = `${riskLabel(level)} (${Math.round(score)})`;

  const bg =
    level === "high"
      ? "bg-destructive/10 text-destructive"
      : level === "medium"
      ? "bg-yellow-500/10 text-yellow-700"
      : level === "low"
      ? "bg-green-500/10 text-green-700"
      : "bg-muted text-muted-foreground";

  return (
    <span className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-medium ${bg}`}>
      {label}
    </span>
  );
};
