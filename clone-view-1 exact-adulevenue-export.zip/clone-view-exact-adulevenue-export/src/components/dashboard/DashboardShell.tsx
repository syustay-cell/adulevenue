import React from "react";
import { cn } from "@/lib/utils";
import { GlobalSearchTrigger } from "@/components/global-search/GlobalSearchTrigger";
import { AutoListenToggle } from "@/components/ui/AutoListenToggle";

type DashboardShellProps = {
  roleLabel: string;
  breadcrumbTail: string;
  title: string;
  description?: string;
  showSearch?: boolean;
  showAutoListen?: boolean;
  className?: string;
  children: React.ReactNode;
};

export function DashboardShell({
  roleLabel,
  breadcrumbTail,
  title,
  description,
  showSearch = true,
  showAutoListen = true,
  className,
  children,
}: DashboardShellProps) {
  return (
    <div className={cn("flex h-full flex-col gap-4 px-4 py-4 sm:px-6 lg:px-8", className)}>
      {/* Top Shell / Breadcrumb + Controls */}
      <div className="flex flex-col gap-4 border-b border-border pb-4 md:flex-row md:items-center md:justify-between">
        {/* Left: breadcrumb + title */}
        <div className="space-y-2">
          <div className="flex items-center gap-2 text-xs font-medium text-muted-foreground">
            <span>{roleLabel}</span>
            <span className="text-border">/</span>
            <span className="text-foreground">{breadcrumbTail}</span>
          </div>

          <div className="space-y-1">
            <h1 className="text-lg font-semibold tracking-tight sm:text-xl lg:text-2xl">
              {title}
            </h1>
            {description && (
              <p className="max-w-3xl text-xs text-muted-foreground sm:text-sm">
                {description}
              </p>
            )}
          </div>
        </div>

        {/* Right: Global Search + Auto-listen */}
        {(showSearch || showAutoListen) && (
          <div className="flex items-center justify-start gap-3 md:justify-end">
            {showSearch && (
              <div className="hidden sm:block">
                <GlobalSearchTrigger />
              </div>
            )}
            {showAutoListen && <AutoListenToggle />}
          </div>
        )}
      </div>

      {/* Main content */}
      <div className="flex-1">
        {children}
      </div>
    </div>
  );
}
