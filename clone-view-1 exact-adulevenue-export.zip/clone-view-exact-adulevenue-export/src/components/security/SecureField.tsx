// V25: Secure field component with masking and reveal

import { useState, useCallback } from 'react';
import { Lock, Eye, EyeOff } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import { useAuditLog } from '@/hooks/useAuditLog';
import { 
  maskSSN, 
  maskPhone, 
  maskEmail, 
  maskName, 
  maskAddress,
  type MaskLevel 
} from '@/lib/securityMasking';

type FieldType = 'ssn' | 'phone' | 'email' | 'name' | 'address' | 'text';

interface SecureFieldProps {
  value: string | null | undefined;
  type: FieldType;
  maskLevel: MaskLevel;
  allowReveal?: boolean;
  resourceType?: string;
  resourceId?: string;
  className?: string;
}

const maskFunctions: Record<FieldType, (v: string | null | undefined, opts: { level: MaskLevel }) => string> = {
  ssn: maskSSN,
  phone: maskPhone,
  email: maskEmail,
  name: maskName,
  address: maskAddress,
  text: (v, opts) => opts.level === 'none' ? (v || '') : '••••••••',
};

export function SecureField({
  value,
  type,
  maskLevel,
  allowReveal = false,
  resourceType = 'unknown',
  resourceId = 'unknown',
  className,
}: SecureFieldProps) {
  const [revealed, setRevealed] = useState(false);
  const { logFieldReveal } = useAuditLog();

  const handleReveal = useCallback(() => {
    if (!revealed) {
      logFieldReveal(type, resourceType, resourceId);
    }
    setRevealed(!revealed);
  }, [revealed, type, resourceType, resourceId, logFieldReveal]);

  const maskFn = maskFunctions[type] || maskFunctions.text;
  const displayLevel = revealed ? 'none' : maskLevel;
  const displayValue = maskFn(value, { level: displayLevel });

  const isVaultLocked = maskLevel === 'vault' && !allowReveal;

  return (
    <span 
      className={cn(
        'inline-flex items-center gap-2 font-mono',
        isVaultLocked && 'text-muted-foreground',
        className
      )}
      data-sensitive={maskLevel !== 'none'}
    >
      {isVaultLocked && <Lock className="h-3 w-3 text-destructive" />}
      <span className={cn(
        maskLevel === 'vault' && 'blur-sm select-none',
        revealed && 'blur-0'
      )}>
        {displayValue}
      </span>
      {allowReveal && maskLevel !== 'none' && (
        <Button
          variant="ghost"
          size="sm"
          className="h-6 w-6 p-0"
          onClick={handleReveal}
        >
          {revealed ? (
            <EyeOff className="h-3 w-3" />
          ) : (
            <Eye className="h-3 w-3" />
          )}
        </Button>
      )}
    </span>
  );
}
