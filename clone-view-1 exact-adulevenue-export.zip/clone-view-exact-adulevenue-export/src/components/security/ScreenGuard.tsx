// V25: Screen guard wrapper for internal dashboards (anti-screenshot)

import { ReactNode, useEffect } from 'react';
import { useAntiScreenshot } from '@/hooks/useAntiScreenshot';
import { useToast } from '@/hooks/use-toast';

interface ScreenGuardProps {
  children: ReactNode;
  enabled?: boolean;
}

export function ScreenGuard({ children, enabled = true }: ScreenGuardProps) {
  const { toast } = useToast();

  const { logAttempt } = useAntiScreenshot({
    enabled,
    onAttempt: (type) => {
      toast({
        title: 'Security Alert',
        description: 'Screen capture has been blocked and logged.',
        variant: 'destructive',
      });
    },
  });

  useEffect(() => {
    if (!enabled) return;

    // Inject CSS for additional protections
    const style = document.createElement('style');
    style.id = 'wolf-screen-guard-styles';
    style.textContent = `
      [data-sensitive] {
        -webkit-user-select: none !important;
        user-select: none !important;
      }
      
      @media print {
        [data-sensitive] {
          visibility: hidden !important;
        }
        body::before {
          content: 'Printing of sensitive content is blocked';
          display: block;
          text-align: center;
          padding: 2rem;
          font-size: 1.5rem;
        }
      }
    `;
    document.head.appendChild(style);

    return () => {
      document.getElementById('wolf-screen-guard-styles')?.remove();
    };
  }, [enabled]);

  return <>{children}</>;
}
