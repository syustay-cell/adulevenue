// V25: Vault mask wrapper for sensitive content sections

import { ReactNode } from 'react';
import { Lock, ShieldOff } from 'lucide-react';
import { cn } from '@/lib/utils';
import { useSecurity } from '@/components/providers/SecurityProvider';

interface VaultMaskProps {
  children: ReactNode;
  className?: string;
  showDeniedMessage?: boolean;
}

export function VaultMask({ 
  children, 
  className,
  showDeniedMessage = true 
}: VaultMaskProps) {
  const { canAccessVault } = useSecurity();

  if (canAccessVault) {
    return <>{children}</>;
  }

  return (
    <div className={cn('relative', className)}>
      {/* Blurred content (zero-knowledge preview) */}
      <div 
        className="blur-md select-none pointer-events-none opacity-50"
        data-sensitive="true"
        aria-hidden="true"
      >
        {children}
      </div>

      {/* Overlay message */}
      {showDeniedMessage && (
        <div className="absolute inset-0 flex flex-col items-center justify-center bg-background/80 backdrop-blur-sm">
          <div className="flex flex-col items-center gap-2 text-muted-foreground">
            <div className="flex items-center gap-2">
              <Lock className="h-5 w-5" />
              <ShieldOff className="h-5 w-5" />
            </div>
            <span className="text-sm font-medium">Vault Access Required</span>
            <span className="text-xs">Owner or Legal role needed</span>
          </div>
        </div>
      )}
    </div>
  );
}
