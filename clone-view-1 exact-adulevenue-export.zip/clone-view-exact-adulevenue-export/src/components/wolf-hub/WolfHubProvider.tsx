import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { WolfHubButton } from "./WolfHubButton";
import { WolfHubDrawer } from "./WolfHubDrawer";

export const WolfHubProvider = () => {
  const [open, setOpen] = useState(false);
  const [userId, setUserId] = useState<string | null>(null);
  const [userEmail, setUserEmail] = useState("");
  const [userRole, setUserRole] = useState("user");

  useEffect(() => {
    const fetchUser = async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      setUserId(user.id);
      setUserEmail(user.email || "");

      // Get role
      const { data: roleData } = await supabase
        .from("user_roles")
        .select("role")
        .eq("user_id", user.id)
        .eq("approved", true)
        .order("created_at", { ascending: false })
        .limit(1)
        .maybeSingle();

      if (roleData?.role) {
        setUserRole(roleData.role);
      }

      // Update presence
      await supabase.functions.invoke("wolf-hub-chat", {
        body: { action: "update_presence", is_online: true },
      });
    };

    fetchUser();

    // Update presence every 2 minutes
    const interval = setInterval(() => {
      if (userId) {
        supabase.functions.invoke("wolf-hub-chat", {
          body: { action: "update_presence", is_online: true },
        });
      }
    }, 120000);

    // Set offline on unmount
    return () => {
      clearInterval(interval);
      if (userId) {
        supabase.functions.invoke("wolf-hub-chat", {
          body: { action: "update_presence", is_online: false },
        });
      }
    };
  }, [userId]);

  if (!userId) return null;

  return (
    <>
      <WolfHubButton onClick={() => setOpen(true)} />
      <WolfHubDrawer
        open={open}
        onClose={() => setOpen(false)}
        userRole={userRole}
        userEmail={userEmail}
        userId={userId}
      />
    </>
  );
};
