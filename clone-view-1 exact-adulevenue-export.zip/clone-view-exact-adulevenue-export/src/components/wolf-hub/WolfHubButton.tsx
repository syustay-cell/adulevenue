import { HelpCircle } from "lucide-react";

interface WolfHubButtonProps {
  onClick: () => void;
}

export const WolfHubButton = ({ onClick }: WolfHubButtonProps) => {
  return (
    <button
      type="button"
      onClick={onClick}
      className="fixed bottom-6 right-6 z-40 flex h-14 w-14 items-center justify-center rounded-full bg-gradient-to-br from-amber-400 to-amber-600 text-white shadow-lg shadow-amber-500/30 transition-all hover:scale-105 hover:shadow-amber-500/40"
      aria-label="Open Wolf Hub"
    >
      <HelpCircle className="h-7 w-7" />
    </button>
  );
};
