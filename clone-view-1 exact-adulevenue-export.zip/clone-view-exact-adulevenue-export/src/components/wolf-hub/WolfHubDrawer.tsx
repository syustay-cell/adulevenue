import { useState, useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { X, Send, Loader2, Sparkles, MessageSquare, Users, LayoutDashboard } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

interface WolfHubDrawerProps {
  open: boolean;
  onClose: () => void;
  userRole: string;
  userEmail: string;
  userId: string;
}

interface Message {
  role: "user" | "assistant";
  content: string;
}

interface Conversation {
  id: string;
  department: string;
  subject: string | null;
  status: string;
  updated_at: string;
  chat_messages?: { body: string; sender_role: string; created_at: string }[];
}

interface ChatMessage {
  id: string;
  body: string;
  sender_id: string;
  sender_role: string;
  created_at: string;
}

const DEPARTMENTS = [
  { value: "funding", label: "Funding / Application", icon: "💰" },
  { value: "credit_fix", label: "Credit Repair", icon: "🔧" },
  { value: "underwriting", label: "Underwriting Question", icon: "📋" },
  { value: "general", label: "General Support", icon: "💬" },
];

export const WolfHubDrawer = ({
  open,
  onClose,
  userRole,
  userEmail,
  userId,
}: WolfHubDrawerProps) => {
  const navigate = useNavigate();
  const isOwner = userRole === "owner";
  const [activeTab, setActiveTab] = useState<"ai" | "chat">("ai");
  
  // AI Assistant state
  const [aiQuestion, setAiQuestion] = useState("");
  const [aiMessages, setAiMessages] = useState<Message[]>([]);
  const [aiLoading, setAiLoading] = useState(false);

  // Chat state
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [activeConversation, setActiveConversation] = useState<string | null>(null);
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([]);
  const [chatInput, setChatInput] = useState("");
  const [chatLoading, setChatLoading] = useState(false);
  const [showNewChat, setShowNewChat] = useState(false);
  const [selectedDepartment, setSelectedDepartment] = useState<string | null>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Load conversations on open
  useEffect(() => {
    if (open && activeTab === "chat") {
      loadConversations();
    }
  }, [open, activeTab]);

  // Subscribe to realtime messages
  useEffect(() => {
    if (!activeConversation) return;

    const channel = supabase
      .channel(`chat-${activeConversation}`)
      .on(
        "postgres_changes",
        {
          event: "INSERT",
          schema: "public",
          table: "chat_messages",
          filter: `conversation_id=eq.${activeConversation}`,
        },
        (payload) => {
          const newMsg = payload.new as ChatMessage;
          setChatMessages((prev) => [...prev, newMsg]);
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [activeConversation]);

  // Scroll to bottom on new messages
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [chatMessages, aiMessages]);

  const loadConversations = async () => {
    try {
      const { data, error } = await supabase.functions.invoke("wolf-hub-chat", {
        body: { action: "get_conversations" },
      });
      if (error) throw error;
      setConversations(data?.conversations || []);
    } catch (e) {
      console.error("Failed to load conversations:", e);
    }
  };

  const loadMessages = async (convId: string) => {
    try {
      const { data, error } = await supabase.functions.invoke("wolf-hub-chat", {
        body: { action: "get_messages", conversation_id: convId },
      });
      if (error) throw error;
      setChatMessages(data?.messages || []);
      setActiveConversation(convId);
      setShowNewChat(false);
    } catch (e) {
      console.error("Failed to load messages:", e);
    }
  };

  const createConversation = async (department: string) => {
    try {
      setChatLoading(true);
      const { data, error } = await supabase.functions.invoke("wolf-hub-chat", {
        body: { action: "create_conversation", department },
      });
      if (error) throw error;
      
      await loadConversations();
      if (data?.conversation?.id) {
        await loadMessages(data.conversation.id);
      }
      setSelectedDepartment(null);
      setShowNewChat(false);
    } catch (e) {
      console.error("Failed to create conversation:", e);
    } finally {
      setChatLoading(false);
    }
  };

  const sendChatMessage = async () => {
    if (!chatInput.trim() || !activeConversation) return;

    const body = chatInput.trim();
    setChatInput("");
    setChatLoading(true);

    try {
      const { error } = await supabase.functions.invoke("wolf-hub-chat", {
        body: { action: "send_message", conversation_id: activeConversation, body },
      });
      if (error) throw error;
    } catch (e) {
      console.error("Failed to send message:", e);
      setChatInput(body); // Restore on error
    } finally {
      setChatLoading(false);
    }
  };

  const askAI = async () => {
    if (!aiQuestion.trim() || aiLoading) return;

    const userMessage = aiQuestion.trim();
    setAiQuestion("");
    setAiMessages((prev) => [...prev, { role: "user", content: userMessage }]);
    setAiLoading(true);

    try {
      const { data, error } = await supabase.functions.invoke("wolf-assistant", {
        body: {
          role: userRole,
          email: userEmail,
          page: window.location.pathname,
          entity: null,
          question: userMessage,
        },
      });

      if (error) throw error;
      setAiMessages((prev) => [
        ...prev,
        { role: "assistant", content: data?.answer || "No response received." },
      ]);
    } catch (e: any) {
      setAiMessages((prev) => [
        ...prev,
        { role: "assistant", content: `Error: ${e.message || "Unknown error"}` },
      ]);
    } finally {
      setAiLoading(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent, type: "ai" | "chat") => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      if (type === "ai") askAI();
      else sendChatMessage();
    }
  };

  const getDepartmentLabel = (dept: string) => {
    const d = DEPARTMENTS.find((d) => d.value === dept);
    return d ? d.label : "Support";
  };

  const getDisplayName = (senderRole: string) => {
    if (senderRole === "client") return "You";
    if (senderRole === "admin") return "Wolf Fund Support";
    if (senderRole === "worker") return "Wolf Fund Team";
    if (senderRole === "underwriter") return "Underwriting Desk";
    if (senderRole === "credit_fix") return "Credit Fix Support";
    return "Wolf Fund";
  };

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 flex justify-end">
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={onClose} />

      <div className="relative flex h-full w-full max-w-md flex-col bg-slate-950 shadow-2xl animate-in slide-in-from-right duration-300">
        {/* Header */}
        <header className="flex items-center justify-between border-b border-slate-800 px-4 py-3">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-gradient-to-br from-amber-400 to-amber-600">
              <Sparkles className="h-5 w-5 text-white" />
            </div>
            <div>
              <h2 className="text-sm font-semibold text-white">Wolf Hub</h2>
              <p className="text-[11px] text-slate-400">{userRole} · {userEmail}</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="flex h-8 w-8 items-center justify-center rounded-full bg-slate-800 text-slate-400 hover:bg-slate-700 hover:text-white"
          >
            <X className="h-4 w-4" />
          </button>
        </header>

        {/* Owner Motherboard Quick Access - Owner role only */}
        {isOwner && (
          <div className="border-b border-slate-800 px-4 py-3">
            <button
              type="button"
              onClick={() => {
                navigate('/owner/motherboard');
                onClose();
              }}
              className="flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 px-4 py-3 text-sm font-medium text-white shadow-lg shadow-amber-500/20 transition-all hover:from-amber-400 hover:to-amber-500 hover:shadow-amber-500/30"
            >
              <LayoutDashboard className="h-4 w-4" />
              Owner Motherboard
            </button>
          </div>
        )}

        {/* Tabs */}
        <Tabs value={activeTab} onValueChange={(v) => setActiveTab(v as "ai" | "chat")} className="flex-1 flex flex-col">
          <TabsList className="mx-4 mt-3 grid w-auto grid-cols-2 bg-slate-900">
            <TabsTrigger value="ai" className="flex items-center gap-2 text-xs">
              <Sparkles className="h-3.5 w-3.5" />
              AI Assistant
            </TabsTrigger>
            <TabsTrigger value="chat" className="flex items-center gap-2 text-xs">
              <MessageSquare className="h-3.5 w-3.5" />
              Chat with Team
            </TabsTrigger>
          </TabsList>

          {/* AI Tab */}
          <TabsContent value="ai" className="flex-1 flex flex-col mt-0 data-[state=inactive]:hidden">
            <ScrollArea className="flex-1 px-4 py-4">
              {aiMessages.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-12 text-center">
                  <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-slate-800">
                    <Sparkles className="h-8 w-8 text-amber-400" />
                  </div>
                  <h3 className="mb-2 text-sm font-medium text-white">Ask Wolf AI</h3>
                  <p className="max-w-xs text-[12px] text-slate-400">
                    Ask about your file status, documents needed, or how to navigate the platform.
                  </p>
                </div>
              ) : (
                <div className="space-y-4">
                  {aiMessages.map((msg, i) => (
                    <div key={i} className={cn("flex", msg.role === "user" ? "justify-end" : "justify-start")}>
                      <div className={cn(
                        "max-w-[85%] rounded-2xl px-4 py-2.5 text-[13px]",
                        msg.role === "user" ? "bg-amber-500 text-white" : "bg-slate-800 text-slate-100"
                      )}>
                        <p className="whitespace-pre-wrap">{msg.content}</p>
                      </div>
                    </div>
                  ))}
                  {aiLoading && (
                    <div className="flex justify-start">
                      <div className="flex items-center gap-2 rounded-2xl bg-slate-800 px-4 py-2.5 text-slate-400">
                        <Loader2 className="h-4 w-4 animate-spin" />
                        <span className="text-[12px]">Thinking...</span>
                      </div>
                    </div>
                  )}
                  <div ref={messagesEndRef} />
                </div>
              )}
            </ScrollArea>

            <footer className="border-t border-slate-800 p-4">
              <div className="flex items-end gap-2">
                <textarea
                  value={aiQuestion}
                  onChange={(e) => setAiQuestion(e.target.value)}
                  onKeyDown={(e) => handleKeyDown(e, "ai")}
                  placeholder="Ask Wolf AI..."
                  className="flex-1 resize-none rounded-xl border border-slate-700 bg-slate-900 px-4 py-3 text-[13px] text-white placeholder:text-slate-500 focus:border-amber-500 focus:outline-none"
                  rows={2}
                />
                <button
                  type="button"
                  onClick={askAI}
                  disabled={aiLoading || !aiQuestion.trim()}
                  className="flex h-11 w-11 items-center justify-center rounded-xl bg-amber-500 text-white hover:bg-amber-400 disabled:opacity-50"
                >
                  {aiLoading ? <Loader2 className="h-5 w-5 animate-spin" /> : <Send className="h-5 w-5" />}
                </button>
              </div>
            </footer>
          </TabsContent>

          {/* Chat Tab */}
          <TabsContent value="chat" className="flex-1 flex flex-col mt-0 data-[state=inactive]:hidden">
            {!activeConversation && !showNewChat ? (
              // Conversation List
              <ScrollArea className="flex-1 px-4 py-4">
                <button
                  onClick={() => setShowNewChat(true)}
                  className="mb-4 w-full rounded-xl border border-dashed border-slate-700 bg-slate-900/50 p-4 text-center text-sm text-slate-400 hover:border-amber-500/50 hover:text-amber-400"
                >
                  + New Conversation
                </button>

                {conversations.length === 0 ? (
                  <div className="text-center py-8 text-slate-500 text-sm">
                    No conversations yet
                  </div>
                ) : (
                  <div className="space-y-2">
                    {conversations.map((conv) => (
                      <button
                        key={conv.id}
                        onClick={() => loadMessages(conv.id)}
                        className="w-full rounded-xl bg-slate-900 border border-slate-800 p-3 text-left hover:border-amber-500/50 transition-colors"
                      >
                        <div className="flex items-center justify-between mb-1">
                          <Badge variant="outline" className="text-[10px] border-slate-700">
                            {getDepartmentLabel(conv.department)}
                          </Badge>
                          <span className="text-[10px] text-slate-500">
                            {new Date(conv.updated_at).toLocaleDateString()}
                          </span>
                        </div>
                        <p className="text-xs text-slate-300 truncate">
                          {conv.chat_messages?.[conv.chat_messages.length - 1]?.body || "No messages yet"}
                        </p>
                      </button>
                    ))}
                  </div>
                )}
              </ScrollArea>
            ) : showNewChat ? (
              // New Conversation - Department Selection
              <ScrollArea className="flex-1 px-4 py-4">
                <button
                  onClick={() => setShowNewChat(false)}
                  className="mb-4 text-xs text-slate-400 hover:text-white"
                >
                  ← Back to conversations
                </button>
                
                <h3 className="text-sm font-medium text-white mb-4">What do you want to talk about?</h3>
                
                <div className="space-y-2">
                  {DEPARTMENTS.map((dept) => (
                    <button
                      key={dept.value}
                      onClick={() => createConversation(dept.value)}
                      disabled={chatLoading}
                      className="w-full rounded-xl bg-slate-900 border border-slate-800 p-4 text-left hover:border-amber-500/50 transition-colors flex items-center gap-3"
                    >
                      <span className="text-xl">{dept.icon}</span>
                      <span className="text-sm text-white">{dept.label}</span>
                    </button>
                  ))}
                </div>
              </ScrollArea>
            ) : (
              // Active Conversation
              <>
                <div className="px-4 py-2 border-b border-slate-800">
                  <button
                    onClick={() => {
                      setActiveConversation(null);
                      setChatMessages([]);
                    }}
                    className="text-xs text-slate-400 hover:text-white"
                  >
                    ← Back to conversations
                  </button>
                </div>

                <ScrollArea className="flex-1 px-4 py-4">
                  <div className="space-y-4">
                    {chatMessages.map((msg) => {
                      const isMe = msg.sender_id === userId;
                      return (
                        <div key={msg.id} className={cn("flex", isMe ? "justify-end" : "justify-start")}>
                          <div className={cn(
                            "max-w-[85%] rounded-2xl px-4 py-2.5",
                            isMe ? "bg-amber-500 text-white" : "bg-slate-800 text-slate-100"
                          )}>
                            {!isMe && (
                              <p className="text-[10px] text-amber-400/80 mb-1 font-medium">
                                {getDisplayName(msg.sender_role)}
                              </p>
                            )}
                            <p className="text-[13px] whitespace-pre-wrap">{msg.body}</p>
                          </div>
                        </div>
                      );
                    })}
                    <div ref={messagesEndRef} />
                  </div>
                </ScrollArea>

                <footer className="border-t border-slate-800 p-4">
                  <div className="flex items-end gap-2">
                    <textarea
                      value={chatInput}
                      onChange={(e) => setChatInput(e.target.value)}
                      onKeyDown={(e) => handleKeyDown(e, "chat")}
                      placeholder="Type your message..."
                      className="flex-1 resize-none rounded-xl border border-slate-700 bg-slate-900 px-4 py-3 text-[13px] text-white placeholder:text-slate-500 focus:border-amber-500 focus:outline-none"
                      rows={2}
                    />
                    <button
                      type="button"
                      onClick={sendChatMessage}
                      disabled={chatLoading || !chatInput.trim()}
                      className="flex h-11 w-11 items-center justify-center rounded-xl bg-amber-500 text-white hover:bg-amber-400 disabled:opacity-50"
                    >
                      {chatLoading ? <Loader2 className="h-5 w-5 animate-spin" /> : <Send className="h-5 w-5" />}
                    </button>
                  </div>
                </footer>
              </>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};
