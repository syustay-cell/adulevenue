import { useSessionTimeout } from "@/hooks/useSessionTimeout";

/**
 * SessionTimeoutProvider
 * 
 * Activates the session timeout logic globally.
 * Monitors user activity and auto-logs out on idle timeout or max session duration.
 * Must be placed inside Router context (uses useNavigate).
 */
export function SessionTimeoutProvider({ children }: { children: React.ReactNode }) {
  // Activate timeout monitoring
  useSessionTimeout();
  
  return <>{children}</>;
}
