// src/components/ProtectedRoute.tsx
import React, { useEffect, useState } from "react";
import { Navigate, useLocation } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { hasRoleOrHigher, getHighestRole, isInternalRole } from "@/lib/roleHierarchy";
import type { AppRole } from "@/lib/permissions";
import { AuthGateError } from "@/components/auth/AuthGateError";

interface ProtectedRouteProps {
  children: React.ReactNode;
  minRole?: AppRole;
  requireAdmin?: boolean;   // legacy support
  requireInternal?: boolean;
}

export const ProtectedRoute: React.FC<ProtectedRouteProps> = ({
  children,
  minRole,
  requireAdmin = false,
  requireInternal = false,
}) => {
  const location = useLocation();
  const [loading, setLoading] = useState(true);
  const [roles, setRoles] = useState<string[]>([]);
  const [hasSession, setHasSession] = useState<boolean | null>(null);
  const [email, setEmail] = useState<string | null>(null);
  const [authError, setAuthError] = useState<string | null>(null);

  // Resolve effective minRole (support old requireAdmin usage)
  const effectiveMinRole: AppRole = (minRole || (requireAdmin ? "admin" : "user")) as AppRole;

  useEffect(() => {
    let cancelled = false;

    (async () => {
      try {
        // 1) Get current session
        const {
          data: { session },
          error: sessionError,
        } = await supabase.auth.getSession();

        if (cancelled) return;

        if (sessionError) {
          console.error("ProtectedRoute: session error", sessionError);
          setAuthError(sessionError.message);
          setHasSession(false);
          setRoles([]);
          setEmail(null);
          setLoading(false);
          return;
        }
        if (!session) {
          console.log("ProtectedRoute: no session", { path: location.pathname });
          setAuthError(null);
          setHasSession(false);
          setRoles([]);
          setEmail(null);
          setLoading(false);
          return;
        }

        setHasSession(true);
        setEmail(session.user.email ?? null);

        // 2) Load all APPROVED roles for this user
        const { data: userRoles, error: rolesError } = await supabase
          .from("user_roles")
          .select("role, approved")
          .eq("user_id", session.user.id)
          .eq("approved", true);

        if (cancelled) return;

        if (rolesError) {
          console.error("ProtectedRoute: error fetching roles", rolesError);
          setAuthError(rolesError.message);
          setRoles([]);
        } else {
          setAuthError(null);
          const roleStrings = (userRoles ?? []).map((r: any) => r.role as string);
          console.log("ProtectedRoute: fetched roles", {
            email: session.user.email,
            roles: roleStrings,
            path: location.pathname,
          });
          setRoles(roleStrings);
        }
      } catch (err) {
        if (!cancelled) {
          console.error("ProtectedRoute: fatal error", err);
          setAuthError(err instanceof Error ? err.message : "Unknown error");
          setHasSession(false);
          setRoles([]);
        }
      } finally {
        if (!cancelled) {
          setLoading(false);
        }
      }
    })();

    return () => {
      cancelled = true;
    };
  }, [location.pathname]);

  // 3) While loading, DO NOT deny access yet
  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-sm text-muted-foreground">Loading…</div>
      </div>
    );
  }

  // 3b) Any auth/config error -> show inline persistent error (no redirect)
  if (authError) {
    return <AuthGateError message={authError} />;
  }

  // 4) No session -> send to /auth
  if (!hasSession) {
    return <Navigate to="/auth" state={{ from: location }} replace />;
  }

  // 5) Session exists but roles array is still empty
  // This can happen if the roles query is slow or failed.
  // DO NOT hard-deny here; show nothing and let it re-run.
  if (hasSession && roles.length === 0) {
    console.log("ProtectedRoute: session ok but roles empty, holding access", {
      email,
      path: location.pathname,
    });
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-sm text-muted-foreground">Loading permissions…</div>
      </div>
    );
  }

  // 6) Access check using FULL role list (owner/admin/worker/underwriter, etc.)
  const canAccess = hasRoleOrHigher(roles, effectiveMinRole);
  const highest = getHighestRole(roles);
  const meetsInternalReq = !requireInternal || isInternalRole(highest);

  console.log("ProtectedRoute: access check", {
    email,
    path: location.pathname,
    roles,
    minRole: effectiveMinRole,
    canAccess,
    meetsInternalReq,
  });

  if (!canAccess || !meetsInternalReq) {
    return (
      <div className="flex flex-col items-center justify-center py-20 text-center text-sm text-slate-400">
        <h1 className="text-lg font-semibold text-slate-100 mb-2">Access Denied</h1>
        <p className="mb-1">You don't have permission to view this page.</p>
        <p className="text-xs text-slate-500">
          Required: <code>{effectiveMinRole}</code> or higher. Roles:{" "}
          <code>{roles.join(", ") || "none"}</code>
        </p>
      </div>
    );
  }

  // 7) All good -> render the protected content
  return <>{children}</>;
};

export default ProtectedRoute;
