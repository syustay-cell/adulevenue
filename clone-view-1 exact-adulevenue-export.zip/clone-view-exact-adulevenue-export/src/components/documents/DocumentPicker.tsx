import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { Search, FileText, FileCheck, Check } from "lucide-react";

interface WolfDocument {
  id: string;
  file_name: string;
  storage_path: string;
  file_type: string;
  category: string;
  tags: string[];
  is_template: boolean;
  description: string | null;
}

interface DocumentPickerProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSelect: (doc: WolfDocument) => void;
  selectedIds?: string[];
  categoryFilter?: string;
  templateOnly?: boolean;
}

const CATEGORIES = [
  { value: 'all', label: 'All Categories' },
  { value: 'contract', label: 'Contracts' },
  { value: 'template', label: 'Templates' },
  { value: 'credit_letter', label: 'Credit Letters' },
  { value: 'iso_agreement', label: 'ISO Agreements' },
  { value: 'marketing_asset', label: 'Marketing Assets' },
  { value: 'other', label: 'Other' }
];

export function DocumentPicker({ 
  open, 
  onOpenChange, 
  onSelect,
  selectedIds = [],
  categoryFilter: defaultCategory,
  templateOnly = false
}: DocumentPickerProps) {
  const [documents, setDocuments] = useState<WolfDocument[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState(defaultCategory || "all");

  useEffect(() => {
    if (open) {
      fetchDocuments();
    }
  }, [open]);

  const fetchDocuments = async () => {
    setLoading(true);
    try {
      let query = (supabase.from('wolf_documents' as any) as any)
        .select('id, file_name, storage_path, file_type, category, tags, is_template, description')
        .eq('is_active', true)
        .order('created_at', { ascending: false });

      if (templateOnly) {
        query = query.eq('is_template', true);
      }

      const { data, error } = await query;
      if (error) throw error;
      setDocuments((data as WolfDocument[]) || []);
    } catch (err) {
      console.error('Failed to fetch documents:', err);
    } finally {
      setLoading(false);
    }
  };

  const filteredDocs = documents.filter(doc => {
    if (category !== 'all' && doc.category !== category) return false;
    if (search && !doc.file_name.toLowerCase().includes(search.toLowerCase())) return false;
    return true;
  });

  const isSelected = (id: string) => selectedIds.includes(id);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <FileText className="h-5 w-5" />
            Select Document
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          {/* Filters */}
          <div className="flex gap-2">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search documents..."
                className="pl-9"
              />
            </div>
            <Select value={category} onValueChange={setCategory}>
              <SelectTrigger className="w-[140px]">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {CATEGORIES.map(c => (
                  <SelectItem key={c.value} value={c.value}>{c.label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Document List */}
          <ScrollArea className="h-[300px] border rounded-md">
            {loading ? (
              <div className="flex justify-center py-8">
                <div className="animate-spin h-6 w-6 border-2 border-primary border-t-transparent rounded-full" />
              </div>
            ) : filteredDocs.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                <FileText className="h-8 w-8 mx-auto mb-2 opacity-50" />
                <p className="text-sm">No documents found</p>
              </div>
            ) : (
              <div className="divide-y">
                {filteredDocs.map((doc) => (
                  <button
                    key={doc.id}
                    onClick={() => onSelect(doc)}
                    className={`w-full text-left px-4 py-3 hover:bg-muted/50 transition-colors flex items-center gap-3 ${
                      isSelected(doc.id) ? 'bg-primary/10' : ''
                    }`}
                  >
                    <FileText className="h-5 w-5 text-muted-foreground shrink-0" />
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="font-medium truncate">{doc.file_name}</span>
                        {doc.is_template && (
                          <Badge variant="secondary" className="text-xs shrink-0">
                            <FileCheck className="h-3 w-3 mr-1" />
                            Template
                          </Badge>
                        )}
                      </div>
                      {doc.description && (
                        <p className="text-xs text-muted-foreground truncate">{doc.description}</p>
                      )}
                      {doc.tags.length > 0 && (
                        <div className="flex gap-1 mt-1">
                          {doc.tags.slice(0, 3).map((tag, i) => (
                            <Badge key={i} variant="outline" className="text-xs">
                              {tag}
                            </Badge>
                          ))}
                        </div>
                      )}
                    </div>
                    {isSelected(doc.id) && (
                      <Check className="h-5 w-5 text-primary shrink-0" />
                    )}
                  </button>
                ))}
              </div>
            )}
          </ScrollArea>
        </div>
      </DialogContent>
    </Dialog>
  );
}
