import { cn } from "@/lib/utils";

type WolfStatProps = {
  label: string;
  value: string | number;
  subtext?: string;
  className?: string;
};

export function WolfStat({ label, value, subtext, className }: WolfStatProps) {
  return (
    <div
      className={cn(
        "stat rounded-2xl border border-transparent bg-gradient-to-br from-slate-900/5 to-slate-900/0 p-4 dark:from-slate-50/5",
        className
      )}
    >
      <p className="text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">
        {label}
      </p>
      <p className="text-2xl font-semibold text-foreground">{value}</p>
      {subtext && (
        <p className="text-xs text-muted-foreground mt-1">{subtext}</p>
      )}
    </div>
  );
}
