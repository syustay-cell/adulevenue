import React from "react";
import { Volume2, VolumeX, Pause, Loader2 } from "lucide-react";
import { useTextToSpeech } from "@/hooks/useTextToSpeech";
import { cn } from "@/lib/utils";

type ListenButtonProps = {
  text: string;
  label?: string;
  size?: "sm" | "md";
  className?: string;
};

export function ListenButton({
  text,
  label,
  size = "sm",
  className,
}: ListenButtonProps) {
  const { speaking, paused, loading, isSupported, toggle, stop } = useTextToSpeech();

  if (!isSupported) return null;

  const isActive = speaking && !paused;

  const handleClick = () => {
    if (loading) return;
    if (speaking && !paused) {
      stop();
    } else {
      toggle(text);
    }
  };

  const iconSize = size === "sm" ? "h-3.5 w-3.5" : "h-4 w-4";

  return (
    <button
      type="button"
      onClick={handleClick}
      disabled={loading}
      aria-label={loading ? "Loading voice..." : isActive ? "Stop listening" : "Listen to this section"}
      className={cn(
        "inline-flex items-center gap-1.5 text-muted-foreground hover:text-foreground transition-colors",
        isActive && "text-primary",
        loading && "opacity-50 cursor-wait",
        className
      )}
    >
      {loading ? (
        <Loader2 className={cn(iconSize, "animate-spin")} />
      ) : isActive ? (
        <VolumeX className={iconSize} />
      ) : paused ? (
        <Pause className={iconSize} />
      ) : (
        <Volume2 className={iconSize} />
      )}
      {label && (
        <span className={cn("text-xs", size === "sm" && "text-[11px]")}>
          {loading ? "Loading..." : label}
        </span>
      )}
    </button>
  );
}

type ListenRowButtonProps = {
  text: string;
  className?: string;
};

export function ListenRowButton({ text, className }: ListenRowButtonProps) {
  const { speaking, paused, loading, isSupported, toggle, stop } = useTextToSpeech();

  if (!isSupported) return null;

  const isActive = speaking && !paused;

  const handleClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (loading) return;
    if (speaking && !paused) {
      stop();
    } else {
      toggle(text);
    }
  };

  return (
    <button
      type="button"
      onClick={handleClick}
      disabled={loading}
      aria-label={isActive ? "Stop" : "Listen"}
      className={cn(
        "p-1 rounded hover:bg-muted/50 transition-colors text-muted-foreground hover:text-foreground opacity-50 hover:opacity-100",
        isActive && "text-primary opacity-100",
        loading && "cursor-wait",
        className
      )}
    >
      {loading ? (
        <Loader2 className="h-3 w-3 animate-spin" />
      ) : isActive ? (
        <VolumeX className="h-3 w-3" />
      ) : (
        <Volume2 className="h-3 w-3" />
      )}
    </button>
  );
}
