import { cn } from "@/lib/utils";
import { HTMLAttributes } from "react";

export function WolfTable({
  className,
  ...props
}: HTMLAttributes<HTMLTableElement>) {
  return (
    <table
      {...props}
      className={cn(
        "table-basic w-full border-collapse text-sm text-foreground [&_th]:text-left [&_th]:text-[11px] [&_th]:uppercase [&_th]:tracking-wide [&_th]:text-muted-foreground",
        className
      )}
    />
  );
}
