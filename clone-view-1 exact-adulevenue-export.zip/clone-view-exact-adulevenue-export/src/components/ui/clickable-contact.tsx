import { Phone, Mail } from "lucide-react";
import { useUserRoles } from "@/hooks/useUserRoles";
import { canViewRawPii, maskEmail, maskPhone } from "@/lib/masking";
import type { AppRole } from "@/lib/permissions";

interface ClickablePhoneProps {
  phone: string;
  displayText?: string;
  className?: string;
}

export const ClickablePhone = ({ phone, displayText, className = "" }: ClickablePhoneProps) => {
  if (!phone) return <span className="text-muted-foreground">-</span>;
  const { roles } = useUserRoles();
  const canViewPii = canViewRawPii((roles as AppRole[]) || []);
  
  return (
    canViewPii ? (
      <a 
        href={`tel:${phone}`}
        onClick={(event) => {
          // Prevent parent click handlers (like row navigation) from hijacking the call action
          event.stopPropagation();
        }}
        className={`inline-flex items-center gap-2 text-primary hover:text-primary/80 font-semibold bg-primary/10 hover:bg-primary/20 px-3 py-2 rounded-full transition-all hover:scale-105 active:scale-95 min-h-[44px] sm:min-h-[36px] ${className}`}
      >
        <Phone className="h-4 w-4" />
        <span className="text-sm">{displayText || "Call Client"}</span>
      </a>
    ) : (
      <span
        className={`inline-flex items-center gap-2 text-muted-foreground font-semibold bg-muted/50 px-3 py-2 rounded-full min-h-[44px] sm:min-h-[36px] ${className}`}
      >
        <Phone className="h-4 w-4" />
        <span className="text-sm">{maskPhone(phone)}</span>
      </span>
    )
  );
};

interface ClickableEmailProps {
  email: string;
  subject?: string;
  className?: string;
}

export const ClickableEmail = ({ email, subject, className = "" }: ClickableEmailProps) => {
  if (!email) return <span className="text-muted-foreground">-</span>;
  const { roles } = useUserRoles();
  const canViewPii = canViewRawPii((roles as AppRole[]) || []);
  
  const mailtoLink = subject 
    ? `mailto:${email}?subject=${encodeURIComponent(subject)}`
    : `mailto:${email}`;
  
  return (
    canViewPii ? (
      <a 
        href={mailtoLink}
        className={`inline-flex items-center gap-2 text-primary hover:text-primary/80 font-semibold bg-primary/10 hover:bg-primary/20 px-3 py-2 rounded-full transition-all hover:scale-105 active:scale-95 min-h-[44px] sm:min-h-[36px] ${className}`}
      >
        <Mail className="h-4 w-4" />
        <span className="text-sm">{email}</span>
      </a>
    ) : (
      <span
        className={`inline-flex items-center gap-2 text-muted-foreground font-semibold bg-muted/50 px-3 py-2 rounded-full min-h-[44px] sm:min-h-[36px] ${className}`}
      >
        <Mail className="h-4 w-4" />
        <span className="text-sm">{maskEmail(email)}</span>
      </span>
    )
  );
};
