import React from "react";
import { useAutoTts } from "@/context/AutoTtsProvider";
import { Volume2 } from "lucide-react";
import { cn } from "@/lib/utils";

type AutoListenToggleProps = {
  className?: string;
};

export function AutoListenToggle({ className }: AutoListenToggleProps) {
  const { enabled, setEnabled, loading } = useAutoTts();

  if (loading) return null;

  return (
    <label
      className={cn(
        "inline-flex items-center gap-2 text-xs cursor-pointer select-none",
        className
      )}
    >
      <span
        className={cn(
          "relative inline-flex h-5 w-9 items-center rounded-full transition-colors",
          enabled ? "bg-primary" : "bg-muted"
        )}
      >
        <input
          type="checkbox"
          checked={enabled}
          onChange={(e) => setEnabled(e.target.checked)}
          className="sr-only"
        />
        <span
          className={cn(
            "inline-block h-4 w-4 transform rounded-full bg-background shadow transition-transform",
            enabled ? "translate-x-4" : "translate-x-0.5"
          )}
        />
      </span>
      <Volume2 className="h-3.5 w-3.5 text-muted-foreground" />
      <span className="text-muted-foreground">Auto-listen</span>
    </label>
  );
}
