import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { RefreshCw, DollarSign, Zap, TrendingUp, AlertTriangle, Cloud, Cpu } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { AI_PRICING, estimateCost } from "@/lib/aiPricing";

interface CostSummary {
  ok: boolean;
  provider: string;
  current_month: {
    cost_usd: number;
    tokens: number;
    calls: number;
    start_date: string;
  };
  last_month: {
    cost_usd: number;
  };
  budget: {
    monthly_budget_usd: number;
    warn_at_usd: number;
    critical_at_usd: number;
    status: 'ok' | 'warning' | 'critical';
    remaining_usd: number;
    percent_used: number;
  };
  by_feature: Array<{ feature: string; calls: number; tokens: number; cost: number; provider?: string }>;
  by_brand: Array<{ brand: string; calls: number; cost: number }>;
}

interface ProviderSummary {
  provider: string;
  name: string;
  calls: number;
  cost: number;
  tokens: number;
}

export function AICostPanel() {
  const [summary, setSummary] = useState<CostSummary | null>(null);
  const [providerStats, setProviderStats] = useState<ProviderSummary[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState("overview");

  const fetchSummary = async () => {
    setLoading(true);
    try {
      // Fetch from both providers in parallel
      const [gatewayRes, openaiRes] = await Promise.all([
        supabase.functions.invoke('wf-ai-cost-summary', { body: { provider: 'gateway' } }),
        supabase.functions.invoke('wf-ai-cost-summary', { body: { provider: 'openai' } }).catch(() => null)
      ]);

      if (gatewayRes.error) throw gatewayRes.error;
      setSummary(gatewayRes.data);

      // Build provider comparison stats
      const stats: ProviderSummary[] = [];
      
      if (gatewayRes.data?.ok) {
        stats.push({
          provider: 'gateway',
          name: 'AI Gateway',
          calls: gatewayRes.data.current_month.calls || 0,
          cost: gatewayRes.data.current_month.cost_usd || 0,
          tokens: gatewayRes.data.current_month.tokens || 0,
        });
      }
      
      if (openaiRes?.data?.ok) {
        stats.push({
          provider: 'openai',
          name: 'OpenAI',
          calls: openaiRes.data.current_month.calls || 0,
          cost: openaiRes.data.current_month.cost_usd || 0,
          tokens: openaiRes.data.current_month.tokens || 0,
        });
      }

      setProviderStats(stats);
    } catch (err) {
      console.error('Failed to fetch cost summary:', err);
      toast.error('Failed to load AI cost summary');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchSummary();
  }, []);

  const totalCost = providerStats.reduce((sum, p) => sum + p.cost, 0);
  const totalCalls = providerStats.reduce((sum, p) => sum + p.calls, 0);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'critical': return 'bg-destructive text-destructive-foreground';
      case 'warning': return 'bg-yellow-500 text-white';
      default: return 'bg-green-500 text-white';
    }
  };

  const getStatusIcon = (status: string) => {
    if (status === 'critical' || status === 'warning') {
      return <AlertTriangle className="h-4 w-4" />;
    }
    return <Zap className="h-4 w-4" />;
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center p-8">
        <RefreshCw className="h-6 w-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (!summary) {
    return (
      <Card>
        <CardContent className="p-6">
          <p className="text-muted-foreground">Unable to load cost data</p>
          <Button onClick={fetchSummary} variant="outline" className="mt-4">
            <RefreshCw className="h-4 w-4 mr-2" /> Retry
          </Button>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header with Refresh */}
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold">AI Cost Analytics (V23)</h3>
        <Button onClick={fetchSummary} variant="outline" size="sm">
          <RefreshCw className="h-4 w-4 mr-2" /> Refresh
        </Button>
      </div>

      {/* Provider Comparison Cards */}
      {providerStats.length > 0 && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {/* Total */}
          <Card className="border-2 border-primary/20">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                <DollarSign className="h-4 w-4" /> Total (All Providers)
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">${totalCost.toFixed(2)}</div>
              <p className="text-xs text-muted-foreground">{totalCalls} total calls</p>
            </CardContent>
          </Card>
          
          {/* AI Gateway */}
          {providerStats.find(p => p.provider === 'gateway') && (
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                  <Cloud className="h-4 w-4 text-blue-500" /> AI Gateway
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-blue-600">
                  ${providerStats.find(p => p.provider === 'gateway')?.cost.toFixed(2)}
                </div>
                <p className="text-xs text-muted-foreground">
                  {providerStats.find(p => p.provider === 'gateway')?.calls} calls
                </p>
              </CardContent>
            </Card>
          )}
          
          {/* OpenAI */}
          {providerStats.find(p => p.provider === 'openai') && (
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                  <Cpu className="h-4 w-4 text-green-500" /> OpenAI
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-green-600">
                  ${providerStats.find(p => p.provider === 'openai')?.cost.toFixed(2)}
                </div>
                <p className="text-xs text-muted-foreground">
                  {providerStats.find(p => p.provider === 'openai')?.calls} calls
                </p>
              </CardContent>
            </Card>
          )}
        </div>
      )}

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
              <DollarSign className="h-4 w-4" /> This Month
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">${summary.current_month.cost_usd.toFixed(2)}</div>
            <p className="text-xs text-muted-foreground">{summary.current_month.calls} calls</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
              <TrendingUp className="h-4 w-4" /> Last Month
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">${summary.last_month.cost_usd.toFixed(2)}</div>
            <p className="text-xs text-muted-foreground">comparison</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
              <Zap className="h-4 w-4" /> Tokens Used
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{summary.current_month.tokens.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground">estimated</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
              {getStatusIcon(summary.budget.status)} Budget Status
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Badge className={getStatusColor(summary.budget.status)}>
              {summary.budget.status.toUpperCase()}
            </Badge>
            <p className="text-xs text-muted-foreground mt-1">
              ${summary.budget.remaining_usd.toFixed(2)} remaining
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Budget Progress */}
      <Card>
        <CardHeader>
          <CardTitle className="text-sm font-medium">Monthly Budget Progress</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span>${summary.current_month.cost_usd.toFixed(2)} used</span>
              <span>${summary.budget.monthly_budget_usd.toFixed(2)} budget</span>
            </div>
            <Progress 
              value={Math.min(summary.budget.percent_used, 100)} 
              className={summary.budget.status === 'critical' ? 'bg-destructive/20' : summary.budget.status === 'warning' ? 'bg-yellow-500/20' : ''}
            />
            <div className="flex justify-between text-xs text-muted-foreground">
              <span>Warn at ${summary.budget.warn_at_usd}</span>
              <span>Critical at ${summary.budget.critical_at_usd}</span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Cost by Feature */}
      <Card>
        <CardHeader>
          <CardTitle className="text-sm font-medium">Cost by Feature (This Month)</CardTitle>
        </CardHeader>
        <CardContent>
          {summary.by_feature.length === 0 ? (
            <p className="text-muted-foreground text-sm">No usage data yet</p>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Feature</TableHead>
                  <TableHead className="text-right">Calls</TableHead>
                  <TableHead className="text-right">Tokens</TableHead>
                  <TableHead className="text-right">Cost</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {summary.by_feature.map((f) => (
                  <TableRow key={f.feature}>
                    <TableCell className="font-medium">{f.feature}</TableCell>
                    <TableCell className="text-right">{f.calls}</TableCell>
                    <TableCell className="text-right">{f.tokens.toLocaleString()}</TableCell>
                    <TableCell className="text-right">${f.cost.toFixed(4)}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      {/* Cost by Brand */}
      <Card>
        <CardHeader>
          <CardTitle className="text-sm font-medium">Cost by Brand (This Month)</CardTitle>
        </CardHeader>
        <CardContent>
          {summary.by_brand.length === 0 ? (
            <p className="text-muted-foreground text-sm">No usage data yet</p>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Brand</TableHead>
                  <TableHead className="text-right">Calls</TableHead>
                  <TableHead className="text-right">Cost</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {summary.by_brand.map((b) => (
                  <TableRow key={b.brand}>
                    <TableCell className="font-medium">{b.brand}</TableCell>
                    <TableCell className="text-right">{b.calls}</TableCell>
                    <TableCell className="text-right">${b.cost.toFixed(4)}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
