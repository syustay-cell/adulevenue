import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { AlertTriangle, XCircle, RefreshCw, ExternalLink, BarChart3 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
interface CreditStatus {
  ok: boolean;
  source: string;
  status: 'ok' | 'warning' | 'critical' | 'halt';
  consecutive_errors: number;
  last_error_at: string | null;
  last_success_at: string | null;
  auto_pause_heavy: boolean;
  message: string;
}

export function CreditMonitorBanner() {
  const navigate = useNavigate();
  const [status, setStatus] = useState<CreditStatus | null>(null);
  const [loading, setLoading] = useState(true);
  const [resetting, setResetting] = useState(false);
  const fetchStatus = async () => {
    try {
      const { data, error } = await supabase.functions.invoke('wf-credit-monitor', {
        body: { action: 'check' }
      });
      
      if (error) throw error;
      setStatus(data);
    } catch (err) {
      console.error('Failed to fetch credit status:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleReset = async () => {
    setResetting(true);
    try {
      const { data, error } = await supabase.functions.invoke('wf-credit-monitor', {
        body: { action: 'reset' }
      });
      
      if (error) throw error;
      setStatus(data);
      toast.success('Credit status reset - AI engines resumed');
    } catch (err) {
      toast.error('Failed to reset credit status');
    } finally {
      setResetting(false);
    }
  };

  useEffect(() => {
    fetchStatus();
    // Refresh every 2 minutes
    const interval = setInterval(fetchStatus, 120000);
    return () => clearInterval(interval);
  }, []);

  if (loading || !status || status.status === 'ok') {
    return null;
  }

  const getVariant = () => {
    if (status.status === 'halt') return 'destructive';
    if (status.status === 'critical') return 'destructive';
    return 'default';
  };

  const getIcon = () => {
    if (status.status === 'halt') return <XCircle className="h-5 w-5" />;
    if (status.status === 'critical') return <AlertTriangle className="h-5 w-5" />;
    return <AlertTriangle className="h-5 w-5" />;
  };

  const getTitle = () => {
    if (status.status === 'halt') return '🚨 AI Engines Paused';
    if (status.status === 'critical') return '🔴 AI Credits Critical';
    return '🟡 AI Credits Low';
  };

  return (
    <Alert variant={getVariant()} className="mb-4">
      {getIcon()}
      <AlertTitle className="flex items-center gap-2">
        {getTitle()}
        {status.consecutive_errors > 0 && (
          <span className="text-xs font-normal opacity-70">
            ({status.consecutive_errors} consecutive errors)
          </span>
        )}
      </AlertTitle>
      <AlertDescription className="mt-2">
        <p className="mb-3">{status.message}</p>
        <div className="flex flex-wrap gap-2">
          <Button
            size="sm"
            variant="outline"
            onClick={() => navigate('/wolf-motherboard?tab=ai-cost')}
          >
            <BarChart3 className="h-4 w-4 mr-1" />
            View AI Cost Analytics
          </Button>
          <Button
            size="sm"
            variant="outline"
            onClick={() => window.open('https://wolf-fund.com', '_blank')}
          >
            <ExternalLink className="h-4 w-4 mr-1" />
            Account & Billing
          </Button>
          <Button
            size="sm"
            variant="secondary"
            onClick={handleReset}
            disabled={resetting}
          >
            <RefreshCw className={`h-4 w-4 mr-1 ${resetting ? 'animate-spin' : ''}`} />
            {resetting ? 'Resetting...' : 'Reset Status'}
          </Button>
          <Button
            size="sm"
            variant="ghost"
            onClick={fetchStatus}
          >
            <RefreshCw className="h-4 w-4 mr-1" />
            Refresh
          </Button>
        </div>
        {status.last_error_at && (
          <p className="text-xs opacity-60 mt-2">
            Last error: {new Date(status.last_error_at).toLocaleString()}
          </p>
        )}
      </AlertDescription>
    </Alert>
  );
}
