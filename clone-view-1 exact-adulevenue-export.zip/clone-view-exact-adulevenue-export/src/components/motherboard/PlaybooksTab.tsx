import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { ScrollArea } from "@/components/ui/scroll-area";
import { toast } from "sonner";
import {
  CheckCircle2,
  XCircle,
  AlertTriangle,
  BookOpen,
  FileText,
  Route,
  Zap,
  ExternalLink,
  Check,
  X,
  RefreshCw,
} from "lucide-react";
import {
  fetchDriftItems,
  resolveDriftItem,
  calculatePlaybookCompliance,
  type PlaybookDriftItem,
  type PlaybookCompliance,
} from "@/core/playbook";

interface PlaybooksTabProps {
  tenantId: string;
}

export function PlaybooksTab({ tenantId }: PlaybooksTabProps) {
  const queryClient = useQueryClient();
  const [selectedBrand, setSelectedBrand] = useState<string>("all");

  // Fetch compliance data
  const { data: compliance = [], isLoading: complianceLoading } = useQuery({
    queryKey: ["playbook-compliance", tenantId],
    queryFn: () => calculatePlaybookCompliance(tenantId),
    enabled: !!tenantId,
  });

  // Fetch drift items
  const { data: driftItems = [], isLoading: driftLoading } = useQuery({
    queryKey: ["playbook-drift", tenantId, selectedBrand],
    queryFn: () =>
      fetchDriftItems(tenantId, {
        brand_key: selectedBrand === "all" ? undefined : selectedBrand,
        status: "detected",
      }),
    enabled: !!tenantId,
  });

  // Resolve drift mutation
  const resolveMutation = useMutation({
    mutationFn: ({ id, action }: { id: string; action: "approve" | "ignore" }) =>
      resolveDriftItem(id, action),
    onSuccess: (_, { action }) => {
      toast.success(`Drift item ${action === "approve" ? "approved and added to playbook" : "ignored"}`);
      queryClient.invalidateQueries({ queryKey: ["playbook-drift"] });
      queryClient.invalidateQueries({ queryKey: ["playbook-compliance"] });
    },
    onError: (error: Error) => {
      toast.error(`Failed to resolve drift item: ${error.message}`);
    },
  });

  const getComplianceColor = (percentage: number) => {
    if (percentage >= 90) return "text-green-500";
    if (percentage >= 70) return "text-yellow-500";
    return "text-red-500";
  };

  const getComplianceBadge = (percentage: number) => {
    if (percentage >= 90) return <Badge className="bg-green-500/20 text-green-500">Compliant</Badge>;
    if (percentage >= 70) return <Badge className="bg-yellow-500/20 text-yellow-500">Partial</Badge>;
    return <Badge className="bg-red-500/20 text-red-500">Gaps Found</Badge>;
  };

  const getDriftTypeIcon = (type: string) => {
    switch (type) {
      case "usage_event":
        return <Zap className="h-4 w-4" />;
      case "ip_asset":
        return <FileText className="h-4 w-4" />;
      case "ui_route":
        return <Route className="h-4 w-4" />;
      case "workflow":
        return <BookOpen className="h-4 w-4" />;
      default:
        return <AlertTriangle className="h-4 w-4" />;
    }
  };

  const pendingDriftCount = driftItems.filter((d) => d.status === "detected").length;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-foreground">Playbook Compliance</h2>
          <p className="text-muted-foreground">
            Monitor brand playbook adherence and review out-of-playbook items
          </p>
        </div>
        {pendingDriftCount > 0 && (
          <Badge variant="destructive" className="text-sm">
            {pendingDriftCount} items need review
          </Badge>
        )}
      </div>

      <Tabs defaultValue="compliance" className="w-full">
        <TabsList>
          <TabsTrigger value="compliance">Brand Compliance</TabsTrigger>
          <TabsTrigger value="drift">
            Out-of-Playbook
            {pendingDriftCount > 0 && (
              <Badge variant="secondary" className="ml-2">
                {pendingDriftCount}
              </Badge>
            )}
          </TabsTrigger>
          <TabsTrigger value="sops">SOP Links</TabsTrigger>
        </TabsList>

        {/* Compliance Tab */}
        <TabsContent value="compliance" className="space-y-4">
          {complianceLoading ? (
            <div className="text-center py-8 text-muted-foreground">Loading compliance data...</div>
          ) : compliance.length === 0 ? (
            <Card>
              <CardContent className="py-8 text-center text-muted-foreground">
                No brand playbooks configured. Add playbooks to wolf_master_config.
              </CardContent>
            </Card>
          ) : (
            <div className="grid gap-4 md:grid-cols-2">
              {compliance.map((brand) => (
                <Card key={brand.brand_key}>
                  <CardHeader className="pb-2">
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-lg">{brand.label}</CardTitle>
                      {getComplianceBadge(brand.overall_compliance)}
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {/* Overall Progress */}
                    <div className="space-y-2">
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-muted-foreground">Overall Compliance</span>
                        <span className={getComplianceColor(brand.overall_compliance)}>
                          {brand.overall_compliance}%
                        </span>
                      </div>
                      <Progress value={brand.overall_compliance} className="h-2" />
                    </div>

                    {/* Breakdown */}
                    <div className="space-y-2 text-sm">
                      {/* Usage Events */}
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <Zap className="h-4 w-4 text-muted-foreground" />
                          <span>Usage Events</span>
                        </div>
                        <div className="flex items-center gap-2">
                          {brand.usage_events.found === brand.usage_events.expected ? (
                            <CheckCircle2 className="h-4 w-4 text-green-500" />
                          ) : (
                            <XCircle className="h-4 w-4 text-red-500" />
                          )}
                          <span>
                            {brand.usage_events.found}/{brand.usage_events.expected}
                          </span>
                        </div>
                      </div>
                      {brand.usage_events.missing.length > 0 && (
                        <div className="ml-6 text-xs text-muted-foreground">
                          Missing: {brand.usage_events.missing.join(", ")}
                        </div>
                      )}

                      {/* IP Assets */}
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <FileText className="h-4 w-4 text-muted-foreground" />
                          <span>IP Assets</span>
                        </div>
                        <div className="flex items-center gap-2">
                          {brand.ip_assets.found === brand.ip_assets.expected ? (
                            <CheckCircle2 className="h-4 w-4 text-green-500" />
                          ) : (
                            <XCircle className="h-4 w-4 text-red-500" />
                          )}
                          <span>
                            {brand.ip_assets.found}/{brand.ip_assets.expected}
                          </span>
                        </div>
                      </div>
                      {brand.ip_assets.missing.length > 0 && (
                        <div className="ml-6 text-xs text-muted-foreground">
                          Missing: {brand.ip_assets.missing.join(", ")}
                        </div>
                      )}

                      {/* UI Routes */}
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <Route className="h-4 w-4 text-muted-foreground" />
                          <span>UI Routes</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <CheckCircle2 className="h-4 w-4 text-green-500" />
                          <span>
                            {brand.ui_routes.found}/{brand.ui_routes.expected}
                          </span>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>

        {/* Drift Tab */}
        <TabsContent value="drift" className="space-y-4">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg">Out-of-Playbook Items</CardTitle>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => queryClient.invalidateQueries({ queryKey: ["playbook-drift"] })}
                >
                  <RefreshCw className="h-4 w-4 mr-2" />
                  Refresh
                </Button>
              </div>
              <p className="text-sm text-muted-foreground">
                Items detected in telemetry that are not in any brand playbook
              </p>
            </CardHeader>
            <CardContent>
              {driftLoading ? (
                <div className="text-center py-8 text-muted-foreground">Loading drift items...</div>
              ) : driftItems.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  <CheckCircle2 className="h-12 w-12 mx-auto mb-2 text-green-500" />
                  <p>No out-of-playbook items detected</p>
                  <p className="text-xs">All activity matches brand playbooks</p>
                </div>
              ) : (
                <ScrollArea className="h-[400px]">
                  <div className="space-y-3">
                    {driftItems.map((item) => (
                      <div
                        key={item.id}
                        className="flex items-center justify-between p-3 border rounded-lg bg-card"
                      >
                        <div className="flex items-center gap-3">
                          <div className="p-2 rounded-full bg-muted">
                            {getDriftTypeIcon(item.drift_type)}
                          </div>
                          <div>
                            <div className="font-medium">{item.item_label || item.item_key}</div>
                            <div className="text-xs text-muted-foreground flex items-center gap-2">
                              <Badge variant="outline" className="text-xs">
                                {item.brand_key}
                              </Badge>
                              <span>{item.drift_type.replace("_", " ")}</span>
                              <span>•</span>
                              <span>{new Date(item.detected_at).toLocaleDateString()}</span>
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <Button
                            size="sm"
                            variant="outline"
                            className="text-green-600 hover:text-green-700 hover:bg-green-50"
                            onClick={() => resolveMutation.mutate({ id: item.id, action: "approve" })}
                            disabled={resolveMutation.isPending}
                          >
                            <Check className="h-4 w-4 mr-1" />
                            Approve
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            className="text-muted-foreground hover:text-foreground"
                            onClick={() => resolveMutation.mutate({ id: item.id, action: "ignore" })}
                            disabled={resolveMutation.isPending}
                          >
                            <X className="h-4 w-4 mr-1" />
                            Ignore
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* SOPs Tab */}
        <TabsContent value="sops" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            {compliance.map((brand) => (
              <Card key={brand.brand_key}>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <BookOpen className="h-5 w-5" />
                    {brand.label} SOPs
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {Object.keys(brand.sop_links).length === 0 ? (
                    <p className="text-sm text-muted-foreground">No SOP links configured</p>
                  ) : (
                    <div className="space-y-2">
                      {Object.entries(brand.sop_links).map(([name, url]) => (
                        <a
                          key={name}
                          href={url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="flex items-center justify-between p-2 rounded-lg hover:bg-muted transition-colors"
                        >
                          <span className="text-sm">{name.replace(/_/g, " ")}</span>
                          <ExternalLink className="h-4 w-4 text-muted-foreground" />
                        </a>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
