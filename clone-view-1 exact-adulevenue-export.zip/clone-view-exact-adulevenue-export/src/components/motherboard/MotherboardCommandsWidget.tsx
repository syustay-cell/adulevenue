import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { WidgetCard } from "./WidgetCard";
import { cn } from "@/lib/utils";

type CommandRow = {
  id: string;
  command_type: string;
  status: "pending" | "running" | "success" | "failed" | "canceled";
  source: "manual" | "autopilot" | "night_agent";
  attempts: number;
  max_attempts: number;
  last_error: string | null;
  kill_switch: boolean;
  created_at: string;
  executed_at: string | null;
};

const statusStyles: Record<CommandRow["status"], string> = {
  pending: "bg-muted text-muted-foreground border-border",
  running: "bg-blue-500/10 text-blue-600 border-blue-500/30",
  success: "bg-emerald-500/10 text-emerald-600 border-emerald-500/30",
  failed: "bg-destructive/10 text-destructive border-destructive/30",
  canceled: "bg-amber-500/10 text-amber-600 border-amber-500/30",
};

export function MotherboardCommandsWidget() {
  const query = useQuery({
    queryKey: ["motherboard-commands", "latest"],
    queryFn: async () => {
      const { data, error } = await (supabase.from("motherboard_commands" as any) as any)
        .select("id, command_type, status, source, attempts, max_attempts, last_error, kill_switch, created_at, executed_at")
        .order("created_at", { ascending: false })
        .limit(50);

      if (error) throw error;
      return (data || []) as CommandRow[];
    },
    staleTime: 15_000,
  });

  const rows = query.data || [];

  const listenText = rows.length
    ? `Latest command: ${rows[0].command_type}. Status: ${rows[0].status}.`
    : "No recent Motherboard commands.";

  return (
    <WidgetCard
      title="Command Bus"
      subtitle="motherboard_commands (latest 50)"
      onRefresh={() => query.refetch()}
      listenText={listenText}
      isLoading={query.isLoading}
    >
      {!query.isLoading && rows.length === 0 && (
        <div className="text-xs text-muted-foreground">
          No commands yet. Insert one into <code>public.motherboard_commands</code> to begin.
        </div>
      )}

      {!query.isLoading && rows.length > 0 && (
        <div className="space-y-2 max-h-[280px] overflow-y-auto pr-1">
          {rows.map((c) => (
            <div key={c.id} className="rounded-lg border border-border/50 bg-muted/40 p-2.5">
              <div className="flex items-center justify-between gap-2">
                <div className="flex items-center gap-1.5 min-w-0">
                  <span
                    className={cn(
                      "inline-flex items-center rounded-full px-2 py-0.5 text-[10px] font-medium border",
                      statusStyles[c.status],
                    )}
                  >
                    {c.status}
                  </span>
                  <span className="text-[11px] font-medium truncate">{c.command_type}</span>
                  {c.kill_switch && (
                    <span className="text-[10px] text-amber-600 border border-amber-500/30 rounded-full px-2 py-0.5">
                      kill_switch
                    </span>
                  )}
                </div>
                <span className="text-[10px] text-muted-foreground whitespace-nowrap">
                  {new Date(c.created_at).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                </span>
              </div>

              <div className="mt-1 flex flex-wrap items-center gap-2 text-[10px] text-muted-foreground">
                <span>source: {c.source}</span>
                <span>
                  attempts: {c.attempts}/{c.max_attempts}
                </span>
                {c.executed_at && <span>executed: {new Date(c.executed_at).toLocaleString()}</span>}
              </div>

              {c.last_error && (
                <div className="mt-1 text-[11px] text-destructive line-clamp-2">
                  {c.last_error}
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </WidgetCard>
  );
}

