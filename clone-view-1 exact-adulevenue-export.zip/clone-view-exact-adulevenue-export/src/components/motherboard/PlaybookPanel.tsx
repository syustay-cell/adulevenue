// src/components/motherboard/PlaybookPanel.tsx

import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { formatDistanceToNow } from "date-fns";
import { useTenant } from "@/hooks/useTenant";
import { toast } from "sonner";
import {
  getPlaybooks,
  getPlaybookRuns,
  runPlaybookManually,
  togglePlaybookEnabled,
} from "@/lib/playbookActions";
import type { WfPlaybook, WfPlaybookRun } from "@/types/playbooks";
import { WidgetCard } from "@/components/motherboard/WidgetCard";
import { cn } from "@/lib/utils";
import { Play, Pause, CheckCircle2, AlertTriangle, Loader2 } from "lucide-react";

const triggerModeStyles: Record<string, string> = {
  manual: "bg-muted text-muted-foreground",
  alert: "bg-amber-500/10 text-amber-600",
  insight: "bg-blue-500/10 text-blue-600",
  mixed: "bg-purple-500/10 text-purple-600",
};

const runStatusStyles: Record<string, string> = {
  running: "text-blue-500",
  success: "text-emerald-500",
  partial: "text-amber-500",
  failed: "text-destructive",
};

const runStatusIcons: Record<string, JSX.Element> = {
  running: <Loader2 className="h-3 w-3 animate-spin" />,
  success: <CheckCircle2 className="h-3 w-3" />,
  partial: <AlertTriangle className="h-3 w-3" />,
  failed: <AlertTriangle className="h-3 w-3" />,
};

export function PlaybookPanel() {
  const queryClient = useQueryClient();
  const { currentTenantId, loading: tenantLoading } = useTenant();

  const playbooksQuery = useQuery({
    queryKey: ["wf-playbooks", currentTenantId],
    queryFn: async () => {
      if (!currentTenantId) return [];
      return getPlaybooks(currentTenantId);
    },
    enabled: !!currentTenantId && !tenantLoading,
    staleTime: 30_000,
  });

  const runsQuery = useQuery({
    queryKey: ["wf-playbook-runs", currentTenantId],
    queryFn: async () => {
      if (!currentTenantId) return [];
      return getPlaybookRuns(currentTenantId, { limit: 5 });
    },
    enabled: !!currentTenantId && !tenantLoading,
    staleTime: 30_000,
  });

  const toggleMutation = useMutation({
    mutationFn: async ({ playbookId, enabled }: { playbookId: string; enabled: boolean }) => {
      return togglePlaybookEnabled(playbookId, enabled);
    },
    onSuccess: (result, variables) => {
      if (result.ok) {
        queryClient.invalidateQueries({ queryKey: ["wf-playbooks"] });
        toast.success(variables.enabled ? "Playbook enabled" : "Playbook disabled");
      } else {
        toast.error(result.error || "Failed to toggle playbook");
      }
    },
  });

  const runMutation = useMutation({
    mutationFn: async (playbookId: string) => {
      if (!currentTenantId) throw new Error("No tenant");
      return runPlaybookManually({ tenantId: currentTenantId, playbookId });
    },
    onSuccess: (result) => {
      if (result.ok) {
        queryClient.invalidateQueries({ queryKey: ["wf-playbook-runs"] });
        toast.success("Playbook executed successfully");
      } else {
        toast.error(result.error || "Failed to run playbook");
      }
    },
  });

  const isLoading = playbooksQuery.isLoading || runsQuery.isLoading || tenantLoading;
  const playbooks = playbooksQuery.data || [];
  const runs = runsQuery.data || [];

  const getListenText = () => {
    if (!playbooks.length) {
      return "No playbooks defined yet. Start by adding a Collections Blitz or Stuck Applications playbook.";
    }
    const enabledCount = playbooks.filter((pb) => pb.enabled).length;
    const lastRun = runs[0];
    const runInfo = lastRun
      ? `Last run was "${lastRun.status}" ${formatDistanceToNow(new Date(lastRun.started_at), {
          addSuffix: true,
        })}.`
      : "No recent runs.";
    return `You have ${playbooks.length} playbooks (${enabledCount} enabled). ${runInfo}`;
  };

  return (
    <WidgetCard
      title="AI Playbooks"
      subtitle="Multi-step recipes for alerts, insights and manual cleanups."
      isLoading={isLoading}
      onRefresh={() => {
        playbooksQuery.refetch();
        runsQuery.refetch();
      }}
      listenText={getListenText()}
    >
      {playbooks.length === 0 ? (
        <div className="text-xs text-muted-foreground">
          No playbooks configured. Playbooks are multi-step recipes that run when conditions are
          met.
        </div>
      ) : (
        <div className="space-y-2">
          {playbooks.slice(0, 5).map((pb: WfPlaybook) => (
            <div
              key={pb.id}
              className="rounded-md border border-border/70 bg-card px-2.5 py-2 text-xs shadow-sm"
            >
              <div className="flex items-center justify-between gap-2">
                <div className="flex flex-col gap-1">
                  <div className="flex items-center gap-1.5">
                    <span className="font-medium">{pb.name}</span>
                    <span
                      className={cn(
                        "rounded-full px-1.5 py-0.5 text-[10px] font-medium",
                        triggerModeStyles[pb.trigger_mode] || triggerModeStyles.manual,
                      )}
                    >
                      {pb.trigger_mode}
                    </span>
                  </div>
                </div>
                <div className="flex items-center gap-1.5">
                  {pb.trigger_mode === "manual" && (
                    <button
                      type="button"
                      onClick={() => runMutation.mutate(pb.id)}
                      disabled={runMutation.isPending || !pb.enabled}
                      className="rounded p-1 text-primary hover:bg-primary/10 disabled:opacity-50"
                      title="Run now"
                    >
                      <Play className="h-3 w-3" />
                    </button>
                  )}
                  <button
                    type="button"
                    onClick={() =>
                      toggleMutation.mutate({ playbookId: pb.id, enabled: !pb.enabled })
                    }
                    disabled={toggleMutation.isPending}
                    className="rounded p-1 text-muted-foreground hover:bg-muted"
                    title={pb.enabled ? "Disable" : "Enable"}
                  >
                    {pb.enabled ? (
                      <Pause className="h-3 w-3" />
                    ) : (
                      <Play className="h-3 w-3" />
                    )}
                  </button>
                </div>
              </div>
              {pb.description && (
                <p className="mt-1 line-clamp-2 text-[11px] text-muted-foreground">
                  {pb.description}
                </p>
              )}
            </div>
          ))}
        </div>
      )}

      {runs.length > 0 && (
        <div className="mt-3 border-t border-border/60 pt-2">
          <div className="mb-1 text-[11px] font-medium text-muted-foreground">
            Recent Runs
          </div>
          <div className="space-y-1.5">
            {runs.slice(0, 3).map((run: WfPlaybookRun) => (
              <div
                key={run.id}
                className="flex items-center justify-between text-[11px]"
              >
                <div className="flex items-center gap-1.5">
                  <span className={cn(runStatusStyles[run.status])}>
                    {runStatusIcons[run.status]}
                  </span>
                  <span className="text-muted-foreground">
                    {run.steps_completed}/{run.total_steps} steps
                  </span>
                </div>
                <div className="text-[10px] text-muted-foreground">
                  {formatDistanceToNow(new Date(run.started_at), { addSuffix: true })}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </WidgetCard>
  );
}
