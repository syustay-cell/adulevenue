import React from "react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { WidgetCard } from "./WidgetCard";

type TaskStats = {
  task_type: string;
  count: number;
};

export function TaskQueuesWidget() {
  const query = useQuery({
    queryKey: ["motherboard-tasks"],
    queryFn: async (): Promise<TaskStats[]> => {
      const { data, error } = await supabase
        .from("outreach_tasks")
        .select("task_type, status");

      if (error) throw error;

      const aggregated: Record<string, TaskStats> = {};

      (data || []).forEach((row: any) => {
        if (row.status !== "pending") return;
        const type = row.task_type || "unknown";
        if (!aggregated[type]) {
          aggregated[type] = { task_type: type, count: 0 };
        }
        aggregated[type].count += 1;
      });

      return Object.values(aggregated);
    },
    staleTime: 60_000,
  });

  const getListenText = () => {
    if (!query.data || query.data.length === 0) return "No pending tasks.";
    const total = query.data.reduce((sum, r) => sum + r.count, 0);
    return `Task Queues: ${total} pending tasks. ${query.data.map(r => `${r.count} ${r.task_type.replace(/_/g, " ")}`).join(", ")}.`;
  };

  return (
    <WidgetCard
      title="Task Queues"
      subtitle="Pending tasks by type"
      onRefresh={() => query.refetch()}
      listenText={getListenText()}
    >
      {query.isLoading && (
        <p className="text-xs text-muted-foreground">Loading task queue metrics…</p>
      )}

      {!query.isLoading && query.data && query.data.length === 0 && (
        <p className="text-xs text-muted-foreground">No pending tasks.</p>
      )}

      {!query.isLoading && query.data && query.data.length > 0 && (
        <ul className="space-y-1">
          {query.data.map((row) => (
            <li
              key={row.task_type}
              className="flex items-center justify-between text-xs"
            >
              <span className="capitalize text-muted-foreground">
                {row.task_type || "unknown"}
              </span>
              <span className="font-medium">{row.count}</span>
            </li>
          ))}
        </ul>
      )}
    </WidgetCard>
  );
}
