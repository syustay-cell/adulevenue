import React from "react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { WidgetCard } from "./WidgetCard";

type TenantRow = {
  id: string;
  name: string | null;
  intake_count: number;
  deal_count: number;
  credit_count: number;
};

export function TenantsSummaryWidget() {
  const query = useQuery({
    queryKey: ["motherboard-tenants"],
    queryFn: async (): Promise<TenantRow[]> => {
      const { data: tenants, error: tenantsError } = await supabase
        .from("wf_tenants")
        .select("id, name");

      if (tenantsError) throw tenantsError;

      const list = tenants || [];
      const results: TenantRow[] = [];

      for (const t of list) {
        const tenantId = t.id;

        const [intakeRes, dealsRes, creditRes] = await Promise.all([
          supabase
            .from("intake_clients")
            .select("id", { count: "exact", head: true })
            .eq("tenant_id", tenantId),
          supabase
            .from("deals")
            .select("id", { count: "exact", head: true })
            .eq("tenant_id", tenantId),
          supabase
            .from("credit_repair_cases")
            .select("id", { count: "exact", head: true })
            .eq("tenant_id", tenantId),
        ]);

        results.push({
          id: tenantId,
          name: t.name,
          intake_count: intakeRes.count ?? 0,
          deal_count: dealsRes.count ?? 0,
          credit_count: creditRes.count ?? 0,
        });
      }

      return results;
    },
    staleTime: 60_000,
  });

  const getListenText = () => {
    if (!query.data || query.data.length === 0) return "No tenants found.";
    return `Tenants Overview: ${query.data.length} tenants. ${query.data.map(t => 
      `${t.name || "Unnamed"}: ${t.intake_count} clients, ${t.deal_count} deals, ${t.credit_count} credit cases`
    ).join(". ")}.`;
  };

  return (
    <WidgetCard
      title="Tenants Overview"
      subtitle="Per-tenant intake, deals, and credit cases"
      onRefresh={() => query.refetch()}
      listenText={getListenText()}
    >
      {query.isLoading && (
        <p className="text-xs text-muted-foreground">Loading tenant metrics…</p>
      )}

      {!query.isLoading && query.data && query.data.length === 0 && (
        <p className="text-xs text-muted-foreground">No tenants found.</p>
      )}

      {!query.isLoading && query.data && query.data.length > 0 && (
        <div className="space-y-1">
          {query.data.map((t) => (
            <div
              key={t.id}
              className="flex items-center justify-between text-xs"
            >
              <div className="flex flex-col min-w-0">
                <span className="font-medium truncate">
                  {t.name || "Unnamed tenant"}
                </span>
                <span className="text-[11px] text-muted-foreground">
                  {t.intake_count} clients • {t.deal_count} deals • {t.credit_count} credit cases
                </span>
              </div>
            </div>
          ))}
        </div>
      )}
    </WidgetCard>
  );
}
