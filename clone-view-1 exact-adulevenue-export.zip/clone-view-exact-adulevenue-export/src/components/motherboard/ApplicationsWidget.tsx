import React from "react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { WidgetCard } from "./WidgetCard";

type AppStats = {
  status: string;
  count: number;
};

export function ApplicationsWidget() {
  const query = useQuery({
    queryKey: ["motherboard-applications"],
    queryFn: async (): Promise<AppStats[]> => {
      const { data, error } = await supabase
        .from("fast_track_applications")
        .select("status");

      if (error) throw error;

      const aggregated: Record<string, AppStats> = {};

      (data || []).forEach((row: any) => {
        const status = row.status || "unknown";
        if (!aggregated[status]) {
          aggregated[status] = { status, count: 0 };
        }
        aggregated[status].count += 1;
      });

      return Object.values(aggregated);
    },
    staleTime: 60_000,
  });

  const getListenText = () => {
    if (!query.data || query.data.length === 0) return "No merchant applications.";
    const total = query.data.reduce((sum, r) => sum + r.count, 0);
    return `Merchant Applications: ${total} total. ${query.data.map(r => `${r.count} ${r.status}`).join(", ")}.`;
  };

  return (
    <WidgetCard
      title="Merchant Applications"
      subtitle="Fast track apps by status"
      onRefresh={() => query.refetch()}
      listenText={getListenText()}
    >
      {query.isLoading && (
        <p className="text-xs text-muted-foreground">Loading applications metrics…</p>
      )}

      {!query.isLoading && query.data && query.data.length === 0 && (
        <p className="text-xs text-muted-foreground">No merchant applications yet.</p>
      )}

      {!query.isLoading && query.data && query.data.length > 0 && (
        <ul className="space-y-1">
          {query.data.map((row) => (
            <li
              key={row.status}
              className="flex items-center justify-between text-xs"
            >
              <span className="capitalize text-muted-foreground">
                {row.status || "unknown"}
              </span>
              <span className="font-medium">{row.count}</span>
            </li>
          ))}
        </ul>
      )}
    </WidgetCard>
  );
}
