import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { toast } from "sonner";
import { 
  Shield, AlertTriangle, CheckCircle, XCircle, RefreshCw, 
  DollarSign, FileText, Cpu, ExternalLink, Info, Bell,
  Clock, Download, Eye, CheckCheck, BarChart3, History
} from "lucide-react";
import {
  fetchGovernanceAlerts,
  fetchGovernanceReports,
  fetchGovernanceActions,
  updateAlertStatus,
  logGovernanceAction,
  runScheduledGovernanceScan,
  getAlertCounts,
  generateGovernanceReportHTML,
  type GovernanceAlert,
  type GovernanceReport,
  type GovernanceAction,
} from "@/core/governance/api";

interface GovernanceCheck {
  id: string;
  area: "billing" | "ip" | "ai_change" | "defense" | "playbook";
  severity: "info" | "warn" | "critical";
  status: "pass" | "warn" | "fail";
  message: string;
  details?: Record<string, unknown>;
}

interface GovernanceSuggestion {
  id: string;
  title: string;
  area: "billing" | "ip" | "ai_change" | "defense" | "playbook";
  severity: "info" | "warn" | "critical";
  summary: string;
  actions: Array<{
    label: string;
    type: "navigate" | "run_scan" | "remediate";
    target: string;
  }>;
  source_check_id: string;
}

interface GovernanceSummary {
  total_checks: number;
  pass_count: number;
  warn_count: number;
  fail_count: number;
  billing_status: "ok" | "issues";
  ip_status: "ok" | "issues";
  ai_status: "ok" | "issues";
  defense_status?: "ok" | "issues";
  playbook_status?: "ok" | "issues";
  automation_status?: "ok" | "issues";
}

interface GovernanceSignals {
  billing?: {
    total_events_30d: number;
    event_types_seen: string[];
    priced_event_types: string[];
    unpriced_event_types: string[];
    events_by_type: Record<string, number>;
    events_by_brand: Record<string, number>;
  };
  ip?: {
    total_assets: number;
    total_drafts: number;
    total_filing_packets: number;
    drafts_by_status: Record<string, number>;
    packets_by_status: Record<string, number>;
    packets_by_type: Record<string, number>;
    legal_backlog: number;
    high_priority_undocumented: number;
    high_priority_without_packets: number;
    ai_generated_assets: number;
    ai_touched_no_legal: number;
    recent_ip_events: number;
    assets_by_brand: Record<string, number>;
    assets_by_type: Record<string, number>;
    assets_by_priority: Record<string, number>;
  };
  ip_defense?: {
    brand_readiness: Record<string, { score: number; high_critical_no_packet: number; unreviewed_critical: number }>;
  };
  playbook?: {
    pending_count: number;
  };
  alerts?: {
    open_count: number;
    high_severity_open_count: number;
  };
}

// V19: Get tenant ID from context (default for now, wire to real auth later)
const DEFAULT_TENANT_ID = "00000000-0000-0000-0000-000000000001";

export function GovernanceTab() {
  const queryClient = useQueryClient();
  const [loading, setLoading] = useState(false);
  const [lastScan, setLastScan] = useState<Date | null>(null);
  const [summary, setSummary] = useState<GovernanceSummary | null>(null);
  const [signals, setSignals] = useState<GovernanceSignals>({});
  const [checks, setChecks] = useState<GovernanceCheck[]>([]);
  const [suggestions, setSuggestions] = useState<GovernanceSuggestion[]>([]);
  const [currentUserId, setCurrentUserId] = useState<string | null>(null);
  const [tenantId, setTenantId] = useState<string>(DEFAULT_TENANT_ID);

  // V19: Get current user for audit tracking
  useEffect(() => {
    supabase.auth.getUser().then(({ data }) => {
      if (data?.user?.id) {
        setCurrentUserId(data.user.id);
      }
    });
  }, []);

  // V19: Fetch alerts
  const { data: alerts = [], refetch: refetchAlerts } = useQuery({
    queryKey: ["governance-alerts", tenantId],
    queryFn: () => fetchGovernanceAlerts(tenantId, "all"),
    staleTime: 30000,
  });

  // V19: Fetch reports
  const { data: reports = [] } = useQuery({
    queryKey: ["governance-reports", tenantId],
    queryFn: () => fetchGovernanceReports(tenantId, 10),
    staleTime: 60000,
  });

  // V19: Fetch actions
  const { data: actions = [] } = useQuery({
    queryKey: ["governance-actions", tenantId],
    queryFn: () => fetchGovernanceActions(tenantId, 20),
    staleTime: 30000,
  });

  // V19: Alert counts
  const { data: alertCounts } = useQuery({
    queryKey: ["governance-alert-counts", tenantId],
    queryFn: () => getAlertCounts(tenantId),
    staleTime: 30000,
  });

  // V19: Update alert mutation with user tracking
  const updateAlertMutation = useMutation({
    mutationFn: ({ alertId, status }: { alertId: string; status: "acknowledged" | "resolved" }) =>
      updateAlertStatus(alertId, status, currentUserId || undefined),
    onSuccess: () => {
      toast.success("Alert updated");
      refetchAlerts();
      queryClient.invalidateQueries({ queryKey: ["governance-alert-counts"] });
    },
  });

  useEffect(() => {
    runGovernanceScan();
  }, [tenantId]);

  const runGovernanceScan = async () => {
    setLoading(true);
    try {
      // V19: Pass tenant_id for alerts enrichment
      const { data, error } = await supabase.functions.invoke("wf-governance-scan", {
        body: { tenant_id: tenantId, scope: "all" },
      });

      if (error) throw error;
      if (!data?.ok) throw new Error(data?.error || "Scan failed");

      setSummary(data.summary);
      setSignals(data.signals);
      setChecks(data.checks || []);
      setSuggestions(data.suggestions || []);
      setLastScan(new Date());
      toast.success("Governance scan complete");
    } catch (err: any) {
      toast.error(`Scan failed: ${err.message}`);
    } finally {
      setLoading(false);
    }
  };

  // V19: Run scheduled scan with persistence
  const runScheduledScan = async () => {
    setLoading(true);
    try {
      const result = await runScheduledGovernanceScan(tenantId);
      toast.success(`Scan complete: ${result.results?.[0]?.alerts_created || 0} alerts created`);
      refetchAlerts();
      queryClient.invalidateQueries({ queryKey: ["governance-reports"] });
      queryClient.invalidateQueries({ queryKey: ["governance-actions"] });
      runGovernanceScan();
    } catch (err: any) {
      toast.error(`Scheduled scan failed: ${err.message}`);
    } finally {
      setLoading(false);
    }
  };

  // V19: Handle remediation action - now actually performs actions, not just logs
  const handleRemediation = async (
    actionType: string,
    sourceCheckId?: string,
    sourceSuggestionId?: string
  ) => {
    try {
      let result: any = null;
      let actionNotes = `Remediation triggered from Governance tab`;

      // V19: Route to actual remediation functions based on action type
      switch (actionType) {
        case "create_ip_filing_packets_for_high_priority":
          // Call edge function to create filing packets for high-priority assets
          const { data: filingResult, error: filingError } = await supabase.functions.invoke(
            "wf-ip-filing-generate",
            { body: { tenant_id: tenantId, priority_filter: ["high", "critical"], auto_batch: true } }
          );
          if (filingError) throw filingError;
          result = filingResult;
          actionNotes = `Created ${filingResult?.created_count || 0} filing packets for high-priority assets`;
          break;

        case "resolve_playbook_drift":
          // Call existing playbook drift resolve function
          const { data: driftResult, error: driftError } = await supabase.functions.invoke(
            "wf-playbook-drift-resolve",
            { body: { tenant_id: tenantId, action: "approve_all_detected" } }
          );
          if (driftError) throw driftError;
          result = driftResult;
          actionNotes = `Resolved ${driftResult?.resolved_count || 0} playbook drift items`;
          break;

        case "add_unpriced_events_to_billing":
          // This would update wolf_master_config billing event_pricing
          actionNotes = `Flagged unpriced events for billing config update (manual review required)`;
          break;

        default:
          // For other action types, just log (audit-only)
          actionNotes = `Action '${actionType}' logged for review`;
      }

      // Always log the action for audit trail
      await logGovernanceAction({
        tenant_id: tenantId,
        action_type: actionType,
        source_check_id: sourceCheckId,
        source_suggestion_id: sourceSuggestionId,
        performed_by: currentUserId || undefined,
        notes: actionNotes,
        new_state: result,
      });

      queryClient.invalidateQueries({ queryKey: ["governance-actions"] });
      toast.success(actionNotes);
      
      // Re-scan to see updated state
      if (result) {
        setTimeout(() => runGovernanceScan(), 1000);
      }
    } catch (err: any) {
      toast.error(`Remediation failed: ${err.message}`);
    }
  };

  // V19: Export report as HTML
  const exportReport = (report: GovernanceReport) => {
    const html = generateGovernanceReportHTML(report);
    const blob = new Blob([html], { type: "text/html" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `governance-report-${new Date(report.created_at).toISOString().split("T")[0]}.html`;
    a.click();
    URL.revokeObjectURL(url);
    toast.success("Report exported");
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "pass":
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case "warn":
        return <AlertTriangle className="h-4 w-4 text-yellow-500" />;
      case "fail":
        return <XCircle className="h-4 w-4 text-red-500" />;
      default:
        return <Info className="h-4 w-4 text-muted-foreground" />;
    }
  };

  const getSeverityBadge = (severity: string) => {
    switch (severity) {
      case "critical":
        return <Badge variant="destructive">Critical</Badge>;
      case "warn":
        return <Badge variant="outline" className="border-yellow-500 text-yellow-600">Warning</Badge>;
      default:
        return <Badge variant="secondary">Info</Badge>;
    }
  };

  const getAreaIcon = (area: string) => {
    switch (area) {
      case "billing":
        return <DollarSign className="h-4 w-4" />;
      case "ip":
      case "defense":
        return <FileText className="h-4 w-4" />;
      case "ai_change":
        return <Cpu className="h-4 w-4" />;
      default:
        return <Shield className="h-4 w-4" />;
    }
  };

  const getAlertTypeBadge = (alertType: string) => {
    switch (alertType) {
      case "ip_defense_low":
        return <Badge variant="destructive">IP Defense Low</Badge>;
      case "unpriced_events":
        return <Badge variant="outline" className="border-yellow-500 text-yellow-600">Unpriced Events</Badge>;
      case "playbook_drift_backlog":
        return <Badge variant="outline" className="border-orange-500 text-orange-600">Playbook Drift</Badge>;
      case "legal_backlog_high":
        return <Badge variant="destructive">Legal Backlog</Badge>;
      default:
        return <Badge variant="secondary">{alertType}</Badge>;
    }
  };

  const handleAction = async (action: { label: string; type: string; target: string }, suggestion?: GovernanceSuggestion) => {
    if (action.type === "navigate") {
      window.location.href = action.target;
    } else if (action.type === "run_scan") {
      runGovernanceScan();
    } else if (action.type === "remediate" && suggestion) {
      await handleRemediation(action.target, suggestion.source_check_id, suggestion.id);
    }
  };

  const openAlerts = alerts.filter((a) => a.status === "open");

  return (
    <div className="space-y-6">
      {/* Summary Strip */}
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div className="flex items-center gap-4 flex-wrap">
          <div className="flex items-center gap-2">
            <DollarSign className="h-5 w-5" />
            <span className="font-medium">Billing:</span>
            {summary?.billing_status === "ok" ? (
              <Badge variant="outline" className="border-green-500 text-green-600">OK</Badge>
            ) : (
              <Badge variant="destructive">Issues</Badge>
            )}
          </div>
          <div className="flex items-center gap-2">
            <FileText className="h-5 w-5" />
            <span className="font-medium">IP:</span>
            {summary?.ip_status === "ok" ? (
              <Badge variant="outline" className="border-green-500 text-green-600">OK</Badge>
            ) : (
              <Badge variant="destructive">Issues</Badge>
            )}
          </div>
          <div className="flex items-center gap-2">
            <Cpu className="h-5 w-5" />
            <span className="font-medium">AI:</span>
            {summary?.ai_status === "ok" ? (
              <Badge variant="outline" className="border-green-500 text-green-600">OK</Badge>
            ) : (
              <Badge variant="destructive">Issues</Badge>
            )}
          </div>
          {/* V19: Alerts badge */}
          <div className="flex items-center gap-2">
            <Bell className="h-5 w-5" />
            <span className="font-medium">Alerts:</span>
            {alertCounts?.open === 0 ? (
              <Badge variant="outline" className="border-green-500 text-green-600">0 Open</Badge>
            ) : (
              <Badge variant="destructive">{alertCounts?.open || 0} Open</Badge>
            )}
          </div>
        </div>
        <div className="flex items-center gap-2">
          {lastScan && (
            <span className="text-sm text-muted-foreground">
              Last scan: {lastScan.toLocaleTimeString()}
            </span>
          )}
          <Button onClick={runGovernanceScan} disabled={loading} size="sm" variant="outline">
            <RefreshCw className={`h-4 w-4 mr-2 ${loading ? "animate-spin" : ""}`} />
            Quick Scan
          </Button>
          <Button onClick={runScheduledScan} disabled={loading} size="sm">
            <RefreshCw className={`h-4 w-4 mr-2 ${loading ? "animate-spin" : ""}`} />
            Full Scan + Save
          </Button>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Total Checks</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{summary?.total_checks || 0}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-green-600">Passing</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{summary?.pass_count || 0}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-yellow-600">Warnings</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-yellow-600">{summary?.warn_count || 0}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-red-600">Failures</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">{summary?.fail_count || 0}</div>
          </CardContent>
        </Card>
      </div>

      {/* Detailed Tabs */}
      <Tabs defaultValue="overview" className="space-y-4">
        <TabsList className="flex-wrap h-auto">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="alerts" className="relative">
            Alerts
            {openAlerts.length > 0 && (
              <span className="ml-1 bg-destructive text-destructive-foreground text-xs px-1.5 py-0.5 rounded-full">
                {openAlerts.length}
              </span>
            )}
          </TabsTrigger>
          <TabsTrigger value="billing">Billing</TabsTrigger>
          <TabsTrigger value="ip">IP & Legal</TabsTrigger>
          <TabsTrigger value="brands">Brand Comparison</TabsTrigger>
          <TabsTrigger value="reports">Reports</TabsTrigger>
          <TabsTrigger value="actions">Actions</TabsTrigger>
          <TabsTrigger value="suggestions">Suggestions ({suggestions.length})</TabsTrigger>
        </TabsList>

        {/* Overview Tab */}
        <TabsContent value="overview">
          <Card>
            <CardHeader>
              <CardTitle>All Governance Checks</CardTitle>
              <CardDescription>
                Results from the latest governance scan across all areas
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-[400px]">
                <div className="space-y-3">
                  {checks.map((check) => (
                    <div
                      key={check.id}
                      className="flex items-start justify-between p-3 border rounded-lg"
                    >
                      <div className="flex items-start gap-3">
                        {getStatusIcon(check.status)}
                        <div>
                          <div className="flex items-center gap-2">
                            {getAreaIcon(check.area)}
                            <span className="font-medium text-sm">{check.id}</span>
                            {getSeverityBadge(check.severity)}
                          </div>
                          <p className="text-sm text-muted-foreground mt-1">{check.message}</p>
                          {check.details && (
                            <pre className="text-xs text-muted-foreground mt-2 bg-muted p-2 rounded max-w-lg overflow-auto">
                              {JSON.stringify(check.details, null, 2)}
                            </pre>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                  {checks.length === 0 && (
                    <p className="text-muted-foreground text-center py-8">
                      No checks available. Run a scan to see results.
                    </p>
                  )}
                </div>
              </ScrollArea>
            </CardContent>
          </Card>
        </TabsContent>

        {/* V19: Alerts Tab */}
        <TabsContent value="alerts">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Bell className="h-5 w-5" />
                Governance Alerts
              </CardTitle>
              <CardDescription>
                Threshold breaches and issues requiring attention
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-[400px]">
                <div className="space-y-3">
                  {alerts.map((alert) => (
                    <div
                      key={alert.id}
                      className={`p-4 border rounded-lg ${
                        alert.status === "open" ? "border-red-200 bg-red-50 dark:bg-red-950/20" : 
                        alert.status === "acknowledged" ? "border-yellow-200 bg-yellow-50 dark:bg-yellow-950/20" : 
                        "border-green-200 bg-green-50 dark:bg-green-950/20"
                      }`}
                    >
                      <div className="flex items-start justify-between">
                        <div className="space-y-1">
                          <div className="flex items-center gap-2">
                            {getAlertTypeBadge(alert.alert_type)}
                            {alert.brand_key && (
                              <Badge variant="outline">{alert.brand_key}</Badge>
                            )}
                            <Badge variant={alert.status === "open" ? "destructive" : alert.status === "acknowledged" ? "outline" : "secondary"}>
                              {alert.status}
                            </Badge>
                          </div>
                          <p className="text-sm">
                            <span className="font-medium">{alert.metric_key}:</span>{" "}
                            {alert.current_value} (threshold: {alert.threshold_value})
                          </p>
                          <p className="text-xs text-muted-foreground">
                            Last triggered: {new Date(alert.last_triggered_at).toLocaleString()}
                          </p>
                        </div>
                        <div className="flex gap-2">
                          {alert.status === "open" && (
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => updateAlertMutation.mutate({ alertId: alert.id, status: "acknowledged" })}
                            >
                              <Eye className="h-4 w-4 mr-1" />
                              Acknowledge
                            </Button>
                          )}
                          {(alert.status === "open" || alert.status === "acknowledged") && (
                            <Button
                              size="sm"
                              variant="default"
                              onClick={() => updateAlertMutation.mutate({ alertId: alert.id, status: "resolved" })}
                            >
                              <CheckCheck className="h-4 w-4 mr-1" />
                              Resolve
                            </Button>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                  {alerts.length === 0 && (
                    <div className="text-center py-8">
                      <CheckCircle className="h-12 w-12 text-green-500 mx-auto mb-2" />
                      <p className="text-muted-foreground">No alerts. All governance thresholds are within limits.</p>
                    </div>
                  )}
                </div>
              </ScrollArea>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Billing Tab */}
        <TabsContent value="billing">
          <Card>
            <CardHeader>
              <CardTitle>Billing Governance</CardTitle>
              <CardDescription>Usage coverage and pricing alignment</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {signals.billing && (
                <>
                  <div className="grid grid-cols-3 gap-4">
                    <div className="p-4 border rounded-lg">
                      <p className="text-sm text-muted-foreground">Events (30 days)</p>
                      <p className="text-2xl font-bold">{signals.billing.total_events_30d}</p>
                    </div>
                    <div className="p-4 border rounded-lg">
                      <p className="text-sm text-muted-foreground">Event Types Seen</p>
                      <p className="text-2xl font-bold">{signals.billing.event_types_seen.length}</p>
                    </div>
                    <div className="p-4 border rounded-lg">
                      <p className="text-sm text-muted-foreground">Unpriced Types</p>
                      <p className={`text-2xl font-bold ${signals.billing.unpriced_event_types.length > 0 ? "text-yellow-600" : "text-green-600"}`}>
                        {signals.billing.unpriced_event_types.length}
                      </p>
                    </div>
                  </div>

                  {signals.billing.unpriced_event_types.length > 0 && (
                    <div className="p-4 border border-yellow-500 rounded-lg bg-yellow-50 dark:bg-yellow-950/20">
                      <p className="font-medium text-yellow-700 dark:text-yellow-400">Unpriced Event Types:</p>
                      <div className="flex flex-wrap gap-2 mt-2">
                        {signals.billing.unpriced_event_types.map((t) => (
                          <Badge key={t} variant="outline">{t}</Badge>
                        ))}
                      </div>
                    </div>
                  )}

                  <div>
                    <p className="font-medium mb-2">Events by Type</p>
                    <div className="grid grid-cols-2 gap-2">
                      {Object.entries(signals.billing.events_by_type).map(([type, count]) => (
                        <div key={type} className="flex justify-between p-2 bg-muted rounded">
                          <span className="text-sm">{type}</span>
                          <span className="font-medium">{count}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* IP & Legal Tab */}
        <TabsContent value="ip">
          <Card>
            <CardHeader>
              <CardTitle>IP & Legal Governance</CardTitle>
              <CardDescription>IP Guardian coverage and documentation status</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {signals.ip && (
                <>
                  <div className="grid grid-cols-4 gap-4">
                    <div className="p-4 border rounded-lg">
                      <p className="text-sm text-muted-foreground">Total Assets</p>
                      <p className="text-2xl font-bold">{signals.ip.total_assets}</p>
                    </div>
                    <div className="p-4 border rounded-lg">
                      <p className="text-sm text-muted-foreground">Legal Drafts</p>
                      <p className="text-2xl font-bold">{signals.ip.total_drafts}</p>
                    </div>
                    <div className="p-4 border rounded-lg">
                      <p className="text-sm text-muted-foreground">Review Backlog</p>
                      <p className={`text-2xl font-bold ${signals.ip.legal_backlog > 5 ? "text-yellow-600" : "text-green-600"}`}>
                        {signals.ip.legal_backlog}
                      </p>
                    </div>
                    <div className="p-4 border rounded-lg">
                      <p className="text-sm text-muted-foreground">High Priority (Undoc)</p>
                      <p className={`text-2xl font-bold ${signals.ip.high_priority_undocumented > 0 ? "text-red-600" : "text-green-600"}`}>
                        {signals.ip.high_priority_undocumented}
                      </p>
                    </div>
                  </div>

                  {signals.ip.high_priority_undocumented > 0 && (
                    <div className="p-4 border border-red-500 rounded-lg bg-red-50 dark:bg-red-950/20">
                      <p className="font-medium text-red-700 dark:text-red-400">
                        {signals.ip.high_priority_undocumented} high-priority asset(s) need legal documentation
                      </p>
                      <Button
                        variant="outline"
                        size="sm"
                        className="mt-2"
                        onClick={() => window.location.href = "/ip-guardian?filter=high_priority"}
                      >
                        <ExternalLink className="h-4 w-4 mr-2" />
                        Open IP Guardian
                      </Button>
                    </div>
                  )}
                </>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* V19: Brand Comparison Tab */}
        <TabsContent value="brands">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BarChart3 className="h-5 w-5" />
                Brand Comparison
              </CardTitle>
              <CardDescription>Side-by-side governance health across brands</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b">
                      <th className="text-left p-3 font-medium">Brand</th>
                      <th className="text-left p-3 font-medium">Defense Score</th>
                      <th className="text-left p-3 font-medium">Assets</th>
                      <th className="text-left p-3 font-medium">Critical Unreviewed</th>
                      <th className="text-left p-3 font-medium">Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {signals.ip_defense?.brand_readiness && Object.entries(signals.ip_defense.brand_readiness).map(([brand, data]) => (
                      <tr key={brand} className="border-b">
                        <td className="p-3 font-medium">{brand}</td>
                        <td className="p-3">
                          <div className="flex items-center gap-2">
                            <div className="w-16 h-2 bg-muted rounded-full overflow-hidden">
                              <div
                                className={`h-full ${data.score >= 80 ? "bg-green-500" : data.score >= 60 ? "bg-yellow-500" : "bg-red-500"}`}
                                style={{ width: `${data.score}%` }}
                              />
                            </div>
                            <span>{data.score}%</span>
                          </div>
                        </td>
                        <td className="p-3">{signals.ip?.assets_by_brand?.[brand] || 0}</td>
                        <td className="p-3">
                          {data.unreviewed_critical > 0 ? (
                            <Badge variant="destructive">{data.unreviewed_critical}</Badge>
                          ) : (
                            <Badge variant="outline" className="border-green-500 text-green-600">0</Badge>
                          )}
                        </td>
                        <td className="p-3">
                          {data.score >= 80 ? (
                            <Badge variant="outline" className="border-green-500 text-green-600">Healthy</Badge>
                          ) : data.score >= 60 ? (
                            <Badge variant="outline" className="border-yellow-500 text-yellow-600">Needs Attention</Badge>
                          ) : (
                            <Badge variant="destructive">Critical</Badge>
                          )}
                        </td>
                      </tr>
                    ))}
                    {(!signals.ip_defense?.brand_readiness || Object.keys(signals.ip_defense.brand_readiness).length === 0) && (
                      <tr>
                        <td colSpan={5} className="p-8 text-center text-muted-foreground">
                          No brand data available. Run a full scan to populate.
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* V19: Reports Tab */}
        <TabsContent value="reports">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" />
                Governance Reports
              </CardTitle>
              <CardDescription>Historical scan snapshots</CardDescription>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-[400px]">
                <div className="space-y-3">
                  {reports.map((report) => (
                    <div key={report.id} className="p-4 border rounded-lg">
                      <div className="flex items-start justify-between">
                        <div>
                          <div className="flex items-center gap-2">
                            <Badge variant="outline">{report.run_type}</Badge>
                            <span className="text-sm text-muted-foreground">
                              {new Date(report.created_at).toLocaleString()}
                            </span>
                          </div>
                          <div className="flex items-center gap-4 mt-2 text-sm">
                            <span className="text-green-600">
                              ✓ {(report.checks as any[])?.filter((c: any) => c.status === "pass").length || 0} pass
                            </span>
                            <span className="text-yellow-600">
                              ⚠ {(report.checks as any[])?.filter((c: any) => c.status === "warn").length || 0} warn
                            </span>
                            <span className="text-red-600">
                              ✕ {(report.checks as any[])?.filter((c: any) => c.status === "fail").length || 0} fail
                            </span>
                          </div>
                        </div>
                        <Button variant="outline" size="sm" onClick={() => exportReport(report)}>
                          <Download className="h-4 w-4 mr-1" />
                          Export
                        </Button>
                      </div>
                    </div>
                  ))}
                  {reports.length === 0 && (
                    <p className="text-muted-foreground text-center py-8">
                      No reports saved yet. Run a "Full Scan + Save" to create one.
                    </p>
                  )}
                </div>
              </ScrollArea>
            </CardContent>
          </Card>
        </TabsContent>

        {/* V19: Actions Tab */}
        <TabsContent value="actions">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <History className="h-5 w-5" />
                Governance Actions
              </CardTitle>
              <CardDescription>Audit trail of remediation actions</CardDescription>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-[400px]">
                <div className="space-y-3">
                  {actions.map((action) => (
                    <div key={action.id} className="p-3 border rounded-lg">
                      <div className="flex items-center gap-2">
                        <Badge variant="secondary">{action.action_type}</Badge>
                        {action.brand_key && <Badge variant="outline">{action.brand_key}</Badge>}
                        <span className="text-xs text-muted-foreground ml-auto">
                          {new Date(action.performed_at).toLocaleString()}
                        </span>
                      </div>
                      {action.notes && (
                        <p className="text-sm text-muted-foreground mt-1">{action.notes}</p>
                      )}
                      {action.source_check_id && (
                        <p className="text-xs text-muted-foreground">
                          Source: {action.source_check_id}
                        </p>
                      )}
                    </div>
                  ))}
                  {actions.length === 0 && (
                    <p className="text-muted-foreground text-center py-8">
                      No actions recorded yet. Actions are logged when you remediate issues.
                    </p>
                  )}
                </div>
              </ScrollArea>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Suggestions Tab */}
        <TabsContent value="suggestions">
          <Card>
            <CardHeader>
              <CardTitle>Governance Suggestions</CardTitle>
              <CardDescription>
                Actionable recommendations from governance checks
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-[400px]">
                <div className="space-y-4">
                  {suggestions.map((suggestion) => (
                    <div
                      key={suggestion.id}
                      className="p-4 border rounded-lg space-y-3"
                    >
                      <div className="flex items-start justify-between">
                        <div className="flex items-center gap-2">
                          {getAreaIcon(suggestion.area)}
                          <span className="font-medium">{suggestion.title}</span>
                          {getSeverityBadge(suggestion.severity)}
                        </div>
                      </div>
                      <p className="text-sm text-muted-foreground">{suggestion.summary}</p>
                      <div className="flex gap-2">
                        {suggestion.actions.map((action, idx) => (
                          <Button
                            key={idx}
                            variant="outline"
                            size="sm"
                            onClick={() => handleAction(action, suggestion)}
                          >
                            <ExternalLink className="h-4 w-4 mr-2" />
                            {action.label}
                          </Button>
                        ))}
                      </div>
                    </div>
                  ))}
                  {suggestions.length === 0 && (
                    <div className="text-center py-8">
                      <CheckCircle className="h-12 w-12 text-green-500 mx-auto mb-2" />
                      <p className="text-muted-foreground">
                        No suggestions. All governance checks are passing!
                      </p>
                    </div>
                  )}
                </div>
              </ScrollArea>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
