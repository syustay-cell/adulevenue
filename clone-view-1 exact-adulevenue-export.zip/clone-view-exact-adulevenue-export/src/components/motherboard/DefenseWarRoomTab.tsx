import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Shield, ShieldCheck, ShieldAlert, ShieldX, FileText, Scale, ExternalLink } from "lucide-react";
import { fetchDefenseReadiness, BrandDefenseReadiness } from "@/core/ip-guardian/defense";
import { useNavigate } from "react-router-dom";

interface DefenseWarRoomTabProps {
  tenantId: string;
}

export function DefenseWarRoomTab({ tenantId }: DefenseWarRoomTabProps) {
  const navigate = useNavigate();

  const { data: readiness, isLoading } = useQuery({
    queryKey: ["defense-readiness", tenantId],
    queryFn: () => fetchDefenseReadiness(tenantId),
    enabled: !!tenantId,
  });

  const getStatusIcon = (status: BrandDefenseReadiness["status"]) => {
    switch (status) {
      case "defense_ready":
        return <ShieldCheck className="h-6 w-6 text-green-500" />;
      case "prepped_gaps":
        return <ShieldAlert className="h-6 w-6 text-yellow-500" />;
      case "high_risk":
        return <ShieldX className="h-6 w-6 text-red-500" />;
    }
  };

  const getStatusBadge = (status: BrandDefenseReadiness["status"]) => {
    switch (status) {
      case "defense_ready":
        return <Badge className="bg-green-100 text-green-800">✅ Defense-Ready</Badge>;
      case "prepped_gaps":
        return <Badge className="bg-yellow-100 text-yellow-800">⚠️ Prepped but Gaps</Badge>;
      case "high_risk":
        return <Badge className="bg-red-100 text-red-800">🟥 High-Risk Gaps</Badge>;
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center p-8">
        <div className="animate-spin h-8 w-8 border-2 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center gap-3">
        <Shield className="h-6 w-6 text-primary" />
        <div>
          <h2 className="text-xl font-semibold">IP Defense War Room</h2>
          <p className="text-sm text-muted-foreground">
            Brand-level defense readiness overview
          </p>
        </div>
      </div>

      {/* Warning Banner */}
      <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
        <p className="text-sm text-amber-800">
          <strong>⚠️ Internal Documentation Only:</strong> This dashboard tracks internal IP documentation status. 
          It does NOT indicate actual legal filings. Attorney review is required before any legal action.
        </p>
      </div>

      {/* Brand Cards */}
      {(!readiness || readiness.length === 0) ? (
        <Card>
          <CardContent className="p-8 text-center text-muted-foreground">
            <Shield className="h-12 w-12 mx-auto mb-4 opacity-50" />
            <p>No IP assets registered yet.</p>
            <p className="text-sm">Assets will appear here once registered in IP Guardian.</p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-6 md:grid-cols-2">
          {readiness.map((brand) => (
            <Card key={brand.brand_key} className="overflow-hidden">
              <CardHeader className="pb-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    {getStatusIcon(brand.status)}
                    <div>
                      <CardTitle className="text-lg capitalize">
                        {brand.brand_key.replace("-", " ")}
                      </CardTitle>
                      <p className="text-sm text-muted-foreground">
                        Defense Score: {brand.score}/100
                      </p>
                    </div>
                  </div>
                  {getStatusBadge(brand.status)}
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* Progress Bar */}
                <div className="h-2 bg-muted rounded-full overflow-hidden">
                  <div
                    className={`h-full transition-all ${
                      brand.score >= 80
                        ? "bg-green-500"
                        : brand.score >= 50
                        ? "bg-yellow-500"
                        : "bg-red-500"
                    }`}
                    style={{ width: `${brand.score}%` }}
                  />
                </div>

                {/* Metrics Grid */}
                <div className="grid grid-cols-2 gap-3 text-sm">
                  <div className="flex items-center gap-2">
                    <FileText className="h-4 w-4 text-muted-foreground" />
                    <span>High/Critical: {brand.high_or_critical_assets_total}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Scale className="h-4 w-4 text-muted-foreground" />
                    <span>With Packets: {brand.with_filing_packets}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <ShieldCheck className="h-4 w-4 text-green-500" />
                    <span>Attorney Reviewed: {brand.attorney_reviewed_assets}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <ExternalLink className="h-4 w-4 text-blue-500" />
                    <span>Externally Filed: {brand.externally_filed_assets}</span>
                  </div>
                </div>

                {/* Gaps */}
                {(brand.high_critical_no_packet > 0 || brand.ai_generated_no_draft > 0) && (
                  <div className="border-t pt-3 mt-3">
                    <p className="text-sm font-medium text-red-600 mb-2">Gaps to Address:</p>
                    <ul className="text-sm space-y-1">
                      {brand.high_critical_no_packet > 0 && (
                        <li className="text-red-600">
                          • {brand.high_critical_no_packet} high/critical assets without filing packets
                        </li>
                      )}
                      {brand.ai_generated_no_draft > 0 && (
                        <li className="text-amber-600">
                          • {brand.ai_generated_no_draft} AI-generated assets without legal drafts
                        </li>
                      )}
                    </ul>
                  </div>
                )}

                {/* Action */}
                <Button
                  variant="outline"
                  size="sm"
                  className="w-full"
                  onClick={() => navigate("/ip-guardian")}
                >
                  Open IP Guardian
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
