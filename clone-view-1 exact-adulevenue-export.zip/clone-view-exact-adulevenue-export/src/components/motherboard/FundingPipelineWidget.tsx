import React from "react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { WidgetCard } from "./WidgetCard";

type FundingStats = {
  status: string;
  deal_count: number;
  total_funded: number;
};

export function FundingPipelineWidget() {
  const query = useQuery({
    queryKey: ["motherboard-funding"],
    queryFn: async (): Promise<FundingStats[]> => {
      const { data, error } = await supabase
        .from("deals")
        .select(`
          status,
          funded_contracts(funded_amount)
        `);

      if (error) throw error;

      const aggregated: Record<string, FundingStats> = {};

      (data || []).forEach((row: any) => {
        const status = row.status || "unknown";
        const fundedContracts = row.funded_contracts || [];
        const fundedSum = fundedContracts.reduce(
          (sum: number, fc: any) => sum + (fc.funded_amount || 0),
          0
        );

        if (!aggregated[status]) {
          aggregated[status] = {
            status,
            deal_count: 0,
            total_funded: 0,
          };
        }

        aggregated[status].deal_count += 1;
        aggregated[status].total_funded += fundedSum;
      });

      return Object.values(aggregated);
    },
    staleTime: 60_000,
  });

  const getListenText = () => {
    if (!query.data || query.data.length === 0) return "No funding deals found.";
    const totalDeals = query.data.reduce((sum, r) => sum + r.deal_count, 0);
    const totalFunded = query.data.reduce((sum, r) => sum + r.total_funded, 0);
    return `Funding Pipeline: ${totalDeals} total deals, $${totalFunded.toLocaleString()} funded. ${query.data
      .map((r) => `${r.deal_count} in ${r.status}`)
      .join(", ")}.`;
  };

  return (
    <WidgetCard
      title="Funding Pipeline"
      subtitle="Deals by status and funded volume"
      onRefresh={() => query.refetch()}
      listenText={getListenText()}
      isLoading={query.isLoading}
    >
      {!query.isLoading && query.data && query.data.length === 0 && (
        <p className="text-xs text-muted-foreground">No deals found yet.</p>
      )}

      {!query.isLoading && query.data && query.data.length > 0 && (
        <div className="space-y-1.5">
          {query.data.map((row) => (
            <div
              key={row.status}
              className="flex items-center justify-between text-xs"
            >
              <span className="text-muted-foreground">
                {row.status || "unknown"}
              </span>
              <div className="flex items-center gap-2">
                <span className="text-[11px]">
                  {row.deal_count} deal{row.deal_count !== 1 ? "s" : ""}
                </span>
                <span className="font-medium">
                  ${row.total_funded.toLocaleString()}
                </span>
              </div>
            </div>
          ))}
        </div>
      )}
    </WidgetCard>
  );
}
