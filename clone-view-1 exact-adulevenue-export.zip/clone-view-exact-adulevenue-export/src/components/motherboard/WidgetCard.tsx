import React from "react";
import { RefreshCw } from "lucide-react";
import { cn } from "@/lib/utils";
import { ListenButton } from "@/components/ui/ListenButton";
import { Skeleton } from "@/components/ui/skeleton";

type WidgetCardProps = {
  title: string;
  subtitle?: string;
  onRefresh?: () => void;
  listenText?: string;
  isLoading?: boolean;
  children: React.ReactNode;
};

export function WidgetCard({
  title,
  subtitle,
  onRefresh,
  listenText,
  isLoading,
  children,
}: WidgetCardProps) {
  return (
    <div className="flex h-full flex-col rounded-xl border border-border bg-card/60 p-3 shadow-sm sm:p-4">
      {/* Header */}
      <div className="mb-2 flex items-center justify-between gap-2">
        <div className="space-y-0.5">
          <h2 className="text-xs font-semibold leading-none sm:text-sm">
            {title}
          </h2>
          {subtitle && (
            <p className="text-[11px] text-muted-foreground sm:text-xs">
              {subtitle}
            </p>
          )}
        </div>

        <div className="flex items-center gap-1.5">
          {listenText && (
            <ListenButton
              text={listenText}
              size="sm"
              label=""
            />
          )}
          {onRefresh && (
            <button
              type="button"
              onClick={onRefresh}
              className={cn(
                "inline-flex h-7 w-7 items-center justify-center rounded-full border border-border",
                "text-[11px] text-muted-foreground hover:bg-accent hover:text-foreground",
                "transition-colors"
              )}
            >
              <RefreshCw className="h-3.5 w-3.5" />
            </button>
          )}
        </div>
      </div>

      {/* Body */}
      <div className="flex-1">
        {isLoading ? (
          <div className="space-y-2">
            <Skeleton className="h-3 w-1/2" />
            <Skeleton className="h-3 w-3/4" />
            <Skeleton className="h-3 w-2/3" />
          </div>
        ) : (
          children
        )}
      </div>
    </div>
  );
}
