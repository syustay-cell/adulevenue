import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { RefreshCw, Zap, Leaf, Crown, User, AlertTriangle, DollarSign, CheckCircle2 } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

interface AIModeConfig {
  workspace_mode: string;
  per_feature: Record<string, string>;
  outsourced_providers: Record<string, any>;
  worker_costs: {
    default_hourly_rate: number;
    avg_minutes_per_task: Record<string, number>;
  };
  mode_definitions: Record<string, any>;
  safety_rules: {
    downgrade_on_warning: boolean;
    manual_on_critical: boolean;
    protected_features: string[];
  };
}

interface CostComparison {
  feature: string;
  current_mode: string;
  current_provider: string;
  ai_cost_openai: number;
  ai_cost_gateway: number;
  openai_calls_30d: number;
  gateway_calls_30d: number;
  worker_cost: number;
  vendor_cost: number | null;
  recommended: string;
  savings_potential: number;
}

const MODE_ICONS = {
  eco: <Leaf className="h-4 w-4 text-green-500" />,
  balanced: <Zap className="h-4 w-4 text-blue-500" />,
  pro: <Crown className="h-4 w-4 text-purple-500" />,
  manual: <User className="h-4 w-4 text-orange-500" />
};

const MODE_COLORS = {
  eco: 'bg-green-500/10 text-green-500 border-green-500/20',
  balanced: 'bg-blue-500/10 text-blue-500 border-blue-500/20',
  pro: 'bg-purple-500/10 text-purple-500 border-purple-500/20',
  manual: 'bg-orange-500/10 text-orange-500 border-orange-500/20'
};

const PROVIDER_LABELS: Record<string, string> = {
  openai: 'OpenAI',
  gateway: 'AI Gateway',
  manual: 'Human Worker'
};

export function AIModeSettingsPanel() {
  const [config, setConfig] = useState<AIModeConfig | null>(null);
  const [creditStatus, setCreditStatus] = useState<string>('ok');
  const [budgetStatus, setBudgetStatus] = useState<string>('ok');
  const [openaiAvailable, setOpenaiAvailable] = useState<boolean>(false);
  const [costComparison, setCostComparison] = useState<CostComparison[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    loadConfig();
    loadCostComparison();
  }, []);

  const loadConfig = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('wf-ai-mode-engine', {
        body: { action: 'get_config' }
      });
      if (error) throw error;
      setConfig(data.config);
      setCreditStatus(data.credit_status?.status || 'ok');
      setBudgetStatus(data.budget_status?.status || 'ok');
      setOpenaiAvailable(data.openai_available || false);
    } catch (err) {
      console.error('Failed to load AI mode config:', err);
      toast.error('Failed to load AI mode settings');
    } finally {
      setLoading(false);
    }
  };

  const loadCostComparison = async () => {
    try {
      const { data, error } = await supabase.functions.invoke('wf-ai-mode-engine', {
        body: { action: 'cost_comparison' }
      });
      if (error) throw error;
      setCostComparison(data.comparison || []);
    } catch (err) {
      console.error('Failed to load cost comparison:', err);
    }
  };

  const saveConfig = async (updates: Partial<AIModeConfig>) => {
    setSaving(true);
    try {
      const { data, error } = await supabase.functions.invoke('wf-ai-mode-engine', {
        body: { action: 'update_config', config_updates: updates }
      });
      if (error) throw error;
      setConfig(data.config);
      toast.success('AI mode settings saved');
    } catch (err) {
      console.error('Failed to save config:', err);
      toast.error('Failed to save settings');
    } finally {
      setSaving(false);
    }
  };

  const updateWorkspaceMode = (mode: string) => {
    if (!config) return;
    saveConfig({ workspace_mode: mode });
  };

  const updateFeatureMode = (feature: string, mode: string) => {
    if (!config) return;
    saveConfig({
      per_feature: { ...config.per_feature, [feature]: mode }
    });
  };

  const updateWorkerRate = (rate: number) => {
    if (!config) return;
    saveConfig({
      worker_costs: { ...config.worker_costs, default_hourly_rate: rate }
    });
  };

  const updateSafetyRule = (rule: string, value: boolean) => {
    if (!config) return;
    saveConfig({
      safety_rules: { ...config.safety_rules, [rule]: value }
    });
  };

  const getProviderForMode = (mode: string): string => {
    if (!config) return 'gateway';
    const modeDef = config.mode_definitions[mode];
    return modeDef?.provider || (mode === 'eco' ? 'openai' : mode === 'manual' ? 'manual' : 'gateway');
  };

  if (loading) {
    return (
      <Card>
        <CardContent className="p-8 text-center">
          <RefreshCw className="h-6 w-6 animate-spin mx-auto mb-2 text-muted-foreground" />
          <p className="text-sm text-muted-foreground">Loading AI mode settings...</p>
        </CardContent>
      </Card>
    );
  }

  if (!config) {
    return (
      <Card>
        <CardContent className="p-8 text-center">
          <AlertTriangle className="h-6 w-6 mx-auto mb-2 text-destructive" />
          <p className="text-sm text-muted-foreground">Failed to load configuration</p>
          <Button variant="outline" size="sm" onClick={loadConfig} className="mt-4">
            Retry
          </Button>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Status Banner */}
      <Card className={creditStatus !== 'ok' || budgetStatus !== 'ok' ? 'border-destructive' : ''}>
        <CardContent className="p-4">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div className="flex flex-wrap items-center gap-4">
              <div className="flex items-center gap-2">
                <span className="text-sm font-medium">Credit Status:</span>
                <Badge variant={creditStatus === 'ok' ? 'default' : 'destructive'}>
                  {creditStatus.toUpperCase()}
                </Badge>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-sm font-medium">Budget Status:</span>
                <Badge variant={budgetStatus === 'ok' ? 'default' : budgetStatus === 'warning' ? 'secondary' : 'destructive'}>
                  {budgetStatus.toUpperCase()}
                </Badge>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-sm font-medium">OpenAI:</span>
                <Badge variant={openaiAvailable ? 'default' : 'secondary'}>
                  {openaiAvailable ? <><CheckCircle2 className="h-3 w-3 mr-1" /> Connected</> : 'Not Configured'}
                </Badge>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-sm text-muted-foreground">Current Mode:</span>
              <Badge className={MODE_COLORS[config.workspace_mode as keyof typeof MODE_COLORS]}>
                {MODE_ICONS[config.workspace_mode as keyof typeof MODE_ICONS]}
                <span className="ml-1">{config.workspace_mode.toUpperCase()}</span>
                <span className="ml-1 opacity-70">({PROVIDER_LABELS[getProviderForMode(config.workspace_mode)]})</span>
              </Badge>
            </div>
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="modes">
        <TabsList>
          <TabsTrigger value="modes">AI Modes</TabsTrigger>
          <TabsTrigger value="costs">Cost Comparison</TabsTrigger>
          <TabsTrigger value="safety">Safety Rules</TabsTrigger>
          <TabsTrigger value="workers">Worker Costs</TabsTrigger>
        </TabsList>

        {/* AI Modes Tab */}
        <TabsContent value="modes" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Workspace Default Mode</CardTitle>
              <CardDescription>Default AI mode when no feature override is set</CardDescription>
            </CardHeader>
            <CardContent>
              <Select value={config.workspace_mode} onValueChange={updateWorkspaceMode}>
                <SelectTrigger className="w-64">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="eco">🌱 Eco (OpenAI - Cheapest)</SelectItem>
                  <SelectItem value="balanced">⚡ Balanced (AI Gateway)</SelectItem>
                  <SelectItem value="pro">👑 Pro (AI Gateway - Best Quality)</SelectItem>
                  <SelectItem value="manual">👤 Manual (Human Worker)</SelectItem>
                </SelectContent>
              </Select>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Per-Feature Overrides</CardTitle>
              <CardDescription>Set specific AI modes for each feature</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Feature</TableHead>
                    <TableHead>Mode</TableHead>
                    <TableHead>Provider</TableHead>
                    <TableHead>Model</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {Object.entries(config.per_feature).map(([feature, mode]) => (
                    <TableRow key={feature}>
                      <TableCell className="font-medium">{feature.replace(/_/g, ' ')}</TableCell>
                      <TableCell>
                        <Select value={mode} onValueChange={(v) => updateFeatureMode(feature, v)}>
                          <SelectTrigger className="w-40">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="eco">🌱 Eco</SelectItem>
                            <SelectItem value="balanced">⚡ Balanced</SelectItem>
                            <SelectItem value="pro">👑 Pro</SelectItem>
                            <SelectItem value="manual">👤 Manual</SelectItem>
                          </SelectContent>
                        </Select>
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline" className="text-xs">
                          {PROVIDER_LABELS[getProviderForMode(mode)]}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-sm text-muted-foreground">
                        {config.mode_definitions[mode]?.model || 'Human Worker'}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Cost Comparison Tab - V23.2 Updated */}
        <TabsContent value="costs">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <DollarSign className="h-5 w-5" />
                Cost Comparison Engine (V23.2)
              </CardTitle>
              <CardDescription>Compare OpenAI vs AI Gateway vs Worker vs Vendor costs per feature</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Feature</TableHead>
                    <TableHead>Current</TableHead>
                    <TableHead className="text-right">OpenAI (avg)</TableHead>
                    <TableHead className="text-right">AI Gateway (avg)</TableHead>
                    <TableHead className="text-right">Worker</TableHead>
                    <TableHead className="text-right">Vendor</TableHead>
                    <TableHead>Recommended</TableHead>
                    <TableHead className="text-right">Savings</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {costComparison.map((row) => (
                    <TableRow key={row.feature}>
                      <TableCell className="font-medium text-xs">{row.feature.replace(/_/g, ' ')}</TableCell>
                      <TableCell>
                        <Badge variant="outline" className={`text-xs ${MODE_COLORS[row.current_mode as keyof typeof MODE_COLORS]}`}>
                          {row.current_mode}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right text-xs">
                        ${row.ai_cost_openai.toFixed(4)}
                        <span className="text-muted-foreground ml-1">({row.openai_calls_30d})</span>
                      </TableCell>
                      <TableCell className="text-right text-xs">
                        ${row.ai_cost_gateway.toFixed(4)}
                        <span className="text-muted-foreground ml-1">({row.gateway_calls_30d})</span>
                      </TableCell>
                      <TableCell className="text-right text-xs">${row.worker_cost.toFixed(2)}</TableCell>
                      <TableCell className="text-right text-xs">
                        {row.vendor_cost !== null ? `$${row.vendor_cost.toFixed(2)}` : '—'}
                      </TableCell>
                      <TableCell>
                        <Badge variant={row.recommended === row.current_provider ? 'default' : 'secondary'} className="text-xs">
                          {row.recommended === 'openai' ? '🤖 OpenAI' : 
                           row.recommended === 'gateway' ? '🧠 AI Gateway' :
                           row.recommended === 'worker' ? '👤 Worker' : '🏢 Vendor'}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right text-green-600 text-xs">
                        {row.savings_potential > 0 ? `$${row.savings_potential.toFixed(4)}` : '—'}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
              <div className="mt-4 flex justify-end">
                <Button variant="outline" size="sm" onClick={loadCostComparison}>
                  <RefreshCw className="h-4 w-4 mr-2" />
                  Refresh
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Safety Rules Tab */}
        <TabsContent value="safety">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Automatic Safety Rules</CardTitle>
              <CardDescription>Control how the system responds to budget/credit issues</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <Label className="font-medium">Downgrade on Budget Warning (75%)</Label>
                  <p className="text-sm text-muted-foreground">
                    Automatically switch to Eco (OpenAI) mode when budget reaches 75%
                  </p>
                </div>
                <Switch
                  checked={config.safety_rules.downgrade_on_warning}
                  onCheckedChange={(v) => updateSafetyRule('downgrade_on_warning', v)}
                />
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <Label className="font-medium">Manual Mode on Critical (95%)</Label>
                  <p className="text-sm text-muted-foreground">
                    Route everything to human workers when budget is critical
                  </p>
                </div>
                <Switch
                  checked={config.safety_rules.manual_on_critical}
                  onCheckedChange={(v) => updateSafetyRule('manual_on_critical', v)}
                />
              </div>
              <div>
                <Label className="font-medium">Protected Features</Label>
                <p className="text-sm text-muted-foreground mb-2">
                  These features will never be downgraded automatically
                </p>
                <div className="flex flex-wrap gap-2">
                  {config.safety_rules.protected_features.map((f) => (
                    <Badge key={f} variant="outline">{f}</Badge>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Worker Costs Tab */}
        <TabsContent value="workers">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Worker Cost Configuration</CardTitle>
              <CardDescription>Set hourly rates and task durations for cost comparison</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div>
                <Label>Default Hourly Rate ($)</Label>
                <Input
                  type="number"
                  value={config.worker_costs.default_hourly_rate}
                  onChange={(e) => updateWorkerRate(parseFloat(e.target.value) || 25)}
                  className="w-32 mt-1"
                />
              </div>
              <div>
                <Label className="mb-2 block">Average Minutes per Task</Label>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Feature</TableHead>
                      <TableHead>Minutes</TableHead>
                      <TableHead>Estimated Cost</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {Object.entries(config.worker_costs.avg_minutes_per_task).map(([feature, minutes]) => (
                      <TableRow key={feature}>
                        <TableCell>{feature.replace(/_/g, ' ')}</TableCell>
                        <TableCell>{minutes} min</TableCell>
                        <TableCell>
                          ${((config.worker_costs.default_hourly_rate / 60) * minutes).toFixed(2)}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
