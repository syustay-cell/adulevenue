// src/components/motherboard/AutopilotControlWidget.tsx - Phase 6: AI Control Tower Widget

import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import type { WfAutopilotPolicy, SlaStatus, ScheduleType } from '@/types/controlTower';
import { WidgetCard } from './WidgetCard';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';
import { useTenant } from '@/hooks/useTenant';
import { getSlaStatus, upsertAutopilotPolicy } from '@/lib/controlTowerActions';
import { Settings2, Clock, AlertTriangle, CheckCircle2, XCircle, Zap } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { useState } from 'react';

const scheduleOptions: { value: ScheduleType; label: string }[] = [
  { value: 'hourly', label: 'Hourly' },
  { value: 'daily', label: 'Daily' },
  { value: 'weekly', label: 'Weekly' },
  { value: 'manual', label: 'Manual Only' },
];

const statusStyles = {
  ok: 'bg-emerald-500/10 text-emerald-600 border-emerald-500/30',
  warning: 'bg-amber-500/10 text-amber-600 border-amber-500/30',
  critical: 'bg-destructive/10 text-destructive border-destructive/30',
};

const statusIcons = {
  ok: <CheckCircle2 className="h-4 w-4 text-emerald-500" />,
  warning: <AlertTriangle className="h-4 w-4 text-amber-500" />,
  critical: <XCircle className="h-4 w-4 text-destructive" />,
};

export function AutopilotControlWidget() {
  const queryClient = useQueryClient();
  const { currentTenantId, loading: tenantLoading } = useTenant();
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState<Partial<WfAutopilotPolicy>>({});

  // Fetch policy
  const policyQuery = useQuery({
    queryKey: ['wf-autopilot-policy', currentTenantId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('wf_autopilot_policies')
        .select('*')
        .eq('tenant_id', currentTenantId!)
        .maybeSingle();

      if (error) throw error;
      return (data || null) as WfAutopilotPolicy | null;
    },
    staleTime: 30_000,
    enabled: !tenantLoading && !!currentTenantId,
  });

  // Fetch SLA status
  const slaQuery = useQuery({
    queryKey: ['wf-sla-status', currentTenantId],
    queryFn: async () => {
      return getSlaStatus(currentTenantId!);
    },
    staleTime: 30_000,
    enabled: !tenantLoading && !!currentTenantId,
  });

  // Mutation to save policy
  const saveMutation = useMutation({
    mutationFn: async (payload: Partial<WfAutopilotPolicy>) => {
      if (!currentTenantId) throw new Error('Missing tenant_id');
      return upsertAutopilotPolicy(currentTenantId, payload);
    },
    onSuccess: (result) => {
      if (result.ok) {
        queryClient.invalidateQueries({ queryKey: ['wf-autopilot-policy'] });
        toast.success('Autopilot policy saved.');
        setIsEditing(false);
      } else {
        toast.error(result.error || 'Failed to save policy.');
      }
    },
    onError: () => {
      toast.error('Failed to save policy.');
    },
  });

  // Toggle enabled
  const toggleMutation = useMutation({
    mutationFn: async (enabled: boolean) => {
      if (!currentTenantId) throw new Error('Missing tenant_id');
      return upsertAutopilotPolicy(currentTenantId, { autopilot_enabled: enabled });
    },
    onSuccess: (result) => {
      if (result.ok) {
        queryClient.invalidateQueries({ queryKey: ['wf-autopilot-policy'] });
        toast.success(result.policy?.autopilot_enabled ? 'Autopilot enabled.' : 'Autopilot disabled.');
      }
    },
  });

  const policy = policyQuery.data;
  const slaStatus = slaQuery.data;
  const isLoading = policyQuery.isLoading || slaQuery.isLoading || tenantLoading;

  const getListenText = () => {
    if (!policy) {
      return 'No autopilot policy configured. Click edit to set up automated runs and SLA thresholds.';
    }
    const enabled = policy.autopilot_enabled ? 'enabled' : 'disabled';
    const schedule = policy.schedule_type;
    const sla = slaStatus?.status || 'unknown';
    const lastAlert = slaStatus?.last_alert
      ? `Last alert was ${slaStatus.last_alert.severity} ${formatDistanceToNow(new Date(slaStatus.last_alert.created_at), { addSuffix: true })}.`
      : 'No recent alerts.';
    return `Autopilot is ${enabled}, schedule ${schedule}. SLA status is ${sla}. ${lastAlert}`;
  };

  const handleEdit = () => {
    setFormData({
      autopilot_enabled: policy?.autopilot_enabled ?? true,
      schedule_type: policy?.schedule_type ?? 'daily',
      schedule_time: policy?.schedule_time ?? '09:00',
      max_open_actions: policy?.max_open_actions ?? 50,
      max_critical_insights: policy?.max_critical_insights ?? 5,
      max_hours_since_last_run: policy?.max_hours_since_last_run ?? 48,
    });
    setIsEditing(true);
  };

  const handleSave = () => {
    saveMutation.mutate(formData);
  };

  return (
    <WidgetCard
      title="AI Control Tower"
      subtitle="Scheduler, SLAs & Alerts"
      onRefresh={() => {
        policyQuery.refetch();
        slaQuery.refetch();
      }}
      isLoading={isLoading}
      listenText={getListenText()}
    >
      {/* SLA Status Banner */}
      {slaStatus && (
        <div
          className={cn(
            'mb-3 flex items-center gap-2 rounded-lg border px-3 py-2 text-sm',
            statusStyles[slaStatus.status]
          )}
        >
          {statusIcons[slaStatus.status]}
          <span className="font-medium">SLA: {slaStatus.status.toUpperCase()}</span>
          <span className="ml-auto text-xs opacity-80">
            {slaStatus.open_actions} open • {slaStatus.critical_insights} critical •{' '}
            {slaStatus.hours_since_last_run != null
              ? `${slaStatus.hours_since_last_run}h ago`
              : 'No runs'}
          </span>
        </div>
      )}

      {!isEditing ? (
        <>
          {/* Policy display */}
          {policy ? (
            <div className="space-y-2 text-xs">
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Autopilot</span>
                <button
                  onClick={() => toggleMutation.mutate(!policy.autopilot_enabled)}
                  disabled={toggleMutation.isPending}
                  className={cn(
                    'rounded-full px-2.5 py-0.5 text-[10px] font-medium transition-colors',
                    policy.autopilot_enabled
                      ? 'bg-emerald-500/20 text-emerald-600'
                      : 'bg-muted text-muted-foreground'
                  )}
                >
                  {policy.autopilot_enabled ? 'Enabled' : 'Disabled'}
                </button>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Schedule</span>
                <span className="flex items-center gap-1">
                  <Clock className="h-3 w-3" />
                  {policy.schedule_type}
                  {policy.schedule_time && ` @ ${policy.schedule_time}`}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Max Open Actions</span>
                <span>{policy.max_open_actions ?? '—'}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Max Critical Insights</span>
                <span>{policy.max_critical_insights ?? '—'}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Max Hours Since Run</span>
                <span>{policy.max_hours_since_last_run ?? '—'}h</span>
              </div>
            </div>
          ) : (
            <p className="text-xs text-muted-foreground">
              No autopilot policy configured. Click Edit to set up.
            </p>
          )}

          <button
            onClick={handleEdit}
            className="mt-3 inline-flex items-center gap-1.5 rounded-md border border-primary/30 bg-primary/10 px-2.5 py-1.5 text-xs font-medium text-primary hover:bg-primary/20 transition-colors"
          >
            <Settings2 className="h-3.5 w-3.5" />
            Edit Policy
          </button>
        </>
      ) : (
        /* Edit form */
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <label className="text-xs text-muted-foreground">Enabled</label>
            <input
              type="checkbox"
              checked={formData.autopilot_enabled ?? true}
              onChange={(e) => setFormData({ ...formData, autopilot_enabled: e.target.checked })}
              className="h-4 w-4 rounded border-border accent-primary"
            />
          </div>

          <div>
            <label className="text-xs text-muted-foreground">Schedule</label>
            <select
              value={formData.schedule_type ?? 'daily'}
              onChange={(e) => setFormData({ ...formData, schedule_type: e.target.value as ScheduleType })}
              className="mt-1 block w-full rounded-md border border-border bg-background px-2 py-1.5 text-xs"
            >
              {scheduleOptions.map((opt) => (
                <option key={opt.value} value={opt.value}>
                  {opt.label}
                </option>
              ))}
            </select>
          </div>

          {formData.schedule_type === 'daily' && (
            <div>
              <label className="text-xs text-muted-foreground">Time (HH:MM)</label>
              <input
                type="text"
                value={formData.schedule_time ?? '09:00'}
                onChange={(e) => setFormData({ ...formData, schedule_time: e.target.value })}
                placeholder="09:00"
                className="mt-1 block w-full rounded-md border border-border bg-background px-2 py-1.5 text-xs"
              />
            </div>
          )}

          <div>
            <label className="text-xs text-muted-foreground">Max Open Actions</label>
            <input
              type="number"
              value={formData.max_open_actions ?? ''}
              onChange={(e) =>
                setFormData({ ...formData, max_open_actions: e.target.value ? Number(e.target.value) : null })
              }
              className="mt-1 block w-full rounded-md border border-border bg-background px-2 py-1.5 text-xs"
            />
          </div>

          <div>
            <label className="text-xs text-muted-foreground">Max Critical Insights</label>
            <input
              type="number"
              value={formData.max_critical_insights ?? ''}
              onChange={(e) =>
                setFormData({
                  ...formData,
                  max_critical_insights: e.target.value ? Number(e.target.value) : null,
                })
              }
              className="mt-1 block w-full rounded-md border border-border bg-background px-2 py-1.5 text-xs"
            />
          </div>

          <div>
            <label className="text-xs text-muted-foreground">Max Hours Since Last Run</label>
            <input
              type="number"
              value={formData.max_hours_since_last_run ?? ''}
              onChange={(e) =>
                setFormData({
                  ...formData,
                  max_hours_since_last_run: e.target.value ? Number(e.target.value) : null,
                })
              }
              className="mt-1 block w-full rounded-md border border-border bg-background px-2 py-1.5 text-xs"
            />
          </div>

          <div className="flex gap-2">
            <button
              onClick={handleSave}
              disabled={saveMutation.isPending}
              className="inline-flex items-center gap-1.5 rounded-md border border-emerald-500/60 bg-emerald-500/10 px-2.5 py-1.5 text-xs font-medium text-emerald-600 hover:bg-emerald-500/20 disabled:opacity-50"
            >
              <Zap className="h-3.5 w-3.5" />
              {saveMutation.isPending ? 'Saving…' : 'Save'}
            </button>
            <button
              onClick={() => setIsEditing(false)}
              className="inline-flex items-center gap-1 rounded-md border border-border bg-background px-2.5 py-1.5 text-xs text-muted-foreground hover:bg-muted"
            >
              Cancel
            </button>
          </div>
        </div>
      )}

      {/* Last alert */}
      {slaStatus?.last_alert && (
        <div className="mt-3 rounded-md border border-border bg-muted/40 p-2 text-xs">
          <div className="flex items-center gap-1.5 text-muted-foreground">
            <AlertTriangle className="h-3 w-3" />
            <span>Last alert:</span>
            <span className="font-medium text-foreground">{slaStatus.last_alert.title}</span>
          </div>
          <div className="mt-1 text-[10px] text-muted-foreground">
            {formatDistanceToNow(new Date(slaStatus.last_alert.created_at), { addSuffix: true })}
          </div>
        </div>
      )}
    </WidgetCard>
  );
}
