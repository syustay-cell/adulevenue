// src/components/motherboard/AIInsightsWidget.tsx - Phase 4: AI Insight Engine Widget

import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import type { WfInsight, WfInsightSeverity } from '@/types/insights';
import { WidgetCard } from './WidgetCard';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';
import { runAiInsightEngine } from '@/lib/insightActions';
import { useTenant } from '@/hooks/useTenant';
import { Sparkles } from 'lucide-react';

const severityStyles: Record<WfInsightSeverity, string> = {
  info: 'bg-muted text-muted-foreground border-border',
  warning: 'bg-amber-500/10 text-amber-600 border-amber-500/30',
  high: 'bg-orange-500/10 text-orange-600 border-orange-500/30',
  critical: 'bg-destructive/10 text-destructive border-destructive/30',
};

export function AIInsightsWidget() {
  const queryClient = useQueryClient();
  const { currentTenantId, loading: tenantLoading } = useTenant();

  const query = useQuery({
    queryKey: ['wf-insights', 'open', currentTenantId],
    queryFn: async () => {
      const baseQuery = supabase
        .from('wf_insights')
        .select('*')
        .eq('status', 'open')
        .order('created_at', { ascending: false })
        .limit(20);

      const { data, error } = currentTenantId
        ? await baseQuery.eq('tenant_id', currentTenantId)
        : await baseQuery;

      if (error) throw error;
      return (data || []) as WfInsight[];
    },
    staleTime: 30_000,
    enabled: !tenantLoading,
  });

  const updateMutation = useMutation({
    mutationFn: async ({ id, status }: { id: string; status: 'applied' | 'dismissed' }) => {
      const { error } = await supabase.from('wf_insights').update({ status }).eq('id', id);
      if (error) throw error;
    },
    onSuccess: (_, vars) => {
      queryClient.invalidateQueries({ queryKey: ['wf-insights'] });
      toast.success(
        vars.status === 'applied' ? 'Insight marked as applied.' : 'Insight dismissed.'
      );
    },
    onError: () => {
      toast.error('Failed to update insight status.');
    },
  });

  const runMutation = useMutation({
    mutationFn: async () => {
      if (!currentTenantId) throw new Error('Missing tenant_id');
      return runAiInsightEngine(currentTenantId);
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['wf-insights'] });
      if (data?.ok) {
        toast.success(
          `AI analyzed metrics and created ${data.inserted}/${data.found} insights.`
        );
      } else {
        toast.error(data?.error || 'AI insight engine failed.');
      }
    },
    onError: (err: Error) => {
      console.error('[AIInsightsWidget] run error:', err);
      toast.error('AI insight engine failed.');
    },
  });

  const getListenText = () => {
    if (!query.data || query.data.length === 0) {
      return 'No AI insights at this time. Your system is stable with no urgent recommendations.';
    }
    const first = query.data[0];
    return `Top AI insight: ${first.title}. Category: ${first.category}. Severity: ${first.severity}.`;
  };

  const isLoading = query.isLoading || runMutation.isPending || tenantLoading;

  return (
    <WidgetCard
      title="AI Insight Engine"
      subtitle="AI recommendations based on live metrics"
      onRefresh={() => query.refetch()}
      isLoading={isLoading}
      listenText={getListenText()}
    >
      {/* Run AI Insights button */}
      <div className="mb-3">
        <button
          onClick={() => runMutation.mutate()}
          disabled={runMutation.isPending || !currentTenantId}
          className={cn(
            'inline-flex items-center gap-1.5 rounded-md border px-2.5 py-1.5 text-xs font-medium',
            'border-primary/30 bg-primary/10 text-primary',
            'hover:bg-primary/20 disabled:opacity-50 transition-colors'
          )}
        >
          <Sparkles className="h-3.5 w-3.5" />
          {runMutation.isPending ? 'Running…' : 'Run AI Insights'}
        </button>
      </div>

      {!isLoading && query.data && query.data.length === 0 && (
        <p className="text-xs text-muted-foreground">
          No open AI insights. You are fully caught up.
        </p>
      )}

      {!isLoading && query.data && query.data.length > 0 && (
        <div className="space-y-2">
          {query.data.map((insight) => (
            <div
              key={insight.id}
              className={cn(
                'rounded-lg border p-2.5 text-xs',
                severityStyles[insight.severity ?? 'info']
              )}
            >
              <div className="mb-1 flex items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <span className="rounded-md bg-background/70 px-1.5 py-0.5 text-[10px] uppercase tracking-wide">
                    {insight.category}
                  </span>
                  <span className="text-[10px] uppercase opacity-70">
                    {insight.scope} insight
                  </span>
                </div>
                <span className="text-[10px] opacity-70">
                  {new Date(insight.created_at).toLocaleDateString()}
                </span>
              </div>
              <div className="font-medium leading-tight">{insight.title}</div>
              {insight.body && (
                <p className="mt-1 text-[11px] leading-snug opacity-80">{insight.body}</p>
              )}
              <div className="mt-2 flex flex-wrap items-center justify-between gap-2">
                <div className="flex gap-2 text-[10px] opacity-80">
                  {insight.impact_score != null && (
                    <span>Impact: {Math.round(insight.impact_score)}/100</span>
                  )}
                  {insight.confidence_score != null && (
                    <span>Confidence: {Math.round(insight.confidence_score)}/100</span>
                  )}
                </div>
                <div className="flex gap-1.5">
                  <button
                    onClick={() =>
                      updateMutation.mutate({ id: insight.id, status: 'applied' })
                    }
                    disabled={updateMutation.isPending}
                    className="inline-flex items-center gap-1 rounded-md border border-emerald-500/60 bg-emerald-500/10 px-2 py-0.5 text-[10px] font-medium text-emerald-600 hover:bg-emerald-500/20 disabled:opacity-50"
                  >
                    Apply
                  </button>
                  <button
                    onClick={() =>
                      updateMutation.mutate({ id: insight.id, status: 'dismissed' })
                    }
                    disabled={updateMutation.isPending}
                    className="inline-flex items-center gap-1 rounded-md border border-border bg-background/60 px-2 py-0.5 text-[10px] text-muted-foreground hover:bg-muted disabled:opacity-50"
                  >
                    Dismiss
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </WidgetCard>
  );
}
