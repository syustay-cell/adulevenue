import { useEffect, useState } from 'react';
import { Badge } from '@/components/ui/badge';
import { Leaf, Zap, Crown, User, AlertTriangle } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';

interface AIModeBadgeProps {
  feature?: string;
  className?: string;
}

const MODE_CONFIG = {
  eco: { icon: Leaf, label: 'ECO', color: 'bg-green-500/10 text-green-600 border-green-500/20' },
  balanced: { icon: Zap, label: 'BALANCED', color: 'bg-blue-500/10 text-blue-600 border-blue-500/20' },
  pro: { icon: Crown, label: 'PRO', color: 'bg-purple-500/10 text-purple-600 border-purple-500/20' },
  manual: { icon: User, label: 'MANUAL', color: 'bg-orange-500/10 text-orange-600 border-orange-500/20' }
};

const PROVIDER_LABELS: Record<string, string> = {
  openai: 'OpenAI',
  gateway: 'AI Gateway',
  manual: 'Human'
};

export function AIModeBadge({ feature, className = '' }: AIModeBadgeProps) {
  const [mode, setMode] = useState<string>('balanced');
  const [provider, setProvider] = useState<string>('gateway');
  const [source, setSource] = useState<string>('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadMode();
  }, [feature]);

  const loadMode = async () => {
    try {
      const { data, error } = await supabase.functions.invoke('wf-ai-mode-engine', {
        body: { action: 'get_mode', feature: feature || 'default' }
      });
      if (!error && data?.mode) {
        setMode(data.mode.name);
        setProvider(data.mode.provider || 'gateway');
        setSource(data.mode.source);
      }
    } catch (err) {
      console.warn('Failed to load AI mode:', err);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return null;
  }

  const config = MODE_CONFIG[mode as keyof typeof MODE_CONFIG] || MODE_CONFIG.balanced;
  const Icon = config.icon;
  const isDowngraded = source === 'safety_downgrade' || source === 'manual_fallback';

  return (
    <Badge variant="outline" className={`${config.color} ${className}`}>
      {isDowngraded && <AlertTriangle className="h-3 w-3 mr-1" />}
      <Icon className="h-3 w-3 mr-1" />
      AI: {config.label}
      <span className="ml-1 opacity-70 text-xs">({PROVIDER_LABELS[provider] || provider})</span>
    </Badge>
  );
}
