import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { WidgetCard } from './WidgetCard';
import type { WfSuggestion } from '@/types/events';
import { cn } from '@/lib/utils';
import { Check, X } from 'lucide-react';
import { toast } from 'sonner';

const severityStyles: Record<string, string> = {
  info: 'bg-muted text-muted-foreground',
  warning: 'bg-amber-500/10 text-amber-600 border-amber-500/30',
  high: 'bg-orange-500/10 text-orange-600 border-orange-500/30',
  critical: 'bg-destructive/10 text-destructive border-destructive/30',
};

export function SuggestionsWidget() {
  const queryClient = useQueryClient();

  const query = useQuery({
    queryKey: ['wf-suggestions', 'open'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('wf_suggestions')
        .select('*')
        .eq('status', 'open')
        .order('created_at', { ascending: false })
        .limit(20);

      if (error) throw error;
      return (data || []) as WfSuggestion[];
    },
    staleTime: 30_000,
  });

  const mutation = useMutation({
    mutationFn: async ({
      id,
      status,
    }: {
      id: string;
      status: 'dismissed' | 'applied';
    }) => {
      const { error } = await supabase
        .from('wf_suggestions')
        .update({ status })
        .eq('id', id);
      if (error) throw error;
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ['wf-suggestions'] });
      toast.success(
        variables.status === 'applied'
          ? 'Suggestion marked as applied'
          : 'Suggestion dismissed'
      );
    },
    onError: () => {
      toast.error('Failed to update suggestion');
    },
  });

  const getListenText = () => {
    if (!query.data || query.data.length === 0) {
      return 'No open suggestions at this time.';
    }
    const first = query.data[0];
    return `Top suggestion: ${first.title}. Category: ${first.category}. Severity: ${first.severity}.`;
  };

  return (
    <WidgetCard
      title="Suggestions"
      subtitle="System recommendations and next actions"
      onRefresh={() => query.refetch()}
      listenText={getListenText()}
      isLoading={query.isLoading}
    >
      {!query.isLoading && query.data && query.data.length === 0 && (
        <div className="text-xs text-muted-foreground">
          No open suggestions. You are fully caught up.
        </div>
      )}

      {!query.isLoading && query.data && query.data.length > 0 && (
        <div className="space-y-2.5 max-h-[280px] overflow-y-auto pr-1">
          {query.data.map((s) => (
            <div
              key={s.id}
              className="rounded-lg border border-border/50 bg-muted/40 p-2.5"
            >
              <div className="flex items-center justify-between gap-2">
                <div className="flex items-center gap-1.5">
                  <span className="text-[10px] uppercase tracking-wide text-muted-foreground">
                    {s.category}
                  </span>
                  <span
                    className={cn(
                      'inline-flex items-center rounded-full px-2 py-0.5 text-[10px] font-medium border',
                      severityStyles[s.severity] || severityStyles.info
                    )}
                  >
                    {s.severity}
                  </span>
                </div>
                <span className="text-[10px] text-muted-foreground">
                  {new Date(s.created_at).toLocaleDateString()}
                </span>
              </div>
              <div className="mt-1 text-xs font-medium">{s.title}</div>
              {s.body && (
                <div className="mt-0.5 text-[11px] text-muted-foreground line-clamp-3">
                  {s.body}
                </div>
              )}
              <div className="mt-2 flex items-center gap-2">
                <button
                  onClick={() => mutation.mutate({ id: s.id, status: 'applied' })}
                  disabled={mutation.isPending}
                  className="inline-flex items-center gap-1 rounded-md border border-emerald-500/60 bg-emerald-500/10 px-2.5 py-1 text-[11px] font-medium text-emerald-600 hover:bg-emerald-500/20 disabled:opacity-50"
                >
                  <Check className="h-3 w-3" />
                  Apply
                </button>
                <button
                  onClick={() => mutation.mutate({ id: s.id, status: 'dismissed' })}
                  disabled={mutation.isPending}
                  className="inline-flex items-center gap-1 rounded-md border border-border px-2.5 py-1 text-[11px] text-muted-foreground hover:bg-muted disabled:opacity-50"
                >
                  <X className="h-3 w-3" />
                  Dismiss
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </WidgetCard>
  );
}
