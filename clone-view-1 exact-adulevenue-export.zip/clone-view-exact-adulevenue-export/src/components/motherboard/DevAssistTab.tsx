import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { toast } from "sonner";
import { 
  AlertTriangle, CheckCircle, Code, FileText, Shield, DollarSign, 
  RefreshCw, ExternalLink, Check, X, BookOpen, Loader2
} from "lucide-react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { 
  logDevSuggestionEvent, 
  fetchDevSuggestionEvents,
  DevSuggestionArea,
  logGovernanceAction
} from "@/core/governance";
import { useNavigate } from "react-router-dom";

interface DevAutopilotSignals {
  unpriced_events: string[];
  unplaybooked_routes: string[];
  unregistered_ip_assets: Array<{ key: string; reason: string }>;
  flows_without_sop: Array<{ brand: string; flow_id: string; name: string }>;
}

interface DevSuggestion {
  id: string;
  title: string;
  area: string;
  severity: string;
  summary: string;
  actions: Array<{ label: string; type: string; target: string }>;
  source_check_id: string;
}

interface Props {
  tenantId: string;
}

export function DevAssistTab({ tenantId }: Props) {
  const queryClient = useQueryClient();
  const navigate = useNavigate();
  const [currentUserId, setCurrentUserId] = useState<string | null>(null);
  const [devSignals, setDevSignals] = useState<DevAutopilotSignals | null>(null);
  const [devSuggestions, setDevSuggestions] = useState<DevSuggestion[]>([]);
  const [scanning, setScanning] = useState(false);

  useEffect(() => {
    supabase.auth.getUser().then(({ data }) => {
      setCurrentUserId(data.user?.id || null);
    });
  }, []);

  // Fetch dev suggestion events history
  const { data: eventHistory = [] } = useQuery({
    queryKey: ["dev-suggestion-events", tenantId],
    queryFn: () => fetchDevSuggestionEvents(tenantId, 20),
    enabled: !!tenantId,
  });

  // Run dev scan
  const runDevScan = async () => {
    setScanning(true);
    try {
      const { data, error } = await supabase.functions.invoke("wf-governance-scan", {
        body: { tenant_id: tenantId },
      });

      if (error) throw error;
      if (!data.ok) throw new Error(data.error);

      // Extract dev autopilot signals
      const signals = data.signals?.dev_autopilot || {
        unpriced_events: [],
        unplaybooked_routes: [],
        unregistered_ip_assets: [],
        flows_without_sop: [],
      };
      setDevSignals(signals);

      // Filter suggestions for dev-related items
      const allSuggestions = data.suggestions || [];
      const devRelated = allSuggestions.filter((s: DevSuggestion) => 
        s.id.startsWith("suggestion.dev.") || 
        s.area === "billing" || 
        s.area === "ip" || 
        s.area === "ai_change"
      );
      setDevSuggestions(devRelated);

      toast.success("Dev scan complete");
    } catch (err: any) {
      toast.error(`Dev scan failed: ${err.message}`);
    } finally {
      setScanning(false);
    }
  };

  // Log suggestion action mutation
  const logActionMutation = useMutation({
    mutationFn: async (params: { suggestion: DevSuggestion; action: "opened" | "applied" | "ignored" }) => {
      const area = params.suggestion.area as DevSuggestionArea;
      await logDevSuggestionEvent({
        tenant_id: tenantId,
        suggestion_id: params.suggestion.id,
        action: params.action,
        area: ["billing", "ip", "playbook", "defense", "ai_change"].includes(area) ? area : "ai_change",
        source_check_id: params.suggestion.source_check_id,
        performed_by: currentUserId || undefined,
        metadata: { title: params.suggestion.title },
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["dev-suggestion-events", tenantId] });
    },
    onError: (err: any) => {
      toast.error(`Failed to log action: ${err.message}`);
    },
  });

  // V20 Fix: Real remediation logic
  const handleRemediation = async (suggestion: DevSuggestion, actionTarget: string) => {
    try {
      let actionNotes = "";
      let newState: Record<string, any> = {};

      // Handle different remediation targets with real actions
      if (actionTarget === "dev.unpriced_events.handled") {
        // Create a governance action TODO for billing team
        actionNotes = `Flagged unpriced events for billing review: ${devSignals?.unpriced_events?.join(", ") || "N/A"}`;
        newState = { flagged_events: devSignals?.unpriced_events || [] };
        
        await logGovernanceAction({
          tenant_id: tenantId,
          action_type: "flag_unpriced_events",
          source_check_id: suggestion.source_check_id,
          performed_by: currentUserId || undefined,
          notes: actionNotes,
        });
      } else if (actionTarget === "dev.unplaybooked_routes.handled") {
        // Create stub playbook entries for unplaybooked routes
        actionNotes = `Created TODO for playbook coverage: ${devSignals?.unplaybooked_routes?.slice(0, 5).join(", ") || "N/A"}`;
        newState = { routes_to_add: devSignals?.unplaybooked_routes || [] };
        
        await logGovernanceAction({
          tenant_id: tenantId,
          action_type: "flag_unplaybooked_routes",
          source_check_id: suggestion.source_check_id,
          performed_by: currentUserId || undefined,
          notes: actionNotes,
        });
      } else if (actionTarget === "dev.unregistered_ip_assets.handled") {
        // Create IP registration tasks
        const assetsToRegister = devSignals?.unregistered_ip_assets || [];
        actionNotes = `Created IP registration backlog: ${assetsToRegister.map(a => a.key).join(", ")}`;
        newState = { assets_to_register: assetsToRegister };
        
        await logGovernanceAction({
          tenant_id: tenantId,
          action_type: "create_ip_backlog",
          source_check_id: suggestion.source_check_id,
          performed_by: currentUserId || undefined,
          notes: actionNotes,
        });
      } else if (actionTarget === "dev.flows_without_sop.handled") {
        // Create SOP backlog entries
        const flowsToDocument = devSignals?.flows_without_sop || [];
        actionNotes = `Created SOP documentation backlog: ${flowsToDocument.slice(0, 3).map(f => f.name).join(", ")}`;
        newState = { flows_needing_sop: flowsToDocument };
        
        await logGovernanceAction({
          tenant_id: tenantId,
          action_type: "create_sop_backlog",
          source_check_id: suggestion.source_check_id,
          performed_by: currentUserId || undefined,
          notes: actionNotes,
        });
      }

      return newState;
    } catch (err: any) {
      console.error("Remediation failed:", err);
      throw err;
    }
  };

  const handleSuggestionAction = async (
    suggestion: DevSuggestion, 
    actionType: "opened" | "applied" | "ignored", 
    navigateTarget?: string,
    remediationTarget?: string
  ) => {
    // If it's a remediation action, perform the real remediation first
    if (actionType === "applied" && remediationTarget) {
      try {
        await handleRemediation(suggestion, remediationTarget);
        toast.success("Action completed and logged to governance backlog");
      } catch (err: any) {
        toast.error(`Remediation failed: ${err.message}`);
        return;
      }
    }
    
    await logActionMutation.mutateAsync({ suggestion, action: actionType });
    
    if (actionType === "opened" && navigateTarget) {
      // Use React Router for internal navigation
      if (navigateTarget.startsWith("/")) {
        navigate(navigateTarget);
      } else {
        window.location.href = navigateTarget;
      }
    } else if (actionType === "applied" || actionType === "ignored") {
      toast.success(`Suggestion marked as ${actionType}`);
      // Remove from local suggestions list
      setDevSuggestions((prev) => prev.filter((s) => s.id !== suggestion.id));
    }
  };

  const getAreaIcon = (area: string) => {
    switch (area) {
      case "billing": return <DollarSign className="h-4 w-4" />;
      case "ip": return <Shield className="h-4 w-4" />;
      case "ai_change": return <Code className="h-4 w-4" />;
      case "playbook": return <BookOpen className="h-4 w-4" />;
      default: return <FileText className="h-4 w-4" />;
    }
  };

  const getAreaColor = (area: string) => {
    switch (area) {
      case "billing": return "bg-yellow-500/10 text-yellow-600 border-yellow-500/20";
      case "ip": return "bg-blue-500/10 text-blue-600 border-blue-500/20";
      case "ai_change": return "bg-purple-500/10 text-purple-600 border-purple-500/20";
      case "playbook": return "bg-orange-500/10 text-orange-600 border-orange-500/20";
      default: return "bg-muted text-muted-foreground";
    }
  };

  const getActionIcon = (action: string) => {
    switch (action) {
      case "applied": return <Check className="h-3 w-3 text-green-500" />;
      case "ignored": return <X className="h-3 w-3 text-muted-foreground" />;
      case "opened": return <ExternalLink className="h-3 w-3 text-blue-500" />;
      default: return <FileText className="h-3 w-3" />;
    }
  };

  const formatDateTime = (dateStr: string) => {
    const date = new Date(dateStr);
    return date.toLocaleString(undefined, { 
      month: "short", 
      day: "numeric", 
      hour: "2-digit", 
      minute: "2-digit" 
    });
  };

  const totalDevIssues = devSignals 
    ? devSignals.unpriced_events.length + 
      devSignals.unplaybooked_routes.length + 
      devSignals.unregistered_ip_assets.length + 
      devSignals.flows_without_sop.length
    : 0;

  return (
    <div className="space-y-6">
      {/* Dev Health Summary Strip */}
      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <Code className="h-5 w-5" />
                Dev Autopilot
              </CardTitle>
              <CardDescription>
                Engineering reminders and governance suggestions
              </CardDescription>
            </div>
            <Button onClick={runDevScan} disabled={scanning}>
              {scanning ? (
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
              ) : (
                <RefreshCw className="h-4 w-4 mr-2" />
              )}
              Refresh Dev To-Dos
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {devSignals ? (
            <div className="flex flex-wrap gap-3">
              <Badge variant="outline" className={devSignals.unpriced_events.length > 0 ? "border-yellow-500 text-yellow-600" : "border-green-500 text-green-600"}>
                <DollarSign className="h-3 w-3 mr-1" />
                {devSignals.unpriced_events.length} unpriced events
              </Badge>
              <Badge variant="outline" className={devSignals.unplaybooked_routes.length > 0 ? "border-purple-500 text-purple-600" : "border-green-500 text-green-600"}>
                <BookOpen className="h-3 w-3 mr-1" />
                {devSignals.unplaybooked_routes.length} routes not in playbooks
              </Badge>
              <Badge variant="outline" className={devSignals.unregistered_ip_assets.length > 0 ? "border-blue-500 text-blue-600" : "border-green-500 text-green-600"}>
                <Shield className="h-3 w-3 mr-1" />
                {devSignals.unregistered_ip_assets.length} assets not in IP Guardian
              </Badge>
              <Badge variant="outline" className={devSignals.flows_without_sop.length > 0 ? "border-orange-500 text-orange-600" : "border-green-500 text-green-600"}>
                <FileText className="h-3 w-3 mr-1" />
                {devSignals.flows_without_sop.length} flows missing SOP
              </Badge>
            </div>
          ) : (
            <p className="text-sm text-muted-foreground">Run a dev scan to see current status</p>
          )}
        </CardContent>
      </Card>

      {/* Dev To-Do List */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <AlertTriangle className="h-5 w-5" />
            Dev To-Dos
            {devSuggestions.length > 0 && (
              <Badge variant="secondary">{devSuggestions.length}</Badge>
            )}
          </CardTitle>
          <CardDescription>
            Actionable items from governance scan
          </CardDescription>
        </CardHeader>
        <CardContent>
          <ScrollArea className="h-[400px]">
            {devSuggestions.length > 0 ? (
              <div className="space-y-3">
                {devSuggestions.map((suggestion) => (
                  <div
                    key={suggestion.id}
                    className={`p-4 rounded-lg border ${getAreaColor(suggestion.area)}`}
                  >
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          {getAreaIcon(suggestion.area)}
                          <Badge variant="outline" className="text-xs">
                            {suggestion.area}
                          </Badge>
                          {suggestion.severity === "warn" && (
                            <Badge variant="outline" className="text-xs border-yellow-500 text-yellow-600">
                              Warning
                            </Badge>
                          )}
                          {suggestion.severity === "critical" && (
                            <Badge variant="outline" className="text-xs border-red-500 text-red-600">
                              Critical
                            </Badge>
                          )}
                        </div>
                        <h4 className="font-medium">{suggestion.title}</h4>
                        <p className="text-sm text-muted-foreground mt-1">
                          {suggestion.summary}
                        </p>
                      </div>
                      <div className="flex flex-col gap-2">
                        {suggestion.actions.map((action, idx) => (
                          <Button
                            key={idx}
                            size="sm"
                            variant={action.type === "navigate" ? "default" : "outline"}
                            onClick={() => handleSuggestionAction(
                              suggestion,
                              action.type === "navigate" ? "opened" : "applied",
                              action.type === "navigate" ? action.target : undefined,
                              action.type === "remediate" ? action.target : undefined
                            )}
                          >
                            {action.type === "navigate" ? (
                              <ExternalLink className="h-3 w-3 mr-1" />
                            ) : (
                              <Check className="h-3 w-3 mr-1" />
                            )}
                            {action.label}
                          </Button>
                        ))}
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => handleSuggestionAction(suggestion, "ignored")}
                        >
                          <X className="h-3 w-3 mr-1" />
                          Ignore
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center py-12 text-center">
                <CheckCircle className="h-12 w-12 text-green-500 mb-4" />
                <h3 className="font-medium">All Clear!</h3>
                <p className="text-sm text-muted-foreground">
                  No dev to-dos at the moment. Run a scan to check for new items.
                </p>
              </div>
            )}
          </ScrollArea>
        </CardContent>
      </Card>

      {/* Recent Actions History */}
      <Card>
        <CardHeader>
          <CardTitle className="text-sm font-medium">Recent Dev Actions</CardTitle>
        </CardHeader>
        <CardContent>
          {eventHistory.length > 0 ? (
            <ScrollArea className="h-[200px]">
              <div className="space-y-2">
                {eventHistory.slice(0, 10).map((event) => (
                  <div
                    key={event.id}
                    className="flex items-center justify-between py-2 px-3 bg-muted/50 rounded text-sm"
                  >
                    <div className="flex items-center gap-2">
                      {getActionIcon(event.action)}
                      <Badge variant="outline" className="text-xs">{event.area}</Badge>
                      <span className="text-muted-foreground truncate max-w-[200px]">
                        {(event.metadata as any)?.title || event.suggestion_id}
                      </span>
                    </div>
                    <span className="text-xs text-muted-foreground whitespace-nowrap">
                      {formatDateTime(event.performed_at)}
                    </span>
                  </div>
                ))}
              </div>
            </ScrollArea>
          ) : (
            <p className="text-sm text-muted-foreground text-center py-4">
              No recent dev actions recorded
            </p>
          )}
        </CardContent>
      </Card>
    </div>
  );
}