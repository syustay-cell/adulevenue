// src/components/motherboard/AutopilotWidget.tsx - Phase 5: AI Autopilot Engine Widget

import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import type { WfAutopilotRun, WfAutopilotAction, WfAutopilotActionSeverity } from '@/types/autopilot';
import { WidgetCard } from './WidgetCard';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';
import { runAiAutopilotEngine } from '@/lib/autopilotActions';
import { useTenant } from '@/hooks/useTenant';
import { Bot, CheckCircle2, XCircle, Clock, AlertTriangle, Zap } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';

const severityStyles: Record<WfAutopilotActionSeverity, string> = {
  info: 'bg-muted text-muted-foreground border-border',
  warning: 'bg-amber-500/10 text-amber-600 border-amber-500/30',
  high: 'bg-orange-500/10 text-orange-600 border-orange-500/30',
  critical: 'bg-destructive/10 text-destructive border-destructive/30',
};

const statusIcons: Record<string, React.ReactNode> = {
  running: <Clock className="h-3.5 w-3.5 animate-spin text-primary" />,
  success: <CheckCircle2 className="h-3.5 w-3.5 text-emerald-500" />,
  partial: <AlertTriangle className="h-3.5 w-3.5 text-amber-500" />,
  failed: <XCircle className="h-3.5 w-3.5 text-destructive" />,
};

export function AutopilotWidget() {
  const queryClient = useQueryClient();
  const { currentTenantId, loading: tenantLoading } = useTenant();

  // Fetch latest autopilot run
  const runsQuery = useQuery({
    queryKey: ['wf-autopilot-runs', currentTenantId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('wf_autopilot_runs')
        .select('*')
        .eq('tenant_id', currentTenantId!)
        .order('started_at', { ascending: false })
        .limit(1);

      if (error) throw error;
      return (data?.[0] || null) as WfAutopilotRun | null;
    },
    staleTime: 30_000,
    enabled: !tenantLoading && !!currentTenantId,
  });

  // Fetch open autopilot actions
  const actionsQuery = useQuery({
    queryKey: ['wf-autopilot-actions', 'open', currentTenantId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('wf_autopilot_actions')
        .select('*')
        .eq('tenant_id', currentTenantId!)
        .eq('status', 'open')
        .order('created_at', { ascending: false })
        .limit(5);

      if (error) throw error;
      return (data || []) as WfAutopilotAction[];
    },
    staleTime: 30_000,
    enabled: !tenantLoading && !!currentTenantId,
  });

  // Count actions by status
  const countsQuery = useQuery({
    queryKey: ['wf-autopilot-actions-counts', currentTenantId],
    queryFn: async () => {
      const [openRes, doneRes] = await Promise.all([
        supabase
          .from('wf_autopilot_actions')
          .select('*', { count: 'exact', head: true })
          .eq('tenant_id', currentTenantId!)
          .eq('status', 'open'),
        supabase
          .from('wf_autopilot_actions')
          .select('*', { count: 'exact', head: true })
          .eq('tenant_id', currentTenantId!)
          .eq('status', 'done'),
      ]);
      return {
        open: openRes.count ?? 0,
        done: doneRes.count ?? 0,
      };
    },
    staleTime: 30_000,
    enabled: !tenantLoading && !!currentTenantId,
  });

  // Update action status
  const updateActionMutation = useMutation({
    mutationFn: async ({ id, status }: { id: string; status: 'done' | 'dismissed' }) => {
      const { error } = await supabase
        .from('wf_autopilot_actions')
        .update({ status })
        .eq('id', id);
      if (error) throw error;
    },
    onSuccess: (_, vars) => {
      queryClient.invalidateQueries({ queryKey: ['wf-autopilot-actions'] });
      queryClient.invalidateQueries({ queryKey: ['wf-autopilot-actions-counts'] });
      toast.success(vars.status === 'done' ? 'Action completed.' : 'Action dismissed.');
    },
    onError: () => {
      toast.error('Failed to update action status.');
    },
  });

  // Run autopilot engine
  const runMutation = useMutation({
    mutationFn: async () => {
      if (!currentTenantId) throw new Error('Missing tenant_id');
      return runAiAutopilotEngine(currentTenantId);
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['wf-autopilot-runs'] });
      queryClient.invalidateQueries({ queryKey: ['wf-autopilot-actions'] });
      queryClient.invalidateQueries({ queryKey: ['wf-autopilot-actions-counts'] });
      if (data?.ok) {
        toast.success(
          `Autopilot created ${data.total_actions} actions from ${data.total_insights} insights.`
        );
      } else {
        toast.error(data?.error || 'Autopilot engine failed.');
      }
    },
    onError: (err: Error) => {
      console.error('[AutopilotWidget] run error:', err);
      toast.error('Autopilot engine failed.');
    },
  });

  const getListenText = () => {
    const lastRun = runsQuery.data;
    const counts = countsQuery.data;
    if (!lastRun) {
      return 'No autopilot runs yet. Click Run Autopilot to start the AI operations co-pilot.';
    }
    const timeAgo = formatDistanceToNow(new Date(lastRun.started_at), { addSuffix: true });
    return `Last autopilot run ${timeAgo}. Status: ${lastRun.status}. Created ${lastRun.total_actions} actions. Currently ${counts?.open || 0} open actions.`;
  };

  const isLoading = runsQuery.isLoading || actionsQuery.isLoading || runMutation.isPending || tenantLoading;
  const lastRun = runsQuery.data;
  const actions = actionsQuery.data || [];
  const counts = countsQuery.data || { open: 0, done: 0 };

  return (
    <WidgetCard
      title="AI Autopilot"
      subtitle="Self-running operations co-pilot"
      onRefresh={() => {
        runsQuery.refetch();
        actionsQuery.refetch();
        countsQuery.refetch();
      }}
      isLoading={isLoading}
      listenText={getListenText()}
    >
      {/* Run Autopilot button */}
      <div className="mb-3 flex items-center justify-between gap-2">
        <button
          onClick={() => runMutation.mutate()}
          disabled={runMutation.isPending || !currentTenantId}
          className={cn(
            'inline-flex items-center gap-1.5 rounded-md border px-2.5 py-1.5 text-xs font-medium',
            'border-primary/30 bg-primary/10 text-primary',
            'hover:bg-primary/20 disabled:opacity-50 transition-colors'
          )}
        >
          <Zap className="h-3.5 w-3.5" />
          {runMutation.isPending ? 'Running…' : 'Run Autopilot'}
        </button>

        {/* Status counts */}
        <div className="flex items-center gap-3 text-[10px]">
          <span className="flex items-center gap-1 text-muted-foreground">
            <Bot className="h-3 w-3" />
            <span className="font-medium text-foreground">{counts.open}</span> open
          </span>
          <span className="flex items-center gap-1 text-muted-foreground">
            <CheckCircle2 className="h-3 w-3 text-emerald-500" />
            <span className="font-medium text-foreground">{counts.done}</span> done
          </span>
        </div>
      </div>

      {/* Last run status */}
      {lastRun && (
        <div className="mb-3 flex items-center gap-2 rounded-md border border-border bg-muted/40 px-2.5 py-2 text-[11px]">
          {statusIcons[lastRun.status]}
          <span className="font-medium">Last run:</span>
          <span className="text-muted-foreground">
            {formatDistanceToNow(new Date(lastRun.started_at), { addSuffix: true })}
          </span>
          <span className="ml-auto text-muted-foreground">
            {lastRun.total_actions} actions • {lastRun.total_tags} tags
          </span>
        </div>
      )}

      {/* Open actions list */}
      {actions.length === 0 && !isLoading && (
        <p className="text-xs text-muted-foreground">
          No open autopilot actions. Run the engine to generate new tasks.
        </p>
      )}

      {actions.length > 0 && (
        <div className="space-y-2">
          {actions.map((action) => (
            <div
              key={action.id}
              className={cn(
                'rounded-lg border p-2.5 text-xs',
                severityStyles[(action.severity as WfAutopilotActionSeverity) ?? 'info']
              )}
            >
              <div className="mb-1 flex items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <span className="rounded-md bg-background/70 px-1.5 py-0.5 text-[10px] uppercase tracking-wide">
                    {action.category}
                  </span>
                  <span className="text-[10px] uppercase opacity-70">
                    {action.scope}
                  </span>
                </div>
                <span className="text-[10px] opacity-70">
                  {new Date(action.created_at).toLocaleDateString()}
                </span>
              </div>
              <div className="font-medium leading-tight">{action.title}</div>
              {action.body && (
                <p className="mt-1 text-[11px] leading-snug opacity-80 line-clamp-2">{action.body}</p>
              )}
              <div className="mt-2 flex flex-wrap items-center justify-between gap-2">
                <div className="flex gap-2 text-[10px] opacity-80">
                  {action.impact_score != null && (
                    <span>Impact: {Math.round(action.impact_score)}/100</span>
                  )}
                  {action.confidence_score != null && (
                    <span>Confidence: {Math.round(action.confidence_score)}/100</span>
                  )}
                </div>
                <div className="flex gap-1.5">
                  <button
                    onClick={() => updateActionMutation.mutate({ id: action.id, status: 'done' })}
                    disabled={updateActionMutation.isPending}
                    className="inline-flex items-center gap-1 rounded-md border border-emerald-500/60 bg-emerald-500/10 px-2 py-0.5 text-[10px] font-medium text-emerald-600 hover:bg-emerald-500/20 disabled:opacity-50"
                  >
                    Done
                  </button>
                  <button
                    onClick={() => updateActionMutation.mutate({ id: action.id, status: 'dismissed' })}
                    disabled={updateActionMutation.isPending}
                    className="inline-flex items-center gap-1 rounded-md border border-border bg-background/60 px-2 py-0.5 text-[10px] text-muted-foreground hover:bg-muted disabled:opacity-50"
                  >
                    Dismiss
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </WidgetCard>
  );
}
