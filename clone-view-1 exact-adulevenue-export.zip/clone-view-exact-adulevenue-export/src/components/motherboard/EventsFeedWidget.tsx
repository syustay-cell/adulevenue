import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { WidgetCard } from './WidgetCard';
import type { WfEvent } from '@/types/events';
import { cn } from '@/lib/utils';

const severityStyles: Record<string, string> = {
  info: 'bg-muted text-muted-foreground',
  warning: 'bg-amber-500/10 text-amber-600 border-amber-500/30',
  success: 'bg-emerald-500/10 text-emerald-600 border-emerald-500/30',
  critical: 'bg-destructive/10 text-destructive border-destructive/30',
};

export function EventsFeedWidget() {
  const query = useQuery({
    queryKey: ['wf-events', 'feed'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('wf_events')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(25);

      if (error) throw error;
      return (data || []) as WfEvent[];
    },
    staleTime: 30_000,
  });

  const getListenText = () => {
    if (!query.data || query.data.length === 0) {
      return 'No recent system events.';
    }
    const latest = query.data[0];
    return `Latest event: ${latest.title}. Source: ${latest.source}. Severity: ${latest.severity}.`;
  };

  return (
    <WidgetCard
      title="Events Stream"
      subtitle="Recent activity across your pipelines"
      onRefresh={() => query.refetch()}
      listenText={getListenText()}
      isLoading={query.isLoading}
    >
      {!query.isLoading && query.data && query.data.length === 0 && (
        <div className="text-xs text-muted-foreground">
          No recent events. Your system is quiet.
        </div>
      )}

      {!query.isLoading && query.data && query.data.length > 0 && (
        <div className="space-y-2.5 max-h-[280px] overflow-y-auto pr-1">
          {query.data.map((event) => (
            <div
              key={event.id}
              className="rounded-lg border border-border/50 bg-muted/40 p-2.5"
            >
              <div className="flex items-center justify-between gap-2">
                <div className="flex items-center gap-1.5">
                  <span className="text-[10px] uppercase tracking-wide text-muted-foreground">
                    {event.source}
                  </span>
                  <span
                    className={cn(
                      'inline-flex items-center rounded-full px-2 py-0.5 text-[10px] font-medium border',
                      severityStyles[event.severity] || severityStyles.info
                    )}
                  >
                    {event.severity}
                  </span>
                </div>
                <span className="text-[10px] text-muted-foreground">
                  {new Date(event.created_at).toLocaleTimeString([], {
                    hour: '2-digit',
                    minute: '2-digit',
                  })}
                </span>
              </div>
              <div className="mt-1 text-xs font-medium">{event.title}</div>
              {event.description && (
                <div className="mt-0.5 text-[11px] text-muted-foreground line-clamp-2">
                  {event.description}
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </WidgetCard>
  );
}
