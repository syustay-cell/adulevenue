import React, { useCallback, useEffect, useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

interface IsoApplication {
  id: string;
  business_name: string | null;
  status: string;
  created_at: string;
}

interface IsoStats {
  totalSubmissions: number;
  pendingSubmissions: number;
  approvedSubmissions: number;
}

function StatusBadge({ status }: { status: string }) {
  if (status === 'funded' || status === 'approved') {
    return (
      <span className="inline-flex items-center rounded-full bg-emerald-100 px-2 py-0.5 text-xs font-medium text-emerald-800">
        Approved
      </span>
    );
  }

  // ISO pipeline statuses (from server) tend to be workflow-ish, not just "pending".
  if (
    [
      'pending',
      'review',
      'submitted',
      'under_review',
      'intake',
      'submitted_by_iso',
      'docs_pending',
      'ready_for_funding',
    ].includes(status)
  ) {
    return (
      <span className="inline-flex items-center rounded-full bg-amber-100 px-2 py-0.5 text-xs font-medium text-amber-800">
        Pending
      </span>
    );
  }

  if (status === 'declined') {
    return (
      <span className="inline-flex items-center rounded-full bg-red-100 px-2 py-0.5 text-xs font-medium text-red-800">
        Declined
      </span>
    );
  }

  return (
    <span className="inline-flex items-center rounded-full bg-slate-100 px-2 py-0.5 text-xs font-medium text-slate-800">
      {status}
    </span>
  );
}

export function IsoDashboard() {
  const [applications, setApplications] = useState<IsoApplication[]>([]);
  const [stats, setStats] = useState<IsoStats | null>(null);
  const [loading, setLoading] = useState(false);
  const [userEmail, setUserEmail] = useState<string | null>(null);

  const loadData = useCallback(async () => {
    setLoading(true);
    try {
      const { data: userData } = await supabase.auth.getUser();
      const email = userData?.user?.email || null;

      if (!userData?.user?.id) {
        toast.error('Not authenticated');
        return;
      }

      setUserEmail(email);

      // ISO submissions are scoped by `iso_partners.id` (not `fast_track_applications.user_id`).
      // Use the server function which resolves ISO partner identity from the caller JWT.
      const { data, error } = await supabase.functions.invoke('iso-get-pipeline', {
        body: { status: 'all' },
      });

      if (error) {
        console.error('[IsoDashboard] iso-get-pipeline error:', error);
        toast.error('Failed to load ISO pipeline');
        return;
      }

      if (!data?.ok) {
        toast.error(data?.message || 'Failed to load ISO pipeline');
        return;
      }

      const list = ((data.deals || []) as any[]).map((d) => ({
        id: String(d.id),
        business_name: (d.business_name ?? null) as string | null,
        status: String(d.status ?? 'unknown'),
        created_at: String(d.created_at ?? new Date().toISOString()),
      })) as IsoApplication[];

      setApplications(list);

      const totalSubmissions = list.length;
      const approvedSubmissions = list.filter(a =>
        a.status === 'approved' || a.status === 'funded'
      ).length;
      const pendingSubmissions = list.filter(a =>
        [
          'pending',
          'review',
          'submitted',
          'under_review',
          'intake',
          'submitted_by_iso',
          'docs_pending',
          'ready_for_funding',
        ].includes(a.status)
      ).length;

      setStats({
        totalSubmissions,
        pendingSubmissions,
        approvedSubmissions,
      });
    } catch (err) {
      console.error('[IsoDashboard] error:', err);
      toast.error('Failed to load ISO data');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadData();
  }, [loadData]);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-start justify-between gap-4">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">ISO Portal</h1>
          <p className="text-sm text-muted-foreground mt-1">
            View deals you&apos;ve submitted and track their status. You cannot see the internal lead engine.
          </p>
          {userEmail && (
            <p className="text-xs text-muted-foreground mt-1">
              Logged in as: <span className="font-medium">{userEmail}</span>
            </p>
          )}
        </div>
        <button
          type="button"
          onClick={loadData}
          disabled={loading}
          className="inline-flex items-center rounded-md border px-3 py-1.5 text-sm font-medium shadow-sm hover:bg-accent disabled:opacity-60"
        >
          {loading ? 'Refreshing…' : 'Refresh'}
        </button>
      </div>

      {/* Stats */}
      {stats && (
        <div className="grid gap-4 sm:grid-cols-3">
          <div className="rounded-lg border bg-card p-4">
            <p className="text-xs font-medium text-muted-foreground">
              Total Submissions
            </p>
            <p className="mt-2 text-2xl font-semibold">
              {stats.totalSubmissions}
            </p>
          </div>

          <div className="rounded-lg border bg-card p-4">
            <p className="text-xs font-medium text-muted-foreground">
              Pending
            </p>
            <p className="mt-2 text-2xl font-semibold">
              {stats.pendingSubmissions}
            </p>
          </div>

          <div className="rounded-lg border bg-card p-4">
            <p className="text-xs font-medium text-muted-foreground">
              Approved / Funded
            </p>
            <p className="mt-2 text-2xl font-semibold">
              {stats.approvedSubmissions}
            </p>
          </div>
        </div>
      )}

      {/* Table */}
      <div>
        <h2 className="text-sm font-medium mb-3">Your Submissions</h2>

        {loading && applications.length === 0 ? (
          <div className="rounded-md border bg-muted/40 p-4 text-sm">
            Loading...
          </div>
        ) : applications.length === 0 ? (
          <div className="rounded-md border bg-muted/40 p-4 text-sm">
            No submissions yet. Submit your first deal to get started.
          </div>
        ) : (
          <div className="overflow-x-auto rounded-md border">
            <table className="min-w-full text-sm">
              <thead className="bg-muted/60">
                <tr className="text-left">
                  <th className="px-3 py-2 font-medium">Business</th>
                  <th className="px-3 py-2 font-medium">Status</th>
                  <th className="px-3 py-2 font-medium">Submitted</th>
                </tr>
              </thead>
              <tbody>
                {applications.map((app) => (
                  <tr key={app.id} className="border-t">
                    <td className="px-3 py-2">
                      {app.business_name || app.id.slice(0, 8)}
                    </td>
                    <td className="px-3 py-2">
                      <StatusBadge status={app.status} />
                    </td>
                    <td className="px-3 py-2">
                      {new Date(app.created_at).toLocaleDateString()}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Access notice */}
      <p className="text-xs text-muted-foreground">
        As an ISO partner, you can only view applications you&apos;ve submitted.
        Internal lead mining, outreach tools, and System Mode controls are not accessible.
      </p>
    </div>
  );
}
