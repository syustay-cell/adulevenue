import { CheckCircle2 } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ClickablePhone, ClickableEmail } from "@/components/ui/clickable-contact";

interface ContactHeaderProps {
  name?: string;
  phone?: string;
  email?: string;
  hasIdExtraction?: boolean;
}

export const ContactHeader = ({ name, phone, email, hasIdExtraction }: ContactHeaderProps) => {
  return (
    <Card className="p-5 sm:p-6 mb-6 border-2">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div className="flex-1">
          <div className="flex flex-col sm:flex-row sm:items-center gap-3 mb-4">
            <h3 className="text-xl sm:text-lg font-bold">{name || 'Applicant'}</h3>
            {hasIdExtraction && (
              <Badge variant="secondary" className="gap-1.5 px-3 py-1 w-fit">
                <CheckCircle2 className="h-4 w-4" />
                <span className="font-semibold">ID Verified</span>
              </Badge>
            )}
          </div>
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3">
            {phone && <ClickablePhone phone={phone} displayText="Call Client" />}
            {email && <ClickableEmail email={email} subject={`Wolf Fund Application - ${name || 'Applicant'}`} />}
          </div>
        </div>
      </div>
    </Card>
  );
};
