import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { LineChart, Line, BarChart, Bar, AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";
import { TrendingUp, TrendingDown, DollarSign, Activity } from "lucide-react";

interface CashFlowVisualizationProps {
  metrics: any;
}

export const CashFlowVisualization = ({ metrics }: CashFlowVisualizationProps) => {
  if (!metrics) return null;

  // Prepare revenue trend data
  const revenueData = metrics.raw_metrics?.monthly_revenue_breakdown?.map((month: any) => ({
    month: month.month,
    revenue: month.total_deposits || 0,
    withdrawals: Math.abs(month.total_withdrawals || 0),
    netFlow: (month.total_deposits || 0) - Math.abs(month.total_withdrawals || 0)
  })) || [];

  // Prepare balance trend data (simulated from available metrics)
  const balanceData = metrics.raw_metrics?.monthly_revenue_breakdown?.map((month: any, idx: number) => ({
    month: month.month,
    balance: metrics.avg_daily_balance || 0,
    low: metrics.raw_metrics?.lowest_balance || 0,
    high: metrics.highest_monthly_deposits || metrics.avg_daily_balance * 1.5 || 0
  })) || [];

  // Calculate trend indicators
  const calculateTrend = () => {
    if (revenueData.length < 2) return { direction: 'stable', percentage: 0 };
    const recent = revenueData[revenueData.length - 1]?.revenue || 0;
    const previous = revenueData[revenueData.length - 2]?.revenue || 0;
    if (previous === 0) return { direction: 'stable', percentage: 0 };
    const change = ((recent - previous) / previous) * 100;
    return {
      direction: change > 5 ? 'up' : change < -5 ? 'down' : 'stable',
      percentage: Math.abs(change).toFixed(1)
    };
  };

  const trend = calculateTrend();

  // Deposit frequency data
  const depositFrequencyData = [
    { type: 'Daily Deposits', count: metrics.raw_metrics?.deposit_count || 0 },
    { type: 'Large Deposits', count: metrics.raw_metrics?.large_deposits?.length || 0 },
    { type: 'Recurring Payments', count: metrics.raw_metrics?.funding_deductions?.length || 0 }
  ];

  // Custom tooltip formatter
  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-background border border-border p-3 rounded-lg shadow-lg">
          <p className="font-semibold text-sm mb-2">{label}</p>
          {payload.map((entry: any, index: number) => (
            <p key={index} className="text-xs" style={{ color: entry.color }}>
              {entry.name}: ${entry.value.toLocaleString()}
            </p>
          ))}
        </div>
      );
    }
    return null;
  };

  return (
    <Card className="mt-6">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <Activity className="h-5 w-5" />
            Cash Flow Visualization
          </CardTitle>
          <div className="flex items-center gap-2 text-sm">
            {trend.direction === 'up' && (
              <div className="flex items-center gap-1 text-green-600">
                <TrendingUp className="h-4 w-4" />
                <span className="font-semibold">+{trend.percentage}%</span>
              </div>
            )}
            {trend.direction === 'down' && (
              <div className="flex items-center gap-1 text-red-600">
                <TrendingDown className="h-4 w-4" />
                <span className="font-semibold">-{trend.percentage}%</span>
              </div>
            )}
            {trend.direction === 'stable' && (
              <span className="text-muted-foreground">Stable Trend</span>
            )}
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="revenue" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="revenue">Revenue Flow</TabsTrigger>
            <TabsTrigger value="balance">Balance Trends</TabsTrigger>
            <TabsTrigger value="activity">Activity Analysis</TabsTrigger>
          </TabsList>

          {/* Revenue Flow Chart */}
          <TabsContent value="revenue" className="space-y-4">
            <div className="h-[300px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={revenueData}>
                  <defs>
                    <linearGradient id="colorRevenue" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.8}/>
                      <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0}/>
                    </linearGradient>
                    <linearGradient id="colorWithdrawals" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="hsl(var(--destructive))" stopOpacity={0.8}/>
                      <stop offset="95%" stopColor="hsl(var(--destructive))" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                  <XAxis 
                    dataKey="month" 
                    tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: 12 }}
                  />
                  <YAxis 
                    tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: 12 }}
                    tickFormatter={(value) => `$${(value / 1000).toFixed(0)}k`}
                  />
                  <Tooltip content={<CustomTooltip />} />
                  <Legend />
                  <Area 
                    type="monotone" 
                    dataKey="revenue" 
                    stroke="hsl(var(--primary))" 
                    fillOpacity={1}
                    fill="url(#colorRevenue)"
                    name="Deposits"
                  />
                  <Area 
                    type="monotone" 
                    dataKey="withdrawals" 
                    stroke="hsl(var(--destructive))" 
                    fillOpacity={1}
                    fill="url(#colorWithdrawals)"
                    name="Withdrawals"
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>

            {/* Summary metrics */}
            <div className="grid grid-cols-3 gap-4">
              <div className="bg-primary/5 p-3 rounded-lg">
                <p className="text-xs text-muted-foreground mb-1">Avg Monthly Revenue</p>
                <p className="text-lg font-bold text-primary">
                  ${(metrics.avg_monthly_revenue || 0).toLocaleString()}
                </p>
              </div>
              <div className="bg-green-500/5 p-3 rounded-lg">
                <p className="text-xs text-muted-foreground mb-1">Peak Month</p>
                <p className="text-lg font-bold text-green-600">
                  ${(metrics.highest_monthly_deposits || 0).toLocaleString()}
                </p>
              </div>
              <div className="bg-muted p-3 rounded-lg">
                <p className="text-xs text-muted-foreground mb-1">Net Cash Flow</p>
                <p className="text-lg font-bold">
                  ${revenueData.reduce((sum: number, d: any) => sum + d.netFlow, 0).toLocaleString()}
                </p>
              </div>
            </div>
          </TabsContent>

          {/* Balance Trends Chart */}
          <TabsContent value="balance" className="space-y-4">
            <div className="h-[300px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={balanceData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                  <XAxis 
                    dataKey="month" 
                    tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: 12 }}
                  />
                  <YAxis 
                    tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: 12 }}
                    tickFormatter={(value) => `$${(value / 1000).toFixed(0)}k`}
                  />
                  <Tooltip content={<CustomTooltip />} />
                  <Legend />
                  <Line 
                    type="monotone" 
                    dataKey="high" 
                    stroke="hsl(var(--primary))" 
                    strokeWidth={2}
                    dot={{ r: 4 }}
                    name="High Balance"
                  />
                  <Line 
                    type="monotone" 
                    dataKey="balance" 
                    stroke="hsl(142 76% 36%)" 
                    strokeWidth={2}
                    dot={{ r: 4 }}
                    name="Avg Balance"
                  />
                  <Line 
                    type="monotone" 
                    dataKey="low" 
                    stroke="hsl(var(--destructive))" 
                    strokeWidth={2}
                    dot={{ r: 4 }}
                    name="Low Balance"
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>

            {/* Balance metrics */}
            <div className="grid grid-cols-3 gap-4">
              <div className="bg-muted p-3 rounded-lg">
                <p className="text-xs text-muted-foreground mb-1">Avg Daily Balance</p>
                <p className="text-lg font-bold">
                  ${(metrics.avg_daily_balance || 0).toLocaleString()}
                </p>
              </div>
              <div className="bg-destructive/5 p-3 rounded-lg">
                <p className="text-xs text-muted-foreground mb-1">Lowest Balance</p>
                <p className="text-lg font-bold text-destructive">
                  ${(metrics.raw_metrics?.lowest_balance || 0).toLocaleString()}
                </p>
              </div>
              <div className="bg-yellow-500/5 p-3 rounded-lg">
                <p className="text-xs text-muted-foreground mb-1">Negative Days</p>
                <p className="text-lg font-bold text-yellow-600">
                  {metrics.negative_days || 0} days
                </p>
              </div>
            </div>
          </TabsContent>

          {/* Activity Analysis Chart */}
          <TabsContent value="activity" className="space-y-4">
            <div className="h-[300px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={depositFrequencyData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                  <XAxis 
                    dataKey="type" 
                    tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: 12 }}
                  />
                  <YAxis 
                    tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: 12 }}
                  />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: 'hsl(var(--background))',
                      border: '1px solid hsl(var(--border))',
                      borderRadius: '8px'
                    }}
                  />
                  <Bar 
                    dataKey="count" 
                    fill="hsl(var(--primary))" 
                    radius={[8, 8, 0, 0]}
                    name="Count"
                  />
                </BarChart>
              </ResponsiveContainer>
            </div>

            {/* Activity metrics */}
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-muted p-3 rounded-lg">
                <p className="text-xs text-muted-foreground mb-1">NSF/Returned Items</p>
                <p className="text-lg font-bold text-destructive">
                  {metrics.nsf_count || 0}
                </p>
              </div>
              <div className="bg-primary/5 p-3 rounded-lg">
                <p className="text-xs text-muted-foreground mb-1">Active Funding Positions</p>
                <p className="text-lg font-bold text-primary">
                  {metrics.raw_metrics?.funding_deductions?.length || 0}
                </p>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
};
