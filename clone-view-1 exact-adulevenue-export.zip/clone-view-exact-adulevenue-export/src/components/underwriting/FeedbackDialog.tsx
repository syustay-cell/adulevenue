import { useState } from "react";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { AlertCircle, CheckCircle2, Loader2 } from "lucide-react";

interface FeedbackDialogProps {
  underwritingCaseId: string;
  applicationId: string;
  applicationType: string;
  field: string;
  originalValue: string;
  onSubmitSuccess?: () => void;
  trigger?: React.ReactNode;
}

export const FeedbackDialog = ({
  underwritingCaseId,
  applicationId,
  applicationType,
  field,
  originalValue,
  onSubmitSuccess,
  trigger
}: FeedbackDialogProps) => {
  const [open, setOpen] = useState(false);
  const [correctedValue, setCorrectedValue] = useState('');
  const [feedbackType, setFeedbackType] = useState('incorrect_value');
  const [notes, setNotes] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async () => {
    if (!correctedValue.trim()) {
      toast.error('Please provide a corrected value');
      return;
    }

    setLoading(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Not authenticated');

      const { error } = await supabase
        .from('underwriting_feedback')
        .insert({
          underwriting_case_id: underwritingCaseId,
          application_id: applicationId,
          application_type: applicationType,
          field,
          original_value: originalValue,
          corrected_value: correctedValue,
          feedback_type: feedbackType,
          notes: notes || null,
          corrected_by: user.id
        });

      if (error) throw error;

      toast.success('Feedback submitted! AI will learn from this correction.', {
        icon: <CheckCircle2 className="text-green-600" />
      });
      
      setOpen(false);
      setCorrectedValue('');
      setNotes('');
      if (onSubmitSuccess) onSubmitSuccess();
    } catch (error: any) {
      console.error('Error submitting feedback:', error);
      toast.error('Failed to submit feedback');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        {trigger || (
          <Button variant="ghost" size="sm">
            <AlertCircle className="w-4 h-4 mr-1" />
            Report Issue
          </Button>
        )}
      </DialogTrigger>
      <DialogContent className="sm:max-w-[500px] max-h-[90vh] flex flex-col">
        <DialogHeader className="flex-shrink-0">
          <DialogTitle>Submit AI Learning Feedback</DialogTitle>
          <DialogDescription>
            Help improve underwriting accuracy by reporting incorrect AI detections or missed items.
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-4 py-4 overflow-y-auto flex-1 px-1">
          <div className="space-y-2">
            <Label>Field</Label>
            <Input value={field.replace(/_/g, ' ').toUpperCase()} disabled />
          </div>

          <div className="space-y-2">
            <Label>AI Detected (Original)</Label>
            <Textarea 
              value={originalValue} 
              disabled 
              className="bg-muted"
              rows={2}
            />
          </div>

          <div className="space-y-2">
            <Label>Correction Type</Label>
            <Select value={feedbackType} onValueChange={setFeedbackType}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="false_positive">False Positive (AI detected something that doesn't exist)</SelectItem>
                <SelectItem value="missed_detection">Missed Detection (AI didn't catch something)</SelectItem>
                <SelectItem value="incorrect_value">Incorrect Value (Wrong amount/name/detail)</SelectItem>
                <SelectItem value="incorrect_classification">Incorrect Classification (Wrong category/risk level)</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label>Corrected Value *</Label>
            <Textarea 
              value={correctedValue}
              onChange={(e) => setCorrectedValue(e.target.value)}
              placeholder="Enter the correct value..."
              rows={2}
            />
          </div>

          <div className="space-y-2">
            <Label>Notes (Optional)</Label>
            <Textarea 
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Add context or explanation..."
              rows={2}
            />
          </div>
        </div>

        <div className="flex justify-end gap-2 flex-shrink-0 pt-4 border-t">
          <Button variant="outline" onClick={() => setOpen(false)} disabled={loading}>
            Cancel
          </Button>
          <Button onClick={handleSubmit} disabled={loading}>
            {loading && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
            Submit Feedback
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};