import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { AlertTriangle, CheckCircle2, XCircle, ExternalLink, RefreshCw } from "lucide-react";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

interface LegalRiskPanelProps {
  applicationId: string;
  applicationType: string;
  businessName?: string;
  fullName?: string;
  state?: string;
  city?: string;
}

interface LegalFinding {
  case_id?: string;
  type: string;
  status: string;
  filed_date?: string;
  court?: string;
  short_description?: string;
  link?: string;
  amount?: number;
  jurisdiction?: string;
  secured_party?: string;
  collateral_summary?: string;
  title?: string;
  date?: string;
  source?: string;
}

interface FraudIndicator {
  type: string;
  severity: 'low' | 'medium' | 'high';
  description: string;
}

interface LegalScanResults {
  entity_name: string;
  scan_timestamp: string;
  summary_risk_level: 'low' | 'medium' | 'high';
  summary_text: string;
  risk_score?: number;
  fraud_indicators?: FraudIndicator[];
  findings: {
    court_cases: LegalFinding[];
    liens: LegalFinding[];
    bankruptcies: LegalFinding[];
    ucc_filings: LegalFinding[];
    news_mentions: LegalFinding[];
  };
}

export const LegalRiskPanel = ({
  applicationId,
  applicationType,
  businessName,
  fullName,
  state,
  city
}: LegalRiskPanelProps) => {
  const [scanResults, setScanResults] = useState<LegalScanResults | null>(null);
  const [isScanning, setIsScanning] = useState(false);
  const [lastScanned, setLastScanned] = useState<string | null>(null);

  const handleScan = async () => {
    setIsScanning(true);
    try {
      const { data, error } = await supabase.functions.invoke('legal-risk-scan', {
        body: {
          full_legal_name: fullName,
          business_name: businessName,
          state,
          city
        }
      });

      if (error) throw error;

      if (data?.scan_results) {
        setScanResults(data.scan_results);
        setLastScanned(new Date().toISOString());
        toast.success('Legal risk scan completed');
      }
    } catch (error) {
      console.error('Legal scan error:', error);
      toast.error('Failed to complete legal risk scan');
    } finally {
      setIsScanning(false);
    }
  };

  const handleMarkRelevance = async (findingType: string, findingId: string, isRelevant: boolean) => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Not authenticated');

      await supabase
        .from('legal_risk_feedback')
        .insert({
          application_id: applicationId,
          application_type: applicationType,
          finding_type: findingType,
          finding_id: findingId,
          is_relevant: isRelevant,
          created_by: user.id
        });

      toast.success(isRelevant ? 'Marked as relevant' : 'Marked as not our client');
    } catch (error) {
      console.error('Error saving feedback:', error);
      toast.error('Failed to save feedback');
    }
  };

  const getRiskBadgeVariant = (level: string) => {
    switch (level) {
      case 'low': return 'default';
      case 'medium': return 'secondary';
      case 'high': return 'destructive';
      default: return 'default';
    }
  };

  const getRiskIcon = (level: string) => {
    switch (level) {
      case 'low': return <CheckCircle2 className="h-4 w-4" />;
      case 'medium': return <AlertTriangle className="h-4 w-4" />;
      case 'high': return <XCircle className="h-4 w-4" />;
      default: return <AlertTriangle className="h-4 w-4" />;
    }
  };

  const renderFindings = (title: string, findings: LegalFinding[], type: string) => {
    if (!findings || findings.length === 0) return null;

    return (
      <Collapsible className="mb-4">
        <CollapsibleTrigger asChild>
          <Button variant="ghost" className="w-full justify-between p-3 h-auto">
            <span className="font-semibold">{title} ({findings.length})</span>
          </Button>
        </CollapsibleTrigger>
        <CollapsibleContent className="px-3 py-2 space-y-2">
          {findings.map((finding, idx) => (
            <Card key={idx} className="p-3">
              <div className="space-y-2">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <p className="text-sm font-medium">
                      {finding.case_id || finding.title || `${type} ${idx + 1}`}
                    </p>
                    <p className="text-xs text-muted-foreground mt-1">
                      {finding.short_description || finding.collateral_summary}
                    </p>
                    <div className="flex items-center gap-3 mt-2 text-xs text-muted-foreground">
                      {finding.filed_date && <span>Filed: {finding.filed_date}</span>}
                      {finding.date && <span>{finding.date}</span>}
                      {finding.status && <Badge variant="outline" className="text-xs">{finding.status}</Badge>}
                      {finding.amount && <span>${finding.amount.toLocaleString()}</span>}
                    </div>
                  </div>
                  {finding.link && (
                    <Button variant="ghost" size="sm" asChild>
                      <a href={finding.link} target="_blank" rel="noopener noreferrer">
                        <ExternalLink className="h-3 w-3" />
                      </a>
                    </Button>
                  )}
                </div>
                <div className="flex items-center gap-2 pt-2 border-t">
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => handleMarkRelevance(type, `${type}-${idx}`, true)}
                  >
                    <CheckCircle2 className="h-3 w-3 mr-1" />
                    Relevant
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => handleMarkRelevance(type, `${type}-${idx}`, false)}
                  >
                    <XCircle className="h-3 w-3 mr-1" />
                    Not our client
                  </Button>
                </div>
              </div>
            </Card>
          ))}
        </CollapsibleContent>
      </Collapsible>
    );
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle>Legal & Public-Record Risk</CardTitle>
          <Button
            onClick={handleScan}
            disabled={isScanning}
            size="sm"
            variant={scanResults ? "outline" : "default"}
          >
            <RefreshCw className={`h-4 w-4 mr-2 ${isScanning ? 'animate-spin' : ''}`} />
            {scanResults ? 'Refresh Scan' : 'Run Scan'}
          </Button>
        </div>
        {lastScanned && (
          <p className="text-xs text-muted-foreground mt-1">
            Last scanned: {new Date(lastScanned).toLocaleString()}
          </p>
        )}
      </CardHeader>
      <CardContent>
        {!scanResults && !isScanning && (
          <div className="text-center py-8 text-muted-foreground">
            <AlertTriangle className="h-12 w-12 mx-auto mb-3 opacity-50" />
            <p>No legal risk scan has been run yet.</p>
            <p className="text-sm mt-2">Click "Run Scan" to check public records.</p>
          </div>
        )}

        {isScanning && (
          <div className="text-center py-8">
            <RefreshCw className="h-12 w-12 mx-auto mb-3 animate-spin text-primary" />
            <p>Scanning public records...</p>
          </div>
        )}

        {scanResults && (
          <div className="space-y-4">
            {/* Risk Summary Header */}
            <div className="p-4 bg-muted rounded-lg space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  {getRiskIcon(scanResults.summary_risk_level)}
                  <Badge variant={getRiskBadgeVariant(scanResults.summary_risk_level)} className="text-sm">
                    {scanResults.summary_risk_level.toUpperCase()} RISK
                  </Badge>
                  {scanResults.risk_score !== undefined && (
                    <span className="text-sm font-semibold">Score: {scanResults.risk_score}/100</span>
                  )}
                </div>
                <div className="text-right text-xs text-muted-foreground">
                  {Object.values(scanResults.findings).reduce((acc, arr) => acc + arr.length, 0)} findings
                </div>
              </div>
              <p className="text-sm text-muted-foreground">{scanResults.summary_text}</p>
            </div>

            {/* Fraud Indicators */}
            {scanResults.fraud_indicators && scanResults.fraud_indicators.length > 0 && (
              <Card className="border-destructive bg-destructive/5">
                <CardHeader className="pb-3">
                  <CardTitle className="text-base flex items-center gap-2">
                    <AlertTriangle className="h-4 w-4 text-destructive" />
                    Fraud Indicators Detected
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-2">
                  {scanResults.fraud_indicators.map((indicator, idx) => (
                    <div key={idx} className="flex items-start gap-2 p-2 bg-background rounded">
                      <Badge variant={indicator.severity === 'high' ? 'destructive' : 'secondary'} className="text-xs">
                        {indicator.severity.toUpperCase()}
                      </Badge>
                      <div className="flex-1">
                        <p className="text-sm font-medium">{indicator.type.replace(/_/g, ' ').toUpperCase()}</p>
                        <p className="text-xs text-muted-foreground">{indicator.description}</p>
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>
            )}

            {/* Findings by Category */}

            {renderFindings('Court Cases', scanResults.findings.court_cases, 'court_case')}
            {renderFindings('Liens', scanResults.findings.liens, 'lien')}
            {renderFindings('UCC Filings', scanResults.findings.ucc_filings, 'ucc')}
            {renderFindings('Bankruptcies', scanResults.findings.bankruptcies, 'bankruptcy')}
            {renderFindings('News Mentions', scanResults.findings.news_mentions, 'news')}

            {Object.values(scanResults.findings).every(arr => arr.length === 0) && (
              <div className="text-center py-4 text-muted-foreground">
                <CheckCircle2 className="h-8 w-8 mx-auto mb-2 text-green-500" />
                <p>No significant public record findings detected.</p>
              </div>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
};
