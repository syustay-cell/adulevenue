import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Brain, TrendingUp, AlertCircle, CheckCircle2 } from "lucide-react";

export const AILearningStats = () => {
  const [stats, setStats] = useState({
    totalFeedback: 0,
    falsePositives: 0,
    missedDetections: 0,
    incorrectValues: 0,
    recentCorrections: [] as any[]
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchStats();
  }, []);

  const fetchStats = async () => {
    try {
      const { data: feedback, error } = await supabase
        .from('underwriting_feedback')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;

      if (feedback) {
        setStats({
          totalFeedback: feedback.length,
          falsePositives: feedback.filter(f => f.feedback_type === 'false_positive').length,
          missedDetections: feedback.filter(f => f.feedback_type === 'missed_detection').length,
          incorrectValues: feedback.filter(f => f.feedback_type === 'incorrect_value').length,
          recentCorrections: feedback.slice(0, 5)
        });
      }
    } catch (error) {
      console.error('Error fetching AI learning stats:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading || stats.totalFeedback === 0) return null;

  return (
    <Card className="border-purple-500/50 bg-purple-500/5">
      <CardHeader>
        <CardTitle className="text-base flex items-center gap-2">
          <Brain className="w-4 h-4 text-purple-600" />
          AI Learning System
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          <div className="text-center">
            <p className="text-2xl font-bold text-purple-600">{stats.totalFeedback}</p>
            <p className="text-xs text-muted-foreground">Total Corrections</p>
          </div>
          <div className="text-center">
            <p className="text-2xl font-bold text-red-600">{stats.falsePositives}</p>
            <p className="text-xs text-muted-foreground">False Positives</p>
          </div>
          <div className="text-center">
            <p className="text-2xl font-bold text-yellow-600">{stats.missedDetections}</p>
            <p className="text-xs text-muted-foreground">Missed Items</p>
          </div>
          <div className="text-center">
            <p className="text-2xl font-bold text-blue-600">{stats.incorrectValues}</p>
            <p className="text-xs text-muted-foreground">Value Corrections</p>
          </div>
        </div>

        {stats.recentCorrections.length > 0 && (
          <div className="pt-3 border-t">
            <p className="text-sm font-semibold mb-3 flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-purple-600" />
              Recent Improvements
            </p>
            <div className="space-y-2">
              {stats.recentCorrections.map((correction) => (
                <div key={correction.id} className="p-2 bg-white rounded border text-xs">
                  <div className="flex items-start gap-2">
                    {correction.feedback_type === 'false_positive' && (
                      <AlertCircle className="w-3 h-3 text-red-500 mt-0.5 flex-shrink-0" />
                    )}
                    {correction.feedback_type === 'missed_detection' && (
                      <AlertCircle className="w-3 h-3 text-yellow-500 mt-0.5 flex-shrink-0" />
                    )}
                    {correction.feedback_type === 'incorrect_value' && (
                      <CheckCircle2 className="w-3 h-3 text-blue-500 mt-0.5 flex-shrink-0" />
                    )}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <Badge variant="outline" className="text-[10px] px-1 py-0">
                          {correction.field.replace(/_/g, ' ').toUpperCase()}
                        </Badge>
                        <Badge variant="outline" className="text-[10px] px-1 py-0">
                          {correction.feedback_type}
                        </Badge>
                      </div>
                      <p className="text-muted-foreground truncate">
                        Corrected to: <span className="font-semibold text-foreground">{correction.corrected_value}</span>
                      </p>
                      {correction.notes && (
                        <p className="text-muted-foreground mt-1 text-[10px] italic">
                          {correction.notes}
                        </p>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        <div className="pt-3 border-t">
          <p className="text-xs text-muted-foreground flex items-center gap-1">
            <Brain className="w-3 h-3" />
            The AI incorporates these corrections to improve future underwriting accuracy.
          </p>
        </div>
      </CardContent>
    </Card>
  );
};