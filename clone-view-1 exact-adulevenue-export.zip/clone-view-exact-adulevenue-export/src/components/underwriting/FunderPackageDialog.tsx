import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Send } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { useQuery, useQueryClient } from "@tanstack/react-query";

interface FunderPackageDialogProps {
  applicationId: string;
  applicationType: string;
}

export const FunderPackageDialog = ({ applicationId, applicationType }: FunderPackageDialogProps) => {
  const queryClient = useQueryClient();
  const [open, setOpen] = useState(false);
  const [selectedFunders, setSelectedFunders] = useState<string[]>([]);
  const [mode, setMode] = useState<'full' | 'summary'>('summary');
  const [includeStatements, setIncludeStatements] = useState(false);
  const [includeDocs, setIncludeDocs] = useState(false);
  const [isSending, setIsSending] = useState(false);

  const { data: funders, isLoading } = useQuery({
    queryKey: ['funders'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('funders')
        .select('*')
        .order('name');
      
      if (error) throw error;
      return data;
    }
  });

  const handleFunderToggle = (funderId: string) => {
    setSelectedFunders(prev =>
      prev.includes(funderId)
        ? prev.filter(id => id !== funderId)
        : [...prev, funderId]
    );
  };

  const handleSend = async () => {
    if (selectedFunders.length === 0) {
      toast.error('Please select at least one funder');
      return;
    }

    setIsSending(true);
    try {
      // Create submission records with pending_admin_approval status
      const submissionRecords = selectedFunders.map(funderId => ({
        application_id: applicationId,
        application_type: applicationType,
        funder_id: funderId,
        mode,
        status: "pending_admin_approval",
        attachments_included: []
      }));

      const { error } = await supabase
        .from("funder_submissions")
        .insert(submissionRecords);

      if (error) throw error;

      queryClient.invalidateQueries({ queryKey: ["funder-submissions"] });
      toast.success(`${selectedFunders.length} submission(s) prepared for admin approval`);
      setOpen(false);
      setSelectedFunders([]);
    } catch (error) {
      console.error('Error preparing submissions:', error);
      toast.error('Failed to prepare submissions');
    } finally {
      setIsSending(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm">
          <Send className="h-4 w-4 mr-2" />
          Send to Funder(s)
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle>Send to Funder(s)</DialogTitle>
        </DialogHeader>

        <div className="space-y-6 py-4">
          {/* Package Mode */}
          <div className="space-y-2">
            <Label>Package Type</Label>
            <Select value={mode} onValueChange={(v) => setMode(v as 'full' | 'summary')}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="full">Full Package (with contact info)</SelectItem>
                <SelectItem value="summary">Funder Summary (no direct contact)</SelectItem>
              </SelectContent>
            </Select>
            <p className="text-xs text-muted-foreground">
              {mode === 'full' 
                ? 'Includes all client contact information and details'
                : 'Redacted summary without direct client contact details'
              }
            </p>
          </div>

          {/* Attachments */}
          <div className="space-y-3">
            <Label>Attachments</Label>
            <div className="flex items-center space-x-2">
              <Checkbox
                id="statements"
                checked={includeStatements}
                onCheckedChange={(checked) => setIncludeStatements(checked as boolean)}
              />
              <label
                htmlFor="statements"
                className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
              >
                Attach bank statements
              </label>
            </div>
            <div className="flex items-center space-x-2">
              <Checkbox
                id="docs"
                checked={includeDocs}
                onCheckedChange={(checked) => setIncludeDocs(checked as boolean)}
              />
              <label
                htmlFor="docs"
                className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
              >
                Attach ID / corporate docs
              </label>
            </div>
          </div>

          {/* Funder Selection */}
          <div className="space-y-3">
            <Label>Select Funder(s)</Label>
            <div className="border rounded-lg p-3 max-h-64 overflow-y-auto space-y-2">
              {isLoading && <p className="text-sm text-muted-foreground">Loading funders...</p>}
              {funders && funders.length === 0 && (
                <p className="text-sm text-muted-foreground">
                  No funders configured. Add funders in Admin settings.
                </p>
              )}
              {funders && funders.map((funder) => (
                <div key={funder.id} className="flex items-center space-x-2">
                  <Checkbox
                    id={funder.id}
                    checked={selectedFunders.includes(funder.id)}
                    onCheckedChange={() => handleFunderToggle(funder.id)}
                  />
                  <label
                    htmlFor={funder.id}
                    className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 flex-1"
                  >
                    {funder.name}
                    <span className="text-xs text-muted-foreground ml-2">({funder.contact_email})</span>
                  </label>
                </div>
              ))}
            </div>
          </div>

          {/* Actions */}
          <div className="flex justify-end gap-2 pt-4">
            <Button variant="outline" onClick={() => setOpen(false)} disabled={isSending}>
              Cancel
            </Button>
            <Button onClick={handleSend} disabled={isSending || selectedFunders.length === 0}>
              <Send className="h-4 w-4 mr-2" />
              {isSending ? 'Preparing...' : 'Prepare for Admin Approval'}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};
