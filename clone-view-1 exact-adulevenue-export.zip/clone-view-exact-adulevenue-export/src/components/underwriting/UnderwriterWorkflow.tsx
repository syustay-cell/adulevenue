import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { 
  Phone, 
  UserCheck, 
  Send, 
  ArrowRight, 
  CheckCircle2,
  Clock,
  Loader2
} from "lucide-react";

type WorkflowStage = "opener" | "underwriter" | "funder_call" | "complete";

interface UnderwriterWorkflowProps {
  caseId: string;
  currentStage: WorkflowStage;
  onStageChange?: (stage: WorkflowStage) => void;
}

const stageConfig = {
  opener: {
    label: "Opener",
    icon: Phone,
    color: "bg-blue-500/10 text-blue-400 border-blue-500/30",
  },
  underwriter: {
    label: "Underwriter Review",
    icon: UserCheck,
    color: "bg-amber-500/10 text-amber-400 border-amber-500/30",
  },
  funder_call: {
    label: "Funder Call",
    icon: Send,
    color: "bg-emerald-500/10 text-emerald-400 border-emerald-500/30",
  },
  complete: {
    label: "Complete",
    icon: CheckCircle2,
    color: "bg-green-500/10 text-green-400 border-green-500/30",
  },
};

export function UnderwriterWorkflow({ 
  caseId, 
  currentStage, 
  onStageChange 
}: UnderwriterWorkflowProps) {
  const { toast } = useToast();
  const [notes, setNotes] = useState("");
  const [loading, setLoading] = useState(false);

  const stages: WorkflowStage[] = ["opener", "underwriter", "funder_call", "complete"];
  const currentIndex = stages.indexOf(currentStage);

  const advanceStage = async () => {
    if (currentIndex >= stages.length - 1) return;
    
    setLoading(true);
    const nextStage = stages[currentIndex + 1];

    try {
      const { error } = await supabase
        .from("underwriting_cases")
        .update({ 
          status: nextStage === "complete" ? "funded" : nextStage,
          funding_call_notes: notes || null,
          funding_call_status: nextStage === "funder_call" ? "scheduled" : undefined,
        })
        .eq("id", caseId);

      if (error) throw error;

      onStageChange?.(nextStage);
      toast({
        title: "Stage Advanced",
        description: `Moved to ${stageConfig[nextStage].label}`,
      });
      setNotes("");
    } catch (err) {
      console.error("Workflow error:", err);
      toast({
        variant: "destructive",
        title: "Failed to advance",
        description: "Please try again.",
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Card className="border-slate-800 bg-slate-900/60">
      <CardHeader className="pb-3">
        <CardTitle className="text-sm font-medium text-slate-200">
          3-Way Underwriting Cycle
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Stage Progress */}
        <div className="flex items-center justify-between gap-1">
          {stages.map((stage, idx) => {
            const config = stageConfig[stage];
            const Icon = config.icon;
            const isActive = idx === currentIndex;
            const isComplete = idx < currentIndex;

            return (
              <div key={stage} className="flex items-center gap-1">
                <div
                  className={`flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-[10px] font-medium transition-all ${
                    isActive
                      ? config.color
                      : isComplete
                      ? "bg-green-500/10 text-green-400 border-green-500/30"
                      : "bg-slate-800/50 text-slate-500 border-slate-700"
                  }`}
                >
                  {isComplete ? (
                    <CheckCircle2 className="h-3 w-3" />
                  ) : isActive ? (
                    <Clock className="h-3 w-3 animate-pulse" />
                  ) : (
                    <Icon className="h-3 w-3" />
                  )}
                  <span className="hidden sm:inline">{config.label}</span>
                </div>
                {idx < stages.length - 1 && (
                  <ArrowRight className="h-3 w-3 text-slate-600" />
                )}
              </div>
            );
          })}
        </div>

        {/* Current Stage Actions */}
        {currentStage !== "complete" && (
          <div className="space-y-3 pt-2">
            <div className="rounded-lg bg-slate-950/50 p-3">
              <p className="text-xs text-slate-400 mb-2">
                {currentStage === "opener" && "Opener has connected with the client. Ready for underwriting?"}
                {currentStage === "underwriter" && "Review complete. Ready to schedule funder call?"}
                {currentStage === "funder_call" && "Funder call scheduled. Mark as complete when funded."}
              </p>
              
              <Textarea
                placeholder="Add notes for this stage..."
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                className="h-16 bg-slate-900 border-slate-700 text-xs"
              />
            </div>

            <Button
              onClick={advanceStage}
              disabled={loading}
              size="sm"
              className="w-full bg-primary text-primary-foreground hover:bg-primary/90"
            >
              {loading && <Loader2 className="mr-1.5 h-3 w-3 animate-spin" />}
              {currentStage === "opener" && "Send to Underwriter"}
              {currentStage === "underwriter" && "Schedule Funder Call"}
              {currentStage === "funder_call" && "Mark as Funded"}
            </Button>
          </div>
        )}

        {currentStage === "complete" && (
          <div className="text-center py-4">
            <CheckCircle2 className="h-8 w-8 text-green-400 mx-auto mb-2" />
            <p className="text-xs text-slate-400">
              Deal successfully funded!
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
