import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { ArrowLeft } from "lucide-react";
import { runFile, markNeedsMoreDocs, sendToFunder, createFundingCall } from "@/lib/underwritingActions";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

interface UnderwritingCaseProps {
  application: any;
  onBack: () => void;
}

export function UnderwritingCase({ application, onBack }: UnderwritingCaseProps) {
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [user, setUser] = useState<any>(null);

  useEffect(() => {
    supabase.auth.getUser().then(({ data }) => setUser(data.user));
  }, []);

  const [numbers, setNumbers] = useState({
    monthly_revenue: 0,
    nsfs_last_90_days: 0,
    avg_daily_balance: 0,
    time_in_business_months: 0,
    recommended_amount: 0,
    recommended_term_months: 0,
    recommended_factor_rate: 0,
  });
  const [notes, setNotes] = useState("");
  const [docsReason, setDocsReason] = useState("");
  const [funderName, setFunderName] = useState("");
  const [scheduledFor, setScheduledFor] = useState("");
  const [dialMethod, setDialMethod] = useState<"phone" | "zoom" | "teams" | "other">("phone");
  const [callNotes, setCallNotes] = useState("");

  const actor = {
    actor_email: user?.email ?? undefined,
    actor_role: "underwriter",
  };

  const handleRunFile = async () => {
    setLoading(true);
    try {
      await runFile(supabase as any, {
        applicationId: application.id,
        underwriterId: user!.id,
        numbers,
        notes,
        actor,
      });
      toast({ title: "File saved", description: "Underwriting summary updated." });
      onBack();
    } catch (e: any) {
      toast({ variant: "destructive", title: "Error", description: e.message });
    } finally {
      setLoading(false);
    }
  };

  const handleNeedDocs = async () => {
    if (!docsReason.trim()) {
      toast({ variant: "destructive", title: "Error", description: "Please provide a reason" });
      return;
    }
    setLoading(true);
    try {
      await markNeedsMoreDocs(supabase as any, {
        applicationId: application.id,
        reason: docsReason,
        actor,
      });
      toast({ title: "Docs requested", description: "Client will be notified." });
      onBack();
    } catch (e: any) {
      toast({ variant: "destructive", title: "Error", description: e.message });
    } finally {
      setLoading(false);
    }
  };

  const handleSendToFunder = async () => {
    setLoading(true);
    try {
      await sendToFunder(supabase as any, {
        applicationId: application.id,
        funderName,
        actor,
      });
      toast({ title: "Sent to funder", description: "File marked ready for funding call." });
      onBack();
    } catch (e: any) {
      toast({ variant: "destructive", title: "Error", description: e.message });
    } finally {
      setLoading(false);
    }
  };

  const handleCreateFundingCall = async () => {
    if (!scheduledFor) {
      toast({ variant: "destructive", title: "Error", description: "Please select a date/time" });
      return;
    }
    setLoading(true);
    try {
      await createFundingCall(supabase as any, {
        applicationId: application.id,
        scheduledFor,
        dialMethod,
        notes: callNotes,
        createdBy: user!.id,
        actor,
      });
      toast({ title: "Funding call scheduled" });
      onBack();
    } catch (e: any) {
      toast({ variant: "destructive", title: "Error", description: e.message });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="container mx-auto p-6">
      <Button variant="ghost" onClick={onBack} className="mb-4">
        <ArrowLeft className="mr-2 h-4 w-4" /> Back to Queue
      </Button>

      <h1 className="text-3xl font-bold mb-6">{application.business_name}</h1>

      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Application Details</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            <p><strong>Contact:</strong> {application.client_name || application.email}</p>
            <p><strong>Phone:</strong> {application.phone}</p>
            <p><strong>Email:</strong> {application.email}</p>
            <p><strong>Status:</strong> {application.status}</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Run File</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label>Monthly Revenue</Label>
              <Input type="number" value={numbers.monthly_revenue} onChange={(e) => setNumbers({...numbers, monthly_revenue: +e.target.value})} />
            </div>
            <div>
              <Label>NSFs (Last 90 Days)</Label>
              <Input type="number" value={numbers.nsfs_last_90_days} onChange={(e) => setNumbers({...numbers, nsfs_last_90_days: +e.target.value})} />
            </div>
            <div>
              <Label>Avg Daily Balance</Label>
              <Input type="number" value={numbers.avg_daily_balance} onChange={(e) => setNumbers({...numbers, avg_daily_balance: +e.target.value})} />
            </div>
            <div>
              <Label>Time in Business (Months)</Label>
              <Input type="number" value={numbers.time_in_business_months} onChange={(e) => setNumbers({...numbers, time_in_business_months: +e.target.value})} />
            </div>
            <div>
              <Label>Recommended Amount</Label>
              <Input type="number" value={numbers.recommended_amount} onChange={(e) => setNumbers({...numbers, recommended_amount: +e.target.value})} />
            </div>
            <div>
              <Label>Recommended Term (Months)</Label>
              <Input type="number" value={numbers.recommended_term_months} onChange={(e) => setNumbers({...numbers, recommended_term_months: +e.target.value})} />
            </div>
            <div>
              <Label>Recommended Factor Rate</Label>
              <Input type="number" step="0.01" value={numbers.recommended_factor_rate} onChange={(e) => setNumbers({...numbers, recommended_factor_rate: +e.target.value})} />
            </div>
            <div>
              <Label>Notes</Label>
              <Textarea value={notes} onChange={(e) => setNotes(e.target.value)} />
            </div>
            <Button onClick={handleRunFile} disabled={loading} className="w-full">
              Save & Run File
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Request More Documents</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label>Reason</Label>
              <Textarea value={docsReason} onChange={(e) => setDocsReason(e.target.value)} placeholder="Explain what documents are needed..." />
            </div>
            <Button onClick={handleNeedDocs} disabled={loading} variant="secondary" className="w-full">
              Request More Docs
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Send to Funder</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label>Funder Name (Optional)</Label>
              <Input value={funderName} onChange={(e) => setFunderName(e.target.value)} placeholder="e.g. ABC Capital" />
            </div>
            <Button onClick={handleSendToFunder} disabled={loading} className="w-full">
              Send to Funder
            </Button>
          </CardContent>
        </Card>

        <Card className="md:col-span-2">
          <CardHeader>
            <CardTitle>Schedule Funding Call</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <Label>Scheduled For</Label>
                <Input type="datetime-local" value={scheduledFor} onChange={(e) => setScheduledFor(e.target.value)} />
              </div>
              <div>
                <Label>Dial Method</Label>
                <Select value={dialMethod} onValueChange={(v: any) => setDialMethod(v)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="phone">Phone</SelectItem>
                    <SelectItem value="zoom">Zoom</SelectItem>
                    <SelectItem value="teams">Teams</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div>
              <Label>Call Notes (Optional)</Label>
              <Textarea value={callNotes} onChange={(e) => setCallNotes(e.target.value)} placeholder="Any special instructions..." />
            </div>
            <Button onClick={handleCreateFundingCall} disabled={loading} className="w-full">
              Schedule Funding Call
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
