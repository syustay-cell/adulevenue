import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { MessageSquare, Mail, Loader2, Sparkles, ArrowLeft, Clock, Lock } from "lucide-react";

interface MessageTemplate {
  id: string;
  name: string;
  product_line: string;
  channel: string;
  subject: string | null;
  body: string;
  ai_prompt_hint: string | null;
}

interface SendInfoModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  lead: any;
  workerId: string;
  caseId?: string;
  clientId?: string;
  productLine?: 'mca' | 'credit_fix' | 'loan' | 'hybrid' | 'general';
  onSuccess?: () => void;
}

type Channel = 'sms' | 'email';
type Step = 'channel' | 'compose';

// Quick template bubbles by product + channel
const QUICK_BUBBLES: Record<string, Record<Channel, { key: string; label: string }[]>> = {
  mca: {
    sms: [
      { key: 'mca_intro_sms', label: 'Intro' },
      { key: 'general_followup_sms', label: 'Follow-Up' },
      { key: 'general_missed_call_sms', label: 'Missed Call' },
    ],
    email: [
      { key: 'mca_docs_request_email', label: 'Docs Request' },
      { key: 'mca_conditional_approval_email', label: 'Conditional' },
      { key: 'mca_decline_to_credit_fix', label: 'Decline → Credit Fix' },
    ],
  },
  credit_fix: {
    sms: [
      { key: 'credit_fix_intro_sms', label: 'Intro' },
      { key: 'credit_fix_update_sms', label: 'Update' },
    ],
    email: [
      { key: 'credit_fix_onboarding_email', label: 'Onboarding' },
      { key: 'credit_fix_ready_for_funding_email', label: 'Ready for Funding' },
    ],
  },
  general: {
    sms: [
      { key: 'general_followup_sms', label: 'Follow-Up' },
      { key: 'general_missed_call_sms', label: 'Missed Call' },
    ],
    email: [
      { key: 'mca_docs_request_email', label: 'Docs Request' },
    ],
  },
};

export function SendInfoModal({ 
  open, 
  onOpenChange, 
  lead, 
  workerId, 
  caseId, 
  clientId,
  productLine = 'mca', 
  onSuccess 
}: SendInfoModalProps) {
  const [step, setStep] = useState<Step>('channel');
  const [channel, setChannel] = useState<Channel>('sms');
  const [selectedTemplate, setSelectedTemplate] = useState<string>('');
  const [dbTemplates, setDbTemplates] = useState<MessageTemplate[]>([]);
  const [loadingTemplates, setLoadingTemplates] = useState(false);
  const [recipientPhone, setRecipientPhone] = useState(lead?.phone || '');
  const [recipientEmail, setRecipientEmail] = useState(lead?.email || '');
  const [subject, setSubject] = useState('');
  const [body, setBody] = useState('');
  const [replyInHours, setReplyInHours] = useState<number>(24);
  const [lock7Days, setLock7Days] = useState(true);
  const [generating, setGenerating] = useState(false);
  const [sending, setSending] = useState(false);

  // Reset state when modal opens
  useEffect(() => {
    if (open) {
      setRecipientPhone(lead?.phone || '');
      setRecipientEmail(lead?.email || '');
      fetchTemplates();
    }
  }, [open, channel, productLine]);

  const fetchTemplates = async () => {
    setLoadingTemplates(true);
    try {
      let query = supabase
        .from('message_templates')
        .select('*')
        .eq('channel', channel)
        .eq('is_active', true);

      if (productLine) {
        query = query.or(`product_line.eq.${productLine},product_line.eq.general`);
      }

      const { data, error } = await query.order('is_default', { ascending: false });
      
      if (error) throw error;
      setDbTemplates((data as MessageTemplate[]) || []);
    } catch (error) {
      console.error('Error fetching templates:', error);
      setDbTemplates([]);
    } finally {
      setLoadingTemplates(false);
    }
  };

  const resetState = () => {
    setStep('channel');
    setChannel('sms');
    setSelectedTemplate('');
    setBody('');
    setSubject('');
    setReplyInHours(24);
    setLock7Days(true);
  };

  const handleClose = () => {
    resetState();
    onOpenChange(false);
  };

  const handleBubbleClick = async (templateKey: string) => {
    setSelectedTemplate(templateKey);
    setGenerating(true);

    const name = lead?.full_name || lead?.owner_full_name || 'there';
    const firstName = name.split(' ')[0];

    try {
      // Find template in DB
      const template = dbTemplates.find(t => t.name === templateKey);
      
      if (template) {
        // Try AI enhancement
        const { data, error } = await supabase.functions.invoke("ai-draft-outreach", {
          body: {
            channel,
            template_type: template.name,
            template_body: template.body,
            ai_hint: template.ai_prompt_hint,
            lead: {
              full_name: lead?.full_name || lead?.owner_full_name,
              business_name: lead?.business_name,
              phone: lead?.phone,
              email: lead?.email,
            },
          },
        });

        if (!error && data?.ok) {
          if (channel === 'email') {
            setSubject(data.subject || template.subject || 'Wolf Fund Capital');
          }
          setBody(data.body || data.draft || replaceVariables(template.body, firstName));
        } else {
          // Fallback to template without AI
          setBody(replaceVariables(template.body, firstName));
          if (channel === 'email') {
            setSubject(template.subject || 'Wolf Fund Capital');
          }
        }
      } else {
        // Fallback default message
        setBody(getDefaultMessage(channel, templateKey, firstName));
        if (channel === 'email') {
          setSubject('Wolf Fund Capital - Business Funding');
        }
      }
    } catch (error) {
      console.error("Template load error:", error);
      setBody(getDefaultMessage(channel, templateKey, firstName));
    } finally {
      setGenerating(false);
      setStep('compose');
    }
  };

  const replaceVariables = (text: string, firstName: string): string => {
    return text
      .replace(/\{\{client_first_name\}\}/g, firstName)
      .replace(/\{\{first_name\}\}/g, firstName)
      .replace(/\{\{full_name\}\}/g, lead?.full_name || lead?.owner_full_name || 'there')
      .replace(/\{\{worker_name\}\}/g, 'Wolf Fund Team')
      .replace(/\{\{business_name\}\}/g, lead?.business_name || 'your business')
      .replace(/\{\{upload_link\}\}/g, '[UPLOAD LINK]')
      .replace(/\{\{worker_phone\}\}/g, '(888) WOLF-FUND');
  };

  const getDefaultMessage = (ch: Channel, key: string, firstName: string): string => {
    if (ch === 'sms') {
      if (key.includes('intro')) {
        return `Hi ${firstName}, this is Wolf Fund Capital. I'm reaching out about funding opportunities for your business. Do you have a few minutes to chat?`;
      }
      if (key.includes('followup')) {
        return `Hi ${firstName}, just following up from our conversation. Let me know if you have any questions. - Wolf Fund`;
      }
      if (key.includes('missed')) {
        return `Hi ${firstName}, I tried calling but couldn't reach you. Please call back when you have a moment. - Wolf Fund`;
      }
      return `Hi ${firstName}, this is Wolf Fund Capital. Reply with any questions!`;
    } else {
      return `Dear ${firstName},\n\nThank you for your interest in business funding with Wolf Fund Capital.\n\nPlease let us know if you have any questions.\n\nBest regards,\nWolf Fund Capital Team`;
    }
  };

  const handleSend = async () => {
    if (!body.trim()) {
      toast.error("Message body is required");
      return;
    }

    const recipient = channel === 'sms' ? recipientPhone : recipientEmail;
    if (!recipient) {
      toast.error(channel === 'sms' ? "Phone number is required" : "Email is required");
      return;
    }

    setSending(true);

    try {
      const functionName = channel === 'sms' ? 'send-smart-sms' : 'send-smart-email';
      
      const payload: any = {
        lead_id: lead.id,
        template_name: selectedTemplate || 'custom',
        to_phone: channel === 'sms' ? recipientPhone : undefined,
        case_id: caseId,
        client_id: clientId,
        reply_in_hours: replyInHours > 0 ? replyInHours : undefined,
        sent_by_user_id: workerId,
        body,
      };

      if (channel === 'email') {
        payload.subject = subject;
      }

      const { data, error } = await supabase.functions.invoke(functionName, { body: payload });

      if (error) {
        console.error('Send transport error:', error);
        toast.error("Connection issue. Please try again.");
        return;
      }

      if (!data?.ok) {
        toast.error(data?.message || `Failed to send ${channel.toUpperCase()}`);
        return;
      }

      // Lock lead for 7 days if enabled
      if (lock7Days && lead.id) {
        try {
          await supabase.rpc("lock_lead_for_client_work", {
            p_lead_id: lead.id,
            p_worker_id: workerId,
            p_reason: `${channel}_sent`,
          });
        } catch (lockErr) {
          console.log("Lead lock skipped:", lockErr);
        }
      }

      toast.success(`${channel === 'sms' ? 'SMS' : 'Email'} sent successfully`);
      handleClose();
      onSuccess?.();
    } catch (error) {
      console.error("Send error:", error);
      toast.error(`Failed to send ${channel.toUpperCase()}`);
    } finally {
      setSending(false);
    }
  };

  // Get quick bubbles for current product + channel
  const quickBubbles = QUICK_BUBBLES[productLine]?.[channel] || QUICK_BUBBLES.general[channel] || [];

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            {step === 'compose' && (
              <Button variant="ghost" size="icon" className="h-6 w-6" onClick={() => setStep('channel')}>
                <ArrowLeft className="h-4 w-4" />
              </Button>
            )}
            Send Info to Client
          </DialogTitle>
        </DialogHeader>

        {step === 'channel' && (
          <div className="space-y-4">
            {/* Channel Tabs */}
            <div className="flex gap-2 border-b pb-3">
              <Button
                variant={channel === 'sms' ? 'default' : 'outline'}
                size="sm"
                className="rounded-full"
                onClick={() => {
                  setChannel('sms');
                  setRecipientPhone(lead?.phone || '');
                }}
              >
                <MessageSquare className="h-4 w-4 mr-1" />
                SMS
              </Button>
              <Button
                variant={channel === 'email' ? 'default' : 'outline'}
                size="sm"
                className="rounded-full"
                onClick={() => {
                  setChannel('email');
                  setRecipientEmail(lead?.email || '');
                }}
              >
                <Mail className="h-4 w-4 mr-1" />
                Email
              </Button>
            </div>

            {/* Quick Template Bubbles */}
            {quickBubbles.length > 0 && (
              <div>
                <Label className="text-xs font-medium text-muted-foreground mb-2 block">
                  Quick templates
                </Label>
                <div className="flex flex-wrap gap-2">
                  {quickBubbles.map((b) => (
                    <Button
                      key={b.key}
                      variant={selectedTemplate === b.key ? 'default' : 'secondary'}
                      size="sm"
                      className="rounded-full text-xs"
                      onClick={() => handleBubbleClick(b.key)}
                      disabled={generating}
                    >
                      {b.label}
                    </Button>
                  ))}
                </div>
              </div>
            )}

            {/* All Templates Dropdown */}
            <div className="space-y-2">
              <Label className="text-xs font-medium text-muted-foreground">
                Or select from all templates
              </Label>
              {loadingTemplates ? (
                <div className="flex items-center justify-center py-4">
                  <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
                </div>
              ) : dbTemplates.length > 0 ? (
                <div className="space-y-1 max-h-48 overflow-y-auto">
                  {dbTemplates.map((t) => (
                    <div
                      key={t.id}
                      className="flex items-center space-x-3 p-2 rounded-lg border hover:bg-muted/50 cursor-pointer transition-colors"
                      onClick={() => handleBubbleClick(t.name)}
                    >
                      <div className={`w-3 h-3 rounded-full border-2 ${selectedTemplate === t.name ? 'bg-primary border-primary' : 'border-muted-foreground'}`} />
                      <div className="flex-1 min-w-0">
                        <p className="font-medium text-sm truncate">{t.name.replace(/_/g, ' ')}</p>
                        <p className="text-xs text-muted-foreground truncate">{t.body.substring(0, 50)}...</p>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-sm text-muted-foreground py-2">No templates found. Click a quick template above.</p>
              )}
            </div>
          </div>
        )}

        {step === 'compose' && (
          <div className="space-y-4">
            {/* To Field */}
            <div className="space-y-2">
              <Label className="text-xs">To</Label>
              <Input
                value={channel === 'sms' ? recipientPhone : recipientEmail}
                onChange={(e) => channel === 'sms' ? setRecipientPhone(e.target.value) : setRecipientEmail(e.target.value)}
                placeholder={channel === 'sms' ? 'Phone number' : 'Email address'}
                className="h-9"
              />
            </div>

            {/* Subject for Email */}
            {channel === 'email' && (
              <div className="space-y-2">
                <Label className="text-xs">Subject</Label>
                <Input
                  value={subject}
                  onChange={(e) => setSubject(e.target.value)}
                  placeholder="Email subject"
                  className="h-9"
                />
              </div>
            )}

            {/* Message Body */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label className="text-xs">Message</Label>
                {generating && (
                  <span className="text-xs text-muted-foreground flex items-center gap-1">
                    <Sparkles className="h-3 w-3" />
                    AI drafting...
                  </span>
                )}
              </div>
              {generating ? (
                <div className="h-32 flex items-center justify-center border rounded-md bg-muted/30">
                  <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
                </div>
              ) : (
                <Textarea
                  value={body}
                  onChange={(e) => setBody(e.target.value)}
                  placeholder="Message content..."
                  className="min-h-[120px] text-sm"
                />
              )}
              <p className="text-[10px] text-muted-foreground">
                Variables like {"{{first_name}}"} are auto-filled when sending.
              </p>
            </div>

            {/* Follow-up & Lock Options */}
            <div className="flex items-center justify-between gap-4 pt-2 border-t">
              <div className="flex items-center gap-2">
                <Clock className="h-4 w-4 text-muted-foreground" />
                <Label className="text-xs text-muted-foreground">Follow-up in</Label>
                <Input
                  type="number"
                  min={0}
                  value={replyInHours}
                  onChange={(e) => setReplyInHours(Number(e.target.value) || 0)}
                  className="h-7 w-14 text-xs"
                />
                <span className="text-xs text-muted-foreground">hrs</span>
              </div>

              <div className="flex items-center gap-2">
                <Checkbox
                  id="lock7"
                  checked={lock7Days}
                  onCheckedChange={(checked) => setLock7Days(checked as boolean)}
                />
                <Label htmlFor="lock7" className="text-xs text-muted-foreground flex items-center gap-1 cursor-pointer">
                  <Lock className="h-3 w-3" />
                  Lock 7 days
                </Label>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex gap-2 pt-2">
              <Button variant="outline" className="flex-1" onClick={() => setStep('channel')}>
                Back
              </Button>
              <Button 
                className="flex-1" 
                onClick={handleSend} 
                disabled={sending || generating || !body.trim()}
              >
                {sending ? (
                  <>
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                    Sending...
                  </>
                ) : (
                  `Send ${channel === 'sms' ? 'SMS' : 'Email'}`
                )}
              </Button>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
