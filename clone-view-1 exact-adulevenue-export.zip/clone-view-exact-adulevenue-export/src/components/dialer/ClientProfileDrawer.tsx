import { X, User, Mail, Phone, Building, FileText, MessageSquare, Clock, TrendingUp } from "lucide-react";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { useUserRoles } from "@/hooks/useUserRoles";
import { canViewRawPii, maskEmail, maskPhone } from "@/lib/masking";
import type { AppRole } from "@/lib/permissions";

interface ClientProfileDrawerProps {
  lead: any;
  isOpen: boolean;
  onClose: () => void;
}

export const ClientProfileDrawer = ({ lead, isOpen, onClose }: ClientProfileDrawerProps) => {
  if (!lead) return null;
  const { roles } = useUserRoles();
  const canViewPii = canViewRawPii((roles as AppRole[]) || []);

  return (
    <Sheet open={isOpen} onOpenChange={onClose}>
      <SheetContent side="right" className="w-full sm:w-[540px] sm:max-w-[540px]">
        <SheetHeader>
          <SheetTitle className="flex items-center gap-2">
            <User className="h-5 w-5 text-primary" />
            Client Profile
          </SheetTitle>
        </SheetHeader>

        <Tabs defaultValue="summary" className="mt-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="summary">Summary</TabsTrigger>
            <TabsTrigger value="notes">Notes</TabsTrigger>
            <TabsTrigger value="history">History</TabsTrigger>
            <TabsTrigger value="docs">Docs</TabsTrigger>
          </TabsList>

          {/* AI Summary Tab */}
          <TabsContent value="summary" className="mt-4">
            <ScrollArea className="h-[calc(100vh-200px)]">
              <div className="space-y-4">
                {/* Contact Info */}
                <Card className="p-4">
                  <h3 className="text-sm font-semibold text-foreground mb-3">Contact Information</h3>
                  <div className="space-y-3">
                    <div className="flex items-center gap-3">
                      <User className="h-4 w-4 text-muted-foreground" />
                      <div>
                        <div className="text-xs text-muted-foreground">Full Name</div>
                        <div className="text-sm font-medium">{lead.full_name || 'Unknown'}</div>
                      </div>
                    </div>
                    {lead.business_name && (
                      <div className="flex items-center gap-3">
                        <Building className="h-4 w-4 text-muted-foreground" />
                        <div>
                          <div className="text-xs text-muted-foreground">Business</div>
                          <div className="text-sm font-medium">{lead.business_name}</div>
                        </div>
                      </div>
                    )}
                    <div className="flex items-center gap-3">
                      <Phone className="h-4 w-4 text-muted-foreground" />
                      <div>
                        <div className="text-xs text-muted-foreground">Phone</div>
                        {canViewPii ? (
                          <a href={`tel:${lead.phone}`} className="text-sm font-medium text-primary hover:underline">
                            {lead.phone || 'No phone'}
                          </a>
                        ) : (
                          <span className="text-sm font-medium">{maskPhone(lead.phone)}</span>
                        )}
                      </div>
                    </div>
                    {lead.email && (
                      <div className="flex items-center gap-3">
                        <Mail className="h-4 w-4 text-muted-foreground" />
                        <div>
                          <div className="text-xs text-muted-foreground">Email</div>
                          {canViewPii ? (
                            <a href={`mailto:${lead.email}`} className="text-sm font-medium text-primary hover:underline">
                              {lead.email}
                            </a>
                          ) : (
                            <span className="text-sm font-medium">{maskEmail(lead.email)}</span>
                          )}
                        </div>
                      </div>
                    )}
                  </div>
                </Card>

                {/* Wolf Brain Score */}
                <Card className="p-4 bg-gradient-to-br from-primary/10 to-secondary/10">
                  <h3 className="text-sm font-semibold text-foreground mb-3 flex items-center gap-2">
                    <TrendingUp className="h-4 w-4 text-primary" />
                    Wolf Brain Score
                  </h3>
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="text-3xl font-bold text-primary">
                        {lead.ai_score || 0}
                      </div>
                      <div className="text-xs text-muted-foreground mt-1">
                        Priority {lead.ai_priority || 'B'}
                      </div>
                    </div>
                    <Badge 
                      variant={lead.ai_recommended_path === 'fast_track_funding' ? 'default' : 'secondary'}
                      className="text-xs"
                    >
                      {lead.ai_recommended_path === 'credit_fix_first' ? 'Credit Fix' : 'Funding Ready'}
                    </Badge>
                  </div>
                </Card>

                {/* Path Recommendation */}
                <Card className="p-4">
                  <h3 className="text-sm font-semibold text-foreground mb-3">Recommended Path</h3>
                  <div className="text-sm text-muted-foreground">
                    {lead.ai_recommended_path === 'credit_fix_first' 
                      ? 'Start with credit repair. Expected timeline: 30-90 days. Then refund immediately for better terms.'
                      : 'Strong profile. Direct to Fast Track funding application. Expected approval: 24-48 hours.'}
                  </div>
                </Card>

                {/* Risk Flags */}
                {lead.ai_risk_flags && lead.ai_risk_flags.length > 0 && (
                  <Card className="p-4 bg-amber-50 dark:bg-amber-950/20 border-amber-200">
                    <h3 className="text-sm font-semibold text-amber-900 dark:text-amber-200 mb-3">
                      ⚠️ Risk Flags
                    </h3>
                    <div className="flex flex-wrap gap-2">
                      {lead.ai_risk_flags.map((flag: string) => (
                        <Badge key={flag} variant="outline" className="bg-amber-100 text-amber-800">
                          {flag.replace('_', ' ')}
                        </Badge>
                      ))}
                    </div>
                  </Card>
                )}

                {/* Funding Capacity */}
                {lead.requested_amount && (
                  <Card className="p-4">
                    <h3 className="text-sm font-semibold text-foreground mb-3">Funding Capacity Estimate</h3>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Requested:</span>
                        <span className="font-semibold">${lead.requested_amount.toLocaleString()}</span>
                      </div>
                      {lead.est_credit_score && (
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Est. Credit:</span>
                          <span className="font-semibold">{lead.est_credit_score}</span>
                        </div>
                      )}
                      <Separator />
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Potential Range:</span>
                        <span className="font-semibold text-emerald-600">
                          ${Math.round(lead.requested_amount * 0.8).toLocaleString()} - ${Math.round(lead.requested_amount * 1.5).toLocaleString()}
                        </span>
                      </div>
                    </div>
                  </Card>
                )}
              </div>
            </ScrollArea>
          </TabsContent>

          {/* Notes Tab */}
          <TabsContent value="notes" className="mt-4">
            <ScrollArea className="h-[calc(100vh-200px)]">
              <div className="space-y-3">
                {lead.notes ? (
                  <Card className="p-4">
                    <div className="text-sm text-foreground whitespace-pre-wrap">{lead.notes}</div>
                  </Card>
                ) : (
                  <div className="text-center py-12 text-muted-foreground text-sm">
                    No notes yet
                  </div>
                )}
              </div>
            </ScrollArea>
          </TabsContent>

          {/* Call History Tab */}
          <TabsContent value="history" className="mt-4">
            <ScrollArea className="h-[calc(100vh-200px)]">
              <div className="space-y-2">
                {lead.attempt_history && lead.attempt_history.length > 0 ? (
                  lead.attempt_history.map((attempt: any, i: number) => (
                    <Card key={i} className="p-3">
                      <div className="flex items-start gap-3">
                        <Clock className="h-4 w-4 text-muted-foreground mt-0.5" />
                        <div className="flex-1">
                          <div className="flex items-center justify-between mb-1">
                            <span className="text-sm font-medium text-foreground">
                              Attempt #{i + 1}
                            </span>
                            <Badge variant="outline" className="text-xs">
                              {attempt.result || 'no_answer'}
                            </Badge>
                          </div>
                          <div className="text-xs text-muted-foreground">
                            {new Date(attempt.time).toLocaleString()}
                          </div>
                          {attempt.notes && (
                            <div className="text-xs text-foreground mt-2 italic">
                              "{attempt.notes}"
                            </div>
                          )}
                        </div>
                      </div>
                    </Card>
                  ))
                ) : (
                  <div className="text-center py-12 text-muted-foreground text-sm">
                    No call history yet
                  </div>
                )}
              </div>
            </ScrollArea>
          </TabsContent>

          {/* Documents Tab */}
          <TabsContent value="docs" className="mt-4">
            <ScrollArea className="h-[calc(100vh-200px)]">
              <div className="text-center py-12 text-muted-foreground text-sm">
                <FileText className="h-12 w-12 mx-auto mb-3 opacity-50" />
                No documents uploaded yet
              </div>
            </ScrollArea>
          </TabsContent>
        </Tabs>
      </SheetContent>
    </Sheet>
  );
};