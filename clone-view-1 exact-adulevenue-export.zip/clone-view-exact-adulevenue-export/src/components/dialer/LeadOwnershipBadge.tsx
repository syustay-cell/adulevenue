import { Lock, Users } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';

interface LeadOwnershipBadgeProps {
  currentOwnerId: string | null;
  currentOwnerEmail: string | null;
  lockExpiresAt: string | null;
  lockReason: string | null;
  currentUserId: string;
}

export function LeadOwnershipBadge({
  currentOwnerId,
  currentOwnerEmail,
  lockExpiresAt,
  lockReason,
  currentUserId,
}: LeadOwnershipBadgeProps) {
  if (!currentOwnerId) return null;

  const isOwner = currentOwnerId === currentUserId;
  const expiresIn = lockExpiresAt
    ? formatDistanceToNow(new Date(lockExpiresAt), { addSuffix: true })
    : null;

  return (
    <div
      className={[
        'inline-flex items-center gap-2 rounded-full px-3 py-1.5 text-xs font-medium',
        isOwner
          ? 'bg-emerald-500/10 text-emerald-300'
          : 'bg-amber-500/10 text-amber-300',
      ].join(' ')}
    >
      {isOwner ? (
        <Lock className="h-3.5 w-3.5" />
      ) : (
        <Users className="h-3.5 w-3.5" />
      )}
      <span>
        {isOwner
          ? `Owned by you`
          : `Owned by ${currentOwnerEmail?.split('@')[0] || 'another worker'}`}
      </span>
      {expiresIn && (
        <span className="opacity-70">• Expires {expiresIn}</span>
      )}
    </div>
  );
}
