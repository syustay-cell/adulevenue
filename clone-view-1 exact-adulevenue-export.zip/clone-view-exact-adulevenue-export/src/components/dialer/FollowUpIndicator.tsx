import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Badge } from "@/components/ui/badge";
import { AlertTriangle } from "lucide-react";

interface FollowUpIndicatorProps {
  leadId: string;
}

export function FollowUpIndicator({ leadId }: FollowUpIndicatorProps) {
  const [pendingCount, setPendingCount] = useState(0);

  useEffect(() => {
    if (!leadId) return;
    
    const fetchPendingTasks = async () => {
      const { count, error } = await supabase
        .from("outreach_tasks")
        .select("*", { count: "exact", head: true })
        .eq("lead_id", leadId)
        .eq("status", "pending");

      if (!error && count) {
        setPendingCount(count);
      }
    };

    fetchPendingTasks();
  }, [leadId]);

  if (pendingCount === 0) return null;

  return (
    <Badge variant="destructive" className="text-xs flex items-center gap-1">
      <AlertTriangle className="h-3 w-3" />
      {pendingCount} Follow-up{pendingCount > 1 ? "s" : ""} due
    </Badge>
  );
}
