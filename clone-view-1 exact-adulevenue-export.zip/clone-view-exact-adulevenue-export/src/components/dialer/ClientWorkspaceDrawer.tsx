import { useState, useEffect } from "react";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { useUserRoles } from "@/hooks/useUserRoles";
import { canViewRawPii, maskEmail, maskPhone } from "@/lib/masking";
import type { AppRole } from "@/lib/permissions";
import { 
  Phone, Mail, Building2, User, Clock, MessageSquare, 
  Send, FileText, CreditCard, AlertCircle, Plus, Loader2
} from "lucide-react";
import { format, formatDistanceToNow } from "date-fns";
import { SendInfoModal } from "./SendInfoModal";

function isDebugEnabled() {
  try {
    return new URLSearchParams(window.location.search).get("debug") === "1";
  } catch {
    return false;
  }
}

function safeParseDate(field: string, value: unknown): Date | null {
  const d = new Date(value as any);
  const invalid = Number.isNaN(d.getTime());
  if (invalid) {
    if (isDebugEnabled()) {
      console.warn("[RC_DATE_INPUT]", { field, value });
    }
    return null;
  }
  return d;
}

interface ClientWorkspaceDrawerProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  lead: any;
  workerId: string;
  onLeadUpdated?: () => void;
}

interface TimelineEvent {
  id: string;
  type: 'call' | 'sms' | 'email' | 'note' | 'status';
  title: string;
  description: string;
  worker_email?: string;
  created_at: string;
  metadata?: any;
}

export function ClientWorkspaceDrawer({ 
  open, 
  onOpenChange, 
  lead, 
  workerId,
  onLeadUpdated 
}: ClientWorkspaceDrawerProps) {
  const { roles } = useUserRoles();
  const canViewPii = canViewRawPii((roles as AppRole[]) || []);
  const [timeline, setTimeline] = useState<TimelineEvent[]>([]);
  const [loading, setLoading] = useState(false);
  const [noteText, setNoteText] = useState("");
  const [addingNote, setAddingNote] = useState(false);
  const [sendInfoOpen, setSendInfoOpen] = useState(false);
  const [filter, setFilter] = useState<'all' | 'call' | 'sms' | 'email' | 'note'>('all');

  useEffect(() => {
    if (open && lead?.id) {
      loadTimeline();
    }
  }, [open, lead?.id]);

  const loadTimeline = async () => {
    if (!lead?.id) return;
    setLoading(true);
    
    try {
      // Load all data in parallel - including unified client_activity table
      const [callsRes, callAttemptsRes, commsRes, notesRes, activityRes] = await Promise.all([
        supabase.from("calls").select("*").eq("lead_id", lead.id).order("created_at", { ascending: false }),
        supabase.from("lead_call_attempts").select("*").eq("lead_id", lead.id).order("created_at", { ascending: false }),
        supabase.from("client_communications").select("*").eq("lead_id", lead.id).order("created_at", { ascending: false }),
        supabase.from("client_notes").select("*").eq("lead_id", lead.id).order("created_at", { ascending: false }),
        supabase.from("client_activity").select("*").eq("lead_id", lead.id).order("created_at", { ascending: false }).limit(100),
      ]);

      const events: TimelineEvent[] = [];

      // Add calls from calls table
      callsRes.data?.forEach(c => {
        events.push({
          id: c.id,
          type: 'call',
          title: `Call: ${c.outcome}`,
          description: c.notes || `Duration: ${c.duration_seconds || 0}s`,
          created_at: c.created_at || new Date().toISOString(),
        });
      });

      // Add call attempts from lead_call_attempts
      callAttemptsRes.data?.forEach(c => {
        events.push({
          id: c.id,
          type: 'call',
          title: `Call: ${c.outcome}`,
          description: c.notes || `Duration: ${c.duration_seconds || 0}s`,
          worker_email: c.agent_email,
          created_at: c.created_at || new Date().toISOString(),
        });
      });

      // Add communications (SMS/Email)
      commsRes.data?.forEach(c => {
        events.push({
          id: c.id,
          type: c.channel as 'sms' | 'email',
          title: c.channel === 'sms' ? `SMS: ${c.template_type}` : `Email: ${c.subject || c.template_type}`,
          description: c.body?.substring(0, 100) + (c.body?.length > 100 ? '...' : ''),
          worker_email: c.worker_email,
          created_at: c.created_at,
          metadata: { status: c.status },
        });
      });

      // Add notes
      notesRes.data?.forEach(n => {
        events.push({
          id: n.id,
          type: 'note',
          title: 'Note',
          description: n.note,
          worker_email: n.worker_email,
          created_at: n.created_at,
        });
      });

      // Add unified client_activity events (system events, locks, status changes)
      activityRes.data?.forEach((a: any) => {
        // Map activity type to timeline event type
        const typeMap: Record<string, TimelineEvent['type']> = {
          call: 'call',
          sms: 'sms',
          email: 'email',
          note: 'note',
        };
        const mappedType = typeMap[a.type] || 'status';
        
        events.push({
          id: a.id,
          type: mappedType,
          title: a.subject || `${a.type.charAt(0).toUpperCase()}${a.type.slice(1)}`,
          description: a.body || '',
          worker_email: undefined, // client_activity doesn't have worker_email directly
          created_at: a.created_at,
          metadata: a.meta,
        });
      });

      // Sort by date descending and dedupe by id
      const uniqueEvents = events.filter((event, index, self) => 
        index === self.findIndex(e => e.id === event.id)
      );
      uniqueEvents.sort((a, b) => {
        const bd = safeParseDate("timeline.created_at", b.created_at);
        const ad = safeParseDate("timeline.created_at", a.created_at);
        return (bd?.getTime() ?? 0) - (ad?.getTime() ?? 0);
      });
      setTimeline(uniqueEvents);
    } catch (error) {
      console.error("Failed to load timeline:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleAddNote = async () => {
    if (!noteText.trim() || !lead?.id) return;
    setAddingNote(true);

    try {
      const { data: { user } } = await supabase.auth.getUser();
      
      const { error } = await supabase.from("client_notes").insert({
        lead_id: lead.id,
        worker_id: workerId,
        worker_email: user?.email,
        note: noteText.trim(),
      });

      if (error) throw error;
      
      toast.success("Note added");
      setNoteText("");
      loadTimeline();
    } catch (error) {
      console.error("Failed to add note:", error);
      toast.error("Failed to add note");
    } finally {
      setAddingNote(false);
    }
  };

  const handleSendInfoSuccess = () => {
    loadTimeline();
    onLeadUpdated?.();
  };

  const getEventIcon = (type: string) => {
    switch (type) {
      case 'call': return <Phone className="h-4 w-4" />;
      case 'sms': return <MessageSquare className="h-4 w-4" />;
      case 'email': return <Mail className="h-4 w-4" />;
      case 'note': return <FileText className="h-4 w-4" />;
      default: return <AlertCircle className="h-4 w-4" />;
    }
  };

  const getEventColor = (type: string) => {
    switch (type) {
      case 'call': return 'bg-blue-500/10 text-blue-600 border-blue-500/20';
      case 'sms': return 'bg-green-500/10 text-green-600 border-green-500/20';
      case 'email': return 'bg-purple-500/10 text-purple-600 border-purple-500/20';
      case 'note': return 'bg-yellow-500/10 text-yellow-600 border-yellow-500/20';
      default: return 'bg-muted text-muted-foreground';
    }
  };

  if (!lead) return null;

  const lockExpiresAt = lead.lock_expires_at ? safeParseDate("lock_expires_at", lead.lock_expires_at) : null;
  const isLocked = lockExpiresAt ? lockExpiresAt > new Date() : false;
  const businessStartDate = lead.business_start_date
    ? safeParseDate("business_start_date", lead.business_start_date)
    : null;

  return (
    <>
      <Sheet open={open} onOpenChange={onOpenChange}>
        <SheetContent className="w-full sm:max-w-lg overflow-hidden flex flex-col">
          <SheetHeader className="pb-4 border-b">
            <SheetTitle className="flex items-center gap-2">
              <User className="h-5 w-5" />
              Client Workspace
            </SheetTitle>
          </SheetHeader>

          <Tabs defaultValue="snapshot" className="flex-1 flex flex-col overflow-hidden">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="snapshot">Snapshot</TabsTrigger>
              <TabsTrigger value="timeline">Timeline</TabsTrigger>
              <TabsTrigger value="actions">Actions</TabsTrigger>
            </TabsList>

            {/* Client Snapshot Tab */}
            <TabsContent value="snapshot" className="flex-1 overflow-auto mt-4 space-y-4">
              {/* Basic Info */}
              <div className="space-y-3">
                <div className="flex items-center gap-2">
                  <User className="h-4 w-4 text-muted-foreground" />
                  <span className="font-medium">{lead.full_name || lead.owner_full_name || "Unknown"}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Building2 className="h-4 w-4 text-muted-foreground" />
                  <span>{lead.business_name || "No business name"}</span>
                </div>
                {lead.phone && (
                  <div className="flex items-center gap-2">
                    <Phone className="h-4 w-4 text-muted-foreground" />
                    {canViewPii ? (
                      <a href={`tel:${lead.phone}`} className="text-primary hover:underline font-medium">
                        {lead.phone}
                      </a>
                    ) : (
                      <span className="font-medium">{maskPhone(lead.phone)}</span>
                    )}
                  </div>
                )}
                {lead.email && (
                  <div className="flex items-center gap-2">
                    <Mail className="h-4 w-4 text-muted-foreground" />
                    {canViewPii ? (
                      <a href={`mailto:${lead.email}`} className="text-primary hover:underline">
                        {lead.email}
                      </a>
                    ) : (
                      <span>{maskEmail(lead.email)}</span>
                    )}
                  </div>
                )}
              </div>

              {/* AI Scoring */}
              <div className="p-3 rounded-lg bg-muted/50 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">AI Score</span>
                  <Badge variant={lead.ai_score >= 70 ? "default" : lead.ai_score >= 40 ? "secondary" : "outline"}>
                    {lead.ai_score || 0}
                  </Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Priority</span>
                  <Badge variant={lead.ai_priority === 'A' ? "default" : "secondary"}>
                    {lead.ai_priority || "—"}
                  </Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Path</span>
                  <span className="text-sm font-medium">{lead.ai_recommended_path?.replace(/_/g, ' ') || "—"}</span>
                </div>
              </div>

              {/* Lock Status */}
              <div className="p-3 rounded-lg border space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">Lock Status</span>
                  {isLocked ? (
                    <Badge variant="default" className="bg-green-500/10 text-green-600 border-green-500/20">
                      Locked
                    </Badge>
                  ) : (
                    <Badge variant="outline">Available</Badge>
                  )}
                </div>
                {isLocked && (
                  <>
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">Owner</span>
                      <span>{lead.locked_by_worker_email || lead.current_owner_email || "—"}</span>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">Expires</span>
                      <span className="flex items-center gap-1">
                        <Clock className="h-3 w-3" />
                        {lockExpiresAt ? formatDistanceToNow(lockExpiresAt, { addSuffix: true }) : "—"}
                      </span>
                    </div>
                    {lead.lock_reason && (
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-muted-foreground">Reason</span>
                        <span>{lead.lock_reason}</span>
                      </div>
                    )}
                  </>
                )}
              </div>

              {/* Financial Info */}
              {(lead.estimated_monthly_revenue || lead.business_start_date) && (
                <div className="p-3 rounded-lg border space-y-2">
                  <span className="text-sm font-medium">Business Info</span>
                  {lead.estimated_monthly_revenue && (
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">Monthly Revenue</span>
                      <span className="font-medium">${Number(lead.estimated_monthly_revenue).toLocaleString()}</span>
                    </div>
                  )}
                  {businessStartDate && (
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">Started</span>
                      <span>{format(businessStartDate, "MMM yyyy")}</span>
                    </div>
                  )}
                </div>
              )}
            </TabsContent>

            {/* Timeline Tab */}
            <TabsContent value="timeline" className="flex-1 overflow-hidden mt-4 flex flex-col">
              {/* Filter Buttons */}
              <div className="flex gap-1 mb-3 flex-wrap">
                {(['all', 'call', 'sms', 'email', 'note'] as const).map((f) => (
                  <Button
                    key={f}
                    size="sm"
                    variant={filter === f ? "default" : "outline"}
                    onClick={() => setFilter(f)}
                    className="h-7 text-xs px-2"
                  >
                    {f === 'all' ? 'All' : f === 'call' ? '📞 Calls' : f === 'sms' ? '💬 SMS' : f === 'email' ? '📧 Email' : '📝 Notes'}
                  </Button>
                ))}
              </div>

              {/* Add Note */}
              <div className="flex gap-2 mb-4">
                <Textarea
                  placeholder="Add a note..."
                  value={noteText}
                  onChange={(e) => setNoteText(e.target.value)}
                  className="min-h-[60px] resize-none"
                />
                <Button 
                  size="icon" 
                  onClick={handleAddNote} 
                  disabled={!noteText.trim() || addingNote}
                >
                  {addingNote ? <Loader2 className="h-4 w-4 animate-spin" /> : <Plus className="h-4 w-4" />}
                </Button>
              </div>

              <ScrollArea className="flex-1">
                {loading ? (
                  <div className="flex items-center justify-center py-8">
                    <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
                  </div>
                ) : timeline.filter(e => filter === 'all' || e.type === filter).length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">
                    {filter === 'all' ? 'No activity yet' : `No ${filter} activity`}
                  </div>
                ) : (
                  <div className="space-y-3 pr-4">
                    {timeline
                      .filter(e => filter === 'all' || e.type === filter)
                      .map((event) => (
                      <div 
                        key={event.id} 
                        className={`p-3 rounded-lg border ${getEventColor(event.type)}`}
                      >
                        <div className="flex items-start gap-2">
                          {getEventIcon(event.type)}
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center justify-between">
                              <span className="font-medium text-sm">{event.title}</span>
                              {event.metadata?.status && (
                                <Badge variant="outline" className="text-xs">
                                  {event.metadata.status}
                                </Badge>
                              )}
                            </div>
                            <p className="text-sm text-muted-foreground mt-1 break-words">
                              {event.description}
                            </p>
                            <div className="flex items-center gap-2 mt-2 text-xs text-muted-foreground">
                              {(() => {
                                const d = safeParseDate("timeline.created_at", event.created_at);
                                return <span>{d ? format(d, "MMM d, h:mm a") : "—"}</span>;
                              })()}
                              {event.worker_email && (
                                <>
                                  <span>•</span>
                                  <span>{event.worker_email}</span>
                                </>
                              )}
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </ScrollArea>
            </TabsContent>

            {/* Actions Tab */}
            <TabsContent value="actions" className="flex-1 mt-4 space-y-3">
              <Button 
                className="w-full justify-start gap-2" 
                onClick={() => setSendInfoOpen(true)}
              >
                <Send className="h-4 w-4" />
                Send Info (SMS / Email)
              </Button>

              <Button 
                variant="outline" 
                className="w-full justify-start gap-2"
                onClick={() => {
                  // Add note modal or inline
                }}
              >
                <FileText className="h-4 w-4" />
                Add Note
              </Button>

              <Button 
                variant="outline" 
                className="w-full justify-start gap-2"
                onClick={async () => {
                  try {
                    await supabase.rpc("lock_lead_for_client_work", {
                      p_lead_id: lead.id,
                      p_worker_id: workerId,
                      p_reason: "application_started"
                    });
                    toast.success("Lead locked - Application Started");
                    onLeadUpdated?.();
                  } catch (error) {
                    toast.error("Failed to lock lead");
                  }
                }}
              >
                <CreditCard className="h-4 w-4" />
                Mark as Application Started
              </Button>
            </TabsContent>
          </Tabs>
        </SheetContent>
      </Sheet>

      <SendInfoModal
        open={sendInfoOpen}
        onOpenChange={setSendInfoOpen}
        lead={lead}
        workerId={workerId}
        onSuccess={handleSendInfoSuccess}
      />
    </>
  );
}