import { useState, useEffect } from "react";
import { Bell, CheckCircle, XCircle, Users, Clock, DollarSign } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

interface NotificationsPanelProps {
  userId: string;
  onApproveRequest?: (requestId: string) => Promise<void>;
}

interface Notification {
  id: string;
  type: 'share_request' | 'share_approved' | 'share_declined' | 'lock_expiring' | 'commission';
  title: string;
  message: string;
  created_at: string;
  read: boolean;
  action_id?: string;
}

export const NotificationsPanel = ({ userId, onApproveRequest }: NotificationsPanelProps) => {
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [isOpen, setIsOpen] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    if (userId) {
      loadNotifications();
      const cleanup = subscribeToNotifications();
      return cleanup;
    }
  }, [userId]);

  const loadNotifications = async () => {
    if (!userId) return;

    // Load lock requests
    const { data: requests } = await supabase
      .from('lead_lock_requests')
      .select('*, leads(full_name)')
      .or(`from_agent_id.eq.${userId},to_agent_id.eq.${userId}`)
      .order('created_at', { ascending: false })
      .limit(20);

    if (requests) {
      const notifs: Notification[] = requests.map(req => ({
        id: req.id,
        type: req.status === 'pending' ? 'share_request' : 
              req.status === 'approved' ? 'share_approved' : 'share_declined',
        title: req.from_agent_id === userId 
          ? `Request ${req.status}` 
          : 'New Lead Request',
        message: req.from_agent_id === userId
          ? `Your ${req.request_type === 'release' ? 'release' : '50/50'} request was ${req.status}`
          : `${req.from_agent_email} wants to ${req.request_type === 'release' ? 'take over' : 'split 50/50'} ${req.leads?.full_name}`,
        created_at: req.created_at,
        read: req.status !== 'pending',
        action_id: req.id
      }));

      setNotifications(notifs);
      setUnreadCount(notifs.filter(n => !n.read).length);
    }
  };

  const subscribeToNotifications = () => {
    const channel = supabase
      .channel('lock_notifications')
      .on('postgres_changes', {
        event: '*',
        schema: 'public',
        table: 'lead_lock_requests',
        filter: `to_agent_id=eq.${userId}`
      }, () => {
        loadNotifications();
        toast({
          title: "New Lead Request",
          description: "Someone wants to share one of your locked leads",
        });
      })
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  };

  const handleApprove = async (requestId: string) => {
    try {
      await supabase.rpc('respond_to_lead_lock_request', {
        p_request_id: requestId,
        p_decision: 'approve'
      });
      
      toast({ 
        title: "Request approved",
        description: "Lead has been shared"
      });
      
      if (onApproveRequest) {
        await onApproveRequest(requestId);
      }
      
      loadNotifications();
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Failed to approve",
        description: error.message
      });
    }
  };

  const handleReject = async (requestId: string) => {
    try {
      await supabase.rpc('respond_to_lead_lock_request', {
        p_request_id: requestId,
        p_decision: 'reject'
      });
      
      toast({ 
        title: "Request rejected",
      });
      
      loadNotifications();
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Failed to reject",
        description: error.message
      });
    }
  };

  const getIcon = (type: string) => {
    switch (type) {
      case 'share_request': return <Users className="h-4 w-4 text-blue-600" />;
      case 'share_approved': return <CheckCircle className="h-4 w-4 text-emerald-600" />;
      case 'share_declined': return <XCircle className="h-4 w-4 text-rose-600" />;
      case 'lock_expiring': return <Clock className="h-4 w-4 text-amber-600" />;
      case 'commission': return <DollarSign className="h-4 w-4 text-gold" />;
      default: return <Bell className="h-4 w-4" />;
    }
  };

  return (
    <div className="relative">
      <Button
        variant="outline"
        size="icon"
        className="relative"
        onClick={() => setIsOpen(!isOpen)}
      >
        <Bell className="h-5 w-5" />
        {unreadCount > 0 && (
          <Badge 
            variant="destructive" 
            className="absolute -top-2 -right-2 h-5 w-5 flex items-center justify-center p-0 text-[10px]"
          >
            {unreadCount}
          </Badge>
        )}
      </Button>

      {isOpen && (
        <Card className="absolute right-0 top-12 w-80 sm:w-96 shadow-lg z-50">
          <div className="p-4 border-b">
            <h3 className="font-semibold text-foreground flex items-center gap-2">
              <Bell className="h-4 w-4" />
              Notifications
              {unreadCount > 0 && (
                <Badge variant="secondary" className="ml-auto">
                  {unreadCount} new
                </Badge>
              )}
            </h3>
          </div>
          
          <ScrollArea className="h-[400px]">
            {notifications.length === 0 ? (
              <div className="p-8 text-center text-muted-foreground text-sm">
                No notifications yet
              </div>
            ) : (
              <div className="divide-y">
                {notifications.map(notif => (
                  <div
                    key={notif.id}
                    className={`p-4 hover:bg-muted/30 transition-colors ${
                      !notif.read ? 'bg-primary/5' : ''
                    }`}
                  >
                    <div className="flex items-start gap-3">
                      <div className="mt-1">{getIcon(notif.type)}</div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-foreground truncate">
                          {notif.title}
                        </p>
                        <p className="text-xs text-muted-foreground mt-1 line-clamp-2">
                          {notif.message}
                        </p>
                        <p className="text-[10px] text-muted-foreground mt-1">
                          {new Date(notif.created_at).toLocaleDateString()} at{' '}
                          {new Date(notif.created_at).toLocaleTimeString()}
                        </p>
                        
                        {/* Action buttons for pending requests */}
                        {!notif.read && notif.type === 'share_request' && notif.action_id && (
                          <div className="flex gap-2 mt-3">
                            <Button
                              size="sm"
                              onClick={() => handleApprove(notif.action_id!)}
                              className="h-7 text-xs"
                            >
                              Approve
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleReject(notif.action_id!)}
                              className="h-7 text-xs"
                            >
                              Reject
                            </Button>
                          </div>
                        )}
                      </div>
                      {!notif.read && (
                        <div className="h-2 w-2 rounded-full bg-primary flex-shrink-0 mt-2" />
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </ScrollArea>
        </Card>
      )}
    </div>
  );
};