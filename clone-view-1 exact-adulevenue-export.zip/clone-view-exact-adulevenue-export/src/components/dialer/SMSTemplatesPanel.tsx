import { useState } from "react";
import { MessageSquare, Send, Copy, Check } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Card } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";

interface SMSTemplatesPanelProps {
  lead: any;
  isOpen: boolean;
  onClose: () => void;
  onSend: (message: string) => Promise<void>;
}

const templates = [
  {
    id: 'funding_app',
    name: 'Funding Application Link',
    icon: '💰',
    message: 'Hi {name}, great speaking with you! Here\'s your Wolf Fund Capital application: [LINK]. Takes 3 minutes. Let me know when submitted!'
  },
  {
    id: 'credit_repair',
    name: 'Credit Repair Link',
    icon: '🔧',
    message: 'Hi {name}, let\'s fix your credit first, then get you funded! Start here: [LINK]. 30-90 days to approval. I\'ll guide you through it.'
  },
  {
    id: 'follow_up',
    name: 'Quick Follow-up',
    icon: '👋',
    message: 'Hey {name}, following up on our call. Still interested in funding? Let me know and I\'ll send the application right over!'
  },
  {
    id: 'missed_call',
    name: 'Missed Call',
    icon: '📞',
    message: 'Hi {name}, I tried calling about your funding request. When\'s a good time to chat? I can get you approved in 24-48 hours.'
  },
  {
    id: 'interest_confirm',
    name: 'Interest Confirmation',
    icon: '✅',
    message: 'Perfect {name}! I\'m sending the application now. Complete it ASAP - funding decisions happen within 48 hours. Questions? Text me back!'
  },
  {
    id: 'doc_request',
    name: 'Document Request',
    icon: '📄',
    message: 'Hi {name}, to move forward I need: 3 months bank statements, driver\'s license (front/back), voided check. Can you send those over?'
  },
  {
    id: 'bank_statement',
    name: 'Bank Statement Request',
    icon: '🏦',
    message: '{name}, last step! Need your last 3 months of bank statements to finalize approval. PDF or screenshots work. Send when ready!'
  }
];

export const SMSTemplatesPanel = ({ lead, isOpen, onClose, onSend }: SMSTemplatesPanelProps) => {
  const [selectedTemplate, setSelectedTemplate] = useState<string | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [sending, setSending] = useState(false);
  const { toast } = useToast();

  const fillTemplate = (template: string) => {
    const firstName = lead.full_name?.split(' ')[0] || 'there';
    return template
      .replace('{name}', firstName)
      .replace('[LINK]', 'https://wolf-fund.com/apply');
  };

  const handleCopy = (templateId: string, message: string) => {
    const filled = fillTemplate(message);
    navigator.clipboard.writeText(filled);
    setCopiedId(templateId);
    setTimeout(() => setCopiedId(null), 2000);
    toast({ title: "Copied to clipboard" });
  };

  const handleSend = async (message: string) => {
    setSending(true);
    try {
      const filled = fillTemplate(message);
      await onSend(filled);
      toast({ title: "SMS sent successfully!" });
      onClose();
    } catch (error) {
      toast({ 
        title: "Failed to send SMS",
        description: "Please try again",
        variant: "destructive"
      });
    } finally {
      setSending(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[600px] max-h-[80vh]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <MessageSquare className="h-5 w-5 text-primary" />
            SMS Templates
          </DialogTitle>
          <DialogDescription>
            Quick message templates for {lead.full_name?.split(' ')[0] || 'lead'}
          </DialogDescription>
        </DialogHeader>

        <ScrollArea className="h-[500px] pr-4">
          <div className="space-y-3">
            {templates.map(template => (
              <Card 
                key={template.id}
                className="p-4 hover:bg-muted/50 transition-colors cursor-pointer"
                onClick={() => setSelectedTemplate(template.id)}
              >
                <div className="flex items-start justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <span className="text-2xl">{template.icon}</span>
                    <h4 className="font-semibold text-sm text-foreground">{template.name}</h4>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={(e) => {
                      e.stopPropagation();
                      handleCopy(template.id, template.message);
                    }}
                    className="h-8 w-8 p-0"
                  >
                    {copiedId === template.id ? (
                      <Check className="h-4 w-4 text-emerald-600" />
                    ) : (
                      <Copy className="h-4 w-4" />
                    )}
                  </Button>
                </div>

                <p className="text-sm text-muted-foreground leading-relaxed">
                  {fillTemplate(template.message)}
                </p>

                {selectedTemplate === template.id && (
                  <div className="mt-3 pt-3 border-t flex gap-2">
                    <Button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleSend(template.message);
                      }}
                      disabled={sending}
                      className="flex-1 bg-emerald-600 hover:bg-emerald-700"
                    >
                      <Send className="h-4 w-4 mr-2" />
                      Send SMS
                    </Button>
                    <Button
                      variant="outline"
                      onClick={(e) => {
                        e.stopPropagation();
                        setSelectedTemplate(null);
                      }}
                    >
                      Cancel
                    </Button>
                  </div>
                )}
              </Card>
            ))}
          </div>
        </ScrollArea>
      </DialogContent>
    </Dialog>
  );
};