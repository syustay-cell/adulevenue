import { useEffect, useState } from "react";
import { Activity, Users, TrendingUp, DollarSign, Phone, Target } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { supabase } from "@/integrations/supabase/client";

interface AgentActivity {
  worker_id: string;
  worker_email: string;
  status: 'active' | 'idle' | 'on_call';
  current_lead_id: string | null;
  calls_today: number;
  interested_today: number;
  locked_leads: number;
  last_activity: string;
}

export const AdminMonitorView = () => {
  const [agents, setAgents] = useState<AgentActivity[]>([]);
  const [leaderboard, setLeaderboard] = useState<any[]>([]);
  const [activityFeed, setActivityFeed] = useState<any[]>([]);

  useEffect(() => {
    loadAgentActivity();
    loadLeaderboard();
    loadActivityFeed();

    // Real-time updates
    const channel = supabase
      .channel('admin_monitor')
      .on('postgres_changes', {
        event: '*',
        schema: 'public',
        table: 'call_sessions'
      }, () => loadAgentActivity())
      .on('postgres_changes', {
        event: '*',
        schema: 'public',
        table: 'lead_call_logs'
      }, () => {
        loadLeaderboard();
        loadActivityFeed();
      })
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  const loadAgentActivity = async () => {
    // Fetch all active sessions and worker stats
    const { data: sessions } = await supabase
      .from('call_sessions')
      .select('*')
      .eq('is_active', true);

    // Get call logs for today
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    const { data: logs } = await supabase
      .from('lead_call_logs')
      .select('worker_id, outcome')
      .gte('created_at', today.toISOString());

    // Get locked leads count per worker
    const { data: leads } = await supabase
      .from('leads')
      .select('owner_id')
      .not('owner_id', 'is', null)
      .gt('lock_expires_at', new Date().toISOString());

    // Aggregate data (simplified)
    const agentMap = new Map<string, AgentActivity>();
    
    sessions?.forEach(session => {
      agentMap.set(session.worker_id, {
        worker_id: session.worker_id,
        worker_email: 'agent@example.com', // TODO: join with users
        status: 'active',
        current_lead_id: null,
        calls_today: 0,
        interested_today: 0,
        locked_leads: 0,
        last_activity: session.started_at
      });
    });

    logs?.forEach(log => {
      const agent = agentMap.get(log.worker_id);
      if (agent) {
        agent.calls_today++;
        if (log.outcome === 'interested') agent.interested_today++;
      }
    });

    leads?.forEach(lead => {
      if (lead.owner_id) {
        const agent = agentMap.get(lead.owner_id);
        if (agent) agent.locked_leads++;
      }
    });

    setAgents(Array.from(agentMap.values()));
  };

  const loadLeaderboard = async () => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const { data } = await supabase
      .from('lead_call_logs')
      .select('worker_id, outcome')
      .gte('created_at', today.toISOString());

    // Aggregate by worker
    const workerStats = new Map<string, any>();
    data?.forEach(log => {
      if (!workerStats.has(log.worker_id)) {
        workerStats.set(log.worker_id, {
          worker_id: log.worker_id,
          total_calls: 0,
          interested: 0,
          conversion_rate: 0
        });
      }
      const stats = workerStats.get(log.worker_id);
      stats.total_calls++;
      if (log.outcome === 'interested') stats.interested++;
      stats.conversion_rate = Math.round((stats.interested / stats.total_calls) * 100);
    });

    const sorted = Array.from(workerStats.values())
      .sort((a, b) => b.interested - a.interested)
      .slice(0, 10);

    setLeaderboard(sorted);
  };

  const loadActivityFeed = async () => {
    const { data } = await supabase
      .from('activity_feed')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(50);

    setActivityFeed(data || []);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-foreground">Admin Monitor</h2>
          <p className="text-muted-foreground">Real-time agent activity & performance</p>
        </div>
        <Badge variant="secondary" className="gap-2">
          <Activity className="h-3 w-3 animate-pulse" />
          Live
        </Badge>
      </div>

      {/* Agent Activity Heatmap */}
      <Card className="p-6">
        <h3 className="text-lg font-semibold text-foreground mb-4 flex items-center gap-2">
          <Users className="h-5 w-5 text-primary" />
          Agent Activity ({agents.length} active)
        </h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {agents.length === 0 ? (
            <div className="col-span-full text-center py-12 text-muted-foreground">
              No active agents right now
            </div>
          ) : (
            agents.map(agent => (
              <Card key={agent.worker_id} className="p-4 bg-gradient-to-br from-emerald-50 to-white border-2 border-emerald-200">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <div className="h-2 w-2 rounded-full bg-emerald-500 animate-pulse" />
                    <span className="font-semibold text-sm text-foreground truncate">
                      {agent.worker_email}
                    </span>
                  </div>
                  <Badge variant="secondary" className="text-xs">
                    {agent.status}
                  </Badge>
                </div>

                <div className="grid grid-cols-3 gap-2 text-center">
                  <div>
                    <div className="text-lg font-bold text-foreground">{agent.calls_today}</div>
                    <div className="text-[10px] text-muted-foreground">Calls</div>
                  </div>
                  <div>
                    <div className="text-lg font-bold text-emerald-600">{agent.interested_today}</div>
                    <div className="text-[10px] text-muted-foreground">Hot</div>
                  </div>
                  <div>
                    <div className="text-lg font-bold text-primary">{agent.locked_leads}</div>
                    <div className="text-[10px] text-muted-foreground">Locked</div>
                  </div>
                </div>
              </Card>
            ))
          )}
        </div>
      </Card>

      {/* Tabs: Leaderboard & Activity Feed */}
      <Tabs defaultValue="leaderboard">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="leaderboard">🏆 Leaderboard</TabsTrigger>
          <TabsTrigger value="activity">📊 Activity Feed</TabsTrigger>
        </TabsList>

        {/* Leaderboard */}
        <TabsContent value="leaderboard">
          <Card className="p-6">
            <h3 className="text-lg font-semibold text-foreground mb-4 flex items-center gap-2">
              <TrendingUp className="h-5 w-5 text-gold" />
              Top Performers Today
            </h3>

            {leaderboard.length === 0 ? (
              <div className="text-center py-12 text-muted-foreground">
                No calls logged today yet
              </div>
            ) : (
              <div className="space-y-3">
                {leaderboard.map((worker, index) => (
                  <div 
                    key={worker.worker_id}
                    className="flex items-center gap-4 p-4 rounded-lg bg-muted/30 hover:bg-muted/50 transition-colors"
                  >
                    <div className="text-2xl font-bold text-gold min-w-[40px]">
                      #{index + 1}
                    </div>
                    <div className="flex-1">
                      <div className="font-semibold text-foreground text-sm">
                        Worker {worker.worker_id.slice(0, 8)}...
                      </div>
                      <div className="text-xs text-muted-foreground mt-1">
                        {worker.total_calls} calls • {worker.interested} interested • {worker.conversion_rate}% conversion
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <Badge variant="secondary">{worker.total_calls} 📞</Badge>
                      <Badge className="bg-emerald-600">{worker.interested} ✅</Badge>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </Card>
        </TabsContent>

        {/* Activity Feed */}
        <TabsContent value="activity">
          <Card className="p-6">
            <h3 className="text-lg font-semibold text-foreground mb-4">Platform Activity</h3>
            <ScrollArea className="h-[500px]">
              {activityFeed.length === 0 ? (
                <div className="text-center py-12 text-muted-foreground">
                  No activity yet
                </div>
              ) : (
                <div className="space-y-2">
                  {activityFeed.map(activity => (
                    <div 
                      key={activity.id}
                      className="p-3 rounded-lg border bg-card hover:bg-muted/30 transition-colors"
                    >
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="text-sm font-medium text-foreground">
                            {activity.summary}
                          </div>
                          <div className="text-xs text-muted-foreground mt-1">
                            {new Date(activity.created_at).toLocaleString()}
                          </div>
                        </div>
                        <Badge variant="outline" className="text-xs">
                          {activity.event_type}
                        </Badge>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </ScrollArea>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};