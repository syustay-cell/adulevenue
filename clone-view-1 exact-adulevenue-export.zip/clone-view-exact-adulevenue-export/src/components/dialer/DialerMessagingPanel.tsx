import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { MessageSquare, Mail, Sparkles, Send } from "lucide-react";
import { useUserRoles } from "@/hooks/useUserRoles";
import { canViewRawPii, maskEmail, maskPhone } from "@/lib/masking";
import type { AppRole } from "@/lib/permissions";

interface Lead {
  id: string;
  phone?: string | null;
  email?: string | null;
  full_name?: string | null;
  business_name?: string | null;
}

interface DialerMessagingPanelProps {
  lead: Lead;
  onMessageSent?: () => void;
}

const SMS_TEMPLATES = [
  { id: "intro", label: "Intro", body: "Hi {{name}}, this is Wolf Fund. We help businesses like {{business}} access working capital quickly. Do you have 2 minutes to chat?" },
  { id: "followup", label: "Follow-up", body: "Hi {{name}}, following up on our conversation. Ready to discuss funding options for {{business}}?" },
  { id: "docs", label: "Docs Request", body: "Hi {{name}}, to move forward with your funding, please send your last 3 bank statements. Reply here or email them to us." },
  { id: "callback", label: "Callback", body: "Hi {{name}}, I tried calling but missed you. When's a good time to reconnect about funding for {{business}}?" },
];

const EMAIL_TEMPLATES = [
  { id: "intro", label: "Introduction", subject: "Business Funding Opportunity for {{business}}", body: "Hi {{name}},\n\nI hope this email finds you well. My name is [Your Name] from Wolf Fund.\n\nWe specialize in helping businesses like {{business}} access the working capital they need to grow.\n\nWould you have 15 minutes this week for a quick call?\n\nBest regards" },
  { id: "followup", label: "Follow-up", subject: "Following Up - {{business}} Funding", body: "Hi {{name}},\n\nI wanted to follow up on my previous message regarding funding opportunities for {{business}}.\n\nWe have several programs that could be a great fit. Let me know if you'd like to learn more.\n\nBest regards" },
  { id: "docs", label: "Document Request", subject: "Documents Needed - {{business}}", body: "Hi {{name}},\n\nThank you for your interest in working with Wolf Fund.\n\nTo move forward, please send:\n- Last 3 months bank statements\n- Valid ID\n\nYou can reply directly to this email with the attachments.\n\nBest regards" },
];

export function DialerMessagingPanel({ lead, onMessageSent }: DialerMessagingPanelProps) {
  const { roles } = useUserRoles();
  const canViewPii = canViewRawPii((roles as AppRole[]) || []);
  const [smsBody, setSmsBody] = useState("");
  const [emailBody, setEmailBody] = useState("");
  const [emailSubject, setEmailSubject] = useState("");
  const [sendingSms, setSendingSms] = useState(false);
  const [sendingEmail, setSendingEmail] = useState(false);
  const [generatingSms, setGeneratingSms] = useState(false);
  const [generatingEmail, setGeneratingEmail] = useState(false);

  const canSms = !!lead.phone;
  const canEmail = !!lead.email;

  const personalize = (text: string) => {
    return text
      .replace(/\{\{name\}\}/g, lead.full_name || "there")
      .replace(/\{\{business\}\}/g, lead.business_name || "your business");
  };

  const handleSelectSmsTemplate = (template: typeof SMS_TEMPLATES[0]) => {
    setSmsBody(personalize(template.body));
  };

  const handleSelectEmailTemplate = (template: typeof EMAIL_TEMPLATES[0]) => {
    setEmailSubject(personalize(template.subject));
    setEmailBody(personalize(template.body));
  };

  const handleAiRewriteSms = async () => {
    if (!smsBody.trim()) {
      toast.error("Enter some text first");
      return;
    }
    setGeneratingSms(true);
    try {
      const { data, error } = await supabase.functions.invoke("ai-draft-outreach", {
        body: {
          channel: "sms",
          lead_context: {
            name: lead.full_name,
            business: lead.business_name,
          },
          current_draft: smsBody,
          action: "rewrite",
        },
      });
      if (error) {
        console.error("[DialerMessagingPanel] AI SMS transport error:", error);
        toast.error("Connection issue. Please try again.");
        return;
      }
      if (!data?.ok) {
        toast.error(data?.message || "AI rewrite unavailable");
        return;
      }
      if (data?.draft) {
        setSmsBody(data.draft);
        toast.success("SMS rewritten by AI");
      }
    } catch (e) {
      console.error("[DialerMessagingPanel] AI SMS error:", e);
      toast.error("AI rewrite failed");
    } finally {
      setGeneratingSms(false);
    }
  };

  const handleAiRewriteEmail = async () => {
    if (!emailBody.trim()) {
      toast.error("Enter some text first");
      return;
    }
    setGeneratingEmail(true);
    try {
      const { data, error } = await supabase.functions.invoke("ai-draft-outreach", {
        body: {
          channel: "email",
          lead_context: {
            name: lead.full_name,
            business: lead.business_name,
          },
          current_draft: emailBody,
          subject: emailSubject,
          action: "rewrite",
        },
      });
      if (error) {
        console.error("[DialerMessagingPanel] AI Email transport error:", error);
        toast.error("Connection issue. Please try again.");
        return;
      }
      if (!data?.ok) {
        toast.error(data?.message || "AI rewrite unavailable");
        return;
      }
      if (data?.draft) {
        setEmailBody(data.draft);
        if (data.subject) setEmailSubject(data.subject);
        toast.success("Email rewritten by AI");
      }
    } catch (e) {
      console.error("[DialerMessagingPanel] AI Email error:", e);
      toast.error("AI rewrite failed");
    } finally {
      setGeneratingEmail(false);
    }
  };

  const handleSendSms = async () => {
    if (!canSms || !smsBody.trim()) return;
    setSendingSms(true);
    try {
      const { data, error } = await supabase.functions.invoke("send-smart-sms", {
        body: {
          lead_id: lead.id,
          to_phone: lead.phone,
          body: smsBody,
        },
      });
      if (error) {
        console.error("[DialerMessagingPanel] SMS transport error:", error);
        toast.error("Connection issue. Please try again.");
        return;
      }
      if (!data?.ok) {
        toast.error(data?.message || "Could not send SMS");
        return;
      }
      toast.success(`SMS sent to ${canViewPii ? lead.phone : maskPhone(lead.phone || null)}`);
      setSmsBody("");
      onMessageSent?.();
    } catch (e: unknown) {
      console.error("[DialerMessagingPanel] SMS error:", e);
      toast.error("Could not send SMS");
    } finally {
      setSendingSms(false);
    }
  };

  const handleSendEmail = async () => {
    if (!canEmail || !emailBody.trim() || !emailSubject.trim()) return;
    setSendingEmail(true);
    try {
      const { data, error } = await supabase.functions.invoke("send-smart-email", {
        body: {
          lead_id: lead.id,
          to_email: lead.email,
          subject: emailSubject,
          body: emailBody,
        },
      });
      if (error) throw error;
      if (!data?.success) throw new Error(data?.error || "Email failed");
      toast.success(`Email sent to ${canViewPii ? lead.email : maskEmail(lead.email || null)}`);
      setEmailBody("");
      setEmailSubject("");
      onMessageSent?.();
    } catch (e: unknown) {
      console.error("[DialerMessagingPanel] Email error:", e);
      toast.error(e instanceof Error ? e.message : "Could not send email");
    } finally {
      setSendingEmail(false);
    }
  };

  return (
    <div className="mt-4 rounded-xl border border-border bg-card/50 p-4">
      <div className="grid gap-4 md:grid-cols-2">
        {/* SMS V1 */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <MessageSquare className="h-4 w-4 text-emerald-600" />
              <span className="text-sm font-semibold">SMS V1</span>
            </div>
            {canSms ? (
              <Badge variant="outline" className="text-xs bg-emerald-50 text-emerald-700 border-emerald-200">
                {canViewPii ? lead.phone : maskPhone(lead.phone || null)}
              </Badge>
            ) : (
              <Badge variant="outline" className="text-xs bg-muted text-muted-foreground">
                No phone
              </Badge>
            )}
          </div>

          {/* SMS Templates */}
          <div className="flex flex-wrap gap-1">
            {SMS_TEMPLATES.map((t) => (
              <button
                key={t.id}
                onClick={() => handleSelectSmsTemplate(t)}
                disabled={!canSms}
                className="rounded-full border border-border bg-background px-2.5 py-1 text-xs hover:bg-accent disabled:opacity-50"
              >
                {t.label}
              </button>
            ))}
          </div>

          <Textarea
            disabled={!canSms}
            className="min-h-[100px] text-sm resize-none"
            placeholder={canSms ? "Type SMS message..." : "No phone on file"}
            value={smsBody}
            onChange={(e) => setSmsBody(e.target.value)}
          />

          <div className="flex items-center gap-2">
            <Button
              size="sm"
              variant="outline"
              disabled={!canSms || !smsBody.trim() || generatingSms}
              onClick={handleAiRewriteSms}
              className="gap-1"
            >
              <Sparkles className="h-3 w-3" />
              {generatingSms ? "..." : "AI Rewrite"}
            </Button>
            <Button
              size="sm"
              disabled={!canSms || sendingSms || !smsBody.trim()}
              onClick={handleSendSms}
              className="gap-1 bg-emerald-600 hover:bg-emerald-700"
            >
              <Send className="h-3 w-3" />
              {sendingSms ? "Sending..." : "Send SMS"}
            </Button>
          </div>
        </div>

        {/* Email V1 */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Mail className="h-4 w-4 text-indigo-600" />
              <span className="text-sm font-semibold">Emailer V1</span>
            </div>
            {canEmail ? (
              <Badge variant="outline" className="text-xs bg-indigo-50 text-indigo-700 border-indigo-200">
                {canViewPii ? lead.email : maskEmail(lead.email || null)}
              </Badge>
            ) : (
              <Badge variant="outline" className="text-xs bg-muted text-muted-foreground">
                No email
              </Badge>
            )}
          </div>

          {/* Email Templates */}
          <div className="flex flex-wrap gap-1">
            {EMAIL_TEMPLATES.map((t) => (
              <button
                key={t.id}
                onClick={() => handleSelectEmailTemplate(t)}
                disabled={!canEmail}
                className="rounded-full border border-border bg-background px-2.5 py-1 text-xs hover:bg-accent disabled:opacity-50"
              >
                {t.label}
              </button>
            ))}
          </div>

          <Input
            disabled={!canEmail}
            className="text-sm"
            placeholder="Subject"
            value={emailSubject}
            onChange={(e) => setEmailSubject(e.target.value)}
          />

          <Textarea
            disabled={!canEmail}
            className="min-h-[80px] text-sm resize-none"
            placeholder={canEmail ? "Write email..." : "No email on file"}
            value={emailBody}
            onChange={(e) => setEmailBody(e.target.value)}
          />

          <div className="flex items-center gap-2">
            <Button
              size="sm"
              variant="outline"
              disabled={!canEmail || !emailBody.trim() || generatingEmail}
              onClick={handleAiRewriteEmail}
              className="gap-1"
            >
              <Sparkles className="h-3 w-3" />
              {generatingEmail ? "..." : "AI Rewrite"}
            </Button>
            <Button
              size="sm"
              disabled={!canEmail || sendingEmail || !emailBody.trim() || !emailSubject.trim()}
              onClick={handleSendEmail}
              className="gap-1 bg-indigo-600 hover:bg-indigo-700"
            >
              <Send className="h-3 w-3" />
              {sendingEmail ? "Sending..." : "Send Email"}
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
