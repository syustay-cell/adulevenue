import { X, User, Building2, Phone, Mail, MapPin, DollarSign, Calendar, AlertTriangle, Shield } from 'lucide-react';
import { useUserRoles } from "@/hooks/useUserRoles";
import { canViewRawPii, maskEmail, maskPhone } from "@/lib/masking";
import type { AppRole } from "@/lib/permissions";

interface LeadQuickInfoPopupProps {
  lead: any;
  onClose: () => void;
}

export function LeadQuickInfoPopup({ lead, onClose }: LeadQuickInfoPopupProps) {
  if (!lead) return null;
  const { roles } = useUserRoles();
  const canViewPii = canViewRawPii((roles as AppRole[]) || []);

  const rawData = lead.raw_data as Record<string, any> || {};
  
  // Extract all relevant fields
  const ownerFullName = lead.owner_full_name || rawData["Owner Full Name"] || "";
  const ownerFirstName = lead.owner_first_name || rawData["Owner First Name"] || "";
  const ownerLastName = lead.owner_last_name || rawData["Owner Last Name"] || "";
  const displayOwnerName = ownerFullName || `${ownerFirstName} ${ownerLastName}`.trim() || lead.full_name || "";
  
  const businessName = lead.business_name || rawData["Business Name"] || "";
  const phone = lead.phone || rawData["Mobile"] || "";
  const email = lead.email || rawData["Email"] || "";
  
  const address = lead.address || rawData["Address"] || rawData["Address "] || "";
  const city = lead.city || rawData["City"] || "";
  const state = lead.state || rawData["State"] || "";
  const postalCode = lead.postal_code || rawData["Zip"] || "";
  
  const monthlyRevenue = lead.estimated_monthly_revenue || rawData["Monthly Revenue"] || null;
  const businessStartDate = lead.business_start_date || rawData["Business Start Date"] || "";
  const defaultsFlag = lead.defaults_flag ?? rawData["Defaults"] ?? null;
  const ssnMasked = lead.ssn_masked || (rawData["SSN"] ? `***-**-${String(rawData["SSN"]).slice(-4)}` : "");
  const ein = lead.ein || rawData["EIN"] || "";

  const InfoRow = ({ icon: Icon, label, value }: { icon: any; label: string; value: string | number | null }) => {
    if (!value && value !== 0) return null;
    return (
      <div className="flex items-center gap-2 text-xs">
        <Icon className="h-3 w-3 text-slate-500 shrink-0" />
        <span className="text-slate-400">{label}:</span>
        <span className="text-slate-200 truncate">{typeof value === 'number' ? value.toLocaleString() : value}</span>
      </div>
    );
  };

  return (
    <div className="absolute top-0 right-0 z-50 w-72 animate-in slide-in-from-right-2 fade-in duration-200">
      <div className="rounded-xl border border-slate-700 bg-slate-900/95 backdrop-blur-sm shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-700 px-3 py-2">
          <span className="text-xs font-semibold text-slate-300">Quick Info</span>
          <button
            onClick={onClose}
            className="rounded-full p-1 hover:bg-slate-700 transition-colors"
          >
            <X className="h-3.5 w-3.5 text-slate-400" />
          </button>
        </div>

        {/* Content */}
        <div className="p-3 space-y-3 max-h-80 overflow-y-auto">
          {!canViewPii ? (
            <div className="rounded-lg border border-slate-700 bg-slate-950/40 p-3 text-xs text-slate-300">
              <div className="font-semibold text-slate-100 mb-1">Access denied</div>
              Raw client identifiers are <span className="font-semibold">Owner-only</span>.
            </div>
          ) : (
            <>
          {/* Owner */}
          <div className="space-y-1">
            <div className="text-[10px] uppercase tracking-wider text-slate-500 font-semibold">Owner</div>
            <InfoRow icon={User} label="Name" value={displayOwnerName} />
            {ssnMasked && <InfoRow icon={Shield} label="SSN" value={ssnMasked} />}
          </div>

          {/* Business */}
          <div className="space-y-1">
            <div className="text-[10px] uppercase tracking-wider text-slate-500 font-semibold">Business</div>
            <InfoRow icon={Building2} label="Name" value={businessName} />
            <InfoRow icon={Calendar} label="Started" value={businessStartDate} />
            {monthlyRevenue && (
              <InfoRow icon={DollarSign} label="Revenue" value={`$${Number(monthlyRevenue).toLocaleString()}/mo`} />
            )}
            {ein && <InfoRow icon={Shield} label="EIN" value={ein} />}
            {defaultsFlag && (
              <div className="flex items-center gap-1 text-xs text-amber-400">
                <AlertTriangle className="h-3 w-3" />
                <span>Has Defaults</span>
              </div>
            )}
          </div>

          {/* Contact */}
          <div className="space-y-1">
            <div className="text-[10px] uppercase tracking-wider text-slate-500 font-semibold">Contact</div>
            <InfoRow icon={Phone} label="Phone" value={phone} />
            <InfoRow icon={Mail} label="Email" value={email} />
          </div>

          {/* Address */}
          {(address || city || state) && (
            <div className="space-y-1">
              <div className="text-[10px] uppercase tracking-wider text-slate-500 font-semibold">Address</div>
              <div className="flex items-start gap-2 text-xs">
                <MapPin className="h-3 w-3 text-slate-500 shrink-0 mt-0.5" />
                <span className="text-slate-200">
                  {[address, city, state, postalCode].filter(Boolean).join(", ")}
                </span>
              </div>
            </div>
          )}

          {/* AI Score */}
          {lead.ai_score != null && (
            <div className="pt-2 border-t border-slate-700">
              <div className="flex items-center justify-between">
                <span className="text-[10px] uppercase tracking-wider text-slate-500">AI Score</span>
                <span className="text-sm font-bold text-emerald-400">{lead.ai_score}/100</span>
              </div>
              {lead.ai_recommended_path && (
                <div className="text-[10px] text-amber-400 mt-1">
                  Recommended: {lead.ai_recommended_path.replace(/_/g, ' ')}
                </div>
              )}
            </div>
          )}
            </>
          )}
        </div>
      </div>
    </div>
  );
}
