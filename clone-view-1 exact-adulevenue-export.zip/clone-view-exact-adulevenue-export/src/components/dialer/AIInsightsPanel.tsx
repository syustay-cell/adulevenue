import { Brain, TrendingUp, AlertCircle, Target, DollarSign } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";

interface AIInsightsPanelProps {
  lead: any;
}

export const AIInsightsPanel = ({ lead }: AIInsightsPanelProps) => {
  if (!lead) return null;

  const getScript = () => {
    if (lead.ai_recommended_path === 'credit_fix_first') {
      return {
        opening: "Hi {name}, I'm calling from Wolf Fund Capital. I see you're looking for funding - I want to help you get approved. First, may I ask about your current credit situation?",
        objections: [
          { question: "Why credit?", answer: "Better credit = bigger funding & better terms. We can get you there." },
          { question: "How long?", answer: "30-90 days typically. Then we refund you immediately." }
        ]
      };
    }
    return {
      opening: "Hi {name}, I'm calling from Wolf Fund Capital. I see you're looking for business funding - we have programs that can get you approved in 24-48 hours. When's a good time to discuss?",
      objections: [
        { question: "What rates?", answer: "Depends on revenue and credit. Let me qualify you first." },
        { question: "How much?", answer: "$10K-$500K+ based on your monthly revenue." }
      ]
    };
  };

  const script = getScript();
  const aiScore = lead.ai_score || 0;
  const closingChance = Math.min(95, Math.max(10, aiScore));
  const estimatedCommission = lead.requested_amount 
    ? Math.round(lead.requested_amount * 0.08) 
    : 5000;

  return (
    <div className="space-y-4">
      {/* Wolf Brain Header */}
      <div className="flex items-center gap-2 rounded-xl bg-gradient-to-r from-primary/10 to-secondary/10 p-3 border border-primary/20">
        <Brain className="h-5 w-5 text-primary" />
        <div>
          <h3 className="text-sm font-semibold text-foreground">Wolf Brain Insights</h3>
          <p className="text-xs text-muted-foreground">AI-powered recommendation</p>
        </div>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-2 gap-3">
        <Card className="p-3">
          <div className="flex items-center gap-2 mb-1">
            <Target className="h-4 w-4 text-primary" />
            <span className="text-xs text-muted-foreground">Priority</span>
          </div>
          <div className="text-lg font-bold text-foreground">
            {lead.ai_priority || 'B'}
          </div>
        </Card>

        <Card className="p-3">
          <div className="flex items-center gap-2 mb-1">
            <TrendingUp className="h-4 w-4 text-emerald-600" />
            <span className="text-xs text-muted-foreground">Close %</span>
          </div>
          <div className="text-lg font-bold text-emerald-600">
            {closingChance}%
          </div>
        </Card>

        <Card className="p-3 col-span-2">
          <div className="flex items-center gap-2 mb-1">
            <DollarSign className="h-4 w-4 text-gold" />
            <span className="text-xs text-muted-foreground">Est. Commission</span>
          </div>
          <div className="text-xl font-bold text-gold">
            ${estimatedCommission.toLocaleString()}
          </div>
        </Card>
      </div>

      {/* Recommended Path */}
      <Card className="p-4">
        <div className="flex items-center gap-2 mb-2">
          <AlertCircle className="h-4 w-4 text-secondary" />
          <h4 className="text-sm font-semibold text-foreground">Recommended Path</h4>
        </div>
        <Badge variant={lead.ai_recommended_path === 'fast_track_funding' ? 'default' : 'secondary'}>
          {lead.ai_recommended_path === 'credit_fix_first' ? '🔧 Credit Fix First' : '💰 Funding First'}
        </Badge>
        <p className="text-xs text-muted-foreground mt-2">
          {lead.ai_recommended_path === 'credit_fix_first' 
            ? 'Low credit score detected. Start with credit repair, then refund immediately.'
            : 'Strong profile. Go straight to funding application.'}
        </p>
      </Card>

      {/* AI-Generated Script */}
      <Card className="p-4">
        <h4 className="text-sm font-semibold text-foreground mb-3">📞 Call Script</h4>
        <ScrollArea className="h-[200px]">
          <div className="space-y-3 text-xs">
            <div>
              <div className="font-semibold text-secondary mb-1">Opening:</div>
              <p className="text-muted-foreground leading-relaxed">
                {script.opening.replace('{name}', lead.full_name?.split(' ')[0] || 'there')}
              </p>
            </div>

            <div>
              <div className="font-semibold text-secondary mb-1">Objection Handling:</div>
              <div className="space-y-2">
                {script.objections.map((obj, i) => (
                  <div key={i} className="pl-3 border-l-2 border-primary/30">
                    <p className="font-medium text-foreground">{obj.question}</p>
                    <p className="text-muted-foreground">{obj.answer}</p>
                  </div>
                ))}
              </div>
            </div>

            <div className="pt-2 border-t">
              <div className="font-semibold text-secondary mb-1">Close:</div>
              <p className="text-muted-foreground leading-relaxed">
                "Perfect! I'm going to send you the application link via text right now. It takes 3 minutes to complete. Can I send it to this number?"
              </p>
            </div>
          </div>
        </ScrollArea>
      </Card>

      {/* Risk Flags */}
      {lead.ai_risk_flags && lead.ai_risk_flags.length > 0 && (
        <Card className="p-4 bg-amber-50 dark:bg-amber-950/20 border-amber-200 dark:border-amber-800">
          <div className="flex items-center gap-2 mb-2">
            <AlertCircle className="h-4 w-4 text-amber-600" />
            <h4 className="text-sm font-semibold text-amber-900 dark:text-amber-200">⚠️ Flags</h4>
          </div>
          <div className="flex flex-wrap gap-2">
            {lead.ai_risk_flags.map((flag: string) => (
              <Badge key={flag} variant="outline" className="bg-amber-100 dark:bg-amber-900 text-amber-800 dark:text-amber-200 border-amber-300">
                {flag.replace('_', ' ')}
              </Badge>
            ))}
          </div>
        </Card>
      )}
    </div>
  );
};