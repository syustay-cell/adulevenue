import { useState } from "react";
import { Shield, Users, DollarSign, Lock, Unlock } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";

interface LeadLockingModalProps {
  lead: any;
  currentUserId: string;
  onClose: () => void;
  onRequestRelease: (message: string) => Promise<void>;
  onRequestSplit: (message: string) => Promise<void>;
  onApprove: (requestId: string, type: 'release' | 'split') => Promise<void>;
}

export const LeadLockingModal = ({
  lead,
  currentUserId,
  onClose,
  onRequestRelease,
  onRequestSplit,
  onApprove,
}: LeadLockingModalProps) => {
  const [message, setMessage] = useState("");
  const [loading, setLoading] = useState(false);
  
  const isOwner = lead.owner_id === currentUserId;
  const hasRequest = lead.pending_share_request;
  const lockExpires = lead.lock_expires_at 
    ? new Date(lead.lock_expires_at).toLocaleString()
    : null;

  const handleRequestRelease = async () => {
    setLoading(true);
    try {
      await onRequestRelease(message);
      onClose();
    } finally {
      setLoading(false);
    }
  };

  const handleRequestSplit = async () => {
    setLoading(true);
    try {
      await onRequestSplit(message);
      onClose();
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Shield className="h-5 w-5 text-primary" />
            Lead Ownership
          </DialogTitle>
          <DialogDescription>
            {isOwner 
              ? "You own this lead exclusively for 7 days"
              : "This lead is currently locked by another agent"}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          {/* Lead Info */}
          <div className="rounded-lg border bg-muted/30 p-4">
            <div className="flex items-center justify-between mb-2">
              <div>
                <h4 className="font-semibold text-foreground">{lead.full_name}</h4>
                <p className="text-sm text-muted-foreground">{lead.business_name}</p>
              </div>
              {lead.lock_expires_at && (
                <Badge variant="secondary" className="gap-1">
                  <Lock className="h-3 w-3" />
                  Locked
                </Badge>
              )}
            </div>
            {lockExpires && (
              <p className="text-xs text-muted-foreground">
                Lock expires: {lockExpires}
              </p>
            )}
          </div>

          {/* Owner View: Incoming Request */}
          {isOwner && hasRequest && (
            <div className="space-y-3">
              <div className="rounded-lg border border-amber-200 bg-amber-50 dark:bg-amber-950/20 p-4">
                <p className="text-sm font-medium text-amber-900 dark:text-amber-200 mb-1">
                  Incoming Request
                </p>
                <p className="text-sm text-amber-800 dark:text-amber-300">
                  Agent {hasRequest.from_worker_email} is requesting:
                </p>
                <Badge variant="outline" className="mt-2">
                  {hasRequest.type === 'release' ? (
                    <>
                      <Unlock className="h-3 w-3 mr-1" />
                      Full Release
                    </>
                  ) : (
                    <>
                      <Users className="h-3 w-3 mr-1" />
                      50/50 Split
                    </>
                  )}
                </Badge>
                {hasRequest.message && (
                  <p className="text-xs text-muted-foreground mt-2 italic">
                    "{hasRequest.message}"
                  </p>
                )}
              </div>

              <div className="flex gap-2">
                <Button
                  onClick={() => onApprove(hasRequest.id, hasRequest.type)}
                  className="flex-1 bg-emerald-600 hover:bg-emerald-700"
                  disabled={loading}
                >
                  ✓ Approve Request
                </Button>
                <Button
                  onClick={onClose}
                  variant="outline"
                  className="flex-1"
                  disabled={loading}
                >
                  Decline
                </Button>
              </div>
            </div>
          )}

          {/* Non-Owner View: Send Request */}
          {!isOwner && !hasRequest && (
            <div className="space-y-4">
              <div>
                <Label htmlFor="request-message">Message to Owner (Optional)</Label>
                <Textarea
                  id="request-message"
                  placeholder="Explain why you'd like this lead..."
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  rows={3}
                  className="mt-2"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <Button
                  onClick={handleRequestRelease}
                  variant="outline"
                  className="h-20 flex-col gap-2"
                  disabled={loading}
                >
                  <Unlock className="h-5 w-5" />
                  <div className="text-xs leading-tight">
                    Request<br />Release
                  </div>
                </Button>
                <Button
                  onClick={handleRequestSplit}
                  className="h-20 flex-col gap-2 bg-amber-600 hover:bg-amber-700"
                  disabled={loading}
                >
                  <DollarSign className="h-5 w-5" />
                  <div className="text-xs leading-tight">
                    Propose<br />50/50 Split
                  </div>
                </Button>
              </div>

              <p className="text-xs text-muted-foreground text-center">
                The owner will receive your request and can approve or decline
              </p>
            </div>
          )}

          {/* Pending Request */}
          {!isOwner && hasRequest && (
            <div className="rounded-lg border border-blue-200 bg-blue-50 dark:bg-blue-950/20 p-4">
              <p className="text-sm font-medium text-blue-900 dark:text-blue-200 mb-1">
                ⏳ Request Pending
              </p>
              <p className="text-sm text-blue-800 dark:text-blue-300">
                Your {hasRequest.type === 'release' ? 'release' : '50/50 split'} request is waiting for owner approval
              </p>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
};