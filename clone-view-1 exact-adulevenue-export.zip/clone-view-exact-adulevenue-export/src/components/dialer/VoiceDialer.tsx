import React, { useState, useEffect } from 'react';
import { Phone, PhoneOff, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import { RealtimeVoiceChat } from '@/utils/RealtimeVoice';

interface VoiceDialerProps {
  leadId: string;
  leadName: string;
  leadPhone: string;
  onCallComplete: (outcome: string, notes?: string) => void;
}

export function VoiceDialer({ leadId, leadName, leadPhone, onCallComplete }: VoiceDialerProps) {
  const { toast } = useToast();
  const [isConnecting, setIsConnecting] = useState(false);
  const [isConnected, setIsConnected] = useState(false);
  const [voiceChat, setVoiceChat] = useState<RealtimeVoiceChat | null>(null);
  const [transcript, setTranscript] = useState<string[]>([]);

  const handleMessage = (event: any) => {
    console.log('Voice event:', event.type);
    
    if (event.type === 'response.audio_transcript.delta') {
      setTranscript(prev => [...prev, event.delta]);
    } else if (event.type === 'response.audio_transcript.done') {
      console.log('AI response complete');
    } else if (event.type === 'conversation.item.created') {
      console.log('Conversation item created:', event.item);
    }
  };

  const handleConnectionChange = (connected: boolean) => {
    setIsConnected(connected);
    setIsConnecting(false);
  };

  const startCall = async () => {
    try {
      setIsConnecting(true);
      console.log('Starting voice call for lead:', leadId);
      
      const chat = new RealtimeVoiceChat(handleMessage, handleConnectionChange);
      await chat.init();
      
      setVoiceChat(chat);
      
      toast({
        title: "Call Connected",
        description: `Now speaking with ${leadName}`,
      });
    } catch (error) {
      console.error('Failed to start call:', error);
      setIsConnecting(false);
      toast({
        title: "Call Failed",
        description: error instanceof Error ? error.message : 'Failed to connect',
        variant: "destructive",
      });
    }
  };

  const endCall = () => {
    if (voiceChat) {
      voiceChat.disconnect();
      setVoiceChat(null);
      setTranscript([]);
      toast({
        title: "Call Ended",
        description: "Voice session disconnected",
      });
    }
  };

  useEffect(() => {
    return () => {
      if (voiceChat) {
        voiceChat.disconnect();
      }
    };
  }, [voiceChat]);

  return (
    <div className="flex flex-col gap-4">
      <div className="flex items-center justify-between p-4 border rounded-lg bg-card">
        <div className="flex-1">
          <div className="font-semibold">{leadName}</div>
          <div className="text-sm text-muted-foreground">{leadPhone}</div>
          {isConnected && (
            <div className="text-xs text-green-600 font-medium mt-1">
              🔴 Live Call
            </div>
          )}
        </div>
        
        <div className="flex gap-2">
          {!isConnected ? (
            <Button
              onClick={startCall}
              disabled={isConnecting}
              className="bg-green-600 hover:bg-green-700"
            >
              {isConnecting ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Connecting...
                </>
              ) : (
                <>
                  <Phone className="h-4 w-4 mr-2" />
                  Call Now
                </>
              )}
            </Button>
          ) : (
            <Button
              onClick={endCall}
              variant="destructive"
            >
              <PhoneOff className="h-4 w-4 mr-2" />
              End Call
            </Button>
          )}
        </div>
      </div>

      {transcript.length > 0 && (
        <div className="p-4 border rounded-lg bg-muted/50">
          <div className="text-xs font-semibold text-muted-foreground mb-2">
            Call Transcript
          </div>
          <div className="space-y-1 text-sm">
            {transcript.map((line, i) => (
              <div key={i}>{line}</div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
