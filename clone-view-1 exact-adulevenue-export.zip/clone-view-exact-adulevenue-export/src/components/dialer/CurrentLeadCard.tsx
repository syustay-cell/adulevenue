import { useState } from 'react';
import { Phone, Mail, PhoneOff, Eye } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { LeadOwnershipBadge } from './LeadOwnershipBadge';
import { LeadReleaseDialog } from './LeadReleaseDialog';
import { LeadQuickInfoPopup } from './LeadQuickInfoPopup';
import type { Lead } from '@/hooks/useDialerSession';
import { useUserRoles } from "@/hooks/useUserRoles";
import { canViewRawPii, maskEmail, maskPhone } from "@/lib/masking";
import type { AppRole } from "@/lib/permissions";

interface CurrentLeadCardProps {
  lead: Lead;
  workerId: string;
  onMarkOutcome: (
    outcome: 'no_answer' | 'left_voicemail' | 'connected',
    nextAction: 'next' | 'schedule_callback' | 'convert_to_application' | 'not_interested' | 'dead',
    callbackAt?: string
  ) => Promise<void>;
  sessionActive: boolean;
}

export function CurrentLeadCard({ lead, workerId, onMarkOutcome, sessionActive }: CurrentLeadCardProps) {
  const navigate = useNavigate();
  const [releaseDialogOpen, setReleaseDialogOpen] = useState(false);
  const [isCalling, setIsCalling] = useState(false);
  const [showQuickInfo, setShowQuickInfo] = useState(false);
  const { roles } = useUserRoles();
  const canViewPii = canViewRawPii(((roles as AppRole[]) || []) as AppRole[]);

  const isOwnedByOther = lead.current_owner_id && lead.current_owner_id !== workerId;
  const telHref = (phone: string | null) => (phone ? `tel:${phone.replace(/\D/g, '')}` : '#');

  const makeCall = () => {
    if (!lead.phone) return;
    if (!canViewPii) return;
    window.location.href = `tel:${lead.phone.replace(/[^0-9+]/g, '')}`;
    setIsCalling(true);
  };

  const handleConvert = async () => {
    await onMarkOutcome('connected', 'convert_to_application');
    navigate(`/fast-track?lead_id=${lead.id}`);
  };

  return (
    <div className="relative space-y-4 rounded-2xl border border-slate-800 bg-slate-950/60 p-6">
      {/* Quick Info Popup */}
      {showQuickInfo && (
        <LeadQuickInfoPopup lead={lead} onClose={() => setShowQuickInfo(false)} />
      )}

      <div className="flex items-start justify-between gap-4">
        <div>
          <div className="text-sm uppercase tracking-wider text-slate-500">Current Lead</div>
          <h2 className="mt-1 text-2xl font-bold text-slate-50">
            {lead.full_name || 'Unknown'}
          </h2>
          {lead.business_name && (
            <p className="mt-0.5 text-sm text-slate-400">{lead.business_name}</p>
          )}
        </div>

        <div className="flex items-center gap-2">
          {/* View Info Button */}
          <button
            onClick={() => setShowQuickInfo(!showQuickInfo)}
            className={`inline-flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-medium transition ${
              showQuickInfo 
                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30' 
                : 'bg-slate-800 text-slate-300 hover:bg-slate-700 border border-slate-700'
            }`}
          >
            <Eye className="h-3.5 w-3.5" />
            {showQuickInfo ? 'Hide' : 'View'}
          </button>

          {lead.ai_score != null && (
            <div className="rounded-lg bg-emerald-500/10 px-3 py-1.5">
              <div className="text-xs text-slate-400">AI Score</div>
              <div className="text-lg font-bold text-emerald-300">{lead.ai_score}/100</div>
            </div>
          )}
        </div>
      </div>

      <div className="flex flex-wrap gap-2">
        <LeadOwnershipBadge
          currentOwnerId={lead.current_owner_id}
          currentOwnerEmail={lead.current_owner_email}
          lockExpiresAt={lead.lock_expires_at}
          lockReason={lead.lock_reason}
          currentUserId={workerId}
        />

        {isOwnedByOther && (
          <button
            onClick={() => setReleaseDialogOpen(true)}
            className="inline-flex items-center gap-1.5 rounded-full bg-amber-500/10 px-3 py-1.5 text-xs font-medium text-amber-300 hover:bg-amber-500/20"
          >
            Request Access / 50-50
          </button>
        )}
      </div>

      {/* Contact Info */}
      <div className="grid gap-2 sm:grid-cols-2">
        {lead.phone && (
          canViewPii ? (
            <a
              href={telHref(lead.phone)}
              className="flex items-center gap-2 rounded-lg bg-slate-900/80 px-3 py-2 text-sm text-slate-200 hover:bg-slate-900"
            >
              <Phone className="h-4 w-4 text-emerald-400" />
              {lead.phone}
            </a>
          ) : (
            <div className="flex items-center gap-2 rounded-lg bg-slate-900/80 px-3 py-2 text-sm text-slate-200">
              <Phone className="h-4 w-4 text-emerald-400" />
              {maskPhone(lead.phone)}
            </div>
          )
        )}
        {lead.email && (
          canViewPii ? (
            <a
              href={`mailto:${lead.email}`}
              className="flex items-center gap-2 rounded-lg bg-slate-900/80 px-3 py-2 text-sm text-slate-200 hover:bg-slate-900"
            >
              <Mail className="h-4 w-4 text-blue-400" />
              {lead.email}
            </a>
          ) : (
            <div className="flex items-center gap-2 rounded-lg bg-slate-900/80 px-3 py-2 text-sm text-slate-200">
              <Mail className="h-4 w-4 text-blue-400" />
              {maskEmail(lead.email)}
            </div>
          )
        )}
      </div>

      {/* MODERN CALL CONTROLS */}
      <div className="space-y-3 rounded-xl border border-slate-700 bg-slate-900/40 p-4">
        <div className="flex items-center justify-between">
          <div className="text-sm font-medium text-slate-400">Dialer Status:</div>

          {isCalling ? (
            <button
              onClick={() => setIsCalling(false)}
              className="inline-flex items-center gap-2 rounded-full bg-red-600 px-4 py-1.5 text-xs font-semibold text-white shadow-lg transition hover:bg-red-700"
            >
              <PhoneOff className="h-3.5 w-3.5" />
              Stop Calling
            </button>
          ) : (
            <button
              onClick={makeCall}
              disabled={!sessionActive || !canViewPii}
              className="inline-flex items-center gap-2 rounded-full bg-emerald-600 px-4 py-1.5 text-xs font-semibold text-white shadow-lg transition hover:bg-emerald-700 disabled:opacity-50"
            >
              <Phone className="h-3.5 w-3.5" />
              Start Calling
            </button>
          )}
        </div>

        {/* CONNECTED / NOT CONNECTED BUTTONS (only show when calling) */}
        {isCalling && (
          <div className="flex flex-wrap gap-2 border-t border-slate-700 pt-3">
            <button
              onClick={() => {
                onMarkOutcome('no_answer', 'next');
                setIsCalling(false);
              }}
              className="rounded-full border border-slate-600 bg-slate-800/60 px-3 py-1 text-xs font-medium text-slate-200 transition hover:bg-slate-800"
            >
              No Answer → Next
            </button>

            <button
              onClick={() => {
                onMarkOutcome('left_voicemail', 'next');
                setIsCalling(false);
              }}
              className="rounded-full border border-slate-600 bg-slate-800/60 px-3 py-1 text-xs font-medium text-slate-200 transition hover:bg-slate-800"
            >
              Left Voicemail → Next
            </button>

            <button
              onClick={() => {
                onMarkOutcome('connected', 'not_interested');
                setIsCalling(false);
              }}
              className="rounded-full border border-slate-600 bg-slate-800/60 px-3 py-1 text-xs font-medium text-slate-200 transition hover:bg-slate-800"
            >
              Not Interested
            </button>

            <button
              onClick={() => {
                handleConvert();
                setIsCalling(false);
              }}
              className="rounded-full border border-emerald-600 bg-emerald-600/20 px-3 py-1 text-xs font-medium text-emerald-200 transition hover:bg-emerald-600/30"
            >
              Send Application
            </button>
          </div>
        )}
      </div>

      {/* Release Dialog */}
      {isOwnedByOther && (
        <LeadReleaseDialog
          open={releaseDialogOpen}
          onOpenChange={setReleaseDialogOpen}
          leadId={lead.id}
          currentOwnerEmail={lead.current_owner_email || 'another worker'}
          workerId={workerId}
        />
      )}
    </div>
  );
}
