import { Play, Square } from 'lucide-react';

interface DialerSessionControlsProps {
  sessionActive: boolean;
  onStart: () => void;
  onStop: () => void;
  disabled?: boolean;
}

export function DialerSessionControls({
  sessionActive,
  onStart,
  onStop,
  disabled = false,
}: DialerSessionControlsProps) {
  return (
    <button
      onClick={sessionActive ? onStop : onStart}
      disabled={disabled}
      className={[
        'inline-flex items-center gap-2 rounded-full px-6 py-2.5 text-sm font-semibold transition-all',
        sessionActive
          ? 'bg-red-500 text-white hover:bg-red-600 disabled:bg-red-500/50'
          : 'bg-emerald-500 text-emerald-950 hover:bg-emerald-400 disabled:bg-emerald-500/50',
      ].join(' ')}
    >
      {sessionActive ? (
        <>
          <Square className="h-4 w-4" />
          Stop Calling
        </>
      ) : (
        <>
          <Play className="h-4 w-4" />
          Start Calling
        </>
      )}
    </button>
  );
}
