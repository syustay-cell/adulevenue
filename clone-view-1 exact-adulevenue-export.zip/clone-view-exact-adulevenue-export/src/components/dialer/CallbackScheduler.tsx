import { useState } from "react";
import { Calendar, Clock } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Calendar as CalendarComponent } from "@/components/ui/calendar";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

interface CallbackSchedulerProps {
  lead: any;
  isOpen: boolean;
  onClose: () => void;
  onScheduled: () => void;
}

export const CallbackScheduler = ({ lead, isOpen, onClose, onScheduled }: CallbackSchedulerProps) => {
  const [date, setDate] = useState<Date | undefined>(new Date());
  const [time, setTime] = useState("14:00");
  const [notes, setNotes] = useState("");
  const [priority, setPriority] = useState("medium");
  const [saving, setSaving] = useState(false);
  const { toast } = useToast();

  const handleSchedule = async () => {
    if (!date) return;

    setSaving(true);
    try {
      const [hours, minutes] = time.split(':');
      const scheduledDateTime = new Date(date);
      scheduledDateTime.setHours(parseInt(hours), parseInt(minutes), 0);

      // Update lead with callback time
      const { error } = await supabase
        .from('leads')
        .update({ 
          follow_up_at: scheduledDateTime.toISOString(),
          status: 'callback_scheduled',
          notes: notes || lead.notes
        })
        .eq('id', lead.id);

      if (error) throw error;

      toast({
        title: "Callback Scheduled",
        description: `Set for ${scheduledDateTime.toLocaleString()}`
      });

      onScheduled();
      onClose();
    } catch (error) {
      console.error('Error scheduling callback:', error);
      toast({
        title: "Failed to schedule",
        description: "Please try again",
        variant: "destructive"
      });
    } finally {
      setSaving(false);
    }
  };

  const timeSlots = [
    "09:00", "09:30", "10:00", "10:30", "11:00", "11:30",
    "12:00", "12:30", "13:00", "13:30", "14:00", "14:30",
    "15:00", "15:30", "16:00", "16:30", "17:00", "17:30",
    "18:00", "18:30", "19:00"
  ];

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Calendar className="h-5 w-5 text-primary" />
            Schedule Callback
          </DialogTitle>
          <DialogDescription>
            Set a reminder to call {lead.full_name?.split(' ')[0] || 'this lead'} back
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          {/* Date Picker */}
          <div>
            <Label className="flex items-center gap-2 mb-2">
              <Calendar className="h-4 w-4" />
              Select Date
            </Label>
            <div className="border rounded-lg p-3 flex justify-center">
              <CalendarComponent
                mode="single"
                selected={date}
                onSelect={setDate}
                disabled={(date) => date < new Date(new Date().setHours(0, 0, 0, 0))}
                className="rounded-md"
              />
            </div>
          </div>

          {/* Time Picker */}
          <div>
            <Label className="flex items-center gap-2 mb-2">
              <Clock className="h-4 w-4" />
              Select Time
            </Label>
            <Select value={time} onValueChange={setTime}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="max-h-[200px]">
                {timeSlots.map(slot => (
                  <SelectItem key={slot} value={slot}>
                    {slot}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Priority */}
          <div>
            <Label className="mb-2">Priority Level</Label>
            <Select value={priority} onValueChange={setPriority}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="low">Low Priority</SelectItem>
                <SelectItem value="medium">Medium Priority</SelectItem>
                <SelectItem value="high">High Priority</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Notes */}
          <div>
            <Label htmlFor="callback-notes" className="mb-2">
              Reminder Notes (Optional)
            </Label>
            <Textarea
              id="callback-notes"
              placeholder="Why are you calling back? Any special notes..."
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              rows={3}
            />
          </div>

          {/* Preview */}
          {date && (
            <div className="rounded-lg bg-muted/50 p-3 text-sm">
              <div className="font-medium text-foreground mb-1">Callback scheduled for:</div>
              <div className="text-muted-foreground">
                {new Date(date.setHours(parseInt(time.split(':')[0]), parseInt(time.split(':')[1]))).toLocaleString('en-US', {
                  weekday: 'long',
                  year: 'numeric',
                  month: 'long',
                  day: 'numeric',
                  hour: 'numeric',
                  minute: '2-digit',
                  hour12: true
                })}
              </div>
            </div>
          )}

          {/* Actions */}
          <div className="flex gap-2 pt-2">
            <Button
              onClick={handleSchedule}
              disabled={!date || saving}
              className="flex-1 bg-emerald-600 hover:bg-emerald-700"
            >
              {saving ? 'Scheduling...' : 'Schedule Callback'}
            </Button>
            <Button
              variant="outline"
              onClick={onClose}
              disabled={saving}
            >
              Cancel
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};