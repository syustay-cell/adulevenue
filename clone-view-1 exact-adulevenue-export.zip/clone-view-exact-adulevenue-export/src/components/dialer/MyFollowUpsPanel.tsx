import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useUserRoles } from "@/hooks/useUserRoles";
import { canViewRawPii, maskEmail, maskPhone } from "@/lib/masking";
import type { AppRole } from "@/lib/permissions";
import { 
  CheckCircle, 
  Clock, 
  MessageSquare, 
  Mail, 
  Phone,
  AlertTriangle,
  ExternalLink,
  RefreshCw
} from "lucide-react";
import { toast } from "sonner";
import { formatDistanceToNow, parseISO } from "date-fns";

interface TaskMeta {
  channel?: string;
  to?: string;
  template_name?: string;
  reason?: string;
}

interface LeadInfo {
  id: string;
  business_name: string | null;
  full_name: string | null;
  phone: string | null;
  email: string | null;
}

interface FollowUpTask {
  id: string;
  message_id: string | null;
  lead_id: string | null;
  case_id: string | null;
  status: string;
  task_type?: string;
  title?: string;
  due_at: string;
  created_at: string;
  meta: TaskMeta | null;
  lead: LeadInfo | null;
}

interface MyFollowUpsPanelProps {
  workerId?: string;
  onOpenClient?: (params: {
    leadId?: string | null;
    clientId?: string | null;
    caseId?: string | null;
  }) => void;
  limit?: number;
}

export function MyFollowUpsPanel({ workerId, onOpenClient, limit = 50 }: MyFollowUpsPanelProps) {
  const [tasks, setTasks] = useState<FollowUpTask[]>([]);
  const [loading, setLoading] = useState(true);
  const [completingId, setCompletingId] = useState<string | null>(null);
  const { roles } = useUserRoles();
  const canViewPii = canViewRawPii(((roles as AppRole[]) || []) as AppRole[]);

  const fetchTasks = async () => {
    setLoading(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      const targetWorkerId = workerId || user?.id;
      if (!targetWorkerId) return;

      let query = supabase
        .from("outreach_tasks")
        .select(`
          *,
          lead:leads(id, business_name, full_name, phone, email)
        `)
        .eq("status", "pending")
        .order("due_at", { ascending: true })
        .limit(limit);

      if (targetWorkerId) {
        query = query.eq("assigned_to_user_id", targetWorkerId);
      }

      const { data, error } = await query;

      if (error) throw error;
      
      const transformedTasks: FollowUpTask[] = (data || []).map((row: any) => ({
        id: row.id,
        message_id: row.message_id,
        lead_id: row.lead_id,
        case_id: row.case_id,
        status: row.status,
        task_type: row.task_type,
        title: row.title,
        due_at: row.due_at,
        created_at: row.created_at,
        meta: row.meta as TaskMeta | null,
        lead: row.lead as LeadInfo | null,
      }));
      
      setTasks(transformedTasks);
    } catch (error) {
      console.error("Error fetching follow-up tasks:", error);
      toast.error("Failed to load follow-up tasks");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchTasks();
    const interval = setInterval(fetchTasks, 60_000);
    return () => clearInterval(interval);
  }, [workerId]);

  const markComplete = async (taskId: string, leadId: string | null) => {
    setCompletingId(taskId);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      
      const { error } = await supabase
        .from("outreach_tasks")
        .update({ 
          status: "done", 
          completed_at: new Date().toISOString() 
        })
        .eq("id", taskId);

      if (error) throw error;

      if (leadId && user) {
        await supabase.from("client_activity").insert({
          lead_id: leadId,
          worker_id: user.id,
          type: "task_completed",
          channel: "system",
          direction: "internal",
          body: "Follow-up task marked as complete",
          meta: { task_id: taskId }
        });
      }

      toast.success("Task marked complete");
      setTasks(prev => prev.filter(t => t.id !== taskId));
    } catch (error) {
      console.error("Error completing task:", error);
      toast.error("Failed to complete task");
    } finally {
      setCompletingId(null);
    }
  };

  const isOverdue = (dueAt: string | null) => {
    if (!dueAt) return false;
    return parseISO(dueAt).getTime() < Date.now();
  };

  const formatDue = (dueAt: string | null) => {
    if (!dueAt) return "No due date";
    return formatDistanceToNow(parseISO(dueAt), { addSuffix: true });
  };

  const getChannelIcon = (channel?: string) => {
    switch (channel) {
      case "sms": return <MessageSquare className="h-3.5 w-3.5" />;
      case "email": return <Mail className="h-3.5 w-3.5" />;
      default: return <Phone className="h-3.5 w-3.5" />;
    }
  };

  const getChannelBadge = (channel?: string) => {
    switch (channel) {
      case "sms": 
        return <Badge variant="secondary" className="text-[10px] bg-emerald-50 text-emerald-700 border-emerald-200">SMS</Badge>;
      case "email": 
        return <Badge variant="outline" className="text-[10px] bg-sky-50 text-sky-700 border-sky-200">Email</Badge>;
      default: 
        return <Badge className="text-[10px]">Unknown</Badge>;
    }
  };

  const getReasonLabel = (reason?: string) => {
    if (!reason) return "Follow-up needed";
    if (reason === "no_reply_after_due_time") return "No reply after outreach";
    return reason.replace(/_/g, " ");
  };

  if (loading && tasks.length === 0) {
    return (
      <Card className="border-border/50">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-medium flex items-center gap-2">
            <Clock className="h-4 w-4 text-muted-foreground" />
            My Follow-Ups
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            {Array.from({ length: 3 }).map((_, i) => (
              <div key={i} className="h-12 animate-pulse rounded-lg bg-muted" />
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="border-border/50">
      <CardHeader className="pb-3">
        <CardTitle className="text-sm font-medium flex items-center justify-between">
          <span className="flex items-center gap-2">
            <Clock className="h-4 w-4 text-muted-foreground" />
            My Follow-Ups
          </span>
          <div className="flex items-center gap-2">
            {tasks.length > 0 && (
              <Badge variant="destructive" className="text-xs">
                {tasks.length} pending
              </Badge>
            )}
            <Button
              variant="ghost"
              size="sm"
              className="h-7 w-7 p-0"
              onClick={fetchTasks}
              disabled={loading}
            >
              <RefreshCw className={`h-3.5 w-3.5 ${loading ? "animate-spin" : ""}`} />
            </Button>
          </div>
        </CardTitle>
        <p className="text-[11px] text-muted-foreground">
          Auto-created tasks when clients don't reply to SMS/Email.
        </p>
      </CardHeader>
      <CardContent className="p-0">
        {tasks.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-8 px-4 text-center">
            <CheckCircle className="h-8 w-8 text-green-500 mb-2" />
            <p className="text-sm text-muted-foreground">All caught up!</p>
            <p className="text-xs text-muted-foreground/70">No pending follow-ups</p>
          </div>
        ) : (
          <ScrollArea className="h-[300px]">
            <div className="divide-y divide-border/50">
              {tasks.map((task) => {
                const overdue = isOverdue(task.due_at);
                const channel = task.meta?.channel;
                const to = task.meta?.to;
                const templateName = task.meta?.template_name;
                const reason = task.meta?.reason;
                const displayTo =
                  canViewPii
                    ? (to || "N/A")
                    : (channel === "email" ? maskEmail(to || null) : maskPhone(to || null));

                return (
                  <div key={task.id} className="p-3 hover:bg-muted/30 transition-colors">
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          {overdue ? (
                            <AlertTriangle className="h-3.5 w-3.5 text-amber-500" />
                          ) : (
                            <CheckCircle className="h-3.5 w-3.5 text-emerald-500" />
                          )}
                          <span className="font-medium text-sm truncate">
                            {task.lead?.business_name || task.lead?.full_name || "Unknown Client"}
                          </span>
                          {getChannelBadge(channel)}
                        </div>
                        
                        <div className="text-xs text-muted-foreground space-y-0.5">
                          <div className="flex items-center gap-1">
                            {getChannelIcon(channel)}
                            <span className="truncate">{displayTo}</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <span className={overdue ? "text-amber-600 font-medium" : ""}>
                              Due {formatDue(task.due_at)}
                            </span>
                          </div>
                          {templateName && (
                            <div className="text-muted-foreground/70 truncate">
                              Template: {templateName.replace(/_/g, " ")}
                            </div>
                          )}
                          <div className="text-muted-foreground/70">
                            {getReasonLabel(reason)}
                          </div>
                        </div>
                      </div>
                      
                      <div className="flex flex-col gap-1">
                        {onOpenClient && task.lead_id && (
                          <Button
                            size="sm"
                            variant="default"
                            className="h-7 text-xs"
                            onClick={() => onOpenClient({
                              leadId: task.lead_id,
                              clientId: null,
                              caseId: task.case_id,
                            })}
                          >
                            <ExternalLink className="h-3 w-3 mr-1" />
                            Open
                          </Button>
                        )}
                        <Button
                          size="sm"
                          variant="outline"
                          className="h-7 text-xs"
                          disabled={completingId === task.id}
                          onClick={() => markComplete(task.id, task.lead_id)}
                        >
                          <CheckCircle className="h-3 w-3 mr-1" />
                          {completingId === task.id ? "..." : "Done"}
                        </Button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </ScrollArea>
        )}
      </CardContent>
    </Card>
  );
}