import { useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';

interface LeadReleaseDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  leadId: string;
  currentOwnerEmail: string;
  workerId: string;
  onSuccess?: () => void;
}

export function LeadReleaseDialog({
  open,
  onOpenChange,
  leadId,
  currentOwnerEmail,
  workerId,
  onSuccess,
}: LeadReleaseDialogProps) {
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);

  const handleRequest = async () => {
    setLoading(true);
    try {
      const { error } = await supabase.rpc('request_lead_release', {
        p_lead_id: leadId,
        p_from_worker_id: workerId,
      });

      if (error) throw error;

      toast({
        title: 'Request sent',
        description: `${currentOwnerEmail} will be notified of your request`,
      });

      onOpenChange(false);
      onSuccess?.();
    } catch (e: any) {
      console.error('Failed to request release:', e);
      toast({
        variant: 'destructive',
        title: 'Failed to send request',
        description: e.message || 'Please try again',
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Request Lead Access</DialogTitle>
          <DialogDescription className="space-y-3 pt-2">
            <p>
              This client is currently owned by{' '}
              <strong>{currentOwnerEmail}</strong>.
            </p>
            <p>
              You can request access to this lead. The current owner can:
            </p>
            <ul className="list-inside list-disc space-y-1 pl-2 text-sm">
              <li>
                <strong>Release</strong> – Transfer full ownership to you
              </li>
              <li>
                <strong>50/50 Split</strong> – Share commission with you
              </li>
              <li>
                <strong>Deny</strong> – Keep exclusive ownership
              </li>
            </ul>
          </DialogDescription>
        </DialogHeader>
        <DialogFooter className="flex-col gap-2 sm:flex-row sm:justify-end">
          <Button
            variant="outline"
            onClick={() => onOpenChange(false)}
            disabled={loading}
          >
            Cancel
          </Button>
          <Button onClick={handleRequest} disabled={loading}>
            {loading ? 'Sending...' : 'Send Request'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
