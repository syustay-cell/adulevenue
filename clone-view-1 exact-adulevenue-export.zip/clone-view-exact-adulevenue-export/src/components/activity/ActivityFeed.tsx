import { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Button } from '@/components/ui/button';
import { RefreshCw, Bot, User, Settings, AlertTriangle, Info, AlertCircle, Zap } from 'lucide-react';
import { getRecentActivity, type ActivityLogEntry, type ActivitySeverity } from '@/lib/activityLogClient';
import { ActivityNarrator } from './ActivityNarrator';

const severityConfig: Record<ActivitySeverity, { color: string; icon: typeof Info }> = {
  info: { color: 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200', icon: Info },
  low: { color: 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200', icon: Zap },
  medium: { color: 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200', icon: AlertTriangle },
  high: { color: 'bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-200', icon: AlertCircle },
  critical: { color: 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200', icon: AlertCircle },
};

const actorIcons: Record<string, typeof Bot> = {
  AI_AUTOPILOT: Bot,
  USER: User,
  OWNER: User,
  SYSTEM: Settings,
};

function ActivityCard({ entry }: { entry: ActivityLogEntry }) {
  const severity = (entry.severity as ActivitySeverity) || 'info';
  const config = severityConfig[severity] || severityConfig.info;
  const SeverityIcon = config.icon;
  const ActorIcon = actorIcons[entry.actor] || Bot;

  const timeAgo = getTimeAgo(new Date(entry.created_at));

  return (
    <div className="border-b border-border/50 pb-3 mb-3 last:border-0 last:pb-0 last:mb-0">
      <div className="flex items-start gap-3">
        <div className={`p-2 rounded-lg ${config.color}`}>
          <SeverityIcon className="h-4 w-4" />
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="font-medium text-sm">{entry.title}</span>
            <Badge variant="outline" className="text-xs">
              {entry.module}
            </Badge>
            {entry.auto_executed && (
              <Badge variant="default" className="text-xs bg-green-600">
                Executed
              </Badge>
            )}
            {!entry.auto_executed && (
              <Badge variant="secondary" className="text-xs">
                Pending
              </Badge>
            )}
          </div>
          <p className="text-sm text-muted-foreground mt-1">{entry.summary}</p>
          {entry.proposed_action && (
            <p className="text-xs text-primary mt-1">
              → {entry.proposed_action}
            </p>
          )}
          <div className="flex items-center gap-2 mt-2 text-xs text-muted-foreground">
            <ActorIcon className="h-3 w-3" />
            <span>{entry.actor.replace('_', ' ')}</span>
            <span>•</span>
            <span>{entry.mode}</span>
            <span>•</span>
            <span>{timeAgo}</span>
          </div>
        </div>
      </div>
    </div>
  );
}

function getTimeAgo(date: Date): string {
  const seconds = Math.floor((Date.now() - date.getTime()) / 1000);

  if (seconds < 60) return 'just now';
  if (seconds < 3600) return `${Math.floor(seconds / 60)}m ago`;
  if (seconds < 86400) return `${Math.floor(seconds / 3600)}h ago`;
  return `${Math.floor(seconds / 86400)}d ago`;
}

export function ActivityFeed() {
  const [entries, setEntries] = useState<ActivityLogEntry[]>([]);
  const [loading, setLoading] = useState(true);

  async function loadActivity() {
    setLoading(true);
    const data = await getRecentActivity(30);
    setEntries(data);
    setLoading(false);
  }

  useEffect(() => {
    loadActivity();
    // Auto-refresh every 30 seconds
    const interval = setInterval(loadActivity, 30000);
    return () => clearInterval(interval);
  }, []);

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg flex items-center gap-2">
            <Bot className="h-5 w-5 text-primary" />
            Live Activity Command Center
          </CardTitle>
          <Button
            variant="ghost"
            size="sm"
            onClick={loadActivity}
            disabled={loading}
          >
            <RefreshCw className={`h-4 w-4 ${loading ? 'animate-spin' : ''}`} />
          </Button>
        </div>
        <ActivityNarrator />
      </CardHeader>
      <CardContent>
        <ScrollArea className="h-[400px] pr-4">
          {entries.length === 0 && !loading && (
            <div className="text-center py-8 text-muted-foreground">
              <Bot className="h-8 w-8 mx-auto mb-2 opacity-50" />
              <p>No activity yet. The AI will log actions here.</p>
            </div>
          )}
          {entries.map((entry) => (
            <ActivityCard key={entry.id} entry={entry} />
          ))}
        </ScrollArea>
      </CardContent>
    </Card>
  );
}
