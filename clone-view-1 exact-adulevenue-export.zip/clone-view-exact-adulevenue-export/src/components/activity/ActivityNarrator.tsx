import { useState, useEffect, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { Play, Square, Volume2 } from 'lucide-react';
import { getRecentActivity } from '@/lib/activityLogClient';
import { toast } from 'sonner';

/**
 * Get preferred voice for TTS - tries to find a more natural voice
 */
function getPreferredVoice(): SpeechSynthesisVoice | null {
  if (typeof window === "undefined" || !("speechSynthesis" in window)) return null;
  
  const voices = window.speechSynthesis.getVoices();
  if (!voices || !voices.length) return null;

  // Try to pick a good English voice (browser-dependent)
  const preferred =
    voices.find((v) => /Google US English|Microsoft .* English/i.test(v.name)) ||
    voices.find((v) => v.lang.startsWith("en-US")) ||
    voices[0];

  return preferred || null;
}

/**
 * Speak text with better voice selection
 */
function speakText(text: string, onEnd?: () => void, onError?: () => void) {
  if (typeof window === "undefined" || !("speechSynthesis" in window)) return;

  const synth = window.speechSynthesis;
  synth.cancel();

  const utterance = new SpeechSynthesisUtterance(text);

  const voice = getPreferredVoice();
  if (voice) {
    utterance.voice = voice;
  }

  // Tuned to sound less robotic than default
  utterance.rate = 0.9;
  utterance.pitch = 1.05;
  utterance.volume = 1.0;
  utterance.lang = "en-US";

  if (onEnd) utterance.onend = onEnd;
  if (onError) utterance.onerror = onError;

  synth.speak(utterance);
}

export function ActivityNarrator() {
  const [playing, setPlaying] = useState(false);
  const [loading, setLoading] = useState(false);

  // Ensure voices are loaded (some browsers load them async)
  useEffect(() => {
    if (typeof window !== "undefined" && "speechSynthesis" in window) {
      window.speechSynthesis.getVoices();
      window.speechSynthesis.onvoiceschanged = () => {
        window.speechSynthesis.getVoices();
      };
    }
  }, []);

  const handlePlay = useCallback(async () => {
    if (playing) {
      window.speechSynthesis.cancel();
      setPlaying(false);
      return;
    }

    if (!('speechSynthesis' in window)) {
      toast.error('Speech synthesis not supported in this browser');
      return;
    }

    setLoading(true);

    try {
      const events = await getRecentActivity(20);

      if (events.length === 0) {
        toast.info('No recent activity to narrate');
        setLoading(false);
        return;
      }

      setPlaying(true);
      setLoading(false);

      // Reverse to read oldest first (chronological order)
      const sentences = events
        .slice()
        .reverse()
        .map((e) => {
          const when = new Date(e.created_at).toLocaleTimeString([], { 
            hour: '2-digit', 
            minute: '2-digit' 
          });
          const executed = e.auto_executed
            ? 'and already executed.'
            : 'and is waiting for approval.';
          const actionText = e.proposed_action
            ? `Action: ${e.proposed_action}. `
            : '';
          return `At ${when}, ${e.module}. ${e.title}. ${e.summary}. ${actionText}${executed}`;
        });

      const fullText = sentences.join(' ... ');

      speakText(
        fullText,
        () => setPlaying(false),
        () => {
          setPlaying(false);
          toast.error('Narrator encountered an error');
        }
      );
    } catch (error) {
      setLoading(false);
      toast.error('Failed to load activity for narration');
    }
  }, [playing]);

  return (
    <div className="flex items-center gap-3">
      <Button
        onClick={handlePlay}
        variant="outline"
        size="sm"
        disabled={loading}
        className="gap-2"
      >
        {playing ? (
          <>
            <Square className="h-4 w-4" />
            Stop Narrator
          </>
        ) : (
          <>
            <Play className="h-4 w-4" />
            Play Activity
          </>
        )}
      </Button>
      <div className="flex items-center gap-1 text-xs text-muted-foreground">
        <Volume2 className="h-3 w-3" />
        <span>Reads the latest AI actions and proposals out loud.</span>
      </div>
    </div>
  );
}
