import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { toast } from "@/hooks/use-toast";
import { 
  FileText, Clock, Shield, Download, Eye, CheckCircle, 
  AlertTriangle, Scale, Hash, GitBranch, ExternalLink 
} from "lucide-react";
import { 
  fetchEvidenceLocker, 
  generateEvidenceBundle,
  updateAssetDefenseStatus,
  updatePacketAttorneyFlags,
  type DefenseStatus,
  type EvidenceLockerData
} from "@/core/ip-guardian/defense";
import { supabase } from "@/integrations/supabase/client";

interface EvidenceLockerPanelProps {
  assetId: string;
  tenantId: string;
  onClose?: () => void;
}

export function EvidenceLockerPanel({ assetId, tenantId, onClose }: EvidenceLockerPanelProps) {
  const queryClient = useQueryClient();
  const [notesForAttorney, setNotesForAttorney] = useState("");
  const [bundlePreview, setBundlePreview] = useState<string | null>(null);
  const [showPreview, setShowPreview] = useState(false);
  const [currentUserId, setCurrentUserId] = useState<string | null>(null);

  // Get current user for audit trail
  useEffect(() => {
    supabase.auth.getUser().then(({ data }) => {
      setCurrentUserId(data.user?.id || null);
    });
  }, []);

  const { data, isLoading, refetch } = useQuery({
    queryKey: ["evidence-locker", assetId],
    queryFn: () => fetchEvidenceLocker(assetId),
    enabled: !!assetId,
  });

  const generateBundleMutation = useMutation({
    mutationFn: () => generateEvidenceBundle({
      tenant_id: tenantId,
      asset_id: assetId,
      notes_for_attorney: notesForAttorney,
      generated_by: currentUserId || undefined,
    }),
    onSuccess: (result) => {
      toast({ title: "Evidence Bundle Generated" });
      setBundlePreview(result.bundle_html);
      setShowPreview(true);
      refetch();
    },
    onError: (error: Error) => {
      toast({ title: "Generation Failed", description: error.message, variant: "destructive" });
    },
  });

  const updateDefenseStatusMutation = useMutation({
    mutationFn: ({ status, notes }: { status: DefenseStatus; notes?: string }) =>
      updateAssetDefenseStatus(assetId, status, notes),
    onSuccess: () => {
      toast({ title: "Defense Status Updated" });
      refetch();
      queryClient.invalidateQueries({ queryKey: ["ip-assets"] });
    },
  });

  const updateAttorneyFlagsMutation = useMutation({
    mutationFn: ({ packetId, flags }: { packetId: string; flags: any }) =>
      updatePacketAttorneyFlags(packetId, flags),
    onSuccess: () => {
      toast({ title: "Attorney Flags Updated" });
      refetch();
      queryClient.invalidateQueries({ queryKey: ["ip-filing-packets"] });
    },
  });

  const downloadBundle = () => {
    if (!bundlePreview) return;
    const blob = new Blob([bundlePreview], { type: "text/html" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `evidence-bundle-${data?.asset?.name || assetId}.html`;
    a.click();
    URL.revokeObjectURL(url);
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center p-8">
        <div className="animate-spin h-8 w-8 border-2 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  if (!data?.asset) {
    return (
      <div className="p-8 text-center text-muted-foreground">
        Asset not found
      </div>
    );
  }

  const { asset, versions, events, drafts, packets, bundles } = data;

  const getDefenseStatusBadge = (status: string) => {
    switch (status) {
      case "filed_externally":
        return <Badge className="bg-green-100 text-green-800">✅ Filed Externally</Badge>;
      case "attorney_reviewed":
        return <Badge className="bg-blue-100 text-blue-800">⚖️ Attorney Reviewed</Badge>;
      case "prepped":
        return <Badge className="bg-yellow-100 text-yellow-800">📋 Prepped</Badge>;
      default:
        return <Badge className="bg-gray-100 text-gray-800">📝 Draft</Badge>;
    }
  };

  // Merge versions and events into timeline
  const timeline = [
    ...versions.map((v: any) => ({ ...v, type: "version", ts: v.created_at })),
    ...events.map((e: any) => ({ ...e, type: "event", ts: e.created_at })),
  ].sort((a, b) => new Date(a.ts).getTime() - new Date(b.ts).getTime());

  return (
    <div className="space-y-6">
      {/* Warning Banner */}
      <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
        <p className="text-sm text-amber-800">
          <strong>⚠️ Internal Documentation Only:</strong> This evidence locker is for internal tracking. 
          Attorney review is required before any legal action.
        </p>
      </div>

      {/* Asset Overview */}
      <Card>
        <CardHeader className="pb-2">
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <Shield className="h-5 w-5" />
              {asset.name}
            </CardTitle>
            {getDefenseStatusBadge(asset.defense_status || "draft")}
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div>
              <span className="text-muted-foreground">Type:</span> {asset.asset_type}
            </div>
            <div>
              <span className="text-muted-foreground">Priority:</span> {asset.legal_priority || "medium"}
            </div>
            <div>
              <span className="text-muted-foreground">Brand:</span> {asset.brand_key || "wolf-fund"}
            </div>
            <div>
              <span className="text-muted-foreground">Source:</span> {asset.source_path || "N/A"}
            </div>
          </div>
          {asset.hash_signature && (
            <div className="flex items-center gap-2 text-sm">
              <Hash className="h-4 w-4 text-muted-foreground" />
              <code className="bg-muted px-2 py-1 rounded text-xs">{asset.hash_signature}</code>
            </div>
          )}

          {/* Defense Status Update */}
          <div className="pt-2 border-t">
            <Label className="text-sm font-medium">Update Defense Status</Label>
            <div className="flex gap-2 mt-2 flex-wrap">
              {(["draft", "prepped", "attorney_reviewed", "filed_externally"] as DefenseStatus[]).map((status) => (
                <Button
                  key={status}
                  size="sm"
                  variant={asset.defense_status === status ? "default" : "outline"}
                  onClick={() => updateDefenseStatusMutation.mutate({ status })}
                  disabled={updateDefenseStatusMutation.isPending}
                >
                  {status.replace("_", " ")}
                </Button>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Timeline */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Clock className="h-5 w-5" />
            Version & Event Timeline ({timeline.length})
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ScrollArea className="h-[250px]">
            {timeline.length === 0 ? (
              <p className="text-muted-foreground text-center py-4">No history recorded</p>
            ) : (
              <div className="space-y-3">
                {timeline.map((item: any, idx: number) => (
                  <div key={idx} className="flex gap-3 border-l-2 border-primary/30 pl-4 py-2">
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        {item.type === "version" ? (
                          <GitBranch className="h-4 w-4 text-blue-500" />
                        ) : (
                          <FileText className="h-4 w-4 text-green-500" />
                        )}
                        <span className="font-medium">
                          {item.type === "version" 
                            ? `Version ${item.version_tag || idx + 1}` 
                            : item.event_type}
                        </span>
                        <span className="text-xs text-muted-foreground">
                          {new Date(item.ts).toLocaleDateString()}
                        </span>
                      </div>
                      {item.type === "version" && item.snapshot_hash && (
                        <code className="text-xs bg-muted px-1 rounded">{item.snapshot_hash.slice(0, 16)}...</code>
                      )}
                      {item.type === "event" && item.source && (
                        <span className="text-xs text-muted-foreground">Source: {item.source}</span>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </ScrollArea>
        </CardContent>
      </Card>

      {/* Linked Legal Docs */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Scale className="h-5 w-5" />
            Linked Legal Documents
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Drafts */}
          <div>
            <h4 className="text-sm font-medium mb-2">Legal Drafts ({drafts.length})</h4>
            {drafts.length === 0 ? (
              <p className="text-sm text-muted-foreground">No drafts generated</p>
            ) : (
              <div className="space-y-2">
                {drafts.slice(0, 3).map((draft: any) => (
                  <div key={draft.id} className="flex items-center justify-between p-2 bg-muted rounded">
                    <span className="text-sm">{draft.draft_type}</span>
                    <Badge variant="outline">{draft.status}</Badge>
                  </div>
                ))}
              </div>
            )}
          </div>

          <Separator />

          {/* Filing Packets */}
          <div>
            <h4 className="text-sm font-medium mb-2">Filing Packets ({packets.length})</h4>
            {packets.length === 0 ? (
              <p className="text-sm text-muted-foreground">No filing packets generated</p>
            ) : (
              <div className="space-y-3">
                {packets.map((packet: any) => (
                  <div key={packet.id} className="p-3 border rounded-lg space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="font-medium">{packet.packet_type} - {packet.title}</span>
                      <Badge variant="outline">{packet.status}</Badge>
                    </div>
                    <div className="flex flex-wrap items-center gap-4 text-sm">
                      <div className="flex items-center gap-2">
                        <Switch
                          checked={packet.attorney_reviewed || false}
                          onCheckedChange={(checked) =>
                            updateAttorneyFlagsMutation.mutate({
                              packetId: packet.id,
                              flags: { attorney_reviewed: checked },
                            })
                          }
                        />
                        <span>Attorney Reviewed</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Switch
                          checked={packet.externally_filed || false}
                          onCheckedChange={(checked) =>
                            updateAttorneyFlagsMutation.mutate({
                              packetId: packet.id,
                              flags: { externally_filed: checked },
                            })
                          }
                        />
                        <span>Externally Filed</span>
                      </div>
                    </div>
                    {/* Attorney Name field */}
                    {packet.attorney_reviewed && (
                      <Input
                        placeholder="Attorney name..."
                        defaultValue={packet.attorney_name || ""}
                        onBlur={(e) =>
                          updateAttorneyFlagsMutation.mutate({
                            packetId: packet.id,
                            flags: { attorney_name: e.target.value },
                          })
                        }
                        className="text-sm"
                      />
                    )}
                    {packet.externally_filed && (
                      <Input
                        placeholder="Filing reference number..."
                        defaultValue={packet.external_filing_ref || ""}
                        onBlur={(e) =>
                          updateAttorneyFlagsMutation.mutate({
                            packetId: packet.id,
                            flags: { external_filing_ref: e.target.value },
                          })
                        }
                        className="text-sm"
                      />
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Generate Evidence Bundle */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Download className="h-5 w-5" />
            Generate Evidence Bundle
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label>Notes for Attorney (optional)</Label>
            <Textarea
              value={notesForAttorney}
              onChange={(e) => setNotesForAttorney(e.target.value)}
              placeholder="Add any context or instructions for attorney review..."
              className="mt-1"
            />
          </div>
          <Button
            onClick={() => generateBundleMutation.mutate()}
            disabled={generateBundleMutation.isPending}
            className="w-full"
          >
            {generateBundleMutation.isPending ? "Generating..." : "Generate Evidence Bundle"}
          </Button>

          {bundles.length > 0 && (
            <div className="pt-2 border-t space-y-2">
              <p className="text-sm font-medium">Previous Bundles ({bundles.length})</p>
              <div className="space-y-2 max-h-[200px] overflow-y-auto">
                {bundles.slice(0, 10).map((bundle: any) => (
                  <div key={bundle.id} className="flex items-center justify-between p-2 bg-muted rounded text-sm">
                    <div>
                      <span className="font-medium">{bundle.bundle_type || "dispute_prep"}</span>
                      <span className="text-muted-foreground ml-2">
                        {new Date(bundle.generated_at).toLocaleDateString()}
                      </span>
                    </div>
                    <div className="flex gap-1">
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => {
                          setBundlePreview(bundle.bundle_html);
                          setShowPreview(true);
                        }}
                      >
                        <Eye className="h-3 w-3" />
                      </Button>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => {
                          const blob = new Blob([bundle.bundle_html], { type: "text/html" });
                          const url = URL.createObjectURL(blob);
                          const a = document.createElement("a");
                          a.href = url;
                          a.download = `evidence-bundle-${new Date(bundle.generated_at).toISOString().slice(0,10)}.html`;
                          a.click();
                          URL.revokeObjectURL(url);
                        }}
                      >
                        <Download className="h-3 w-3" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Bundle Preview Dialog */}
      <Dialog open={showPreview} onOpenChange={setShowPreview}>
        <DialogContent className="max-w-4xl max-h-[90vh]">
          <DialogHeader>
            <DialogTitle>Evidence Bundle Preview</DialogTitle>
          </DialogHeader>
          <div className="flex gap-2 mb-4">
            <Button onClick={downloadBundle}>
              <Download className="h-4 w-4 mr-2" />
              Download HTML
            </Button>
          </div>
          <ScrollArea className="h-[60vh]">
            {bundlePreview && (
              <iframe
                srcDoc={bundlePreview}
                className="w-full h-[55vh] border rounded"
                title="Evidence Bundle Preview"
              />
            )}
          </ScrollArea>
        </DialogContent>
      </Dialog>
    </div>
  );
}
