import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

type CreditCase = {
  id: string;
  status: string;
  ai_recommended_path?: string | null;
  last_eligibility_status?: string | null;
  last_soft_score?: number | null;
  credit_repair_applications?: {
    full_name?: string;
    email?: string;
  };
};

interface CreditCasesListProps {
  cases: CreditCase[];
  selectedId: string | null;
  onSelect: (id: string) => void;
}

export const CreditCasesList = ({ cases, selectedId, onSelect }: CreditCasesListProps) => {
  const getEligibilityBadge = (status: string | null | undefined, score: number | null | undefined) => {
    if (!status) {
      return <Badge variant="outline" className="text-[10px]">ℹ️ Not Checked</Badge>;
    }
    
    if (status === 'funding_ready') {
      return <Badge className="bg-emerald-500/20 text-emerald-300 border-emerald-500/30 text-[10px]">✅ Ready</Badge>;
    }
    if (status === 'needs_credit_clean') {
      return <Badge className="bg-amber-500/20 text-amber-300 border-amber-500/30 text-[10px]">🧹 Clean</Badge>;
    }
    if (status === 'high_risk') {
      return <Badge className="bg-rose-500/20 text-rose-300 border-rose-500/30 text-[10px]">⚠️ Risk</Badge>;
    }
    
    return <Badge variant="outline" className="text-[10px]">Unknown</Badge>;
  };

  const getAiPathBadge = (path: string | null | undefined) => {
    if (!path) return null;
    
    if (path === 'credit_fix_first') {
      return <Badge className="bg-blue-500/20 text-blue-300 border-blue-500/30 text-[10px]">Credit Fix First</Badge>;
    }
    if (path === 'fast_track_funding') {
      return <Badge className="bg-emerald-500/20 text-emerald-300 border-emerald-500/30 text-[10px]">Funding First</Badge>;
    }
    if (path === 'hybrid_path') {
      return <Badge className="bg-purple-500/20 text-purple-300 border-purple-500/30 text-[10px]">Hybrid</Badge>;
    }
    
    return <Badge className="bg-slate-500/20 text-slate-300 border-slate-500/30 text-[10px]">Review</Badge>;
  };

  const getStatusPill = (status: string) => {
    const statusColors: Record<string, string> = {
      intake: 'bg-blue-500/20 text-blue-300',
      docs_pending: 'bg-amber-500/20 text-amber-300',
      investigation: 'bg-purple-500/20 text-purple-300',
      bureaus_pending: 'bg-orange-500/20 text-orange-300',
      results_received: 'bg-emerald-500/20 text-emerald-300',
      completed: 'bg-slate-500/20 text-slate-300',
    };

    return (
      <span className={`rounded-full px-2 py-0.5 text-[10px] uppercase tracking-wide ${statusColors[status] || 'bg-slate-800 text-slate-300'}`}>
        {status.replace(/_/g, ' ')}
      </span>
    );
  };

  if (cases.length === 0) {
    return (
      <div className="flex h-full items-center justify-center p-8">
        <div className="text-center">
          <div className="text-4xl mb-3">📋</div>
          <p className="text-sm text-slate-400">No cases found</p>
          <p className="text-xs text-slate-500 mt-1">Cases will appear here when assigned</p>
        </div>
      </div>
    );
  }

  return (
    <div className="h-full space-y-2 overflow-y-auto pr-2">
      {cases.map((c) => {
        const isSelected = c.id === selectedId;
        const app = c.credit_repair_applications;

        return (
          <button
            key={c.id}
            onClick={() => onSelect(c.id)}
            className={`w-full rounded-2xl border px-4 py-3 text-left text-xs transition shadow-sm ${
              isSelected
                ? 'border-emerald-400 bg-slate-900 text-slate-50 shadow-emerald-500/20'
                : 'border-slate-800 bg-slate-950/60 text-slate-200 hover:border-slate-600 hover:bg-slate-900/40'
            }`}
          >
            <div className="flex items-center justify-between gap-2 mb-1">
              <div className="font-semibold truncate">
                {app?.full_name || 'Unknown Client'}
              </div>
              {getStatusPill(c.status)}
            </div>

            {app?.email && (
              <div className="text-[11px] text-slate-400 truncate mb-2">
                {app.email}
              </div>
            )}

            <div className="flex flex-wrap items-center gap-1.5">
              {getAiPathBadge(c.ai_recommended_path)}
              {getEligibilityBadge(c.last_eligibility_status, c.last_soft_score)}
              {c.last_soft_score != null && (
                <Badge variant="outline" className="text-[10px]">
                  Score: {c.last_soft_score}
                </Badge>
              )}
            </div>
          </button>
        );
      })}
    </div>
  );
};
