import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/components/ui/use-toast";
import { Badge } from "@/components/ui/badge";

type Props = { 
  caseId: string | null;
  onUpdate?: () => void;
};

export const CreditCaseWorkspace: React.FC<Props> = ({ caseId, onUpdate }) => {
  const [caseData, setCaseData] = useState<any | null>(null);
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  const load = async () => {
    if (!caseId) return;
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from("credit_repair_cases")
        .select(`
          *,
          credit_repair_application:credit_repair_application_id(
            full_name,
            email,
            phone
          ),
          credit_repair_items(*)
        `)
        .eq("id", caseId)
        .maybeSingle();

      if (error) throw error;
      setCaseData(data);
    } catch (e: any) {
      console.error("Failed to load case", e);
      toast({
        variant: "destructive",
        title: "Failed to load case",
        description: e.message || "Please try again.",
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    setCaseData(null);
    load();
  }, [caseId]);

  if (!caseId) {
    return (
      <div className="flex h-full items-center justify-center text-xs text-slate-400">
        Select a case from the left to begin.
      </div>
    );
  }

  if (loading || !caseData) {
    return (
      <div className="flex h-full items-center justify-center text-xs text-slate-400">
        Loading case…
      </div>
    );
  }

  const items = caseData.credit_repair_items || [];
  const application = caseData.credit_repair_application;

  return (
    <div className="flex h-full flex-col gap-3">
      {/* Top: client summary */}
      <div className="flex flex-wrap items-center justify-between gap-2 rounded-xl bg-slate-900/80 px-3 py-2">
        <div>
          <p className="text-sm font-semibold text-slate-50">
            {application?.full_name || application?.email || "Client"}
          </p>
          {application?.email && (
            <p className="text-xs text-slate-400">{application.email}</p>
          )}
          {application?.phone && (
            <p className="text-xs text-slate-400">{application.phone}</p>
          )}
        </div>
        <div className="flex flex-wrap items-center gap-2 text-[11px]">
          <Badge className="bg-slate-800 text-slate-200">
            {caseData.status.replace(/_/g, " ").toUpperCase()}
          </Badge>
          {caseData.ai_score != null && (
            <Badge className="bg-slate-800 text-slate-200">
              AI score {caseData.ai_score}
            </Badge>
          )}
        </div>
      </div>

      {/* Two-column inside workspace on desktop */}
      <div className="grid flex-1 grid-cols-1 gap-3 overflow-auto md:grid-cols-2">
        {/* Timeline / activity */}
        <div className="flex flex-col rounded-xl bg-slate-900/70 p-3">
          <p className="mb-2 text-xs font-semibold text-slate-100">
            Case Timeline
          </p>
          <div className="flex-1 space-y-2 overflow-y-auto text-[11px] text-slate-300">
            <div className="rounded-lg border border-slate-700 bg-slate-950/50 p-2">
              <p className="text-[10px] text-slate-400">
                {new Date(caseData.created_at).toLocaleDateString()}
              </p>
              <p className="text-slate-200">Case created</p>
            </div>
            {caseData.ai_last_evaluated_at && (
              <div className="rounded-lg border border-slate-700 bg-slate-950/50 p-2">
                <p className="text-[10px] text-slate-400">
                  {new Date(caseData.ai_last_evaluated_at).toLocaleDateString()}
                </p>
                <p className="text-slate-200">AI evaluation completed</p>
              </div>
            )}
            {items.length > 0 && (
              <div className="rounded-lg border border-slate-700 bg-slate-950/50 p-2">
                <p className="text-[10px] text-slate-400">Items identified</p>
                <p className="text-slate-200">{items.length} negative items detected</p>
              </div>
            )}
          </div>
        </div>

        {/* Negative items + letters */}
        <div className="flex flex-col gap-3">
          <div className="flex flex-1 flex-col rounded-xl bg-slate-900/70 p-3">
            <p className="mb-2 text-xs font-semibold text-slate-100">
              Negative Items
            </p>
            <div className="flex-1 space-y-1 overflow-y-auto text-[11px] text-slate-300">
              {items.length === 0 ? (
                <p className="py-3 text-center text-slate-500">
                  No negative items identified yet.
                </p>
              ) : (
                items.map((item: any) => (
                  <div
                    key={item.id}
                    className="rounded-lg border border-slate-700 bg-slate-950/50 p-2"
                  >
                    <p className="font-semibold text-slate-200">
                      {item.item_type.replace(/_/g, " ")}
                    </p>
                    {item.creditor_name && (
                      <p className="text-[10px] text-slate-400">{item.creditor_name}</p>
                    )}
                    <div className="mt-1 flex flex-wrap gap-1">
                      <Badge className="bg-slate-800 text-[9px] text-slate-300">
                        {item.status}
                      </Badge>
                      {item.source_bureau && (
                        <Badge className="bg-slate-800 text-[9px] text-slate-300">
                          {item.source_bureau}
                        </Badge>
                      )}
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>

          <div className="flex flex-1 flex-col rounded-xl bg-slate-900/70 p-3">
            <p className="mb-2 text-xs font-semibold text-slate-100">
              Dispute Letters
            </p>
            <div className="flex-1 text-[11px] text-slate-300">
              <p className="text-center text-slate-500">
                Letter templates will appear here once items are ready for dispute.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
