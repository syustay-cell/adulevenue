import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { FileText, Calendar, User } from "lucide-react";
import { format } from "date-fns";

interface CreditCaseDetailProps {
  caseId: string | null;
}

export function CreditCaseDetail({ caseId }: CreditCaseDetailProps) {
  const { data: caseData } = useQuery({
    queryKey: ["credit-case-detail", caseId],
    queryFn: async () => {
      if (!caseId) return null;

      const { data, error } = await supabase
        .from("credit_repair_cases")
        .select(`
          *,
          credit_repair_application:credit_repair_application_id(*),
          credit_repair_items(*),
          credit_repair_tasks(*),
          credit_repair_dispute_drafts(*)
        `)
        .eq("id", caseId)
        .maybeSingle();

      if (error) throw error;
      return data;
    },
    enabled: !!caseId,
  });

  if (!caseId) {
    return (
      <div className="flex h-full items-center justify-center">
        <div className="text-center">
          <FileText className="mx-auto mb-4 h-12 w-12 text-slate-600" />
          <p className="text-sm text-slate-400">Select a case to view details</p>
        </div>
      </div>
    );
  }

  if (!caseData) {
    return (
      <div className="flex h-full items-center justify-center">
        <div className="text-sm text-slate-400">Loading case...</div>
      </div>
    );
  }

  const items = caseData.credit_repair_items || [];
  const tasks = caseData.credit_repair_tasks || [];
  const drafts = caseData.credit_repair_dispute_drafts || [];

  return (
    <div className="flex h-full flex-col gap-4">
      {/* Header */}
      <div className="flex items-start justify-between">
        <div>
          <h2 className="text-xl font-semibold text-slate-50">
            {caseData.credit_repair_application?.full_name}
          </h2>
          <div className="mt-1 flex items-center gap-2 text-sm text-slate-400">
            <User className="h-3 w-3" />
            {caseData.credit_repair_application?.email}
          </div>
        </div>
        <Badge className="capitalize">{caseData.status.replace(/_/g, " ")}</Badge>
      </div>

      {/* Timeline */}
      <Card className="border-slate-700 bg-slate-800/50 p-4">
        <h3 className="mb-3 text-sm font-semibold text-slate-50">Case Timeline</h3>
        <div className="flex flex-col gap-2">
          <div className="flex items-center gap-2 text-xs">
            <Calendar className="h-3 w-3 text-slate-400" />
            <span className="text-slate-400">Created:</span>
            <span className="text-slate-200">
              {format(new Date(caseData.created_at), "MMM d, yyyy")}
            </span>
          </div>
          {caseData.completed_at && (
            <div className="flex items-center gap-2 text-xs">
              <Calendar className="h-3 w-3 text-slate-400" />
              <span className="text-slate-400">Completed:</span>
              <span className="text-slate-200">
                {format(new Date(caseData.completed_at), "MMM d, yyyy")}
              </span>
            </div>
          )}
        </div>
      </Card>

      {/* Stats Grid */}
      <div className="grid grid-cols-3 gap-3">
        <Card className="border-slate-700 bg-slate-800/50 p-3">
          <div className="text-xs text-slate-400">Negative Items</div>
          <div className="mt-1 text-2xl font-bold text-slate-50">{items.length}</div>
        </Card>
        <Card className="border-slate-700 bg-slate-800/50 p-3">
          <div className="text-xs text-slate-400">Tasks</div>
          <div className="mt-1 text-2xl font-bold text-slate-50">
            {tasks.filter(t => !t.completed).length}
          </div>
        </Card>
        <Card className="border-slate-700 bg-slate-800/50 p-3">
          <div className="text-xs text-slate-400">Drafts</div>
          <div className="mt-1 text-2xl font-bold text-slate-50">{drafts.length}</div>
        </Card>
      </div>

      {/* Negative Items */}
      {items.length > 0 && (
        <Card className="border-slate-700 bg-slate-800/50 p-4">
          <h3 className="mb-3 text-sm font-semibold text-slate-50">Negative Items</h3>
          <div className="flex flex-col gap-2">
            {items.slice(0, 5).map((item) => (
              <div
                key={item.id}
                className="flex items-center justify-between rounded-md border border-slate-700 bg-slate-900/50 p-2"
              >
                <div className="flex-1">
                  <div className="text-sm font-medium text-slate-200">
                    {item.creditor_name || "Unknown Creditor"}
                  </div>
                  <div className="text-xs text-slate-400">
                    {item.item_type} • {item.status}
                  </div>
                </div>
                {item.dispute_basis_code && (
                  <Badge className="bg-purple-500/20 text-[10px] text-purple-300">
                    {item.dispute_basis_code}
                  </Badge>
                )}
              </div>
            ))}
            {items.length > 5 && (
              <Button variant="ghost" size="sm" className="text-xs text-slate-400">
                View all {items.length} items →
              </Button>
            )}
          </div>
        </Card>
      )}

      {/* AI Path */}
      {caseData.ai_recommended_path && (
        <Card className="border-purple-500/30 bg-purple-500/10 p-4">
          <h3 className="mb-2 text-sm font-semibold text-purple-300">AI Recommendation</h3>
          <p className="text-xs text-slate-300">
            {caseData.ai_recommended_path === "credit_fix_first" &&
              "Credit repair should be prioritized before funding"}
            {caseData.ai_recommended_path === "funding_first" &&
              "Client may be funding-ready with minimal credit work"}
            {caseData.ai_recommended_path === "hybrid_path" &&
              "Parallel credit repair and funding approach recommended"}
          </p>
        </Card>
      )}
    </div>
  );
}
