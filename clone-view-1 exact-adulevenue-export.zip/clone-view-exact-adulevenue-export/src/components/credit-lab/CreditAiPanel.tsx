import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Brain, FileText, Shield, AlertTriangle, Activity } from "lucide-react";
import { useState } from "react";
import { useToast } from "@/components/ui/use-toast";

interface CreditAiPanelProps {
  caseId: string | null;
}

export function CreditAiPanel({ caseId }: CreditAiPanelProps) {
  const [question, setQuestion] = useState("");
  const [answer, setAnswer] = useState<string | null>(null);
  const [asking, setAsking] = useState(false);
  const { toast } = useToast();

  const { data: caseData } = useQuery({
    queryKey: ["credit-ai-panel", caseId],
    queryFn: async () => {
      if (!caseId) return null;

      const { data, error } = await supabase
        .from("credit_repair_cases")
        .select(`
          *,
          credit_repair_items(*),
          credit_repair_application:credit_repair_application_id(*)
        `)
        .eq("id", caseId)
        .maybeSingle();

      if (error) throw error;
      return data;
    },
    enabled: !!caseId,
  });

  const { data: snapshot, refetch: refetchSnapshot } = useQuery({
    queryKey: ["credit-readiness-snapshot", caseId],
    queryFn: async () => {
      if (!caseData?.credit_repair_application?.id) return null;

      // Try to find snapshot via lead_id from the application
      const { data, error } = await supabase
        .from("credit_public_snapshot")
        .select("*")
        .order("created_at", { ascending: false })
        .limit(1)
        .maybeSingle();

      if (error) throw error;
      return data;
    },
    enabled: !!caseData?.credit_repair_application?.id,
  });

  const handleRunReadiness = async () => {
    if (!caseId) return;
    try {
      toast({ title: "Running readiness test…" });
      const { error } = await supabase.functions.invoke("credit-readiness-test", {
        body: { case_id: caseId },
      });
      if (error) throw error;
      toast({
        title: "Readiness test completed",
        description: "AI score & risk flags updated.",
      });
      await refetchSnapshot();
    } catch (e: any) {
      console.error("Readiness test failed", e);
      toast({
        variant: "destructive",
        title: "Readiness test failed",
        description: e.message || "Please try again.",
      });
    }
  };

  const handleAskWolf = async () => {
    if (!caseId || !question.trim()) return;
    setAsking(true);
    try {
      const { data, error } = await supabase.functions.invoke("wolf-assistant", {
        body: {
          context: "credit_case",
          case_id: caseId,
          question,
        },
      });
      if (error) throw error;
      setAnswer(data?.answer || "No answer returned.");
    } catch (e: any) {
      console.error("Wolf assistant error", e);
      toast({
        variant: "destructive",
        title: "Assistant error",
        description: e.message || "Please try again.",
      });
    } finally {
      setAsking(false);
    }
  };

  if (!caseId) {
    return (
      <div className="flex h-[70vh] flex-col gap-3">
        <Card className="flex flex-col gap-3 border-slate-700 bg-slate-800/50 p-4">
          <div className="flex items-center gap-2">
            <Brain className="h-4 w-4 text-purple-400" />
            <h3 className="text-sm font-semibold text-slate-50">AI Control Panel</h3>
          </div>
          <p className="text-xs text-slate-400">Select a case to access AI tools</p>
        </Card>
      </div>
    );
  }

  const items = caseData?.credit_repair_items || [];
  const complianceCodes = items.filter(
    (item: any) => item.fcra_section || item.fdcpa_section || item.metro2_code
  ).length;

  const readinessScore = snapshot?.readiness_score ?? null;
  const riskLevel = snapshot?.risk_level ?? "unknown";

  const getPathLabel = (path: string | null) => {
    switch (path) {
      case "fast_track_funding": return "Funding First";
      case "credit_fix_first": return "Credit Fix First";
      case "hybrid_path": return "Hybrid Path";
      case "do_not_work": return "Do Not Work";
      default: return "Not evaluated";
    }
  };

  return (
    <div className="flex h-[70vh] flex-col gap-3">
      {/* Credit Readiness Test */}
      <Card className="border-slate-700 bg-slate-900/80 p-3 shadow-md">
        <div className="mb-2 flex items-center gap-2">
          <Activity className="h-4 w-4 text-sky-400" />
          <p className="text-xs font-semibold text-slate-100">Credit Readiness Test</p>
        </div>
        <p className="mb-2 text-[11px] text-slate-400">
          High-level public/legal signals for this client.
        </p>

        {readinessScore == null ? (
          <p className="py-3 text-[11px] text-slate-500">No test run yet for this case.</p>
        ) : (
          <div className="mb-2 rounded-xl bg-slate-950/70 p-3 text-[11px]">
            <p className="text-slate-300">
              Readiness score:{" "}
              <span className="font-semibold text-emerald-300">{readinessScore}</span>
            </p>
            <p className="text-slate-300">
              Risk: <span className="font-semibold capitalize text-slate-100">{riskLevel}</span>
            </p>
            {snapshot?.has_bankruptcy && (
              <p className="mt-1 text-[11px] text-amber-300">
                ⚠ Bankruptcy on file
              </p>
            )}
            {(snapshot?.lien_count ?? 0) > 0 && (
              <p className="mt-1 text-[11px] text-amber-300">
                ⚠ {snapshot.lien_count} lien(s) detected
              </p>
            )}
            {(snapshot?.judgment_count ?? 0) > 0 && (
              <p className="mt-1 text-[11px] text-amber-300">
                ⚠ {snapshot.judgment_count} judgment(s) detected
              </p>
            )}
          </div>
        )}

        <Button
          onClick={handleRunReadiness}
          disabled={!caseId}
          size="sm"
          className="w-full bg-sky-500 text-white hover:bg-sky-400 disabled:opacity-60"
        >
          Run Readiness Test
        </Button>
      </Card>

      {/* AI Recommendation */}
      <Card className="border-slate-700 bg-slate-900/80 p-3 shadow-md">
        <div className="mb-2 flex items-center gap-2">
          <Brain className="h-4 w-4 text-purple-400" />
          <p className="text-xs font-semibold text-slate-100">AI Route</p>
        </div>
        <p className="mb-2 text-[11px] text-slate-400">
          Wolf Brain suggested path based on score, history & risk.
        </p>

        {caseData?.ai_recommended_path ? (
          <Badge className="mb-2 bg-purple-500/20 text-purple-300">
            {getPathLabel(caseData.ai_recommended_path)}
          </Badge>
        ) : (
          <p className="text-[11px] text-slate-500">No AI recommendation yet.</p>
        )}

        {caseData?.ai_score && (
          <div className="mt-2 text-[11px] text-slate-300">
            AI Score: <span className="font-semibold">{caseData.ai_score}</span>
          </div>
        )}
      </Card>

      {/* Compliance Summary */}
      <Card className="border-slate-700 bg-slate-900/80 p-3 shadow-md">
        <div className="mb-2 flex items-center gap-2">
          <Shield className="h-4 w-4 text-blue-400" />
          <h3 className="text-xs font-semibold text-slate-50">Compliance Assistant</h3>
        </div>

        <div className="flex flex-col gap-2 text-[11px]">
          <div className="flex items-center justify-between">
            <span className="text-slate-400">Items with codes:</span>
            <Badge className="bg-blue-500/20 text-blue-300">
              {complianceCodes}/{items.length}
            </Badge>
          </div>
        </div>

        <div className="mt-3 rounded-md bg-slate-950/50 p-2">
          <p className="text-[10px] text-slate-400">
            <strong className="text-slate-300">Note:</strong> AI analysis is an administrative
            tool only, not legal advice. All strategies require specialist review.
          </p>
        </div>
      </Card>

      {/* Wolf Assistant per-case */}
      <Card className="flex flex-1 flex-col border-slate-700 bg-slate-900/80 p-3 shadow-md">
        <div className="mb-2 flex items-center gap-2">
          <FileText className="h-4 w-4 text-emerald-400" />
          <p className="text-xs font-semibold text-slate-100">Wolf Assistant</p>
        </div>
        <Textarea
          className="mb-2 h-20 border-slate-700 bg-slate-950/60 text-[11px] text-slate-100"
          placeholder="Ask Wolf how to prioritize this case, which items to dispute first, or if they look funding-ready..."
          value={question}
          onChange={(e) => setQuestion(e.target.value)}
        />
        <Button
          onClick={handleAskWolf}
          disabled={!caseId || asking}
          size="sm"
          className="mb-2 bg-emerald-500 text-white hover:bg-emerald-400 disabled:opacity-60"
        >
          {asking ? "Thinking…" : "Ask Wolf"}
        </Button>
        <div className="flex-1 overflow-y-auto rounded-xl bg-slate-950/60 p-2 text-[11px] text-slate-200">
          {answer ? (
            <p className="whitespace-pre-line">{answer}</p>
          ) : (
            <p className="text-slate-500">Wolf's answer will appear here.</p>
          )}
        </div>
      </Card>
    </div>
  );
}
