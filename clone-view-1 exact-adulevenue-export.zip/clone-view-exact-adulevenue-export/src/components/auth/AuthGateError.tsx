import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Link } from "react-router-dom";

type Props = {
  title?: string;
  message: string;
  actionHref?: string;
  actionLabel?: string;
};

export function AuthGateError({
  title = "Authentication error",
  message,
  actionHref = "/auth",
  actionLabel = "Go to sign in",
}: Props) {
  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <div className="w-full max-w-2xl">
        <Alert variant="destructive">
          <AlertTitle>{title}</AlertTitle>
          <AlertDescription>
            <p className="break-words whitespace-pre-wrap">{message}</p>
            {actionHref && actionLabel && (
              <div className="mt-3">
                <Link className="underline" to={actionHref}>
                  {actionLabel}
                </Link>
              </div>
            )}
          </AlertDescription>
        </Alert>
      </div>
    </div>
  );
}

