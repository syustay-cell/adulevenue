import { useEffect, useState } from 'react';
import { getSystemModeState, type SystemModeState } from '@/lib/systemMode';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';

const MODE_CONFIG: Record<string, { label: string; color: string; tooltip: string }> = {
  'MANUAL': {
    label: 'Manual',
    color: 'text-yellow-600 border-yellow-600/50 bg-yellow-50 dark:bg-yellow-950/30',
    tooltip: 'Manual mode. AI suggests, humans approve. No automatic actions.',
  },
  'AUTOPILOT_STANDARD': {
    label: 'Autopilot · Standard',
    color: 'text-green-600 border-green-600/50 bg-green-50 dark:bg-green-950/30',
    tooltip: 'Balanced Autopilot. Normal volume, standard risk/return targeting.',
  },
  'AUTOPILOT_ECO': {
    label: 'Autopilot · Eco',
    color: 'text-emerald-600 border-emerald-600/50 bg-emerald-50 dark:bg-emerald-950/30',
    tooltip: 'Conservative Autopilot. Lower risk, lower spend, smaller moves.',
  },
  'AUTOPILOT_AGGRESSIVE': {
    label: 'Autopilot · Aggressive',
    color: 'text-orange-600 border-orange-600/50 bg-orange-50 dark:bg-orange-950/30',
    tooltip: 'High-drive Autopilot. More outreach, more offers, within guardrails.',
  },
};

function getModeKey(state: SystemModeState): string {
  if (state.executionMode === 'MANUAL') return 'MANUAL';
  return `AUTOPILOT_${state.strategyProfile}`;
}

export function GlobalModeIndicator() {
  const [modeState, setModeState] = useState<SystemModeState | null>(null);

  useEffect(() => {
    loadMode();
    // Refresh every 30 seconds
    const interval = setInterval(loadMode, 30000);
    return () => clearInterval(interval);
  }, []);

  async function loadMode() {
    try {
      const state = await getSystemModeState();
      setModeState(state);
    } catch (err) {
      console.error('Failed to load system mode', err);
    }
  }

  if (!modeState) return null;

  const key = getModeKey(modeState);
  const config = MODE_CONFIG[key] || MODE_CONFIG['AUTOPILOT_STANDARD'];

  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>
          <span
            className={`inline-flex items-center rounded-full border px-2 py-0.5 text-[10px] font-semibold cursor-default ${config.color}`}
          >
            {config.label}
          </span>
        </TooltipTrigger>
        <TooltipContent side="bottom" className="max-w-[240px] text-center">
          <p className="text-xs">{config.tooltip}</p>
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
}
