import React from "react";
import { describe, it, expect, vi } from "vitest";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";

import { createSupabaseMock } from "@/test/utils/supabaseMock";

vi.mock("@/hooks/useUserRoles", () => ({
  useUserRoles: () => ({ roles: ["owner"] }),
}));

vi.mock("@/hooks/use-toast", () => ({
  useToast: () => ({ toast: vi.fn() }),
}));

vi.mock("@/components/puzzle-panel/PuzzlePanelContext", () => ({
  usePuzzlePanelContext: () => ({ openPanel: vi.fn() }),
}));

var supabaseMock: any;
vi.mock("@/integrations/supabase/client", () => ({
  supabase: supabaseMock,
}));

describe("ResearchCenterV10 dialer failure artifact", () => {
  it("writes dialer_send_failed artifact via save-puzzle-file when no valid phone is available", async () => {
    const canonical = {
      id: "ic_1",
      vault_id: null,
      phone_primary: null,
      email_primary: null,
      website: null,
      business_start_date: null,
      ai_summary: null,
      updated_at: new Date().toISOString(),
    };

    const lead = {
      id: "lead_1",
      business_name: "Biz",
      owner_name: "Owner",
      phone: "",
      new_phone: "",
      email: "",
      website: "",
      research_status: null,
      created_at: new Date().toISOString(),
    };

    const { supabase, invoke } = createSupabaseMock({
      authUserId: "u_owner",
      leadLists: [],
      lead,
      canonical,
      invokeImpl: async (name, args) => {
        if (name !== "save-puzzle-file") {
          return { data: null, error: { message: "unexpected invoke" } };
        }
        return { data: { ok: true, intake_client_id: canonical.id, vault_id: null }, error: null };
      },
    });
    supabaseMock = supabase;

    const { ResearchCenterV10 } = await import("@/components/lead-engine/ResearchCenterV10");

    const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } });
    render(
      <QueryClientProvider client={qc}>
        <ResearchCenterV10 />
      </QueryClientProvider>,
    );

    const user = userEvent.setup();
    await user.click(await screen.findByRole("button", { name: /Save & Send to Dialer/i }));

    // Ensure save-puzzle-file was invoked with dialer_send_failed artifact
    const calls = invoke.mock.calls.filter((c: any[]) => c[0] === "save-puzzle-file");
    expect(calls.length).toBeGreaterThan(0);
    const last = calls[calls.length - 1][1];
    const artifact = last?.body?.artifacts?.[0];
    expect(artifact?.type).toBe("dialer_send_failed");
    expect(artifact?.body_json?.reason).toBe("no_valid_phone");
    expect(artifact?.body_json?.userId).toBe("u_owner");
    expect(artifact?.body_json?.intakeClientId).toBe("ic_1");
  });
});

