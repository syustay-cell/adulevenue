import React from "react";
import { describe, it, expect, vi } from "vitest";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";

import { createSupabaseMock } from "@/test/utils/supabaseMock";

vi.mock("@/hooks/useUserRoles", () => ({
  useUserRoles: () => ({ roles: ["owner"] }),
}));

vi.mock("@/hooks/use-toast", () => ({
  useToast: () => ({ toast: vi.fn() }),
}));

vi.mock("@/components/puzzle-panel/PuzzlePanelContext", () => ({
  usePuzzlePanelContext: () => ({ openPanel: vi.fn() }),
}));

var supabaseMock: any;
vi.mock("@/integrations/supabase/client", () => ({
  supabase: supabaseMock,
}));

describe("ResearchCenterV10 Executive Summary canonical hydration", () => {
  it("loads last saved summary from intake_clients and renders canonical facts (not UI state)", async () => {
    const canonical = {
      id: "ic_1",
      vault_id: null,
      phone_primary: "15551234567",
      email_primary: "owner@example.com",
      website: "example.com",
      business_start_date: "2020-01-01",
      updated_at: new Date().toISOString(),
      ai_summary: {
        version: "v5",
        client_name: "Somebody",
        business_name: "Biz",
        contact_profile: { primary_phone: "DIFFERENT", primary_email: "DIFFERENT" },
        funding_intel: { business_age_years: 1, industry_risk: "low", notes: [] },
        snapshot: { status: "Nurture" },
      },
    };

    const lead = {
      id: "lead_1",
      business_name: "Biz",
      owner_name: "Owner",
      phone: "",
      new_phone: "",
      email: "",
      website: "",
      research_status: null,
      created_at: new Date().toISOString(),
    };

    const { supabase, invoke } = createSupabaseMock({
      authUserId: "u_owner",
      leadLists: [],
      lead,
      canonical,
      invokeImpl: async (name, args) => {
        // Should not need to call research-copilot if canonical summary exists
        return { data: { ok: true, intake_client_id: canonical.id }, error: null };
      },
    });

    supabaseMock = supabase;

    const { ResearchCenterV10 } = await import("@/components/lead-engine/ResearchCenterV10");

    const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } });
    render(
      <QueryClientProvider client={qc}>
        <ResearchCenterV10 />
      </QueryClientProvider>,
    );

    // Click the AI Summary button
    const user = userEvent.setup();
    await user.click(await screen.findByRole("button", { name: /AI Summary - Full Profile Report/i }));

    // Modal title
    expect(await screen.findByText(/Executive Intelligence Summary/i)).toBeInTheDocument();

    // Canonical facts win
    expect(await screen.findByText("15551234567")).toBeInTheDocument();
    expect(screen.getByText("owner@example.com")).toBeInTheDocument();

    // No research-copilot invoked (canonical ai_summary exists)
    expect(invoke).not.toHaveBeenCalledWith("research-copilot", expect.anything());
  });
});

