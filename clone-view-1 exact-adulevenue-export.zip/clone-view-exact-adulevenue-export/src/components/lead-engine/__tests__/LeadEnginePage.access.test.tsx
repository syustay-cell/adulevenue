import React from "react";
import { describe, it, expect, vi } from "vitest";
import { MemoryRouter } from "react-router-dom";
import { render, screen } from "@testing-library/react";

import { createSupabaseMock } from "@/test/utils/supabaseMock";

vi.mock("@/lib/api/leadEngine", () => ({
  fetchLeadLanes: vi.fn(async () => []),
}));

vi.mock("@/components/lead-engine/LeadCallQueue", () => ({
  LeadCallQueue: () => <div>LeadCallQueue</div>,
}));

vi.mock("@/components/lead-engine/LeadListsPanel", () => ({
  LeadListsPanel: () => <div>LeadListsPanel</div>,
}));

vi.mock("@/components/lead-engine/ResearchCenterV10", () => ({
  ResearchCenterV10: () => <div>ResearchCenterV10</div>,
}));

vi.mock("@/components/lead-engine/ShareRequestsDrawer", () => ({
  ShareRequestsDrawer: () => null,
}));

vi.mock("@/components/dialer/MyFollowUpsPanel", () => ({
  MyFollowUpsPanel: () => null,
}));

vi.mock("@/components/dialer/ClientWorkspaceDrawer", () => ({
  ClientWorkspaceDrawer: () => null,
}));

vi.mock("@/components/lead/LeadLaneBoard", () => ({
  LeadLaneBoard: () => <div>LeadLaneBoard</div>,
}));

var supabaseMock: any;
vi.mock("@/integrations/supabase/client", () => ({
  supabase: supabaseMock,
}));

describe("LeadEnginePage access control", () => {
  it("shows Research Center tab and mounts component", async () => {
    const { supabase } = createSupabaseMock({
      authUserId: "u_owner",
      leadLists: [],
      lead: null,
      canonical: null,
    });
    supabaseMock = supabase;

    const { default: LeadEnginePage } = await import("@/pages/LeadEnginePage");

    render(
      <MemoryRouter initialEntries={["/lead-engine/v4?tab=research"]}>
        <LeadEnginePage />
      </MemoryRouter>,
    );

    expect(await screen.findByText("Research Center")).toBeInTheDocument();
    expect(await screen.findByText("ResearchCenterV10")).toBeInTheDocument();
  });
});

