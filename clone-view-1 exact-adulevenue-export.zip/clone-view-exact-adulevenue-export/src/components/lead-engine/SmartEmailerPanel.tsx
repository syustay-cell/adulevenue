import { useState, useEffect, useCallback } from "react";
import { Mail, Send, SkipForward, RefreshCw, Users } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { useUserRoles } from "@/hooks/useUserRoles";
import { canViewRawPii, maskEmail } from "@/lib/masking";
import type { AppRole } from "@/lib/permissions";

type EmailLead = {
  id: string;
  email: string | null;
  full_name: string | null;
  business_name: string | null;
  phone: string | null;
  ai_score: number | null;
};

export function SmartEmailerPanel() {
  const { toast } = useToast();
  const { roles } = useUserRoles();
  const canViewPii = canViewRawPii((roles as AppRole[]) || []);
  const [emailLead, setEmailLead] = useState<EmailLead | null>(null);
  const [queueCount, setQueueCount] = useState(0);
  const [loading, setLoading] = useState(false);
  const [sending, setSending] = useState(false);

  const loadNextEmailLead = useCallback(async () => {
    setLoading(true);
    try {
      // Get email-only leads (has email, no phone OR route = email)
      const { data: leads, error } = await supabase
        .from("leads")
        .select("id, email, full_name, business_name, phone, ai_score")
        .not("email", "is", null)
        .or("phone.is.null,route.eq.email")
        .eq("status", "new")
        .order("ai_score", { ascending: false, nullsFirst: false })
        .limit(1);

      if (error) throw error;
      setEmailLead(leads?.[0] || null);

      // Get count
      const { count } = await supabase
        .from("leads")
        .select("*", { count: "exact", head: true })
        .not("email", "is", null)
        .or("phone.is.null,route.eq.email")
        .eq("status", "new");

      setQueueCount(count || 0);
    } catch (e: any) {
      console.error("Failed to load email lead:", e);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadNextEmailLead();
  }, [loadNextEmailLead]);

  const handleSendEmail = async () => {
    if (!emailLead || !emailLead.email) return;
    setSending(true);
    try {
      // Call send-smart-email V6 edge function
      const { data: user } = await supabase.auth.getUser();
      const { data, error } = await supabase.functions.invoke("send-smart-email", {
        body: {
          lead_id: emailLead.id,
          template_name: "general_followup_email",
          reply_in_hours: 24,
          sent_by_user_id: user?.user?.id,
        },
      });

      if (error) throw error;
      if (data && !data.success) throw new Error(data.error || "Email failed");

      toast({
        title: "Email sent",
        description: `Sent to ${canViewPii ? (data?.email || emailLead.email) : maskEmail((data?.email || emailLead.email) ?? null)}. Follow-up task will be created in 24h if no reply.`,
      });
      await loadNextEmailLead();
    } catch (e: any) {
      console.error("Send email failed:", e);
      toast({
        variant: "destructive",
        title: "Email failed",
        description: e.message || "Please try again.",
      });
    } finally {
      setSending(false);
    }
  };

  const handleSkip = async () => {
    if (!emailLead) return;
    await loadNextEmailLead();
    toast({
      title: "Skipped",
      description: "Moving to next email lead",
    });
  };

  return (
    <div className="border-t border-border bg-card/50 px-4 py-3">
      <div className="mb-2 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Mail className="h-4 w-4 text-primary" />
          <span className="text-xs font-semibold uppercase text-muted-foreground">
            Smart Emailer
          </span>
          <Badge variant="secondary" className="text-[10px]">
            <Users className="mr-1 h-3 w-3" />
            {queueCount} in queue
          </Badge>
        </div>
        <Button
          variant="ghost"
          size="sm"
          onClick={loadNextEmailLead}
          disabled={loading}
          className="h-6 px-2"
        >
          <RefreshCw className={`h-3 w-3 ${loading ? "animate-spin" : ""}`} />
        </Button>
      </div>

      {loading && !emailLead?.id ? (
        <div className="text-xs text-muted-foreground">Loading email queue...</div>
      ) : !emailLead?.id ? (
        <div className="rounded-lg border border-dashed border-border bg-muted/30 p-3 text-center text-xs text-muted-foreground">
          No email-only leads in queue. Upload lists with emails to get started.
        </div>
      ) : (
        <div className="flex items-center justify-between rounded-lg border border-border bg-card p-3">
          <div className="flex-1 min-w-0">
            <div className="font-medium text-sm truncate">
              {emailLead.business_name || "Unknown Business"}
            </div>
            <div className="text-xs text-muted-foreground truncate">
              {emailLead.full_name || "No contact"} · {canViewPii ? emailLead.email : maskEmail(emailLead.email)}
            </div>
            {emailLead.ai_score && (
              <Badge variant="outline" className="mt-1 text-[10px]">
                Score: {emailLead.ai_score}
              </Badge>
            )}
          </div>
          <div className="flex gap-2 ml-3">
            <Button
              variant="outline"
              size="sm"
              onClick={handleSkip}
              disabled={sending}
              className="h-8"
            >
              <SkipForward className="h-3 w-3" />
            </Button>
            <Button
              size="sm"
              onClick={handleSendEmail}
              disabled={sending}
              className="h-8"
            >
              {sending ? (
                <RefreshCw className="h-3 w-3 animate-spin mr-1" />
              ) : (
                <Send className="h-3 w-3 mr-1" />
              )}
              {sending ? "Sending..." : "Send Email"}
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}
