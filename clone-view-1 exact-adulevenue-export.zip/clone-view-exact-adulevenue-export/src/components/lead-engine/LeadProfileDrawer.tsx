import React, { useState } from 'react';
import { Sheet, SheetContent, SheetHeader, SheetTitle } from '@/components/ui/sheet';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { 
  Upload, FileText, Sparkles, Phone, Mail, Building2, 
  MapPin, Calendar, DollarSign, User, Shield, AlertTriangle,
  FileSpreadsheet, Clock, Hash
} from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { LegalScanPanel } from '@/components/ai-reports/LegalScanPanel';
import { useUserRoles } from "@/hooks/useUserRoles";
import { canViewRawPii } from "@/lib/masking";
import type { AppRole } from "@/lib/permissions";

interface LeadProfileDrawerProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  lead: any;
  onEnrichmentComplete?: () => void;
}

export function LeadProfileDrawer({ 
  open, 
  onOpenChange, 
  lead,
  onEnrichmentComplete 
}: LeadProfileDrawerProps) {
  const { toast } = useToast();
  const { roles } = useUserRoles();
  const canViewPii = canViewRawPii((roles as AppRole[]) || []);
  const [isEnriching, setIsEnriching] = useState(false);
  const [uploadingFile, setUploadingFile] = useState(false);

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file || !lead?.id) return;

    try {
      setUploadingFile(true);
      const filePath = `${lead.id}/${Date.now()}_${file.name}`;
      const { error: uploadError } = await supabase.storage
        .from('lead-files')
        .upload(filePath, file);

      if (uploadError) throw uploadError;

      const { error: dbError } = await supabase
        .from('lead_files')
        .insert({
          lead_id: lead.id,
          file_name: file.name,
          file_path: filePath,
          file_type: file.type,
          file_size: file.size,
          is_ai_generated: false,
        });

      if (dbError) throw dbError;

      toast({
        title: "File Uploaded",
        description: `${file.name} attached to lead`,
      });
    } catch (error) {
      console.error('File upload error:', error);
      toast({
        title: "Upload Failed",
        description: error instanceof Error ? error.message : 'Failed to upload file',
        variant: "destructive",
      });
    } finally {
      setUploadingFile(false);
      event.target.value = '';
    }
  };

  const handleEnrichLead = async () => {
    if (!lead?.id) return;

    try {
      setIsEnriching(true);
      
      const { error } = await supabase.functions.invoke('wolf-brain-enrich-lead', {
        body: { lead_id: lead.id }
      });

      if (error) throw error;

      toast({
        title: "Enrichment Complete",
        description: "Lead data enhanced with AI insights",
      });

      onEnrichmentComplete?.();
    } catch (error) {
      console.error('Enrichment error:', error);
      toast({
        title: "Enrichment Failed",
        description: error instanceof Error ? error.message : 'Failed to enrich lead',
        variant: "destructive",
      });
    } finally {
      setIsEnriching(false);
    }
  };

  if (!lead) return null;
  if (!canViewPii) {
    return (
      <Sheet open={open} onOpenChange={onOpenChange}>
        <SheetContent className="w-full sm:max-w-2xl p-0">
          <SheetHeader className="p-6 pb-0">
            <SheetTitle className="flex items-center gap-2">
              <Shield className="h-5 w-5 text-destructive" />
              Access denied
            </SheetTitle>
            <p className="text-sm text-muted-foreground">
              This view contains raw client identifiers and is <span className="font-semibold">Owner-only</span>.
            </p>
          </SheetHeader>
          <div className="p-6">
            <div className="rounded-lg border border-border bg-card p-4 text-sm text-muted-foreground">
              PII is masked for non-owners. Use system-mediated actions instead.
            </div>
          </div>
        </SheetContent>
      </Sheet>
    );
  }

  // Extract all data from lead and raw_data
  const rawData = lead.raw_data as Record<string, any> || {};
  
  // Owner info
  const ownerFullName = lead.owner_full_name || rawData["Owner Full Name"] || "";
  const ownerFirstName = lead.owner_first_name || rawData["Owner First Name"] || "";
  const ownerLastName = lead.owner_last_name || rawData["Owner Last Name"] || "";
  const displayOwnerName = ownerFullName || `${ownerFirstName} ${ownerLastName}`.trim() || lead.full_name || "";
  const ownerBirthDate = lead.owner_birth_date || rawData["Birth Date"] || "";
  
  // Business info
  const businessName = lead.business_name || rawData["Business Name"] || "";
  const businessStartDate = lead.business_start_date || rawData["Business Start Date"] || "";
  const ein = lead.ein || rawData["EIN"] || "";
  const ssnMasked = lead.ssn_masked || (rawData["SSN"] ? `***-**-${String(rawData["SSN"]).slice(-4)}` : "");
  
  // Contact info
  const phone = lead.phone || rawData["Mobile"] || "";
  const email = lead.email || rawData["Email"] || "";
  const phoneLineType = lead.phone_line_type || rawData["Line Type"] || "";
  const phoneCarrier = lead.phone_carrier || rawData["Carrier"] || "";
  
  // Address info
  const address = lead.address || rawData["Address"] || rawData["Address "] || "";
  const city = lead.city || rawData["City"] || "";
  const state = lead.state || rawData["State"] || "";
  const postalCode = lead.postal_code || rawData["Zip"] || "";
  const fullAddress = [address, city, state, postalCode].filter(Boolean).join(", ");
  
  // Financial info
  const monthlyRevenue = lead.estimated_monthly_revenue || rawData["Monthly Revenue"] || null;
  const defaultsFlag = lead.defaults_flag ?? rawData["Defaults"] ?? null;
  const fileAgeCode = lead.file_age_code || rawData["Age"] || "";
  
  // Source info
  const sourceListName = lead.source_list_name || "";
  const sourceFileName = lead.source_file_name || "";
  const sourceFolderName = lead.source_folder_name || rawData["Drive Folder Name"] || "";
  
  // AI Scoring
  const aiScore = lead.ai_score;
  const aiPriority = lead.ai_priority;
  const aiRecommendedPath = lead.ai_recommended_path;
  const fundingScore = lead.funding_score;
  
  // Route/Status
  const importBucket = lead.import_bucket || lead.route || "";
  const status = lead.status || "";

  const InfoRow = ({ label, value, icon: Icon, sensitive = false }: { 
    label: string; 
    value: string | number | null | undefined; 
    icon?: any;
    sensitive?: boolean;
  }) => {
    if (!value && value !== 0) return null;
    return (
      <div className="flex items-start gap-3 py-2">
        {Icon && <Icon className="h-4 w-4 text-muted-foreground mt-0.5 shrink-0" />}
        <div className="flex-1 min-w-0">
          <div className="text-xs text-muted-foreground">{label}</div>
          <div className={`text-sm font-medium truncate ${sensitive ? 'font-mono' : ''}`}>
            {typeof value === 'number' ? value.toLocaleString() : value}
          </div>
        </div>
      </div>
    );
  };

  const Section = ({ title, children }: { title: string; children: React.ReactNode }) => (
    <div className="space-y-1">
      <h3 className="text-sm font-semibold text-foreground">{title}</h3>
      <div className="bg-muted/30 rounded-lg p-3 space-y-1">
        {children}
      </div>
    </div>
  );

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent className="w-full sm:max-w-2xl p-0">
        <SheetHeader className="p-6 pb-0">
          <SheetTitle className="flex items-center gap-2">
            <FileSpreadsheet className="h-5 w-5 text-primary" />
            Complete Lead Profile
          </SheetTitle>
          <p className="text-sm text-muted-foreground">
            All extracted data for this lead
          </p>
        </SheetHeader>

        <ScrollArea className="h-[calc(100vh-8rem)]">
          <div className="p-6 space-y-6">
            {/* Status Badges */}
            <div className="flex flex-wrap gap-2">
              {importBucket && (
                <Badge variant={importBucket === 'dialer' ? 'default' : importBucket === 'email' ? 'secondary' : 'outline'}>
                  {importBucket.toUpperCase()}
                </Badge>
              )}
              {status && (
                <Badge variant="outline">{status}</Badge>
              )}
              {aiPriority && (
                <Badge variant={aiPriority === 'A' ? 'default' : aiPriority === 'B' ? 'secondary' : 'outline'}>
                  Priority {aiPriority}
                </Badge>
              )}
              {defaultsFlag && (
                <Badge variant="destructive">
                  <AlertTriangle className="h-3 w-3 mr-1" />
                  Has Defaults
                </Badge>
              )}
            </div>

            {/* AI Scores */}
            {(aiScore || fundingScore) && (
              <div className="grid grid-cols-2 gap-3">
                {aiScore && (
                  <div className="bg-primary/10 rounded-lg p-3 text-center">
                    <div className="text-2xl font-bold text-primary">{aiScore}</div>
                    <div className="text-xs text-muted-foreground">AI Score</div>
                  </div>
                )}
                {fundingScore && (
                  <div className="bg-emerald-500/10 rounded-lg p-3 text-center">
                    <div className="text-2xl font-bold text-emerald-600">{fundingScore}</div>
                    <div className="text-xs text-muted-foreground">Funding Score</div>
                  </div>
                )}
              </div>
            )}

            {aiRecommendedPath && (
              <div className="p-3 bg-amber-500/10 border border-amber-500/20 rounded-lg">
                <div className="text-xs text-muted-foreground">AI Recommended Path</div>
                <div className="text-sm font-semibold text-amber-700 dark:text-amber-400">
                  {aiRecommendedPath.replace(/_/g, ' ').toUpperCase()}
                </div>
              </div>
            )}

            <Separator />

            {/* Owner Information */}
            <Section title="👤 Owner Information">
              <InfoRow label="Full Name" value={displayOwnerName} icon={User} />
              <InfoRow label="First Name" value={ownerFirstName} />
              <InfoRow label="Last Name" value={ownerLastName} />
              <InfoRow label="Date of Birth" value={ownerBirthDate} icon={Calendar} />
              <InfoRow label="SSN (Masked)" value={ssnMasked} icon={Shield} sensitive />
            </Section>

            {/* Business Information */}
            <Section title="🏢 Business Information">
              <InfoRow label="Business Name" value={businessName} icon={Building2} />
              <InfoRow label="Business Start Date" value={businessStartDate} icon={Calendar} />
              <InfoRow label="EIN" value={ein} icon={Hash} sensitive />
              <InfoRow label="Monthly Revenue" value={monthlyRevenue ? `$${Number(monthlyRevenue).toLocaleString()}` : null} icon={DollarSign} />
              <InfoRow label="Defaults" value={defaultsFlag ? 'Yes' : defaultsFlag === false ? 'No' : null} icon={AlertTriangle} />
              <InfoRow label="File Age Code" value={fileAgeCode} icon={Clock} />
            </Section>

            {/* Contact Information */}
            <Section title="📞 Contact Information">
              <InfoRow label="Phone" value={phone} icon={Phone} />
              <InfoRow label="Line Type" value={phoneLineType} />
              <InfoRow label="Carrier" value={phoneCarrier} />
              <InfoRow label="Email" value={email} icon={Mail} />
            </Section>

            {/* Address */}
            <Section title="📍 Address">
              <InfoRow label="Street Address" value={address} icon={MapPin} />
              <InfoRow label="City" value={city} />
              <InfoRow label="State" value={state} />
              <InfoRow label="ZIP Code" value={postalCode} />
              {fullAddress && (
                <div className="pt-2 border-t border-border/50 mt-2">
                  <div className="text-xs text-muted-foreground">Full Address</div>
                  <div className="text-sm">{fullAddress}</div>
                </div>
              )}
            </Section>

            {/* Source Information */}
            <Section title="📁 Source Information">
              <InfoRow label="Source List" value={sourceListName} icon={FileSpreadsheet} />
              <InfoRow label="Source File" value={sourceFileName} icon={FileText} />
              <InfoRow label="Drive Folder" value={sourceFolderName} />
              <InfoRow label="Lead ID" value={lead.id} sensitive />
              <InfoRow label="Created" value={lead.created_at ? new Date(lead.created_at).toLocaleString() : null} icon={Clock} />
            </Section>

            {/* Raw Data (collapsed by default) */}
            {Object.keys(rawData).length > 0 && (
              <details className="group">
                <summary className="cursor-pointer text-sm font-semibold text-muted-foreground hover:text-foreground">
                  📋 View All Raw Fields ({Object.keys(rawData).length} fields)
                </summary>
                <div className="mt-2 bg-muted/30 rounded-lg p-3 space-y-1 text-xs">
                  {Object.entries(rawData).map(([key, value]) => (
                    <div key={key} className="flex justify-between gap-2 py-1 border-b border-border/30 last:border-0">
                      <span className="text-muted-foreground truncate">{key}</span>
                      <span className="font-mono text-right truncate max-w-[60%]">
                        {typeof value === 'object' ? JSON.stringify(value) : String(value || '—')}
                      </span>
                    </div>
                  ))}
                </div>
            </details>
            )}

            <Separator />

            {/* AI Legal / Lien / Bankruptcy Scan */}
            {lead?.id && (
              <LegalScanPanel
                leadId={lead.id}
                contextForAI={{
                  business_name: businessName,
                  owner_name: displayOwnerName,
                  ein: ein,
                  state: state,
                  city: city,
                  address_line1: address,
                  zip: postalCode,
                }}
              />
            )}

            <Separator />

            {/* Actions */}
            <div className="flex flex-wrap gap-2">
              <Button
                onClick={handleEnrichLead}
                disabled={isEnriching}
                size="sm"
                variant="outline"
              >
                <Sparkles className="h-4 w-4 mr-2" />
                {isEnriching ? 'Enriching...' : 'AI Enrich'}
              </Button>
              
              <label htmlFor="file-upload-drawer">
                <Button
                  size="sm"
                  variant="outline"
                  disabled={uploadingFile}
                  asChild
                >
                  <span className="cursor-pointer">
                    <Upload className="h-4 w-4 mr-2" />
                    {uploadingFile ? 'Uploading...' : 'Upload File'}
                  </span>
                </Button>
                <input
                  id="file-upload-drawer"
                  type="file"
                  className="hidden"
                  onChange={handleFileUpload}
                  disabled={uploadingFile}
                />
              </label>

              {phone && (
                <Button size="sm" variant="default" asChild>
                  <a href={`tel:${phone}`}>
                    <Phone className="h-4 w-4 mr-2" />
                    Call
                  </a>
                </Button>
              )}

              {email && (
                <Button size="sm" variant="secondary" asChild>
                  <a href={`mailto:${email}`}>
                    <Mail className="h-4 w-4 mr-2" />
                    Email
                  </a>
                </Button>
              )}
            </div>
          </div>
        </ScrollArea>
      </SheetContent>
    </Sheet>
  );
}
