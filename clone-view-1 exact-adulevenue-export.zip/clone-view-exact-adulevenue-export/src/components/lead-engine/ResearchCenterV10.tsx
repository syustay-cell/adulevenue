import React, { useEffect, useMemo, useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Card } from '@/components/ui/card';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { useQueryClient } from "@tanstack/react-query";
import { 
  Search, Loader2, Phone, Mail, ArrowRight, XCircle, SkipForward,
  Compass, Lightbulb, Zap, User, Building2, FileText, ExternalLink, AlertCircle, Save
} from 'lucide-react';
import { SendInfoModal } from '@/components/dialer/SendInfoModal';
import { ClientWorkspaceDrawer } from '@/components/dialer/ClientWorkspaceDrawer';
import DOMPurify from 'dompurify';
import { usePuzzlePanelContext } from "@/components/puzzle-panel/PuzzlePanelContext";

// Simple markdown to HTML converter
const markdownToHtml = (markdown: string): string => {
  if (!markdown) return '';
  
  let html = markdown
    // Headers
    .replace(/^### (.*$)/gim, '<h3 class="text-lg font-semibold text-slate-800 mt-4 mb-2">$1</h3>')
    .replace(/^## (.*$)/gim, '<h2 class="text-xl font-bold text-slate-800 mt-6 mb-3 border-b border-slate-200 pb-2">$1</h2>')
    .replace(/^# (.*$)/gim, '<h1 class="text-2xl font-bold text-slate-900 mt-6 mb-4">$1</h1>')
    // Bold and italic
    .replace(/\*\*\*(.+?)\*\*\*/g, '<strong><em>$1</em></strong>')
    .replace(/\*\*(.+?)\*\*/g, '<strong class="font-semibold">$1</strong>')
    .replace(/\*(.+?)\*/g, '<em>$1</em>')
    // Lists
    .replace(/^\s*[-*]\s+(.*)$/gim, '<li class="ml-4 text-slate-700">$1</li>')
    .replace(/^\s*(\d+)\.\s+(.*)$/gim, '<li class="ml-4 text-slate-700">$2</li>')
    // Line breaks
    .replace(/\n\n/g, '</p><p class="mb-3 text-slate-700">')
    .replace(/\n/g, '<br/>');
  
  // Wrap in paragraph if not starting with header
  if (!html.startsWith('<h')) {
    html = '<p class="mb-3 text-slate-700">' + html + '</p>';
  }
  
  return html;
};

// Safe array helper - ensures we always have an array for .map()
const safeArray = (items: unknown): string[] => {
  if (!items) return [];
  if (typeof items === 'string') return [items];
  if (Array.isArray(items)) return items.map(i => String(i));
  if (typeof items === 'object') {
    return Object.entries(items).map(([k, v]) => `${k}: ${String(v)}`);
  }
  return [String(items)];
};

const hashString = (value: string): string => {
  let hash = 5381;
  for (let i = 0; i < value.length; i += 1) {
    hash = (hash * 33) ^ value.charCodeAt(i);
  }
  return (hash >>> 0).toString(16);
};

interface LeadList {
  id: string;
  name: string;
}

interface Lead {
  id: string;
  lead_list_id: string | null;
  business_name: string | null;
  owner_name: string | null;
  owner_full_name?: string | null;
  owner_first_name?: string | null;
  owner_last_name?: string | null;
  owner_birth_date?: string | null;
  phone: string | null;
  new_phone: string | null;
  email: string | null;
  website: string | null;
  business_start_date?: string | null;
  ein?: string | null;
  ssn_masked?: string | null;
  address?: string | null;
  city?: string | null;
  state?: string | null;
  postal_code?: string | null;
  source_list_name?: string | null;
  source_file_name?: string | null;
  source_folder_name?: string | null;
  raw_data?: Record<string, any> | null;
  research_notes: string | null;
  ai_score: number | null;
  ai_priority: string | null;
  ai_recommended_path: string | null;
  funding_score: number | null;
  funding_recommendation: string | null;
}

interface CopilotMessage {
  id: string;
  role: 'system' | 'ai' | 'user';
  text: string;
  timestamp: Date;
}

interface QueueStats {
  in_research: number;
  fixed_today: number;
  routed_dialer: number;
  routed_email: number;
}

type PuzzleFile = {
  intakeClientId: string;
  vaultId: string | null;
  intakeClient: any | null;
};

type PuzzleCanonical = {
  id: string;
  vault_id: string | null;
  full_name?: string | null;
  business_name?: string | null;
  phone_primary: string | null;
  email_primary: string | null;
  website: string | null;
  address?: string | null;
  city?: string | null;
  state?: string | null;
  zip?: string | null;
  ein?: string | null;
  owner_birth_date?: string | null;
  ssn_last4?: string | null;
  source_meta?: Record<string, any> | null;
  business_start_date: string | null;
  ai_summary: any | null;
  updated_at: string | null;
};

type SummaryView = {
  canonical: PuzzleCanonical;
  summary: any | null;
  display: {
    primary_phone: string;
    primary_email: string;
    website: string;
    years_in_business: string;
  };
};

export const ResearchCenterV10: React.FC = () => {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { openPanel } = usePuzzlePanelContext();
  
  // State
  const [lists, setLists] = useState<LeadList[]>([]);
  const [selectedListId, setSelectedListId] = useState<string>('all');
  const [activeLead, setActiveLead] = useState<Lead | null>(null);
  const [loadingLead, setLoadingLead] = useState(false);
  const [userId, setUserId] = useState<string | null>(null);
  
  // Form state
  const [phone, setPhone] = useState('');
  const [newPhone, setNewPhone] = useState('');
  const [email, setEmail] = useState('');
  const [website, setWebsite] = useState('');
  const [notes, setNotes] = useState('');
  
  // Stats
  const [stats, setStats] = useState<QueueStats>({ in_research: 0, fixed_today: 0, routed_dialer: 0, routed_email: 0 });
  const [bootError, setBootError] = useState<string | null>(null);
  
  // Copilot
  const [copilotMessages, setCopilotMessages] = useState<CopilotMessage[]>([]);
  const [copilotLoading, setCopilotLoading] = useState<string | null>(null);
  
  // Modals
  const [showSendModal, setShowSendModal] = useState(false);
  const [showWorkspace, setShowWorkspace] = useState(false);
  const [showSummary, setShowSummary] = useState(false);
  const [summaryView, setSummaryView] = useState<SummaryView | null>(null);
  const [sendChannel, setSendChannel] = useState<'sms' | 'email'>('sms');
  const [puzzleFile, setPuzzleFile] = useState<PuzzleFile | null>(null);
  const [canonicalDebug, setCanonicalDebug] = useState<PuzzleCanonical | null>(null);
  const [savingPuzzle, setSavingPuzzle] = useState(false);

  const buildSummaryInput = () => ({
    lead_id: activeLead?.id ?? null,
    business_name: activeLead?.business_name ?? null,
    contact_name:
      activeLead?.owner_full_name ||
      (activeLead?.owner_first_name && activeLead?.owner_last_name
        ? `${activeLead.owner_first_name} ${activeLead.owner_last_name}`
        : activeLead?.owner_name || null),
    phone: phone || newPhone || activeLead?.phone || null,
    email: email || activeLead?.email || null,
    website: website || activeLead?.website || null,
    address: activeLead?.address || null,
    city: activeLead?.city || null,
    state: activeLead?.state || null,
    zip: activeLead?.postal_code || null,
    lead_list_id: activeLead?.lead_list_id ?? null,
    source_list_name: activeLead?.source_list_name ?? null,
    source_file_name: activeLead?.source_file_name ?? null,
  });

  const buildSummaryMeta = (
    input: Record<string, unknown>,
    overrides: Record<string, unknown>,
  ) => {
    const inputHash = hashString(JSON.stringify(input));
    return {
      summary_version: overrides.summary_version ?? "v5",
      generated_at: new Date().toISOString(),
      input_hash: inputHash,
      source: "research_center_v10",
      ...overrides,
    };
  };

  const attachSummaryMeta = (summary: Record<string, any>, input: Record<string, unknown>, overrides: Record<string, unknown>) => {
    const meta = buildSummaryMeta(input, overrides);
    const existingMeta =
      summary?.wf_meta && typeof summary.wf_meta === "object" ? summary.wf_meta : {};
    return {
      ...summary,
      wf_meta: {
        ...existingMeta,
        ...meta,
      },
    };
  };

  const buildFallbackSummary = (
    input: ReturnType<typeof buildSummaryInput>,
    errorInfo: Record<string, unknown> | null,
  ) => {
    const fullName = input.contact_name || "Unknown";
    const [firstName, lastName] = fullName.split(" ");
    const location = [input.city, input.state].filter(Boolean).join(", ");
    const fullAddress = [input.address, input.city, input.state, input.zip].filter(Boolean).join(", ");

    return {
      version: "fallback_v1",
      client_name: fullName,
      client_first_name: firstName || null,
      client_last_name: lastName || null,
      business_name: input.business_name || "Unknown",
      funding_path: activeLead?.funding_recommendation || "funding_first",
      funding_score: activeLead?.funding_score ?? null,
      priority_band: activeLead?.ai_priority ?? null,
      snapshot: {
        one_liner: input.business_name ? `${input.business_name} lead` : "Lead summary unavailable",
        status: "Nurture",
        quick_summary:
          "AI summary unavailable. Using cached lead identity details until a full report is generated.",
      },
      contact_profile: {
        primary_phone: input.phone,
        primary_email: input.email,
        location: location || null,
        full_address: fullAddress || null,
        best_channel: input.phone ? "phone" : input.email ? "email" : "none",
      },
      business_intel: {
        business_name: input.business_name || "Unknown",
        owner_name: fullName,
        owner_first_name: firstName || null,
        owner_last_name: lastName || null,
        ein: activeLead?.ein || null,
        business_start_date: activeLead?.business_start_date || null,
        years_in_business: null,
        industry: null,
        industry_risk_level: "medium",
        employee_count: null,
        website: input.website,
        notes: ["Fallback summary stored due to AI failure."],
      },
      funding_intel: {
        estimated_monthly_revenue: null,
        annual_revenue: null,
        business_age_years: null,
        industry_risk: "medium",
        notes: [],
      },
      credit_identity_intel: {
        credit_risk: "medium",
        identity_theft_risk: "low",
        credit_fix_recommended: false,
        notes: [],
      },
      public_records_intel: {
        overall_risk: "unknown",
        liens: { has_liens: false, lien_count: 0, lien_details: [], total_lien_amount: null },
        tax_issues: {
          has_tax_liens: false,
          tax_lien_count: 0,
          tax_details: [],
          irs_issues: false,
          state_tax_issues: false,
        },
        bankruptcies: {
          has_bankruptcy: false,
          bankruptcy_type: null,
          bankruptcy_date: null,
          bankruptcy_status: null,
          bankruptcy_details: [],
        },
        court_records: {
          has_court_cases: false,
          civil_cases: 0,
          criminal_cases: 0,
          court_details: [],
        },
        judgments: {
          has_judgments: false,
          judgment_count: 0,
          judgment_details: [],
          total_judgment_amount: null,
        },
        ucc_filings: { has_ucc: false, ucc_count: 0, ucc_details: [] },
        summary: "No public records summary available.",
      },
      ocm_intel: {
        is_ocm: false,
        license_id: null,
        license_status: null,
        expiration_date: null,
        municipality: null,
      },
      risk_flags: [],
      recommended_next_steps: [],
      credit_fix_action_items: [],
      missing_info: [],
      wf_meta: buildSummaryMeta(input, {
        summary_version: "fallback_v1",
        status: "fallback",
        last_error: errorInfo || null,
      }),
    };
  };

  const buildCanonicalUpdates = (summaryPayload?: any) => ({
    full_name:
      activeLead?.owner_full_name ||
      (activeLead?.owner_first_name && activeLead?.owner_last_name
        ? `${activeLead.owner_first_name} ${activeLead.owner_last_name}`
        : activeLead?.owner_name || null),
    business_name: activeLead?.business_name || null,
    phone_primary: phone || newPhone || null,
    email_primary: email || null,
    website: website || null,
    ai_summary: summaryPayload ?? summaryView?.summary ?? null,
    business_start_date:
      summaryPayload?.business_intel?.business_start_date ??
      summaryPayload?.business_intelligence?.business_start_date ??
      summaryView?.summary?.business_intel?.business_start_date ??
      summaryView?.summary?.business_intelligence?.business_start_date ??
      activeLead?.business_start_date ??
      null,
    ein: activeLead?.ein || null,
    owner_birth_date: activeLead?.owner_birth_date || null,
    ssn_last4: activeLead?.ssn_masked ? activeLead.ssn_masked.replace(/[^0-9]/g, "").slice(-4) : null,
    source_meta: {
      excel_import: {
        batch_id: activeLead?.lead_list_id ?? null,
        row_index: activeLead?.raw_data?.row_index ?? null,
        file_name: activeLead?.source_file_name ?? null,
        list_name: activeLead?.source_list_name ?? null,
        folder_name: activeLead?.source_folder_name ?? null,
      },
    },
  });

  // Initialize
  useEffect(() => {
    console.log("[ResearchCenterV10] mount", { href: window.location.href });
    supabase.auth
      .getUser()
      .then(({ data }) => {
        setUserId(data.user?.id ?? null);
      })
      .catch((e) => {
        console.error('[ResearchCenterV10] auth.getUser failed:', e);
        setUserId(null);
      });

    // Never allow an unhandled rejection to crash the page
    void loadLeadLists().catch((e) => {
      console.error('[ResearchCenterV10] loadLeadLists failed:', e);
      setBootError('Failed to load lead lists.');
      setLists([]);
    });
  }, []);

  useEffect(() => {
    // Never allow an unhandled rejection to crash the page
    void loadStatsAndLead().catch((e) => {
      console.error('[ResearchCenterV10] loadStatsAndLead failed:', e);
      setBootError('Failed to load research queue.');
    });
  }, [selectedListId]);

  // Executive Summary modal: hydrate from canonical on open (reload-safe)
  useEffect(() => {
    if (!showSummary) return;
    void hydrateSummaryFromCanonical().catch((e) => {
      console.error("[ResearchCenterV10] hydrateSummaryFromCanonical failed:", e);
    });
  }, [showSummary, activeLead?.id]);

  const loadLeadLists = async () => {
    try {
      const { data, error } = await supabase
        .from('lead_lists')
        .select('id, name')
        .order('created_at', { ascending: false });

      if (error) {
        console.error('[ResearchCenterV10] lead_lists error:', error);
        setBootError(error.message || 'Failed to load lead lists.');
        setLists([]);
        return;
      }

      setLists((data as LeadList[]) || []);
    } catch (e) {
      console.error('[ResearchCenterV10] loadLeadLists fatal:', e);
      setBootError('Failed to load lead lists.');
      setLists([]);
    }
  };

  const loadStatsAndLead = async () => {
    try {
      await Promise.all([loadStats(), loadActiveLead()]);
    } catch (e) {
      console.error('[ResearchCenterV10] loadStatsAndLead fatal:', e);
      setBootError('Failed to load research queue.');
    }
  };

  const loadStats = async () => {
    try {
      const { data, error } = await supabase.rpc('research_center_stats', {
        p_lead_list_id: selectedListId === 'all' ? null : selectedListId
      });
      
      if (error) {
        console.error('[ResearchCenterV10] Stats RPC error:', error);
        return;
      }
      
      if (data && typeof data === 'object') {
        const statsData = data as unknown as QueueStats;
        setStats({
          in_research: statsData.in_research || 0,
          fixed_today: statsData.fixed_today || 0,
          routed_dialer: statsData.routed_dialer || 0,
          routed_email: statsData.routed_email || 0,
        });
      }
    } catch (e) {
      console.error('[ResearchCenterV10] loadStats error:', e);
    }
  };

  const loadActiveLead = async () => {
    setLoadingLead(true);
    setCopilotMessages([]);

    try {
      // Build query to find leads needing research:
      // - Not skipped
      // - research_status is null, pending, or in_progress
      let query = supabase
        .from('leads')
        .select('*')
        .or('research_status.is.null,research_status.eq.pending,research_status.eq.in_progress')
        .order('created_at', { ascending: true })
        .limit(1);

      if (selectedListId !== 'all') {
        query = query.eq('lead_list_id', selectedListId);
      }

      const { data, error } = await query.maybeSingle();

      if (error) throw error;

      if (!data) {
        setActiveLead(null);
        clearForm();
        // If stats say there are leads but we can't fetch any, that's commonly RLS/policy mismatch.
        // `research_center_stats` is SECURITY DEFINER and can report counts even when RLS blocks row reads.
        if (stats.in_research > 0) {
          setBootError('Research queue is non-empty, but this user cannot read leads. Likely RLS/policy mismatch.');
        }
        return;
      }

      setActiveLead(data as unknown as Lead);
      populateForm(data as unknown as Lead);
    } catch (e: any) {
      console.error('[ResearchCenterV10] loadActiveLead:', e);
      toast({ variant: 'destructive', title: 'Failed to load lead' });
    } finally {
      setLoadingLead(false);
    }
  };

  const populateForm = (lead: Lead) => {
    setPhone(lead.phone || '');
    setNewPhone(lead.new_phone || '');
    setEmail(lead.email || '');
    setWebsite(lead.website || '');
    setNotes(lead.research_notes || '');
  };

  const clearForm = () => {
    setPhone('');
    setNewPhone('');
    setEmail('');
    setWebsite('');
    setNotes('');
  };

  const currentListLabel = useMemo(() => {
    if (selectedListId === 'all') return 'All Lists';
    return lists.find(l => l.id === selectedListId)?.name || 'Selected List';
  }, [selectedListId, lists]);

  // Copilot helpers
  const pushCopilotMessage = (role: CopilotMessage['role'], text: string) => {
    setCopilotMessages(prev => [...prev, {
      id: `${Date.now()}-${Math.random()}`,
      role,
      text,
      timestamp: new Date(),
    }]);
  };

  const isDebugEnabled = () => {
    try {
      return new URLSearchParams(window.location.search).get("debug") === "1";
    } catch {
      return false;
    }
  };

  const fetchPuzzleCanonical = async (): Promise<PuzzleCanonical | null> => {
    if (!activeLead?.id) return null;

    // Preferred: by intake_client_id we already have.
    if (puzzleFile?.intakeClientId) {
      const { data, error } = await supabase
        .from("intake_clients")
        .select("id, vault_id, full_name, business_name, phone_primary, email_primary, website, address, city, state, zip, ein, owner_birth_date, ssn_last4, source_meta, business_start_date, ai_summary, updated_at")
        .eq("id", puzzleFile.intakeClientId)
        .maybeSingle();
      if (error) throw error;
      if (data) return data as any;
    }

    // Fallback: latest file by lead_id
    const { data, error } = await supabase
      .from("intake_clients")
      .select("id, vault_id, full_name, business_name, phone_primary, email_primary, website, address, city, state, zip, ein, owner_birth_date, ssn_last4, source_meta, business_start_date, ai_summary, updated_at")
      .eq("lead_id", activeLead.id)
      .order("updated_at", { ascending: false })
      .limit(1)
      .maybeSingle();
    if (error) throw error;
    return (data as any) ?? null;
  };

  const buildSummaryViewModel = (canonical: PuzzleCanonical, summaryJson: any | null): SummaryView => {
    const primary_phone =
      canonical.phone_primary ||
      summaryJson?.contact_profile?.primary_phone ||
      "Missing";
    const primary_email =
      canonical.email_primary ||
      summaryJson?.contact_profile?.primary_email ||
      "Missing";
    const website =
      canonical.website ||
      summaryJson?.business_intel?.website ||
      summaryJson?.business_intelligence?.website ||
      "Missing";

    let years_in_business = "Unknown";
    const start = canonical.business_start_date || summaryJson?.business_intel?.business_start_date || summaryJson?.business_intelligence?.business_start_date;
    if (typeof start === "string" && start.trim()) {
      const d = new Date(start);
      if (!Number.isNaN(d.getTime())) {
        const years = Math.max(0, Math.floor((Date.now() - d.getTime()) / (365.25 * 24 * 60 * 60 * 1000)));
        years_in_business = String(years);
      }
    } else if (typeof summaryJson?.funding_intel?.business_age_years === "number") {
      years_in_business = String(summaryJson.funding_intel.business_age_years);
    }

    return {
      canonical,
      summary: summaryJson ?? null,
      display: {
        primary_phone,
        primary_email,
        website,
        years_in_business,
      },
    };
  };

  const refreshPuzzleFor = async (intakeClientId: string, leadId: string) => {
    // Open the panel (this also logs panel_open)
    openPanel(intakeClientId);

    // Force-refresh all queries that back the Puzzle UI.
    await Promise.all([
      queryClient.invalidateQueries({ queryKey: ["puzzle-header", intakeClientId] }),
      queryClient.invalidateQueries({ queryKey: ["puzzle-panel-client", intakeClientId] }),
      queryClient.invalidateQueries({ queryKey: ["intake-client-lead", intakeClientId] }),
      queryClient.invalidateQueries({ queryKey: ["client-activity", leadId] }),
      queryClient.invalidateQueries({ queryKey: ["client-notes", leadId] }),
      queryClient.invalidateQueries({ queryKey: ["outreach-tasks", intakeClientId] }),
      queryClient.invalidateQueries({ queryKey: ["funding-applications", intakeClientId] }),
      queryClient.invalidateQueries({ queryKey: ["funding-deals", intakeClientId] }),
    ]);
  };

  const savePuzzleFile = async (params: {
    canonicalUpdates?: Record<string, unknown>;
    artifacts?: Array<{
      type: string;
      subject?: string | null;
      body_json?: unknown;
      body_text?: string | null;
      meta?: Record<string, unknown>;
    }>;
    refreshPuzzle?: boolean;
  }): Promise<PuzzleFile> => {
    if (!activeLead?.id) throw new Error("No lead selected");

    const { data, error } = await supabase.functions.invoke("save-puzzle-file", {
      body: {
        lead_id: activeLead.id,
        intake_client_id: puzzleFile?.intakeClientId ?? null,
        canonical_updates: params.canonicalUpdates ?? {},
        artifacts: params.artifacts ?? [],
      },
    });

    if (error) throw error;
    if (!data?.ok) throw new Error(data?.error || "Save failed");

    const next: PuzzleFile = {
      intakeClientId: data.intake_client_id,
      vaultId: data.vault_id ?? null,
      intakeClient: data.intake_client ?? null,
    };
    setPuzzleFile(next);
    if (params.refreshPuzzle) {
      await refreshPuzzleFor(next.intakeClientId, activeLead.id);
    }
    return next;
  };

  const hydrateSummaryFromCanonical = async () => {
    const canonical = await fetchPuzzleCanonical();
    if (!canonical) {
      setSummaryView(null);
      return;
    }
    setPuzzleFile({ intakeClientId: canonical.id, vaultId: canonical.vault_id ?? null, intakeClient: canonical });
    setSummaryView(buildSummaryViewModel(canonical, canonical.ai_summary ?? null));
  };

  // AI Actions
  const handleRunSpider = async () => {
    if (!activeLead?.id) {
      toast({ variant: 'destructive', title: 'No lead selected' });
      return;
    }

    setCopilotLoading('spider');
    pushCopilotMessage('system', '🔍 Running AI Research Spider - searching for contact info...');

    try {
      const { data, error } = await supabase.functions.invoke('research-copilot', {
        body: { lead_id: activeLead.id, mode: 'spider' }
      });

      if (error) throw new Error(error.message || 'Network error');
      if (!data?.ok) throw new Error(data?.message || 'AI Spider failed');

      // Update form fields with found data
      if (data?.phone) {
        if (phone && data.phone !== phone) {
          setNewPhone(data.phone);
          pushCopilotMessage('ai', `📱 Found new phone: ${data.phone} (different from original)`);
        } else if (!phone) {
          setPhone(data.phone);
          pushCopilotMessage('ai', `📱 Found phone: ${data.phone}`);
        }
      }
      if (data?.email && !email) {
        setEmail(data.email);
        pushCopilotMessage('ai', `📧 Found email: ${data.email}`);
      }
      if (data?.website && !website) {
        setWebsite(data.website);
        pushCopilotMessage('ai', `🌐 Found website: ${data.website}`);
      }
      
      // Handle owner name extraction
      if (data?.owner_name || data?.owner_first_name || data?.owner_last_name) {
        const firstName = data.owner_first_name || null;
        const lastName = data.owner_last_name || null;
        const fullName = data.owner_name || (firstName && lastName ? `${firstName} ${lastName}` : null);
        
        if (fullName || firstName || lastName) {
          pushCopilotMessage('ai', `👤 Found owner: ${fullName || `${firstName || ''} ${lastName || ''}`.trim()}`);
          
          // Update the lead in database with owner names
          const updateData: Record<string, any> = {};
          if (fullName) updateData.owner_name = fullName;
          if (firstName) updateData.owner_first_name = firstName;
          if (lastName) updateData.owner_last_name = lastName;
          
          if (Object.keys(updateData).length > 0) {
            await supabase.from('leads').update(updateData).eq('id', activeLead.id);
            // Update local state
            setActiveLead(prev => prev ? { ...prev, ...updateData } : null);
          }
        }
      }

      // Show summary
      const summary = data?.summary || 'Research complete. Check the updated fields above.';
      pushCopilotMessage('ai', `\n${summary}\n\nConfidence: ${Math.round((data?.confidence || 0) * 100)}%`);

      await savePuzzleFile({
        canonicalUpdates: {
          full_name:
            data?.owner_name ||
            (data?.owner_first_name && data?.owner_last_name
              ? `${data.owner_first_name} ${data.owner_last_name}`
              : null),
          business_name: activeLead.business_name || null,
          phone_primary: data?.phone || newPhone || phone || null,
          email_primary: data?.email || email || null,
          website: data?.website || website || null,
          address: data?.address || null,
          city: data?.city || null,
          state: data?.state || null,
        },
        artifacts: [
          {
            type: "ai_research_spider_result",
            subject: "AI Research Spider",
            body_json: data,
            meta: {
              source_action: "research_center_v10.research_spider",
              mode: "spider",
              generated_at: new Date().toISOString(),
            },
          },
        ],
        refreshPuzzle: false,
      });
    } catch (e: any) {
      console.error('[ResearchCenterV10] Spider error:', e);
      pushCopilotMessage('ai', '❌ I ran into an error while researching this lead. Try again or use manual search links below.');
    } finally {
      setCopilotLoading(null);
    }
  };

  const handleSuggestContact = async () => {
    if (!activeLead?.id) return;

    setCopilotLoading('suggest');
    pushCopilotMessage('system', 'Analyzing best contact info...');

    try {
      const { data, error } = await supabase.functions.invoke('research-copilot', {
        body: { lead_id: activeLead.id, mode: 'suggest_contact' }
      });

      if (error) throw new Error(error.message || 'Network error');
      if (!data?.ok) throw new Error(data?.message || 'Contact suggestion failed');

      if (data?.best_phone && !phone) setPhone(data.best_phone);
      if (data?.best_email && !email) setEmail(data.best_email);

      const lines: string[] = [];
      if (data?.best_phone) lines.push(`Best phone: ${data.best_phone} (${Math.round((data.phone_confidence || 0) * 100)}% confidence)`);
      if (data?.best_email) lines.push(`Best email: ${data.best_email} (${Math.round((data.email_confidence || 0) * 100)}% confidence)`);
      if (data?.notes) lines.push(data.notes);

      pushCopilotMessage('ai', lines.join('\n') || 'No additional contact suggestions found.');
    } catch (e: any) {
      console.error('[ResearchCenterV10] Suggest error:', e);
      pushCopilotMessage('ai', 'Could not analyze contact info. Try manual research.');
    } finally {
      setCopilotLoading(null);
    }
  };

  const handleRecommendRoute = async () => {
    if (!activeLead?.id) return;

    setCopilotLoading('route');
    pushCopilotMessage('system', 'Analyzing best routing...');

    try {
      const { data, error } = await supabase.functions.invoke('research-copilot', {
        body: { lead_id: activeLead.id, mode: 'recommend_route' }
      });

      if (error) throw new Error(error.message || 'Network error');
      if (!data?.ok) throw new Error(data?.message || 'Route recommendation failed');

      const route = data?.recommended_route || 'dialer';
      const message = data?.ai_message || `I recommend routing this lead to: ${route}`;
      
      pushCopilotMessage('ai', message);

      await savePuzzleFile({
        artifacts: [
          {
            type: "ai_route_recommendation_result",
            subject: "AI Route Recommendation",
            body_json: data,
            meta: {
              source_action: "research_center_v10.recommend_route",
              mode: "recommend_route",
              generated_at: new Date().toISOString(),
            },
          },
        ],
        refreshPuzzle: false,
      });
    } catch (e: any) {
      console.error('[ResearchCenterV10] Route error:', e);
      pushCopilotMessage('ai', 'Could not determine best route. Default to Dialer if phone exists.');
    } finally {
      setCopilotLoading(null);
    }
  };

  const handlePublicRecordsScan = async () => {
    if (!activeLead?.id) return;

    setCopilotLoading('public');
    pushCopilotMessage('system', 'Scanning public records for liens, tax issues, bankruptcies, court cases...');

    try {
      const { data, error } = await supabase.functions.invoke('research-copilot', {
        body: { lead_id: activeLead.id, mode: 'public_records' }
      });

      if (error) throw new Error(error.message || 'Network error');
      if (!data?.ok) throw new Error(data?.message || 'Public records scan failed');

      // Extract owner name and address from public records if found
      if (data?.owner_first_name || data?.owner_last_name || data?.address_from_records) {
        const updateData: Record<string, any> = {};
        
        if (data.owner_first_name && !activeLead.owner_first_name) {
          updateData.owner_first_name = data.owner_first_name;
        }
        if (data.owner_last_name && !activeLead.owner_last_name) {
          updateData.owner_last_name = data.owner_last_name;
        }
        if (data.owner_full_name && !activeLead.owner_name) {
          updateData.owner_name = data.owner_full_name;
        }
        if (data.address_from_records && !activeLead.address) {
          updateData.address = data.address_from_records;
        }
        if (data.city_from_records && !activeLead.city) {
          updateData.city = data.city_from_records;
        }
        if (data.state_from_records && !activeLead.state) {
          updateData.state = data.state_from_records;
        }
        if (data.postal_code_from_records && !activeLead.postal_code) {
          updateData.postal_code = data.postal_code_from_records;
        }
        
        if (Object.keys(updateData).length > 0) {
          await supabase.from('leads').update(updateData).eq('id', activeLead.id);
          setActiveLead(prev => prev ? { ...prev, ...updateData } : null);
          
          const foundItems = [];
          if (updateData.owner_first_name || updateData.owner_last_name) {
            foundItems.push(`Owner: ${updateData.owner_first_name || ''} ${updateData.owner_last_name || ''}`.trim());
          }
          if (updateData.address) foundItems.push(`Address: ${updateData.address}`);
          if (foundItems.length > 0) {
            pushCopilotMessage('ai', `📋 Extracted from public records:\n${foundItems.join('\n')}`);
          }
        }
      }

      const message = data?.ai_message || 
        `🔍 **PUBLIC RECORDS SCAN RESULTS**\n\n` +
        `**Risk Level:** ${data?.risk_level || 'Unknown'}\n\n` +
        `**📋 Liens:**\n${data?.has_liens ? '⚠️ Yes - ' + data.lien_details : '✅ None found'}\n\n` +
        `**⚖️ Judgments & Court Cases:**\n${data?.has_judgments ? '⚠️ Yes - ' + data.judgment_details : '✅ None found'}\n\n` +
        `**📉 Bankruptcies:**\n${data?.has_bankruptcies ? '⚠️ Yes - ' + data.bankruptcy_details : '✅ None found'}\n\n` +
        `**💰 Tax Liens:**\n${data?.has_tax_liens ? '⚠️ Yes - ' + data.tax_lien_details : '✅ None found'}\n\n` +
        `**📄 UCC Filings:**\n${data?.has_ucc_filings ? '⚠️ Yes - ' + data.ucc_details : '✅ None found'}\n\n` +
        `**🏛️ Court Records:**\n${data?.has_court_records ? '⚠️ Yes - ' + data.court_details : '✅ None found'}\n\n` +
        `---\n` +
        `**Summary:** ${data?.risk_summary || 'N/A'}\n` +
        `**Recommendation:** ${data?.funding_recommendation || 'N/A'}`;
      
      pushCopilotMessage('ai', message);

      await savePuzzleFile({
        canonicalUpdates: {
          full_name:
            data?.owner_full_name ||
            (data?.owner_first_name && data?.owner_last_name
              ? `${data.owner_first_name} ${data.owner_last_name}`
              : null),
          address: data?.address_from_records || null,
          city: data?.city_from_records || null,
          state: data?.state_from_records || null,
          zip: data?.postal_code_from_records || null,
        },
        artifacts: [
          {
            type: "ai_public_records_result",
            subject: "Public Records Intel",
            body_json: data,
            meta: {
              source_action: "research_center_v10.public_records",
              mode: "public_records",
              generated_at: new Date().toISOString(),
            },
          },
        ],
        refreshPuzzle: false,
      });
    } catch (e: any) {
      console.error('[ResearchCenterV10] Public records error:', e);
      pushCopilotMessage('ai', 'Could not complete public records scan. Try again later.');
    } finally {
      setCopilotLoading(null);
    }
  };

  const handleGenerateSummary = async () => {
    if (!activeLead?.id) {
      toast({ variant: 'destructive', title: 'No lead selected', description: 'Please select a lead first' });
      return;
    }

    setShowSummary(true);
    const summaryInput = buildSummaryInput();

    try {
      // 1) Always hydrate from canonical on open (reload-safe)
      await hydrateSummaryFromCanonical();

      // 2) If canonical summary exists, load it automatically (no prompt).
      const canonical = await fetchPuzzleCanonical();
      if (canonical?.ai_summary) {
        setSummaryView(buildSummaryViewModel(canonical, canonical.ai_summary));
        return;
      }

      // 3) Otherwise generate summary, save to canonical, then re-hydrate from canonical
      setCopilotLoading('summary');
      const { data, error } = await supabase.functions.invoke('research-copilot', {
        body: { lead_id: activeLead.id, mode: 'summary_v5' }
      });
      if (error || !data?.ok) {
        const errorInfo = {
          edge_fn: "research-copilot",
          error_code: data?.error_code ?? "AI_SUMMARY_FAILED",
          message: error?.message || data?.message || "AI Summary temporarily unavailable",
          request_id: data?.request_id ?? null,
          client_id: puzzleFile?.intakeClientId ?? null,
          input_hash: buildSummaryMeta(summaryInput, {}).input_hash,
          generated_at: new Date().toISOString(),
        };

        const fallbackSummary = buildFallbackSummary(summaryInput, errorInfo);
        const fallbackPayload = attachSummaryMeta(fallbackSummary, summaryInput, {
          summary_version: "fallback_v1",
          status: "fallback",
          last_error: errorInfo,
        });

        await savePuzzleFile({
          canonicalUpdates: buildCanonicalUpdates(fallbackPayload),
          artifacts: [
            {
              type: "ai_summary_error",
              subject: "Executive Summary failed",
              body_json: errorInfo,
              meta: {
                source_action: "research_center_v10.executive_summary",
                mode: "summary_v5",
                generated_at: new Date().toISOString(),
              },
            },
          ],
          refreshPuzzle: true,
        });

        await hydrateSummaryFromCanonical();
        toast({ variant: 'destructive', title: 'Summary generation failed', description: 'Showing fallback data' });
        return;
      }

      const summaryPayload = attachSummaryMeta(data, summaryInput, {
        summary_version: data?.version ?? "v5",
        status: "success",
      });

      await savePuzzleFile({
        canonicalUpdates: buildCanonicalUpdates(summaryPayload),
        artifacts: [
          {
            type: "ai_executive_summary_v5",
            subject: "Executive Summary (V5)",
            body_json: summaryPayload,
            meta: {
              source_action: "research_center_v10.executive_summary",
              mode: "summary_v5",
              generated_at: new Date().toISOString(),
            },
          },
        ],
        refreshPuzzle: true,
      });

      await hydrateSummaryFromCanonical();
    } catch (e: any) {
      console.error('[ResearchCenterV10] Summary error:', e);
      const errorInfo = {
        edge_fn: "research-copilot",
        error_code: "AI_SUMMARY_FAILED",
        message: e?.message || "AI Summary temporarily unavailable",
        request_id: null,
        client_id: puzzleFile?.intakeClientId ?? null,
        input_hash: buildSummaryMeta(summaryInput, {}).input_hash,
        generated_at: new Date().toISOString(),
      };
      const fallbackSummary = buildFallbackSummary(summaryInput, errorInfo);
      const fallbackPayload = attachSummaryMeta(fallbackSummary, summaryInput, {
        summary_version: "fallback_v1",
        status: "fallback",
        last_error: errorInfo,
      });

      try {
        await savePuzzleFile({
          canonicalUpdates: buildCanonicalUpdates(fallbackPayload),
          artifacts: [
            {
              type: "ai_summary_error",
              subject: "Executive Summary failed",
              body_json: errorInfo,
              meta: {
                source_action: "research_center_v10.executive_summary",
                mode: "summary_v5",
                generated_at: new Date().toISOString(),
              },
            },
          ],
          refreshPuzzle: true,
        });
        await hydrateSummaryFromCanonical();
      } catch (saveErr) {
        console.warn("[ResearchCenterV10] Fallback save failed:", saveErr);
        const localCanonical: PuzzleCanonical = {
          id: puzzleFile?.intakeClientId ?? activeLead.id,
          vault_id: puzzleFile?.vaultId ?? null,
          full_name: buildCanonicalUpdates(fallbackPayload).full_name || null,
          business_name: buildCanonicalUpdates(fallbackPayload).business_name || null,
          phone_primary: buildCanonicalUpdates(fallbackPayload).phone_primary || null,
          email_primary: buildCanonicalUpdates(fallbackPayload).email_primary || null,
          website: buildCanonicalUpdates(fallbackPayload).website || null,
          address: activeLead.address || null,
          city: activeLead.city || null,
          state: activeLead.state || null,
          zip: activeLead.postal_code || null,
          ein: activeLead.ein || null,
          owner_birth_date: activeLead.owner_birth_date || null,
          ssn_last4: activeLead.ssn_masked ? activeLead.ssn_masked.replace(/[^0-9]/g, "").slice(-4) : null,
          source_meta: buildCanonicalUpdates(fallbackPayload).source_meta ?? null,
          business_start_date: activeLead.business_start_date || null,
          ai_summary: fallbackPayload,
          updated_at: new Date().toISOString(),
        };
        setSummaryView(buildSummaryViewModel(localCanonical, fallbackPayload));
      }
      toast({ variant: 'destructive', title: 'Summary generation failed', description: 'Showing fallback data' });
    } finally {
      setCopilotLoading(null);
    }
  };

  const handleRegenerateSummary = async () => {
    if (!activeLead?.id) {
      toast({ variant: 'destructive', title: 'No lead selected', description: 'Please select a lead first' });
      return;
    }
    setShowSummary(true);
    setCopilotLoading('summary');
    const summaryInput = buildSummaryInput();
    try {
      const { data, error } = await supabase.functions.invoke('research-copilot', {
        body: { lead_id: activeLead.id, mode: 'summary_v5' }
      });
      if (error || !data?.ok) {
        const errorInfo = {
          edge_fn: "research-copilot",
          error_code: data?.error_code ?? "AI_SUMMARY_FAILED",
          message: error?.message || data?.message || "AI Summary temporarily unavailable",
          request_id: data?.request_id ?? null,
          client_id: puzzleFile?.intakeClientId ?? null,
          input_hash: buildSummaryMeta(summaryInput, {}).input_hash,
          generated_at: new Date().toISOString(),
        };

        const canonical = await fetchPuzzleCanonical();
        const existingSummary = canonical?.ai_summary || null;
        const fallbackSummary = existingSummary
          ? attachSummaryMeta(existingSummary, summaryInput, {
              summary_version: existingSummary?.version ?? "v5",
              status: "cached",
              last_error: errorInfo,
            })
          : attachSummaryMeta(buildFallbackSummary(summaryInput, errorInfo), summaryInput, {
              summary_version: "fallback_v1",
              status: "fallback",
              last_error: errorInfo,
            });

        await savePuzzleFile({
          canonicalUpdates: buildCanonicalUpdates(fallbackSummary),
          artifacts: [
            {
              type: "ai_summary_error",
              subject: "Executive Summary regenerate failed",
              body_json: errorInfo,
              meta: {
                source_action: "research_center_v10.executive_summary.regenerate",
                mode: "summary_v5",
                generated_at: new Date().toISOString(),
              },
            },
          ],
          refreshPuzzle: true,
        });

        await hydrateSummaryFromCanonical();
        toast({ variant: 'destructive', title: 'Regenerate failed', description: 'Showing cached summary' });
        return;
      }

      const summaryPayload = attachSummaryMeta(data, summaryInput, {
        summary_version: data?.version ?? "v5",
        status: "success",
      });

      await savePuzzleFile({
        canonicalUpdates: buildCanonicalUpdates(summaryPayload),
        artifacts: [
          {
            type: "ai_executive_summary_v5",
            subject: "Executive Summary (V5)",
            body_json: summaryPayload,
            meta: {
              source_action: "research_center_v10.executive_summary.regenerate",
              mode: "summary_v5",
              generated_at: new Date().toISOString(),
            },
          },
        ],
        refreshPuzzle: true,
      });

      await hydrateSummaryFromCanonical();
    } catch (e: any) {
      console.error('[ResearchCenterV10] Regenerate summary error:', e);
      toast({ variant: 'destructive', title: 'Regenerate failed', description: e?.message || 'Unable to regenerate summary' });
    } finally {
      setCopilotLoading(null);
    }
  };

  // Save to Intake & Route
  const [savingToIntake, setSavingToIntake] = useState(false);
  const [primaryPath, setPrimaryPath] = useState<'funding_first' | 'credit_first' | 'hybrid' | 'do_not_work'>('funding_first');
  
  const handleSaveToPuzzleDraft = async () => {
    if (!activeLead?.id) {
      toast({ variant: 'destructive', title: 'No lead selected' });
      return;
    }

    try {
      setSavingPuzzle(true);
      const generatedAt = new Date().toISOString();
      const ref = `PUZZLE-SAVE-${activeLead.id.slice(0, 8)}-${Date.now()}`;
      const summaryInput = buildSummaryInput();
      const summaryPayload = summaryView?.summary
        ? attachSummaryMeta(summaryView.summary, summaryInput, {
            summary_version: summaryView.summary?.version ?? "v5",
            status: "cached",
          })
        : attachSummaryMeta(buildFallbackSummary(summaryInput, null), summaryInput, {
            summary_version: "fallback_v1",
            status: "manual_save",
          });

      const saved = await savePuzzleFile({
        canonicalUpdates: buildCanonicalUpdates(summaryPayload),
        artifacts: [
          {
            type: "puzzle_draft",
            subject: "Saved to Puzzle (Draft)",
            body_json: {
              ref,
              generated_at: generatedAt,
              lead_id: activeLead.id,
              has_summary: Boolean(summaryPayload),
              puzzle_state: "draft",
            },
            meta: {
              source_action: "research_center_v10.save_to_puzzle",
              ref,
              generated_at: generatedAt,
            },
          },
          ...(summaryPayload
            ? [
                {
                  type: "ai_executive_summary_v5",
                  subject: "Executive Summary (V5)",
                  body_json: summaryPayload,
                  meta: {
                    source_action: "research_center_v10.ai_summary_full_profile_report",
                    ref,
                    generated_at: generatedAt,
                  },
                },
              ]
            : []),
        ],
        refreshPuzzle: true,
      });

      toast({
        title: "Saved to Puzzle",
        description: saved.vaultId ? `Stored under ${saved.vaultId}.` : "Saved.",
      });
      if (!summaryView?.summary) {
        setSummaryView(buildSummaryViewModel(
          {
            id: saved.intakeClientId,
            vault_id: saved.vaultId ?? null,
            phone_primary: buildCanonicalUpdates(summaryPayload).phone_primary || null,
            email_primary: buildCanonicalUpdates(summaryPayload).email_primary || null,
            website: buildCanonicalUpdates(summaryPayload).website || null,
            business_start_date: buildCanonicalUpdates(summaryPayload).business_start_date || null,
            ai_summary: summaryPayload,
            updated_at: generatedAt,
          },
          summaryPayload,
        ));
      }
    } catch (e: any) {
      console.error("[ResearchCenterV10] Save to Puzzle draft error:", e);
      toast({
        variant: "destructive",
        title: "Save failed",
        description: e?.message || "Unable to save Puzzle file.",
      });
    } finally {
      setSavingPuzzle(false);
    }
  };

  // Generate summary HTML from canonical-hydrated summary view for PDF/Print
  const generateSummaryHtml = (): string => {
    if (!summaryView?.summary) return '';
    const s = summaryView.summary;
    const display = summaryView.display;
    
    const bulletList = (items?: string[] | string | object | null) => {
      if (!items) return '';
      if (typeof items === 'string') return `<li>${items}</li>`;
      if (Array.isArray(items)) return items.map(i => `<li>${String(i)}</li>`).join('');
      if (typeof items === 'object') {
        // Handle object - convert to array of strings
        return Object.entries(items).map(([k, v]) => `<li><strong>${k}:</strong> ${String(v)}</li>`).join('');
      }
      return '';
    };
    
    return `
      <div class="wf-summary">
        <header class="mb-6 border-b pb-4">
          <div class="text-xs tracking-widest text-amber-600 font-semibold">WOLF FUND</div>
          <h1 class="mt-1 text-2xl font-bold text-slate-900">Executive Intelligence Summary</h1>
          <p class="mt-2 text-sm text-slate-500">${activeLead?.business_name || 'Business Profile'}</p>
        </header>
        
        <section class="mb-6">
          <div class="flex flex-wrap gap-2 text-sm">
            <span class="inline-flex items-center rounded-full bg-emerald-50 px-3 py-1 text-emerald-700">
              Funding Score: <span class="ml-1 font-semibold">${s.funding_score ?? '—'}</span>
            </span>
            <span class="inline-flex items-center rounded-full bg-indigo-50 px-3 py-1 text-indigo-700">
              Priority: <span class="ml-1 font-semibold">${s.priority_grade ?? s.ai_priority ?? '—'}</span>
            </span>
            <span class="inline-flex items-center rounded-full bg-amber-50 px-3 py-1 text-amber-700">
              ${s.funding_recommendation || s.recommended_path || primaryPath}
            </span>
          </div>
        </section>
        
        <section class="mb-6">
          <h3 class="text-sm font-semibold text-slate-700 uppercase tracking-wide">Business Intelligence</h3>
          <ul class="mt-2 list-disc pl-5 text-sm text-slate-700">
            ${bulletList(s.business_intelligence?.key_findings || s.key_findings || [])}
          </ul>
        </section>
        
        <section class="mb-6">
          <h3 class="text-sm font-semibold text-slate-700 uppercase tracking-wide">Risk Assessment</h3>
          <p class="mt-1 text-sm">
            <strong>Credit Risk:</strong> ${(s.credit_risk || 'UNKNOWN').toUpperCase()} · 
            <strong class="ml-2">ID Theft Risk:</strong> ${(s.identity_theft_risk || 'UNKNOWN').toUpperCase()}
          </p>
          <ul class="mt-2 list-disc pl-5 text-sm">
            ${bulletList(s.risk_factors || s.fraud_signals || [])}
          </ul>
        </section>
        
        <section class="mb-6">
          <h3 class="text-sm font-semibold text-slate-700 uppercase tracking-wide">Public Records Intel</h3>
          <ul class="mt-2 list-disc pl-5 text-sm">
            ${bulletList(s.public_records_intel?.summary || s.public_records || [])}
          </ul>
        </section>
        
        <section class="mb-6">
          <h3 class="text-sm font-semibold text-slate-700 uppercase tracking-wide">Recommended Next Steps</h3>
          <ol class="mt-2 list-decimal pl-5 text-sm">
            ${bulletList(s.recommended_next_steps || s.next_steps || [])}
          </ol>
        </section>
        
        <footer class="mt-8 border-t pt-4 text-xs text-slate-500">
          Wolf Fund Intelligence System • Confidential • ${new Date().toLocaleDateString()}
        </footer>
      </div>
    `;
  };
  
  const handleSaveToIntake = async () => {
    if (!activeLead?.id) {
      toast({ variant: 'destructive', title: 'No lead selected' });
      return;
    }

    setSavingToIntake(true);

    try {
      const summaryInput = buildSummaryInput();
      const summaryPayload = summaryView?.summary
        ? attachSummaryMeta(summaryView.summary, summaryInput, {
            summary_version: summaryView.summary?.version ?? "v5",
            status: "cached",
          })
        : attachSummaryMeta(buildFallbackSummary(summaryInput, null), summaryInput, {
            summary_version: "fallback_v1",
            status: "save_to_intake",
          });

      // Use the new save-intake-route function with full summary data
      // Note: Do NOT send created_by - the edge function doesn't use it
      const { data, error } = await supabase.functions.invoke('save-intake-route', {
        body: {
          lead_id: activeLead.id,
          route_tag: primaryPath,
          summary_json: summaryPayload,
          profile_updates: {
            business_name: activeLead.business_name || null,
            contact_name: activeLead.owner_first_name && activeLead.owner_last_name
              ? `${activeLead.owner_first_name} ${activeLead.owner_last_name}`
              : activeLead.owner_name || activeLead.owner_full_name || null,
            owner_first_name: activeLead.owner_first_name || null,
            owner_last_name: activeLead.owner_last_name || null,
            phone: phone || newPhone || null,
            email: email || null,
            website: website || null,
          },
        }
      });

      if (error) {
        console.error('[ResearchCenterV10] Edge function error:', error);
        throw new Error(error.message || 'Edge function failed');
      }
      
      if (!data?.success) {
        throw new Error(data?.error || 'Save failed');
      }

      const routeLabel = data.route === 'dialer' ? 'Dialer Queue' : 
                         data.route === 'email' ? 'Email Queue' : 
                         data.route === 'credit_fix' ? 'Credit Fix Queue' :
                         data.route === 'archived' ? 'Archived' :
                         'Research Queue';

      toast({
        title: '✅ Saved to Intake',
        description: `Client saved with path: ${primaryPath.replace(/_/g, ' ')}. Routed to ${routeLabel}`,
      });

      if (data?.intake_client_id) {
        const nextFile: PuzzleFile = {
          intakeClientId: data.intake_client_id,
          vaultId: null,
          intakeClient: null,
        };
        setPuzzleFile(nextFile);
        await refreshPuzzleFor(nextFile.intakeClientId, activeLead.id);
      }

      // Close summary modal and load next lead
      setShowSummary(false);
      await loadStatsAndLead();
    } catch (e: any) {
      console.error('[ResearchCenterV10] Save to intake error:', e);
      toast({ variant: 'destructive', title: 'Save failed', description: e.message || 'Unknown error' });
    } finally {
      setSavingToIntake(false);
    }
  };

  // Save & Route helpers
  const saveLeadEdits = async () => {
    if (!activeLead) return;

    const { error } = await supabase
      .from('leads')
      .update({
        phone: phone || null,
        new_phone: newPhone || null,
        email: email || null,
        website: website || null,
        research_notes: notes || null,
        research_status: 'completed',
        research_completed_at: new Date().toISOString(),
      })
      .eq('id', activeLead.id);

    if (error) throw error;
  };

  const routeLead = async (route: 'dialer' | 'email' | 'credit_fix' | 'do_not_work') => {
    if (!activeLead) return;

    const { error } = await supabase
      .from('leads')
      .update({
        import_bucket: route,
        route: route,
        ai_recommended_path: route === 'credit_fix' ? 'credit_fix_first' : 
                           route === 'do_not_work' ? 'do_not_work' : 'funding_first',
      })
      .eq('id', activeLead.id);

    if (error) throw error;
  };

  const logActivity = async (type: string, meta: Record<string, any> = {}) => {
    if (!activeLead) return;
    try {
      await savePuzzleFile({
        artifacts: [
          {
            type,
            subject: type.replace(/_/g, " "),
            body_json: meta,
            meta: {
              source_action: "research_center_v10.log_activity",
              generated_at: new Date().toISOString(),
            },
          },
        ],
        refreshPuzzle: true,
      });
    } catch (e) {
      console.warn("[ResearchCenterV10] logActivity failed (non-blocking)");
    }
  };

  // Button handlers
  const handleSendToDialer = async () => {
    try {
      if (!activeLead?.id) return;
      if (!userId) {
        toast({ variant: "destructive", title: "Authentication required" });
        return;
      }

      const canonical = await fetchPuzzleCanonical();
      const canonicalPhone = (canonical?.phone_primary || "").trim();
      const candidatePhone = (phone || newPhone || canonicalPhone || "").trim();
      const normalized = candidatePhone.replace(/[^0-9+]/g, "");
      if (!normalized || normalized.replace(/\D/g, "").length < 10) {
        // Persist failure (reload-safe) and show exact UX
        await savePuzzleFile({
          canonicalUpdates: {
            phone_primary: phone || newPhone || null,
            email_primary: email || null,
            website: website || null,
          },
          artifacts: [
            {
              type: "dialer_send_failed",
              subject: "Dialer send failed",
              body_json: {
                reason: "no_valid_phone",
                message: "No valid phone on file",
                code: null,
                details: null,
                hint: null,
                payload: {
                  phone,
                  newPhone,
                  canonical_phone_primary: canonical?.phone_primary ?? null,
                },
                userId,
                intakeClientId: canonical?.id ?? puzzleFile?.intakeClientId ?? null,
              },
              meta: {
                source_action: "research_center_v10.save_send_dialer",
                generated_at: new Date().toISOString(),
              },
            },
          ],
          refreshPuzzle: true,
        });
        toast({ variant: "destructive", title: "No valid phone on file" });
        return;
      }

      // Ensure Puzzle file exists + canonical facts are saved (fill blanks only)
      const file = await savePuzzleFile({
        canonicalUpdates: {
          full_name:
            activeLead.owner_full_name ||
            (activeLead.owner_first_name && activeLead.owner_last_name
              ? `${activeLead.owner_first_name} ${activeLead.owner_last_name}`
              : activeLead.owner_name || null),
          business_name: activeLead.business_name || null,
          phone_primary: normalized,
          email_primary: email || null,
          website: website || null,
        },
        refreshPuzzle: true,
      });

      await saveLeadEdits();
      await routeLead('dialer');

      // Create a concrete dialer follow-up task keyed to intake_client_id (Puzzle Tasks tab reads this).
      const dueAt = new Date(Date.now() + 15 * 60 * 1000).toISOString();
      let taskErr: any = null;
      try {
        const res = await supabase.from("outreach_tasks").insert({
          intake_client_id: file.intakeClientId,
          lead_id: activeLead.id,
          assigned_to_user_id: userId,
          task_type: "dialer_call",
          title: "Call lead (Dialer)",
          status: "pending",
          due_at: dueAt,
          meta: {
            source_action: "research_center_v10.save_send_dialer",
            phone: normalized,
          },
        });
        taskErr = res.error ?? null;
      } catch (e: any) {
        taskErr = e;
      }

      if (taskErr) {
        await savePuzzleFile({
          artifacts: [
            {
              type: "dialer_send_failed",
              subject: "Dialer send failed",
              body_json: {
                reason: "outreach_tasks_insert_failed",
                message: taskErr?.message ?? String(taskErr),
                code: taskErr?.code ?? null,
                details: taskErr?.details ?? null,
                hint: taskErr?.hint ?? null,
                payload: {
                  lead_id: activeLead.id,
                  intake_client_id: file.intakeClientId,
                  assigned_to_user_id: userId,
                  task_type: "dialer_call",
                  status: "pending",
                  due_at: dueAt,
                },
                userId,
                intakeClientId: file.intakeClientId,
              },
              meta: {
                source_action: "research_center_v10.save_send_dialer",
                generated_at: new Date().toISOString(),
              },
            },
          ],
          refreshPuzzle: true,
        });
        throw taskErr;
      }

      await logActivity("research_routed_dialer", { phone: normalized, intake_client_id: file.intakeClientId });
      toast({ title: "Lead sent to Dialer", description: "Task created in Puzzle → Tasks." });
      await loadStatsAndLead();
    } catch (e: any) {
      console.error("[ResearchCenterV10] send to dialer failed:", e);
      try {
        const canonical = await fetchPuzzleCanonical();
        await savePuzzleFile({
          canonicalUpdates: {
            phone_primary: phone || newPhone || null,
            email_primary: email || null,
            website: website || null,
          },
          artifacts: [
            {
              type: "dialer_send_failed",
              subject: "Dialer send failed",
              body_json: {
                message: e?.message ?? String(e),
                code: e?.code ?? null,
                details: e?.details ?? null,
                hint: e?.hint ?? null,
                stack: e?.stack ?? null,
                payload: {
                  phone,
                  newPhone,
                  canonical_phone_primary: canonical?.phone_primary ?? null,
                  email,
                  website,
                },
                userId,
                intakeClientId: canonical?.id ?? puzzleFile?.intakeClientId ?? null,
              },
              meta: {
                source_action: "research_center_v10.save_send_dialer",
                generated_at: new Date().toISOString(),
              },
            },
          ],
          refreshPuzzle: true,
        });
      } catch {
        // Non-blocking: do not swallow the user-visible error
      }
      toast({ variant: "destructive", title: "Failed to send to Dialer", description: e?.message || "Unknown error" });
    }
  };

  const handleSendToEmail = async () => {
    if (!email.trim()) {
      toast({ variant: 'destructive', title: 'Email is required to send to Smart Emailer' });
      return;
    }
    try {
      if (!activeLead?.id) return;
      await saveLeadEdits();
      await savePuzzleFile({
        canonicalUpdates: {
          full_name:
            activeLead.owner_full_name ||
            (activeLead.owner_first_name && activeLead.owner_last_name
              ? `${activeLead.owner_first_name} ${activeLead.owner_last_name}`
              : activeLead.owner_name || null),
          business_name: activeLead.business_name || null,
          phone_primary: phone || newPhone || null,
          email_primary: email || null,
          website: website || null,
        },
        artifacts: [
          {
            type: "research_prepared_email_send",
            subject: "Prepared Email Send",
            body_json: { email },
            meta: { source_action: "research_center_v10.save_send_email", generated_at: new Date().toISOString() },
          },
        ],
        refreshPuzzle: true,
      });
      // Ensure modal starts with the latest form values (SendInfoModal reads from `lead` prop).
      setActiveLead(prev => prev ? { ...prev, phone: phone || null, new_phone: newPhone || null, email: email || null } : prev);
      setSendChannel('email');
      setShowSendModal(true);
    } catch {
      toast({ variant: 'destructive', title: 'Failed to prepare email send' });
    }
  };

  const handleSendModalSuccess = async () => {
    try {
      if (sendChannel === 'email') {
        await routeLead('email');
        await logActivity('research_routed_email', { email });
        toast({ title: 'Lead sent to Smart Emailer' });
      } else {
        // SMS outreach implies dialer follow-up; route to Dialer so it exits research queue.
        await routeLead('dialer');
        await logActivity('research_sent_sms', { phone: phone || newPhone || null });
        toast({ title: 'SMS sent (lead routed to Dialer for follow-up)' });
      }
      setShowSendModal(false);
      await loadStatsAndLead();
    } catch {
      toast({ variant: 'destructive', title: 'Failed to update lead after email' });
    }
  };

  const handleSendToCreditFix = async () => {
    try {
      if (!activeLead?.id) return;
      await saveLeadEdits();
      await savePuzzleFile({
        canonicalUpdates: {
          full_name:
            activeLead.owner_full_name ||
            (activeLead.owner_first_name && activeLead.owner_last_name
              ? `${activeLead.owner_first_name} ${activeLead.owner_last_name}`
              : activeLead.owner_name || null),
          business_name: activeLead.business_name || null,
          phone_primary: phone || newPhone || null,
          email_primary: email || null,
          website: website || null,
        },
        artifacts: [
          {
            type: "research_prepared_credit_fix_send",
            subject: "Prepared Credit Fix Send",
            body_json: {},
            meta: { source_action: "research_center_v10.save_send_credit_fix", generated_at: new Date().toISOString() },
          },
        ],
      });
      await routeLead('credit_fix');
      await logActivity('research_routed_credit_fix', {});
      toast({ title: 'Lead sent to Credit Fix queue' });
      await loadStatsAndLead();
    } catch {
      toast({ variant: 'destructive', title: 'Failed to send to Credit Fix' });
    }
  };

  const handleCannotFind = async () => {
    if (!notes.trim()) {
      toast({ variant: 'destructive', title: 'Please add a note before marking Cannot Find Info' });
      return;
    }
    try {
      await saveLeadEdits();
      await routeLead('do_not_work');
      await logActivity('research_cannot_find_info', {});
      toast({ title: 'Lead marked as Do Not Work' });
      await loadStatsAndLead();
    } catch {
      toast({ variant: 'destructive', title: 'Failed to update lead' });
    }
  };

  const handleSkip = async () => {
    if (!activeLead?.id) return;
    
    try {
      // Mark current lead as 'skipped' so it moves to end of queue
      await supabase
        .from('leads')
        .update({ 
          research_status: 'skipped',
          updated_at: new Date().toISOString()
        })
        .eq('id', activeLead.id);
      
      await logActivity('research_skipped', { lead_id: activeLead.id });
      toast({ title: 'Lead skipped', description: 'Loading next lead...' });
      await loadStatsAndLead();
    } catch (e) {
      console.error('[ResearchCenterV10] Skip error:', e);
      toast({ variant: 'destructive', title: 'Failed to skip lead' });
    }
  };

  return (
    <div className="space-y-4">
      {bootError && (
        <Card className="p-3 border border-red-200 bg-red-50">
          <div className="flex items-start gap-2 text-xs text-red-700">
            <AlertCircle className="h-4 w-4 mt-0.5" />
            <div>Research Center degraded: {bootError}</div>
          </div>
        </Card>
      )}
      {/* RC-004: File Banner */}
      {selectedListId !== 'all' && currentListLabel !== 'All Lists' && (
        <div className="bg-gradient-to-r from-slate-900 to-slate-800 text-white px-4 py-2.5 rounded-lg flex items-center justify-between">
          <div className="flex items-center gap-2">
            <FileText className="h-4 w-4 text-emerald-400" />
            <span className="text-sm font-medium">Working File:</span>
            <span className="text-sm text-emerald-300">{currentListLabel}</span>
          </div>
          <Badge className="bg-white/10 text-white text-[10px]">
            {stats.in_research} leads remaining
          </Badge>
        </div>
      )}

      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="text-lg font-semibold text-foreground">Research Center V10</h2>
          <p className="text-xs text-muted-foreground">
            Fix incomplete leads and route them to Dialer, Email, or Credit Fix.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <Select value={selectedListId} onValueChange={setSelectedListId}>
            <SelectTrigger className="w-[200px] h-9">
              <SelectValue placeholder="Select list" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Lists</SelectItem>
              {lists.map(l => (
                <SelectItem key={l.id} value={l.id}>{l.name}</SelectItem>
              ))}
            </SelectContent>
          </Select>

          {/* Stats */}
          <div className="flex flex-wrap gap-1.5">
            <Badge variant="secondary" className="text-[10px]">
              In Research: {stats.in_research}
            </Badge>
            <Badge className="bg-emerald-100 text-emerald-800 text-[10px]">
              Fixed Today: {stats.fixed_today}
            </Badge>
            <Badge className="bg-sky-100 text-sky-800 text-[10px]">
              → Dialer: {stats.routed_dialer}
            </Badge>
            <Badge className="bg-indigo-100 text-indigo-800 text-[10px]">
              → Email: {stats.routed_email}
            </Badge>
          </div>
        </div>
      </div>

      {/* RC-003: Sticky Action Bar */}
      {activeLead && (
        <div className="sticky top-0 z-20 bg-background/95 backdrop-blur-sm border-b border-border pb-3 -mx-4 px-4 pt-2">
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-xs font-medium text-muted-foreground mr-2">Quick Actions:</span>
            <Button 
              size="sm" 
              onClick={handleSendToDialer}
              className="bg-emerald-500 hover:bg-emerald-600 text-white text-xs h-8"
            >
              <Phone className="h-3 w-3 mr-1" />
              Pass to Dialer
            </Button>
            <Button 
              size="sm" 
              onClick={handleSendToEmail}
              className="bg-sky-600 hover:bg-sky-700 text-white text-xs h-8"
            >
              <Mail className="h-3 w-3 mr-1" />
              Pass to Email
            </Button>
            <Button 
              size="sm" 
              onClick={async () => {
                if (!phone.trim() && !newPhone.trim()) {
                  toast({ variant: 'destructive', title: 'Phone is required to send SMS' });
                  return;
                }
                try {
                  await saveLeadEdits();
                  setActiveLead(prev => prev ? { ...prev, phone: phone || null, new_phone: newPhone || null, email: email || null } : prev);
                  setSendChannel('sms');
                  setShowSendModal(true);
                } catch {
                  toast({ variant: 'destructive', title: 'Failed to prepare SMS send' });
                }
              }}
              className="bg-violet-600 hover:bg-violet-700 text-white text-xs h-8"
            >
              💬 Send SMS
            </Button>
            <Button 
              size="sm" 
              onClick={handleSendToCreditFix}
              className="bg-indigo-600 hover:bg-indigo-700 text-white text-xs h-8"
            >
              <ArrowRight className="h-3 w-3 mr-1" />
              Send to Credit Fix
            </Button>
            <Button 
              size="sm" 
              onClick={handleCannotFind}
              variant="outline"
              className="text-xs h-8 text-red-600 border-red-200 hover:bg-red-50"
            >
              <XCircle className="h-3 w-3 mr-1" />
              Archive Lead
            </Button>
            <div className="ml-auto">
              <Button variant="ghost" size="sm" onClick={handleSkip} className="text-xs h-8 text-muted-foreground">
                <SkipForward className="h-3 w-3 mr-1" />
                Skip
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* Main content */}
      {loadingLead && !activeLead ? (
        <Card className="p-6">
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <Loader2 className="h-4 w-4 animate-spin" />
            Loading research lead...
          </div>
        </Card>
      ) : !activeLead ? (
        <Card className="p-8 text-center border-dashed">
          <Search className="h-10 w-10 mx-auto text-muted-foreground/50 mb-3" />
          <p className="text-sm text-muted-foreground">
            No more research leads in this list.
          </p>
          <p className="text-xs text-muted-foreground mt-1">
            Switch lists or upload a new file to keep going.
          </p>
        </Card>
      ) : (
        <>
          <div className="grid gap-4 lg:grid-cols-[2fr_1.5fr]">
            {/* LEFT: Lead form */}
            <Card className="p-4">
              <div className="mb-4">
                <p className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">
                  Research Lead
                </p>
                <h3 className="text-sm font-semibold text-foreground flex items-center gap-1.5">
                  <Building2 className="h-3.5 w-3.5" />
                  {activeLead.business_name || 'Unknown Business'}
                </h3>
                {(activeLead.owner_first_name || activeLead.owner_last_name || activeLead.owner_name || activeLead.owner_full_name) && (
                  <p className="text-xs text-muted-foreground flex items-center gap-1">
                    <User className="h-3 w-3" />
                    {activeLead.owner_first_name && activeLead.owner_last_name 
                      ? `${activeLead.owner_first_name} ${activeLead.owner_last_name}`
                      : activeLead.owner_name || activeLead.owner_full_name}
                  </p>
                )}
              </div>

              {/* Badges */}
              <div className="flex flex-wrap gap-1.5 mb-4">
                {!activeLead.phone && (
                  <Badge variant="outline" className="bg-amber-50 text-amber-700 border-amber-200 text-[10px]">
                    Missing Phone
                  </Badge>
                )}
                {!activeLead.email && (
                  <Badge variant="outline" className="bg-amber-50 text-amber-700 border-amber-200 text-[10px]">
                    Missing Email
                  </Badge>
                )}
                {activeLead.ai_score != null && (
                  <Badge className="bg-slate-900 text-white text-[10px]">
                    AI Score: {activeLead.ai_score}
                  </Badge>
                )}
                {activeLead.funding_score != null && (
                  <Badge className="bg-emerald-100 text-emerald-800 text-[10px]">
                    Funding: {activeLead.funding_score}
                  </Badge>
                )}
              </div>

              {isDebugEnabled() && (
                <div className="mb-4 rounded-lg border border-slate-200 bg-slate-50 p-3">
                  <div className="flex items-center justify-between gap-2">
                    <div>
                      <div className="text-xs font-semibold text-slate-700">Debug: canonical Puzzle file (`intake_clients`)</div>
                      <div className="text-[11px] text-slate-500">Read-only dump for the active lead.</div>
                    </div>
                    <Button
                      size="sm"
                      variant="outline"
                      className="h-8 text-xs"
                      onClick={async () => {
                        const canonical = await fetchPuzzleCanonical();
                        setCanonicalDebug(canonical);
                      }}
                    >
                      Refresh
                    </Button>
                  </div>
                  <div className="mt-2">
                    {canonicalDebug ? (
                      <pre className="max-h-56 overflow-auto rounded bg-white p-2 text-[10px] text-slate-700 border border-slate-200">
                        {JSON.stringify(canonicalDebug, null, 2)}
                      </pre>
                    ) : (
                      <div className="text-[11px] text-slate-500">Click “Refresh” to load canonical fields.</div>
                    )}
                  </div>
                </div>
              )}

              {/* Form fields */}
              <div className="space-y-3">
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="text-[11px] font-medium text-muted-foreground">Original Phone</label>
                    <Input
                      value={phone}
                      onChange={e => setPhone(e.target.value)}
                      placeholder="Original phone"
                      className="mt-1 h-9 text-sm"
                    />
                  </div>
                  <div>
                    <label className="text-[11px] font-medium text-emerald-600">New Phone (AI Found)</label>
                    <Input
                      value={newPhone}
                      onChange={e => setNewPhone(e.target.value)}
                      placeholder="AI discovered phone"
                      className="mt-1 h-9 text-sm border-emerald-200 focus:border-emerald-400"
                    />
                  </div>
                </div>
                <div>
                  <label className="text-[11px] font-medium text-muted-foreground">Email</label>
                  <Input
                    value={email}
                    onChange={e => setEmail(e.target.value)}
                    placeholder="Enter email"
                    className="mt-1 h-9 text-sm"
                  />
                </div>
                <div>
                  <label className="text-[11px] font-medium text-muted-foreground">Website</label>
                  <Input
                    value={website}
                    onChange={e => setWebsite(e.target.value)}
                    placeholder="Enter website"
                    className="mt-1 h-9 text-sm"
                  />
                </div>
                <div>
                  <label className="text-[11px] font-medium text-muted-foreground">Research Notes</label>
                  <Textarea
                    value={notes}
                    onChange={e => setNotes(e.target.value)}
                    placeholder="Add notes about your research, findings, and next steps..."
                    rows={10}
                    className="mt-1 text-sm min-h-[200px] resize-y"
                  />
                </div>
              </div>

              {/* Quick links */}
              <div className="flex flex-wrap gap-2 mt-4">
                <Button variant="outline" size="sm" onClick={() => setShowWorkspace(true)} className="text-xs">
                  📋 View Full Profile
                </Button>
                {activeLead.business_name && (
                  <>
                    <a
                      href={`https://www.google.com/search?q=${encodeURIComponent(activeLead.business_name)}`}
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      <Button variant="outline" size="sm" className="text-xs">
                        <ExternalLink className="h-3 w-3 mr-1" />
                        Google
                      </Button>
                    </a>
                    <a
                      href={`https://www.linkedin.com/search/results/companies/?keywords=${encodeURIComponent(activeLead.business_name)}`}
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      <Button variant="outline" size="sm" className="text-xs">
                        <ExternalLink className="h-3 w-3 mr-1" />
                        LinkedIn
                      </Button>
                    </a>
                  </>
                )}
              </div>
            </Card>

            {/* RIGHT: AI Copilot */}
            <Card className="p-4 bg-sky-50/50 border-sky-100">
              <div className="mb-3">
                <p className="text-[10px] font-semibold uppercase tracking-wide text-sky-700">
                  Research Copilot
                </p>
                <p className="text-[11px] text-sky-600">
                  AI assistant for contact discovery, validation & routing.
                </p>
              </div>

              {/* Copilot buttons - Row 1 */}
              <div className="flex flex-wrap gap-2 mb-2">
                <Button
                  size="sm"
                  onClick={handleRunSpider}
                  disabled={!!copilotLoading}
                  className="bg-emerald-500 hover:bg-emerald-600 text-white text-xs"
                >
                  {copilotLoading === 'spider' ? <Loader2 className="h-3 w-3 animate-spin mr-1" /> : <Zap className="h-3 w-3 mr-1" />}
                  AI Research Spider
                </Button>
                <Button
                  size="sm"
                  onClick={handleSuggestContact}
                  disabled={!!copilotLoading}
                  className="bg-sky-600 hover:bg-sky-700 text-white text-xs"
                >
                  {copilotLoading === 'suggest' ? <Loader2 className="h-3 w-3 animate-spin mr-1" /> : <Lightbulb className="h-3 w-3 mr-1" />}
                  Suggest Contact
                </Button>
                <Button
                  size="sm"
                  onClick={handleRecommendRoute}
                  disabled={!!copilotLoading}
                  className="bg-slate-900 hover:bg-black text-white text-xs"
                >
                  {copilotLoading === 'route' ? <Loader2 className="h-3 w-3 animate-spin mr-1" /> : <Compass className="h-3 w-3 mr-1" />}
                  Recommend Route
                </Button>
              </div>

              {/* Copilot buttons - Row 2: Public Records */}
              <div className="flex flex-wrap gap-2 mb-3">
                <Button
                  size="sm"
                  onClick={handlePublicRecordsScan}
                  disabled={!!copilotLoading}
                  className="bg-amber-500 hover:bg-amber-600 text-white text-xs"
                >
                  {copilotLoading === 'public' ? <Loader2 className="h-3 w-3 animate-spin mr-1" /> : <Search className="h-3 w-3 mr-1" />}
                  🔍 Liens / Tax / Bankruptcy / Courts
                </Button>
              </div>

              {/* Copilot feed */}
              <ScrollArea className="h-[320px] rounded-lg bg-white p-3 shadow-inner">
                {copilotMessages.length === 0 ? (
                  <p className="text-xs text-muted-foreground">
                    Click an action above and I'll drop my findings here.
                  </p>
                ) : (
                  <div className="space-y-2">
                    {copilotMessages.map(m => (
                      <div
                        key={m.id}
                        className={`rounded-lg px-3 py-2 text-xs ${
                          m.role === 'ai' ? 'bg-sky-50 text-sky-900' :
                          m.role === 'system' ? 'bg-slate-100 text-slate-700' :
                          'bg-emerald-50 text-emerald-900'
                        }`}
                      >
                        <div className="text-[10px] font-semibold uppercase tracking-wide opacity-70 mb-1">
                          {m.role === 'ai' ? 'AI' : m.role === 'system' ? 'System' : 'You'}
                        </div>
                        <pre className="whitespace-pre-wrap font-sans text-[12px] leading-relaxed">{m.text}</pre>
                      </div>
                    ))}
                  </div>
                )}
              </ScrollArea>

              {/* AI Summary Button */}
              <div className="mt-3 pt-3 border-t border-sky-200">
                <Button
                  onClick={handleGenerateSummary}
                  disabled={!!copilotLoading}
                  className="w-full bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-white"
                >
                  {copilotLoading === 'summary' ? (
                    <Loader2 className="h-4 w-4 animate-spin mr-2" />
                  ) : (
                    <FileText className="h-4 w-4 mr-2" />
                  )}
                  📋 AI Summary - Full Profile Report
                </Button>
              </div>
            </Card>
          </div>

          {/* Bottom routing buttons */}
          <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-4">
            <Button onClick={handleSendToDialer} className="bg-emerald-500 hover:bg-emerald-600 text-white">
              <Phone className="h-4 w-4 mr-1.5" />
              Save & Send to Dialer
            </Button>
            <Button onClick={handleSendToEmail} className="bg-sky-600 hover:bg-sky-700 text-white">
              <Mail className="h-4 w-4 mr-1.5" />
              Save & Send to Email
            </Button>
            <Button onClick={handleSendToCreditFix} className="bg-indigo-600 hover:bg-indigo-700 text-white">
              <ArrowRight className="h-4 w-4 mr-1.5" />
              Save & Send to Credit Fix
            </Button>
            <Button onClick={handleCannotFind} variant="secondary">
              <XCircle className="h-4 w-4 mr-1.5" />
              Cannot Find Info
            </Button>
          </div>
        </>
      )}

      {/* Send Info Modal */}
      {activeLead && userId && (
        <SendInfoModal
          open={showSendModal}
          onOpenChange={setShowSendModal}
          lead={{
            ...activeLead,
            phone: phone || newPhone || activeLead.phone,
            new_phone: newPhone || activeLead.new_phone,
            email: email || activeLead.email,
          }}
          workerId={userId}
          clientId={puzzleFile?.intakeClientId}
          productLine="mca"
          onSuccess={handleSendModalSuccess}
        />
      )}

      {/* Client Workspace */}
      {activeLead && userId && (
        <ClientWorkspaceDrawer
          open={showWorkspace}
          onOpenChange={setShowWorkspace}
          lead={activeLead}
          workerId={userId}
        />
      )}

      {/* AI Summary Full-Page Report - with print-area for branded printing */}
      <Dialog open={showSummary} onOpenChange={setShowSummary}>
        <DialogContent id="exec-summary-print" className="max-w-4xl h-[85vh] flex flex-col print-area">
          {/* Branded Header */}
          <DialogHeader className="border-b pb-4 flex-shrink-0 print-header">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-xs font-semibold uppercase tracking-[0.2em] text-amber-500">
                  Wolf Fund
                </div>
                <DialogTitle className="text-xl font-bold flex items-center gap-2 mt-1">
                  <FileText className="h-5 w-5 text-indigo-600 print:hidden" />
                  Executive Intelligence Summary
                </DialogTitle>
              </div>
              <div className="text-right text-xs text-muted-foreground print:text-slate-600">
                <div>Generated: {new Date().toLocaleDateString()}</div>
                <div>Ref: {activeLead?.id?.slice(0, 8) || 'N/A'}</div>
              </div>
            </div>
            <p className="text-sm text-muted-foreground mt-1">
              {activeLead?.business_name || 'Unknown Business'}
            </p>
          </DialogHeader>
          
          <ScrollArea className="flex-1 min-h-0">
            <div className="py-4">
              {copilotLoading === 'summary' ? (
                <div className="flex flex-col items-center justify-center h-64 gap-4">
                  <Loader2 className="h-10 w-10 animate-spin text-indigo-600" />
                  <p className="text-sm text-muted-foreground">Generating executive summary...</p>
                  <p className="text-xs text-muted-foreground">Analyzing lead data and risk factors</p>
                </div>
              ) : summaryView ? (
                <div className="bg-gradient-to-br from-slate-50 to-indigo-50/50 rounded-xl p-6 border border-slate-200 print:bg-white print:border-0 print:p-0 space-y-5">
                  
                  {/* SECTION 1: Plain Text Executive Summary */}
                  <div className="p-4 bg-white rounded-lg border border-slate-200 shadow-sm">
                    <h2 className="text-sm font-bold text-slate-800 uppercase tracking-wide mb-3 flex items-center gap-2">
                      📋 Executive Summary
                    </h2>
                    <div className="text-sm text-slate-700 space-y-2">
                      <p><strong>Client:</strong> {(summaryView.summary?.client_name || activeLead?.owner_name || 'Unknown')} — {(summaryView.summary?.business_name || activeLead?.business_name || 'Unknown Business')}</p>
                      <p><strong>Funding Path:</strong> <span className={`font-semibold ${summaryView.summary?.funding_path === 'funding_first' ? 'text-emerald-600' : summaryView.summary?.funding_path === 'credit_first' ? 'text-indigo-600' : summaryView.summary?.funding_path === 'hybrid' ? 'text-amber-600' : 'text-red-600'}`}>
                        {summaryView.summary?.funding_path?.replace(/_/g, ' ')?.toUpperCase() || 'NOT DETERMINED'}
                      </span></p>
                      <p><strong>Funding Score:</strong> {summaryView.summary?.funding_score ?? 'N/A'} / 100 | <strong>Priority:</strong> {summaryView.summary?.priority_band || 'C'}</p>
                      <p><strong>Status:</strong> {summaryView.summary?.snapshot?.status || 'Nurture'}</p>
                      {summaryView.summary?.snapshot?.one_liner && (
                        <p className="italic text-slate-600 mt-2">"{summaryView.summary.snapshot.one_liner}"</p>
                      )}
                      
                      {/* Risk Summary */}
                      {safeArray(summaryView.summary?.risk_flags).length > 0 && (
                        <div className="mt-3 pt-3 border-t border-slate-100">
                          <p className="font-semibold text-red-700 mb-1">⚠️ Risk Factors:</p>
                          <ul className="list-disc list-inside text-xs text-red-600 space-y-0.5">
                            {safeArray(summaryView.summary?.risk_flags).slice(0, 4).map((flag, i) => (
                              <li key={i}>{flag}</li>
                            ))}
                          </ul>
                        </div>
                      )}
                      
                      {/* Next Steps Summary */}
                      {safeArray(summaryView.summary?.recommended_next_steps).length > 0 && (
                        <div className="mt-3 pt-3 border-t border-slate-100">
                          <p className="font-semibold text-sky-700 mb-1">✅ Next Steps:</p>
                          <ol className="list-decimal list-inside text-xs text-sky-600 space-y-0.5">
                            {safeArray(summaryView.summary?.recommended_next_steps).slice(0, 3).map((step, i) => (
                              <li key={i}>{step}</li>
                            ))}
                          </ol>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* SECTION 2: Visual Blocks */}
                  {/* Header with Snapshot */}
                  <div className="text-center pb-4 border-b border-slate-200">
                    <h1 className="text-2xl font-bold text-slate-800 mb-1">
                      {summaryView.summary?.business_name || activeLead?.business_name || 'Business Profile'}
                    </h1>
                    <p className="text-sm text-slate-500 mb-2">
                      {summaryView.summary?.client_name || activeLead?.owner_name || 'Owner Not Available'}
                    </p>
                    <div className="flex flex-wrap justify-center gap-2 mt-2">
                      {summaryView.summary?.funding_score && (
                        <Badge className="bg-emerald-600 text-white">Funding Score: {summaryView.summary.funding_score}</Badge>
                      )}
                      {summaryView.summary?.priority_band && (
                        <Badge className={`${summaryView.summary.priority_band === 'A' ? 'bg-green-600' : summaryView.summary.priority_band === 'B' ? 'bg-blue-600' : summaryView.summary.priority_band === 'C' ? 'bg-amber-600' : 'bg-red-600'} text-white`}>
                          Priority: {summaryView.summary.priority_band}
                        </Badge>
                      )}
                      {summaryView.summary?.snapshot?.status && (
                        <Badge className={`${summaryView.summary.snapshot.status === 'Work Now' ? 'bg-emerald-100 text-emerald-800' : summaryView.summary.snapshot.status === 'Nurture' ? 'bg-amber-100 text-amber-800' : 'bg-red-100 text-red-800'}`}>
                          {summaryView.summary.snapshot.status}
                        </Badge>
                      )}
                    </div>
                    {summaryView.summary?.snapshot?.one_liner && (
                      <p className="text-sm text-slate-600 mt-3 italic">"{summaryView.summary.snapshot.one_liner}"</p>
                    )}
                  </div>

                  {/* Contact Profile */}
                  {summaryView && (
                    <div className="grid grid-cols-2 gap-4 p-4 bg-slate-50 rounded-lg">
                      <div>
                        <p className="text-xs font-semibold text-slate-500 uppercase mb-1">Primary Phone</p>
                        <p className="text-sm font-medium">{summaryView.display.primary_phone}</p>
                      </div>
                      <div>
                        <p className="text-xs font-semibold text-slate-500 uppercase mb-1">Primary Email</p>
                        <p className="text-sm font-medium">{summaryView.display.primary_email}</p>
                      </div>
                      <div>
                        <p className="text-xs font-semibold text-slate-500 uppercase mb-1">Location</p>
                        <p className="text-sm">{summaryView.summary?.contact_profile?.location || 'Unknown'}</p>
                      </div>
                      <div>
                        <p className="text-xs font-semibold text-slate-500 uppercase mb-1">Best Channel</p>
                        <Badge variant="outline" className="capitalize">{summaryView.summary?.contact_profile?.best_channel || 'none'}</Badge>
                      </div>
                    </div>
                  )}

                  {/* Funding Intel */}
                  {summaryView.summary?.funding_intel && (
                    <div className="p-4 bg-emerald-50/50 rounded-lg border border-emerald-100">
                      <h3 className="text-sm font-bold text-emerald-800 mb-3 flex items-center gap-2">
                        💰 Funding Intelligence
                      </h3>
                      <div className="grid grid-cols-3 gap-3 text-center mb-3">
                        <div className="bg-white p-2 rounded">
                          <p className="text-[10px] text-slate-500 uppercase">Monthly Revenue</p>
                          <p className="text-sm font-bold">{
                            typeof summaryView.summary.funding_intel.estimated_monthly_revenue === 'number'
                              ? `$${summaryView.summary.funding_intel.estimated_monthly_revenue.toLocaleString()}`
                              : 'Unknown'
                          }</p>
                        </div>
                        <div className="bg-white p-2 rounded">
                          <p className="text-[10px] text-slate-500 uppercase">Business Age</p>
                          <p className="text-sm font-bold">{summaryView.display.years_in_business !== "Unknown" ? `${summaryView.display.years_in_business} yrs` : 'Unknown'}</p>
                        </div>
                        <div className="bg-white p-2 rounded">
                          <p className="text-[10px] text-slate-500 uppercase">Industry Risk</p>
                          <Badge className={`${summaryView.summary.funding_intel.industry_risk === 'low' ? 'bg-green-100 text-green-800' : summaryView.summary.funding_intel.industry_risk === 'high' ? 'bg-red-100 text-red-800' : 'bg-amber-100 text-amber-800'}`}>
                            {summaryView.summary.funding_intel.industry_risk || 'Medium'}
                          </Badge>
                        </div>
                      </div>
                      {safeArray(summaryView.summary?.funding_intel?.notes).length > 0 && (
                        <ul className="text-xs text-slate-600 space-y-1">
                          {safeArray(summaryView.summary?.funding_intel?.notes).map((note, i) => (
                            <li key={i} className="flex items-start gap-1">• {note}</li>
                          ))}
                        </ul>
                      )}
                    </div>
                  )}

                  {/* Credit & Identity Intel */}
                  {summaryView.summary?.credit_identity_intel && (
                    <div className="p-4 bg-indigo-50/50 rounded-lg border border-indigo-100">
                      <h3 className="text-sm font-bold text-indigo-800 mb-3 flex items-center gap-2">
                        🛡️ Credit & Identity
                      </h3>
                      <div className="grid grid-cols-3 gap-3 text-center mb-3">
                        <div className="bg-white p-2 rounded">
                          <p className="text-[10px] text-slate-500 uppercase">Credit Risk</p>
                          <Badge className={`${summaryView.summary.credit_identity_intel.credit_risk === 'low' ? 'bg-green-100 text-green-800' : summaryView.summary.credit_identity_intel.credit_risk === 'high' ? 'bg-red-100 text-red-800' : 'bg-amber-100 text-amber-800'}`}>
                            {summaryView.summary.credit_identity_intel.credit_risk || 'Medium'}
                          </Badge>
                        </div>
                        <div className="bg-white p-2 rounded">
                          <p className="text-[10px] text-slate-500 uppercase">ID Theft Risk</p>
                          <Badge className={`${summaryView.summary.credit_identity_intel.identity_theft_risk === 'low' ? 'bg-green-100 text-green-800' : summaryView.summary.credit_identity_intel.identity_theft_risk === 'high' ? 'bg-red-100 text-red-800' : 'bg-amber-100 text-amber-800'}`}>
                            {summaryView.summary.credit_identity_intel.identity_theft_risk || 'Low'}
                          </Badge>
                        </div>
                        <div className="bg-white p-2 rounded">
                          <p className="text-[10px] text-slate-500 uppercase">Credit Fix?</p>
                          <Badge className={summaryView.summary.credit_identity_intel.credit_fix_recommended ? 'bg-amber-100 text-amber-800' : 'bg-green-100 text-green-800'}>
                            {summaryView.summary.credit_identity_intel.credit_fix_recommended ? 'Yes' : 'No'}
                          </Badge>
                        </div>
                      </div>
                      {safeArray(summaryView.summary?.credit_identity_intel?.notes).length > 0 && (
                        <ul className="text-xs text-slate-600 space-y-1">
                          {safeArray(summaryView.summary?.credit_identity_intel?.notes).map((note, i) => (
                            <li key={i} className="flex items-start gap-1">• {note}</li>
                          ))}
                        </ul>
                      )}
                    </div>
                  )}

                  {/* PUBLIC RECORDS INTEL - Full Breakdown */}
                  {summaryView.summary?.public_records_intel && (
                    <div className="p-4 bg-orange-50/50 rounded-lg border border-orange-200">
                      <h3 className="text-sm font-bold text-orange-800 mb-3 flex items-center gap-2">
                        🔍 Public Records Intel — Liens / Tax / Bankruptcy / Courts
                        <Badge className={`ml-2 ${
                          summaryView.summary.public_records_intel.overall_risk === 'critical' ? 'bg-red-600 text-white' :
                          summaryView.summary.public_records_intel.overall_risk === 'high' ? 'bg-red-500 text-white' :
                          summaryView.summary.public_records_intel.overall_risk === 'medium' ? 'bg-amber-500 text-white' :
                          'bg-green-500 text-white'
                        }`}>
                          {(summaryView.summary.public_records_intel.overall_risk || 'unknown').toUpperCase()} RISK
                        </Badge>
                      </h3>
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-sm">
                        {/* Liens Section */}
                        <div className="bg-white p-3 rounded border">
                          <p className="text-xs font-semibold text-slate-500 uppercase mb-2 flex items-center gap-1">
                            📋 Liens
                            <Badge className={summaryView.summary.public_records_intel.liens?.has_liens ? 'bg-red-100 text-red-800 ml-1' : 'bg-green-100 text-green-800 ml-1'}>
                              {summaryView.summary.public_records_intel.liens?.has_liens ? `${summaryView.summary.public_records_intel.liens.lien_count || 'Yes'} Found` : 'None'}
                            </Badge>
                          </p>
                          {safeArray(summaryView.summary.public_records_intel.liens?.lien_details).length > 0 ? (
                            <ul className="text-xs text-slate-600 space-y-0.5">
                              {safeArray(summaryView.summary.public_records_intel.liens?.lien_details).map((d, i) => (
                                <li key={i}>• {d}</li>
                              ))}
                            </ul>
                          ) : (
                            <p className="text-xs text-green-600">✓ No liens found</p>
                          )}
                          {summaryView.summary.public_records_intel.liens?.total_lien_amount && (
                            <p className="text-xs font-semibold mt-1 text-red-700">Total: {summaryView.summary.public_records_intel.liens.total_lien_amount}</p>
                          )}
                        </div>
                        
                        {/* Tax Issues Section */}
                        <div className="bg-white p-3 rounded border">
                          <p className="text-xs font-semibold text-slate-500 uppercase mb-2 flex items-center gap-1">
                            💰 Tax Issues
                            <Badge className={summaryView.summary.public_records_intel.tax_issues?.has_tax_liens ? 'bg-red-100 text-red-800 ml-1' : 'bg-green-100 text-green-800 ml-1'}>
                              {summaryView.summary.public_records_intel.tax_issues?.has_tax_liens ? `${summaryView.summary.public_records_intel.tax_issues.tax_lien_count || 'Yes'} Found` : 'None'}
                            </Badge>
                          </p>
                          {safeArray(summaryView.summary.public_records_intel.tax_issues?.tax_details).length > 0 ? (
                            <ul className="text-xs text-slate-600 space-y-0.5">
                              {safeArray(summaryView.summary.public_records_intel.tax_issues?.tax_details).map((d, i) => (
                                <li key={i}>• {d}</li>
                              ))}
                            </ul>
                          ) : (
                            <p className="text-xs text-green-600">✓ No tax issues found</p>
                          )}
                          {(summaryView.summary.public_records_intel.tax_issues?.irs_issues || summaryView.summary.public_records_intel.tax_issues?.state_tax_issues) && (
                            <p className="text-xs font-semibold mt-1 text-red-700">
                              {summaryView.summary.public_records_intel.tax_issues?.irs_issues && '⚠️ IRS Issues '}
                              {summaryView.summary.public_records_intel.tax_issues?.state_tax_issues && '⚠️ State Tax Issues'}
                            </p>
                          )}
                        </div>
                        
                        {/* Bankruptcies Section */}
                        <div className="bg-white p-3 rounded border">
                          <p className="text-xs font-semibold text-slate-500 uppercase mb-2 flex items-center gap-1">
                            📉 Bankruptcies
                            <Badge className={summaryView.summary.public_records_intel.bankruptcies?.has_bankruptcy ? 'bg-red-100 text-red-800 ml-1' : 'bg-green-100 text-green-800 ml-1'}>
                              {summaryView.summary.public_records_intel.bankruptcies?.has_bankruptcy ? summaryView.summary.public_records_intel.bankruptcies.bankruptcy_type || 'Yes' : 'None'}
                            </Badge>
                          </p>
                          {summaryView.summary.public_records_intel.bankruptcies?.has_bankruptcy ? (
                            <div className="text-xs text-slate-600 space-y-1">
                              {summaryView.summary.public_records_intel.bankruptcies.bankruptcy_type && (
                                <p><strong>Type:</strong> {summaryView.summary.public_records_intel.bankruptcies.bankruptcy_type}</p>
                              )}
                              {summaryView.summary.public_records_intel.bankruptcies.bankruptcy_date && (
                                <p><strong>Date:</strong> {summaryView.summary.public_records_intel.bankruptcies.bankruptcy_date}</p>
                              )}
                              {summaryView.summary.public_records_intel.bankruptcies.bankruptcy_status && (
                                <p><strong>Status:</strong> {summaryView.summary.public_records_intel.bankruptcies.bankruptcy_status}</p>
                              )}
                              {safeArray(summaryView.summary.public_records_intel.bankruptcies?.bankruptcy_details).map((d, i) => (
                                <p key={i}>• {d}</p>
                              ))}
                            </div>
                          ) : (
                            <p className="text-xs text-green-600">✓ No bankruptcies found</p>
                          )}
                        </div>
                        
                        {/* Court Records Section */}
                        <div className="bg-white p-3 rounded border">
                          <p className="text-xs font-semibold text-slate-500 uppercase mb-2 flex items-center gap-1">
                            ⚖️ Court Records
                            <Badge className={summaryView.summary.public_records_intel.court_records?.has_court_cases ? 'bg-red-100 text-red-800 ml-1' : 'bg-green-100 text-green-800 ml-1'}>
                              {summaryView.summary.public_records_intel.court_records?.has_court_cases 
                                ? `${(summaryView.summary.public_records_intel.court_records.civil_cases || 0) + (summaryView.summary.public_records_intel.court_records.criminal_cases || 0)} Found` 
                                : 'None'}
                            </Badge>
                          </p>
                          {summaryView.summary.public_records_intel.court_records?.has_court_cases ? (
                            <div className="text-xs text-slate-600 space-y-1">
                              {summaryView.summary.public_records_intel.court_records.civil_cases > 0 && (
                                <p>📋 Civil Cases: {summaryView.summary.public_records_intel.court_records.civil_cases}</p>
                              )}
                              {summaryView.summary.public_records_intel.court_records.criminal_cases > 0 && (
                                <p className="text-red-700">⚠️ Criminal Cases: {summaryView.summary.public_records_intel.court_records.criminal_cases}</p>
                              )}
                              {safeArray(summaryView.summary.public_records_intel.court_records?.court_details).map((d, i) => (
                                <p key={i}>• {d}</p>
                              ))}
                            </div>
                          ) : (
                            <p className="text-xs text-green-600">✓ No court records found</p>
                          )}
                        </div>
                        
                        {/* Judgments Section */}
                        <div className="bg-white p-3 rounded border">
                          <p className="text-xs font-semibold text-slate-500 uppercase mb-2 flex items-center gap-1">
                            🔨 Judgments
                            <Badge className={summaryView.summary.public_records_intel.judgments?.has_judgments ? 'bg-red-100 text-red-800 ml-1' : 'bg-green-100 text-green-800 ml-1'}>
                              {summaryView.summary.public_records_intel.judgments?.has_judgments ? `${summaryView.summary.public_records_intel.judgments.judgment_count || 'Yes'} Found` : 'None'}
                            </Badge>
                          </p>
                          {safeArray(summaryView.summary.public_records_intel.judgments?.judgment_details).length > 0 ? (
                            <ul className="text-xs text-slate-600 space-y-0.5">
                              {safeArray(summaryView.summary.public_records_intel.judgments?.judgment_details).map((d, i) => (
                                <li key={i}>• {d}</li>
                              ))}
                            </ul>
                          ) : (
                            <p className="text-xs text-green-600">✓ No judgments found</p>
                          )}
                          {summaryView.summary.public_records_intel.judgments?.total_judgment_amount && (
                            <p className="text-xs font-semibold mt-1 text-red-700">Total: {summaryView.summary.public_records_intel.judgments.total_judgment_amount}</p>
                          )}
                        </div>
                        
                        {/* UCC Filings Section */}
                        <div className="bg-white p-3 rounded border">
                          <p className="text-xs font-semibold text-slate-500 uppercase mb-2 flex items-center gap-1">
                            📄 UCC Filings
                            <Badge className={summaryView.summary.public_records_intel.ucc_filings?.has_ucc ? 'bg-amber-100 text-amber-800 ml-1' : 'bg-green-100 text-green-800 ml-1'}>
                              {summaryView.summary.public_records_intel.ucc_filings?.has_ucc ? `${summaryView.summary.public_records_intel.ucc_filings.ucc_count || 'Yes'} Found` : 'None'}
                            </Badge>
                          </p>
                          {safeArray(summaryView.summary.public_records_intel.ucc_filings?.ucc_details).length > 0 ? (
                            <ul className="text-xs text-slate-600 space-y-0.5">
                              {safeArray(summaryView.summary.public_records_intel.ucc_filings?.ucc_details).map((d, i) => (
                                <li key={i}>• {d}</li>
                              ))}
                            </ul>
                          ) : (
                            <p className="text-xs text-green-600">✓ No UCC filings found</p>
                          )}
                        </div>
                      </div>
                      
                      {/* Public Records Summary */}
                      {summaryView.summary?.public_records_intel?.summary && (
                        <div className="mt-3 pt-3 border-t border-orange-200">
                          <p className="text-xs text-orange-800 font-medium">{summaryView.summary.public_records_intel.summary}</p>
                        </div>
                      )}
                    </div>
                  )}

                  {/* Quick Summary if available */}
                  {summaryView.summary?.snapshot?.quick_summary && (
                    <div className="p-4 bg-slate-100 rounded-lg border border-slate-200">
                      <h3 className="text-sm font-bold text-slate-800 mb-2">📝 Full Analysis</h3>
                      <p className="text-xs text-slate-700 whitespace-pre-wrap">{summaryView.summary.snapshot.quick_summary}</p>
                    </div>
                  )}

                  {/* Credit Fix Action Items */}
                  {safeArray(summaryView.summary?.credit_fix_action_items).length > 0 && (
                    <div className="p-4 bg-violet-50/50 rounded-lg border border-violet-200">
                      <h3 className="text-sm font-bold text-violet-800 mb-2">🛠️ Credit Fix Action Items</h3>
                      <ul className="text-xs text-violet-700 space-y-1">
                        {safeArray(summaryView.summary?.credit_fix_action_items).map((item, i) => (
                          <li key={i} className="flex items-start gap-1">☐ {item}</li>
                        ))}
                      </ul>
                    </div>
                  )}

                  {/* Missing Info */}
                  {safeArray(summaryView.summary?.missing_info).length > 0 && (
                    <div className="p-4 bg-gray-50 rounded-lg border border-gray-200">
                      <h3 className="text-sm font-bold text-gray-700 mb-2">❓ Missing Information</h3>
                      <ul className="text-xs text-gray-600 space-y-1">
                        {safeArray(summaryView.summary?.missing_info).map((item, i) => (
                          <li key={i}>• {item}</li>
                        ))}
                      </ul>
                    </div>
                  )}

                  {/* OCM Intel (if applicable) */}
                  {summaryView.summary?.ocm_intel?.is_ocm && (
                    <div className="p-4 bg-purple-50/50 rounded-lg border border-purple-100">
                      <h3 className="text-sm font-bold text-purple-800 mb-3 flex items-center gap-2">
                        🏛️ OCM License Intel
                      </h3>
                      <div className="grid grid-cols-2 gap-3 text-sm">
                        <div><span className="text-slate-500">License ID:</span> {summaryView.summary.ocm_intel.license_id || 'N/A'}</div>
                        <div><span className="text-slate-500">Status:</span> <Badge variant="outline">{summaryView.summary.ocm_intel.license_status || 'Unknown'}</Badge></div>
                        <div><span className="text-slate-500">Expiration:</span> {summaryView.summary.ocm_intel.expiration_date || 'N/A'}</div>
                        <div><span className="text-slate-500">Municipality:</span> {summaryView.summary.ocm_intel.municipality || 'N/A'}</div>
                      </div>
                    </div>
                  )}

                  {/* Risk Flags */}
                  {safeArray(summaryView.summary?.risk_flags).length > 0 && (
                    <div className="p-4 bg-red-50/50 rounded-lg border border-red-100">
                      <h3 className="text-sm font-bold text-red-800 mb-2 flex items-center gap-2">
                        ⚠️ Risk Flags
                      </h3>
                      <ul className="text-xs text-red-700 space-y-1">
                        {safeArray(summaryView.summary?.risk_flags).map((flag, i) => (
                          <li key={i} className="flex items-start gap-1">• {flag}</li>
                        ))}
                      </ul>
                    </div>
                  )}

                  {/* Recommended Next Steps */}
                  {safeArray(summaryView.summary?.recommended_next_steps).length > 0 && (
                    <div className="p-4 bg-sky-50/50 rounded-lg border border-sky-100">
                      <h3 className="text-sm font-bold text-sky-800 mb-2 flex items-center gap-2">
                        ✅ Recommended Next Steps
                      </h3>
                      <ol className="text-xs text-sky-700 space-y-1 list-decimal list-inside">
                        {safeArray(summaryView.summary?.recommended_next_steps).map((step, i) => (
                          <li key={i}>{step}</li>
                        ))}
                      </ol>
                    </div>
                  )}
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center h-64 gap-3 text-center">
                  <AlertCircle className="h-10 w-10 text-amber-500" />
                  <p className="text-sm text-muted-foreground">No summary content available</p>
                  <Button variant="outline" size="sm" onClick={handleGenerateSummary}>
                    Try Again
                  </Button>
                </div>
              )}
            </div>
          </ScrollArea>

          {/* Routing Path Selection + Actions - hidden on print */}
          <div className="border-t pt-4 space-y-4 print:hidden">
            {/* Path Selection */}
            <div>
              <p className="text-xs text-muted-foreground mb-2">
                Select where this client should go first:
              </p>
              <div className="flex flex-wrap gap-2">
                {[
                  { value: 'funding_first', label: 'Funding First', color: 'emerald' },
                  { value: 'credit_first', label: 'Clean Credit First', color: 'indigo' },
                  { value: 'hybrid', label: 'Hybrid Path', color: 'amber' },
                  { value: 'do_not_work', label: 'Do Not Work', color: 'red' },
                ].map(opt => (
                  <button
                    key={opt.value}
                    onClick={() => setPrimaryPath(opt.value as typeof primaryPath)}
                    className={`rounded-full px-3 py-1.5 border text-xs font-medium transition-all ${
                      primaryPath === opt.value
                        ? opt.color === 'emerald' ? 'border-emerald-500 bg-emerald-500/10 text-emerald-700' :
                          opt.color === 'indigo' ? 'border-indigo-500 bg-indigo-500/10 text-indigo-700' :
                          opt.color === 'amber' ? 'border-amber-500 bg-amber-500/10 text-amber-700' :
                          'border-red-500 bg-red-500/10 text-red-700'
                        : 'border-slate-300 bg-slate-100 text-slate-600 hover:border-slate-400'
                    }`}
                  >
                    {opt.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex flex-col sm:flex-row justify-between items-center gap-3">
              <p className="text-xs text-muted-foreground">
                Wolf Fund Intelligence System • Confidential
              </p>
              <div className="flex flex-wrap gap-2">
                <Button variant="outline" onClick={() => window.print()}>
                  🖨️ Print Report
                </Button>
                <Button
                  variant="outline"
                  onClick={handleRegenerateSummary}
                  disabled={copilotLoading === 'summary'}
                >
                  ♻️ Regenerate
                </Button>
                <Button
                  variant="outline"
                  onClick={handleSaveToPuzzleDraft}
                  disabled={savingPuzzle || copilotLoading === 'summary'}
                >
                  💾 Save to Puzzle (Draft)
                </Button>
                <Button 
                  onClick={handleSaveToIntake}
                  disabled={savingToIntake || copilotLoading === 'summary'}
                  className="bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white"
                >
                  {savingToIntake ? (
                    <Loader2 className="h-4 w-4 animate-spin mr-2" />
                  ) : (
                    <Save className="h-4 w-4 mr-2" />
                  )}
                  Save to Intake & Route
                </Button>
                <Button variant="outline" onClick={() => setShowSummary(false)}>
                  Close
                </Button>
              </div>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};
