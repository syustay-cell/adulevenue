import React, { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { Phone, Mail, Search, AlertCircle, CheckCircle2, RefreshCw, FileSpreadsheet, Trash2, Edit, Eye } from "lucide-react";
import { useUserRoles } from "@/hooks/useUserRoles";
import { canViewRawPii, maskEmail, maskPhone } from "@/lib/masking";
import type { AppRole } from "@/lib/permissions";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

interface LeadList {
  id: string;
  name: string;
  source: string | null;
  status: string;
  total_rows: number | null;
  processed_rows: number | null;
  dialer_count: number | null;
  email_count: number | null;
  research_count: number | null;
  rejected_count: number | null;
  header_confidence: number | null;
  field_coverage: number | null;
  source_type: string | null;
  processing_summary: any;
  raw_headers: string[] | null;
  import_quality_score: number | null;
  file_path: string | null;
  error_message: string | null;
  created_at: string;
}

interface Lead {
  id: string;
  full_name: string | null;
  business_name: string | null;
  phone: string | null;
  email: string | null;
  status: string | null;
  raw_data: {
    original_row?: any[];
    original_headers?: string[];
    [key: string]: any;
  } | null;
}

export const LeadListsPanel: React.FC = () => {
  const { toast } = useToast();
  const { roles } = useUserRoles();
  const canViewPii = canViewRawPii((roles as AppRole[]) || []);
  const [file, setFile] = useState<File | null>(null);
  const [name, setName] = useState("");
  const [loading, setLoading] = useState(false);
  const [lists, setLists] = useState<LeadList[]>([]);
  const [expandedId, setExpandedId] = useState<string | null>(null);
  
  // Delete confirmation
  const [deleteListId, setDeleteListId] = useState<string | null>(null);
  const [deleting, setDeleting] = useState(false);
  
  // Edit modal
  const [editList, setEditList] = useState<LeadList | null>(null);
  const [editName, setEditName] = useState("");
  const [saving, setSaving] = useState(false);
  
  // View leads modal
  const [viewListId, setViewListId] = useState<string | null>(null);
  const [viewLeads, setViewLeads] = useState<Lead[]>([]);
  const [loadingLeads, setLoadingLeads] = useState(false);

  const loadLists = async () => {
    const { data, error } = await supabase
      .from("lead_lists")
      .select("*")
      .order("created_at", { ascending: false })
      .limit(50);

    if (!error && data) {
      setLists(data as any);
    }
  };

  useEffect(() => {
    loadLists();
  }, []);

  const handleUpload = async () => {
    if (!file) return;
    setLoading(true);

    try {
      const {
        data: { session },
      } = await supabase.auth.getSession();
      if (!session) throw new Error("No session");

      const userId = session.user.id;
      const listName = name || file.name;

      const { data: list, error: listError } = await supabase
        .from("lead_lists")
        .insert({
          name: listName,
          source: "file_upload",
          status: "pending",
          created_by: userId,
          file_path: "",
        } as any)
        .select()
        .single();

      if (listError || !list) throw listError || new Error("Failed to create list");

      const listId = list.id as string;
      const storagePath = `${listId}/${file.name}`;

      const { error: uploadError } = await supabase.storage
        .from("lead-lists")
        .upload(storagePath, file, { upsert: true });

      if (uploadError) throw uploadError;

      await supabase
        .from("lead_lists")
        .update({ file_path: storagePath, status: "processing" })
        .eq("id", listId);

      console.log("[LeadListsPanel] Invoking process-lead-list:", { listId, storagePath });
      
      const { data: fnData, error: fnError } = await supabase.functions.invoke(
        "process-lead-list",
        { body: { list_id: listId, file_path: storagePath } }
      );

      console.log("[LeadListsPanel] Function response:", { fnData, fnError });

      if (fnError) {
        console.error("[LeadListsPanel] Function error:", fnError);
        await supabase
          .from("lead_lists")
          .update({ status: "failed", error_message: fnError.message || "Function invocation failed" })
          .eq("id", listId);
        throw fnError;
      }

      setFile(null);
      setName("");
      await loadLists();
      toast({
        title: "Lead list uploaded",
        description: "AI extraction started. Results will appear shortly.",
      });
    } catch (e: any) {
      console.error("Lead list upload failed", e);
      toast({
        variant: "destructive",
        title: "Upload failed",
        description: e.message || "Please try again.",
      });
    } finally {
      setLoading(false);
    }
  };

  const retryProcessing = async (listId: string, filePath: string) => {
    try {
      toast({ title: "Retrying...", description: "Re-processing your lead list." });
      
      await supabase
        .from("lead_lists")
        .update({ status: "processing", error_message: null })
        .eq("id", listId);

      console.log("[LeadListsPanel] Retrying process-lead-list:", { listId, filePath });
      
      const { data: fnData, error: fnError } = await supabase.functions.invoke(
        "process-lead-list",
        { body: { list_id: listId, file_path: filePath } }
      );

      console.log("[LeadListsPanel] Retry response:", { fnData, fnError });

      if (fnError) {
        await supabase
          .from("lead_lists")
          .update({ status: "failed", error_message: fnError.message })
          .eq("id", listId);
        throw fnError;
      }

      await loadLists();
      toast({ title: "Processing complete", description: "Lead list has been processed." });
    } catch (e: any) {
      console.error("Retry failed", e);
      toast({
        variant: "destructive",
        title: "Retry failed",
        description: e.message || "Please try again.",
      });
      await loadLists();
    }
  };

  const handleDelete = async () => {
    if (!deleteListId) return;
    setDeleting(true);
    
    try {
      // First delete all leads associated with this list
      const { error: leadsError } = await supabase
        .from("leads")
        .delete()
        .eq("lead_list_id", deleteListId);
      
      if (leadsError) {
        console.error("Error deleting leads:", leadsError);
      }
      
      // Also try list_id column
      await supabase
        .from("leads")
        .delete()
        .eq("list_id", deleteListId);
      
      // Delete the file from storage
      const list = lists.find(l => l.id === deleteListId);
      if (list?.file_path) {
        await supabase.storage
          .from("lead-lists")
          .remove([list.file_path]);
      }
      
      // Delete the list record
      const { error: listError } = await supabase
        .from("lead_lists")
        .delete()
        .eq("id", deleteListId);
      
      if (listError) throw listError;
      
      toast({ title: "List deleted", description: "Lead list and all associated leads have been removed." });
      await loadLists();
    } catch (e: any) {
      console.error("Delete failed", e);
      toast({
        variant: "destructive",
        title: "Delete failed",
        description: e.message || "Please try again.",
      });
    } finally {
      setDeleting(false);
      setDeleteListId(null);
    }
  };

  const handleEdit = async () => {
    if (!editList) return;
    setSaving(true);
    
    try {
      const { error } = await supabase
        .from("lead_lists")
        .update({ name: editName })
        .eq("id", editList.id);
      
      if (error) throw error;
      
      toast({ title: "List updated", description: "List name has been changed." });
      await loadLists();
      setEditList(null);
    } catch (e: any) {
      console.error("Edit failed", e);
      toast({
        variant: "destructive",
        title: "Update failed",
        description: e.message || "Please try again.",
      });
    } finally {
      setSaving(false);
    }
  };

  const loadLeadsForList = async (listId: string) => {
    setLoadingLeads(true);
    setViewListId(listId);
    
    try {
      // Fetch leads with raw_data containing all original columns
      const { data, error } = await supabase
        .from("leads")
        .select("id, full_name, business_name, phone, email, status, raw_data")
        .or(`lead_list_id.eq.${listId},list_id.eq.${listId}`)
        .limit(200);
      
      if (error) throw error;
      setViewLeads((data || []) as Lead[]);
    } catch (e: any) {
      console.error("Failed to load leads", e);
      toast({
        variant: "destructive",
        title: "Failed to load leads",
        description: e.message,
      });
    } finally {
      setLoadingLeads(false);
    }
  };

  // Get all unique headers from all leads for dynamic table
  const getAllHeaders = (): string[] => {
    if (viewLeads.length === 0) return [];
    
    // Try to get headers from first lead's raw_data
    const firstLead = viewLeads.find(l => l.raw_data?.original_headers);
    if (firstLead?.raw_data?.original_headers) {
      return firstLead.raw_data.original_headers.filter((h: string) => h && h.trim());
    }
    
    // Fallback to standard fields
    return ['Name', 'Business', 'Phone', 'Email', 'Status'];
  };

  // Get cell value for a lead at a specific column
  const getCellValue = (lead: Lead, header: string, index: number): string => {
    // If we have original_row data, use it
    if (lead.raw_data?.original_row && Array.isArray(lead.raw_data.original_row)) {
      const value = lead.raw_data.original_row[index];
      if (value !== null && value !== undefined && String(value).trim()) {
        return String(value);
      }
      return '-';
    }
    
    // Fallback to mapped fields
    const headerLower = header.toLowerCase();
    if (headerLower.includes('name') && !headerLower.includes('business') && !headerLower.includes('entity')) {
      return lead.full_name || '-';
    }
    if (headerLower.includes('business') || headerLower.includes('entity') || headerLower.includes('company')) {
      return lead.business_name || '-';
    }
    if (headerLower.includes('phone') || headerLower.includes('tel')) {
      if (!lead.phone) return '-';
      return canViewPii ? lead.phone : maskPhone(lead.phone);
    }
    if (headerLower.includes('email')) {
      if (!lead.email) return '-';
      return canViewPii ? lead.email : maskEmail(lead.email);
    }
    return '-';
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "completed":
        return <span className="inline-flex items-center gap-1 rounded-full bg-emerald-100 px-2 py-0.5 text-[10px] font-medium text-emerald-700"><CheckCircle2 className="h-3 w-3" />Completed</span>;
      case "processing":
        return <span className="inline-flex items-center gap-1 rounded-full bg-amber-100 px-2 py-0.5 text-[10px] font-medium text-amber-700"><RefreshCw className="h-3 w-3 animate-spin" />Processing</span>;
      case "failed":
        return <span className="inline-flex items-center gap-1 rounded-full bg-red-100 px-2 py-0.5 text-[10px] font-medium text-red-700"><AlertCircle className="h-3 w-3" />Failed</span>;
      default:
        return <span className="inline-flex items-center rounded-full bg-slate-100 px-2 py-0.5 text-[10px] font-medium text-slate-600">{status}</span>;
    }
  };

  const getSourceBadge = (sourceType: string | null) => {
    if (sourceType === "ocm_upload") {
      return <span className="rounded-full bg-emerald-500/10 px-2 py-0.5 text-[10px] font-medium text-emerald-600">🌿 OCM</span>;
    }
    return <span className="rounded-full bg-slate-100 px-2 py-0.5 text-[10px] font-medium text-slate-500">Generic</span>;
  };

  const getQualityBadge = (score: number | null) => {
    if (score == null) return null;
    const colorClass = score >= 80 
      ? "bg-emerald-100 text-emerald-700"
      : score >= 60 
        ? "bg-amber-100 text-amber-700"
        : "bg-red-100 text-red-700";
    return <span className={`rounded-full px-2 py-0.5 text-[10px] font-medium ${colorClass}`}>Quality: {score}%</span>;
  };

  return (
    <div className="space-y-6">
      {/* Upload card */}
      <div className="rounded-2xl border border-dashed border-slate-300 bg-slate-50 p-4 sm:p-6">
        <div className="flex items-center gap-2 mb-2">
          <FileSpreadsheet className="h-5 w-5 text-slate-600" />
          <h2 className="text-sm font-semibold text-slate-900">Upload Lead List</h2>
        </div>
        <p className="text-xs text-slate-500 mb-4">
          Upload CSV or XLSX files. AI will auto-detect headers, normalize data, and route leads to Dialer/Email/Research queues.
        </p>

        <div className="flex flex-col gap-3 sm:flex-row sm:items-end">
          <div className="flex-1 space-y-2">
            <label className="block text-[11px] font-medium text-slate-600">List Name</label>
            <input
              type="text"
              className="w-full rounded-lg border border-slate-200 px-3 py-2 text-xs focus:border-primary focus:ring-1 focus:ring-primary"
              placeholder="e.g. OCM Long Island Licenses"
              value={name}
              onChange={(e) => setName(e.target.value)}
            />
            <label className="block text-[11px] font-medium text-slate-600">File (CSV, XLSX)</label>
            <input
              type="file"
              accept=".csv,.xlsx,.xls"
              onChange={(e) => setFile(e.target.files?.[0] ?? null)}
              className="w-full text-xs file:mr-3 file:rounded-full file:border-0 file:bg-primary/10 file:px-3 file:py-1.5 file:text-[11px] file:font-medium file:text-primary hover:file:bg-primary/20"
            />
          </div>
          <button
            type="button"
            disabled={!file || loading}
            onClick={handleUpload}
            className="inline-flex h-10 items-center justify-center rounded-lg bg-primary px-4 text-xs font-medium text-primary-foreground hover:bg-primary/90 disabled:opacity-60"
          >
            {loading ? "Processing…" : "Upload & Extract"}
          </button>
        </div>
      </div>

      {/* Lead lists with summary */}
      <div className="rounded-2xl border border-slate-200 bg-white p-4 sm:p-6">
        <div className="mb-4 flex items-center justify-between">
          <h2 className="text-sm font-semibold text-slate-900">Lead Lists</h2>
          <button
            type="button"
            onClick={loadLists}
            className="inline-flex items-center gap-1 text-[11px] text-slate-500 hover:text-slate-800"
          >
            <RefreshCw className="h-3 w-3" /> Refresh
          </button>
        </div>

        {lists.length === 0 ? (
          <p className="py-8 text-center text-xs text-slate-400">No lead lists uploaded yet.</p>
        ) : (
          <div className="space-y-3">
            {lists.map((list) => (
              <div
                key={list.id}
                className="rounded-xl border border-slate-100 bg-slate-50/50 p-3 transition-all hover:border-slate-200"
              >
                {/* Header row */}
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="text-xs font-semibold text-slate-900">{list.name}</span>
                    {getStatusBadge(list.status)}
                    {getSourceBadge(list.source_type)}
                    {getQualityBadge(list.import_quality_score)}
                    {list.status === "failed" && list.file_path && (
                      <button
                        type="button"
                        onClick={() => retryProcessing(list.id, list.file_path!)}
                        className="inline-flex items-center gap-1 rounded-full bg-amber-100 px-2 py-0.5 text-[10px] font-medium text-amber-700 hover:bg-amber-200"
                      >
                        <RefreshCw className="h-3 w-3" /> Retry
                      </button>
                    )}
                  </div>
                  
                  {/* Action buttons */}
                  <div className="flex items-center gap-1">
                    <button
                      type="button"
                      onClick={() => loadLeadsForList(list.id)}
                      className="inline-flex items-center gap-1 rounded-lg border border-slate-200 bg-white px-2 py-1 text-[10px] font-medium text-slate-600 hover:bg-slate-50"
                    >
                      <Eye className="h-3 w-3" /> View
                    </button>
                    <button
                      type="button"
                      onClick={() => { setEditList(list); setEditName(list.name); }}
                      className="inline-flex items-center gap-1 rounded-lg border border-slate-200 bg-white px-2 py-1 text-[10px] font-medium text-slate-600 hover:bg-slate-50"
                    >
                      <Edit className="h-3 w-3" /> Edit
                    </button>
                    <button
                      type="button"
                      onClick={() => setDeleteListId(list.id)}
                      className="inline-flex items-center gap-1 rounded-lg border border-red-200 bg-red-50 px-2 py-1 text-[10px] font-medium text-red-600 hover:bg-red-100"
                    >
                      <Trash2 className="h-3 w-3" /> Delete
                    </button>
                    <span className="text-[10px] text-slate-400 ml-2">
                      {new Date(list.created_at).toLocaleDateString()}
                    </span>
                  </div>
                </div>

                {/* Error message for failed lists */}
                {list.status === "failed" && list.error_message && (
                  <div className="mt-2 rounded-lg bg-red-50 p-2 text-[11px] text-red-600">
                    {list.error_message}
                  </div>
                )}

                {/* Summary stats */}
                {list.status === "completed" && (
                  <div className="mt-3 grid grid-cols-2 gap-2 sm:grid-cols-5">
                    <div className="rounded-lg bg-white p-2 text-center shadow-sm">
                      <div className="text-lg font-bold text-slate-900">{list.processed_rows ?? 0}</div>
                      <div className="text-[10px] text-slate-500">Processed</div>
                    </div>
                    <div className="rounded-lg bg-emerald-50 p-2 text-center">
                      <div className="flex items-center justify-center gap-1 text-lg font-bold text-emerald-600">
                        <Phone className="h-3.5 w-3.5" />
                        {list.dialer_count ?? 0}
                      </div>
                      <div className="text-[10px] text-emerald-600">Dialer</div>
                    </div>
                    <div className="rounded-lg bg-blue-50 p-2 text-center">
                      <div className="flex items-center justify-center gap-1 text-lg font-bold text-blue-600">
                        <Mail className="h-3.5 w-3.5" />
                        {list.email_count ?? 0}
                      </div>
                      <div className="text-[10px] text-blue-600">Email Only</div>
                    </div>
                    <div className="rounded-lg bg-amber-50 p-2 text-center">
                      <div className="flex items-center justify-center gap-1 text-lg font-bold text-amber-600">
                        <Search className="h-3.5 w-3.5" />
                        {list.research_count ?? 0}
                      </div>
                      <div className="text-[10px] text-amber-600">Research</div>
                    </div>
                    <div className="rounded-lg bg-slate-100 p-2 text-center">
                      <div className="text-lg font-bold text-slate-500">{list.rejected_count ?? 0}</div>
                      <div className="text-[10px] text-slate-500">Rejected</div>
                    </div>
                  </div>
                )}

                {/* Confidence & coverage bar */}
                {list.status === "completed" && (
                  <div className="mt-3 flex flex-wrap items-center gap-4 text-[10px]">
                    <div className="flex items-center gap-1.5">
                      <span className="text-slate-500">Header Mapping:</span>
                      <div className="h-1.5 w-16 rounded-full bg-slate-200">
                        <div
                          className="h-1.5 rounded-full bg-emerald-500"
                          style={{ width: `${list.header_confidence ?? 0}%` }}
                        />
                      </div>
                      <span className="font-medium text-slate-700">{list.header_confidence ?? 0}%</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <span className="text-slate-500">Field Coverage:</span>
                      <div className="h-1.5 w-16 rounded-full bg-slate-200">
                        <div
                          className="h-1.5 rounded-full bg-blue-500"
                          style={{ width: `${list.field_coverage ?? 0}%` }}
                        />
                      </div>
                      <span className="font-medium text-slate-700">{list.field_coverage ?? 0}%</span>
                    </div>
                    <button
                      type="button"
                      onClick={() => setExpandedId(expandedId === list.id ? null : list.id)}
                      className="ml-auto text-primary hover:underline"
                    >
                      {expandedId === list.id ? "Hide details" : "View details"}
                    </button>
                  </div>
                )}

                {/* Expanded details */}
                {expandedId === list.id && list.processing_summary && (
                  <div className="mt-3 rounded-lg bg-white p-3 text-[11px] text-slate-600 shadow-sm">
                    <div className="font-semibold text-slate-800 mb-2">Processing Summary</div>
                    <div className="grid grid-cols-2 gap-x-4 gap-y-1">
                      <div>Phone Present: <span className="font-medium">{list.processing_summary.coverage?.phone_pct ?? 0}%</span></div>
                      <div>Email Present: <span className="font-medium">{list.processing_summary.coverage?.email_pct ?? 0}%</span></div>
                      <div>Source Detected: <span className="font-medium capitalize">{list.processing_summary.source_detected?.replace("_", " ") || "Generic"}</span></div>
                      <div>Total Rows: <span className="font-medium">{list.processing_summary.total_rows}</span></div>
                    </div>
                    {list.processing_summary.header_mapping && (
                      <div className="mt-2 pt-2 border-t border-slate-100">
                        <div className="font-semibold text-slate-800 mb-1">Header Mapping</div>
                        <div className="flex flex-wrap gap-1">
                          {Object.entries(list.processing_summary.header_mapping).map(([field, info]: [string, any]) => (
                            <span key={field} className="inline-flex items-center rounded bg-slate-100 px-1.5 py-0.5 text-[10px]">
                              <span className="text-slate-500">{info.original}</span>
                              <span className="mx-1 text-slate-300">→</span>
                              <span className="font-medium text-slate-700">{field}</span>
                            </span>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={!!deleteListId} onOpenChange={() => setDeleteListId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Lead List?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete this lead list and ALL leads imported from it. This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={deleting}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDelete}
              disabled={deleting}
              className="bg-red-600 hover:bg-red-700"
            >
              {deleting ? "Deleting..." : "Delete List & Leads"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Edit Dialog */}
      <Dialog open={!!editList} onOpenChange={() => setEditList(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Lead List</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">List Name</label>
              <input
                type="text"
                value={editName}
                onChange={(e) => setEditName(e.target.value)}
                className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm focus:border-primary focus:ring-1 focus:ring-primary"
              />
            </div>
            <div className="flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setEditList(null)}
                className="rounded-lg border border-slate-200 px-4 py-2 text-sm font-medium text-slate-600 hover:bg-slate-50"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleEdit}
                disabled={saving || !editName.trim()}
                className="rounded-lg bg-primary px-4 py-2 text-sm font-medium text-primary-foreground hover:bg-primary/90 disabled:opacity-50"
              >
                {saving ? "Saving..." : "Save Changes"}
              </button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* View Leads Dialog - Shows ALL original columns */}
      <Dialog open={!!viewListId} onOpenChange={() => { setViewListId(null); setViewLeads([]); }}>
        <DialogContent className="max-w-[95vw] h-[90vh] flex flex-col p-0">
          <DialogHeader className="p-4 pb-2 flex-shrink-0 border-b border-slate-200">
            <DialogTitle>
              Leads in List ({viewLeads.length} records)
            </DialogTitle>
          </DialogHeader>
          <div className="flex-1 overflow-auto p-4 min-h-0">
            {loadingLeads ? (
              <div className="py-8 text-center text-sm text-slate-500">Loading leads...</div>
            ) : viewLeads.length === 0 ? (
              <div className="py-8 text-center text-sm text-slate-500">No leads found in this list.</div>
            ) : (
              <table className="w-full text-xs border-collapse">
                <thead className="bg-slate-100 sticky top-0 z-10">
                  <tr>
                    {getAllHeaders().map((header, idx) => (
                      <th 
                        key={idx} 
                        className="px-2 py-2 text-left text-[11px] font-semibold text-slate-700 border-b border-slate-200 whitespace-nowrap"
                      >
                        {header}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {viewLeads.map((lead) => (
                    <tr key={lead.id} className="hover:bg-slate-50">
                      {getAllHeaders().map((header, idx) => (
                        <td 
                          key={idx} 
                          className="px-2 py-1.5 text-slate-600 border-b border-slate-50 max-w-[200px] truncate"
                          title={getCellValue(lead, header, idx)}
                        >
                          {getCellValue(lead, header, idx)}
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};