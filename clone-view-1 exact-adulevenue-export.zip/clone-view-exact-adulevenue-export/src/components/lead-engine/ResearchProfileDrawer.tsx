import { X, TrendingUp, AlertTriangle, Shield, Building2, DollarSign, Globe, User } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ResearchProfile } from "@/lib/api/researchIntel";
import { useUserRoles } from "@/hooks/useUserRoles";
import { canViewRawPii, maskEmail, maskPhone } from "@/lib/masking";
import type { AppRole } from "@/lib/permissions";

interface ResearchProfileDrawerProps {
  profile: ResearchProfile;
  leadName: string;
  onClose: () => void;
  onCallNow?: () => void;
  onSendFundingLink?: () => void;
  onMoveToCredit?: () => void;
  onArchive?: () => void;
}

export function ResearchProfileDrawer({
  profile,
  leadName,
  onClose,
  onCallNow,
  onSendFundingLink,
  onMoveToCredit,
  onArchive,
}: ResearchProfileDrawerProps) {
  const { roles } = useUserRoles();
  const canViewPii = canViewRawPii((roles as AppRole[]) || []);
  const getRiskBadgeColor = (risk: string) => {
    switch (risk) {
      case "low":
        return "bg-emerald-500/20 text-emerald-300 border-emerald-500/30";
      case "medium":
        return "bg-amber-500/20 text-amber-300 border-amber-500/30";
      case "high":
        return "bg-rose-500/20 text-rose-300 border-rose-500/30";
      default:
        return "bg-slate-500/20 text-slate-300 border-slate-500/30";
    }
  };

  const getRecommendationBadge = (rec: string) => {
    switch (rec) {
      case "funding_first":
        return { label: "Funding First", className: "bg-emerald-500/20 text-emerald-300 border-emerald-500/30" };
      case "credit_first":
        return { label: "Credit First", className: "bg-sky-500/20 text-sky-300 border-sky-500/30" };
      case "hybrid":
        return { label: "Hybrid Path", className: "bg-amber-500/20 text-amber-300 border-amber-500/30" };
      case "do_not_work":
        return { label: "Do Not Work", className: "bg-rose-500/20 text-rose-300 border-rose-500/30" };
      default:
        return { label: "Unknown", className: "bg-slate-500/20 text-slate-300 border-slate-500/30" };
    }
  };

  const recommendation = getRecommendationBadge(profile.funding_recommendation);
  const enriched = profile.enriched || {};

  if (!canViewPii) {
    return (
      <div className="fixed inset-0 z-50 flex justify-end bg-black/40 backdrop-blur-sm">
        <div className="h-full w-full max-w-2xl bg-slate-950 shadow-2xl flex flex-col border-l border-slate-800">
          <div className="flex items-center justify-between border-b border-slate-800 bg-slate-900/50 px-6 py-4">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <Shield className="h-5 w-5 text-rose-400" />
                <h2 className="text-lg font-semibold text-slate-50">Access denied</h2>
              </div>
              <p className="text-xs text-slate-400">
                AI research intelligence contains raw PII and is <span className="font-semibold">Owner-only</span>.
              </p>
            </div>
            <button
              onClick={onClose}
              className="text-slate-400 hover:text-slate-200 transition-colors p-2 hover:bg-slate-800 rounded-lg"
            >
              <X className="h-5 w-5" />
            </button>
          </div>
          <div className="p-6 text-sm text-slate-300">
            PII is masked for non-owners. Use system-mediated actions instead.
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-black/40 backdrop-blur-sm">
      <div className="h-full w-full max-w-2xl bg-slate-950 shadow-2xl flex flex-col border-l border-slate-800">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 bg-slate-900/50 px-6 py-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <Shield className="h-5 w-5 text-emerald-400" />
              <h2 className="text-lg font-semibold text-slate-50">
                AI Research Intelligence
              </h2>
            </div>
            <p className="text-xs text-slate-400">
              AI-powered enrichment & funding analysis for {leadName}
            </p>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-200 transition-colors p-2 hover:bg-slate-800 rounded-lg"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto px-6 py-6 space-y-6">
          {/* Funding Score Card */}
          <div className="rounded-2xl border border-slate-800 bg-gradient-to-br from-emerald-500/10 to-sky-500/10 p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <TrendingUp className="h-5 w-5 text-emerald-400" />
                <h3 className="text-sm font-semibold text-slate-50">AI Funding Score</h3>
              </div>
              <Badge className={recommendation.className}>
                {recommendation.label}
              </Badge>
            </div>
            <div className="text-6xl font-bold text-emerald-300 mb-2">
              {profile.funding_score}
              <span className="text-2xl text-slate-400">/100</span>
            </div>
            <div className="text-xs text-slate-400">
              AI-computed funding eligibility score based on enriched data
            </div>
          </div>

          {/* Enriched Contact Info */}
          <div className="rounded-xl border border-emerald-800 bg-emerald-500/5 p-5">
            <div className="flex items-center gap-2 mb-4">
              <User className="h-4 w-4 text-emerald-400" />
              <h3 className="text-sm font-semibold text-slate-50">AI-Enriched Contact Info</h3>
              {enriched.online_presence_score && (
                <Badge className="ml-auto bg-emerald-500/20 text-emerald-300 text-xs">
                  {enriched.online_presence_score}% data found
                </Badge>
              )}
            </div>
            <div className="space-y-2 text-sm">
              <div className="grid grid-cols-3 gap-2">
                <span className="text-slate-400">Name:</span>
                <span className="col-span-2 text-slate-200 font-medium">
                  {enriched.name || enriched.owner_name || "Not found"}
                </span>
              </div>
              <div className="grid grid-cols-3 gap-2">
                <span className="text-slate-400">Business:</span>
                <span className="col-span-2 text-slate-200 font-medium">
                  {enriched.business_name || "—"}
                </span>
              </div>
              <div className="grid grid-cols-3 gap-2">
                <span className="text-slate-400">Phone:</span>
                <span className="col-span-2">
                  {enriched.phone ? (
                    <a 
                      href={`tel:${enriched.phone}`}
                      className="text-emerald-300 hover:text-emerald-400 font-bold underline bg-emerald-500/10 px-2 py-0.5 rounded"
                    >
                      📞 {canViewPii ? enriched.phone : maskPhone(enriched.phone)}
                    </a>
                  ) : (
                    <span className="text-rose-400">❌ Not found</span>
                  )}
                </span>
              </div>
              <div className="grid grid-cols-3 gap-2">
                <span className="text-slate-400">Email:</span>
                <span className="col-span-2">
                  {enriched.email ? (
                    <a 
                      href={`mailto:${enriched.email}`}
                      className="text-sky-300 hover:text-sky-400 font-bold underline bg-sky-500/10 px-2 py-0.5 rounded"
                    >
                      ✉️ {canViewPii ? enriched.email : maskEmail(enriched.email)}
                    </a>
                  ) : (
                    <span className="text-amber-400">⚠️ Not found</span>
                  )}
                </span>
              </div>
              {enriched.website && (
                <div className="grid grid-cols-3 gap-2">
                  <span className="text-slate-400">Website:</span>
                  <span className="col-span-2">
                    <a 
                      href={enriched.website.startsWith('http') ? enriched.website : `https://${enriched.website}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-sky-300 hover:text-sky-400 font-medium underline flex items-center gap-1"
                    >
                      <Globe className="h-3 w-3" />
                      {enriched.website}
                    </a>
                  </span>
                </div>
              )}
              {enriched.owner_name && enriched.owner_name !== enriched.name && (
                <div className="grid grid-cols-3 gap-2">
                  <span className="text-slate-400">Owner:</span>
                  <span className="col-span-2 text-slate-200 font-medium">
                    {enriched.owner_name}
                  </span>
                </div>
              )}
              <div className="grid grid-cols-3 gap-2">
                <span className="text-slate-400">Address:</span>
                <span className="col-span-2 text-slate-200">
                  {enriched.address || "—"}
                </span>
              </div>
              <div className="grid grid-cols-3 gap-2">
                <span className="text-slate-400">Industry:</span>
                <span className="col-span-2 text-slate-200">
                  {enriched.industry || "—"}
                </span>
              </div>
            </div>
          </div>

          {/* Funding Eligibility */}
          <div className="rounded-xl border border-slate-800 bg-slate-900/40 p-5">
            <div className="flex items-center gap-2 mb-4">
              <DollarSign className="h-4 w-4 text-emerald-400" />
              <h3 className="text-sm font-semibold text-slate-50">Funding Eligibility</h3>
            </div>
            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-4">
                <div className="rounded-lg bg-slate-950/60 p-3">
                  <div className="text-xs text-slate-400 mb-1">Est. Monthly Revenue</div>
                  <div className="text-lg font-semibold text-slate-100">
                    {profile.estimated_revenue 
                      ? `$${profile.estimated_revenue.toLocaleString()}`
                      : "Unknown"}
                  </div>
                </div>
                <div className="rounded-lg bg-slate-950/60 p-3">
                  <div className="text-xs text-slate-400 mb-1">Business Age</div>
                  <div className="text-lg font-semibold text-slate-100">
                    {profile.business_age_years != null 
                      ? `${profile.business_age_years} years`
                      : "Unknown"}
                  </div>
                </div>
              </div>
              <div className="grid grid-cols-1 gap-2 text-sm">
                <div className="flex items-center justify-between">
                  <span className="text-slate-400">Industry Risk:</span>
                  <Badge className={getRiskBadgeColor(profile.industry_risk || 'unknown')}>
                    {(profile.industry_risk || 'unknown').toUpperCase()}
                  </Badge>
                </div>
              </div>
            </div>
          </div>

          {/* Credit & Identity Intelligence */}
          <div className="rounded-xl border border-slate-800 bg-slate-900/40 p-5">
            <div className="flex items-center gap-2 mb-4">
              <AlertTriangle className="h-4 w-4 text-amber-400" />
              <h3 className="text-sm font-semibold text-slate-50">Credit & Identity Intelligence</h3>
            </div>
            <div className="space-y-3 text-sm">
              <div className="flex items-center justify-between">
                <span className="text-slate-400">Credit Risk:</span>
                <Badge className={getRiskBadgeColor(profile.credit_risk)}>
                  {profile.credit_risk.toUpperCase()}
                </Badge>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-400">Identity Theft Risk:</span>
                <Badge className={getRiskBadgeColor(profile.identity_theft_risk)}>
                  {profile.identity_theft_risk.toUpperCase()}
                </Badge>
              </div>
            </div>
          </div>

          {/* AI Notes */}
          {profile.notes && Object.keys(profile.notes).length > 0 && (
            <div className="rounded-xl border border-slate-800 bg-slate-900/40 p-5">
              <h3 className="text-sm font-semibold text-slate-50 mb-3">AI Analysis Notes</h3>
              <div className="text-xs text-slate-300 space-y-2">
                {(profile.notes as any).reason_summary && (
                  <div className="bg-slate-950/60 p-3 rounded-lg">
                    {(profile.notes as any).reason_summary}
                  </div>
                )}
                {(profile.notes as any).ai_enriched && (
                  <div className="flex items-center gap-2 text-emerald-400">
                    <span>✓</span>
                    <span>AI-enriched via the AI Gateway</span>
                  </div>
                )}
                {(profile.notes as any).warning && (
                  <div className="flex items-center gap-2 text-rose-400">
                    <span>⚠️</span>
                    <span>{(profile.notes as any).warning}</span>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>

        {/* Footer Actions */}
        <div className="border-t border-slate-800 bg-slate-900/50 px-6 py-4">
          <div className="text-xs text-slate-400 mb-3">Action Recommendations</div>
          <div className="flex flex-wrap gap-2">
            {onCallNow && enriched.phone && (
              <Button
                onClick={onCallNow}
                size="sm"
                className="bg-emerald-600 hover:bg-emerald-700 text-white"
              >
                📞 Call Now
              </Button>
            )}
            {onSendFundingLink && enriched.email && (
              <Button
                onClick={onSendFundingLink}
                size="sm"
                variant="outline"
                className="border-emerald-600 text-emerald-300 hover:bg-emerald-600/20"
              >
                Send Funding Link
              </Button>
            )}
            {onMoveToCredit && (
              <Button
                onClick={onMoveToCredit}
                size="sm"
                variant="outline"
                className="border-sky-600 text-sky-300 hover:bg-sky-600/20"
              >
                Move to Credit
              </Button>
            )}
            {onArchive && (
              <Button
                onClick={onArchive}
                size="sm"
                variant="outline"
                className="border-rose-600 text-rose-300 hover:bg-rose-600/20"
              >
                Archive
              </Button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
