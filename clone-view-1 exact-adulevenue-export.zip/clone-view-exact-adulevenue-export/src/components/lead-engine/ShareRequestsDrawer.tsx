import { useEffect, useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

type RequestStatus = 'pending' | 'accepted' | 'rejected';
type RequestType = 'release' | 'split_50_50';

type ShareRequest = {
  id: string;
  lead_id: string;
  from_worker_id: string;
  to_worker_id: string;
  type: RequestType;
  status: RequestStatus;
  message: string | null;
  created_at: string;
  responded_at: string | null;
  lead: {
    id: string;
    full_name: string | null;
    business_name: string | null;
    email: string | null;
    phone: string | null;
  };
  from_user_email: string | null;
};

export function ShareRequestsDrawer({
  open,
  onClose,
  currentUserId,
}: {
  open: boolean;
  onClose: () => void;
  currentUserId: string | null;
}) {
  const [requests, setRequests] = useState<ShareRequest[]>([]);
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  const load = async () => {
    if (!currentUserId) return;
    setLoading(true);

    const { data, error } = await supabase
      .from('lead_share_requests_view')
      .select('*')
      .or(
        `from_worker_id.eq.${currentUserId},to_worker_id.eq.${currentUserId}`,
      )
      .order('created_at', { ascending: false })
      .limit(100);

    if (error) {
      console.error('Failed to load share requests', error);
      toast({
        variant: 'destructive',
        title: 'Could not load share requests',
      });
    } else {
      setRequests((data ?? []) as any);
    }
    setLoading(false);
  };

  useEffect(() => {
    if (open) load();
  }, [open, currentUserId]);

  const respond = async (id: string, decision: 'accepted' | 'rejected') => {
    try {
      const { error } = await supabase.rpc('respond_lead_share', {
        p_request_id: id,
        p_owner_id: currentUserId,
        p_decision: decision,
      });
      if (error) throw error;

      toast({
        title: `Request ${decision}`,
      });
      await load();
    } catch (e: any) {
      console.error('Failed to respond to request', e);
      toast({
        variant: 'destructive',
        title: 'Failed to respond',
        description: e.message || 'Please try again',
      });
    }
  };

  const typeLabel = (t: RequestType) =>
    t === 'release' ? 'Release Lead' : '50/50 Split';

  const statusBadge = (s: RequestStatus) => {
    const base =
      'inline-flex items-center rounded-full px-2 py-0.5 text-[10px] font-medium';
    switch (s) {
      case 'pending':
        return base + ' bg-amber-100 text-amber-800';
      case 'accepted':
        return base + ' bg-emerald-100 text-emerald-700';
      case 'rejected':
        return base + ' bg-rose-100 text-rose-700';
    }
  };

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-40 flex justify-end bg-black/20">
      <div className="flex h-full w-full max-w-md flex-col bg-white shadow-xl">
        <header className="flex items-center justify-between border-b px-4 py-3">
          <div>
            <h2 className="text-sm font-semibold text-slate-900">
              Lead Share Requests
            </h2>
            <p className="text-xs text-slate-500">
              Release & 50/50 split requests you're involved in.
            </p>
          </div>
          <button
            onClick={onClose}
            className="rounded-full border border-slate-200 px-2 py-1 text-xs"
          >
            ✕
          </button>
        </header>

        <div className="flex-1 overflow-y-auto px-4 py-3">
          {loading && (
            <p className="py-4 text-center text-xs text-slate-400">
              Loading requests…
            </p>
          )}

          {!loading && requests.length === 0 && (
            <p className="py-4 text-center text-xs text-slate-400">
              No share requests yet.
            </p>
          )}

          <ul className="space-y-3">
            {requests.map((r) => {
              const isOwner = r.to_worker_id === currentUserId;
              const awaitingOwner = r.status === 'pending' && isOwner;
              return (
                <li
                  key={r.id}
                  className="rounded-xl border border-slate-100 bg-slate-50 p-3 text-xs text-slate-700"
                >
                  <div className="mb-1 flex items-center justify-between">
                    <span className="font-semibold">
                      {typeLabel(r.type)}
                    </span>
                    <span className={statusBadge(r.status)}>
                      {r.status.toUpperCase()}
                    </span>
                  </div>

                  <div className="space-y-0.5">
                    <p className="text-[11px] text-slate-600">
                      Lead:{' '}
                      <span className="font-medium">
                        {r.lead.full_name ||
                          r.lead.business_name ||
                          'Unknown lead'}
                      </span>
                      {r.lead.email && ` · ${r.lead.email}`}
                    </p>
                    <p className="text-[11px] text-slate-500">
                      Requested by:{' '}
                      <span className="font-medium">
                        {r.from_user_email || 'Unknown user'}
                      </span>{' '}
                      · {new Date(r.created_at).toLocaleString()}
                    </p>
                    {r.message && (
                      <p className="mt-1 text-[11px] text-slate-500">
                        "{r.message}"
                      </p>
                    )}
                  </div>

                  {awaitingOwner && (
                    <div className="mt-2 flex gap-2">
                      <button
                        onClick={() => respond(r.id, 'accepted')}
                        className="flex-1 rounded-full bg-emerald-500 px-2 py-1 text-[11px] font-semibold text-white hover:bg-emerald-600"
                      >
                        Accept
                      </button>
                      <button
                        onClick={() => respond(r.id, 'rejected')}
                        className="flex-1 rounded-full bg-rose-500 px-2 py-1 text-[11px] font-semibold text-white hover:bg-rose-600"
                      >
                        Reject
                      </button>
                    </div>
                  )}
                </li>
              );
            })}
          </ul>
        </div>
      </div>
    </div>
  );
}
