import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { FileText, Wrench, Loader2 } from "lucide-react";
import { logActivity } from "@/lib/activity";
import type { Lead } from "@/types/core";

interface LeadActionButtonsProps {
  lead: Lead;
  user: { id: string; email: string | undefined };
  userRole: string;
  onActionComplete?: () => void;
}

export const LeadActionButtons = ({
  lead,
  user,
  userRole,
  onActionComplete,
}: LeadActionButtonsProps) => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [isStartingApp, setIsStartingApp] = useState(false);
  const [isStartingCredit, setIsStartingCredit] = useState(false);

  const handleStartApplication = async () => {
    if (!user || !user.email) return;

    try {
      setIsStartingApp(true);

      const { data: app, error } = await supabase
        .from('fast_track_applications')
        .insert({
          email: lead.email || '',
          client_name: lead.full_name,
          business_name: lead.business_name || '',
          phone: lead.phone || '',
          status: 'intake',
          user_id: user.id,
          in_business_over_6_months: false,
          has_previous_loan: false,
        })
        .select()
        .single();

      if (error) throw error;

      await supabase
        .from('leads')
        .update({
          status: 'application_started',
          assigned_to_worker_id: user.id,
          updated_at: new Date().toISOString(),
        })
        .eq('id', lead.id);

      await logActivity({
        actorId: user.id,
        actorEmail: user.email,
        actorRole: userRole,
        eventType: 'funding',
        decision: 'pending',
        summary: `Started Fast Track application from lead ${lead.email || lead.id}`,
        contextType: 'lead',
        contextId: lead.id,
      });

      toast({
        title: 'Application started',
        description: 'Redirecting to funding application...',
      });

      navigate(`/fast-track?applicationId=${app.id}`);
      onActionComplete?.();
    } catch (e: any) {
      console.error('Failed to start application', e);
      toast({
        variant: 'destructive',
        title: 'Error starting application',
        description: e.message || 'Please try again.',
      });
    } finally {
      setIsStartingApp(false);
    }
  };

  const handleSendToCreditFix = async () => {
    if (!user || !user.email) return;

    try {
      setIsStartingCredit(true);

      // First create a credit repair application
      const { data: creditApp, error: creditAppError } = await supabase
        .from('credit_repair_applications')
        .insert({
          email: lead.email || '',
          phone: lead.phone || '',
          full_name: lead.full_name || '',
          status: 'active',
          user_id: user.id,
        })
        .select()
        .single();

      if (creditAppError) throw creditAppError;

      // Then create credit repair case
      const { data: creditCase, error } = await supabase
        .from('credit_repair_cases')
        .insert({
          credit_repair_application_id: creditApp.id,
          status: 'intake',
          assigned_specialist_id: null,
        })
        .select()
        .single();

      if (error) throw error;

      await supabase
        .from('leads')
        .update({
          status: 'application_started',
          updated_at: new Date().toISOString(),
        })
        .eq('id', lead.id);

      await logActivity({
        actorId: user.id,
        actorEmail: user.email,
        actorRole: userRole,
        eventType: 'credit_repair',
        decision: 'pending',
        summary: `Created credit repair case from lead ${lead.email || lead.id}`,
        contextType: 'credit_case',
        contextId: creditCase.id,
      });

      toast({
        title: 'Credit case created',
        description: 'Opening Credit Fix dashboard...',
      });

      navigate(`/credit-specialist-dashboard?caseId=${creditCase.id}`);
      onActionComplete?.();
    } catch (e: any) {
      console.error('Failed to create credit case', e);
      toast({
        variant: 'destructive',
        title: 'Error creating credit case',
        description: e.message || 'Please try again.',
      });
    } finally {
      setIsStartingCredit(false);
    }
  };

  return (
    <div className="flex gap-2">
      <Button
        variant="outline"
        size="sm"
        onClick={handleStartApplication}
        disabled={isStartingApp}
      >
        {isStartingApp ? (
          <>
            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            Starting...
          </>
        ) : (
          <>
            <FileText className="mr-2 h-4 w-4" />
            Start Fast Track
          </>
        )}
      </Button>
      <Button
        variant="outline"
        size="sm"
        onClick={handleSendToCreditFix}
        disabled={isStartingCredit}
      >
        {isStartingCredit ? (
          <>
            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            Creating...
          </>
        ) : (
          <>
            <Wrench className="mr-2 h-4 w-4" />
            Open Credit Fix Case
          </>
        )}
      </Button>
    </div>
  );
};
