import React, { useEffect, useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { Shield, Play, Square, ChevronDown, Eye, Send } from 'lucide-react';
import { useCallSession } from '@/hooks/useCallSession';
import { SmartEmailerPanel } from './SmartEmailerPanel';
import { SmartSmsPanel } from './SmartSmsPanel';
import { SendInfoModal } from '@/components/dialer/SendInfoModal';
import { ClientWorkspaceDrawer } from '@/components/dialer/ClientWorkspaceDrawer';
import { useUserRoles } from "@/hooks/useUserRoles";
import { canViewRawPii, maskEmail, maskPhone } from "@/lib/masking";
import type { AppRole } from "@/lib/permissions";

type Lead = {
  id: string;
  full_name: string | null;
  business_name: string | null;
  email: string | null;
  phone: string | null;
  status: string | null;
  owner_id: string | null;
  lock_expires_at: string | null;
  call_attempts: number | null;
  last_call_outcome: string | null;
  ai_score: number | null;
  ai_priority: 'A' | 'B' | 'C' | null;
  ai_recommended_path:
    | 'fast_track_funding'
    | 'credit_fix_first'
    | 'hybrid_path'
    | 'do_not_work'
    | null;
  ai_risk_flags: string[] | null;
  lead_list_id: string | null;
};

type LeadList = {
  id: string;
  name: string;
};

const pathLabelMap: Record<string, string> = {
  fast_track_funding: 'Funding First',
  credit_fix_first: 'Credit Fix First',
  hybrid_path: 'Hybrid Path',
  do_not_work: 'Do Not Work',
};

const pathClassMap: Record<string, string> = {
  fast_track_funding: 'bg-emerald-100 text-emerald-700',
  credit_fix_first: 'bg-sky-100 text-sky-700',
  hybrid_path: 'bg-violet-100 text-violet-700',
  do_not_work: 'bg-slate-100 text-slate-500',
};

const priorityClassMap: Record<string, string> = {
  A: 'bg-amber-100 text-amber-800',
  B: 'bg-blue-100 text-blue-700',
  C: 'bg-slate-100 text-slate-600',
};

export const LeadCallQueue: React.FC = () => {
  const { toast } = useToast();
  const [leads, setLeads] = useState<Lead[]>([]);
  const [loading, setLoading] = useState(false);
  const [user, setUser] = useState<any>(null);
  const [shareMode, setShareMode] = useState<'release' | 'split_50_50' | null>(null);
  const [shareMessage, setShareMessage] = useState('');
  const { roles } = useUserRoles();
  const canViewPii = canViewRawPii(((roles as AppRole[]) || []) as AppRole[]);
  
  // Lead list filter
  const [leadLists, setLeadLists] = useState<LeadList[]>([]);
  const [selectedListId, setSelectedListId] = useState<string>('all');
  
  // Send Info & View Info modals
  const [showSendInfo, setShowSendInfo] = useState(false);
  const [showViewInfo, setShowViewInfo] = useState(false);

  // Get current user
  useEffect(() => {
    supabase.auth.getUser().then(({ data }) => setUser(data?.user));
  }, []);

  // Load available lead lists (show ALL lists regardless of status)
  useEffect(() => {
    const loadLists = async () => {
      const { data } = await supabase
        .from('lead_lists')
        .select('id, name, status')
        .order('created_at', { ascending: false })
        .limit(50);
      if (data) setLeadLists(data);
    };
    loadLists();
  }, []);

  const submitShareRequest = async () => {
    if (!shareMode || !user || !currentLead) return;
    const { error } = await supabase.rpc('request_lead_share', {
      p_lead_id: currentLead.id,
      p_from_worker_id: user.id,
      p_type: shareMode,
      p_message: shareMessage || null,
    });
    if (error) {
      console.error(error);
      toast({ variant: 'destructive', title: 'Failed to send request' });
    } else {
      toast({ title: 'Request sent to owner' });
      setShareMode(null);
      setShareMessage('');
    }
  };

  const { active, currentLead, loading: sessionLoading, start, stop, recordOutcome } =
    useCallSession(user?.id ?? null);

  const load = async () => {
    setLoading(true);
    try {
      // Build query
      let query = supabase
        .from('leads')
        .select('*')
        .in('status', ['new', 'assigned', 'no_answer', 'callback'])
        .order('ai_score', { ascending: false, nullsFirst: false })
        .order('created_at', { ascending: true })
        .limit(100);
      
      // Filter by selected list if not "all"
      if (selectedListId !== 'all') {
        query = query.or(`lead_list_id.eq.${selectedListId},list_id.eq.${selectedListId}`);
      }

      const { data, error } = await query;

      if (error) throw error;
      setLeads((data || []) as Lead[]);
    } catch (e: any) {
      console.error('Failed to load leads', e);
      toast({
        variant: 'destructive',
        title: 'Failed to load leads',
        description: e.message || 'Please try again.',
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
  }, [selectedListId]);

  const telHref = (phone: string | null) => {
    if (!phone) return '';
    if (!canViewPii) return '';
    return `tel:${phone.replace(/[^0-9+]/g, '')}`;
  };

  const isOwner = currentLead?.owner_id === user?.id;
  const lockUntil = currentLead?.lock_expires_at
    ? new Date(currentLead.lock_expires_at).toLocaleString()
    : null;

  const displayLead = currentLead || (leads.length > 0 ? leads[0] : null);

  return (
    <section className="rounded-2xl bg-white p-4 shadow-sm sm:p-6">
      {/* Header */}
      <div className="mb-4 flex flex-col items-start justify-between gap-3 sm:flex-row sm:items-center">
        <div>
          <h2 className="text-sm font-semibold text-slate-900">Smart Dialer V3</h2>
          <p className="text-xs text-slate-500">
            Start calling to lock leads automatically. 7-day exclusive window.
          </p>
        </div>
        
        {/* File Selector Dropdown */}
        <div className="flex items-center gap-3 flex-wrap">
          <div className="relative">
            <select
              value={selectedListId}
              onChange={(e) => setSelectedListId(e.target.value)}
              className="appearance-none rounded-lg border border-slate-200 bg-white pl-3 pr-8 py-2 text-xs font-medium text-slate-700 shadow-sm hover:border-slate-300 focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary min-w-[180px]"
            >
              <option value="all">📁 All Lists</option>
              {leadLists.map((list) => (
                <option key={list.id} value={list.id}>
                  📄 {list.name}
                </option>
              ))}
            </select>
            <ChevronDown className="pointer-events-none absolute right-2 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
          </div>
          
        <div className="flex gap-2">
          <button
            type="button"
            onClick={active ? stop : start}
            disabled={sessionLoading}
            className={`inline-flex items-center gap-2 rounded-full px-4 py-2 text-xs font-semibold transition ${
              active
                ? 'bg-rose-100 text-rose-700 border border-rose-300 hover:bg-rose-200'
                : 'bg-emerald-100 text-emerald-700 border border-emerald-300 hover:bg-emerald-200'
            }`}
          >
            {active ? (
              <>
                <Square className="h-3.5 w-3.5" />
                Stop Calling
              </>
            ) : (
              <>
                <Play className="h-3.5 w-3.5" />
                Start Calling
              </>
            )}
          </button>
          <button
            type="button"
            onClick={load}
            className="inline-flex items-center rounded-full border border-slate-300 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50"
          >
            {loading ? (
              <>
                <span className="mr-1 h-3.5 w-3.5 animate-spin rounded-full border border-slate-400 border-t-transparent" />
                Refreshing…
              </>
            ) : (
              <>
                <svg
                  className="mr-1 h-3.5 w-3.5"
                  viewBox="0 0 20 20"
                  fill="none"
                >
                  <path
                    d="M4 4v4h4M16 16v-4h-4M5 11a5 5 0 0 0 8.66 3.54M15 9a5 5 0 0 0-8.66-3.54"
                    stroke="currentColor"
                    strokeWidth="1.5"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                </svg>
                Refresh
              </>
            )}
          </button>
        </div>
        </div>
      </div>

      {/* Body */}
      {!active && !displayLead ? (
        <div className="py-12 text-center">
          <p className="text-xs text-slate-400 mb-3">
            No active call session. Click "Start Calling" to begin.
          </p>
        </div>
      ) : displayLead ? (
        <>
          {/* ACTIVE LEAD PANEL */}
          <div className="mb-6 rounded-xl border-2 border-emerald-500/20 bg-gradient-to-br from-emerald-50 to-white p-5 shadow-lg">
            {/* Ownership Status */}
            {currentLead && (
              <div className="mb-3 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 text-xs">
                <div>
                  {isOwner ? (
                    <p className="text-emerald-700 font-semibold">
                      You own this lead (locked until {lockUntil})
                    </p>
                  ) : currentLead.owner_id ? (
                    <p className="text-slate-600">
                      Locked by another worker until {lockUntil}
                    </p>
                  ) : (
                    <p className="text-slate-500">Unassigned lead</p>
                  )}
                </div>

                {currentLead.owner_id && currentLead.owner_id !== user?.id && (
                  <div className="flex gap-2">
                    <button
                      onClick={() => setShareMode('release')}
                      className="rounded-full border border-slate-300 px-3 py-1 text-[11px] hover:bg-slate-50"
                    >
                      Request Release
                    </button>
                    <button
                      onClick={() => setShareMode('split_50_50')}
                      className="rounded-full border border-amber-300 bg-amber-50 px-3 py-1 text-[11px] text-amber-800 hover:bg-amber-100"
                    >
                      Propose 50/50 Split
                    </button>
                  </div>
                )}
              </div>
            )}

            <div className="mb-3 flex items-center justify-between">
              <h3 className="text-base font-bold text-slate-900">
                📞 {active ? 'Current Lead' : 'Next Lead to Call'}
              </h3>
              {displayLead.call_attempts && displayLead.call_attempts > 0 && (
                <span className="rounded-full bg-amber-100 px-2.5 py-1 text-[10px] font-semibold text-amber-700">
                  Attempt #{displayLead.call_attempts + 1}
                </span>
              )}
            </div>

            <div className="mb-4 space-y-1 text-sm text-slate-700">
              <p className="font-bold text-slate-900">
                {displayLead.full_name || 'Unknown Lead'}
              </p>
              {displayLead.business_name && (
                <p className="text-slate-600">{displayLead.business_name}</p>
              )}
              {displayLead.email && (
                <p className="text-slate-600">{canViewPii ? displayLead.email : maskEmail(displayLead.email)}</p>
              )}
              {displayLead.phone && (
                <p className="font-semibold text-slate-900">{canViewPii ? displayLead.phone : maskPhone(displayLead.phone)}</p>
              )}

              <div className="flex flex-wrap gap-2 pt-2">
                {displayLead.ai_score != null && (
                  <span className="inline-flex items-center rounded-full bg-slate-900 px-2.5 py-1 text-[10px] font-medium text-white">
                    AI Score {Math.round(displayLead.ai_score)}
                  </span>
                )}
                {displayLead.ai_priority && (
                  <span
                    className={
                      'inline-flex items-center rounded-full px-2.5 py-1 text-[10px] font-medium ' +
                      (priorityClassMap[displayLead.ai_priority] ||
                        'bg-slate-100 text-slate-600')
                    }
                  >
                    Priority {displayLead.ai_priority}
                  </span>
                )}
                {displayLead.ai_recommended_path && (
                  <span
                    className={
                      'inline-flex items-center rounded-full px-2.5 py-1 text-[10px] font-medium ' +
                      (pathClassMap[displayLead.ai_recommended_path] ||
                        'bg-emerald-100 text-emerald-700')
                    }
                  >
                    {pathLabelMap[displayLead.ai_recommended_path] ||
                      'Funding First'}
                  </span>
                )}
              </div>
            </div>

            {/* ACTION BUTTONS ROW */}
            <div className="mb-4 flex flex-wrap gap-2">
              {/* Call button */}
              {displayLead.phone && canViewPii ? (
                <a
                  href={telHref(displayLead.phone)}
                  className="inline-flex items-center justify-center gap-1.5 rounded-xl bg-emerald-500 px-4 py-2.5 text-sm font-semibold text-white shadow-sm transition hover:bg-emerald-600 active:scale-95"
                >
                  📞 Call
                </a>
              ) : displayLead.phone ? (
                <button
                  type="button"
                  disabled
                  className="inline-flex items-center justify-center gap-1.5 rounded-xl bg-emerald-500/30 px-4 py-2.5 text-sm font-semibold text-white/80 shadow-sm opacity-60"
                >
                  📞 Call (masked)
                </button>
              ) : null}
              
              {/* Send Info button */}
              <button
                type="button"
                onClick={() => setShowSendInfo(true)}
                className="inline-flex items-center justify-center gap-1.5 rounded-xl bg-sky-500 px-4 py-2.5 text-sm font-semibold text-white shadow-sm transition hover:bg-sky-600 active:scale-95"
              >
                <Send className="h-4 w-4" />
                Send Info
              </button>
              
              {/* View Info button */}
              <button
                type="button"
                onClick={() => setShowViewInfo(true)}
                className="inline-flex items-center justify-center gap-1.5 rounded-xl border border-slate-300 bg-white px-4 py-2.5 text-sm font-semibold text-slate-700 shadow-sm transition hover:bg-slate-50 active:scale-95"
              >
                <Eye className="h-4 w-4" />
                View Info
              </button>
            </div>

            {/* OUTCOME BUTTONS */}
            {active ? (
              <div className="grid grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={() => recordOutcome('interested')}
                  disabled={sessionLoading}
                  className="inline-flex items-center justify-center gap-1.5 rounded-xl bg-emerald-500 px-4 py-3 text-sm font-semibold text-white shadow-sm transition hover:bg-emerald-600 active:scale-95 disabled:opacity-50"
                >
                  ✅ Interested
                </button>

                <button
                  type="button"
                  onClick={() => recordOutcome('not_interested')}
                  disabled={sessionLoading}
                  className="inline-flex items-center justify-center gap-1.5 rounded-xl bg-rose-500 px-4 py-3 text-sm font-semibold text-white shadow-sm transition hover:bg-rose-600 active:scale-95 disabled:opacity-50"
                >
                  🚫 Not Interested
                </button>

                <button
                  type="button"
                  onClick={() => recordOutcome('no_answer')}
                  disabled={sessionLoading}
                  className="inline-flex items-center justify-center gap-1.5 rounded-xl bg-amber-400 px-4 py-3 text-sm font-semibold text-slate-900 shadow-sm transition hover:bg-amber-500 active:scale-95 disabled:opacity-50"
                >
                  ☎️ No Answer
                </button>

                <button
                  type="button"
                  onClick={() => recordOutcome('bad_number')}
                  disabled={sessionLoading}
                  className="inline-flex items-center justify-center gap-1.5 rounded-xl bg-slate-800 px-4 py-3 text-sm font-semibold text-slate-50 shadow-sm transition hover:bg-slate-900 active:scale-95 disabled:opacity-50"
                >
                  ⛔ Bad Number
                </button>
              </div>
            ) : (
              <p className="text-center text-xs text-slate-500 py-4">
                Click "Start Calling" above to begin working this lead
              </p>
            )}
          </div>

          {/* FULL QUEUE LIST */}
          <div>
            <h4 className="mb-2 text-xs font-semibold text-slate-600">
              Up Next ({leads.length - 1} leads in queue)
            </h4>
            <div className="max-h-[400px] space-y-2 overflow-y-auto pr-1">
              {leads.slice(1).map((lead) => {
                const path = lead.ai_recommended_path || 'fast_track_funding';
                const hasRiskFlags =
                  lead.ai_risk_flags && lead.ai_risk_flags.length > 0;

                return (
                  <div
                    key={lead.id}
                    className="flex flex-col gap-2 rounded-xl border border-slate-100 bg-slate-50 px-3 py-2 text-xs text-slate-700 sm:flex-row sm:items-center sm:justify-between"
                  >
                    <div className="space-y-1">
                      <div className="flex flex-wrap items-center gap-1.5">
                        <span className="font-medium">
                          {lead.full_name || 'Unknown lead'}
                        </span>
                        {lead.email && (
                          <span className="text-[11px] text-slate-500">
                            • {lead.email}
                          </span>
                        )}
                      </div>

                      <div className="flex flex-wrap gap-2 text-[11px] text-slate-500">
                        {lead.business_name && <span>{lead.business_name}</span>}
                        {lead.phone && (
                          <span className="text-slate-600">{lead.phone}</span>
                        )}
                      </div>

                      <div className="flex flex-wrap items-center gap-2 pt-1">
                        {lead.ai_score != null && (
                          <span className="inline-flex items-center rounded-full bg-slate-900 px-2 py-0.5 text-[10px] font-medium text-white">
                            AI Score&nbsp;{Math.round(lead.ai_score)}
                          </span>
                        )}

                        {lead.ai_priority && (
                          <span
                            className={
                              'inline-flex items-center rounded-full px-2 py-0.5 text-[10px] font-medium ' +
                              (priorityClassMap[lead.ai_priority] ||
                                'bg-slate-100 text-slate-600')
                            }
                          >
                            Priority&nbsp;{lead.ai_priority}
                          </span>
                        )}

                        <span
                          className={
                            'inline-flex items-center rounded-full px-2 py-0.5 text-[10px] font-medium ' +
                            (pathClassMap[path] ||
                              'bg-emerald-100 text-emerald-700')
                          }
                        >
                          {pathLabelMap[path] || 'Funding First'}
                        </span>

                        {hasRiskFlags && (
                          <span className="inline-flex items-center rounded-full bg-rose-50 px-2 py-0.5 text-[10px] font-medium text-rose-700">
                            ⚠️ {lead.ai_risk_flags!.join(', ')}
                          </span>
                        )}

                        {lead.call_attempts && lead.call_attempts > 0 && (
                          <span className="inline-flex items-center rounded-full bg-amber-100 px-2 py-0.5 text-[10px] font-medium text-amber-700">
                            Attempt #{lead.call_attempts + 1}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </>
      ) : null}

      {/* Share Request Modal */}
      {shareMode && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/30">
          <div className="w-full max-w-md rounded-2xl bg-white p-4 shadow-xl">
            <h3 className="mb-2 text-sm font-semibold text-slate-900">
              {shareMode === 'release' ? 'Request Lead Release' : 'Propose 50/50 Split'}
            </h3>
            <p className="mb-3 text-xs text-slate-600">
              Send a message to the current owner explaining why you'd like this lead.
            </p>
            <textarea
              value={shareMessage}
              onChange={(e) => setShareMessage(e.target.value)}
              placeholder="Optional message..."
              className="mb-3 w-full rounded-xl border border-slate-200 p-2 text-xs"
              rows={3}
            />
            <div className="flex gap-2">
              <button
                onClick={submitShareRequest}
                className="flex-1 rounded-full bg-emerald-500 px-3 py-2 text-xs font-semibold text-white hover:bg-emerald-600"
              >
                Send Request
              </button>
              <button
                onClick={() => {
                  setShareMode(null);
                  setShareMessage('');
                }}
                className="flex-1 rounded-full border border-slate-300 px-3 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Smart SMS Panel */}
      <SmartSmsPanel />

      {/* Smart Emailer Panel at bottom */}
      <SmartEmailerPanel />

      {/* Send Info Modal */}
      {displayLead && (
        <SendInfoModal
          open={showSendInfo}
          onOpenChange={setShowSendInfo}
          lead={displayLead}
          workerId={user?.id || ''}
          onSuccess={() => {
            load();
          }}
        />
      )}

      {/* Client Workspace Drawer */}
      {displayLead && (
        <ClientWorkspaceDrawer
          open={showViewInfo}
          onOpenChange={setShowViewInfo}
          lead={displayLead}
          workerId={user?.id || ''}
        />
      )}
    </section>
  );
};
