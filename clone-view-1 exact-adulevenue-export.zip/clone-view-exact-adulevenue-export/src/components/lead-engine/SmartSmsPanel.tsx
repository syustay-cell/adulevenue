import { useState, useEffect, useCallback } from "react";
import { MessageSquare, Send, SkipForward, RefreshCw, Users } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { useUserRoles } from "@/hooks/useUserRoles";
import { canViewRawPii, maskPhone } from "@/lib/masking";
import type { AppRole } from "@/lib/permissions";

type SmsLead = {
  id: string;
  email: string | null;
  full_name: string | null;
  business_name: string | null;
  phone: string | null;
  ai_score: number | null;
};

export function SmartSmsPanel() {
  const { toast } = useToast();
  const { roles } = useUserRoles();
  const canViewPii = canViewRawPii((roles as AppRole[]) || []);
  const [smsLead, setSmsLead] = useState<SmsLead | null>(null);
  const [queueCount, setQueueCount] = useState(0);
  const [loading, setLoading] = useState(false);
  const [sending, setSending] = useState(false);

  const loadNextSmsLead = useCallback(async () => {
    setLoading(true);
    try {
      // Get SMS-only leads (has phone, no email OR phone_valid = true)
      const { data: leads, error } = await supabase
        .from("leads")
        .select("id, email, full_name, business_name, phone, ai_score")
        .not("phone", "is", null)
        .or("email.is.null,route.eq.sms")
        .eq("status", "new")
        .order("ai_score", { ascending: false, nullsFirst: false })
        .limit(1);

      if (error) throw error;
      setSmsLead(leads?.[0] || null);

      // Get count
      const { count } = await supabase
        .from("leads")
        .select("*", { count: "exact", head: true })
        .not("phone", "is", null)
        .or("email.is.null,route.eq.sms")
        .eq("status", "new");

      setQueueCount(count || 0);
    } catch (e: any) {
      console.error("Failed to load SMS lead:", e);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadNextSmsLead();
  }, [loadNextSmsLead]);

  const handleSendSms = async () => {
    if (!smsLead || !smsLead.phone) return;
    setSending(true);
    try {
      // Call send-smart-sms V6 edge function
      const { data: user } = await supabase.auth.getUser();
      const { error } = await supabase.functions.invoke("send-smart-sms", {
        body: {
          lead_id: smsLead.id,
          template_name: "general_followup_sms",
          to_phone: smsLead.phone,
          reply_in_hours: 24,
          sent_by_user_id: user?.user?.id,
        },
      });

      if (error) throw error;

      toast({
        title: "SMS sent",
        description: `Sent to ${canViewPii ? smsLead.phone : maskPhone(smsLead.phone)}. Follow-up task will be created in 24h if no reply.`,
      });
      await loadNextSmsLead();
    } catch (e: any) {
      console.error("Send SMS failed:", e);
      toast({
        variant: "destructive",
        title: "SMS failed",
        description: e.message || "Please try again.",
      });
    } finally {
      setSending(false);
    }
  };

  const handleSkip = async () => {
    if (!smsLead) return;
    await loadNextSmsLead();
    toast({
      title: "Skipped",
      description: "Moving to next SMS lead",
    });
  };

  return (
    <div className="border-t border-border bg-card/50 px-4 py-3">
      <div className="mb-2 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <MessageSquare className="h-4 w-4 text-emerald-600" />
          <span className="text-xs font-semibold uppercase text-muted-foreground">
            Smart SMS
          </span>
          <Badge variant="secondary" className="text-[10px]">
            <Users className="mr-1 h-3 w-3" />
            {queueCount} in queue
          </Badge>
        </div>
        <Button
          variant="ghost"
          size="sm"
          onClick={loadNextSmsLead}
          disabled={loading}
          className="h-6 px-2"
        >
          <RefreshCw className={`h-3 w-3 ${loading ? "animate-spin" : ""}`} />
        </Button>
      </div>

      {loading && !smsLead?.id ? (
        <div className="text-xs text-muted-foreground">Loading SMS queue...</div>
      ) : !smsLead?.id ? (
        <div className="rounded-lg border border-dashed border-border bg-muted/30 p-3 text-center text-xs text-muted-foreground">
          No SMS-only leads in queue. Upload lists with mobile numbers to get started.
        </div>
      ) : (
        <div className="flex items-center justify-between rounded-lg border border-border bg-card p-3">
          <div className="flex-1 min-w-0">
            <div className="font-medium text-sm truncate">
              {smsLead.business_name || "Unknown Business"}
            </div>
            <div className="text-xs text-muted-foreground truncate">
              {smsLead.full_name || "No contact"} · {canViewPii ? smsLead.phone : maskPhone(smsLead.phone)}
            </div>
            {smsLead.ai_score && (
              <Badge variant="outline" className="mt-1 text-[10px]">
                Score: {smsLead.ai_score}
              </Badge>
            )}
          </div>
          <div className="flex gap-2 ml-3">
            <Button
              variant="outline"
              size="sm"
              onClick={handleSkip}
              disabled={sending}
              className="h-8"
            >
              <SkipForward className="h-3 w-3" />
            </Button>
            <Button
              size="sm"
              onClick={handleSendSms}
              disabled={sending}
              className="h-8 bg-emerald-600 hover:bg-emerald-700"
            >
              {sending ? (
                <RefreshCw className="h-3 w-3 animate-spin mr-1" />
              ) : (
                <Send className="h-3 w-3 mr-1" />
              )}
              {sending ? "Sending..." : "Send SMS"}
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}
