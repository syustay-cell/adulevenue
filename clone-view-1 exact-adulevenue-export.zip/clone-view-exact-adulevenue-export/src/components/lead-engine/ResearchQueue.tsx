import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { ExternalLink, Search, Sparkles, FileText } from 'lucide-react';
import type { Database } from '@/integrations/supabase/types';
import { runResearchIntel, ResearchProfile, ResearchResult } from '@/lib/api/researchIntel';
import { ResearchProfileDrawer } from './ResearchProfileDrawer';
import { LeadProfileDrawer } from './LeadProfileDrawer';

type LeadRow = Database['public']['Tables']['leads']['Row'];

export const ResearchQueue: React.FC = () => {
  const { toast } = useToast();
  const [current, setCurrent] = useState<LeadRow | null>(null);
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [website, setWebsite] = useState('');
  const [notes, setNotes] = useState('');
  const [loading, setLoading] = useState(false);
  const [userId, setUserId] = useState<string | null>(null);
  const [researchProfile, setResearchProfile] = useState<ResearchProfile | null>(null);
  const [researchLoading, setResearchLoading] = useState(false);
  const [showResearchDrawer, setShowResearchDrawer] = useState(false);
  const [showProfileDrawer, setShowProfileDrawer] = useState(false);

  // Get current user ID on mount
  useEffect(() => {
    supabase.auth.getUser().then(({ data }) => {
      setUserId(data.user?.id ?? null);
    });
  }, []);

  const normalizePhone = (value: string) => {
    const digits = value.replace(/[^0-9+]/g, '');
    return digits.length >= 10 ? digits : '';
  };

  const handleRunResearchQ = async () => {
    if (!current) return;

    try {
      setResearchLoading(true);
      const result: ResearchResult = await runResearchIntel(current.id);
      
      // Store the profile from the result
      setResearchProfile(result.profile);
      setShowResearchDrawer(true);
      
      // Auto-populate fields with enriched data
      const enriched = result.profile.enriched;
      if (enriched?.phone && !phone) {
        setPhone(enriched.phone);
      }
      if (enriched?.email && !email) {
        setEmail(enriched.email);
      }
      if (enriched?.website && !website) {
        setWebsite(enriched.website);
      }
      
      // Show recommendation badge
      const recLabel = {
        funding_first: "Funding First",
        credit_first: "Credit First",
        hybrid: "Hybrid Path",
        do_not_work: "Do Not Work"
      }[result.profile.funding_recommendation] || "Unknown";
      
      toast({
        title: "AI Research Complete",
        description: `Score: ${result.profile.funding_score}/100 — ${recLabel}`,
      });
    } catch (error: any) {
      console.error("Research Q failed:", error);
      toast({
        variant: "destructive",
        title: "Research Failed",
        description: error.message || "Please try again.",
      });
    } finally {
      setResearchLoading(false);
    }
  };

  const loadNext = async () => {
    if (!userId) {
      toast({
        variant: 'destructive',
        title: 'Authentication required',
        description: 'Please log in to claim leads.',
      });
      return;
    }

    setLoading(true);
    try {
      const { data, error } = await supabase.rpc('claim_next_research_lead', {
        p_worker_id: userId,
      });

      if (error) throw error;

      let lead = data as LeadRow | null;

      // Fallback: if RPC returns null, query directly from leads
      // Support both V3 import_bucket and legacy route field
      if (!lead) {
        const { data: fallback, error: fallbackError } = await supabase
          .from('leads')
          .select('*')
          .or('import_bucket.eq.research,route.eq.research')
          .in('research_status', ['pending', null])
          .eq('status', 'new')
          .order('import_confidence_score', { ascending: true, nullsFirst: true })
          .order('created_at', { ascending: true })
          .limit(1)
          .maybeSingle();

        if (fallbackError) throw fallbackError;
        lead = (fallback as LeadRow | null) ?? null;
      }

      if (!lead) {
        toast({
          title: 'No leads available',
          description: 'Research queue is empty. Check back later.',
        });
        setCurrent(null);
        return;
      }

      setCurrent(lead);
      setPhone(lead.phone || '');
      setEmail(lead.email || '');
      // Extract website from raw_data if present
      const rawData = lead.raw_data as any;
      setWebsite(
        rawData?.raw_website || rawData?.website || rawData?.col_website || ''
      );
      setNotes(lead.research_notes || '');
    } catch (e: any) {
      console.error('[ResearchQueue] loadNext error:', e);
      toast({
        variant: 'destructive',
        title: 'Failed to load lead',
        description: e.message || 'Please try again.',
      });
    } finally {
      setLoading(false);
    }
  };

  const updateLead = async (updates: any) => {
    if (!current) return;
    setLoading(true);
    try {
      const { error } = await supabase
        .from('leads')
        .update({
          ...updates,
          research_notes: notes || null,
          updated_at: new Date().toISOString(),
        })
        .eq('id', current.id);

      if (error) throw error;

      toast({
        title: 'Lead updated',
        description: 'Successfully routed to the next queue.',
      });

      // Auto-load next lead
      await loadNext();
    } catch (e: any) {
      console.error('[ResearchQueue] updateLead error:', e);
      toast({
        variant: 'destructive',
        title: 'Failed to save lead',
        description: e.message || 'Please try again.',
      });
    } finally {
      setLoading(false);
    }
  };

  const handleToDialer = () => {
    if (!phone) {
      toast({
        variant: 'destructive',
        title: 'Phone required',
        description: 'You must add a phone number to route to dialer.',
      });
      return;
    }
    updateLead({
      phone: normalizePhone(phone),
      email: email || null,
      route: 'dialer',
      import_bucket: 'dialer',
      status: 'new',
      dialer_status: 'new',
      research_status: 'done',
      research_completed_at: new Date().toISOString(),
      missing_phone: false,
      phone_invalid: false, // Clear invalid flag
      missing_email: !email,
    });
  };

  const handleToEmail = () => {
    if (!email) {
      toast({
        variant: 'destructive',
        title: 'Email required',
        description: 'You must add an email to route to email queue.',
      });
      return;
    }
    updateLead({
      phone: normalizePhone(phone) || null,
      email: email || null,
      route: 'email',
      import_bucket: 'email',
      status: 'new',
      email_status: 'pending',
      research_status: 'done',
      research_completed_at: new Date().toISOString(),
      missing_phone: !phone,
      missing_email: false,
      email_invalid: false, // Clear invalid flag
    });
  };

  const handleCannotFind = () => {
    if (!notes.trim()) {
      toast({
        variant: 'destructive',
        title: 'Note required',
        description: 'Please add a note explaining why contact info cannot be found.',
      });
      return;
    }
    updateLead({
      research_status: 'cannot_find',
      status: 'disqualified',
      research_completed_at: new Date().toISOString(),
    });
  };

  // Extract city/state from raw_data or lead fields
  const rawData = current?.raw_data as any;
  const city = (current as any)?.city || rawData?.raw_city || rawData?.city || rawData?.City || '';
  const state = (current as any)?.state || rawData?.raw_state || rawData?.state || rawData?.State || '';

  // Build best-guess person name for TruePeopleSearch
  const ownerFullName =
    rawData?.["Owner Full Name"] ||
    (current as any)?.owner_full_name ||
    `${rawData?.["Owner First Name"] || (current as any)?.owner_first_name || ""} ${rawData?.["Owner Last Name"] || (current as any)?.owner_last_name || ""}`.trim();

  const personName =
    ownerFullName ||
    current?.full_name ||
    (current as any)?.contact_name ||
    current?.business_name ||
    "";

  // Determine if we have enough data to enable TruePeopleSearch
  const hasTruePeopleData = !!personName && !!state;

  // Handler to open TruePeopleSearch in new tab
  const handleOpenTruePeopleSearch = () => {
    if (!personName || !state) {
      toast({
        variant: "destructive",
        title: "Missing data",
        description: "Need at least a name and state to search TruePeopleSearch.",
      });
      return;
    }

    const baseUrl = "https://www.truepeoplesearch.com/results";
    const params = new URLSearchParams({
      name: personName,
      state: state,
    });

    const url = `${baseUrl}?${params.toString()}`;
    window.open(url, "_blank");

    // Optional: log action (fire-and-forget)
    if (userId && current?.id) {
      supabase
        .from("lead_events")
        .insert({
          lead_id: current.id,
          event_type: "truepeople_open",
          created_by: userId,
          metadata: { personName, state, city },
        });
    }
  };

  // Empty state
  if (!current) {
    return (
      <div className="rounded-2xl bg-card p-6 shadow-sm border border-border">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-lg font-semibold text-foreground flex items-center gap-2">
              <Search className="w-5 h-5" />
              Research Queue
            </h2>
            <p className="text-sm text-muted-foreground mt-1">
              Find missing phones/emails and route leads to the right queue.
            </p>
          </div>
          <Button onClick={loadNext} disabled={loading} size="sm">
            {loading ? 'Loading…' : 'Start Research'}
          </Button>
        </div>
        <div className="mt-6 p-4 border border-dashed border-border rounded-lg text-center">
          <p className="text-sm text-muted-foreground">
            No lead loaded. Click "Start Research" to claim the next lead.
          </p>
        </div>
      </div>
    );
  }

  const searchQuery = `${current.business_name || ''} ${city} ${state}`.trim();

  return (
    <div className="rounded-2xl bg-card p-6 shadow-sm border border-border space-y-6">
      {/* Header */}
      <div className="flex items-start justify-between">
        <div>
          <h2 className="text-lg font-semibold text-foreground flex items-center gap-2">
            <Search className="w-5 h-5" />
            Research Lead
          </h2>
          <p className="text-sm text-muted-foreground mt-1">
            {current.business_name || 'Unknown business'} {city && state && `— ${city}, ${state}`}
          </p>
        </div>
        <Button onClick={loadNext} disabled={loading} variant="outline" size="sm">
          {loading ? 'Loading…' : 'Skip / Next'}
        </Button>
      </div>

      {/* Lead Info Tags - Bounce-back chips */}
      <div className="flex flex-wrap gap-2">
        {(current as any).phone_invalid && (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-rose-500/20 text-rose-400 border border-rose-500/30">
            📵 Phone Invalid (from Dialer)
          </span>
        )}
        {(current as any).email_invalid && (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-rose-500/20 text-rose-400 border border-rose-500/30">
            📧 Email Bounced
          </span>
        )}
        {((current as any).missing_phone || !current.phone) && !(current as any).phone_invalid && (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-amber-500/20 text-amber-400 border border-amber-500/30">
            Missing Phone
          </span>
        )}
        {((current as any).missing_email || !current.email) && !(current as any).email_invalid && (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-amber-500/20 text-amber-400 border border-amber-500/30">
            Missing Email
          </span>
        )}
        {(current as any).last_dial_disposition && (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-slate-500/20 text-slate-400 border border-slate-500/30">
            Last: {(current as any).last_dial_disposition?.replace(/_/g, ' ')}
          </span>
        )}
        {(current as any).dial_attempts > 0 && (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-500/20 text-blue-400 border border-blue-500/30">
            {(current as any).dial_attempts} dial attempts
          </span>
        )}
        {current.full_name && (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-muted text-muted-foreground">
            Contact: {current.full_name}
          </span>
        )}
      </div>

      {/* Input Fields */}
      <div className="grid gap-4 sm:grid-cols-3">
        <div>
          <label className="block text-sm font-medium text-foreground mb-1.5">
            Phone
          </label>
          <Input
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
            placeholder="Enter phone number"
            className="text-sm"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-foreground mb-1.5">
            Email
          </label>
          <Input
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="Enter email"
            className="text-sm"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-foreground mb-1.5">
            Website
          </label>
          <Input
            value={website}
            onChange={(e) => setWebsite(e.target.value)}
            placeholder="Enter website"
            className="text-sm"
          />
        </div>
      </div>

      {/* Notes */}
      <div>
        <label className="block text-sm font-medium text-foreground mb-1.5">
          Research Notes
        </label>
        <Textarea
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
          placeholder="Add notes about your research..."
          className="text-sm"
          rows={3}
        />
      </div>

      {/* AI Research Button */}
      <div className="pt-2 pb-4 border-y border-border">
        <Button
          onClick={handleRunResearchQ}
          disabled={researchLoading}
          className="w-full bg-gradient-to-r from-emerald-600 to-sky-600 hover:from-emerald-700 hover:to-sky-700 text-white font-semibold shadow-lg"
          size="lg"
        >
          <Sparkles className="h-4 w-4 mr-2" />
          {researchLoading ? "AI Analyzing..." : "🔍 AI Research Spider — Find Contact Info"}
        </Button>
        <p className="text-xs text-muted-foreground mt-2 text-center">
          AI searches public records to find phone, email, website, owner name & funding eligibility
        </p>
      </div>

      {/* Quick Search Links */}
      <div className="flex flex-wrap gap-2">
        <button
          onClick={() => setShowProfileDrawer(true)}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-primary bg-primary/10 hover:bg-primary/20 text-sm font-medium transition-colors text-primary"
        >
          <FileText className="w-3.5 h-3.5" />
          View Full Profile
        </button>
        <a
          href={`https://www.google.com/search?q=${encodeURIComponent(searchQuery)}`}
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-border bg-background hover:bg-accent text-sm font-medium transition-colors"
        >
          <ExternalLink className="w-3.5 h-3.5" />
          Google Search
        </a>
        {website && (
          <a
            href={website.startsWith('http') ? website : `https://${website}`}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-border bg-background hover:bg-accent text-sm font-medium transition-colors"
          >
            <ExternalLink className="w-3.5 h-3.5" />
            Open Website
          </a>
        )}
        <a
          href={`https://www.linkedin.com/search/results/all/?keywords=${encodeURIComponent(current.business_name || '')}`}
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-border bg-background hover:bg-accent text-sm font-medium transition-colors"
        >
          <ExternalLink className="w-3.5 h-3.5" />
          LinkedIn Search
        </a>
        <button
          onClick={handleOpenTruePeopleSearch}
          disabled={!hasTruePeopleData}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-border bg-background hover:bg-accent text-sm font-medium transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          title={hasTruePeopleData ? `Search for ${personName} in ${state}` : "Need name + state"}
        >
          <Search className="w-3.5 h-3.5" />
          TruePeopleSearch
        </button>
      </div>

      {/* Action Buttons */}
      <div className="grid gap-3 sm:grid-cols-3 pt-4 border-t border-border">
        <Button
          onClick={handleToDialer}
          disabled={loading || !phone}
          className="w-full bg-emerald-600 hover:bg-emerald-700 text-white"
        >
          Save & Send to Dialer
        </Button>
        <Button
          onClick={handleToEmail}
          disabled={loading || !email}
          className="w-full bg-sky-600 hover:bg-sky-700 text-white"
        >
          Save & Send to Email
        </Button>
        <Button
          onClick={handleCannotFind}
          disabled={loading}
          variant="secondary"
          className="w-full"
        >
          Cannot Find Info
        </Button>
      </div>

      {/* Research Profile Drawer */}
      {showResearchDrawer && researchProfile && current && (
        <ResearchProfileDrawer
          profile={researchProfile}
          leadName={current.full_name || current.business_name || "Unknown Lead"}
          onClose={() => setShowResearchDrawer(false)}
          onCallNow={() => {
            const phoneToCall = researchProfile.enriched?.phone || phone || current.phone;
            if (phoneToCall) {
              window.location.href = `tel:${phoneToCall.replace(/[^0-9+]/g, '')}`;
            }
          }}
          onSendFundingLink={() => {
            toast({
              title: "Funding Link",
              description: "Funding application link feature coming soon.",
            });
          }}
          onMoveToCredit={() => {
            toast({
              title: "Move to Credit",
              description: "Credit repair transfer feature coming soon.",
            });
          }}
          onArchive={() => {
            handleCannotFind();
            setShowResearchDrawer(false);
          }}
        />
      )}

      {/* Full Lead Profile Drawer */}
      <LeadProfileDrawer
        open={showProfileDrawer}
        onOpenChange={setShowProfileDrawer}
        lead={current}
        onEnrichmentComplete={() => loadNext()}
      />
    </div>
  );
};
