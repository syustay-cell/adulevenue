import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Phone, Mail, MessageSquare, Lightbulb, Shield, Loader2 } from "lucide-react";

interface OutreachScriptDialogProps {
  leadId: string;
  leadName: string;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function OutreachScriptDialog({ leadId, leadName, open, onOpenChange }: OutreachScriptDialogProps) {
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [scripts, setScripts] = useState<any>(null);

  const generateScripts = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('ai-draft-outreach', {
        body: { leadId }
      });

      if (error) throw error;

      setScripts(data);
      toast({
        title: "Scripts generated!",
        description: "AI has created personalized outreach for this lead",
      });
    } catch (error: any) {
      console.error('Script generation error:', error);
      toast({
        title: "Generation failed",
        description: error.message,
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const copyToClipboard = (text: string, type: string) => {
    navigator.clipboard.writeText(text);
    toast({
      title: "Copied!",
      description: `${type} copied to clipboard`,
    });
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>AI Outreach Scripts</DialogTitle>
          <DialogDescription>
            Personalized outreach content for {leadName}
          </DialogDescription>
        </DialogHeader>

        {!scripts ? (
          <div className="py-12 text-center space-y-4">
            <p className="text-muted-foreground">
              Generate AI-powered call scripts, emails, and talking points customized for this lead
            </p>
            <Button onClick={generateScripts} disabled={loading} size="lg">
              {loading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Generating...
                </>
              ) : (
                <>
                  <Lightbulb className="mr-2 h-4 w-4" />
                  Generate Scripts
                </>
              )}
            </Button>
          </div>
        ) : (
          <Tabs defaultValue="call" className="w-full">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="call">
                <Phone className="mr-2 h-4 w-4" />
                Call
              </TabsTrigger>
              <TabsTrigger value="email">
                <Mail className="mr-2 h-4 w-4" />
                Email
              </TabsTrigger>
              <TabsTrigger value="sms">
                <MessageSquare className="mr-2 h-4 w-4" />
                SMS
              </TabsTrigger>
              <TabsTrigger value="tips">
                <Shield className="mr-2 h-4 w-4" />
                Tips
              </TabsTrigger>
            </TabsList>

            <TabsContent value="call" className="space-y-4 mt-4">
              <Card>
                <CardContent className="pt-6 space-y-4">
                  <div>
                    <h3 className="font-semibold mb-2">Call Script</h3>
                    <p className="text-sm whitespace-pre-wrap text-muted-foreground">
                      {scripts.call_script}
                    </p>
                  </div>
                  <Button 
                    onClick={() => copyToClipboard(scripts.call_script, 'Call script')}
                    variant="outline"
                    size="sm"
                  >
                    Copy Script
                  </Button>
                </CardContent>
              </Card>

              {scripts.talking_points && scripts.talking_points.length > 0 && (
                <Card>
                  <CardContent className="pt-6">
                    <h3 className="font-semibold mb-2">Talking Points</h3>
                    <ul className="space-y-2 text-sm text-muted-foreground">
                      {scripts.talking_points.map((point: string, i: number) => (
                        <li key={i} className="flex items-start gap-2">
                          <span className="text-primary">•</span>
                          <span>{point}</span>
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>
              )}
            </TabsContent>

            <TabsContent value="email" className="space-y-4 mt-4">
              <Card>
                <CardContent className="pt-6 space-y-4">
                  <div>
                    <h3 className="font-semibold mb-2">Subject Line</h3>
                    <p className="text-sm text-muted-foreground">
                      {scripts.email_subject}
                    </p>
                  </div>
                  <Button 
                    onClick={() => copyToClipboard(scripts.email_subject, 'Subject')}
                    variant="outline"
                    size="sm"
                  >
                    Copy Subject
                  </Button>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="pt-6 space-y-4">
                  <div>
                    <h3 className="font-semibold mb-2">Email Body</h3>
                    <p className="text-sm whitespace-pre-wrap text-muted-foreground">
                      {scripts.email_body}
                    </p>
                  </div>
                  <Button 
                    onClick={() => copyToClipboard(scripts.email_body, 'Email body')}
                    variant="outline"
                    size="sm"
                  >
                    Copy Email
                  </Button>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="sms" className="space-y-4 mt-4">
              <Card>
                <CardContent className="pt-6 space-y-4">
                  <div>
                    <h3 className="font-semibold mb-2">SMS Message</h3>
                    <p className="text-sm text-muted-foreground">
                      {scripts.sms_message}
                    </p>
                    <p className="text-xs text-muted-foreground mt-2">
                      Character count: {scripts.sms_message?.length || 0}/160
                    </p>
                  </div>
                  <Button 
                    onClick={() => copyToClipboard(scripts.sms_message, 'SMS message')}
                    variant="outline"
                    size="sm"
                  >
                    Copy SMS
                  </Button>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="tips" className="space-y-4 mt-4">
              {scripts.objection_handlers && scripts.objection_handlers.length > 0 && (
                <Card>
                  <CardContent className="pt-6">
                    <h3 className="font-semibold mb-3">Objection Handlers</h3>
                    <div className="space-y-3">
                      {scripts.objection_handlers.map((handler: string, i: number) => (
                        <div key={i} className="text-sm">
                          <p className="text-muted-foreground">{handler}</p>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              )}

              <Card className="bg-amber-50 dark:bg-amber-950/20 border-amber-200 dark:border-amber-800">
                <CardContent className="pt-6">
                  <h3 className="font-semibold mb-2 flex items-center gap-2">
                    <Shield className="h-4 w-4" />
                    Best Practices
                  </h3>
                  <ul className="space-y-2 text-sm text-muted-foreground">
                    <li>• Build rapport before pitching</li>
                    <li>• Listen more than you talk</li>
                    <li>• Ask open-ended questions</li>
                    <li>• Focus on solving their problems</li>
                    <li>• Always end with a clear next step</li>
                  </ul>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        )}
      </DialogContent>
    </Dialog>
  );
}
