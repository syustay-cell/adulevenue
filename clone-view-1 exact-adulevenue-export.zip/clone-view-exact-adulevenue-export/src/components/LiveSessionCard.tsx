// src/components/LiveSessionCard.tsx
// V11 / B200: Live session card for monitor tab

import React from "react";
import { RiskIndicator } from "./RiskIndicator";
import { formatDuration } from "@/lib/wolfAnalytics";
import { Badge } from "@/components/ui/badge";

interface LiveSessionCardProps {
  session: {
    id: string;
    user_id: string;
    user_email: string | null;
    device_id: string | null;
    portal: string;
    last_seen_at: string;
    started_at: string;
    expires_at: string | null;
    status: string;
    analytics: {
      heartbeat_count: number;
      idle_seconds: number | null;
      duration_seconds: number | null;
      risk_level: string;
    };
    correlation: {
      combined_risk_score: number;
      risk_sources: any[];
    };
  };
}

export const LiveSessionCard: React.FC<LiveSessionCardProps> = ({ session }) => {
  const {
    id,
    user_email,
    portal,
    last_seen_at,
    started_at,
    analytics,
    correlation,
  } = session;

  const durationSec = analytics?.duration_seconds ?? null;
  const idleSec = analytics?.idle_seconds ?? null;
  const hbCount = analytics?.heartbeat_count ?? 0;
  const score = correlation?.combined_risk_score ?? 0;

  return (
    <div className="border rounded-md p-3 mb-2 bg-card shadow-sm">
      <div className="flex justify-between items-center mb-1">
        <div className="text-xs text-muted-foreground truncate">
          Session <span className="font-mono">{id.slice(0, 8)}...</span>
        </div>
        <RiskIndicator score={score} />
      </div>
      <div className="text-sm font-medium">
        {user_email || "Unknown user"}
      </div>
      <div className="flex items-center gap-2 mb-2">
        <Badge variant="outline" className="text-xs capitalize">{portal}</Badge>
      </div>

      <div className="grid grid-cols-2 gap-2 text-xs">
        <div>
          <div className="text-muted-foreground">Started</div>
          <div className="font-mono">
            {started_at ? new Date(started_at).toLocaleTimeString() : "–"}
          </div>
        </div>
        <div>
          <div className="text-muted-foreground">Last seen</div>
          <div className="font-mono">
            {last_seen_at ? new Date(last_seen_at).toLocaleTimeString() : "–"}
          </div>
        </div>
        <div>
          <div className="text-muted-foreground">Duration</div>
          <div>{formatDuration(durationSec)}</div>
        </div>
        <div>
          <div className="text-muted-foreground">Idle</div>
          <div>{formatDuration(idleSec)}</div>
        </div>
        <div>
          <div className="text-muted-foreground">Heartbeats</div>
          <div>{hbCount}</div>
        </div>
      </div>
    </div>
  );
};
