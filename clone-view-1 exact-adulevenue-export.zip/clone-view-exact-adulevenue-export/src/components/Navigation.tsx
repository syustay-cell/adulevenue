import { Link, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Menu, X, Phone, User, LogOut, HardHat } from "lucide-react";
import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { GlobalModeIndicator } from "@/components/GlobalModeIndicator";

const Navigation = () => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [user, setUser] = useState<any>(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const [isWorker, setIsWorker] = useState(false);
  const [isIso, setIsIso] = useState(false);
  const [isCreditSpecialist, setIsCreditSpecialist] = useState(false);
  const [hasABGAccess, setHasABGAccess] = useState(false);
  const { toast } = useToast();
  const navigate = useNavigate();

  useEffect(() => {
    // Get initial session
    supabase.auth.getSession().then(({ data: { session } }) => {
      setUser(session?.user ?? null);
      if (session?.user) {
        checkAdminStatus(session.user.id);
      }
    });

    // Listen for auth changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange((event, session) => {
      setUser(session?.user ?? null);
      if (session?.user) {
        checkAdminStatus(session.user.id);
      } else {
        setIsAdmin(false);
      }
    });

    return () => subscription.unsubscribe();
  }, []);

  const checkAdminStatus = async (userId: string) => {
    const { data: roles } = await supabase
      .from("user_roles")
      .select("role, approved")
      .eq("user_id", userId)
      .eq("approved", true);
    
    setIsAdmin(
      roles?.some(
        (r) => r.role === "admin" || r.role === "owner" || r.role === "super_owner" || r.role === "tenant_admin",
      ) || false,
    );
    setIsWorker(roles?.some(r => r.role === 'worker') || false);
    setIsIso(roles?.some(r => (r.role as string) === 'iso_partner') || false);
    setIsCreditSpecialist(
      roles?.some(
        (r) =>
          r.role === "credit_repair_specialist" ||
          r.role === "admin" ||
          r.role === "owner" ||
          r.role === "super_owner",
      ) || false,
    );

    // Check ABG tenant membership — independent of Wolf Fund roles
    const { data: abgMembership } = await supabase
      .from('wf_tenant_users')
      .select('id, wf_tenants!inner(slug)')
      .eq('user_id', userId)
      .eq('wf_tenants.slug', 'abg')
      .maybeSingle();
    setHasABGAccess(!!abgMembership);
  };

  const handleSignOut = async () => {
    try {
      await supabase.auth.signOut();
      toast({
        title: "Signed out",
        description: "You've been successfully signed out.",
      });
      navigate('/');
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Error",
        description: error.message || "Failed to sign out",
      });
    }
  };

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-background/95 backdrop-blur-sm border-b border-border">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-20">
          {/* Logo + Mode Indicator */}
          <div className="flex items-center gap-3">
            <Link to="/" className="flex items-center gap-2 group">
              <div className="text-4xl transition-transform group-hover:scale-110">🐺</div>
              <div className="flex flex-col">
                <span className="text-2xl font-bold text-primary tracking-tight">WOLF FUND</span>
                <span className="text-xs text-muted-foreground tracking-widest">CAPITAL</span>
              </div>
            </Link>
            {/* Global Mode Indicator - visible to all */}
            <GlobalModeIndicator />
          </div>

          {/* Desktop Navigation */}
          <div className="hidden lg:flex items-center gap-8">
            <Link to="/services" className="text-foreground hover:text-primary transition-colors">
              Services
            </Link>
            <Link to="/how-it-works" className="text-foreground hover:text-primary transition-colors">
              How It Works
            </Link>
            <Link to="/contact" className="text-foreground hover:text-primary transition-colors">
              Contact
            </Link>
            <Link to="/credit-repair-application" className="text-foreground hover:text-primary transition-colors">
              Credit Repair
            </Link>
            <Link to="/membership" className="text-foreground hover:text-primary transition-colors font-semibold">
              Membership
            </Link>
            {isAdmin && (
              <Link to="/lead-engine/v4" className="text-foreground hover:text-primary transition-colors">
                Lead Engine
              </Link>
            )}
            {(isAdmin || isWorker) && (
              <Link to="/worker/queue" className="text-foreground hover:text-primary transition-colors">
                Dialer
              </Link>
            )}
            <a href="tel:+16468269799" className="flex items-center gap-2 text-primary font-semibold hover:text-primary/80 transition-colors">
              <Phone size={18} />
              <span>Call Now</span>
            </a>
            {user ? (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" size="lg" className="gap-2">
                    <User size={18} />
                    <span>Account</span>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuItem className="text-sm text-muted-foreground cursor-default">
                    {user.email}
                  </DropdownMenuItem>

                  {/* ABG Portal switch — always visible if user has ABG access */}
                  {hasABGAccess && (
                    <>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem
                        onClick={() => navigate('/abg/portal/today')}
                        className="cursor-pointer font-semibold gap-2"
                        style={{ color: '#4A8DB7' }}
                      >
                        <HardHat size={15} />
                        Switch to ABG Portal
                      </DropdownMenuItem>
                      <DropdownMenuSeparator />
                    </>
                  )}

                  {isWorker && (
                    <DropdownMenuItem 
                      onClick={() => navigate("/worker/dashboard")} 
                      className="cursor-pointer"
                    >
                      Worker / ISO Portal
                    </DropdownMenuItem>
                  )}
                  {isWorker && (
                    <DropdownMenuItem 
                      onClick={() => navigate('/worker/leads')} 
                      className="cursor-pointer"
                    >
                      Lead Mining
                    </DropdownMenuItem>
                  )}
                  {isIso && (
                    <DropdownMenuItem 
                      onClick={() => navigate('/iso/dashboard')} 
                      className="cursor-pointer"
                    >
                      ISO Portal
                    </DropdownMenuItem>
                  )}
                  {isCreditSpecialist && (
                    <DropdownMenuItem 
                      onClick={() => navigate("/credit-fix/studio")} 
                      className="cursor-pointer"
                    >
                      Credit Fix Studio
                    </DropdownMenuItem>
                  )}
                  {isCreditSpecialist && (
                    <DropdownMenuItem 
                      onClick={() => navigate("/credit-fix/cases")} 
                      className="cursor-pointer"
                    >
                      Credit Fix Dashboard
                    </DropdownMenuItem>
                  )}
                  {isAdmin && (
                    <DropdownMenuItem 
                      onClick={() => navigate("/owner/motherboard")} 
                      className="cursor-pointer"
                    >
                      Owner Dashboard
                    </DropdownMenuItem>
                  )}
                  {isAdmin && (
                    <DropdownMenuItem 
                      onClick={() => navigate("/admin/dashboard")} 
                      className="cursor-pointer"
                    >
                      Admin Dashboard
                    </DropdownMenuItem>
                  )}
                  {isAdmin && (
                    <DropdownMenuItem 
                      onClick={() => navigate("/admin/underwriting")} 
                      className="cursor-pointer font-semibold text-primary"
                    >
                      🔥 Underwriting
                    </DropdownMenuItem>
                  )}
                  {isAdmin && (
                    <DropdownMenuItem 
                      onClick={() => navigate('/owner/motherboard')} 
                      className="cursor-pointer font-semibold text-amber-600"
                    >
                      ⚡ Gods Mode (555)
                    </DropdownMenuItem>
                  )}
                  {isAdmin && (
                    <DropdownMenuItem 
                      onClick={() => navigate("/admin/credit-desk")} 
                      className="cursor-pointer"
                    >
                      Credit Clean Desk
                    </DropdownMenuItem>
                  )}
                  {isAdmin && (
                    <DropdownMenuItem 
                      onClick={() => navigate("/lead-engine/v4")} 
                      className="cursor-pointer"
                    >
                      Lead Engine
                    </DropdownMenuItem>
                  )}
                  {(isAdmin || isWorker) && (
                    <DropdownMenuItem 
                      onClick={() => navigate("/worker/queue")} 
                      className="cursor-pointer"
                    >
                      Dialer
                    </DropdownMenuItem>
                  )}
                  <DropdownMenuItem onClick={handleSignOut} className="gap-2 cursor-pointer">
                    <LogOut size={16} />
                    Sign Out
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            ) : (
              <Button asChild size="lg" variant="outline">
                <Link to="/auth">Sign In</Link>
              </Button>
            )}
            <Button asChild size="lg" className="bg-primary text-primary-foreground hover:bg-primary/90">
              <Link to="/apply">Apply Now</Link>
            </Button>
          </div>

          {/* Mobile Menu Button */}
          <button
            className="lg:hidden text-foreground p-2"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            aria-label="Toggle menu"
          >
            {mobileMenuOpen ? <X size={28} /> : <Menu size={28} />}
          </button>
        </div>

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <div className="lg:hidden border-t border-border py-4 space-y-4">
            <Link
              to="/services"
              className="block py-2 text-foreground hover:text-primary transition-colors"
              onClick={() => setMobileMenuOpen(false)}
            >
              Services
            </Link>
            <Link
              to="/how-it-works"
              className="block py-2 text-foreground hover:text-primary transition-colors"
              onClick={() => setMobileMenuOpen(false)}
            >
              How It Works
            </Link>
            <Link
              to="/contact"
              className="block py-2 text-foreground hover:text-primary transition-colors"
              onClick={() => setMobileMenuOpen(false)}
            >
              Contact
            </Link>
            <Link
              to="/credit-repair-application"
              className="block py-2 text-foreground hover:text-primary transition-colors"
              onClick={() => setMobileMenuOpen(false)}
            >
              Credit Repair
            </Link>
            <Link
              to="/membership"
              className="block py-2 text-foreground hover:text-primary transition-colors font-semibold"
              onClick={() => setMobileMenuOpen(false)}
            >
              Membership
            </Link>
            {isAdmin && (
              <Link
                to="/lead-engine/v4"
                className="block py-2 text-foreground hover:text-primary transition-colors"
                onClick={() => setMobileMenuOpen(false)}
              >
                Lead Engine
              </Link>
            )}
            {(isAdmin || isWorker) && (
              <Link
                to="/worker/queue"
                className="block py-2 text-foreground hover:text-primary transition-colors"
                onClick={() => setMobileMenuOpen(false)}
              >
                Dialer
              </Link>
            )}
            <a 
              href="tel:+16468269799"
              className="flex items-center gap-2 py-2 text-primary font-semibold"
              onClick={() => setMobileMenuOpen(false)}
            >
              <Phone size={18} />
              <span>Call Now</span>
            </a>
            {user ? (
              <>
                <div className="py-2 text-sm text-muted-foreground border-t border-border">
                  {user.email}
                </div>
                {isWorker && (
                  <Button
                    onClick={() => {
                      navigate("/worker/dashboard");
                      setMobileMenuOpen(false);
                    }}
                    variant="outline"
                    className="w-full"
                  >
                    Worker / ISO Portal
                  </Button>
                )}
                {isWorker && (
                  <Button
                    onClick={() => {
                      navigate('/worker/leads');
                      setMobileMenuOpen(false);
                    }}
                    variant="outline"
                    className="w-full"
                  >
                    Lead Mining
                  </Button>
                )}
                {isIso && (
                  <Button
                    onClick={() => {
                      navigate('/iso/dashboard');
                      setMobileMenuOpen(false);
                    }}
                    variant="outline"
                    className="w-full"
                  >
                    ISO Portal
                  </Button>
                )}
                {isCreditSpecialist && (
                  <Button
                    onClick={() => {
                      navigate("/credit-fix/studio");
                      setMobileMenuOpen(false);
                    }}
                    variant="outline"
                    className="w-full"
                  >
                    Credit Fix Studio
                  </Button>
                )}
                {isCreditSpecialist && (
                  <Button
                    onClick={() => {
                      navigate("/credit-fix/cases");
                      setMobileMenuOpen(false);
                    }}
                    variant="outline"
                    className="w-full"
                  >
                    Credit Fix Dashboard
                  </Button>
                )}
                {isAdmin && (
                  <Button
                    onClick={() => {
                      navigate("/admin/dashboard");
                      setMobileMenuOpen(false);
                    }}
                    variant="outline"
                    className="w-full"
                  >
                    Admin Dashboard
                  </Button>
                )}
                {isAdmin && (
                  <Button
                    onClick={() => {
                      navigate("/lead-engine/v4");
                      setMobileMenuOpen(false);
                    }}
                    variant="outline"
                    className="w-full"
                  >
                    Lead Engine
                  </Button>
                )}
                {(isAdmin || isWorker) && (
                  <Button
                    onClick={() => {
                      navigate("/worker/queue");
                      setMobileMenuOpen(false);
                    }}
                    variant="outline"
                    className="w-full"
                  >
                    Dialer
                  </Button>
                )}
                <Button
                  onClick={() => {
                    handleSignOut();
                    setMobileMenuOpen(false);
                  }}
                  variant="outline"
                  className="w-full gap-2"
                >
                  <LogOut size={16} />
                  Sign Out
                </Button>
              </>
            ) : (
              <Button asChild variant="outline" className="w-full">
                <Link to="/auth" onClick={() => setMobileMenuOpen(false)}>
                  Sign In
                </Link>
              </Button>
            )}
            <Button asChild className="w-full bg-primary text-primary-foreground hover:bg-primary/90">
              <Link to="/apply" onClick={() => setMobileMenuOpen(false)}>
                Apply Now
              </Link>
            </Button>
          </div>
        )}
      </div>
    </nav>
  );
};

export default Navigation;
