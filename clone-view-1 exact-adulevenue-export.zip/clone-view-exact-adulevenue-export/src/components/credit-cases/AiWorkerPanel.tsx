// src/components/credit-cases/AiWorkerPanel.tsx
import React, { useState } from "react";
import { CreditCaseV2, aiWorkerAction, AiWorkerAction } from "@/lib/creditCases";

type Props = {
  caseId: string;
  caseData: CreditCaseV2;
};

export const AiWorkerPanel: React.FC<Props> = ({ caseId, caseData }) => {
  const [action, setAction] = useState<AiWorkerAction | "">("");
  const [emailType, setEmailType] = useState<"welcome" | "update" | "completion" | "">(
    "",
  );
  const [loading, setLoading] = useState(false);
  const [output, setOutput] = useState<string>("");
  const [error, setError] = useState<string | null>(null);

  const runAction = async () => {
    if (!action) return;

    try {
      setLoading(true);
      setError(null);
      setOutput("");

      const context: Record<string, any> = {};
      if (action === "draft_email" && emailType) {
        context.email_type = emailType;
      }

      const res = await aiWorkerAction({
        case_id: caseId,
        action,
        context,
      });

      if (!res.ok) {
        throw new Error(res.error || "AI worker error");
      }

      setOutput(res.output || "");
    } catch (err: any) {
      setError(err.message || "Failed to run AI worker");
    } finally {
      setLoading(false);
    }
  };

  const copyToClipboard = () => {
    if (output) {
      navigator.clipboard.writeText(output);
    }
  };

  return (
    <div className="border border-border rounded p-4 text-xs space-y-3">
      <div className="flex items-center justify-between">
        <h2 className="text-sm font-semibold text-foreground">AI Worker</h2>
        <span className="text-[11px] text-muted-foreground">
          {caseData.client_full_name || "Client"}
        </span>
      </div>

      <p className="text-[11px] text-muted-foreground">
        Uses <code className="bg-muted px-1 rounded">wf-ai-worker</code> (V2.2) with full case history, dispute items,
        drafts, and tasks to assist your team.
      </p>

      <div className="grid md:grid-cols-2 gap-4">
        <div className="space-y-2">
          <div className="font-medium text-[11px] text-foreground">Action</div>
          <select
            value={action}
            onChange={(e) => setAction(e.target.value as any)}
            className="w-full border border-border rounded px-2 py-1.5 text-[11px] bg-background text-foreground"
          >
            <option value="">Select action…</option>
            <option value="draft_email">Draft client email</option>
            <option value="summarize_timeline">Summarize case timeline</option>
            <option value="suggest_next_step">Suggest next step</option>
            <option value="explain_strategy">Explain dispute strategy</option>
          </select>

          {action === "draft_email" && (
            <div className="space-y-1">
              <div className="font-medium text-[11px] text-foreground">Email Type</div>
              <select
                value={emailType}
                onChange={(e) => setEmailType(e.target.value as any)}
                className="w-full border border-border rounded px-2 py-1.5 text-[11px] bg-background text-foreground"
              >
                <option value="">Select email type…</option>
                <option value="welcome">Welcome / onboarding</option>
                <option value="update">Progress update</option>
                <option value="completion">Case completion</option>
              </select>
            </div>
          )}

          <button
            type="button"
            onClick={runAction}
            disabled={loading || !action || (action === "draft_email" && !emailType)}
            className="mt-2 px-3 py-1.5 rounded bg-primary text-primary-foreground text-[11px] disabled:opacity-50 hover:bg-primary/90 transition-colors w-full"
          >
            {loading ? "Running…" : "Run AI Worker"}
          </button>

          {error && (
            <div className="text-[11px] text-destructive mt-1">
              {error}
            </div>
          )}

          <div className="text-[10px] text-muted-foreground mt-2 space-y-1">
            <div className="font-medium">Available Actions:</div>
            <ul className="list-disc pl-4 space-y-0.5">
              <li><strong>Draft email</strong> — Generate client communication</li>
              <li><strong>Summarize timeline</strong> — Get case history overview</li>
              <li><strong>Suggest next step</strong> — AI-recommended action</li>
              <li><strong>Explain strategy</strong> — Dispute approach breakdown</li>
            </ul>
          </div>
        </div>

        <div className="space-y-1">
          <div className="flex items-center justify-between">
            <div className="font-medium text-[11px] text-foreground">Output</div>
            {output && (
              <button
                type="button"
                onClick={copyToClipboard}
                className="text-[10px] text-muted-foreground hover:text-foreground underline transition-colors"
              >
                Copy
              </button>
            )}
          </div>
          <textarea
            value={output}
            onChange={(e) => setOutput(e.target.value)}
            placeholder="AI output will appear here…"
            className="w-full h-48 border border-border rounded px-2 py-1.5 text-[11px] bg-background text-foreground resize-vertical"
          />
          {output && (
            <div className="text-[10px] text-muted-foreground">
              You can edit the output above before using it.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
