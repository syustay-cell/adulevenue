// src/components/credit-cases/DisputesPanel.tsx
import React, { useState } from "react";
import {
  CreditCaseV2,
  CreditDisputeItemV2,
  CreditDisputeDraftV2,
  generateDisputeLetters,
  saveDisputeDraft,
  markDisputeDraftSent,
} from "@/lib/creditCases";

type Props = {
  caseId: string;
  caseData: CreditCaseV2;
  items: CreditDisputeItemV2[];
  drafts: CreditDisputeDraftV2[];
  onRefresh: () => Promise<void>;
};

export const DisputesPanel: React.FC<Props> = ({
  caseId,
  caseData,
  items,
  drafts,
  onRefresh,
}) => {
  const [selectedBureaus, setSelectedBureaus] = useState<string[]>([
    "transunion",
    "experian",
    "equifax",
  ]);
  const [selectedItemIds, setSelectedItemIds] = useState<string[]>([]);
  const [letterType, setLetterType] = useState<"dispute" | "validation">("dispute");
  const [activeDraft, setActiveDraft] = useState<CreditDisputeDraftV2 | null>(null);
  const [draftBody, setDraftBody] = useState<string>("");
  const [saving, setSaving] = useState(false);
  const [generating, setGenerating] = useState(false);
  const [markingSent, setMarkingSent] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const toggleBureau = (b: string) => {
    setSelectedBureaus((prev) =>
      prev.includes(b) ? prev.filter((x) => x !== b) : [...prev, b],
    );
  };

  const toggleItem = (id: string) => {
    setSelectedItemIds((prev) =>
      prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id],
    );
  };

  const handleGenerate = async () => {
    try {
      setGenerating(true);
      setError(null);

      if (selectedBureaus.length === 0) {
        throw new Error("Select at least one bureau.");
      }
      if (selectedItemIds.length === 0) {
        throw new Error("Select at least one dispute item.");
      }

      await generateDisputeLetters({
        case_id: caseId,
        bureaus: selectedBureaus,
        item_ids: selectedItemIds,
        letter_type: letterType,
      });

      await onRefresh();
    } catch (err: any) {
      setError(err.message || "Failed to generate dispute letters");
    } finally {
      setGenerating(false);
    }
  };

  const openDraft = (draft: CreditDisputeDraftV2) => {
    setActiveDraft(draft);
    setDraftBody(draft.body || "");
  };

  const handleSaveDraft = async (approve: boolean) => {
    if (!activeDraft) return;
    try {
      setSaving(true);
      setError(null);

      await saveDisputeDraft({
        draft_id: activeDraft.id,
        subject:
          activeDraft.subject ||
          `${activeDraft.letter_type} letter - ${activeDraft.bureau}`,
        body: draftBody,
        status: approve ? "approved" : "draft",
      });

      await onRefresh();
      setActiveDraft(null);
    } catch (err: any) {
      setError(err.message || "Failed to save draft");
    } finally {
      setSaving(false);
    }
  };

  const handleMarkSent = async () => {
    if (!activeDraft) return;
    try {
      setMarkingSent(true);
      setError(null);

      await markDisputeDraftSent({
        draft_id: activeDraft.id,
        sent_method: "mail",
      });

      await onRefresh();
      setActiveDraft(null);
    } catch (err: any) {
      setError(err.message || "Failed to mark as sent");
    } finally {
      setMarkingSent(false);
    }
  };

  return (
    <div className="grid md:grid-cols-3 gap-4">
      {/* Left: Items + Generate */}
      <div className="md:col-span-1 border border-border rounded p-3 space-y-3 text-xs">
        <div className="flex items-center justify-between">
          <h2 className="font-semibold text-sm text-foreground">Dispute Items</h2>
        </div>
        <p className="text-muted-foreground text-[11px]">
          Select which bureaus and items to include in your dispute letters.
        </p>

        <div className="space-y-1">
          <div className="font-medium text-[11px] text-foreground">Bureaus</div>
          <div className="flex flex-wrap gap-2">
            {["transunion", "experian", "equifax"].map((b) => (
              <button
                key={b}
                type="button"
                onClick={() => toggleBureau(b)}
                className={`px-2 py-1 rounded border text-[11px] transition-colors ${
                  selectedBureaus.includes(b)
                    ? "bg-primary text-primary-foreground border-primary"
                    : "bg-background text-foreground border-border hover:bg-muted"
                }`}
              >
                {b.charAt(0).toUpperCase() + b.slice(1)}
              </button>
            ))}
          </div>
        </div>

        <div className="space-y-1">
          <div className="font-medium text-[11px] text-foreground">Letter Type</div>
          <select
            value={letterType}
            onChange={(e) => setLetterType(e.target.value as any)}
            className="w-full border border-border rounded px-2 py-1 text-[11px] bg-background text-foreground"
          >
            <option value="dispute">Dispute Letter</option>
            <option value="validation">Debt Validation Letter</option>
          </select>
        </div>

        <div className="space-y-1 max-h-64 overflow-auto border border-border rounded p-2">
          <div className="font-medium text-[11px] mb-1 text-foreground">Items</div>
          {items.length === 0 ? (
            <div className="text-muted-foreground text-[11px]">
              No dispute items yet.
            </div>
          ) : (
            items.map((item) => (
              <label
                key={item.id}
                className="flex items-start gap-2 py-1 border-b last:border-b-0 border-border/40 cursor-pointer"
              >
                <input
                  type="checkbox"
                  checked={selectedItemIds.includes(item.id)}
                  onChange={() => toggleItem(item.id)}
                  className="mt-0.5"
                />
                <div>
                  <div className="font-medium text-foreground">
                    {item.creditor_name || "Unknown Creditor"} •{" "}
                    {item.bureau.toUpperCase()}
                  </div>
                  <div className="text-[11px] text-muted-foreground">
                    {item.account_type || "Type n/a"} •{" "}
                    {item.account_number || "Acct n/a"}
                  </div>
                  <div className="text-[11px] text-foreground">
                    Reason: {item.dispute_reason || "—"}
                  </div>
                </div>
              </label>
            ))
          )}
        </div>

        <button
          type="button"
          onClick={handleGenerate}
          disabled={generating}
          className="w-full mt-2 px-3 py-1.5 rounded text-[11px] bg-primary text-primary-foreground disabled:opacity-50 hover:bg-primary/90 transition-colors"
        >
          {generating ? "Generating…" : "Generate Dispute Letters"}
        </button>

        {error && (
          <div className="text-[11px] text-destructive mt-1">
            {error}
          </div>
        )}
      </div>

      {/* Right: Draft list + editor */}
      <div className="md:col-span-2 grid md:grid-cols-2 gap-4">
        <div className="border border-border rounded p-3 text-xs space-y-2 max-h-[420px] overflow-auto">
          <div className="flex items-center justify-between">
            <h2 className="font-semibold text-sm text-foreground">Drafts</h2>
          </div>
          {drafts.length === 0 ? (
            <div className="text-muted-foreground text-[11px]">
              No dispute drafts yet. Generate letters from the left panel.
            </div>
          ) : (
            drafts.map((draft) => (
              <button
                key={draft.id}
                type="button"
                onClick={() => openDraft(draft)}
                className={`w-full text-left border rounded px-2 py-1.5 mb-1 text-[11px] transition-colors ${
                  activeDraft?.id === draft.id
                    ? "border-primary bg-primary/5"
                    : "border-border bg-background hover:bg-muted"
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="font-medium text-foreground">
                    {draft.bureau.toUpperCase()} •{" "}
                    {draft.letter_type || "dispute"}
                  </span>
                  <span className={`text-[10px] uppercase px-1 py-0.5 rounded ${
                    draft.status === 'sent' ? 'bg-green-100 text-green-700' :
                    draft.status === 'approved' ? 'bg-blue-100 text-blue-700' :
                    'bg-muted text-muted-foreground'
                  }`}>
                    {draft.status}
                  </span>
                </div>
                <div className="text-[10px] text-muted-foreground truncate">
                  {draft.subject || "(no subject)"}
                </div>
              </button>
            ))
          )}
        </div>

        <div className="border border-border rounded p-3 text-xs flex flex-col">
          <div className="flex items-center justify-between mb-2">
            <h2 className="font-semibold text-sm text-foreground">Draft Editor</h2>
            {activeDraft && (
              <span className="text-[11px] text-muted-foreground">
                {activeDraft.bureau.toUpperCase()} • {activeDraft.status}
              </span>
            )}
          </div>

          {!activeDraft ? (
            <div className="text-[11px] text-muted-foreground">
              Select a draft from the list to view and edit.
            </div>
          ) : (
            <>
              <textarea
                className="flex-1 border border-border rounded px-2 py-1 text-[11px] mb-2 w-full min-h-[220px] resize-vertical bg-background text-foreground"
                value={draftBody}
                onChange={(e) => setDraftBody(e.target.value)}
              />

              <div className="flex items-center justify-between gap-2">
                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={() => handleSaveDraft(false)}
                    disabled={saving}
                    className="px-3 py-1.5 rounded text-[11px] border border-border bg-background text-foreground disabled:opacity-50 hover:bg-muted transition-colors"
                  >
                    {saving ? "Saving…" : "Save Draft"}
                  </button>
                  <button
                    type="button"
                    onClick={() => handleSaveDraft(true)}
                    disabled={saving}
                    className="px-3 py-1.5 rounded text-[11px] bg-green-600 text-white disabled:opacity-50 hover:bg-green-700 transition-colors"
                  >
                    {saving ? "Saving…" : "Approve"}
                  </button>
                </div>
                <button
                  type="button"
                  onClick={handleMarkSent}
                  disabled={markingSent || activeDraft.status !== 'approved'}
                  className="px-3 py-1.5 rounded text-[11px] bg-primary text-primary-foreground disabled:opacity-50 hover:bg-primary/90 transition-colors"
                >
                  {markingSent ? "Marking…" : "Mark as Sent"}
                </button>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
};
