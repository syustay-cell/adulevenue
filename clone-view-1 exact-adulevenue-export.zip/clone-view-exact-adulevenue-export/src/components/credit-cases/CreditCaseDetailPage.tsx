// src/components/credit-cases/CreditCaseDetailPage.tsx
import React, { useEffect, useState } from "react";
import {
  CreditCaseV2,
  CreditDisputeDraftV2,
  CreditDisputeItemV2,
  WfTask,
  fetchCreditCase,
  fetchDisputeItems,
  fetchDisputeDrafts,
  fetchCaseTasks,
} from "@/lib/creditCases";
import { DisputesPanel } from "@/components/credit-cases/DisputesPanel";
import { TasksPanel } from "@/components/credit-cases/TasksPanel";
import { AiWorkerPanel } from "@/components/credit-cases/AiWorkerPanel";

type Props = {
  caseId: string;
};

export const CreditCaseDetailPage: React.FC<Props> = ({ caseId }) => {
  const [caseData, setCaseData] = useState<CreditCaseV2 | null>(null);
  const [items, setItems] = useState<CreditDisputeItemV2[]>([]);
  const [drafts, setDrafts] = useState<CreditDisputeDraftV2[]>([]);
  const [tasks, setTasks] = useState<WfTask[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<"overview" | "disputes" | "tasks" | "ai">(
    "overview",
  );
  const [error, setError] = useState<string | null>(null);

  const loadAll = async () => {
    try {
      setLoading(true);
      setError(null);

      const [c, i, d, t] = await Promise.all([
        fetchCreditCase(caseId),
        fetchDisputeItems(caseId),
        fetchDisputeDrafts(caseId),
        fetchCaseTasks(caseId),
      ]);

      setCaseData(c);
      setItems(i);
      setDrafts(d);
      setTasks(t);
    } catch (err: any) {
      console.error("[CreditCaseDetailPage] load error", err);
      setError(err.message || "Failed to load case");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (!caseId) return;
    loadAll();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [caseId]);

  const refreshDisputes = async () => {
    const [i, d] = await Promise.all([
      fetchDisputeItems(caseId),
      fetchDisputeDrafts(caseId),
    ]);
    setItems(i);
    setDrafts(d);
  };

  const refreshTasks = async () => {
    const t = await fetchCaseTasks(caseId);
    setTasks(t);
  };

  if (loading && !caseData) {
    return (
      <div className="p-6 text-sm text-muted-foreground">
        Loading case…
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-6 text-sm text-destructive">
        Error loading case: {error}
      </div>
    );
  }

  if (!caseData) {
    return (
      <div className="p-6 text-sm text-muted-foreground">
        Case not found.
      </div>
    );
  }

  const tabs = [
    { key: "overview", label: "Overview" },
    { key: "disputes", label: "Disputes", count: drafts.length },
    { key: "tasks", label: "Tasks", count: tasks.filter(t => t.status === 'pending').length },
    { key: "ai", label: "AI Worker" },
  ] as const;

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-semibold text-foreground">
            Credit Case #{caseData.id.slice(0, 8)}…
          </h1>
          <p className="text-sm text-muted-foreground">
            {caseData.client_full_name || "Unknown client"} •{" "}
            {caseData.client_email || "No email"} • Status:{" "}
            <span className={`font-medium ${
              caseData.status === 'closed' ? 'text-green-600' :
              caseData.status === 'dispute_in_progress' ? 'text-blue-600' :
              'text-foreground'
            }`}>{caseData.status}</span>
          </p>
        </div>
        <div className="flex gap-2 text-xs flex-wrap">
          <span className={`px-2 py-1 rounded ${
            caseData.priority === 'high' ? 'bg-orange-100 text-orange-700' :
            caseData.priority === 'urgent' ? 'bg-red-100 text-red-700' :
            'bg-muted text-muted-foreground'
          }`}>
            Priority: {caseData.priority || "n/a"}
          </span>
          {caseData.has_identity_theft && (
            <span className="px-2 py-1 rounded bg-red-100 text-red-700">
              Identity Theft
            </span>
          )}
          {caseData.bureaus && caseData.bureaus.length > 0 && (
            <span className="px-2 py-1 rounded bg-muted text-muted-foreground">
              {caseData.bureaus.join(", ")}
            </span>
          )}
        </div>
      </div>

      {/* Tabs */}
      <div className="border-b border-border flex gap-4 text-sm overflow-x-auto">
        {tabs.map((tab) => (
          <button
            key={tab.key}
            className={`pb-2 whitespace-nowrap flex items-center gap-1.5 transition-colors ${
              activeTab === tab.key 
                ? "border-b-2 border-primary font-medium text-foreground" 
                : "text-muted-foreground hover:text-foreground"
            }`}
            onClick={() => setActiveTab(tab.key)}
          >
            {tab.label}
            {'count' in tab && tab.count !== undefined && tab.count > 0 && (
              <span className={`text-[10px] px-1.5 py-0.5 rounded-full ${
                activeTab === tab.key 
                  ? 'bg-primary text-primary-foreground' 
                  : 'bg-muted text-muted-foreground'
              }`}>
                {tab.count}
              </span>
            )}
          </button>
        ))}
      </div>

      {/* Tab Content */}
      {activeTab === "overview" && (
        <div className="space-y-4 text-sm">
          <div className="border border-border rounded p-4">
            <h2 className="text-sm font-semibold mb-3 text-foreground">Case Snapshot</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 text-xs">
              <div>
                <div className="text-muted-foreground mb-0.5">Client</div>
                <div className="text-foreground font-medium">{caseData.client_full_name || "Unknown"}</div>
              </div>
              <div>
                <div className="text-muted-foreground mb-0.5">Email</div>
                <div className="text-foreground">{caseData.client_email || "—"}</div>
              </div>
              <div>
                <div className="text-muted-foreground mb-0.5">Phone</div>
                <div className="text-foreground">{caseData.client_phone || "—"}</div>
              </div>
              <div>
                <div className="text-muted-foreground mb-0.5">Bureaus</div>
                <div className="text-foreground">
                  {caseData.bureaus && caseData.bureaus.length > 0
                    ? caseData.bureaus.join(", ")
                    : "All / unspecified"}
                </div>
              </div>
            </div>
          </div>

          {/* Quick Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="border border-border rounded p-3">
              <div className="text-[11px] text-muted-foreground">Dispute Items</div>
              <div className="text-lg font-semibold text-foreground">{items.length}</div>
            </div>
            <div className="border border-border rounded p-3">
              <div className="text-[11px] text-muted-foreground">Draft Letters</div>
              <div className="text-lg font-semibold text-foreground">{drafts.filter(d => d.status === 'draft').length}</div>
            </div>
            <div className="border border-border rounded p-3">
              <div className="text-[11px] text-muted-foreground">Letters Sent</div>
              <div className="text-lg font-semibold text-foreground">{drafts.filter(d => d.status === 'sent').length}</div>
            </div>
            <div className="border border-border rounded p-3">
              <div className="text-[11px] text-muted-foreground">Pending Tasks</div>
              <div className="text-lg font-semibold text-foreground">{tasks.filter(t => t.status === 'pending').length}</div>
            </div>
          </div>

          <div className="text-xs text-muted-foreground">
            Use the tabs above to manage dispute letters, action tasks, and AI-assisted
            workflows for this case.
          </div>
        </div>
      )}

      {activeTab === "disputes" && (
        <DisputesPanel
          caseId={caseId}
          caseData={caseData}
          items={items}
          drafts={drafts}
          onRefresh={refreshDisputes}
        />
      )}

      {activeTab === "tasks" && (
        <TasksPanel caseId={caseId} tasks={tasks} onRefresh={refreshTasks} />
      )}

      {activeTab === "ai" && <AiWorkerPanel caseId={caseId} caseData={caseData} />}
    </div>
  );
};

export default CreditCaseDetailPage;
