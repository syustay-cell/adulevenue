// src/components/credit-cases/TasksPanel.tsx
import React, { useState } from "react";
import { WfTask } from "@/lib/creditCases";
import { supabase } from "@/integrations/supabase/client";

type Props = {
  caseId: string;
  tasks: WfTask[];
  onRefresh: () => Promise<void>;
};

export const TasksPanel: React.FC<Props> = ({ caseId, tasks, onRefresh }) => {
  const [updatingId, setUpdatingId] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const markComplete = async (taskId: string) => {
    try {
      setUpdatingId(taskId);
      setError(null);

      const { error: updError } = await supabase
        .from("wf_tasks")
        .update({ status: "completed" })
        .eq("id", taskId);

      if (updError) throw updError;
      await onRefresh();
    } catch (err: any) {
      setError(err.message || "Failed to update task");
    } finally {
      setUpdatingId(null);
    }
  };

  const pendingTasks = tasks.filter(t => t.status === 'pending');
  const completedTasks = tasks.filter(t => t.status === 'completed');

  return (
    <div className="border border-border rounded p-4 text-xs space-y-3">
      <div className="flex items-center justify-between mb-1">
        <h2 className="text-sm font-semibold text-foreground">Tasks</h2>
        <button
          type="button"
          onClick={onRefresh}
          className="text-[11px] underline text-muted-foreground hover:text-foreground transition-colors"
        >
          Refresh
        </button>
      </div>
      <p className="text-[11px] text-muted-foreground">
        Includes auto-generated follow-ups from <code className="bg-muted px-1 rounded">wf-case-auto-actions</code> and
        any manual tasks.
      </p>

      {error && (
        <div className="text-[11px] text-destructive">
          {error}
        </div>
      )}

      {tasks.length === 0 ? (
        <div className="text-[11px] text-muted-foreground">
          No tasks for this case.
        </div>
      ) : (
        <div className="space-y-4">
          {/* Pending Tasks */}
          {pendingTasks.length > 0 && (
            <div>
              <h3 className="text-[11px] font-medium text-foreground mb-2">
                Pending ({pendingTasks.length})
              </h3>
              <div className="space-y-2 max-h-40 overflow-auto">
                {pendingTasks.map((task) => (
                  <div
                    key={task.id}
                    className="border border-border rounded px-2 py-1.5 flex flex-col gap-1 bg-background"
                  >
                    <div className="flex items-center justify-between">
                      <div className="font-medium text-[11px] text-foreground">{task.title}</div>
                      <span className={`text-[10px] uppercase px-1 py-0.5 rounded ${
                        task.priority === 'urgent' ? 'bg-red-100 text-red-700' :
                        task.priority === 'high' ? 'bg-orange-100 text-orange-700' :
                        task.priority === 'medium' ? 'bg-yellow-100 text-yellow-700' :
                        'bg-muted text-muted-foreground'
                      }`}>
                        {task.priority}
                      </span>
                    </div>
                    <div className="text-[11px] text-muted-foreground">
                      {task.description}
                    </div>
                    <div className="flex items-center justify-between text-[10px] mt-1">
                      <div className="text-muted-foreground">
                        Due:{" "}
                        {task.due_date
                          ? new Date(task.due_date).toLocaleString()
                          : "n/a"}
                      </div>
                      <div className="flex items-center gap-2">
                        {task.auto_generated && (
                          <span className="px-1 py-0.5 rounded bg-muted text-muted-foreground">
                            Auto
                          </span>
                        )}
                        <button
                          type="button"
                          onClick={() => markComplete(task.id)}
                          disabled={updatingId === task.id}
                          className="px-2 py-0.5 rounded border border-border text-[10px] disabled:opacity-50 hover:bg-muted transition-colors"
                        >
                          {updatingId === task.id ? "Updating…" : "Mark Done"}
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Completed Tasks */}
          {completedTasks.length > 0 && (
            <div>
              <h3 className="text-[11px] font-medium text-muted-foreground mb-2">
                Completed ({completedTasks.length})
              </h3>
              <div className="space-y-2 max-h-32 overflow-auto">
                {completedTasks.map((task) => (
                  <div
                    key={task.id}
                    className="border border-border/50 rounded px-2 py-1.5 flex flex-col gap-1 bg-muted/30 opacity-70"
                  >
                    <div className="flex items-center justify-between">
                      <div className="font-medium text-[11px] text-muted-foreground line-through">{task.title}</div>
                      <span className="text-[10px] uppercase px-1 py-0.5 rounded bg-green-100 text-green-700">
                        done
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
