import React, { createContext, useContext } from "react";

export type PuzzlePanelContextValue = {
  isOpen: boolean;
  intakeClientId: string | null;
  openPanel: (intakeClientId: string) => void;
  closePanel: () => void;
};

export const PuzzlePanelContext = createContext<PuzzlePanelContextValue | undefined>(
  undefined
);

export function usePuzzlePanelContext(): PuzzlePanelContextValue {
  const ctx = useContext(PuzzlePanelContext);
  if (!ctx) {
    throw new Error("usePuzzlePanelContext must be used within PuzzlePanelProvider");
  }
  return ctx;
}

