import React from "react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { ListenButton } from "@/components/ui/ListenButton";
import { format } from "date-fns";
import { Loader2, AlertTriangle } from "lucide-react";

type Props = {
  intakeClientId: string;
};

export function CollectionsTab({ intakeClientId }: Props) {
  const { data: cases, isLoading } = useQuery({
    queryKey: ["collection-cases", intakeClientId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("collection_cases")
        .select(`
          id,
          status,
          dpd,
          reason,
          strategy,
          notes,
          created_at,
          updated_at
        `)
        .eq("intake_client_id", intakeClientId)
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data;
    },
  });

  const getAllText = () => {
    if (!cases || cases.length === 0) return "No collection cases.";
    return cases
      .map((c) => {
        const parts = [`Status: ${c.status}`];
        if (c.dpd) parts.push(`${c.dpd} days past due`);
        if (c.reason) parts.push(`Reason: ${c.reason}`);
        if (c.strategy) parts.push(`Strategy: ${c.strategy}`);
        return parts.join(", ");
      })
      .join(". ");
  };

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-medium text-foreground flex items-center gap-1.5">
          <AlertTriangle className="h-4 w-4" />
          Collections
        </h3>
        <ListenButton text={getAllText()} label="Listen" />
      </div>

      {isLoading && (
        <div className="flex items-center justify-center py-6">
          <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />
        </div>
      )}

      {!isLoading && (!cases || cases.length === 0) && (
        <p className="text-xs text-muted-foreground py-4">
          No collection cases for this client.
        </p>
      )}

      {!isLoading && cases && cases.length > 0 && (
        <div className="space-y-3">
          {cases.map((caseItem) => (
            <div
              key={caseItem.id}
              className="p-3 rounded-md border bg-muted/20 text-xs space-y-2"
            >
              <div className="flex items-center justify-between">
                <span className="font-medium capitalize px-2 py-0.5 rounded bg-muted">
                  {caseItem.status}
                </span>
                {caseItem.dpd > 0 && (
                  <span className="text-destructive font-medium">
                    {caseItem.dpd} DPD
                  </span>
                )}
              </div>

              {caseItem.reason && (
                <div className="text-muted-foreground">
                  <span className="text-[10px] uppercase tracking-wide">
                    Reason
                  </span>
                  <div className="text-foreground">{caseItem.reason}</div>
                </div>
              )}

              {caseItem.strategy && (
                <div className="text-muted-foreground">
                  <span className="text-[10px] uppercase tracking-wide">
                    Strategy
                  </span>
                  <div className="text-foreground capitalize">
                    {caseItem.strategy}
                  </div>
                </div>
              )}

              {caseItem.notes && (
                <div className="text-muted-foreground">
                  <span className="text-[10px] uppercase tracking-wide">
                    Notes
                  </span>
                  <div className="text-foreground whitespace-pre-wrap">
                    {caseItem.notes}
                  </div>
                </div>
              )}

              <div className="flex items-center justify-between text-[10px] text-muted-foreground pt-1 border-t">
                <span>
                  Created:{" "}
                  {caseItem.created_at &&
                    format(new Date(caseItem.created_at), "MMM d, yyyy")}
                </span>
                <span>
                  Updated:{" "}
                  {caseItem.updated_at &&
                    format(new Date(caseItem.updated_at), "MMM d, yyyy")}
                </span>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
