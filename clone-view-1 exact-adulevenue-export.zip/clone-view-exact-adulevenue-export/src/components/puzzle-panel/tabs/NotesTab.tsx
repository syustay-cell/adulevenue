import React from "react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { ListenButton, ListenRowButton } from "@/components/ui/ListenButton";
import { format } from "date-fns";
import { Loader2 } from "lucide-react";

type Props = {
  intakeClientId: string;
};

type NoteRow = {
  id: string;
  note: string;
  note_type: string | null;
  worker_email: string | null;
  created_at: string;
};

export function NotesTab({ intakeClientId }: Props) {
  // First get the lead_id from intake_clients
  const { data: client } = useQuery({
    queryKey: ["intake-client-lead", intakeClientId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("intake_clients")
        .select("lead_id")
        .eq("id", intakeClientId)
        .maybeSingle();
      if (error) throw error;
      return data;
    },
  });

  const { data: notes, isLoading } = useQuery({
    queryKey: ["client-notes", client?.lead_id],
    enabled: !!client?.lead_id,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("client_notes")
        .select("id, note, note_type, worker_email, created_at")
        .eq("lead_id", client!.lead_id!)
        .order("created_at", { ascending: false })
        .limit(50);
      if (error) throw error;
      return data as NoteRow[];
    },
  });

  const getAllText = () => {
    if (!notes || notes.length === 0) return "No notes available.";
    return notes
      .map((n) => {
        const date = format(new Date(n.created_at), "MMM d");
        return `${date}: ${n.note}`;
      })
      .join(". ");
  };

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-medium text-foreground">Notes</h3>
        <ListenButton text={getAllText()} label="Listen" />
      </div>

      {isLoading && (
        <div className="flex items-center justify-center py-6">
          <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />
        </div>
      )}

      {!isLoading && (!notes || notes.length === 0) && (
        <p className="text-xs text-muted-foreground py-4">
          No notes recorded yet.
        </p>
      )}

      {!isLoading && notes && notes.length > 0 && (
        <div className="space-y-2">
          {notes.map((note) => (
            <NoteItem key={note.id} note={note} />
          ))}
        </div>
      )}
    </div>
  );
}

function NoteItem({ note }: { note: NoteRow }) {
  return (
    <div className="flex items-start justify-between gap-2 p-2 rounded-md border bg-muted/20 text-xs">
      <div className="flex-1 min-w-0 space-y-1">
        <div className="flex items-center gap-2">
          {note.note_type && (
            <span className="px-1.5 py-0.5 rounded bg-muted text-[10px] uppercase">
              {note.note_type}
            </span>
          )}
          {note.worker_email && (
            <span className="text-muted-foreground truncate">
              {note.worker_email}
            </span>
          )}
        </div>
        <div className="text-foreground whitespace-pre-wrap">{note.note}</div>
        <div className="text-[10px] text-muted-foreground">
          {format(new Date(note.created_at), "MMM d, yyyy h:mm a")}
        </div>
      </div>
      <ListenRowButton text={note.note} />
    </div>
  );
}
