import React from "react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { ListenButton } from "@/components/ui/ListenButton";
import { format } from "date-fns";
import { Loader2, CreditCard } from "lucide-react";

type Props = {
  intakeClientId: string;
};

export function CreditTab({ intakeClientId }: Props) {
  const { data: cases, isLoading } = useQuery({
    queryKey: ["credit-cases", intakeClientId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("credit_repair_cases")
        .select(`
          id,
          status,
          created_at,
          updated_at,
          assigned_specialist_id,
          ai_score,
          ai_recommended_path,
          last_soft_score
        `)
        .eq("intake_client_id", intakeClientId)
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data;
    },
  });

  const getAllText = () => {
    if (!cases || cases.length === 0) return "No credit repair cases.";
    return cases
      .map((c) => {
        const parts = [`Case status: ${c.status}`];
        if (c.ai_score) parts.push(`AI score: ${c.ai_score}`);
        if (c.last_soft_score) parts.push(`Soft score: ${c.last_soft_score}`);
        if (c.ai_recommended_path) parts.push(`Path: ${c.ai_recommended_path}`);
        return parts.join(", ");
      })
      .join(". ");
  };

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-medium text-foreground flex items-center gap-1.5">
          <CreditCard className="h-4 w-4" />
          Credit Repair
        </h3>
        <ListenButton text={getAllText()} label="Listen" />
      </div>

      {isLoading && (
        <div className="flex items-center justify-center py-6">
          <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />
        </div>
      )}

      {!isLoading && (!cases || cases.length === 0) && (
        <p className="text-xs text-muted-foreground py-4">
          No credit repair cases for this client.
        </p>
      )}

      {!isLoading && cases && cases.length > 0 && (
        <div className="space-y-3">
          {cases.map((caseItem) => (
            <div
              key={caseItem.id}
              className="p-3 rounded-md border bg-muted/20 text-xs space-y-2"
            >
              <div className="flex items-center justify-between">
                <span className="font-medium capitalize px-2 py-0.5 rounded bg-muted">
                  {caseItem.status}
                </span>
                {caseItem.created_at && (
                  <span className="text-[10px] text-muted-foreground">
                    {format(new Date(caseItem.created_at), "MMM d, yyyy")}
                  </span>
                )}
              </div>

              <div className="grid grid-cols-2 gap-2 text-muted-foreground">
                {caseItem.ai_score && (
                  <div>
                    <span className="text-[10px] uppercase tracking-wide">
                      AI Score
                    </span>
                    <div className="font-medium text-foreground">
                      {caseItem.ai_score}
                    </div>
                  </div>
                )}
                {caseItem.last_soft_score && (
                  <div>
                    <span className="text-[10px] uppercase tracking-wide">
                      Soft Score
                    </span>
                    <div className="font-medium text-foreground">
                      {caseItem.last_soft_score}
                    </div>
                  </div>
                )}
              </div>

              {caseItem.ai_recommended_path && (
                <div className="text-muted-foreground">
                  <span className="text-[10px] uppercase tracking-wide">
                    Recommended Path
                  </span>
                  <div className="font-medium text-foreground capitalize">
                    {caseItem.ai_recommended_path.replace(/_/g, " ")}
                  </div>
                </div>
              )}

              {caseItem.assigned_specialist_id && (
                <div className="text-[10px] text-muted-foreground">
                  Specialist assigned
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
