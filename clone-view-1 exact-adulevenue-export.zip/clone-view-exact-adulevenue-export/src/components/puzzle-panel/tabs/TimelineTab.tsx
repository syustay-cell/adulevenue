import React from "react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { ListenButton, ListenRowButton } from "@/components/ui/ListenButton";
import { format } from "date-fns";
import { Loader2 } from "lucide-react";

type Props = {
  intakeClientId: string;
};

type ActivityRow = {
  id: string;
  type: string;
  subject: string | null;
  body: string | null;
  channel: string | null;
  direction: string | null;
  created_at: string | null;
};

export function TimelineTab({ intakeClientId }: Props) {
  // First get the lead_id from intake_clients
  const { data: client } = useQuery({
    queryKey: ["intake-client-lead", intakeClientId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("intake_clients")
        .select("lead_id")
        .eq("id", intakeClientId)
        .maybeSingle();
      if (error) throw error;
      return data;
    },
  });

  const { data: activities, isLoading } = useQuery({
    queryKey: ["client-activity", client?.lead_id],
    enabled: !!client?.lead_id,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("client_activity")
        .select("id, type, subject, body, channel, direction, created_at")
        .eq("lead_id", client!.lead_id!)
        .order("created_at", { ascending: false })
        .limit(50);
      if (error) throw error;
      return data as ActivityRow[];
    },
  });

  const getAllText = () => {
    if (!activities || activities.length === 0) return "No timeline activity.";
    return activities
      .map((a) => {
        const date = a.created_at
          ? format(new Date(a.created_at), "MMM d")
          : "";
        return `${date}: ${a.type}. ${a.subject || ""} ${a.body || ""}`;
      })
      .join(". ");
  };

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-medium text-foreground">Timeline</h3>
        <ListenButton text={getAllText()} label="Listen" />
      </div>

      {isLoading && (
        <div className="flex items-center justify-center py-6">
          <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />
        </div>
      )}

      {!isLoading && (!activities || activities.length === 0) && (
        <p className="text-xs text-muted-foreground py-4">
          No activity recorded yet.
        </p>
      )}

      {!isLoading && activities && activities.length > 0 && (
        <div className="space-y-2">
          {activities.map((activity) => (
            <ActivityItem key={activity.id} activity={activity} />
          ))}
        </div>
      )}
    </div>
  );
}

function ActivityItem({ activity }: { activity: ActivityRow }) {
  const text = `${activity.type}. ${activity.subject || ""} ${activity.body || ""}`;

  return (
    <div className="flex items-start justify-between gap-2 p-2 rounded-md border bg-muted/20 text-xs">
      <div className="flex-1 min-w-0 space-y-0.5">
        <div className="flex items-center gap-2">
          <span className="font-medium capitalize">{activity.type}</span>
          {activity.channel && (
            <span className="text-muted-foreground">via {activity.channel}</span>
          )}
          {activity.direction && (
            <span className="text-muted-foreground">({activity.direction})</span>
          )}
        </div>
        {activity.subject && (
          <div className="text-muted-foreground truncate">{activity.subject}</div>
        )}
        {activity.body && (
          <div className="text-muted-foreground line-clamp-2">{activity.body}</div>
        )}
        {activity.created_at && (
          <div className="text-[10px] text-muted-foreground">
            {format(new Date(activity.created_at), "MMM d, yyyy h:mm a")}
          </div>
        )}
      </div>
      <ListenRowButton text={text} />
    </div>
  );
}
