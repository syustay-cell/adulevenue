import React from "react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { ListenButton } from "@/components/ui/ListenButton";
import { Loader2, Building2 } from "lucide-react";

type Props = {
  intakeClientId: string;
};

export function MerchantTab({ intakeClientId }: Props) {
  const { data: client, isLoading } = useQuery({
    queryKey: ["merchant-details", intakeClientId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("intake_clients")
        .select("*")
        .eq("id", intakeClientId)
        .maybeSingle();
      if (error) throw error;
      return data;
    },
  });

  const getAllText = () => {
    if (!client) return "No merchant details available.";
    const parts: string[] = [];
    if (client.full_name) parts.push(`Owner: ${client.full_name}`);
    if (client.business_name) parts.push(`Business: ${client.business_name}`);
    if (client.email_primary) parts.push(`Email: ${client.email_primary}`);
    if (client.phone_primary) parts.push(`Phone: ${client.phone_primary}`);
    if (client.primary_path)
      parts.push(`Primary path: ${client.primary_path.replace(/_/g, " ")}`);
    return parts.length > 0 ? parts.join(". ") : "No merchant details.";
  };

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-medium text-foreground flex items-center gap-1.5">
          <Building2 className="h-4 w-4" />
          Merchant Details
        </h3>
        <ListenButton text={getAllText()} label="Listen" />
      </div>

      {isLoading && (
        <div className="flex items-center justify-center py-6">
          <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />
        </div>
      )}

      {!isLoading && !client && (
        <p className="text-xs text-muted-foreground py-4">
          Client record not found.
        </p>
      )}

      {!isLoading && client && (
        <div className="space-y-4">
          {/* Basic Info */}
          <div className="p-3 rounded-md border bg-muted/20 space-y-2">
            <h4 className="text-[10px] font-medium text-muted-foreground uppercase tracking-wide">
              Contact Information
            </h4>
            <div className="space-y-1.5 text-xs">
              <InfoRow label="Full Name" value={client.full_name} />
              <InfoRow label="Email" value={client.email_primary} />
              <InfoRow label="Phone" value={client.phone_primary} />
            </div>
          </div>

          {/* Business Info */}
          <div className="p-3 rounded-md border bg-muted/20 space-y-2">
            <h4 className="text-[10px] font-medium text-muted-foreground uppercase tracking-wide">
              Business Information
            </h4>
            <div className="space-y-1.5 text-xs">
              <InfoRow label="Business Name" value={client.business_name} />
            </div>
          </div>

          {/* Address */}
          {(client.address || client.city || client.state || client.zip) && (
            <div className="p-3 rounded-md border bg-muted/20 space-y-2">
              <h4 className="text-[10px] font-medium text-muted-foreground uppercase tracking-wide">
                Address
              </h4>
              <div className="space-y-1.5 text-xs">
                <InfoRow label="Street" value={client.address} />
                <InfoRow
                  label="City / State / ZIP"
                  value={[client.city, client.state, client.zip]
                    .filter(Boolean)
                    .join(", ")}
                />
              </div>
            </div>
          )}

          {/* Routing Info */}
          <div className="p-3 rounded-md border bg-muted/20 space-y-2">
            <h4 className="text-[10px] font-medium text-muted-foreground uppercase tracking-wide">
              Routing & Status
            </h4>
            <div className="space-y-1.5 text-xs">
              <InfoRow label="Vault ID" value={client.vault_id} />
              <InfoRow
                label="Primary Path"
                value={client.primary_path?.replace(/_/g, " ")}
              />
            </div>
          </div>

          {/* AI Insights (if available) */}
          {(client.ai_funding_score || client.ai_funding_path) && (
            <div className="p-3 rounded-md border bg-muted/20 space-y-2">
              <h4 className="text-[10px] font-medium text-muted-foreground uppercase tracking-wide">
                AI Insights
              </h4>
              <div className="space-y-1.5 text-xs">
                {client.ai_funding_score && (
                  <InfoRow label="Funding Score" value={String(client.ai_funding_score)} />
                )}
                <InfoRow
                  label="Funding Path"
                  value={client.ai_funding_path?.replace(/_/g, " ")}
                />
                <InfoRow
                  label="Credit Risk"
                  value={client.ai_credit_risk?.replace(/_/g, " ")}
                />
                <InfoRow
                  label="Identity Risk"
                  value={client.ai_identity_theft_risk?.replace(/_/g, " ")}
                />
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

function InfoRow({ label, value }: { label: string; value: string | null | undefined }) {
  if (!value) return null;
  return (
    <div className="flex justify-between gap-2">
      <span className="text-muted-foreground">{label}</span>
      <span className="text-foreground text-right capitalize">{value}</span>
    </div>
  );
}
