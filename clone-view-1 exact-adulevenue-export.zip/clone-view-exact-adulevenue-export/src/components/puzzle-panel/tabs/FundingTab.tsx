import React from "react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { ListenButton } from "@/components/ui/ListenButton";
import { format } from "date-fns";
import { Loader2, FileText, DollarSign } from "lucide-react";

type Props = {
  intakeClientId: string;
};

export function FundingTab({ intakeClientId }: Props) {
  const { data: applications, isLoading: appsLoading } = useQuery({
    queryKey: ["funding-applications", intakeClientId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("fast_track_applications")
        .select("id, status, created_at, business_name")
        .eq("intake_client_id", intakeClientId)
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data;
    },
  });

  const { data: deals, isLoading: dealsLoading } = useQuery({
    queryKey: ["funding-deals", intakeClientId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("deals")
        .select(`
          id, 
          status, 
          created_at,
          funded_contracts (
            id,
            funded_amount,
            factor_rate,
            term_length,
            created_at
          )
        `)
        .eq("intake_client_id", intakeClientId)
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data;
    },
  });

  const isLoading = appsLoading || dealsLoading;

  const getAllText = () => {
    const parts: string[] = [];
    
    if (applications && applications.length > 0) {
      parts.push(`${applications.length} application${applications.length !== 1 ? "s" : ""}.`);
      applications.forEach((app) => {
        parts.push(`Application status ${app.status}.`);
      });
    }

    if (deals && deals.length > 0) {
      parts.push(`${deals.length} deal${deals.length !== 1 ? "s" : ""}.`);
      deals.forEach((deal: any) => {
        const contracts = deal.funded_contracts || [];
        const totalFunded = contracts.reduce(
          (sum: number, c: any) => sum + (c.funded_amount || 0),
          0
        );
        parts.push(
          `Deal status ${deal.status}${totalFunded > 0 ? `, funded $${totalFunded.toLocaleString()}` : ""}.`
        );
      });
    }

    return parts.length > 0 ? parts.join(" ") : "No funding activity.";
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-medium text-foreground">Funding</h3>
        <ListenButton text={getAllText()} label="Listen" />
      </div>

      {isLoading && (
        <div className="flex items-center justify-center py-6">
          <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />
        </div>
      )}

      {!isLoading && (
        <div className="space-y-4">
          {/* Applications Section */}
          <div className="space-y-2">
            <h4 className="text-xs font-medium text-muted-foreground uppercase tracking-wide flex items-center gap-1.5">
              <FileText className="h-3 w-3" />
              Applications
            </h4>
            {(!applications || applications.length === 0) && (
              <p className="text-xs text-muted-foreground">No applications.</p>
            )}
            {applications && applications.length > 0 && (
              <div className="space-y-2">
                {applications.map((app) => (
                  <div
                    key={app.id}
                    className="p-2 rounded-md border bg-muted/20 text-xs space-y-1"
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-medium capitalize">{app.status}</span>
                    </div>
                    {app.business_name && (
                      <div className="text-muted-foreground truncate">
                        {app.business_name}
                      </div>
                    )}
                    {app.created_at && (
                      <div className="text-[10px] text-muted-foreground">
                        {format(new Date(app.created_at), "MMM d, yyyy")}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Deals Section */}
          <div className="space-y-2">
            <h4 className="text-xs font-medium text-muted-foreground uppercase tracking-wide flex items-center gap-1.5">
              <DollarSign className="h-3 w-3" />
              Deals & Contracts
            </h4>
            {(!deals || deals.length === 0) && (
              <p className="text-xs text-muted-foreground">No deals.</p>
            )}
            {deals && deals.length > 0 && (
              <div className="space-y-2">
                {deals.map((deal: any) => {
                  const contracts = deal.funded_contracts || [];
                  const totalFunded = contracts.reduce(
                    (sum: number, c: any) => sum + (c.funded_amount || 0),
                    0
                  );

                  return (
                    <div
                      key={deal.id}
                      className="p-2 rounded-md border bg-muted/20 text-xs space-y-1"
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-medium capitalize">
                          {deal.status}
                        </span>
                        {totalFunded > 0 && (
                          <span className="text-green-600 font-medium">
                            ${totalFunded.toLocaleString()}
                          </span>
                        )}
                      </div>
                      {contracts.length > 0 && (
                        <div className="text-muted-foreground">
                          {contracts.length} contract
                          {contracts.length !== 1 ? "s" : ""}
                        </div>
                      )}
                      {deal.created_at && (
                        <div className="text-[10px] text-muted-foreground">
                          {format(new Date(deal.created_at), "MMM d, yyyy")}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
