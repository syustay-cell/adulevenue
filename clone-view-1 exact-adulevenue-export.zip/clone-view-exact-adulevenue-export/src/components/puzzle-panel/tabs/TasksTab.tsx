import React from "react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { ListenButton, ListenRowButton } from "@/components/ui/ListenButton";
import { format } from "date-fns";
import { Loader2, CheckSquare } from "lucide-react";

type Props = {
  intakeClientId: string;
};

type TaskRow = {
  id: string;
  task_type: string;
  status: string;
  due_at: string | null;
  created_at: string;
  meta: Record<string, unknown> | null;
};

export function TasksTab({ intakeClientId }: Props) {
  const { data: tasks, isLoading } = useQuery({
    queryKey: ["outreach-tasks", intakeClientId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("outreach_tasks")
        .select("id, task_type, status, due_at, created_at, meta")
        .eq("intake_client_id", intakeClientId)
        .order("created_at", { ascending: false })
        .limit(50);
      if (error) throw error;
      return data as TaskRow[];
    },
  });

  const getAllText = () => {
    if (!tasks || tasks.length === 0) return "No tasks.";
    const pending = tasks.filter((t) => t.status === "pending").length;
    const completed = tasks.filter((t) => t.status === "completed").length;
    return `${tasks.length} total tasks. ${pending} pending. ${completed} completed. ${tasks
      .slice(0, 5)
      .map((t) => `${t.task_type}: ${t.status}`)
      .join(". ")}`;
  };

  const pendingTasks = tasks?.filter((t) => t.status === "pending") || [];
  const otherTasks = tasks?.filter((t) => t.status !== "pending") || [];

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-medium text-foreground flex items-center gap-1.5">
          <CheckSquare className="h-4 w-4" />
          Tasks
        </h3>
        <ListenButton text={getAllText()} label="Listen" />
      </div>

      {isLoading && (
        <div className="flex items-center justify-center py-6">
          <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />
        </div>
      )}

      {!isLoading && (!tasks || tasks.length === 0) && (
        <p className="text-xs text-muted-foreground py-4">
          No tasks for this client.
        </p>
      )}

      {!isLoading && tasks && tasks.length > 0 && (
        <div className="space-y-4">
          {/* Pending Tasks */}
          {pendingTasks.length > 0 && (
            <div className="space-y-2">
              <h4 className="text-[10px] font-medium text-muted-foreground uppercase tracking-wide">
                Pending ({pendingTasks.length})
              </h4>
              <div className="space-y-2">
                {pendingTasks.map((task) => (
                  <TaskItem key={task.id} task={task} />
                ))}
              </div>
            </div>
          )}

          {/* Other Tasks */}
          {otherTasks.length > 0 && (
            <div className="space-y-2">
              <h4 className="text-[10px] font-medium text-muted-foreground uppercase tracking-wide">
                Completed / Other ({otherTasks.length})
              </h4>
              <div className="space-y-2">
                {otherTasks.map((task) => (
                  <TaskItem key={task.id} task={task} />
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

function TaskItem({ task }: { task: TaskRow }) {
  const text = `${task.task_type}: ${task.status}${task.due_at ? `, due ${format(new Date(task.due_at), "MMM d")}` : ""}`;

  const isPending = task.status === "pending";
  const isOverdue =
    isPending && task.due_at && new Date(task.due_at) < new Date();

  return (
    <div
      className={`flex items-start justify-between gap-2 p-2 rounded-md border text-xs ${
        isOverdue ? "border-destructive/50 bg-destructive/5" : "bg-muted/20"
      }`}
    >
      <div className="flex-1 min-w-0 space-y-1">
        <div className="flex items-center gap-2">
          <span className="font-medium capitalize">
            {task.task_type.replace(/_/g, " ")}
          </span>
          <span
            className={`px-1.5 py-0.5 rounded text-[10px] ${
              isPending
                ? isOverdue
                  ? "bg-destructive/20 text-destructive"
                  : "bg-yellow-100 text-yellow-800"
                : "bg-muted text-muted-foreground"
            }`}
          >
            {task.status}
          </span>
        </div>

        <div className="flex items-center gap-3 text-[10px] text-muted-foreground">
          {task.due_at && (
            <span className={isOverdue ? "text-destructive" : ""}>
              Due: {format(new Date(task.due_at), "MMM d, h:mm a")}
            </span>
          )}
          <span>
            Created: {format(new Date(task.created_at), "MMM d, yyyy")}
          </span>
        </div>
      </div>

      <ListenRowButton text={text} />
    </div>
  );
}
