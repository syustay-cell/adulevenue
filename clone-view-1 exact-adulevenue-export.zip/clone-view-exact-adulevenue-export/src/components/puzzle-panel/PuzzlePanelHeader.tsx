import React, { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useUserRoles } from "@/hooks/useUserRoles";
import { canAccessVault, type AppRole } from "@/lib/permissions";
import { canViewRawPii, maskEmail, maskPhone } from "@/lib/masking";
import { logVaultAccess } from "@/lib/auditLogger";
import { ListenButton } from "@/components/ui/ListenButton";
import { VaultAccessModal } from "./VaultAccessModal";
import { ArrowLeft, Lock, Phone, Mail } from "lucide-react";
import { Button } from "@/components/ui/button";

type Props = {
  intakeClientId: string;
  onClose: () => void;
};

export function PuzzlePanelHeader({ intakeClientId, onClose }: Props) {
  const { roles } = useUserRoles();
  const [vaultOpen, setVaultOpen] = useState(false);
  const canViewPii = canViewRawPii((roles as AppRole[]) || []);

  const { data, isLoading } = useQuery({
    queryKey: ["puzzle-header", intakeClientId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("intake_clients")
        .select("vault_id, full_name, business_name, phone_primary, email_primary")
        .eq("id", intakeClientId)
        .single();

      if (error) throw error;
      return data;
    },
  });

  const showVaultButton = canAccessVault(roles as AppRole[]);

  const handleViewVault = async () => {
    // Log vault access BEFORE opening modal
    await logVaultAccess(intakeClientId).catch(() => {});
    setVaultOpen(true);
  };

  const getReadableText = () => {
    if (!data) return "Loading client information.";
    const parts: string[] = [];
    if (data.vault_id) parts.push(`Vault ID: ${data.vault_id}`);
    if (data.full_name) parts.push(`Name: ${data.full_name}`);
    if (data.business_name) parts.push(`Business: ${data.business_name}`);
    if (data.phone_primary) parts.push(`Phone: ${canViewPii ? data.phone_primary : maskPhone(data.phone_primary)}`);
    if (data.email_primary) parts.push(`Email: ${canViewPii ? data.email_primary : maskEmail(data.email_primary)}`);
    return parts.join(". ");
  };

  return (
    <>
      <header className="px-4 py-3 border-b border-border flex items-center justify-between gap-3 bg-card">
        <div className="flex flex-col overflow-hidden">
          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="text-sm text-muted-foreground hover:text-foreground flex items-center gap-1"
            >
              <ArrowLeft className="h-4 w-4" />
              Back
            </button>
            <span className="text-xs uppercase tracking-wide text-muted-foreground font-mono">
              {data?.vault_id || "WF-??????"}
            </span>
            <ListenButton text={getReadableText()} />
          </div>

          <div className="mt-1">
            <div className="font-semibold truncate text-foreground">
              {isLoading ? "Loading..." : data?.full_name || "Unknown Client"}
            </div>
            <div className="text-xs text-muted-foreground truncate">
              {data?.business_name}
            </div>
          </div>

          <div className="mt-1 text-xs text-muted-foreground flex flex-wrap gap-3">
            {data?.phone_primary && (
              canViewPii ? (
                <a
                  href={`tel:${data.phone_primary}`}
                  className="flex items-center gap-1 hover:text-foreground"
                >
                  <Phone className="h-3 w-3" />
                  {data.phone_primary}
                </a>
              ) : (
                <span className="flex items-center gap-1">
                  <Phone className="h-3 w-3" />
                  {maskPhone(data.phone_primary)}
                </span>
              )
            )}
            {data?.email_primary && (
              canViewPii ? (
                <a
                  href={`mailto:${data.email_primary}`}
                  className="flex items-center gap-1 hover:text-foreground"
                >
                  <Mail className="h-3 w-3" />
                  {data.email_primary}
                </a>
              ) : (
                <span className="flex items-center gap-1">
                  <Mail className="h-3 w-3" />
                  {maskEmail(data.email_primary)}
                </span>
              )
            )}
          </div>
        </div>

        {showVaultButton && (
          <Button
            variant="outline"
            size="sm"
            onClick={handleViewVault}
            className="text-xs"
          >
            <Lock className="h-3 w-3 mr-1" />
            View Vault
          </Button>
        )}
      </header>

      <VaultAccessModal
        isOpen={vaultOpen}
        onClose={() => setVaultOpen(false)}
        intakeClientId={intakeClientId}
      />
    </>
  );
}
