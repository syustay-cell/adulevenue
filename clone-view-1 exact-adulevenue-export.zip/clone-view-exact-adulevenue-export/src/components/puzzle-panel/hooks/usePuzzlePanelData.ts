import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

/**
 * Stub hook for fetching puzzle panel data
 * Will be expanded in Step 4B to fetch data for each tab
 */
export function usePuzzlePanelData(intakeClientId: string | null) {
  // Fetch basic intake client info
  const clientQuery = useQuery({
    queryKey: ["puzzle-panel-client", intakeClientId],
    queryFn: async () => {
      if (!intakeClientId) return null;
      
      const { data, error } = await supabase
        .from("intake_clients")
        .select("*")
        .eq("id", intakeClientId)
        .single();

      if (error) throw error;
      return data;
    },
    enabled: !!intakeClientId,
  });

  return {
    client: clientQuery.data,
    isLoading: clientQuery.isLoading,
    error: clientQuery.error,
  };
}
