import React, { useState, useCallback } from "react";
import { logPanelOpen } from "@/lib/auditLogger";
import { PuzzlePanel } from "./PuzzlePanel";
import { PuzzlePanelContext, type PuzzlePanelContextValue } from "./PuzzlePanelContext";

export function PuzzlePanelProvider({ children }: { children: React.ReactNode }) {
  const [isOpen, setIsOpen] = useState(false);
  const [intakeClientId, setIntakeClientId] = useState<string | null>(null);

  const openPanel = useCallback(async (id: string) => {
    setIntakeClientId(id);
    setIsOpen(true);

    // Log panel open via centralized audit logger
    if (id) {
      await logPanelOpen(id).catch(() => {
        // Silent fail – do NOT break UI if logging fails
      });
    }
  }, []);

  const closePanel = useCallback(() => {
    setIsOpen(false);
    // We keep intakeClientId in memory in case user reopens quickly
  }, []);

  return (
    <PuzzlePanelContext.Provider
      value={{ isOpen, intakeClientId, openPanel, closePanel }}
    >
      {children}
      {/* Render the actual drawer at the root level */}
      <PuzzlePanel />
    </PuzzlePanelContext.Provider>
  );
}
