import React from "react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { ListenButton } from "@/components/ui/ListenButton";
import { Shield, Loader2 } from "lucide-react";

type VaultAccessModalProps = {
  isOpen: boolean;
  onClose: () => void;
  intakeClientId: string;
};

export function VaultAccessModal({
  isOpen,
  onClose,
  intakeClientId,
}: VaultAccessModalProps) {
  const { data, isLoading, error } = useQuery({
    queryKey: ["vault-access", intakeClientId],
    enabled: isOpen && !!intakeClientId,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("client_vault")
        .select("*")
        .eq("intake_client_id", intakeClientId)
        .maybeSingle();

      if (error) throw error;
      return data;
    },
  });

  const getReadableText = () => {
    if (!data) return "No vault data available.";
    const parts = [];
    if (data.real_name) parts.push(`Name: ${data.real_name}`);
    if (data.real_email) parts.push(`Email: ${data.real_email}`);
    if (data.real_phone) parts.push(`Phone: ${data.real_phone}`);
    if (data.real_address) parts.push(`Address: ${data.real_address}`);
    if (data.real_city) parts.push(`City: ${data.real_city}`);
    if (data.real_state) parts.push(`State: ${data.real_state}`);
    if (data.real_zip) parts.push(`ZIP: ${data.real_zip}`);
    if (data.real_ssn_last4) parts.push(`SSN Last 4: ${data.real_ssn_last4}`);
    return parts.length > 0 ? parts.join(". ") : "No vault data available.";
  };

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Shield className="h-4 w-4 text-primary" />
            Secure Vault Access
          </DialogTitle>
          <DialogDescription>
            Protected client PII — Owner & Legal only
          </DialogDescription>
        </DialogHeader>

        <div className="mt-2">
          {isLoading && (
            <div className="flex items-center justify-center py-8">
              <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
            </div>
          )}

          {error && (
            <div className="py-4 text-sm text-destructive">
              Access denied or vault not found.
            </div>
          )}

          {!isLoading && !error && !data && (
            <div className="py-4 text-sm text-muted-foreground">
              No vault record exists for this client.
            </div>
          )}

          {!isLoading && !error && data && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-medium text-muted-foreground uppercase tracking-wide">
                  Protected Information
                </span>
                <ListenButton text={getReadableText()} label="Listen" />
              </div>

              <div className="rounded-md border bg-muted/30 p-3 space-y-2 text-sm">
                <VaultField label="Full Name" value={data.real_name} />
                <VaultField label="Email" value={data.real_email} />
                <VaultField label="Phone" value={data.real_phone} />
                <VaultField label="Address" value={data.real_address} />
                <VaultField
                  label="City / State / ZIP"
                  value={
                    [data.real_city, data.real_state, data.real_zip]
                      .filter(Boolean)
                      .join(", ") || null
                  }
                />
                <VaultField
                  label="SSN (Last 4)"
                  value={data.real_ssn_last4 ? `••• ${data.real_ssn_last4}` : null}
                  sensitive
                />
              </div>

              <p className="text-[11px] text-muted-foreground">
                Vault ID: {data.vault_id || "N/A"}
              </p>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}

function VaultField({
  label,
  value,
  sensitive,
}: {
  label: string;
  value: string | null;
  sensitive?: boolean;
}) {
  if (!value) return null;

  return (
    <div className="flex justify-between gap-2">
      <span className="text-muted-foreground">{label}</span>
      <span className={sensitive ? "font-mono" : ""}>{value}</span>
    </div>
  );
}
