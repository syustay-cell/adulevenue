import React, { useMemo, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { usePuzzlePanelContext } from "./PuzzlePanelContext";
import { useUserRoles } from "@/hooks/useUserRoles";
import { getVisibleTabs, type AppRole } from "@/lib/permissions";
import { PuzzlePanelHeader } from "./PuzzlePanelHeader";

// Tab components
import { TimelineTab } from "./tabs/TimelineTab";
import { NotesTab } from "./tabs/NotesTab";
import { FundingTab } from "./tabs/FundingTab";
import { CreditTab } from "./tabs/CreditTab";
import { CollectionsTab } from "./tabs/CollectionsTab";
import { MerchantTab } from "./tabs/MerchantTab";
import { TasksTab } from "./tabs/TasksTab";

type TabKey =
  | "Timeline"
  | "Notes"
  | "Funding"
  | "Credit"
  | "Collections"
  | "Merchant"
  | "Tasks";

const ALL_TABS: { key: TabKey; label: string }[] = [
  { key: "Timeline", label: "Timeline" },
  { key: "Notes", label: "Notes" },
  { key: "Funding", label: "Funding" },
  { key: "Credit", label: "Credit" },
  { key: "Collections", label: "Collections" },
  { key: "Merchant", label: "Merchant" },
  { key: "Tasks", label: "Tasks" },
];

export function PuzzlePanel() {
  const { isOpen, intakeClientId, closePanel } = usePuzzlePanelContext();
  const { roles } = useUserRoles();
  const [activeTab, setActiveTab] = useState<TabKey>("Timeline");

  const visibleTabs = useMemo(() => {
    return getVisibleTabs(roles as AppRole[])
      .map((tabName) => ALL_TABS.find((t) => t.key === tabName))
      .filter(Boolean) as { key: TabKey; label: string }[];
  }, [roles]);

  // If panel is closed or no client selected, render nothing
  if (!isOpen || !intakeClientId) return null;

  const renderActiveTab = () => {
    switch (activeTab) {
      case "Timeline":
        return <TimelineTab intakeClientId={intakeClientId} />;
      case "Notes":
        return <NotesTab intakeClientId={intakeClientId} />;
      case "Funding":
        return <FundingTab intakeClientId={intakeClientId} />;
      case "Credit":
        return <CreditTab intakeClientId={intakeClientId} />;
      case "Collections":
        return <CollectionsTab intakeClientId={intakeClientId} />;
      case "Merchant":
        return <MerchantTab intakeClientId={intakeClientId} />;
      case "Tasks":
        return <TasksTab intakeClientId={intakeClientId} />;
      default:
        return null;
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            className="fixed inset-0 bg-background/80 backdrop-blur-sm z-40"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={closePanel}
          />
          {/* Drawer */}
          <motion.aside
            className="fixed right-0 top-0 h-full w-full max-w-xl bg-background border-l border-border shadow-xl z-50 flex flex-col"
            initial={{ x: "100%" }}
            animate={{ x: 0 }}
            exit={{ x: "100%" }}
            transition={{ duration: 0.25, ease: "easeOut" }}
          >
            <PuzzlePanelHeader intakeClientId={intakeClientId} onClose={closePanel} />

            {/* Tabs */}
            <div className="border-b border-border px-4 flex gap-2 overflow-x-auto">
              {visibleTabs.map((tab) => (
                <button
                  key={tab.key}
                  className={`py-2 text-sm border-b-2 transition-colors ${
                    activeTab === tab.key
                      ? "border-primary text-foreground font-semibold"
                      : "border-transparent text-muted-foreground hover:text-foreground"
                  }`}
                  onClick={() => setActiveTab(tab.key)}
                >
                  {tab.label}
                </button>
              ))}
            </div>

            {/* Content */}
            <div className="flex-1 overflow-y-auto p-4">
              {renderActiveTab()}
            </div>
          </motion.aside>
        </>
      )}
    </AnimatePresence>
  );
}
