// V25: Security context provider for role-based access

import { createContext, useContext, ReactNode, useMemo } from 'react';
import { useUserRoles } from '@/hooks/useUserRoles';
import { 
  getHighestRole, 
  hasRoleOrHigher, 
  canAccessVault as checkVaultAccess, 
  canAccessMotherboard as checkMotherboardAccess,
  isInternalRole 
} from '@/lib/roleHierarchy';

interface SecurityContextValue {
  isLoading: boolean;
  roles: string[];
  highestRole: string;
  canAccessVault: boolean;
  canAccessMotherboard: boolean;
  isInternal: boolean;
  hasRoleOrHigher: (minRole: string) => boolean;
}

const SecurityContext = createContext<SecurityContextValue | null>(null);

interface SecurityProviderProps {
  children: ReactNode;
}

export function SecurityProvider({ children }: SecurityProviderProps) {
  const { loading, roles, user } = useUserRoles();

  const value = useMemo<SecurityContextValue>(() => {
    const roleStrings = (roles || []) as string[];
    const highest = getHighestRole(roleStrings);

    return {
      isLoading: loading,
      roles: roleStrings,
      highestRole: highest,
      canAccessVault: checkVaultAccess(roleStrings),
      canAccessMotherboard: checkMotherboardAccess(roleStrings),
      isInternal: isInternalRole(highest),
      hasRoleOrHigher: (minRole: string) => hasRoleOrHigher(roleStrings, minRole),
    };
  }, [loading, roles]);

  return (
    <SecurityContext.Provider value={value}>
      {children}
    </SecurityContext.Provider>
  );
}

export function useSecurity(): SecurityContextValue {
  const context = useContext(SecurityContext);
  if (!context) {
    throw new Error('useSecurity must be used within a SecurityProvider');
  }
  return context;
}
