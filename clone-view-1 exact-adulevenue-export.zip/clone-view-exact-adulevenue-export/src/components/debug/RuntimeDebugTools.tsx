import React from "react";

type Level = "warn" | "error";

type LogEntry = {
  id: string;
  ts: string;
  level: Level;
  message: string;
};

function isDebugEnabled() {
  try {
    const sp = new URLSearchParams(window.location.search);
    if (sp.get("debug") === "1") return true;
    if (localStorage.getItem("wolf_debug_console") === "1") return true;
  } catch {
    // ignore
  }
  return false;
}

function formatArg(arg: unknown) {
  if (arg instanceof Error) return `${arg.name}: ${arg.message}${arg.stack ? `\n${arg.stack}` : ""}`;
  if (typeof arg === "string") return arg;
  try {
    return JSON.stringify(arg, null, 2);
  } catch {
    return String(arg);
  }
}

function formatMessage(args: unknown[]) {
  return args.map(formatArg).join(" ");
}

export class AppErrorBoundary extends React.Component<
  { children: React.ReactNode },
  { error: Error | null }
> {
  state: { error: Error | null } = { error: null };

  static getDerivedStateFromError(error: Error) {
    return { error };
  }

  componentDidCatch(error: Error, info: any) {
    console.error("[AppErrorBoundary] crashed", error, info);
  }

  render() {
    if (!this.state.error) return this.props.children;

    return (
      <div className="min-h-screen bg-background p-6">
        <div className="mx-auto max-w-3xl space-y-4">
          <div className="rounded-xl border border-destructive/30 bg-destructive/5 p-4">
            <div className="text-sm font-semibold text-destructive">Crash</div>
            <div className="mt-2 text-xs text-muted-foreground">
              <pre className="whitespace-pre-wrap break-words font-mono">
                {this.state.error.name}: {this.state.error.message}
                {this.state.error.stack ? `\n\n${this.state.error.stack}` : ""}
              </pre>
            </div>
          </div>

          <div className="rounded-xl border border-border/60 bg-card/50 p-4 text-xs text-muted-foreground">
            <div className="font-semibold text-foreground">How to capture logs on iPhone</div>
            <ul className="mt-2 list-disc pl-5 space-y-1">
              <li>
                If you have a Mac: enable iPhone Safari Web Inspector and use Safari{" "}
                <span className="font-mono">Develop</span> menu.
              </li>
              <li>
                No Mac: append <span className="font-mono">?debug=1</span> to the URL (or set{" "}
                <span className="font-mono">localStorage.wolf_debug_console=1</span>) to show the in-app debug
                console overlay.
              </li>
            </ul>
          </div>
        </div>
      </div>
    );
  }
}

export function RuntimeDebugTools() {
  const enabled = isDebugEnabled();
  const [open, setOpen] = React.useState(false);
  const [logs, setLogs] = React.useState<LogEntry[]>([]);

  React.useEffect(() => {
    if (!enabled) return;

    const push = (level: Level, args: unknown[]) => {
      const entry: LogEntry = {
        id: `${Date.now()}-${Math.random().toString(16).slice(2)}`,
        ts: new Date().toISOString(),
        level,
        message: formatMessage(args),
      };
      setLogs((prev) => [entry, ...prev].slice(0, 50));
    };

    const prevWarn = console.warn;
    const prevError = console.error;

    console.warn = (...args: any[]) => {
      push("warn", args);
      prevWarn(...args);
    };
    console.error = (...args: any[]) => {
      push("error", args);
      prevError(...args);
    };

    const onError = (event: ErrorEvent) => {
      push("error", [event.error ?? event.message ?? "window.onerror"]);
    };
    const onRejection = (event: PromiseRejectionEvent) => {
      push("error", [event.reason ?? "unhandledrejection"]);
    };

    window.addEventListener("error", onError);
    window.addEventListener("unhandledrejection", onRejection);

    return () => {
      console.warn = prevWarn;
      console.error = prevError;
      window.removeEventListener("error", onError);
      window.removeEventListener("unhandledrejection", onRejection);
    };
  }, [enabled]);

  if (!enabled) return null;

  return (
    <div className="fixed bottom-3 right-3 z-[9999] font-sans">
      <button
        type="button"
        className="rounded-full border border-border bg-background px-3 py-2 text-xs text-foreground shadow-md"
        onClick={() => setOpen((v) => !v)}
      >
        Debug ({logs.length})
      </button>

      {open && (
        <div className="mt-2 w-[92vw] max-w-[520px] rounded-xl border border-border bg-background shadow-xl">
          <div className="flex items-center justify-between border-b border-border px-3 py-2">
            <div className="text-xs font-semibold text-foreground">In-app console (last 50 warn/error)</div>
            <div className="flex items-center gap-2">
              <button
                type="button"
                className="text-xs text-muted-foreground underline"
                onClick={() => setLogs([])}
              >
                Clear
              </button>
              <button
                type="button"
                className="text-xs text-muted-foreground underline"
                onClick={() => setOpen(false)}
              >
                Close
              </button>
            </div>
          </div>
          <div className="max-h-[60vh] overflow-auto p-3">
            {logs.length === 0 ? (
              <div className="text-xs text-muted-foreground">No logs captured yet.</div>
            ) : (
              <div className="space-y-3">
                {logs.map((l) => (
                  <div key={l.id} className="rounded-lg border border-border/60 bg-muted/20 p-2">
                    <div className="flex items-center justify-between gap-3">
                      <span className="text-[11px] font-semibold text-foreground">{l.level.toUpperCase()}</span>
                      <span className="text-[11px] text-muted-foreground">{l.ts}</span>
                    </div>
                    <pre className="mt-1 whitespace-pre-wrap break-words text-[11px] text-muted-foreground">
                      {l.message}
                    </pre>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

