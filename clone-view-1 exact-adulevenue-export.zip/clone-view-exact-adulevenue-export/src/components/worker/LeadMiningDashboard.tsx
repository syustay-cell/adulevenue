import React, { useCallback, useEffect, useState } from 'react';
import { toast } from 'sonner';
import {
  runLeadOutreachBatch,
  getOutreachStats,
  getLeadMiningStats,
} from '@/lib/leadOutreachEngine';
import { getSystemModeState } from '@/lib/systemMode';
import { LiveActivityCommandCenter } from '@/components/admin/LiveActivityCommandCenter';

interface OutreachStats {
  todaySent: number;
  weekSent: number;
  maxPerDay: number;
  remaining: number;
}

interface MiningStats {
  todayMined: number;
  weekMined: number;
  totalLeads: number;
  pendingLeads: number;
}

export function LeadMiningDashboard() {
  const [outreachStats, setOutreachStats] = useState<OutreachStats | null>(null);
  const [miningStats, setMiningStats] = useState<MiningStats | null>(null);
  const [modeLabel, setModeLabel] = useState<string>('');
  const [loading, setLoading] = useState(false);
  const [refreshTrigger, setRefreshTrigger] = useState(0);

  const loadStats = useCallback(async () => {
    try {
      const [outreach, mining, modeState] = await Promise.all([
        getOutreachStats(),
        getLeadMiningStats(),
        getSystemModeState(),
      ]);

      setOutreachStats(outreach);
      setMiningStats(mining);
      setModeLabel(`${modeState.executionMode} · ${modeState.strategyProfile}`);
    } catch (err) {
      console.error('[LeadMiningDashboard] loadStats error:', err);
      toast.error('Failed to load lead mining stats');
    }
  }, []);

  useEffect(() => {
    loadStats();
  }, [loadStats]);

  const isManual = modeLabel.includes('MANUAL');

  async function handleRunBatch() {
    setLoading(true);
    try {
      const result = await runLeadOutreachBatch();
      toast.success(
        `Outreach batch complete – sent ${result.sent}, skipped ${result.skipped} (${result.mode})`
      );
      await loadStats();
      setRefreshTrigger((x) => x + 1);
    } catch (err) {
      console.error('[LeadMiningDashboard] handleRunBatch error:', err);
      toast.error('Failed to run outreach batch');
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-start justify-between gap-4">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">
            Lead Mining & Outreach
          </h1>
          <p className="text-sm text-muted-foreground mt-1">
            Respects global System Mode. Volumes and templates auto-adjust based on
            ECO / STANDARD / AGGRESSIVE.
          </p>
          <p className="text-xs text-muted-foreground mt-1">
            Current mode:{' '}
            <span className="font-medium">
              {modeLabel || 'Loading...'}
            </span>
          </p>
        </div>

        <button
          type="button"
          onClick={loadStats}
          disabled={loading}
          className="inline-flex items-center rounded-md border px-3 py-1.5 text-sm font-medium shadow-sm hover:bg-accent disabled:opacity-60"
        >
          {loading ? 'Refreshing…' : 'Refresh'}
        </button>
      </div>

      {/* Stats grid */}
      <div className="grid gap-4 sm:grid-cols-4">
        {/* Outreach stats */}
        <div className="rounded-lg border bg-card p-4">
          <p className="text-xs font-medium text-muted-foreground">
            Today Sent
          </p>
          <p className="mt-2 text-2xl font-semibold">
            {outreachStats?.todaySent ?? '—'}
          </p>
        </div>

        <div className="rounded-lg border bg-card p-4">
          <p className="text-xs font-medium text-muted-foreground">
            Week Sent
          </p>
          <p className="mt-2 text-2xl font-semibold">
            {outreachStats?.weekSent ?? '—'}
          </p>
        </div>

        <div className="rounded-lg border bg-card p-4">
          <p className="text-xs font-medium text-muted-foreground">
            Daily Cap
          </p>
          <p className="mt-2 text-2xl font-semibold">
            {outreachStats?.maxPerDay ?? '—'}
          </p>
        </div>

        <div className="rounded-lg border bg-card p-4">
          <p className="text-xs font-medium text-muted-foreground">
            Remaining Today
          </p>
          <p className="mt-2 text-2xl font-semibold">
            {outreachStats?.remaining ?? '—'}
          </p>
        </div>
      </div>

      {/* Mining stats */}
      <div className="grid gap-4 sm:grid-cols-4">
        <div className="rounded-lg border bg-card p-4">
          <p className="text-xs font-medium text-muted-foreground">
            Mined Today
          </p>
          <p className="mt-2 text-2xl font-semibold">
            {miningStats?.todayMined ?? '—'}
          </p>
        </div>

        <div className="rounded-lg border bg-card p-4">
          <p className="text-xs font-medium text-muted-foreground">
            Mined This Week
          </p>
          <p className="mt-2 text-2xl font-semibold">
            {miningStats?.weekMined ?? '—'}
          </p>
        </div>

        <div className="rounded-lg border bg-card p-4">
          <p className="text-xs font-medium text-muted-foreground">
            Total Leads
          </p>
          <p className="mt-2 text-2xl font-semibold">
            {miningStats?.totalLeads ?? '—'}
          </p>
        </div>

        <div className="rounded-lg border bg-card p-4">
          <p className="text-xs font-medium text-muted-foreground">
            Pending (New)
          </p>
          <p className="mt-2 text-2xl font-semibold">
            {miningStats?.pendingLeads ?? '—'}
          </p>
        </div>
      </div>

      {/* Action card */}
      <div className="rounded-lg border bg-card p-4">
        <div className="flex items-start justify-between gap-4">
          <div>
            <h2 className="text-sm font-medium">
              Run Outreach Batch
            </h2>
            <p className="mt-1 text-xs text-muted-foreground">
              {isManual
                ? 'Manual mode active – batch will only log proposals without sending emails.'
                : `Autopilot will send up to ${
                    outreachStats?.remaining ?? 0
                  } emails based on the current strategy.`}
            </p>
          </div>

          <button
            type="button"
            onClick={handleRunBatch}
            disabled={loading}
            className="inline-flex items-center rounded-md bg-primary px-3 py-1.5 text-sm font-medium text-primary-foreground shadow-sm hover:bg-primary/90 disabled:opacity-60"
          >
            {loading ? 'Running…' : 'Run Batch'}
          </button>
        </div>
      </div>

      {/* Activity feed – refreshed when batch runs */}
      <div>
        <LiveActivityCommandCenter refreshTrigger={refreshTrigger} />
      </div>
    </div>
  );
}
