import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import { FileText, Download, Wand2 } from "lucide-react";
import { generateDocument } from "@/lib/templateRenderer";

interface Template {
  id: string;
  category: string;
  name: string;
  channel: string;
}

interface GenerateDocumentButtonProps {
  leadId: string;
  leadName?: string;
}

export function GenerateDocumentButton({ leadId, leadName }: GenerateDocumentButtonProps) {
  const [open, setOpen] = useState(false);
  const [templates, setTemplates] = useState<Template[]>([]);
  const [selectedCategory, setSelectedCategory] = useState("");
  const [selectedTemplate, setSelectedTemplate] = useState("");
  const [loading, setLoading] = useState(false);
  const [preview, setPreview] = useState<{ subject?: string; body: string } | null>(null);

  useEffect(() => {
    if (open) {
      fetchTemplates();
    }
  }, [open]);

  async function fetchTemplates() {
    const { data } = await supabase
      .from("templates_master_library")
      .select("id, category, name, channel")
      .order("category")
      .order("name");

    setTemplates(data || []);
  }

  const categories = [...new Set(templates.map((t) => t.category))];
  const filteredTemplates = selectedCategory
    ? templates.filter((t) => t.category === selectedCategory)
    : templates;

  async function handleGenerate() {
    if (!selectedTemplate) {
      toast.error("Please select a template");
      return;
    }

    setLoading(true);
    const result = await generateDocument(selectedTemplate, leadId);
    setLoading(false);

    if (result.error) {
      toast.error(result.error);
    } else {
      setPreview(result);
      toast.success("Document generated successfully");
    }
  }

  function handleDownload() {
    if (!preview) return;

    const template = templates.find((t) => t.id === selectedTemplate);
    const content = preview.subject
      ? `Subject: ${preview.subject}\n\n${preview.body}`
      : preview.body;

    const blob = new Blob([content], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${leadName || "document"}_${template?.name || "generated"}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm">
          <FileText className="h-4 w-4 mr-2" />
          Generate Document
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Generate Document (Auto-Fill)</DialogTitle>
        </DialogHeader>

        <div className="space-y-4 mt-4">
          {!preview ? (
            <>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium">Category</label>
                  <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                    <SelectTrigger>
                      <SelectValue placeholder="All categories" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="">All categories</SelectItem>
                      {categories.map((cat) => (
                        <SelectItem key={cat} value={cat}>
                          {cat}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium">Template</label>
                  <Select value={selectedTemplate} onValueChange={setSelectedTemplate}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select template" />
                    </SelectTrigger>
                    <SelectContent>
                      {filteredTemplates.map((t) => (
                        <SelectItem key={t.id} value={t.id}>
                          {t.name} ({t.channel})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <p className="text-sm text-muted-foreground">
                The document will be automatically filled with data from the selected lead.
              </p>

              <div className="flex justify-end gap-2">
                <Button variant="outline" onClick={() => setOpen(false)}>
                  Cancel
                </Button>
                <Button onClick={handleGenerate} disabled={loading || !selectedTemplate}>
                  <Wand2 className="h-4 w-4 mr-2" />
                  {loading ? "Generating..." : "Generate"}
                </Button>
              </div>
            </>
          ) : (
            <>
              {preview.subject && (
                <div>
                  <label className="text-sm font-medium text-muted-foreground">Subject</label>
                  <div className="p-3 bg-muted rounded-lg mt-1">{preview.subject}</div>
                </div>
              )}

              <div>
                <label className="text-sm font-medium text-muted-foreground">Body</label>
                <Textarea
                  value={preview.body}
                  readOnly
                  rows={12}
                  className="mt-1 font-mono text-sm"
                />
              </div>

              <div className="flex justify-end gap-2">
                <Button
                  variant="outline"
                  onClick={() => {
                    setPreview(null);
                    setSelectedTemplate("");
                  }}
                >
                  Generate Another
                </Button>
                <Button onClick={handleDownload}>
                  <Download className="h-4 w-4 mr-2" />
                  Download
                </Button>
              </div>
            </>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
