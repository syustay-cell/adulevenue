import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Loader2, TrendingUp, FileText, Wrench } from "lucide-react";
import { ClickablePhone, ClickableEmail } from "@/components/ui/clickable-contact";

interface PipelineItem {
  id: string;
  type: 'lead' | 'application' | 'credit_case';
  name: string;
  business: string | null;
  email: string | null;
  phone: string | null;
  status: string;
  updated_at: string;
}

export const MyPipeline = () => {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [items, setItems] = useState<PipelineItem[]>([]);

  useEffect(() => {
    loadPipeline();
  }, []);

  const loadPipeline = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      // Load leads
      const { data: leads } = await supabase
        .from('leads')
        .select('id, full_name, business_name, email, phone, status, updated_at')
        .eq('assigned_worker_id', user.id)
        .order('updated_at', { ascending: false })
        .limit(20);

      // Load applications
      const { data: applications } = await supabase
        .from('fast_track_applications')
        .select('id, client_name, business_name, email, phone, status, updated_at')
        .eq('user_id', user.id)
        .order('updated_at', { ascending: false })
        .limit(20);

      // Load credit cases
      const { data: creditCases } = await supabase
        .from('credit_repair_cases')
        .select(`
          id, status, updated_at,
          credit_repair_applications!inner(full_name, email, phone)
        `)
        .eq('credit_repair_applications.iso_partner_user_id', user.id)
        .order('updated_at', { ascending: false })
        .limit(20);

      const pipelineItems: PipelineItem[] = [
        ...(leads || []).map(l => ({
          id: l.id,
          type: 'lead' as const,
          name: l.full_name || 'Unnamed Lead',
          business: l.business_name,
          email: l.email,
          phone: l.phone,
          status: l.status || 'new',
          updated_at: l.updated_at || new Date().toISOString(),
        })),
        ...(applications || []).map(a => ({
          id: a.id,
          type: 'application' as const,
          name: a.client_name || 'Unnamed Client',
          business: a.business_name,
          email: a.email,
          phone: a.phone,
          status: a.status,
          updated_at: a.updated_at,
        })),
        ...(creditCases || []).map((c: any) => ({
          id: c.id,
          type: 'credit_case' as const,
          name: c.credit_repair_applications?.full_name || 'Unnamed Client',
          business: null,
          email: c.credit_repair_applications?.email,
          phone: c.credit_repair_applications?.phone,
          status: c.status,
          updated_at: c.updated_at,
        })),
      ];

      pipelineItems.sort((a, b) => 
        new Date(b.updated_at).getTime() - new Date(a.updated_at).getTime()
      );

      setItems(pipelineItems);
    } catch (err) {
      console.error('Failed to load pipeline:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleItemClick = (item: PipelineItem) => {
    if (item.type === 'lead') {
      navigate(`/lead-engine?leadId=${item.id}`);
    } else if (item.type === 'application') {
      navigate(`/fast-track?applicationId=${item.id}`);
    } else if (item.type === 'credit_case') {
      navigate(`/credit-specialist-dashboard?caseId=${item.id}`);
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'lead':
        return <TrendingUp className="h-4 w-4" />;
      case 'application':
        return <FileText className="h-4 w-4" />;
      case 'credit_case':
        return <Wrench className="h-4 w-4" />;
      default:
        return null;
    }
  };

  const getTypeBadge = (type: string) => {
    switch (type) {
      case 'lead':
        return <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">Lead</Badge>;
      case 'application':
        return <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">Funding</Badge>;
      case 'credit_case':
        return <Badge variant="outline" className="bg-amber-50 text-amber-700 border-amber-200">Credit Fix</Badge>;
      default:
        return null;
    }
  };

  if (loading) {
    return (
      <Card>
        <CardContent className="pt-6">
          <div className="flex items-center justify-center py-8">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>My Pipeline</CardTitle>
        <p className="text-sm text-muted-foreground">
          All your leads, applications, and credit cases in one place
        </p>
      </CardHeader>
      <CardContent>
        {items.length === 0 ? (
          <p className="text-center py-8 text-muted-foreground">
            No items in your pipeline yet
          </p>
        ) : (
          <div className="space-y-3">
            {items.map((item) => (
              <div
                key={`${item.type}-${item.id}`}
                onClick={() => handleItemClick(item)}
                className="p-4 rounded-lg border border-border bg-muted/50 hover:bg-muted cursor-pointer transition-colors"
              >
                <div className="flex items-start justify-between mb-2">
                  <div className="flex items-center gap-2">
                    {getTypeIcon(item.type)}
                    <div>
                      <div className="font-medium text-sm">{item.name}</div>
                      {item.business && (
                        <div className="text-xs text-muted-foreground">{item.business}</div>
                      )}
                    </div>
                  </div>
                  {getTypeBadge(item.type)}
                </div>
                <div className="flex items-center gap-4 text-xs text-muted-foreground">
                  {item.email && <ClickableEmail email={item.email} />}
                  {item.phone && <ClickablePhone phone={item.phone} />}
                  <Badge variant="secondary" className="text-xs">
                    {item.status}
                  </Badge>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
};
