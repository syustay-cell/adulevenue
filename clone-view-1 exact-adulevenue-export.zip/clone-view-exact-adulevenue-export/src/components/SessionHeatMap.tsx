// src/components/SessionHeatMap.tsx
// V11 / B200: Portal heat map visualization

import React from "react";

interface SessionHeatMapProps {
  portalHeat: Record<string, number>;
}

export const SessionHeatMap: React.FC<SessionHeatMapProps> = ({ portalHeat }) => {
  const entries = Object.entries(portalHeat || {});
  if (entries.length === 0) {
    return <div className="text-xs text-muted-foreground">No recent portal activity.</div>;
  }

  const max = Math.max(...entries.map(([_, count]) => count));

  return (
    <div className="space-y-2">
      {entries.map(([portal, count]) => {
        const widthPct = max > 0 ? (count / max) * 100 : 0;
        return (
          <div key={portal}>
            <div className="flex justify-between text-xs mb-1">
              <span className="font-medium capitalize">{portal}</span>
              <span className="text-muted-foreground">{count} sessions</span>
            </div>
            <div className="w-full bg-muted h-2 rounded">
              <div
                className="h-2 rounded bg-primary"
                style={{ width: `${widthPct}%` }}
              />
            </div>
          </div>
        );
      })}
    </div>
  );
};
