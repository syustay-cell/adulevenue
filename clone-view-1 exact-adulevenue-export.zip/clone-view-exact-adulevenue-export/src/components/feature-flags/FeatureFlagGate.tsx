import { ReactNode } from "react";
import { Loader2 } from "lucide-react";
import { useFeatureFlag } from "@/hooks/useFeatureFlag";

interface FeatureFlagGateProps {
  flag: string;
  children: ReactNode;
  fallback?: ReactNode;
}

export function FeatureFlagGate({ flag, children, fallback }: FeatureFlagGateProps) {
  const { enabled, loading, error } = useFeatureFlag(flag);

  if (loading) {
    return (
      <div className="flex h-[60vh] w-full items-center justify-center text-muted-foreground">
        <div className="flex items-center gap-2 text-sm">
          <Loader2 className="h-4 w-4 animate-spin" />
          <span>Loading feature flag…</span>
        </div>
      </div>
    );
  }

  if (!enabled) {
    if (fallback) return <>{fallback}</>;

    return (
      <div className="mx-auto flex max-w-xl flex-col items-center gap-3 px-6 py-16 text-center">
        <div className="text-sm font-medium uppercase tracking-wide text-muted-foreground">
          Preview Locked
        </div>
        <p className="text-lg font-semibold text-foreground">Feature flag {flag} is disabled</p>
        <p className="text-sm text-muted-foreground">
          This module is currently running in shadow mode. Enable {flag} in the Motherboard to expose it
          to end users.
        </p>
        {error && (
          <div className="mt-2 w-full rounded-lg border border-destructive/30 bg-destructive/5 p-3 text-left">
            <p className="text-xs font-semibold text-destructive">
              Blocked: unable to read `wolf_feature_flags` (likely RLS)
            </p>
            <p className="mt-1 text-xs text-muted-foreground">
              Error: <span className="font-mono">{error}</span>
            </p>
            <p className="mt-2 text-xs text-muted-foreground">
              Expected: the current user must be allowed to SELECT `wolf_feature_flags` (or this gate will always fail closed).
            </p>
          </div>
        )}
      </div>
    );
  }

  return <>{children}</>;
}
