import { useUserRoles } from "@/hooks/useUserRoles";
import { getHighestRole } from "@/lib/roleHierarchy";

export function WolfFooter() {
  const { roles } = useUserRoles();
  const highest = getHighestRole(roles || []);
  const isOwner = highest === "owner" || highest === "super_owner";

  return (
    <div className="mt-2 border-t border-border pt-2 text-[10px] text-muted-foreground flex justify-between">
      <span>
        {isOwner ? (
          <>© {new Date().getFullYear()} Wolf-Fund.com™ – Wolf Fund OS™</>
        ) : (
          <>© Wolf-Fund.com – proprietary system</>
        )}
      </span>
      <span className="opacity-60">
        Patent-pending multi-tenant funding engine
      </span>
    </div>
  );
}
