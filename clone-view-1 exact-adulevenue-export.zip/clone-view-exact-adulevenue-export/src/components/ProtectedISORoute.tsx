import { useEffect, useState } from "react";
import { Navigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Loader2 } from "lucide-react";
import { AuthGateError } from "@/components/auth/AuthGateError";
import type { Session } from "@supabase/supabase-js";

interface ProtectedISORouteProps {
  children: React.ReactNode;
}

export const ProtectedISORoute = ({ children }: ProtectedISORouteProps) => {
  const [loading, setLoading] = useState(true);
  const [user, setUser] = useState<any>(null);
  const [isISO, setIsISO] = useState(false);
  const [authError, setAuthError] = useState<string | null>(null);

  useEffect(() => {
    void checkAuth();

    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      void checkAuth(session);
    });

    return () => subscription.unsubscribe();
  }, []);

  const checkAuth = async (sessionOverride?: Session | null) => {
    try {
      setLoading(true);
      setAuthError(null);

      const sessionResult = sessionOverride !== undefined
        ? { session: sessionOverride, error: null }
        : await supabase.auth.getSession().then(({ data, error }) => ({ session: data.session, error }));

      if (sessionResult.error) {
        setAuthError(sessionResult.error.message);
        setLoading(false);
        return;
      }

      const session = sessionResult.session;
      if (!session) {
        setUser(null);
        setIsISO(false);
        setLoading(false);
        return;
      }

      setUser(session.user);

      const { data: hasIsoRole, error: roleError } = await supabase.rpc("has_role", {
        user_id: session.user.id,
        required_role: "iso_partner",
      });

      if (roleError) {
        console.error("[ProtectedISORoute] has_role RPC error:", roleError);
        setAuthError(`has_role RPC error: ${roleError.message}`);
        setIsISO(false);
        setLoading(false);
        return;
      }

      const allowed = Boolean(hasIsoRole);
      setIsISO(allowed);

      console.info("[ProtectedISORoute] ISO gate", {
        authUid: session.user.id,
        hasIsoRole: Boolean(hasIsoRole),
        decision: allowed ? "allow" : "deny",
        decisionSource: "has_role",
        decisionReason: allowed ? "has_role:true" : "has_role:false",
      });

      setLoading(false);
    } catch (error) {
      console.error("Auth check error:", error);
      setAuthError(error instanceof Error ? error.message : "Unknown error");
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (authError) {
    return <AuthGateError message={authError} />;
  }

  if (!user) {
    return <Navigate to="/auth" replace />;
  }

  if (!isISO) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4">
        <div className="text-center">
          <h1 className="text-4xl font-bold text-foreground mb-4">Access Denied</h1>
          <p className="text-muted-foreground mb-4">You need ISO Partner access to view this page.</p>
          <a href="/" className="text-primary hover:underline">Go to homepage</a>
        </div>
      </div>
    );
  }

  return <>{children}</>;
};
