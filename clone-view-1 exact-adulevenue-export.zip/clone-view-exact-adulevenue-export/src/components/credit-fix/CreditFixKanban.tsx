import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { 
  User, 
  FileText, 
  Search, 
  Clock, 
  CheckCircle,
  AlertTriangle,
  ChevronRight,
  RefreshCw
} from "lucide-react";

interface CreditCase {
  id: string;
  status: string;
  ai_score: number | null;
  ai_recommended_path: string | null;
  created_at: string;
  credit_repair_application_id: string;
  application?: {
    full_name: string;
    email: string;
    phone: string;
  };
}

const columns = [
  { id: "intake", label: "Intake", icon: User, color: "bg-blue-500" },
  { id: "docs_pending", label: "Docs Pending", icon: FileText, color: "bg-amber-500" },
  { id: "investigation", label: "Investigation", icon: Search, color: "bg-purple-500" },
  { id: "bureaus_pending", label: "Bureaus", icon: Clock, color: "bg-orange-500" },
  { id: "results_received", label: "Results", icon: AlertTriangle, color: "bg-cyan-500" },
  { id: "completed", label: "Completed", icon: CheckCircle, color: "bg-emerald-500" },
];

interface CreditFixKanbanProps {
  onSelectCase: (caseId: string) => void;
  selectedCaseId: string | null;
}

export function CreditFixKanban({ onSelectCase, selectedCaseId }: CreditFixKanbanProps) {
  const { toast } = useToast();
  const [cases, setCases] = useState<CreditCase[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadCases();
  }, []);

  const loadCases = async () => {
    setLoading(true);
    try {
      const { data: casesData, error } = await supabase
        .from("credit_repair_cases")
        .select(`
          id,
          status,
          ai_score,
          ai_recommended_path,
          created_at,
          credit_repair_application_id
        `)
        .order("created_at", { ascending: false });

      if (error) throw error;

      // Fetch application details
      const appIds = casesData?.map(c => c.credit_repair_application_id) || [];
      const { data: apps } = await supabase
        .from("credit_repair_applications")
        .select("id, full_name, email, phone")
        .in("id", appIds);

      const enrichedCases = casesData?.map(c => ({
        ...c,
        application: apps?.find(a => a.id === c.credit_repair_application_id),
      })) || [];

      setCases(enrichedCases);
    } catch (err) {
      console.error("Failed to load cases:", err);
      toast({
        variant: "destructive",
        title: "Failed to load cases",
      });
    } finally {
      setLoading(false);
    }
  };

  const moveCase = async (caseId: string, newStatus: string) => {
    try {
      const { error } = await supabase
        .from("credit_repair_cases")
        .update({ status: newStatus, updated_at: new Date().toISOString() })
        .eq("id", caseId);

      if (error) throw error;

      setCases(prev => prev.map(c => 
        c.id === caseId ? { ...c, status: newStatus } : c
      ));

      toast({ title: "Case moved" });
    } catch (err) {
      console.error("Move error:", err);
      toast({ variant: "destructive", title: "Failed to move case" });
    }
  };

  const getCasesByStatus = (status: string) => 
    cases.filter(c => c.status === status);

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-sm font-semibold text-slate-100">Credit Fix Pipeline</h2>
          <p className="text-[10px] text-slate-500">{cases.length} total cases</p>
        </div>
        <Button
          variant="ghost"
          size="sm"
          onClick={loadCases}
          disabled={loading}
          className="h-7 text-[10px]"
        >
          <RefreshCw className={`h-3 w-3 mr-1 ${loading ? "animate-spin" : ""}`} />
          Refresh
        </Button>
      </div>

      {/* Kanban Board */}
      <div className="flex gap-3 overflow-x-auto pb-4">
        {columns.map(column => {
          const columnCases = getCasesByStatus(column.id);
          const Icon = column.icon;

          return (
            <div
              key={column.id}
              className="flex-shrink-0 w-56 rounded-xl bg-slate-900/60 border border-slate-800"
            >
              {/* Column Header */}
              <div className="flex items-center gap-2 px-3 py-2 border-b border-slate-800">
                <div className={`h-2 w-2 rounded-full ${column.color}`} />
                <span className="text-[11px] font-medium text-slate-200">
                  {column.label}
                </span>
                <Badge variant="secondary" className="ml-auto h-4 text-[9px] px-1.5">
                  {columnCases.length}
                </Badge>
              </div>

              {/* Cards */}
              <ScrollArea className="h-[400px] p-2">
                <div className="space-y-2">
                  {columnCases.map(caseItem => (
                    <div
                      key={caseItem.id}
                      onClick={() => onSelectCase(caseItem.id)}
                      className={`group cursor-pointer rounded-lg border p-2.5 transition-all hover:border-primary/50 ${
                        selectedCaseId === caseItem.id
                          ? "border-primary bg-primary/5"
                          : "border-slate-700/50 bg-slate-950/50"
                      }`}
                    >
                      <div className="flex items-start justify-between gap-2">
                        <div className="min-w-0 flex-1">
                          <p className="text-[11px] font-medium text-slate-100 truncate">
                            {caseItem.application?.full_name || "Unknown"}
                          </p>
                          <p className="text-[9px] text-slate-500 truncate">
                            {caseItem.application?.email}
                          </p>
                        </div>
                        {caseItem.ai_score != null && (
                          <Badge
                            variant="outline"
                            className={`text-[8px] h-4 px-1 ${
                              caseItem.ai_score >= 70
                                ? "border-emerald-500/50 text-emerald-400"
                                : caseItem.ai_score >= 40
                                ? "border-amber-500/50 text-amber-400"
                                : "border-rose-500/50 text-rose-400"
                            }`}
                          >
                            {caseItem.ai_score}
                          </Badge>
                        )}
                      </div>

                      {/* Quick Actions */}
                      <div className="mt-2 flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                        {column.id !== "completed" && (
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={(e) => {
                              e.stopPropagation();
                              const nextIdx = columns.findIndex(c => c.id === column.id) + 1;
                              if (nextIdx < columns.length) {
                                moveCase(caseItem.id, columns[nextIdx].id);
                              }
                            }}
                            className="h-5 text-[9px] px-2 py-0"
                          >
                            Move <ChevronRight className="h-2.5 w-2.5 ml-0.5" />
                          </Button>
                        )}
                      </div>
                    </div>
                  ))}

                  {columnCases.length === 0 && (
                    <div className="py-8 text-center">
                      <Icon className="h-6 w-6 text-slate-700 mx-auto mb-1" />
                      <p className="text-[10px] text-slate-600">No cases</p>
                    </div>
                  )}
                </div>
              </ScrollArea>
            </div>
          );
        })}
      </div>
    </div>
  );
}
