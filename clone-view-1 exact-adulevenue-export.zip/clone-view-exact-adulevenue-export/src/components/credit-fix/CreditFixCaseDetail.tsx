import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { useUserRoles } from "@/hooks/useUserRoles";
import { canViewRawPii, maskEmail, maskPhone } from "@/lib/masking";
import type { AppRole } from "@/lib/permissions";
import {
  User,
  Phone,
  Mail,
  FileText,
  Brain,
  AlertTriangle,
  CheckCircle,
  Clock,
  Loader2,
  Scale,
} from "lucide-react";

interface CreditFixCaseDetailProps {
  caseId: string | null;
}

export function CreditFixCaseDetail({ caseId }: CreditFixCaseDetailProps) {
  const { toast } = useToast();
  const { roles } = useUserRoles();
  const canViewPii = canViewRawPii((roles as AppRole[]) || []);
  const [caseData, setCaseData] = useState<any>(null);
  const [items, setItems] = useState<any[]>([]);
  const [drafts, setDrafts] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [aiLoading, setAiLoading] = useState(false);

  useEffect(() => {
    if (caseId) loadCaseData();
  }, [caseId]);

  const loadCaseData = async () => {
    if (!caseId) return;
    setLoading(true);

    try {
      // Load case with application
      const { data: caseResult } = await supabase
        .from("credit_repair_cases")
        .select("*")
        .eq("id", caseId)
        .single();

      if (caseResult) {
        const { data: app } = await supabase
          .from("credit_repair_applications")
          .select("*")
          .eq("id", caseResult.credit_repair_application_id)
          .single();

        setCaseData({ ...caseResult, application: app });
      }

      // Load items
      const { data: itemsData } = await supabase
        .from("credit_repair_items")
        .select("*")
        .eq("case_id", caseId)
        .order("created_at", { ascending: false });
      setItems(itemsData || []);

      // Load drafts
      const { data: draftsData } = await supabase
        .from("credit_repair_dispute_drafts")
        .select("*")
        .eq("case_id", caseId)
        .order("created_at", { ascending: false });
      setDrafts(draftsData || []);
    } catch (err) {
      console.error("Load error:", err);
    } finally {
      setLoading(false);
    }
  };

  const runAiAnalysis = async (action: string) => {
    if (!caseId) return;
    setAiLoading(true);

    try {
      const functionMap: Record<string, string> = {
        analyze: "credit-repair-analyze-report",
        strategy: "credit-repair-generate-strategy",
        letters: "credit-repair-generate-letters",
        followup: "credit-repair-suggest-followup",
      };

      const body: Record<string, unknown> = { case_id: caseId };
      // Strategy + letters require item_ids (edge function validation)
      if (action === "strategy" || action === "letters") {
        const itemIds = items.map((i) => i.id).filter(Boolean);
        body.item_ids = itemIds;
      }

      const { data, error } = await supabase.functions.invoke(functionMap[action], { body });

      if (error) throw error;
      if (data?.ok === false) {
        throw new Error(data?.message || "AI request failed");
      }

      toast({
        title: "AI Analysis Complete",
        description: data?.message || "Analysis finished",
      });

      loadCaseData();
    } catch (err: any) {
      console.error("AI error:", err);
      toast({
        variant: "destructive",
        title: "AI Analysis Failed",
        description: err.message,
      });
    } finally {
      setAiLoading(false);
    }
  };

  if (!caseId) {
    return (
      <div className="flex flex-col items-center justify-center h-[500px] text-slate-500">
        <FileText className="h-12 w-12 mb-3 opacity-30" />
        <p className="text-sm">Select a case to view details</p>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-[500px]">
        <Loader2 className="h-6 w-6 animate-spin text-primary" />
      </div>
    );
  }

  const app = caseData?.application;

  return (
    <div className="space-y-4">
      {/* Client Info Header */}
      <Card className="border-slate-800 bg-slate-900/60">
        <CardContent className="p-4">
          <div className="flex items-start justify-between">
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <User className="h-4 w-4 text-slate-400" />
                <span className="font-medium text-slate-100">
                  {app?.full_name || "Unknown Client"}
                </span>
                <Badge variant="outline" className="text-[9px]">
                  {caseData?.status?.replace("_", " ")}
                </Badge>
              </div>
              <div className="flex items-center gap-4 text-[11px] text-slate-400">
                {app?.email && (
                  canViewPii ? (
                    <a href={`mailto:${app.email}`} className="flex items-center gap-1 hover:text-primary">
                      <Mail className="h-3 w-3" />
                      {app.email}
                    </a>
                  ) : (
                    <span className="flex items-center gap-1">
                      <Mail className="h-3 w-3" />
                      {maskEmail(app.email)}
                    </span>
                  )
                )}
                {app?.phone && (
                  canViewPii ? (
                    <a href={`tel:${app.phone}`} className="flex items-center gap-1 hover:text-primary">
                      <Phone className="h-3 w-3" />
                      {app.phone}
                    </a>
                  ) : (
                    <span className="flex items-center gap-1">
                      <Phone className="h-3 w-3" />
                      {maskPhone(app.phone)}
                    </span>
                  )
                )}
              </div>
            </div>

            {caseData?.ai_score != null && (
              <div className="text-right">
                <div className="text-2xl font-bold text-primary">{caseData.ai_score}</div>
                <div className="text-[9px] text-slate-500">AI Score</div>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* AI Control Panel */}
      <Card className="border-slate-800 bg-slate-900/60">
        <CardHeader className="py-3">
          <CardTitle className="text-xs font-medium text-slate-300 flex items-center gap-2">
            <Brain className="h-3.5 w-3.5 text-primary" />
            AI Control Panel
          </CardTitle>
        </CardHeader>
        <CardContent className="pb-4">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            {[
              { key: "analyze", label: "Analyze Report", icon: FileText },
              { key: "strategy", label: "Generate Strategy", icon: Brain },
              { key: "letters", label: "Draft Letters", icon: Mail },
              { key: "followup", label: "Suggest Follow-up", icon: Clock },
            ].map(({ key, label, icon: Icon }) => (
              <Button
                key={key}
                variant="outline"
                size="sm"
                disabled={aiLoading}
                onClick={() => runAiAnalysis(key)}
                className="h-9 text-[10px] border-slate-700 hover:border-primary/50"
              >
                {aiLoading ? (
                  <Loader2 className="h-3 w-3 animate-spin mr-1" />
                ) : (
                  <Icon className="h-3 w-3 mr-1" />
                )}
                {label}
              </Button>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Tabs */}
      <Tabs defaultValue="items" className="w-full">
        <TabsList className="bg-slate-900 border border-slate-800">
          <TabsTrigger value="items" className="text-[11px]">
            Negative Items ({items.length})
          </TabsTrigger>
          <TabsTrigger value="drafts" className="text-[11px]">
            Dispute Drafts ({drafts.length})
          </TabsTrigger>
          <TabsTrigger value="compliance" className="text-[11px]">
            Compliance
          </TabsTrigger>
        </TabsList>

        <TabsContent value="items" className="mt-3">
          <ScrollArea className="h-[300px]">
            <div className="space-y-2">
              {items.map((item) => (
                <div
                  key={item.id}
                  className="rounded-lg border border-slate-800 bg-slate-950/50 p-3"
                >
                  <div className="flex items-start justify-between">
                    <div>
                      <p className="text-[11px] font-medium text-slate-200">
                        {item.creditor_name || "Unknown Creditor"}
                      </p>
                      <p className="text-[10px] text-slate-500">
                        {item.item_type} • {item.source_bureau}
                      </p>
                    </div>
                    <Badge
                      variant="outline"
                      className={`text-[8px] ${
                        item.status === "resolved"
                          ? "border-emerald-500/50 text-emerald-400"
                          : item.status === "disputed"
                          ? "border-amber-500/50 text-amber-400"
                          : "border-slate-500/50 text-slate-400"
                      }`}
                    >
                      {item.status}
                    </Badge>
                  </div>
                  {item.fcra_section && (
                    <div className="mt-2 flex items-center gap-1 text-[9px] text-purple-400">
                      <Scale className="h-2.5 w-2.5" />
                      FCRA {item.fcra_section}
                    </div>
                  )}
                </div>
              ))}
              {items.length === 0 && (
                <p className="text-center py-8 text-[11px] text-slate-500">
                  No negative items found
                </p>
              )}
            </div>
          </ScrollArea>
        </TabsContent>

        <TabsContent value="drafts" className="mt-3">
          <ScrollArea className="h-[300px]">
            <div className="space-y-2">
              {drafts.map((draft) => (
                <div
                  key={draft.id}
                  className="rounded-lg border border-slate-800 bg-slate-950/50 p-3"
                >
                  <div className="flex items-start justify-between mb-2">
                    <div>
                      <p className="text-[11px] font-medium text-slate-200">
                        {draft.subject}
                      </p>
                      <p className="text-[10px] text-slate-500">
                        To: {draft.target_name}
                      </p>
                    </div>
                    <Badge
                      variant="outline"
                      className={`text-[8px] ${
                        draft.status === "approved"
                          ? "border-emerald-500/50 text-emerald-400"
                          : draft.status === "sent"
                          ? "border-blue-500/50 text-blue-400"
                          : "border-slate-500/50 text-slate-400"
                      }`}
                    >
                      {draft.status}
                    </Badge>
                  </div>
                  <div className="flex gap-2">
                    <Button variant="ghost" size="sm" className="h-6 text-[9px]">
                      View
                    </Button>
                    <Button variant="ghost" size="sm" className="h-6 text-[9px]">
                      Print
                    </Button>
                    {draft.status === "draft" && (
                      <Button variant="ghost" size="sm" className="h-6 text-[9px] text-primary">
                        Approve
                      </Button>
                    )}
                  </div>
                </div>
              ))}
              {drafts.length === 0 && (
                <p className="text-center py-8 text-[11px] text-slate-500">
                  No dispute drafts yet
                </p>
              )}
            </div>
          </ScrollArea>
        </TabsContent>

        <TabsContent value="compliance" className="mt-3">
          <div className="rounded-lg border border-slate-800 bg-slate-950/50 p-4">
            <div className="flex items-center gap-2 mb-3">
              <Scale className="h-4 w-4 text-purple-400" />
              <span className="text-[11px] font-medium text-slate-200">
                Legal & Compliance Assistant
              </span>
            </div>
            <p className="text-[10px] text-slate-500 mb-3">
              AI-detected compliance codes for this case. These are administrative references only, not legal advice.
            </p>
            <div className="grid grid-cols-3 gap-2">
              {["FCRA §611", "FCRA §609", "FDCPA §807"].map((code) => (
                <div
                  key={code}
                  className="rounded-md bg-purple-500/10 border border-purple-500/30 px-2 py-1.5 text-center"
                >
                  <span className="text-[10px] font-medium text-purple-300">{code}</span>
                </div>
              ))}
            </div>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
