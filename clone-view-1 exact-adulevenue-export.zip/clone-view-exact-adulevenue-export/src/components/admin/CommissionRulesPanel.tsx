import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/hooks/use-toast";
import { Settings, Save, RefreshCw } from "lucide-react";

interface CommissionRules {
  id: string;
  rule_name: string;
  default_referral_pct: number;
  default_iso_pct: number;
  opener_pct_of_worker_pool: number;
  closer_pct_of_worker_pool: number;
  min_house_pct: number;
  autopilot_house_multiplier: number;
  allow_negotiated_overrides: boolean;
  is_active: boolean;
}

export function CommissionRulesPanel() {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [rules, setRules] = useState<CommissionRules | null>(null);
  const { toast } = useToast();

  useEffect(() => {
    fetchRules();
  }, []);

  const fetchRules = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from("commission_rules")
        .select("*")
        .eq("is_active", true)
        .limit(1)
        .single();

      if (error && error.code !== "PGRST116") throw error;

      if (data) {
        setRules(data);
      } else {
        // Create default rules if none exist
        const { data: newRules, error: insertError } = await supabase
          .from("commission_rules")
          .insert({
            rule_name: "default",
            default_referral_pct: 0.03,
            default_iso_pct: 0.05,
            opener_pct_of_worker_pool: 0.5,
            closer_pct_of_worker_pool: 0.5,
            min_house_pct: 0.3,
            autopilot_house_multiplier: 1.2,
            allow_negotiated_overrides: true,
            is_active: true,
          })
          .select()
          .single();

        if (insertError) throw insertError;
        setRules(newRules);
      }
    } catch (err: any) {
      toast({
        title: "Error",
        description: err.message,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const saveRules = async () => {
    if (!rules) return;

    setSaving(true);
    try {
      const { error } = await supabase
        .from("commission_rules")
        .update({
          default_referral_pct: rules.default_referral_pct,
          default_iso_pct: rules.default_iso_pct,
          opener_pct_of_worker_pool: rules.opener_pct_of_worker_pool,
          closer_pct_of_worker_pool: rules.closer_pct_of_worker_pool,
          min_house_pct: rules.min_house_pct,
          autopilot_house_multiplier: rules.autopilot_house_multiplier,
          allow_negotiated_overrides: rules.allow_negotiated_overrides,
          updated_at: new Date().toISOString(),
        })
        .eq("id", rules.id);

      if (error) throw error;

      toast({
        title: "Rules Saved",
        description: "Commission rules have been updated",
      });
    } catch (err: any) {
      toast({
        title: "Error",
        description: err.message,
        variant: "destructive",
      });
    } finally {
      setSaving(false);
    }
  };

  const updateField = (field: keyof CommissionRules, value: number | boolean) => {
    if (!rules) return;
    setRules({ ...rules, [field]: value });
  };

  if (loading) {
    return (
      <Card>
        <CardContent className="py-6">
          <div className="text-center text-muted-foreground">Loading rules...</div>
        </CardContent>
      </Card>
    );
  }

  if (!rules) {
    return (
      <Card>
        <CardContent className="py-6">
          <div className="text-center text-muted-foreground">No rules found</div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <Settings className="w-5 h-5" />
            Commission Rules
          </CardTitle>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={fetchRules}>
              <RefreshCw className="w-4 h-4 mr-2" />
              Reset
            </Button>
            <Button size="sm" onClick={saveRules} disabled={saving}>
              <Save className="w-4 h-4 mr-2" />
              {saving ? "Saving..." : "Save"}
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Referral & ISO Percentages */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <Label htmlFor="referral_pct">Referral Commission (%)</Label>
            <div className="flex items-center gap-2 mt-1">
              <Input
                id="referral_pct"
                type="number"
                min="0"
                max="100"
                step="0.5"
                value={(rules.default_referral_pct * 100).toFixed(1)}
                onChange={(e) =>
                  updateField("default_referral_pct", parseFloat(e.target.value) / 100)
                }
              />
              <span className="text-muted-foreground">%</span>
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              Default cut for referral partners & worker referrals
            </p>
          </div>

          <div>
            <Label htmlFor="iso_pct">ISO Partner Commission (%)</Label>
            <div className="flex items-center gap-2 mt-1">
              <Input
                id="iso_pct"
                type="number"
                min="0"
                max="100"
                step="0.5"
                value={(rules.default_iso_pct * 100).toFixed(1)}
                onChange={(e) =>
                  updateField("default_iso_pct", parseFloat(e.target.value) / 100)
                }
              />
              <span className="text-muted-foreground">%</span>
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              Default cut for ISO partners
            </p>
          </div>
        </div>

        {/* Worker Pool Split */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <Label htmlFor="opener_pct">Opener Share of Worker Pool (%)</Label>
            <div className="flex items-center gap-2 mt-1">
              <Input
                id="opener_pct"
                type="number"
                min="0"
                max="100"
                step="5"
                value={(rules.opener_pct_of_worker_pool * 100).toFixed(0)}
                onChange={(e) =>
                  updateField("opener_pct_of_worker_pool", parseFloat(e.target.value) / 100)
                }
              />
              <span className="text-muted-foreground">%</span>
            </div>
          </div>

          <div>
            <Label htmlFor="closer_pct">Closer Share of Worker Pool (%)</Label>
            <div className="flex items-center gap-2 mt-1">
              <Input
                id="closer_pct"
                type="number"
                min="0"
                max="100"
                step="5"
                value={(rules.closer_pct_of_worker_pool * 100).toFixed(0)}
                onChange={(e) =>
                  updateField("closer_pct_of_worker_pool", parseFloat(e.target.value) / 100)
                }
              />
              <span className="text-muted-foreground">%</span>
            </div>
          </div>
        </div>

        {/* House & Autopilot */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <Label htmlFor="house_pct">Minimum House Cut (%)</Label>
            <div className="flex items-center gap-2 mt-1">
              <Input
                id="house_pct"
                type="number"
                min="0"
                max="100"
                step="5"
                value={(rules.min_house_pct * 100).toFixed(0)}
                onChange={(e) =>
                  updateField("min_house_pct", parseFloat(e.target.value) / 100)
                }
              />
              <span className="text-muted-foreground">%</span>
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              House always gets at least this much
            </p>
          </div>

          <div>
            <Label htmlFor="autopilot_mult">Autopilot House Multiplier</Label>
            <div className="flex items-center gap-2 mt-1">
              <Input
                id="autopilot_mult"
                type="number"
                min="1"
                max="2"
                step="0.1"
                value={rules.autopilot_house_multiplier.toFixed(1)}
                onChange={(e) =>
                  updateField("autopilot_house_multiplier", parseFloat(e.target.value))
                }
              />
              <span className="text-muted-foreground">x</span>
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              Multiplier when AI handles the deal
            </p>
          </div>
        </div>

        {/* Toggles */}
        <div className="flex items-center justify-between p-4 rounded-lg border">
          <div>
            <p className="font-medium">Allow Negotiated Overrides</p>
            <p className="text-sm text-muted-foreground">
              Let admins override percentages per deal
            </p>
          </div>
          <Switch
            checked={rules.allow_negotiated_overrides}
            onCheckedChange={(checked) =>
              updateField("allow_negotiated_overrides", checked)
            }
          />
        </div>
      </CardContent>
    </Card>
  );
}
