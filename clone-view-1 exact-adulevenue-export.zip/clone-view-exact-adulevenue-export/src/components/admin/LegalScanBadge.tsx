import { useState, useEffect } from "react";
import { Scale, RefreshCw, AlertTriangle, CheckCircle2, Eye, Loader2 } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "@/hooks/use-toast";

interface LegalScan {
  id: string;
  deal_contract_id: string;
  risk_score: number | null;
  risk_level: string | null;
  issues: Array<{ code: string; severity: string; clause_ref?: string; message: string }> | null;
  recommendations: Array<{ action: string; description: string }> | null;
  clauses_summary: any;
  run_ts: string;
  engine_version: string | null;
  run_by_type: string;
}

interface LegalScanBadgeProps {
  contractId: string;
  onScanComplete?: () => void;
}

export function LegalScanBadge({ contractId, onScanComplete }: LegalScanBadgeProps) {
  const [loading, setLoading] = useState(true);
  const [scanning, setScanning] = useState(false);
  const [scan, setScan] = useState<LegalScan | null>(null);
  const [showDetails, setShowDetails] = useState(false);

  const fetchLatestScan = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from("wolf_legal_scans" as any)
        .select("*")
        .eq("deal_contract_id", contractId)
        .order("run_ts", { ascending: false })
        .limit(1)
        .single();

      if (error && error.code !== "PGRST116") {
        console.error("Error fetching legal scan:", error);
      }
      setScan(data as unknown as LegalScan | null);
    } catch (err) {
      console.error("Error:", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchLatestScan();
  }, [contractId]);

  const runScan = async () => {
    setScanning(true);
    try {
      const { data, error } = await supabase.functions.invoke("wolf-legal-scan", {
        body: {
          deal_contract_id: contractId,
          run_mode: scan ? "recheck" : "manual",
        },
      });

      if (error) throw error;

      if (data?.ok) {
        toast({
          title: "Legal Scan Complete",
          description: `Risk Level: ${data.risk_level?.toUpperCase()} (Score: ${data.risk_score})`,
        });
        fetchLatestScan();
        onScanComplete?.();
      } else {
        throw new Error(data?.error || "Unknown error");
      }
    } catch (err: any) {
      toast({
        title: "Legal Scan Failed",
        description: err.message,
        variant: "destructive",
      });
    } finally {
      setScanning(false);
    }
  };

  const getRiskBadgeStyle = (level: string | null) => {
    switch (level) {
      case "low":
        return "bg-green-500/10 text-green-600 border-green-500/30";
      case "medium":
        return "bg-amber-500/10 text-amber-600 border-amber-500/30";
      case "high":
        return "bg-orange-500/10 text-orange-600 border-orange-500/30";
      case "critical":
        return "bg-destructive/10 text-destructive border-destructive/30";
      default:
        return "";
    }
  };

  if (loading) {
    return <Badge variant="outline"><Loader2 className="h-3 w-3 animate-spin" /></Badge>;
  }

  return (
    <>
      <div className="flex items-center gap-2">
        {scan ? (
          <>
            <Badge 
              variant="outline" 
              className={`cursor-pointer ${getRiskBadgeStyle(scan.risk_level)}`}
              onClick={() => setShowDetails(true)}
            >
              <Scale className="h-3 w-3 mr-1" />
              {scan.risk_level?.toUpperCase()} ({scan.risk_score})
            </Badge>
            <Button
              size="sm"
              variant="ghost"
              className="h-6 px-2"
              onClick={runScan}
              disabled={scanning}
            >
              <RefreshCw className={`h-3 w-3 ${scanning ? "animate-spin" : ""}`} />
            </Button>
          </>
        ) : (
          <Button
            size="sm"
            variant="outline"
            onClick={runScan}
            disabled={scanning}
          >
            {scanning ? (
              <Loader2 className="h-3 w-3 mr-1 animate-spin" />
            ) : (
              <Scale className="h-3 w-3 mr-1" />
            )}
            {scanning ? "Scanning..." : "Run Legal Scan"}
          </Button>
        )}
      </div>

      {/* Legal Scan Details Dialog */}
      <Dialog open={showDetails} onOpenChange={setShowDetails}>
        <DialogContent className="max-w-lg max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Scale className="h-5 w-5" />
              Legal Scan Results
            </DialogTitle>
            <DialogDescription>
              Scanned: {scan?.run_ts ? new Date(scan.run_ts).toLocaleString() : "N/A"} • 
              Engine: {scan?.engine_version || "N/A"}
            </DialogDescription>
          </DialogHeader>

          {scan && (
            <div className="space-y-4">
              {/* Risk Overview */}
              <div className={`p-4 rounded-lg border ${getRiskBadgeStyle(scan.risk_level)}`}>
                <div className="flex items-center justify-between">
                  <span className="font-medium">Risk Assessment</span>
                  <Badge className={getRiskBadgeStyle(scan.risk_level)}>
                    {scan.risk_level?.toUpperCase()} - Score: {scan.risk_score}
                  </Badge>
                </div>
              </div>

              {/* Issues */}
              {scan.issues && scan.issues.length > 0 && (
                <div className="space-y-2">
                  <h4 className="font-medium text-sm text-muted-foreground">Issues Found</h4>
                  <div className="space-y-2">
                    {scan.issues.map((issue, idx) => (
                      <div 
                        key={idx} 
                        className={`p-3 rounded-lg text-sm ${
                          issue.severity === "critical" || issue.severity === "error" 
                            ? "bg-destructive/10" 
                            : issue.severity === "warn" 
                            ? "bg-amber-500/10" 
                            : "bg-muted/50"
                        }`}
                      >
                        <div className="flex items-start gap-2">
                          <AlertTriangle className={`h-4 w-4 mt-0.5 ${
                            issue.severity === "critical" || issue.severity === "error" 
                              ? "text-destructive" 
                              : issue.severity === "warn" 
                              ? "text-amber-500" 
                              : "text-muted-foreground"
                          }`} />
                          <div>
                            <p className="font-medium">{issue.code}</p>
                            <p className="text-muted-foreground">{issue.message}</p>
                            {issue.clause_ref && (
                              <p className="text-xs mt-1 opacity-70">Ref: {issue.clause_ref}</p>
                            )}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Recommendations */}
              {scan.recommendations && scan.recommendations.length > 0 && (
                <div className="space-y-2">
                  <h4 className="font-medium text-sm text-muted-foreground">Recommendations</h4>
                  <div className="space-y-2">
                    {scan.recommendations.map((rec, idx) => (
                      <div key={idx} className="p-3 rounded-lg bg-primary/5 text-sm">
                        <div className="flex items-start gap-2">
                          <CheckCircle2 className="h-4 w-4 mt-0.5 text-primary" />
                          <div>
                            <p className="font-medium">{rec.action}</p>
                            <p className="text-muted-foreground">{rec.description}</p>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Clauses Summary */}
              {scan.clauses_summary && (
                <div className="space-y-2">
                  <h4 className="font-medium text-sm text-muted-foreground">Contract Summary</h4>
                  <div className="grid grid-cols-2 gap-2 text-sm">
                    {Object.entries(scan.clauses_summary).map(([key, value]) => (
                      <div key={key} className="p-2 bg-muted/30 rounded">
                        <span className="text-muted-foreground capitalize">
                          {key.replace(/_/g, " ")}
                        </span>
                        <span className="float-right font-medium">
                          {typeof value === "boolean" ? (value ? "Yes" : "No") : String(value)}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Run Info */}
              <div className="text-xs text-muted-foreground pt-2 border-t">
                Run by: {scan.run_by_type} • Engine: {scan.engine_version}
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}
