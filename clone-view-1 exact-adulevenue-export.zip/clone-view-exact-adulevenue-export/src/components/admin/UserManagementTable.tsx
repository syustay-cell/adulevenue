import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Edit, RefreshCw } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import type { Database } from '@/integrations/supabase/types';

type AppRole = Database['public']['Enums']['app_role'];

type UserWithRole = {
  user_id: string;
  email: string;
  display_name: string | null;
  position: string | null;
  role: AppRole;
  approved: boolean;
};

const ROLE_COLORS: Record<string, string> = {
  admin: 'bg-red-500/10 text-red-400',
  underwriter: 'bg-purple-500/10 text-purple-400',
  credit_repair_specialist: 'bg-blue-500/10 text-blue-400',
  worker: 'bg-emerald-500/10 text-emerald-400',
  user: 'bg-slate-500/10 text-slate-400'
};

const POSITION_OPTIONS = [
  'ISO Opener',
  'ISO Closer',
  'Underwriter',
  'Credit Specialist',
  'Back Office - Credit Fix',
  'Admin',
  'Lead Generation Worker',
  'Other'
];

export function UserManagementTable() {
  const [users, setUsers] = useState<UserWithRole[]>([]);
  const [loading, setLoading] = useState(false);
  const [editUser, setEditUser] = useState<UserWithRole | null>(null);
  const [editName, setEditName] = useState('');
  const [editPosition, setEditPosition] = useState('');
  const [editRole, setEditRole] = useState('');
  const { toast } = useToast();

  const load = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('user_roles')
        .select('user_id, role, approved, display_name, position')
        .order('display_name');

      if (error) throw error;

      // Get emails - simplified approach
      const enriched: UserWithRole[] = [];
      for (const row of (data || [])) {
        const { data: userData } = await supabase.auth.admin.getUserById(row.user_id);
        enriched.push({
          user_id: row.user_id,
          email: userData?.user?.email || 'unknown@email.com',
          display_name: row.display_name,
          position: row.position,
          role: row.role,
          approved: row.approved
        });
      }

      setUsers(enriched);
    } catch (error: any) {
      toast({ variant: 'destructive', title: 'Error loading users', description: error.message });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
  }, []);

  const openEdit = (user: UserWithRole) => {
    setEditUser(user);
    setEditName(user.display_name || user.email.split('@')[0]);
    setEditPosition(user.position || '');
  };

  const saveEdit = async () => {
    if (!editUser) return;

    try {
      const { error } = await supabase
        .from('user_roles')
        .update({
          display_name: editName,
          position: editPosition
        })
        .eq('user_id', editUser.user_id)
        .eq('role', editUser.role);

      if (error) throw error;

      toast({ title: 'User updated' });
      setEditUser(null);
      await load();
    } catch (error: any) {
      toast({ variant: 'destructive', title: 'Error updating user', description: error.message });
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">Users & Team</h2>
        <Button variant="outline" size="icon" onClick={load} disabled={loading}>
          <RefreshCw className={`h-4 w-4 ${loading ? 'animate-spin' : ''}`} />
        </Button>
      </div>

      <div className="space-y-2">
        {users.map((user) => (
          <Card key={`${user.user_id}-${user.role}`} className="p-4">
            <div className="flex items-center justify-between">
              <div className="flex-1">
                <div className="flex items-center gap-3 mb-1">
                  <p className="font-semibold text-lg">
                    {user.display_name || user.email.split('@')[0]}
                  </p>
                  {user.position && (
                    <Badge variant="outline" className="bg-blue-500/10 text-blue-400">
                      {user.position}
                    </Badge>
                  )}
                  <Badge className={ROLE_COLORS[user.role] || 'bg-slate-500/10 text-slate-400'}>
                    {user.role}
                  </Badge>
                  {!user.approved && (
                    <Badge variant="destructive">Pending Approval</Badge>
                  )}
                </div>
                <p className="text-sm text-muted-foreground">{user.email}</p>
              </div>
              <Button size="sm" variant="ghost" onClick={() => openEdit(user)}>
                <Edit className="h-4 w-4" />
              </Button>
            </div>
          </Card>
        ))}
      </div>

      {/* Edit Dialog */}
      <Dialog open={!!editUser} onOpenChange={() => setEditUser(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit User</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>Display Name</Label>
              <Input value={editName} onChange={(e) => setEditName(e.target.value)} />
            </div>
            <div>
              <Label>Position</Label>
              <Select value={editPosition} onValueChange={setEditPosition}>
                <SelectTrigger>
                  <SelectValue placeholder="Select position" />
                </SelectTrigger>
                <SelectContent>
                  {POSITION_OPTIONS.map(opt => (
                    <SelectItem key={opt} value={opt}>{opt}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Role (read-only)</Label>
              <p className="text-sm text-muted-foreground p-2 border rounded">{editRole}</p>
            </div>
            <div className="flex gap-3">
              <Button onClick={saveEdit}>Save Changes</Button>
              <Button variant="outline" onClick={() => setEditUser(null)}>Cancel</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}