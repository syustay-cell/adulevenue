import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { AlertTriangle, RefreshCw, CheckCircle, XCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export const RiskMonitoring = () => {
  const [alerts, setAlerts] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [scanning, setScanning] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    fetchAlerts();
  }, []);

  const fetchAlerts = async () => {
    try {
      const { data, error } = await supabase
        .from('risk_alerts')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(50);

      if (error) throw error;
      setAlerts(data || []);
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const runRiskScan = async () => {
    setScanning(true);
    try {
      const { data, error } = await supabase.functions.invoke('scan-risk-alerts');
      
      if (error) {
        console.error('Risk scan transport error:', error);
        toast({ title: "System Error", description: "Connection issue. Please try again.", variant: "destructive" });
        return;
      }

      if (!data?.ok) {
        toast({ 
          title: "Scan Failed", 
          description: data?.message || "Unable to complete risk scan",
          variant: "destructive" 
        });
        return;
      }

      toast({
        title: "Scan Complete",
        description: "Risk monitoring scan completed successfully",
      });

      await fetchAlerts();
    } catch (error: any) {
      console.error('Risk scan error:', error);
      toast({ title: "Scan Failed", description: "Unexpected error occurred", variant: "destructive" });
    } finally {
      setScanning(false);
    }
  };

  const updateAlertStatus = async (id: string, newStatus: string) => {
    try {
      const updateData: any = { status: newStatus };
      if (newStatus === 'resolved') {
        updateData.resolved_at = new Date().toISOString();
        updateData.resolved_by = (await supabase.auth.getUser()).data.user?.id;
      }

      const { error } = await supabase
        .from('risk_alerts')
        .update(updateData)
        .eq('id', id);

      if (error) throw error;

      toast({
        title: "Status Updated",
        description: `Alert marked as ${newStatus}`,
      });

      fetchAlerts();
    } catch (error: any) {
      toast({
        title: "Update Failed",
        description: error.message,
        variant: "destructive"
      });
    }
  };

  const getSeverityBadge = (severity: string) => {
    const colors: Record<string, string> = {
      low: 'bg-blue-500',
      medium: 'bg-yellow-500',
      high: 'bg-orange-500',
      critical: 'bg-red-500'
    };
    return <Badge className={colors[severity] || 'bg-gray-500'}>{severity.toUpperCase()}</Badge>;
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'resolved':
        return <Badge className="bg-green-500"><CheckCircle className="w-3 h-3 mr-1" />Resolved</Badge>;
      case 'dismissed':
        return <Badge variant="secondary"><XCircle className="w-3 h-3 mr-1" />Dismissed</Badge>;
      case 'investigating':
        return <Badge className="bg-blue-500">Investigating</Badge>;
      case 'acknowledged':
        return <Badge className="bg-yellow-500">Acknowledged</Badge>;
      default:
        return <Badge variant="destructive"><AlertTriangle className="w-3 h-3 mr-1" />Open</Badge>;
    }
  };

  const openAlerts = alerts.filter(a => a.status === 'open').length;
  const criticalAlerts = alerts.filter(a => a.severity === 'critical' && a.status === 'open').length;
  const highAlerts = alerts.filter(a => a.severity === 'high' && a.status === 'open').length;

  if (loading) {
    return <div className="text-center py-8">Loading risk alerts...</div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">Risk Monitoring & Alerts</h2>
          <p className="text-sm text-muted-foreground">Automated risk detection and monitoring system</p>
        </div>
        <Button onClick={runRiskScan} disabled={scanning} className="gap-2">
          <RefreshCw className={`h-4 w-4 ${scanning ? 'animate-spin' : ''}`} />
          {scanning ? 'Scanning...' : 'Run Risk Scan'}
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="text-center">
              <p className="text-sm text-muted-foreground">Total Open Alerts</p>
              <p className="text-3xl font-bold text-orange-600">{openAlerts}</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="text-center">
              <p className="text-sm text-muted-foreground">Critical</p>
              <p className="text-3xl font-bold text-red-600">{criticalAlerts}</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="text-center">
              <p className="text-sm text-muted-foreground">High Priority</p>
              <p className="text-3xl font-bold text-orange-500">{highAlerts}</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="text-center">
              <p className="text-sm text-muted-foreground">Resolved Today</p>
              <p className="text-3xl font-bold text-green-600">
                {alerts.filter(a => 
                  a.status === 'resolved' && 
                  new Date(a.resolved_at).toDateString() === new Date().toDateString()
                ).length}
              </p>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Recent Alerts</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {alerts.map((alert) => (
              <div key={alert.id} className="border rounded-lg p-4">
                <div className="flex items-start justify-between mb-2">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <AlertTriangle className="w-4 h-4 text-orange-500" />
                      <h3 className="font-semibold">{alert.title}</h3>
                      {getSeverityBadge(alert.severity)}
                      {getStatusBadge(alert.status)}
                    </div>
                    <p className="text-sm text-muted-foreground mb-2">{alert.description}</p>
                    <div className="flex items-center gap-4 text-xs text-muted-foreground">
                      <span>Type: {alert.alert_type.replace(/_/g, ' ')}</span>
                      <span>Entity: {alert.entity_type}</span>
                      <span>Created: {new Date(alert.created_at).toLocaleString()}</span>
                    </div>
                  </div>
                  {alert.status === 'open' && (
                    <div className="flex gap-2 ml-4">
                      <Button size="sm" variant="outline" onClick={() => updateAlertStatus(alert.id, 'acknowledged')}>
                        Acknowledge
                      </Button>
                      <Button size="sm" onClick={() => updateAlertStatus(alert.id, 'investigating')}>
                        Investigate
                      </Button>
                      <Button size="sm" className="bg-green-600 hover:bg-green-700" onClick={() => updateAlertStatus(alert.id, 'resolved')}>
                        Resolve
                      </Button>
                    </div>
                  )}
                </div>
              </div>
            ))}
            {alerts.length === 0 && (
              <div className="text-center py-8 text-muted-foreground">
                No risk alerts detected. System is monitoring for potential issues.
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};