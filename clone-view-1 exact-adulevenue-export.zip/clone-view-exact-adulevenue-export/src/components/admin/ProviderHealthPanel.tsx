import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { RefreshCw, CheckCircle2, XCircle, AlertTriangle, Wifi, Clock } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

interface ProviderHealth {
  id: string;
  provider_key: string;
  status: 'online' | 'offline' | 'degraded' | 'unknown';
  last_check_at: string | null;
  last_success_at: string | null;
  last_error: string | null;
  error_count_today: number;
  success_count_today: number;
  avg_latency_ms: number | null;
}

const PROVIDER_LABELS: Record<string, string> = {
  openai: 'OpenAI API',
  gateway: 'AI Gateway',
  twilio_sms: 'Twilio SMS',
  resend_email: 'Resend Email',
  database: 'Database'
};

const STATUS_CONFIG = {
  online: { icon: CheckCircle2, color: 'text-green-500', bg: 'bg-green-500/10', label: 'Online' },
  offline: { icon: XCircle, color: 'text-red-500', bg: 'bg-red-500/10', label: 'Offline' },
  degraded: { icon: AlertTriangle, color: 'text-yellow-500', bg: 'bg-yellow-500/10', label: 'Degraded' },
  unknown: { icon: Wifi, color: 'text-muted-foreground', bg: 'bg-muted', label: 'Unknown' }
};

export function ProviderHealthPanel() {
  const [providers, setProviders] = useState<ProviderHealth[]>([]);
  const [loading, setLoading] = useState(true);
  const [checking, setChecking] = useState(false);

  useEffect(() => {
    loadHealth();
  }, []);

  const loadHealth = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('wolf_provider_health')
        .select('*')
        .order('provider_key');
      
      if (error) throw error;
      setProviders((data as ProviderHealth[]) || []);
    } catch (err) {
      console.error('Failed to load provider health:', err);
      toast.error('Failed to load provider health');
    } finally {
      setLoading(false);
    }
  };

  const runHealthCheck = async () => {
    setChecking(true);
    try {
      const { data, error } = await supabase.functions.invoke('wolf-provider-health-check');
      
      if (error) throw error;
      
      if (data?.ok) {
        toast.success(`Health check complete: ${data.data.overall_status}`);
        loadHealth();
      } else {
        toast.error(data?.message || 'Health check failed');
      }
    } catch (err) {
      console.error('Health check error:', err);
      toast.error('Failed to run health check');
    } finally {
      setChecking(false);
    }
  };

  const formatTime = (dateStr: string | null) => {
    if (!dateStr) return 'Never';
    const date = new Date(dateStr);
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    
    if (diffMins < 1) return 'Just now';
    if (diffMins < 60) return `${diffMins}m ago`;
    const diffHours = Math.floor(diffMins / 60);
    if (diffHours < 24) return `${diffHours}h ago`;
    return date.toLocaleDateString();
  };

  if (loading) {
    return (
      <Card>
        <CardContent className="p-8 text-center">
          <RefreshCw className="h-6 w-6 animate-spin mx-auto mb-2 text-muted-foreground" />
          <p className="text-sm text-muted-foreground">Loading provider health...</p>
        </CardContent>
      </Card>
    );
  }

  const onlineCount = providers.filter(p => p.status === 'online').length;
  const offlineCount = providers.filter(p => p.status === 'offline').length;

  return (
    <div className="space-y-4">
      {/* Overall Status */}
      <Card className={offlineCount > 0 ? 'border-destructive' : ''}>
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <Wifi className="h-4 w-4" />
                <span className="text-sm font-medium">System Status:</span>
                <Badge variant={offlineCount > 0 ? 'destructive' : 'default'}>
                  {onlineCount}/{providers.length} Online
                </Badge>
              </div>
              {offlineCount > 0 && (
                <Badge variant="destructive">
                  <XCircle className="h-3 w-3 mr-1" />
                  {offlineCount} Offline
                </Badge>
              )}
            </div>
            <Button 
              variant="outline" 
              size="sm" 
              onClick={runHealthCheck}
              disabled={checking}
            >
              {checking ? (
                <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
              ) : (
                <RefreshCw className="h-4 w-4 mr-2" />
              )}
              Run Health Check
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Provider Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {providers.map((provider) => {
          const config = STATUS_CONFIG[provider.status];
          const StatusIcon = config.icon;
          
          return (
            <Card key={provider.id} className={provider.status === 'offline' ? 'border-destructive' : ''}>
              <CardHeader className="pb-2">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-base">
                    {PROVIDER_LABELS[provider.provider_key] || provider.provider_key}
                  </CardTitle>
                  <Badge className={`${config.bg} ${config.color} border-0`}>
                    <StatusIcon className="h-3 w-3 mr-1" />
                    {config.label}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-2">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground flex items-center gap-1">
                    <Clock className="h-3 w-3" />
                    Last Check
                  </span>
                  <span>{formatTime(provider.last_check_at)}</span>
                </div>
                
                {provider.avg_latency_ms && (
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">Latency</span>
                    <Badge variant="outline" className="text-xs">
                      {provider.avg_latency_ms}ms
                    </Badge>
                  </div>
                )}

                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">Today</span>
                  <div className="flex gap-2">
                    <Badge variant="outline" className="text-xs text-green-600">
                      ✓ {provider.success_count_today}
                    </Badge>
                    {provider.error_count_today > 0 && (
                      <Badge variant="outline" className="text-xs text-red-600">
                        ✗ {provider.error_count_today}
                      </Badge>
                    )}
                  </div>
                </div>

                {provider.last_error && provider.status !== 'online' && (
                  <div className="text-xs text-destructive bg-destructive/10 p-2 rounded mt-2">
                    {provider.last_error}
                  </div>
                )}
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
}
