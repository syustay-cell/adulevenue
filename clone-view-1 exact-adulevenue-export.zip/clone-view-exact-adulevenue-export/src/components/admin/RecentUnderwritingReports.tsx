import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { TrendingUp, Loader2, FileText } from "lucide-react";
import { useNavigate } from "react-router-dom";

interface RecentReport {
  case_id: string;
  application_id: string;
  application_type: string;
  client_name: string;
  amount_requested: string | null;
  risk_level: string;
  summary_preview: string;
  created_at: string;
}

export const RecentUnderwritingReports = () => {
  const [reports, setReports] = useState<RecentReport[]>([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    fetchRecentReports();
  }, []);

  const fetchRecentReports = async () => {
    try {
      // Fetch recent underwriting cases with metrics
      const { data: casesData, error: casesError } = await supabase
        .from('underwriting_cases')
        .select(`
          id,
          application_id,
          application_type,
          status,
          created_at
        `)
        .order('created_at', { ascending: false })
        .limit(10);

      if (casesError) throw casesError;
      if (!casesData || casesData.length === 0) {
        setReports([]);
        setLoading(false);
        return;
      }

      // Fetch metrics for these cases
      const caseIds = casesData.map(c => c.id);
      const { data: metricsData, error: metricsError } = await supabase
        .from('underwriting_metrics')
        .select('*')
        .in('underwriting_case_id', caseIds);

      if (metricsError) throw metricsError;

      // Group metrics by case_id (get latest for each case)
      const metricsByCase: Record<string, any> = {};
      metricsData?.forEach(metric => {
        const existing = metricsByCase[metric.underwriting_case_id];
        if (!existing || new Date(metric.created_at) > new Date(existing.created_at)) {
          metricsByCase[metric.underwriting_case_id] = metric;
        }
      });

      // Fetch application details (Fast Track and Loan)
      const fastTrackIds = casesData.filter(c => c.application_type === 'fast_track').map(c => c.application_id);
      const loanIds = casesData.filter(c => c.application_type === 'loan').map(c => c.application_id);

      const [fastTrackRes, loanRes] = await Promise.all([
        fastTrackIds.length > 0 
          ? supabase.from('fast_track_applications').select('id, business_name').in('id', fastTrackIds)
          : Promise.resolve({ data: [] }),
        loanIds.length > 0
          ? supabase.from('loan_applications').select('id, business_name, loan_amount').in('id', loanIds)
          : Promise.resolve({ data: [] })
      ]);

      // Build report list
      const enrichedReports: RecentReport[] = casesData
        .map(caseItem => {
          const metrics = metricsByCase[caseItem.id];
          if (!metrics) return null;

          let appDetails: any = null;
          if (caseItem.application_type === 'fast_track') {
            appDetails = fastTrackRes.data?.find(a => a.id === caseItem.application_id);
          } else if (caseItem.application_type === 'loan') {
            appDetails = loanRes.data?.find(a => a.id === caseItem.application_id);
          }

          return {
            case_id: caseItem.id,
            application_id: caseItem.application_id,
            application_type: caseItem.application_type,
            client_name: appDetails?.business_name || 'Unknown Business',
            amount_requested: appDetails?.loan_amount || null,
            risk_level: metrics.risk_level || 'unknown',
            summary_preview: metrics.summary?.substring(0, 80) + '...' || 'No summary available',
            created_at: metrics.created_at
          };
        })
        .filter(r => r !== null) as RecentReport[];

      setReports(enrichedReports);
    } catch (error: any) {
      console.error('Error fetching recent reports:', error);
    } finally {
      setLoading(false);
    }
  };

  const getRiskBadge = (risk: string) => {
    const colors: Record<string, string> = {
      low: 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400',
      medium: 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-400',
      high: 'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400',
      borderline: 'bg-orange-100 text-orange-800 dark:bg-orange-900/30 dark:text-orange-400',
      unknown: 'bg-gray-100 text-gray-800 dark:bg-gray-900/30 dark:text-gray-400'
    };
    return colors[risk] || colors.unknown;
  };

  const getRiskIcon = (risk: string) => {
    switch (risk) {
      case 'low':
        return '🟢';
      case 'medium':
        return '🟡';
      case 'high':
        return '🔴';
      case 'borderline':
        return '🟠';
      default:
        return '⚪';
    }
  };

  if (loading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileText className="w-5 h-5 text-blue-500" />
            Underwriting AI Reports – Recent Activity
          </CardTitle>
        </CardHeader>
        <CardContent className="flex items-center justify-center py-8">
          <Loader2 className="w-6 h-6 animate-spin text-primary" />
        </CardContent>
      </Card>
    );
  }

  if (reports.length === 0) {
    return (
      <Card className="border-blue-500/30">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileText className="w-5 h-5 text-blue-500" />
            Underwriting AI Reports – Recent Activity
          </CardTitle>
          <CardDescription>No underwriting reports available yet</CardDescription>
        </CardHeader>
      </Card>
    );
  }

  return (
    <Card className="border-blue-500/30 bg-blue-500/5">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <FileText className="w-5 h-5 text-blue-500" />
          Underwriting AI Reports – Recent Activity
        </CardTitle>
        <CardDescription>Latest AI evaluations from the underwriting system</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {reports.map((report) => (
            <div
              key={report.case_id}
              className="flex items-center justify-between p-4 border rounded-lg hover:bg-muted/50 transition-colors"
            >
              <div className="flex-1 grid grid-cols-1 md:grid-cols-5 gap-3 items-center">
                {/* Client Name */}
                <div>
                  <p className="font-semibold text-sm">{report.client_name}</p>
                  <p className="text-xs text-muted-foreground capitalize">
                    {report.application_type.replace('_', ' ')}
                  </p>
                </div>

                {/* Amount Requested */}
                <div className="hidden md:block">
                  {report.amount_requested && (
                    <div className="flex items-center gap-1 text-sm">
                      <TrendingUp className="w-3 h-3 text-green-600" />
                      <span>{report.amount_requested}</span>
                    </div>
                  )}
                </div>

                {/* AI Risk */}
                <div>
                  <Badge className={getRiskBadge(report.risk_level)}>
                    {getRiskIcon(report.risk_level)} {report.risk_level.toUpperCase()}
                  </Badge>
                </div>

                {/* Summary Preview */}
                <div className="col-span-1 md:col-span-2">
                  <p className="text-xs text-muted-foreground italic line-clamp-2">
                    "{report.summary_preview}"
                  </p>
                </div>
              </div>

              {/* Actions */}
              <div className="ml-4">
                <Button
                  onClick={() => navigate(`/underwriting/${report.case_id}`)}
                  size="sm"
                  variant="outline"
                >
                  View Full
                </Button>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-4 pt-4 border-t text-center">
          <Button
            onClick={() => navigate('/underwriting')}
            variant="ghost"
            size="sm"
            className="text-blue-600 hover:text-blue-700"
          >
            View All Underwriting Cases →
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};
