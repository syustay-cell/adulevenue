import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { TrendingUp, DollarSign, AlertCircle, CheckCircle } from "lucide-react";

export const RenewalPipeline = () => {
  const [opportunities, setOpportunities] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<string>("all");
  const { toast } = useToast();

  useEffect(() => {
    fetchOpportunities();
  }, []);

  const fetchOpportunities = async () => {
    try {
      const { data, error } = await supabase
        .from('renewal_opportunities')
        .select(`
          *,
          funded_contracts (
            business_name,
            client_name,
            funding_amount,
            contract_end_date,
            daily_payment
          )
        `)
        .order('priority', { ascending: false })
        .order('created_at', { ascending: false });

      if (error) throw error;
      setOpportunities(data || []);
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const updateStatus = async (id: string, status: string) => {
    try {
      const updates: any = { status };
      if (status === 'contacted') {
        updates.contacted_at = new Date().toISOString();
      } else if (status === 'resolved') {
        updates.resolved_at = new Date().toISOString();
      }

      const { error } = await supabase
        .from('renewal_opportunities')
        .update(updates)
        .eq('id', id);

      if (error) throw error;
      toast({ title: "Success", description: `Status updated to ${status}` });
      fetchOpportunities();
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive"
      });
    }
  };

  const getPriorityBadge = (priority: string) => {
    const colors: Record<string, string> = {
      high: 'bg-red-500',
      medium: 'bg-yellow-500',
      low: 'bg-blue-500',
    };
    return <Badge className={colors[priority] || 'bg-gray-500'}>{priority.toUpperCase()}</Badge>;
  };

  const getStatusBadge = (status: string) => {
    const colors: Record<string, string> = {
      identified: 'bg-blue-500',
      contacted: 'bg-yellow-500',
      in_progress: 'bg-purple-500',
      resolved: 'bg-green-500',
      declined: 'bg-gray-500',
    };
    return <Badge className={colors[status] || 'bg-gray-500'}>{status.replace(/_/g, ' ').toUpperCase()}</Badge>;
  };

  const filteredOpportunities = filter === "all" 
    ? opportunities 
    : opportunities.filter(o => o.status === filter);

  const totalValue = filteredOpportunities
    .filter(o => o.status !== 'declined' && o.status !== 'resolved')
    .reduce((sum, o) => sum + Number(o.suggested_amount || 0), 0);

  if (loading) {
    return <div className="text-center py-8">Loading renewal pipeline...</div>;
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold">Renewal Pipeline</h2>
        <p className="text-sm text-muted-foreground">Track and manage funding renewal opportunities</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-4">
              <TrendingUp className="w-8 h-8 text-primary" />
              <div>
                <p className="text-sm text-muted-foreground">Total Pipeline Value</p>
                <p className="text-2xl font-bold">${totalValue.toLocaleString()}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-4">
              <AlertCircle className="w-8 h-8 text-yellow-500" />
              <div>
                <p className="text-sm text-muted-foreground">Identified</p>
                <p className="text-2xl font-bold">{opportunities.filter(o => o.status === 'identified').length}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-4">
              <DollarSign className="w-8 h-8 text-blue-500" />
              <div>
                <p className="text-sm text-muted-foreground">In Progress</p>
                <p className="text-2xl font-bold">{opportunities.filter(o => o.status === 'in_progress').length}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-4">
              <CheckCircle className="w-8 h-8 text-green-500" />
              <div>
                <p className="text-sm text-muted-foreground">Resolved</p>
                <p className="text-2xl font-bold">{opportunities.filter(o => o.status === 'resolved').length}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>Renewal Opportunities</CardTitle>
            <Select value={filter} onValueChange={setFilter}>
              <SelectTrigger className="w-48">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Opportunities</SelectItem>
                <SelectItem value="identified">Identified</SelectItem>
                <SelectItem value="contacted">Contacted</SelectItem>
                <SelectItem value="in_progress">In Progress</SelectItem>
                <SelectItem value="resolved">Resolved</SelectItem>
                <SelectItem value="declined">Declined</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Client</TableHead>
                <TableHead>Type</TableHead>
                <TableHead>Reason</TableHead>
                <TableHead>Suggested Amount</TableHead>
                <TableHead>Priority</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Contract End</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredOpportunities.map((opp) => (
                <TableRow key={opp.id}>
                  <TableCell>
                    <div>
                      <p className="font-medium">{opp.funded_contracts?.business_name}</p>
                      <p className="text-xs text-muted-foreground">{opp.funded_contracts?.client_name}</p>
                    </div>
                  </TableCell>
                  <TableCell>
                    <Badge variant="outline">{opp.opportunity_type.replace(/_/g, ' ')}</Badge>
                  </TableCell>
                  <TableCell className="max-w-xs text-sm">{opp.reason}</TableCell>
                  <TableCell className="font-bold text-primary">
                    ${Number(opp.suggested_amount || 0).toLocaleString()}
                  </TableCell>
                  <TableCell>{getPriorityBadge(opp.priority)}</TableCell>
                  <TableCell>{getStatusBadge(opp.status)}</TableCell>
                  <TableCell className="text-xs">
                    {new Date(opp.funded_contracts?.contract_end_date).toLocaleDateString()}
                  </TableCell>
                  <TableCell>
                    <Select onValueChange={(value) => updateStatus(opp.id, value)} defaultValue={opp.status}>
                      <SelectTrigger className="w-32">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="identified">Identified</SelectItem>
                        <SelectItem value="contacted">Contacted</SelectItem>
                        <SelectItem value="in_progress">In Progress</SelectItem>
                        <SelectItem value="resolved">Resolved</SelectItem>
                        <SelectItem value="declined">Declined</SelectItem>
                      </SelectContent>
                    </Select>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
          {filteredOpportunities.length === 0 && (
            <div className="text-center py-8 text-muted-foreground">
              No renewal opportunities found
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};
