import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { DollarSign, CheckCircle, Clock, XCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export const ISOCommissionTracking = () => {
  const [commissions, setCommissions] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  useEffect(() => {
    fetchCommissions();
  }, []);

  const fetchCommissions = async () => {
    try {
      const { data, error } = await supabase
        .from('iso_commissions')
        .select(`
          *,
          iso_partner_applications:iso_partner_id (full_name, company_name, email),
          funded_contracts:funded_contract_id (business_name, funding_amount, client_name)
        `)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setCommissions(data || []);
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const updatePaymentStatus = async (id: string, status: string) => {
    try {
      const updateData: any = { payment_status: status };
      if (status === 'paid') {
        updateData.payment_date = new Date().toISOString();
      }

      const { error } = await supabase
        .from('iso_commissions')
        .update(updateData)
        .eq('id', id);

      if (error) throw error;

      toast({
        title: "Status Updated",
        description: `Commission marked as ${status}`,
      });

      fetchCommissions();
    } catch (error: any) {
      toast({
        title: "Update Failed",
        description: error.message,
        variant: "destructive"
      });
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'paid':
        return <Badge className="bg-green-500"><CheckCircle className="w-3 h-3 mr-1" />Paid</Badge>;
      case 'processing':
        return <Badge className="bg-blue-500"><Clock className="w-3 h-3 mr-1" />Processing</Badge>;
      case 'cancelled':
        return <Badge variant="destructive"><XCircle className="w-3 h-3 mr-1" />Cancelled</Badge>;
      default:
        return <Badge variant="secondary"><Clock className="w-3 h-3 mr-1" />Pending</Badge>;
    }
  };

  const totalPending = commissions.filter(c => c.payment_status === 'pending').reduce((sum, c) => sum + Number(c.commission_amount), 0);
  const totalPaid = commissions.filter(c => c.payment_status === 'paid').reduce((sum, c) => sum + Number(c.commission_amount), 0);
  const totalProcessing = commissions.filter(c => c.payment_status === 'processing').reduce((sum, c) => sum + Number(c.commission_amount), 0);

  if (loading) {
    return <div className="text-center py-8">Loading commissions...</div>;
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold">ISO Commission Tracking</h2>
        <p className="text-sm text-muted-foreground">Manage and track ISO partner commissions</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="text-center">
              <p className="text-sm text-muted-foreground">Total Commissions</p>
              <p className="text-3xl font-bold text-primary">${(totalPending + totalPaid + totalProcessing).toLocaleString()}</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="text-center">
              <p className="text-sm text-muted-foreground">Pending</p>
              <p className="text-3xl font-bold text-yellow-600">${totalPending.toLocaleString()}</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="text-center">
              <p className="text-sm text-muted-foreground">Processing</p>
              <p className="text-3xl font-bold text-blue-600">${totalProcessing.toLocaleString()}</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="text-center">
              <p className="text-sm text-muted-foreground">Paid</p>
              <p className="text-3xl font-bold text-green-600">${totalPaid.toLocaleString()}</p>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Commission Records</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>ISO Partner</TableHead>
                  <TableHead>Client</TableHead>
                  <TableHead>Funding Amount</TableHead>
                  <TableHead>Rate</TableHead>
                  <TableHead>Commission</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {commissions.map((commission) => (
                  <TableRow key={commission.id}>
                    <TableCell>
                      <div>
                        <p className="font-medium">{commission.iso_partner_applications?.full_name}</p>
                        <p className="text-xs text-muted-foreground">{commission.iso_partner_applications?.company_name}</p>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div>
                        <p className="font-medium">{commission.funded_contracts?.business_name}</p>
                        <p className="text-xs text-muted-foreground">{commission.funded_contracts?.client_name}</p>
                      </div>
                    </TableCell>
                    <TableCell>${Number(commission.funded_contracts?.funding_amount).toLocaleString()}</TableCell>
                    <TableCell>{Number(commission.commission_rate).toFixed(2)}%</TableCell>
                    <TableCell className="font-bold text-primary">${Number(commission.commission_amount).toLocaleString()}</TableCell>
                    <TableCell>{getStatusBadge(commission.payment_status)}</TableCell>
                    <TableCell>
                      <div className="flex gap-2">
                        {commission.payment_status === 'pending' && (
                          <Button size="sm" onClick={() => updatePaymentStatus(commission.id, 'processing')}>
                            Start Processing
                          </Button>
                        )}
                        {commission.payment_status === 'processing' && (
                          <Button size="sm" className="bg-green-600 hover:bg-green-700" onClick={() => updatePaymentStatus(commission.id, 'paid')}>
                            <DollarSign className="w-3 h-3 mr-1" />
                            Mark Paid
                          </Button>
                        )}
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};