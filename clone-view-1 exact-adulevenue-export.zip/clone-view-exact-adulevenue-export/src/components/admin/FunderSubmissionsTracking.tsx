import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { CheckCircle, XCircle, Clock, Send, Eye } from "lucide-react";
import { format } from "date-fns";

interface FunderSubmission {
  id: string;
  application_id: string;
  application_type: string;
  funder_id: string;
  status: string;
  mode: string;
  sent_at: string;
  created_at: string;
  funders: {
    name: string;
    contact_email: string;
  } | null;
}

const STATUS_OPTIONS = [
  { value: "draft", label: "Draft", icon: Clock },
  { value: "pending_admin_approval", label: "Pending Approval", icon: Clock },
  { value: "approved_not_sent", label: "Approved (Not Sent)", icon: CheckCircle },
  { value: "sent_to_funder", label: "Sent to Funder", icon: Send },
  { value: "funder_in_review", label: "Funder Reviewing", icon: Eye },
  { value: "offer_received", label: "Offer Received", icon: CheckCircle },
  { value: "declined", label: "Declined", icon: XCircle },
  { value: "funded", label: "Funded", icon: CheckCircle }
];

export function FunderSubmissionsTracking() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [statusFilter, setStatusFilter] = useState<string>("all");

  const { data: submissions, isLoading } = useQuery({
    queryKey: ["funder-submissions", statusFilter],
    queryFn: async () => {
      let query = supabase
        .from("funder_submissions")
        .select(`
          *,
          funders (
            name,
            contact_email
          )
        `)
        .order("created_at", { ascending: false });

      if (statusFilter !== "all") {
        query = query.eq("status", statusFilter);
      }

      const { data, error } = await query;
      if (error) throw error;
      return data as FunderSubmission[];
    }
  });

  const updateStatusMutation = useMutation({
    mutationFn: async ({ id, status }: { id: string; status: string }) => {
      const { error } = await supabase
        .from("funder_submissions")
        .update({ status })
        .eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["funder-submissions"] });
      toast({ title: "Submission status updated" });
    },
    onError: () => {
      toast({ title: "Failed to update status", variant: "destructive" });
    }
  });

  const approveMutation = useMutation({
    mutationFn: async (submissionId: string) => {
      const submission = submissions?.find(s => s.id === submissionId);
      if (!submission) throw new Error("Submission not found");

      // Invoke send-to-funder edge function
      const { data, error } = await supabase.functions.invoke("send-to-funder", {
        body: {
          application_id: submission.application_id,
          application_type: submission.application_type,
          funder_ids: [submission.funder_id],
          mode: submission.mode
        }
      });

      // Transport error
      if (error) {
        console.error("[FunderSubmissionsTracking] Transport error:", error);
        throw new Error("Connection error. Please try again.");
      }

      // Business logic error
      if (!data?.ok) {
        throw new Error(data?.message || "Failed to send to funder.");
      }

      return data;
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["funder-submissions"] });
      toast({ 
        title: "Submission Sent",
        description: data?.message || "Successfully sent to funder."
      });
    },
    onError: (error: any) => {
      toast({
        title: "Failed to Send",
        description: error.message || "An error occurred. Please try again.",
        variant: "destructive"
      });
    }
  });

  const getStatusBadge = (status: string) => {
    const statusConfig = STATUS_OPTIONS.find(s => s.value === status);
    const Icon = statusConfig?.icon || Clock;
    
    const variant = 
      status === "funded" || status === "offer_received" ? "default" :
      status === "declined" ? "destructive" :
      status === "pending_admin_approval" ? "secondary" :
      "outline";

    return (
      <Badge variant={variant} className="gap-1">
        <Icon className="w-3 h-3" />
        {statusConfig?.label || status}
      </Badge>
    );
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle>Funder Submissions Tracking</CardTitle>
            <CardDescription>View and manage all funder submissions</CardDescription>
          </div>
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-48">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Statuses</SelectItem>
              {STATUS_OPTIONS.map(opt => (
                <SelectItem key={opt.value} value={opt.value}>
                  {opt.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="text-center py-8 text-muted-foreground">Loading submissions...</div>
        ) : !submissions?.length ? (
          <div className="text-center py-8 text-muted-foreground">
            No submissions found for this filter.
          </div>
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Application</TableHead>
                <TableHead>Funder</TableHead>
                <TableHead>Mode</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Submitted</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {submissions.map((submission) => (
                <TableRow key={submission.id}>
                  <TableCell>
                    <div className="font-medium">
                      {submission.application_type.replace(/_/g, " ").toUpperCase()}
                    </div>
                    <div className="text-xs text-muted-foreground">
                      {submission.application_id.slice(0, 8)}
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="font-medium">{submission.funders?.name || "Unknown"}</div>
                    <div className="text-xs text-muted-foreground">
                      {submission.funders?.contact_email}
                    </div>
                  </TableCell>
                  <TableCell>
                    <Badge variant="outline">
                      {submission.mode.replace(/_/g, " ")}
                    </Badge>
                  </TableCell>
                  <TableCell>{getStatusBadge(submission.status)}</TableCell>
                  <TableCell className="text-sm text-muted-foreground">
                    {format(new Date(submission.created_at), "MMM d, yyyy")}
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex gap-2 justify-end">
                      {submission.status === "pending_admin_approval" && (
                        <Button
                          size="sm"
                          onClick={() => approveMutation.mutate(submission.id)}
                          disabled={approveMutation.isPending}
                        >
                          Approve & Send
                        </Button>
                      )}
                      <Select
                        value={submission.status}
                        onValueChange={(status) =>
                          updateStatusMutation.mutate({ id: submission.id, status })
                        }
                      >
                        <SelectTrigger className="w-40">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {STATUS_OPTIONS.map(opt => (
                            <SelectItem key={opt.value} value={opt.value}>
                              {opt.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </CardContent>
    </Card>
  );
}
