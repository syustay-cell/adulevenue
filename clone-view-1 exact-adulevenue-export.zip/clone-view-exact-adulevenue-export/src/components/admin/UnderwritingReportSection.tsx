import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { AlertCircle, TrendingUp, DollarSign, AlertTriangle, FileText, Loader2, CheckCircle, Download, Wand2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { FunderPackageDialog } from "@/components/underwriting/FunderPackageDialog";
import { generateUnderwritingPDF } from "@/lib/pdf-generator";
import { UnderwriterAssistant } from "@/components/underwriting/UnderwriterAssistant";
import { CashFlowVisualization } from "@/components/underwriting/CashFlowVisualization";

interface UnderwritingReportProps {
  applicationId: string;
  applicationType: 'fast_track' | 'loan';
}

export const UnderwritingReportSection = ({ applicationId, applicationType }: UnderwritingReportProps) => {
  const [loading, setLoading] = useState(true);
  const [analyzing, setAnalyzing] = useState(false);
  const [downloadingPDF, setDownloadingPDF] = useState(false);
  const [underwritingCase, setUnderwritingCase] = useState<any>(null);
  const [metrics, setMetrics] = useState<any>(null);
  const [applicationData, setApplicationData] = useState<any>(null);
  const [editedFunders, setEditedFunders] = useState<Record<number, string>>({});
  const [savingCorrections, setSavingCorrections] = useState(false);
  const [suggestedAction, setSuggestedAction] = useState<any>(null);
  const [loadingSuggestion, setLoadingSuggestion] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    fetchUnderwritingReport();
  }, [applicationId, applicationType]);

  useEffect(() => {
    if (underwritingCase && metrics) {
      fetchSuggestedAction();
    }
  }, [underwritingCase, metrics]);

  const fetchUnderwritingReport = async () => {
    try {
      setLoading(true);
      
      const { data: caseData, error: caseError } = await supabase
        .from('underwriting_cases')
        .select('*')
        .eq('application_id', applicationId)
        .eq('application_type', applicationType)
        .maybeSingle();

      if (caseError) throw caseError;
      
      if (caseData) {
        setUnderwritingCase(caseData);
        
        // Fetch latest metrics
        const { data: metricsData, error: metricsError } = await supabase
          .from('underwriting_metrics')
          .select('*')
          .eq('underwriting_case_id', caseData.id)
          .order('created_at', { ascending: false })
          .limit(1)
          .maybeSingle();

        if (metricsError) throw metricsError;
        setMetrics(metricsData);

        // Fetch application data for PDF
        const table = applicationType === 'fast_track' ? 'fast_track_applications' : 'loan_applications';
        const { data: appData } = await supabase
          .from(table)
          .select('*')
          .eq('id', applicationId)
          .maybeSingle();
        
        setApplicationData(appData);
      }
    } catch (error: any) {
      console.error('Error fetching underwriting report:', error);
    } finally {
      setLoading(false);
    }
  };

  const saveCorrections = async () => {
    if (!underwritingCase || Object.keys(editedFunders).length === 0) return;

    setSavingCorrections(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("Not authenticated");

      // Save each correction to underwriting_feedback
      for (const [idx, correctedName] of Object.entries(editedFunders)) {
        const deduction = metrics.raw_metrics.funding_deductions[parseInt(idx)];
        if (!deduction || deduction.label === correctedName) continue;

        await supabase.from('underwriting_feedback').insert({
          underwriting_case_id: underwritingCase.id,
          application_id: applicationId,
          application_type: applicationType,
          field: 'existing_funding_lender',
          feedback_type: 'incorrect_value',
          original_value: deduction.label,
          corrected_value: correctedName,
          corrected_by: user.id,
          notes: `Source line: ${deduction.source_line || 'N/A'}`
        });
      }

      toast({
        title: "Corrections Saved",
        description: `${Object.keys(editedFunders).length} funder name(s) corrected. AI will learn from this.`,
      });

      setEditedFunders({});
      await fetchUnderwritingReport();
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Save Failed",
        description: error.message || "Failed to save corrections",
      });
    } finally {
      setSavingCorrections(false);
    }
  };

  const fetchSuggestedAction = async () => {
    if (!underwritingCase) return;
    
    setLoadingSuggestion(true);
    try {
      const { data, error } = await supabase.functions.invoke('suggest-next-action', {
        body: { underwritingCaseId: underwritingCase.id }
      });

      if (error) throw error;
      setSuggestedAction(data);
    } catch (error: any) {
      console.error('Error fetching suggested action:', error);
    } finally {
      setLoadingSuggestion(false);
    }
  };

  const runAnalysis = async () => {
    if (!underwritingCase) return;
    
    setAnalyzing(true);
    try {
      const { error } = await supabase.functions.invoke('underwriter-analyze-application', {
        body: { underwriting_case_id: underwritingCase.id }
      });

      if (error) throw error;

      toast({
        title: "Analysis Complete",
        description: "AI underwriting report has been generated",
      });

      await fetchUnderwritingReport();
      await fetchSuggestedAction();
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Analysis Failed",
        description: error.message || "Failed to run AI analysis",
      });
    } finally {
      setAnalyzing(false);
    }
  };

  const downloadPDF = async () => {
    if (!metrics || !applicationData) {
      toast({
        variant: "destructive",
        title: "Cannot Generate PDF",
        description: "Missing report data or application details",
      });
      return;
    }

    setDownloadingPDF(true);
    try {
      await generateUnderwritingPDF({
        applicationId,
        applicationType,
        businessName: applicationData.business_name || applicationData.full_name || 'Unknown',
        fundabilityStatus: metrics.raw_metrics?.fundability_status,
        riskLevel: metrics.risk_level,
        status: underwritingCase.status,
        metrics: metrics,
        createdAt: underwritingCase.created_at,
      });

      toast({
        title: "PDF Downloaded",
        description: "Underwriting report PDF has been generated and downloaded",
      });
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "PDF Generation Failed",
        description: error.message || "Failed to generate PDF report",
      });
    } finally {
      setDownloadingPDF(false);
    }
  };

  const getRiskBadge = (risk: string) => {
    const colors: Record<string, string> = {
      low: 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400',
      medium: 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-400',
      high: 'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400',
      borderline: 'bg-orange-100 text-orange-800 dark:bg-orange-900/30 dark:text-orange-400'
    };
    return colors[risk] || colors.medium;
  };

  const getStatusBadge = (status: string) => {
    const colors: Record<string, string> = {
      pending: 'bg-gray-100 text-gray-800',
      analyzing: 'bg-blue-100 text-blue-800',
      review_ready: 'bg-green-100 text-green-800',
      awaiting_docs: 'bg-yellow-100 text-yellow-800',
      declined: 'bg-red-100 text-red-800',
      approved: 'bg-emerald-100 text-emerald-800',
    };
    return colors[status] || colors.pending;
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-8">
        <Loader2 className="w-6 h-6 animate-spin text-primary" />
      </div>
    );
  }

  if (!underwritingCase) {
    return (
      <Card className="border-muted">
        <CardContent className="pt-6">
          <div className="text-center text-muted-foreground">
            <AlertCircle className="w-12 h-12 mx-auto mb-3 opacity-50" />
            <p className="mb-4">No underwriting case found for this application</p>
            <p className="text-sm">An underwriting case should be automatically created when applications are submitted.</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (!metrics) {
    return (
      <div className="space-y-4">
        {/* AI Suggested Action Banner - Show even without metrics */}
        {suggestedAction && !loadingSuggestion && suggestedAction.suggested_action === 'run_analysis' && (
          <Card className="border-2 border-blue-500 bg-blue-50 dark:bg-blue-950">
            <CardContent className="pt-6">
              <div className="flex items-center gap-2 mb-2">
                <Wand2 className="w-5 h-5 text-blue-600" />
                <h3 className="font-semibold">AI Recommendation: Run Analysis First</h3>
              </div>
              <p className="text-sm">{suggestedAction.message}</p>
            </CardContent>
          </Card>
        )}

        <Card className="border-blue-500/50 bg-blue-500/5">
          <CardContent className="pt-6">
            <div className="text-center">
              <FileText className="w-12 h-12 mx-auto mb-3 text-blue-500 opacity-50" />
              <h3 className="font-semibold text-lg mb-2">No AI Report Available Yet</h3>
              <p className="text-muted-foreground mb-4">
                Status: <Badge className={getStatusBadge(underwritingCase.status)}>
                  {underwritingCase.status.replace('_', ' ')}
                </Badge>
              </p>
              <Button
              onClick={runAnalysis}
              disabled={analyzing}
              className="bg-blue-500 hover:bg-blue-600"
            >
              {analyzing ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Analyzing...
                </>
              ) : (
                <>
                  <FileText className="w-4 h-4 mr-2" />
                  Run AI Underwriting Analysis
                </>
              )}
            </Button>
          </div>
        </CardContent>
      </Card>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* AI Suggested Action Banner */}
      {suggestedAction && !loadingSuggestion && suggestedAction.suggested_action !== 'run_analysis' && (
        <Card className={`border-2 ${
          suggestedAction.suggested_action === 'credit_repair' ? 'border-yellow-500 bg-yellow-50 dark:bg-yellow-950' :
          suggestedAction.suggested_action === 'decline_or_credit_repair' ? 'border-red-500 bg-red-50 dark:bg-red-950' :
          'border-green-500 bg-green-50 dark:bg-green-950'
        }`}>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Wand2 className="w-5 h-5" />
              AI Recommendation: {suggestedAction.suggested_action === 'credit_repair' ? 'Move to Credit Repair' :
                                  suggestedAction.suggested_action === 'decline_or_credit_repair' ? 'Decline or Credit Repair' :
                                  'Send to Funders'}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm font-medium mb-2">{suggestedAction.message}</p>
            {suggestedAction.reason && (
              <p className="text-xs text-muted-foreground mb-4">Reason: {suggestedAction.reason}</p>
            )}
            
            {suggestedAction.recommended_funders && suggestedAction.recommended_funders.length > 0 && (
              <div className="mt-4">
                <p className="text-sm font-medium mb-2">Recommended Funders (Top {suggestedAction.recommended_funders.length}):</p>
                <div className="space-y-2">
                  {suggestedAction.recommended_funders.map((funder: any, idx: number) => (
                    <div key={idx} className="flex items-center justify-between p-2 bg-white dark:bg-gray-800 rounded border">
                      <div>
                        <p className="font-medium text-sm">{funder.funder_name}</p>
                        <p className="text-xs text-muted-foreground">{funder.match_reasons.join(', ')}</p>
                      </div>
                      <Badge variant="outline">Score: {funder.match_score}</Badge>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {suggestedAction.details && (
              <div className="mt-4 p-3 bg-white dark:bg-gray-800 rounded border">
                <p className="text-xs font-medium mb-1">Details:</p>
                <pre className="text-xs overflow-x-auto">{JSON.stringify(suggestedAction.details, null, 2)}</pre>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* Fundability Status Banner - MOST IMPORTANT */}
      {metrics.raw_metrics?.fundability_status && (
        <Card className={`border-2 ${
          metrics.raw_metrics.fundability_status === 'Fundable' ? 'border-green-600 bg-green-50 dark:bg-green-950/20' :
          metrics.raw_metrics.fundability_status === 'Conditional' ? 'border-yellow-600 bg-yellow-50 dark:bg-yellow-950/20' :
          'border-red-600 bg-red-50 dark:bg-red-950/20'
        }`}>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                {metrics.raw_metrics.fundability_status === 'Fundable' && <CheckCircle className="w-8 h-8 text-green-600" />}
                {metrics.raw_metrics.fundability_status === 'Conditional' && <AlertTriangle className="w-8 h-8 text-yellow-600" />}
                {metrics.raw_metrics.fundability_status === 'Not Fundable' && <AlertCircle className="w-8 h-8 text-red-600" />}
                <div>
                  <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Fundability Assessment</p>
                  <p className={`text-2xl font-bold ${
                    metrics.raw_metrics.fundability_status === 'Fundable' ? 'text-green-700 dark:text-green-300' :
                    metrics.raw_metrics.fundability_status === 'Conditional' ? 'text-yellow-700 dark:text-yellow-300' :
                    'text-red-700 dark:text-red-300'
                  }`}>
                    {metrics.raw_metrics.fundability_status}
                  </p>
                </div>
              </div>
              {metrics.recommended_label && (
                <Badge variant="outline" className="text-sm px-3 py-1">
                  {metrics.recommended_label}
                </Badge>
              )}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Status and Risk Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <span className="text-sm text-muted-foreground">Underwriting Status:</span>
          <Badge className={getStatusBadge(underwritingCase.status)}>
            {underwritingCase.status.replace('_', ' ')}
          </Badge>
        </div>
        {metrics.risk_level && (
          <div className="flex items-center gap-2">
            <span className="text-sm text-muted-foreground">Risk Level:</span>
            <Badge className={getRiskBadge(metrics.risk_level)}>
              {metrics.risk_level.toUpperCase()}
            </Badge>
          </div>
        )}
      </div>

      {/* Banking & Underwriting Summary */}
      <Card className="border-primary/50 bg-primary/5">
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2 justify-between">
            <div className="flex items-center gap-2">
              <DollarSign className="w-4 h-4 text-primary" />
              Banking & Underwriting Summary
            </div>
            <div className="flex items-center gap-2">
              <Badge variant="outline" className="text-xs bg-purple-50 border-purple-300 text-purple-700">
                🤖 Gemini Pro Vision
              </Badge>
              <Button 
                variant="outline" 
                size="sm"
                onClick={downloadPDF}
                disabled={downloadingPDF}
                className="gap-2"
              >
                {downloadingPDF ? (
                  <>
                    <Loader2 className="w-3 h-3 animate-spin" />
                    Generating...
                  </>
                ) : (
                  <>
                    <Download className="w-3 h-3" />
                    Download PDF
                  </>
                )}
              </Button>
              <FunderPackageDialog 
                applicationId={applicationId} 
                applicationType={applicationType}
              />
            </div>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {metrics.avg_monthly_revenue !== null && (
              <div>
                <p className="text-xs text-muted-foreground font-semibold">Avg Monthly Revenue</p>
                <p className="text-xl font-bold text-green-600">${metrics.avg_monthly_revenue.toLocaleString()}</p>
                {metrics.raw_metrics?.monthly_revenue_breakdown?.length > 0 && (
                  <div className="mt-2 space-y-0.5">
                    {metrics.raw_metrics.monthly_revenue_breakdown.map((item: any, idx: number) => (
                      <p key={idx} className="text-xs text-muted-foreground">
                        {item.month}: ${item.total_deposits?.toLocaleString() || '0'}
                      </p>
                    ))}
                  </div>
                )}
              </div>
            )}
            {metrics.avg_daily_balance !== null && (
              <div>
                <p className="text-xs text-muted-foreground font-semibold">Avg Daily Balance</p>
                <p className="text-xl font-bold text-blue-600">${metrics.avg_daily_balance.toLocaleString()}</p>
                {metrics.raw_metrics?.ending_balance !== null && (
                  <p className="text-xs text-muted-foreground mt-1">
                    Month-end: ${metrics.raw_metrics.ending_balance.toLocaleString()}
                  </p>
                )}
                {metrics.raw_metrics?.lowest_daily_balance !== null && (
                  <p className="text-xs text-red-600 mt-0.5">
                    Lowest: ${metrics.raw_metrics.lowest_daily_balance.toLocaleString()}
                  </p>
                )}
              </div>
            )}
            {metrics.nsf_count !== null && (
              <div>
                <p className="text-xs text-muted-foreground font-semibold">NSF Count / Month</p>
                <p className="text-xl font-bold text-red-600">{metrics.nsf_count}</p>
                {metrics.negative_days !== null && (
                  <p className="text-xs text-orange-600 mt-1">
                    Negative days: {metrics.negative_days}
                  </p>
                )}
              </div>
            )}
            {metrics.raw_metrics?.total_deposits_count !== null && metrics.raw_metrics?.total_withdrawals_count !== null && (
              <div>
                <p className="text-xs text-muted-foreground font-semibold">Deposits vs Withdrawals</p>
                <p className="text-xl font-bold text-blue-600">
                  {metrics.raw_metrics.total_deposits_count} / {metrics.raw_metrics.total_withdrawals_count}
                </p>
                {metrics.raw_metrics?.deposit_withdrawal_ratio && (
                  <p className="text-xs text-muted-foreground mt-1">
                    {metrics.raw_metrics.deposit_withdrawal_ratio}
                  </p>
                )}
              </div>
            )}
            {metrics.raw_metrics?.funding_deductions && (
              <div>
                <p className="text-xs text-muted-foreground font-semibold">Existing Funding</p>
                <p className="text-xl font-bold text-red-600">
                  {metrics.raw_metrics.funding_deductions.length} position{metrics.raw_metrics.funding_deductions.length !== 1 ? 's' : ''}
                </p>
                {metrics.existing_advances_estimate && (
                  <p className="text-xs text-red-600 mt-1 font-semibold">
                    See details below
                  </p>
                )}
              </div>
            )}
            {metrics.raw_metrics?.deposit_frequency && (
              <div>
                <p className="text-xs text-muted-foreground font-semibold">Deposit Frequency</p>
                <p className="text-xl font-bold text-purple-600 capitalize">
                  {metrics.raw_metrics.deposit_frequency}
                </p>
                {metrics.raw_metrics?.peak_months?.length > 0 && (
                  <p className="text-xs text-purple-600 mt-1">
                    Peak: {metrics.raw_metrics.peak_months.join(', ')}
                  </p>
                )}
              </div>
            )}
            {metrics.raw_metrics?.one_time_windfalls?.length > 0 && (
              <div>
                <p className="text-xs text-muted-foreground font-semibold">One-Time Windfalls</p>
                <p className="text-xl font-bold text-orange-600">
                  {metrics.raw_metrics.one_time_windfalls.length} detected
                </p>
                <p className="text-xs text-orange-600 mt-1 font-semibold">
                  Largest: ${metrics.raw_metrics.one_time_windfalls[0]?.amount?.toLocaleString()}
                </p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Cash Flow Visualization */}
      <CashFlowVisualization metrics={metrics} />

      {/* AI Summary */}
      {(metrics.internal_summary || metrics.summary) && (
        <Card className="border-blue-500/30">
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-blue-600" />
              AI Underwriting Analysis
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="bg-blue-50 dark:bg-blue-950/20 p-4 rounded-lg border-l-4 border-blue-600">
              <div className="flex items-center gap-2 mb-2">
                <Badge className="bg-blue-600 text-white">ADMIN ONLY - INTERNAL USE</Badge>
              </div>
              <p className="text-sm font-semibold text-blue-900 dark:text-blue-100 mb-1">Internal Analysis (Full Details)</p>
              <p className="text-sm leading-relaxed text-blue-800 dark:text-blue-200">{metrics.internal_summary || metrics.summary}</p>
            </div>
            {metrics.recommended_label && (
              <div className="pl-4 border-l-2 border-primary">
                <span className="text-sm font-semibold text-muted-foreground">Recommendation: </span>
                <span className="text-sm font-bold">{metrics.recommended_label}</span>
              </div>
            )}
            {metrics.funder_safe_summary && (
              <div className="bg-green-50 dark:bg-green-950/20 p-4 rounded-lg border-l-4 border-green-600">
                <div className="flex items-center gap-2 mb-2">
                  <Badge className="bg-green-600 text-white">FUNDER-SAFE - SHAREABLE</Badge>
                </div>
                <p className="text-sm font-semibold text-green-900 dark:text-green-100 mb-1">Sanitized Summary (For External Sharing)</p>
                <p className="text-sm leading-relaxed text-green-800 dark:text-green-200">{metrics.funder_safe_summary}</p>
                <p className="text-xs text-muted-foreground mt-2 flex items-center gap-1">
                  <AlertCircle className="w-3 h-3" />
                  Client contact info & sensitive details removed. Safe to send to funders.
                </p>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* Funding Recommendation Engine */}
      {metrics.raw_metrics?.funding_recommendation && (
        <Card className="border-green-600 bg-gradient-to-br from-green-50 to-emerald-50 dark:from-green-950/20 dark:to-emerald-950/20">
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <DollarSign className="w-5 h-5 text-green-600" />
              💰 Funding Recommendation & Offer Engine
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Recommended Funding Range */}
            <div className="bg-white dark:bg-gray-900 p-4 rounded-lg border-2 border-green-300">
              <p className="text-sm font-bold text-green-700 mb-2 uppercase tracking-wide">Recommended Funding Range</p>
              <div className="flex items-baseline gap-2 mb-2">
                <span className="text-3xl font-bold text-green-600">
                  ${metrics.raw_metrics.funding_recommendation.recommended_funding_range?.min?.toLocaleString()}
                </span>
                <span className="text-xl text-muted-foreground">–</span>
                <span className="text-3xl font-bold text-green-600">
                  ${metrics.raw_metrics.funding_recommendation.recommended_funding_range?.max?.toLocaleString()}
                </span>
              </div>
              {metrics.raw_metrics.funding_recommendation.recommended_funding_range?.rationale && (
                <p className="text-sm text-muted-foreground mt-2 italic">
                  {metrics.raw_metrics.funding_recommendation.recommended_funding_range.rationale}
                </p>
              )}
            </div>

            {/* Daily Payment Affordability */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="bg-white dark:bg-gray-900 p-4 rounded-lg border border-blue-200">
                <p className="text-xs font-semibold text-blue-700 mb-2 uppercase">Daily Payment Affordability</p>
                <div className="flex items-baseline gap-2">
                  <span className="text-2xl font-bold text-blue-600">
                    ${metrics.raw_metrics.funding_recommendation.daily_payment_affordability?.min?.toLocaleString()}
                  </span>
                  <span className="text-lg text-muted-foreground">–</span>
                  <span className="text-2xl font-bold text-blue-600">
                    ${metrics.raw_metrics.funding_recommendation.daily_payment_affordability?.max?.toLocaleString()}
                  </span>
                  <span className="text-sm text-muted-foreground">/day</span>
                </div>
                {metrics.raw_metrics.funding_recommendation.daily_payment_affordability?.calculation_basis && (
                  <p className="text-xs text-muted-foreground mt-2">
                    {metrics.raw_metrics.funding_recommendation.daily_payment_affordability.calculation_basis}
                  </p>
                )}
              </div>

              <div className="bg-white dark:bg-gray-900 p-4 rounded-lg border border-purple-200">
                <p className="text-xs font-semibold text-purple-700 mb-2 uppercase">Suggested Terms</p>
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-muted-foreground">Term:</span>
                    <span className="text-lg font-bold text-purple-600">
                      {metrics.raw_metrics.funding_recommendation.suggested_term_months?.min}–{metrics.raw_metrics.funding_recommendation.suggested_term_months?.max} months
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-muted-foreground">Factor:</span>
                    <span className="text-lg font-bold text-purple-600">
                      {metrics.raw_metrics.funding_recommendation.suggested_factor_rate?.min}–{metrics.raw_metrics.funding_recommendation.suggested_factor_rate?.max}
                    </span>
                  </div>
                </div>
              </div>
            </div>

            {/* Recommended Funders */}
            {metrics.raw_metrics.funding_recommendation.recommended_funders?.length > 0 && (
              <div className="bg-white dark:bg-gray-900 p-4 rounded-lg border border-indigo-200">
                <p className="text-sm font-semibold text-indigo-700 mb-2">Recommended Funder Types:</p>
                <div className="flex flex-wrap gap-2">
                  {metrics.raw_metrics.funding_recommendation.recommended_funders.map((funder: string, idx: number) => (
                    <Badge key={idx} className="bg-indigo-100 text-indigo-800 border-indigo-300">
                      {funder}
                    </Badge>
                  ))}
                </div>
              </div>
            )}

            {/* Conditions */}
            {metrics.raw_metrics.funding_recommendation.conditions?.length > 0 && (
              <div className="bg-yellow-50 dark:bg-yellow-950/20 p-4 rounded-lg border-l-4 border-yellow-500">
                <p className="text-sm font-semibold text-yellow-800 dark:text-yellow-200 mb-2 flex items-center gap-2">
                  <AlertCircle className="w-4 h-4" />
                  Conditions for Approval:
                </p>
                <ul className="space-y-1 text-sm text-yellow-700 dark:text-yellow-300">
                  {metrics.raw_metrics.funding_recommendation.conditions.map((condition: string, idx: number) => (
                    <li key={idx} className="flex items-start gap-2">
                      <span className="mt-1">•</span>
                      <span>{condition}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* Red Flags & Risk Analysis */}
      {metrics.raw_metrics?.red_flags && metrics.raw_metrics.red_flags.length > 0 && (
        <Card className="border-red-500/50 bg-red-500/5">
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-red-600" />
              🚩 Risk Flags & Red Flag Analysis
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {metrics.raw_metrics.red_flags.map((flag: any, idx: number) => (
                <div key={idx} className="flex items-start gap-2 p-2 bg-red-50 dark:bg-red-950/30 rounded border-l-4 border-red-600">
                  <AlertCircle className="w-4 h-4 text-red-600 mt-0.5 flex-shrink-0" />
                  <div>
                    <p className="text-sm font-semibold text-red-800 dark:text-red-200">
                      {flag.type.replace(/_/g, ' ').toUpperCase()}
                    </p>
                    <p className="text-xs text-red-700 dark:text-red-300">{flag.description}</p>
                  </div>
                </div>
              ))}
            </div>
            {metrics.concentration_risk && (
              <div className="mt-4 pt-4 border-t border-red-200">
                <p className="text-sm font-semibold text-red-700 mb-1">Concentration Risk:</p>
                <p className="text-sm text-muted-foreground">{metrics.concentration_risk}</p>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* Existing Funding Detection */}
      {(metrics.raw_metrics?.funding_deductions?.length > 0 || 
        metrics.raw_metrics?.large_suspicious_deposits?.length > 0 ||
        metrics.existing_advances_estimate) && (
        <Card className="border-red-500/50 bg-red-500/5">
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-red-600" />
              🚨 Existing Funding Detection
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {metrics.existing_advances_estimate && (
              <div>
                <p className="text-sm font-semibold text-red-700 mb-2">Estimated Total Existing Funding:</p>
                <p className="text-sm leading-relaxed">{metrics.existing_advances_estimate}</p>
              </div>
            )}
            
            {metrics.raw_metrics?.funding_deductions?.length > 0 && (
              <div className="pt-3 border-t">
                <p className="text-sm font-semibold text-red-700 mb-2">Detected Funding Positions:</p>
                <p className="text-xs text-muted-foreground mb-3 italic flex items-center gap-1">
                  <AlertCircle className="w-3 h-3" />
                  ✏️ Click any lender name to edit if AI detected it incorrectly. Click "Save Corrections" when done.
                </p>
                <div className="overflow-x-auto">
                  <table className="w-full text-xs border border-red-200">
                    <thead className="bg-red-100">
                      <tr>
                        <th className="p-2 text-left border-b border-red-200">Lender / Description</th>
                        <th className="p-2 text-left border-b border-red-200">Payment</th>
                        <th className="p-2 text-left border-b border-red-200">Frequency</th>
                        <th className="p-2 text-left border-b border-red-200">First Seen</th>
                        <th className="p-2 text-left border-b border-red-200">Last Seen</th>
                        <th className="p-2 text-left border-b border-red-200">Times</th>
                        <th className="p-2 text-left border-b border-red-200">Source Line</th>
                      </tr>
                    </thead>
                    <tbody>
                      {metrics.raw_metrics.funding_deductions.map((deduction: any, idx: number) => (
                        <tr key={idx} className="bg-white hover:bg-red-50">
                          <td className="p-2 border-b border-red-100 font-semibold text-red-800">
                            <input 
                              type="text" 
                              value={editedFunders[idx] !== undefined ? editedFunders[idx] : deduction.label} 
                              onChange={(e) => setEditedFunders(prev => ({ ...prev, [idx]: e.target.value }))}
                              className="w-full bg-transparent border-b border-dashed border-red-300 hover:border-red-500 focus:outline-none focus:border-red-600 focus:bg-red-50 px-1 py-0.5 rounded"
                              placeholder="Edit funder name"
                              title="Click to edit if AI detected incorrectly"
                            />
                          </td>
                          <td className="p-2 border-b border-red-100 font-semibold">
                            ${deduction.typical_amount?.toLocaleString()}
                          </td>
                          <td className="p-2 border-b border-red-100">
                            <Badge variant="outline" className="text-xs">
                              {deduction.frequency}
                            </Badge>
                          </td>
                          <td className="p-2 border-b border-red-100 text-xs">
                            {deduction.first_seen}
                          </td>
                          <td className="p-2 border-b border-red-100 text-xs">
                            {deduction.last_seen}
                          </td>
                          <td className="p-2 border-b border-red-100 text-center">
                            <Badge variant="outline" className="text-xs">
                              {deduction.times_seen}x
                            </Badge>
                          </td>
                          <td className="p-2 border-b border-red-100 text-xs font-mono text-muted-foreground max-w-xs truncate" title={deduction.source_line}>
                            {deduction.source_line || 'No source line available'}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                  {Object.keys(editedFunders).length > 0 && (
                    <div className="mt-3 flex items-center gap-2">
                      <Button
                        onClick={saveCorrections}
                        disabled={savingCorrections}
                        size="sm"
                        className="bg-red-600 hover:bg-red-700"
                      >
                        {savingCorrections ? (
                          <>
                            <Loader2 className="w-3 h-3 mr-2 animate-spin" />
                            Saving...
                          </>
                        ) : (
                          <>
                            <CheckCircle className="w-3 h-3 mr-2" />
                            Save {Object.keys(editedFunders).length} Correction(s)
                          </>
                        )}
                      </Button>
                      <Button
                        onClick={() => setEditedFunders({})}
                        disabled={savingCorrections}
                        size="sm"
                        variant="outline"
                      >
                        Cancel
                      </Button>
                    </div>
                  )}
                  {metrics.existing_advances_estimate && (
                    <div className="mt-3 p-3 bg-red-50 border border-red-200 rounded text-xs">
                      <p className="font-semibold text-red-800 mb-1">Summary:</p>
                      <p className="text-sm">{metrics.existing_advances_estimate}</p>
                    </div>
                  )}
                </div>
              </div>
            )}
            
            {metrics.raw_metrics?.large_suspicious_deposits?.length > 0 && (
              <div className="pt-3 border-t">
                <p className="text-sm font-semibold text-red-700 mb-3">Large Suspicious Deposits:</p>
                <div className="space-y-2">
                  {metrics.raw_metrics.large_suspicious_deposits.map((deposit: any, idx: number) => (
                    <div key={idx} className="p-3 bg-white border border-yellow-200 rounded-md text-xs">
                      <div className="flex justify-between items-start mb-1">
                        <span className="font-semibold">${deposit.amount?.toLocaleString()}</span>
                        <Badge variant="outline" className={
                          deposit.classification === 'possible_advance' ? 'border-red-500 text-red-700' :
                          deposit.classification === 'owner_injection' ? 'border-blue-500 text-blue-700' :
                          'border-gray-500 text-gray-700'
                        }>
                          {deposit.classification?.replace('_', ' ')}
                        </Badge>
                      </div>
                      <p className="text-muted-foreground text-xs">
                        {deposit.date} - {deposit.description}
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* One-Time Windfalls & Unusual Deposits */}
      {metrics.raw_metrics?.one_time_windfalls?.length > 0 && (
        <Card className="border-orange-500/50 bg-orange-500/5">
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-orange-600" />
              💸 One-Time Windfalls & Unusual Deposits
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground mb-3">
              Large deposits that may not represent regular revenue (excludes from average calculations)
            </p>
            <div className="space-y-2">
              {metrics.raw_metrics.one_time_windfalls.map((windfall: any, idx: number) => (
                <div key={idx} className="p-3 bg-white dark:bg-gray-900 border border-orange-200 rounded-md">
                  <div className="flex justify-between items-start mb-1">
                    <span className="text-lg font-bold text-orange-600">
                      ${windfall.amount?.toLocaleString()}
                    </span>
                    <Badge variant="outline" className="border-orange-500 text-orange-700 text-xs">
                      {windfall.date}
                    </Badge>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    {windfall.description}
                  </p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Missing Items */}
      {metrics.missing_items && Array.isArray(metrics.missing_items) && metrics.missing_items.length > 0 && (
        <Card className="border-yellow-500/50 bg-yellow-500/5">
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-yellow-600" />
              Missing Documents
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-2">
              {metrics.missing_items.map((item: string, index: number) => (
                <Badge key={index} variant="outline" className="border-yellow-500 text-yellow-700 dark:text-yellow-400">
                  {item}
                </Badge>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Actions */}
      <div className="flex gap-2">
        <Button
          onClick={runAnalysis}
          disabled={analyzing}
          variant="outline"
          size="sm"
        >
          {analyzing ? (
            <>
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              Re-analyzing...
            </>
          ) : (
            <>
              <FileText className="w-4 h-4 mr-2" />
              Re-run Analysis
            </>
          )}
        </Button>
        <Button
          onClick={() => window.open(`/underwriting/${underwritingCase.id}`, '_blank')}
          variant="outline"
          size="sm"
        >
          View Full Underwriting Case
        </Button>
      </div>

      {/* AI Underwriting Assistant */}
      <UnderwriterAssistant
        underwritingData={{
          business_name: applicationData?.business_name,
          fundability_status: metrics?.fundability_status,
          risk_level: metrics?.risk_level,
          avg_monthly_revenue: metrics?.avg_monthly_revenue,
          avg_daily_balance: metrics?.avg_daily_balance,
          nsf_count: metrics?.nsf_count,
          negative_days: metrics?.negative_days,
          existing_funding: metrics?.raw_metrics?.funding_deductions || [],
          legal_risk_score: null,
          funding_recommendation: metrics?.funding_recommendation
        }}
        applicationId={applicationId}
      />
    </div>
  );
};
