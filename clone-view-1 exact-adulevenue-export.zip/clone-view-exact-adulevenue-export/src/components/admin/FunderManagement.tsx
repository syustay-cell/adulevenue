import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { Plus, Pencil, Trash2 } from "lucide-react";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";

interface Funder {
  id: string;
  name: string;
  contact_email: string;
  portal_url: string | null;
  preferences: any;
  created_at: string;
}

export function FunderManagement() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingFunder, setEditingFunder] = useState<Funder | null>(null);
  const [formData, setFormData] = useState({
    name: "",
    contact_email: "",
    portal_url: "",
    notes: ""
  });

  const { data: funders, isLoading } = useQuery({
    queryKey: ["funders"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("funders")
        .select("*")
        .order("name");
      if (error) throw error;
      return data as Funder[];
    }
  });

  const createMutation = useMutation({
    mutationFn: async (funderData: any) => {
      const { error } = await supabase.from("funders").insert([funderData]);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["funders"] });
      toast({ title: "Funder added successfully" });
      resetForm();
    },
    onError: () => {
      toast({ title: "Failed to add funder", variant: "destructive" });
    }
  });

  const updateMutation = useMutation({
    mutationFn: async ({ id, data }: { id: string; data: any }) => {
      const { error } = await supabase.from("funders").update(data).eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["funders"] });
      toast({ title: "Funder updated successfully" });
      resetForm();
    },
    onError: () => {
      toast({ title: "Failed to update funder", variant: "destructive" });
    }
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("funders").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["funders"] });
      toast({ title: "Funder deleted successfully" });
    },
    onError: () => {
      toast({ title: "Failed to delete funder", variant: "destructive" });
    }
  });

  const resetForm = () => {
    setFormData({ name: "", contact_email: "", portal_url: "", notes: "" });
    setEditingFunder(null);
    setIsDialogOpen(false);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const preferences = formData.notes ? { notes: formData.notes } : {};
    
    if (editingFunder) {
      updateMutation.mutate({
        id: editingFunder.id,
        data: {
          name: formData.name,
          contact_email: formData.contact_email,
          portal_url: formData.portal_url || null,
          preferences
        }
      });
    } else {
      createMutation.mutate({
        name: formData.name,
        contact_email: formData.contact_email,
        portal_url: formData.portal_url || null,
        preferences
      });
    }
  };

  const handleEdit = (funder: Funder) => {
    setEditingFunder(funder);
    setFormData({
      name: funder.name,
      contact_email: funder.contact_email,
      portal_url: funder.portal_url || "",
      notes: funder.preferences?.notes || ""
    });
    setIsDialogOpen(true);
  };

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <div>
          <CardTitle>Funder Management</CardTitle>
          <CardDescription>Manage your funder contacts and preferences</CardDescription>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={() => { resetForm(); setIsDialogOpen(true); }}>
              <Plus className="w-4 h-4 mr-2" />
              Add Funder
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>{editingFunder ? "Edit Funder" : "Add New Funder"}</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label htmlFor="name">Funder Name *</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  required
                />
              </div>
              <div>
                <Label htmlFor="email">Contact Email *</Label>
                <Input
                  id="email"
                  type="email"
                  value={formData.contact_email}
                  onChange={(e) => setFormData({ ...formData, contact_email: e.target.value })}
                  required
                />
              </div>
              <div>
                <Label htmlFor="portal">Portal URL</Label>
                <Input
                  id="portal"
                  type="url"
                  value={formData.portal_url}
                  onChange={(e) => setFormData({ ...formData, portal_url: e.target.value })}
                  placeholder="https://..."
                />
              </div>
              <div>
                <Label htmlFor="notes">Notes / Preferences</Label>
                <Textarea
                  id="notes"
                  value={formData.notes}
                  onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                  placeholder="Min revenue requirements, states covered, etc."
                />
              </div>
              <div className="flex gap-2 justify-end">
                <Button type="button" variant="outline" onClick={resetForm}>
                  Cancel
                </Button>
                <Button type="submit" disabled={createMutation.isPending || updateMutation.isPending}>
                  {editingFunder ? "Update" : "Create"}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="text-center py-8 text-muted-foreground">Loading funders...</div>
        ) : !funders?.length ? (
          <div className="text-center py-8 text-muted-foreground">
            No funders yet. Add your first funder to get started.
          </div>
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Name</TableHead>
                <TableHead>Email</TableHead>
                <TableHead>Portal</TableHead>
                <TableHead>Notes</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {funders.map((funder) => (
                <TableRow key={funder.id}>
                  <TableCell className="font-medium">{funder.name}</TableCell>
                  <TableCell>{funder.contact_email}</TableCell>
                  <TableCell>
                    {funder.portal_url ? (
                      <a
                        href={funder.portal_url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-primary hover:underline"
                      >
                        Portal
                      </a>
                    ) : (
                      "—"
                    )}
                  </TableCell>
                  <TableCell className="max-w-xs truncate">
                    {funder.preferences?.notes || "—"}
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex gap-2 justify-end">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleEdit(funder)}
                      >
                        <Pencil className="w-4 h-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => {
                          if (confirm("Delete this funder?")) {
                            deleteMutation.mutate(funder.id);
                          }
                        }}
                      >
                        <Trash2 className="w-4 h-4 text-destructive" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </CardContent>
    </Card>
  );
}
