import { useState, useEffect } from "react";
import { FileText, Send, AlertTriangle, CheckCircle2, Clock, Loader2, Eye, Scale } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { LegalScanBadge } from "./LegalScanBadge";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "@/hooks/use-toast";

interface Contract {
  id: string;
  deal_room_id: string;
  funder_id: string;
  status: string;
  amount: number | null;
  factor_rate: number | null;
  term_months: number | null;
  payment_frequency: string | null;
  ai_risk_score: number | null;
  ai_risk_flags: string[] | null;
  ai_notes: string | null;
  created_at: string;
  sent_to_client_at: string | null;
  funders?: { name: string };
}

export function AdminContractManager() {
  const [loading, setLoading] = useState(true);
  const [contracts, setContracts] = useState<Contract[]>([]);
  const [selectedContract, setSelectedContract] = useState<Contract | null>(null);
  const [sending, setSending] = useState(false);

  const loadContracts = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from("deal_contracts" as any)
        .select(`
          *,
          funders (name)
        `)
        .order("created_at", { ascending: false });

      if (error) throw error;
      setContracts((data as unknown as Contract[]) || []);
    } catch (err: any) {
      toast({
        title: "Error loading contracts",
        description: err.message,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadContracts();
  }, []);

  const handleSendToClient = async (contract: Contract, approved: boolean) => {
    setSending(true);
    try {
      const { data, error } = await supabase.functions.invoke("send-contract-to-client", {
        body: {
          contract_id: contract.id,
          admin_approved: approved,
        }
      });

      if (error) throw error;

      if (data?.success) {
        toast({
          title: "Contract Sent",
          description: "The contract has been sent to the client via secure Wolf email.",
        });
        setSelectedContract(null);
        loadContracts();
      } else {
        throw new Error(data?.error || "Failed to send contract");
      }
    } catch (err: any) {
      toast({
        title: "Failed to Send",
        description: err.message,
        variant: "destructive",
      });
    } finally {
      setSending(false);
    }
  };

  const getStatusBadge = (status: string, riskScore: number | null) => {
    if (status === "needs_review") {
      return <Badge variant="destructive">Needs Review</Badge>;
    }
    if (status === "sent_to_client") {
      return <Badge className="bg-blue-500">Sent to Client</Badge>;
    }
    if (status === "signed") {
      return <Badge className="bg-green-500">Signed</Badge>;
    }
    if (status === "uploaded") {
      if (riskScore && riskScore > 50) {
        return <Badge variant="outline" className="border-amber-500 text-amber-600">Review Recommended</Badge>;
      }
      return <Badge variant="outline">Ready to Send</Badge>;
    }
    return <Badge variant="outline">{status}</Badge>;
  };

  const formatCurrency = (val: number | null) => {
    if (!val) return "—";
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
      minimumFractionDigits: 0,
    }).format(val);
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <FileText className="h-5 w-5" />
          Contract Management
        </CardTitle>
        <CardDescription>
          Review and send funder contracts to clients through Wolf secure channels
        </CardDescription>
      </CardHeader>
      <CardContent>
        {loading ? (
          <div className="flex items-center justify-center py-8">
            <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
          </div>
        ) : contracts.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            <FileText className="h-12 w-12 mx-auto mb-4 opacity-50" />
            <p>No contracts uploaded yet.</p>
          </div>
        ) : (
          <div className="space-y-3">
            {contracts.map((contract) => (
              <div
                key={contract.id}
                className="flex items-center justify-between p-4 border rounded-lg"
              >
                <div className="flex items-center gap-4">
                  <div className={`p-2 rounded-lg ${
                    contract.status === "needs_review" ? "bg-destructive/10" :
                    contract.status === "signed" ? "bg-green-500/10" :
                    "bg-muted"
                  }`}>
                    {contract.status === "needs_review" ? (
                      <AlertTriangle className="h-5 w-5 text-destructive" />
                    ) : contract.status === "signed" ? (
                      <CheckCircle2 className="h-5 w-5 text-green-500" />
                    ) : (
                      <FileText className="h-5 w-5 text-muted-foreground" />
                    )}
                  </div>
                  <div>
                    <p className="font-medium">
                      {formatCurrency(contract.amount)} @ {contract.factor_rate || "—"}x
                    </p>
                    <p className="text-sm text-muted-foreground">
                      From {contract.funders?.name || "Unknown Funder"} • {contract.term_months || "—"} months
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  {/* Legal Scan Badge */}
                  <LegalScanBadge 
                    contractId={contract.id} 
                    onScanComplete={loadContracts}
                  />
                  {contract.ai_risk_score !== null && (
                    <div className="text-right">
                      <p className="text-xs text-muted-foreground">AI Risk</p>
                      <p className={`font-bold ${
                        contract.ai_risk_score > 50 ? "text-destructive" :
                        contract.ai_risk_score > 30 ? "text-amber-600" :
                        "text-green-600"
                      }`}>
                        {contract.ai_risk_score}
                      </p>
                    </div>
                  )}
                  {getStatusBadge(contract.status, contract.ai_risk_score)}
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => setSelectedContract(contract)}
                  >
                    <Eye className="h-4 w-4 mr-2" />
                    Review
                  </Button>
                  {(contract.status === "uploaded" || contract.status === "needs_review") && (
                    <Button
                      size="sm"
                      onClick={() => setSelectedContract(contract)}
                    >
                      <Send className="h-4 w-4 mr-2" />
                      Send
                    </Button>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Contract Review Dialog */}
        <Dialog open={!!selectedContract} onOpenChange={() => setSelectedContract(null)}>
          <DialogContent className="max-w-lg">
            <DialogHeader>
              <DialogTitle>Review Contract</DialogTitle>
              <DialogDescription>
                Review AI risk assessment before sending to client
              </DialogDescription>
            </DialogHeader>

            {selectedContract && (
              <div className="space-y-4">
                {/* Contract Details */}
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm text-muted-foreground">Amount</p>
                    <p className="font-medium">{formatCurrency(selectedContract.amount)}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Factor Rate</p>
                    <p className="font-medium">{selectedContract.factor_rate || "—"}x</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Term</p>
                    <p className="font-medium">{selectedContract.term_months || "—"} months</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Frequency</p>
                    <p className="font-medium capitalize">{selectedContract.payment_frequency || "—"}</p>
                  </div>
                </div>

                {/* Risk Assessment */}
                <div className={`p-4 rounded-lg ${
                  (selectedContract.ai_risk_score || 0) > 50 
                    ? "bg-destructive/10 border border-destructive/20" 
                    : "bg-muted"
                }`}>
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-medium">AI Risk Assessment</span>
                    <Badge variant={(selectedContract.ai_risk_score || 0) > 50 ? "destructive" : "outline"}>
                      Score: {selectedContract.ai_risk_score || 0}
                    </Badge>
                  </div>
                  
                  {selectedContract.ai_notes && (
                    <p className="text-sm text-muted-foreground mb-2">{selectedContract.ai_notes}</p>
                  )}

                  {selectedContract.ai_risk_flags && selectedContract.ai_risk_flags.length > 0 && (
                    <div className="space-y-1">
                      <p className="text-sm font-medium text-destructive">Risk Flags:</p>
                      <ul className="text-sm space-y-1">
                        {selectedContract.ai_risk_flags.map((flag, i) => (
                          <li key={i} className="flex items-start gap-2">
                            <AlertTriangle className="h-4 w-4 text-destructive flex-shrink-0 mt-0.5" />
                            <span>{flag}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>

                {/* Status Info */}
                {selectedContract.sent_to_client_at && (
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Clock className="h-4 w-4" />
                    <span>Sent to client on {new Date(selectedContract.sent_to_client_at).toLocaleString()}</span>
                  </div>
                )}
              </div>
            )}

            <DialogFooter>
              <Button variant="outline" onClick={() => setSelectedContract(null)}>
                Cancel
              </Button>
              {selectedContract && (selectedContract.status === "uploaded" || selectedContract.status === "needs_review") && (
                <Button
                  onClick={() => handleSendToClient(selectedContract, true)}
                  disabled={sending}
                >
                  {sending ? (
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  ) : (
                    <Send className="h-4 w-4 mr-2" />
                  )}
                  Approve & Send to Client
                </Button>
              )}
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </CardContent>
    </Card>
  );
}
