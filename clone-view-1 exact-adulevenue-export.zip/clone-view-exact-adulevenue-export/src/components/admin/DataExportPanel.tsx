import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Download, FileSpreadsheet, Users, CreditCard, DollarSign, Loader2 } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

const EXPORT_TYPES = [
  { value: 'leads', label: 'Leads', icon: Users, description: 'Export all leads with contact info and status' },
  { value: 'deals', label: 'Deals/Applications', icon: FileSpreadsheet, description: 'Export funding applications' },
  { value: 'credit_cases', label: 'Credit Repair Cases', icon: CreditCard, description: 'Export credit repair cases and status' },
  { value: 'commissions', label: 'Commissions', icon: DollarSign, description: 'Export funded deals and commission data' }
];

export function DataExportPanel() {
  const [exportType, setExportType] = useState<string>('leads');
  const [dateFrom, setDateFrom] = useState<string>('');
  const [dateTo, setDateTo] = useState<string>('');
  const [status, setStatus] = useState<string>('');
  const [exporting, setExporting] = useState(false);
  const [lastExport, setLastExport] = useState<{ type: string; count: number; date: string } | null>(null);

  const downloadCSV = (csv: string, filename: string) => {
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', filename);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleExport = async () => {
    setExporting(true);
    try {
      const filters: Record<string, string> = {};
      if (dateFrom) filters.date_from = dateFrom;
      if (dateTo) filters.date_to = dateTo;
      if (status) filters.status = status;

      const { data, error } = await supabase.functions.invoke('export-data', {
        body: { export_type: exportType, filters, format: 'csv' }
      });

      if (error) throw error;
      if (!data?.ok) throw new Error(data?.message || 'Export failed');

      const filename = `wolf_${exportType}_${new Date().toISOString().split('T')[0]}.csv`;
      downloadCSV(data.data.csv, filename);
      
      setLastExport({
        type: exportType,
        count: data.data.count,
        date: new Date().toISOString()
      });
      
      toast.success(`Exported ${data.data.count} records`);
    } catch (err) {
      console.error('Export error:', err);
      toast.error('Failed to export data');
    } finally {
      setExporting(false);
    }
  };

  const selectedType = EXPORT_TYPES.find(t => t.value === exportType);
  const TypeIcon = selectedType?.icon || FileSpreadsheet;

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle className="text-lg flex items-center gap-2">
            <Download className="h-5 w-5" />
            Data Export
          </CardTitle>
          <CardDescription>
            Export leads, deals, credit cases, and commissions to CSV
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Export Type Selection */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {EXPORT_TYPES.map((type) => {
              const Icon = type.icon;
              const isSelected = exportType === type.value;
              return (
                <button
                  key={type.value}
                  onClick={() => setExportType(type.value)}
                  className={`p-4 rounded-lg border text-left transition-colors ${
                    isSelected 
                      ? 'border-primary bg-primary/5' 
                      : 'border-border hover:border-primary/50'
                  }`}
                >
                  <Icon className={`h-5 w-5 mb-2 ${isSelected ? 'text-primary' : 'text-muted-foreground'}`} />
                  <div className="font-medium text-sm">{type.label}</div>
                  <div className="text-xs text-muted-foreground mt-1">{type.description}</div>
                </button>
              );
            })}
          </div>

          {/* Filters */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <Label>Date From</Label>
              <Input 
                type="date" 
                value={dateFrom}
                onChange={(e) => setDateFrom(e.target.value)}
              />
            </div>
            <div>
              <Label>Date To</Label>
              <Input 
                type="date" 
                value={dateTo}
                onChange={(e) => setDateTo(e.target.value)}
              />
            </div>
            <div>
              <Label>Status Filter</Label>
              <Input 
                placeholder="e.g., funded, pending"
                value={status}
                onChange={(e) => setStatus(e.target.value)}
              />
            </div>
          </div>

          {/* Export Button */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <TypeIcon className="h-5 w-5 text-muted-foreground" />
              <span className="text-sm text-muted-foreground">
                Ready to export: {selectedType?.label}
              </span>
            </div>
            <Button onClick={handleExport} disabled={exporting}>
              {exporting ? (
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
              ) : (
                <Download className="h-4 w-4 mr-2" />
              )}
              Export to CSV
            </Button>
          </div>

          {/* Last Export Info */}
          {lastExport && (
            <div className="bg-muted/50 p-3 rounded-lg text-sm">
              <span className="text-muted-foreground">Last export: </span>
              <Badge variant="outline" className="mr-2">{lastExport.type}</Badge>
              <span>{lastExport.count} records</span>
              <span className="text-muted-foreground ml-2">
                at {new Date(lastExport.date).toLocaleTimeString()}
              </span>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
