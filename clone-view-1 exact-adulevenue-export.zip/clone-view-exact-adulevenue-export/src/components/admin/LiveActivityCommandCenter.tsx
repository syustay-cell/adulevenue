import React, { useEffect, useState, useCallback } from 'react';
import {
  getActivityEvents,
  summarizeEventsForSpeech,
  getModeFilterLabel,
  type ActivityEvent,
  type ActivityScope,
  type ActivityDecision,
} from '@/lib/activity';
import { Button } from '@/components/ui/button';
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';
import { Volume2, VolumeX, RefreshCw, Loader2, Activity, Bot, User, Cog } from 'lucide-react';

type ModeFilter = 'ALL' | 'MANUAL' | 'AUTOPILOT_STANDARD' | 'AUTOPILOT_ECO' | 'AUTOPILOT_AGGRESSIVE';

function getActorIcon(actorType: string) {
  switch (actorType) {
    case 'AI':
      return <Bot className="h-3 w-3" />;
    case 'ADMIN':
    case 'WORKER':
      return <User className="h-3 w-3" />;
    case 'SYSTEM':
      return <Cog className="h-3 w-3" />;
    default:
      return null;
  }
}

function getDecisionColor(decision: string | null) {
  switch (decision) {
    case 'APPROVED':
      return 'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-300';
    case 'DECLINED':
      return 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-300';
    case 'ESCALATED':
      return 'bg-yellow-100 text-yellow-700 dark:bg-yellow-900/30 dark:text-yellow-300';
    case 'AUTO_ACTION':
      return 'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-300';
    default:
      return 'bg-muted text-muted-foreground';
  }
}

function getSeverityColor(severity: string | null) {
  switch (severity) {
    case 'CRITICAL':
      return 'border-l-red-500';
    case 'HIGH':
      return 'border-l-orange-500';
    case 'MEDIUM':
      return 'border-l-yellow-500';
    case 'LOW':
      return 'border-l-green-500';
    default:
      return 'border-l-muted';
  }
}

interface LiveActivityCommandCenterProps {
  refreshTrigger?: number;
}

export function LiveActivityCommandCenter({ refreshTrigger }: LiveActivityCommandCenterProps) {
  const [events, setEvents] = useState<ActivityEvent[]>([]);
  const [loading, setLoading] = useState(false);
  const [playing, setPlaying] = useState(false);

  const [scopeFilter, setScopeFilter] = useState<ActivityScope | 'ALL'>('ALL');
  const [decisionFilter, setDecisionFilter] = useState<ActivityDecision | 'ALL'>('ALL');
  const [modeFilter, setModeFilter] = useState<ModeFilter>('ALL');

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const data = await getActivityEvents({
        scope: scopeFilter,
        decision: decisionFilter,
        mode: modeFilter,
        limit: 50,
      });
      setEvents(data);
    } catch (err) {
      console.error(err);
      toast.error('Failed to load activity');
    } finally {
      setLoading(false);
    }
  }, [scopeFilter, decisionFilter, modeFilter]);

  useEffect(() => {
    load();
  }, [load, refreshTrigger]);

  const modeLabel = getModeFilterLabel(modeFilter);

  function handlePlay() {
    if (playing) {
      window.speechSynthesis.cancel();
      setPlaying(false);
      return;
    }

    if (events.length === 0) {
      toast.info('No recent activity to read');
      return;
    }

    const text = summarizeEventsForSpeech(events, 15, modeLabel);

    const synth = window.speechSynthesis;
    if (!synth) {
      toast.error('Text-to-speech is not supported in this browser');
      return;
    }

    setPlaying(true);
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = 1.0;
    utterance.pitch = 1.0;
    utterance.lang = 'en-US';
    utterance.onend = () => setPlaying(false);
    utterance.onerror = () => setPlaying(false);
    synth.cancel();
    synth.speak(utterance);
  }

  const filterDescription = modeFilter === 'ALL' 
    ? 'Showing all events.'
    : `Showing events while ${modeLabel} was active.`;

  return (
    <div className="rounded-lg border bg-card p-4 flex flex-col gap-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-semibold flex items-center gap-2">
            <Activity className="h-5 w-5" />
            Live Activity Command Center
          </h2>
          <p className="text-xs text-muted-foreground mt-0.5">
            {filterDescription}
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Button 
            variant="outline" 
            size="sm" 
            onClick={handlePlay}
            className="gap-1"
          >
            {playing ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
            {playing ? 'Stop' : 'Play'}
          </Button>
          <Button 
            variant="outline" 
            size="sm" 
            onClick={load} 
            disabled={loading}
          >
            {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <RefreshCw className="h-4 w-4" />}
          </Button>
        </div>
      </div>

      {/* Filters */}
      <div className="flex flex-wrap gap-2">
        <Select
          value={scopeFilter}
          onValueChange={(v) => setScopeFilter(v as ActivityScope | 'ALL')}
        >
          <SelectTrigger className="w-[160px]">
            <SelectValue placeholder="Scope" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="ALL">All Scopes</SelectItem>
            <SelectItem value="UNDERWRITING">Underwriting</SelectItem>
            <SelectItem value="COLLECTIONS">Collections</SelectItem>
            <SelectItem value="RENEWALS">Renewals</SelectItem>
            <SelectItem value="LEADS">Leads</SelectItem>
            <SelectItem value="CREDIT_REPAIR">Credit Repair</SelectItem>
            <SelectItem value="SYSTEM_MODE">System Mode</SelectItem>
            <SelectItem value="GENERAL">General</SelectItem>
          </SelectContent>
        </Select>

        <Select
          value={decisionFilter}
          onValueChange={(v) => setDecisionFilter(v as ActivityDecision | 'ALL')}
        >
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="Decision" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="ALL">All Decisions</SelectItem>
            <SelectItem value="APPROVED">Approved</SelectItem>
            <SelectItem value="DECLINED">Declined</SelectItem>
            <SelectItem value="ESCALATED">Escalated</SelectItem>
            <SelectItem value="AUTO_ACTION">AI Auto-Action</SelectItem>
            <SelectItem value="INFO">Info / Log Only</SelectItem>
          </SelectContent>
        </Select>

        <Select
          value={modeFilter}
          onValueChange={(v) => setModeFilter(v as ModeFilter)}
        >
          <SelectTrigger className="w-[220px]">
            <SelectValue placeholder="Mode" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="ALL">Mode: All</SelectItem>
            <SelectItem value="MANUAL">Manual only</SelectItem>
            <SelectItem value="AUTOPILOT_STANDARD">Autopilot · Standard</SelectItem>
            <SelectItem value="AUTOPILOT_ECO">Autopilot · Eco</SelectItem>
            <SelectItem value="AUTOPILOT_AGGRESSIVE">Autopilot · Aggressive</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Event list */}
      <div className="flex flex-col gap-2 max-h-[480px] overflow-y-auto">
        {loading && events.length === 0 && (
          <div className="flex items-center justify-center py-8">
            <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
          </div>
        )}
        
        {!loading && events.length === 0 && (
          <div className="text-sm text-muted-foreground text-center py-8">
            No activity matching the current filters.
          </div>
        )}

        {events.map((e) => (
          <div
            key={e.id}
            className={`rounded-md border bg-background px-3 py-2 text-sm flex flex-col gap-1 border-l-4 ${getSeverityColor(e.severity)}`}
          >
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-2 flex-1 min-w-0">
                <span className="font-medium text-foreground truncate">
                  {e.summary}
                </span>
                <Badge variant="outline" className="text-[10px] shrink-0">
                  {e.scope.replace('_', ' ')}
                </Badge>
              </div>
              <span className="text-[10px] text-muted-foreground shrink-0">
                {new Date(e.created_at).toLocaleTimeString()}
              </span>
            </div>
            <div className="flex flex-wrap items-center gap-2 text-[11px] text-muted-foreground">
              <span className="inline-flex items-center gap-1 rounded-full bg-muted px-2 py-[1px]">
                {getActorIcon(e.actor_type)}
                {e.actor_type}
              </span>
              {e.decision && (
                <span className={`rounded-full px-2 py-[1px] ${getDecisionColor(e.decision)}`}>
                  {e.decision.replace('_', ' ')}
                </span>
              )}
              <span className="rounded-full bg-muted px-2 py-[1px]">
                {e.execution_mode === 'MANUAL'
                  ? 'Manual'
                  : `Autopilot · ${e.strategy_profile}`}
              </span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
