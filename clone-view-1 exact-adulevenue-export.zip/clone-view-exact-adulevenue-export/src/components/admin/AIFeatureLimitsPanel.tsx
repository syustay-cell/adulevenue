import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Input } from '@/components/ui/input';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { RefreshCw, Power, Zap, AlertTriangle } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

interface AILimit {
  id: string;
  feature_key: string;
  is_enabled: boolean;
  force_template_mode: boolean;
  max_daily_calls: number | null;
  current_daily_calls: number;
  provider_override: string | null;
  description: string | null;
  last_reset_at: string;
}

export function AIFeatureLimitsPanel() {
  const [limits, setLimits] = useState<AILimit[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState<string | null>(null);

  useEffect(() => {
    loadLimits();
  }, []);

  const loadLimits = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('wolf_ai_limits')
        .select('*')
        .order('feature_key');
      
      if (error) throw error;
      setLimits((data as AILimit[]) || []);
    } catch (err) {
      console.error('Failed to load AI limits:', err);
      toast.error('Failed to load AI feature limits');
    } finally {
      setLoading(false);
    }
  };

  const updateLimit = async (id: string, updates: Partial<AILimit>) => {
    setSaving(id);
    try {
      const { error } = await supabase
        .from('wolf_ai_limits')
        .update(updates)
        .eq('id', id);
      
      if (error) throw error;
      
      setLimits(prev => prev.map(l => l.id === id ? { ...l, ...updates } : l));
      toast.success('AI limit updated');
    } catch (err) {
      console.error('Failed to update limit:', err);
      toast.error('Failed to update AI limit');
    } finally {
      setSaving(null);
    }
  };

  const resetDailyCounters = async () => {
    try {
      const { error } = await supabase
        .from('wolf_ai_limits')
        .update({ current_daily_calls: 0, last_reset_at: new Date().toISOString() })
        .neq('id', '00000000-0000-0000-0000-000000000000');
      
      if (error) throw error;
      
      loadLimits();
      toast.success('Daily counters reset');
    } catch (err) {
      console.error('Failed to reset counters:', err);
      toast.error('Failed to reset counters');
    }
  };

  if (loading) {
    return (
      <Card>
        <CardContent className="p-8 text-center">
          <RefreshCw className="h-6 w-6 animate-spin mx-auto mb-2 text-muted-foreground" />
          <p className="text-sm text-muted-foreground">Loading AI feature limits...</p>
        </CardContent>
      </Card>
    );
  }

  const disabledCount = limits.filter(l => !l.is_enabled).length;
  const templateModeCount = limits.filter(l => l.force_template_mode).length;

  return (
    <div className="space-y-4">
      {/* Status Banner */}
      <Card className={disabledCount > 0 ? 'border-destructive' : ''}>
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <Power className="h-4 w-4" />
                <span className="text-sm font-medium">Active Features:</span>
                <Badge variant="default">{limits.length - disabledCount} / {limits.length}</Badge>
              </div>
              {disabledCount > 0 && (
                <Badge variant="destructive">
                  <AlertTriangle className="h-3 w-3 mr-1" />
                  {disabledCount} Disabled
                </Badge>
              )}
              {templateModeCount > 0 && (
                <Badge variant="secondary">
                  {templateModeCount} Template-Only
                </Badge>
              )}
            </div>
            <Button variant="outline" size="sm" onClick={resetDailyCounters}>
              Reset Daily Counters
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Feature Limits Table */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg flex items-center gap-2">
            <Zap className="h-5 w-5" />
            AI Feature Limits & Kill Switches
          </CardTitle>
          <CardDescription>
            Control which AI features are enabled, set daily limits, and force template mode
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Feature</TableHead>
                <TableHead>Enabled</TableHead>
                <TableHead>Template Mode</TableHead>
                <TableHead>Provider</TableHead>
                <TableHead>Daily Limit</TableHead>
                <TableHead>Today's Usage</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {limits.map((limit) => (
                <TableRow key={limit.id} className={!limit.is_enabled ? 'opacity-50' : ''}>
                  <TableCell>
                    <div>
                      <div className="font-medium">{limit.feature_key.replace(/_/g, ' ')}</div>
                      {limit.description && (
                        <div className="text-xs text-muted-foreground">{limit.description}</div>
                      )}
                    </div>
                  </TableCell>
                  <TableCell>
                    <Switch
                      checked={limit.is_enabled}
                      onCheckedChange={(v) => updateLimit(limit.id, { is_enabled: v })}
                      disabled={saving === limit.id}
                    />
                  </TableCell>
                  <TableCell>
                    <Switch
                      checked={limit.force_template_mode}
                      onCheckedChange={(v) => updateLimit(limit.id, { force_template_mode: v })}
                      disabled={saving === limit.id || !limit.is_enabled}
                    />
                  </TableCell>
                  <TableCell>
                    <Select
                      value={limit.provider_override || 'auto'}
                      onValueChange={(v) => updateLimit(limit.id, { provider_override: v === 'auto' ? null : v })}
                      disabled={saving === limit.id || !limit.is_enabled}
                    >
                      <SelectTrigger className="w-28">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="auto">Auto</SelectItem>
                        <SelectItem value="openai">OpenAI</SelectItem>
                        <SelectItem value="gateway">AI Gateway</SelectItem>
                        <SelectItem value="manual">Manual</SelectItem>
                      </SelectContent>
                    </Select>
                  </TableCell>
                  <TableCell>
                    <Input
                      type="number"
                      className="w-20"
                      value={limit.max_daily_calls ?? ''}
                      placeholder="∞"
                      onChange={(e) => updateLimit(limit.id, { 
                        max_daily_calls: e.target.value ? parseInt(e.target.value) : null 
                      })}
                      disabled={saving === limit.id || !limit.is_enabled}
                    />
                  </TableCell>
                  <TableCell>
                    <Badge 
                      variant={
                        limit.max_daily_calls && limit.current_daily_calls >= limit.max_daily_calls 
                          ? 'destructive' 
                          : limit.max_daily_calls && limit.current_daily_calls >= limit.max_daily_calls * 0.8
                          ? 'secondary'
                          : 'default'
                      }
                    >
                      {limit.current_daily_calls}
                      {limit.max_daily_calls && ` / ${limit.max_daily_calls}`}
                    </Badge>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
