import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Lock, Unlock, Zap, Hand, Settings2 } from 'lucide-react';
import { toast } from 'sonner';
import {
  getSystemMode,
  setSystemMode,
  verifyOptimizationPin,
  getModeDisplayInfo,
  type SystemMode,
} from '@/lib/systemMode';

export function OwnerModeSwitch() {
  const [mode, setModeState] = useState<SystemMode>('AUTOPILOT');
  const [pin, setPin] = useState('');
  const [unlocked, setUnlocked] = useState(false);
  const [loading, setLoading] = useState(false);
  const [initialLoading, setInitialLoading] = useState(true);

  useEffect(() => {
    loadCurrentMode();
  }, []);

  async function loadCurrentMode() {
    try {
      const currentMode = await getSystemMode();
      setModeState(currentMode);
      if (currentMode === 'OPTIMIZATION_PILOT') {
        setUnlocked(true);
      }
    } catch (error) {
      console.error('Failed to load system mode:', error);
    } finally {
      setInitialLoading(false);
    }
  }

  async function handleUnlock() {
    if (!pin.trim()) {
      toast.error('Enter the optimization PIN');
      return;
    }

    setLoading(true);
    try {
      const ok = await verifyOptimizationPin(pin);
      if (ok) {
        setUnlocked(true);
        setPin('');
        toast.success('Optimization mode unlocked');
      } else {
        toast.error('Invalid PIN');
      }
    } catch (error) {
      toast.error('Failed to verify PIN');
    } finally {
      setLoading(false);
    }
  }

  async function changeMode(next: SystemMode) {
    if (!unlocked && next === 'OPTIMIZATION_PILOT') {
      toast.error('Unlock optimization mode first');
      return;
    }

    setLoading(true);
    try {
      const res = await setSystemMode(next);
      if (res.success) {
        setModeState(next);
        const info = getModeDisplayInfo(next);
        toast.success(`Switched to ${info.label} mode`);
      } else {
        toast.error(res.error || 'Failed to change mode');
      }
    } catch (error) {
      toast.error('Failed to change mode');
    } finally {
      setLoading(false);
    }
  }

  if (initialLoading) {
    return (
      <div className="border rounded-lg p-4 bg-muted/50 animate-pulse">
        <div className="h-6 bg-muted rounded w-32" />
      </div>
    );
  }

  const modeInfo = getModeDisplayInfo(mode);

  return (
    <div className="border rounded-lg p-4 space-y-4 bg-card">
      <div className="flex items-start justify-between gap-4">
        <div className="flex-1">
          <div className="flex items-center gap-2">
            <Settings2 className="h-5 w-5 text-muted-foreground" />
            <span className="font-semibold">System Mode</span>
            <Badge variant={mode === 'AUTOPILOT' ? 'default' : mode === 'OPTIMIZATION_PILOT' ? 'secondary' : 'outline'}>
              {modeInfo.label}
            </Badge>
          </div>
          <p className="text-sm text-muted-foreground mt-1">
            {modeInfo.description}
          </p>
        </div>

        <div className="flex gap-2 flex-shrink-0">
          <Button
            size="sm"
            variant={mode === 'MANUAL' ? 'default' : 'outline'}
            onClick={() => changeMode('MANUAL')}
            disabled={loading}
          >
            <Hand className="h-4 w-4 mr-1" />
            Manual
          </Button>
          <Button
            size="sm"
            variant={mode === 'AUTOPILOT' ? 'default' : 'outline'}
            onClick={() => changeMode('AUTOPILOT')}
            disabled={loading}
          >
            <Zap className="h-4 w-4 mr-1" />
            Autopilot
          </Button>
          <Button
            size="sm"
            variant={mode === 'OPTIMIZATION_PILOT' ? 'default' : 'outline'}
            onClick={() => changeMode('OPTIMIZATION_PILOT')}
            disabled={loading || !unlocked}
          >
            {unlocked ? (
              <Unlock className="h-4 w-4 mr-1" />
            ) : (
              <Lock className="h-4 w-4 mr-1" />
            )}
            555
          </Button>
        </div>
      </div>

      {!unlocked && (
        <div className="flex items-center gap-2 pt-2 border-t">
          <Lock className="h-4 w-4 text-muted-foreground" />
          <span className="text-sm text-muted-foreground">Enter PIN to unlock optimization mode:</span>
          <Input
            type="password"
            placeholder="555"
            value={pin}
            onChange={(e) => setPin(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleUnlock()}
            className="max-w-[100px]"
          />
          <Button size="sm" onClick={handleUnlock} disabled={loading}>
            Unlock
          </Button>
        </div>
      )}

      {unlocked && mode !== 'OPTIMIZATION_PILOT' && (
        <div className="flex items-center gap-2 pt-2 border-t text-sm text-muted-foreground">
          <Unlock className="h-4 w-4 text-green-600" />
          <span>Optimization mode unlocked. Click "555" to activate.</span>
        </div>
      )}
    </div>
  );
}
