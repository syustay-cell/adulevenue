import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  Instagram, 
  Facebook, 
  Youtube, 
  Globe, 
  Smartphone, 
  FileText,
  TrendingUp
} from "lucide-react";

interface SourceStats {
  source: string;
  count: number;
  fundedCount: number;
  totalFunded: number;
}

interface WolfFolderStats {
  folder: string;
  count: number;
  sources: Record<string, number>;
}

const sourceIcons: Record<string, React.ReactNode> = {
  APP: <Smartphone className="w-4 h-4" />,
  IG: <Instagram className="w-4 h-4" />,
  FB: <Facebook className="w-4 h-4" />,
  TT: <TrendingUp className="w-4 h-4" />, // TikTok
  YT: <Youtube className="w-4 h-4" />,
  WEB: <Globe className="w-4 h-4" />,
  MANUAL: <FileText className="w-4 h-4" />,
  OTHER: <Globe className="w-4 h-4" />,
};

const sourceLabels: Record<string, string> = {
  APP: "Application",
  IG: "Instagram",
  FB: "Facebook",
  TT: "TikTok",
  YT: "YouTube",
  WEB: "Website",
  MANUAL: "Manual",
  OTHER: "Other",
};

export function LeadSourceAnalytics() {
  const [loading, setLoading] = useState(true);
  const [sourceStats, setSourceStats] = useState<SourceStats[]>([]);
  const [folderStats, setFolderStats] = useState<WolfFolderStats[]>([]);

  useEffect(() => {
    fetchStats();
  }, []);

  const fetchStats = async () => {
    setLoading(true);
    try {
      // Fetch leads with source info
      const { data: leads } = await supabase
        .from("leads")
        .select("source, wolf_folder_label, funded_at");

      if (!leads) return;

      // Calculate source stats
      const sourceMap = new Map<string, SourceStats>();
      const folderMap = new Map<string, WolfFolderStats>();

      for (const lead of leads) {
        const source = lead.source || "OTHER";
        const folder = lead.wolf_folder_label || "Unknown";
        const isFunded = !!lead.funded_at;

        // Source stats
        if (!sourceMap.has(source)) {
          sourceMap.set(source, { source, count: 0, fundedCount: 0, totalFunded: 0 });
        }
        const stat = sourceMap.get(source)!;
        stat.count++;
        if (isFunded) stat.fundedCount++;

        // Folder stats
        if (!folderMap.has(folder)) {
          folderMap.set(folder, { folder, count: 0, sources: {} });
        }
        const fStat = folderMap.get(folder)!;
        fStat.count++;
        fStat.sources[source] = (fStat.sources[source] || 0) + 1;
      }

      setSourceStats(
        Array.from(sourceMap.values()).sort((a, b) => b.count - a.count)
      );
      setFolderStats(
        Array.from(folderMap.values()).sort((a, b) => {
          // Sort by date (newest first) - parse "Wolf January 2026" format
          const aDate = parseWolfFolder(a.folder);
          const bDate = parseWolfFolder(b.folder);
          return bDate.getTime() - aDate.getTime();
        })
      );
    } catch (err) {
      console.error("Error fetching lead stats:", err);
    } finally {
      setLoading(false);
    }
  };

  const parseWolfFolder = (folder: string): Date => {
    const match = folder.match(/Wolf (\w+) (\d{4})/);
    if (match) {
      const monthNames = [
        "January", "February", "March", "April", "May", "June",
        "July", "August", "September", "October", "November", "December"
      ];
      const monthIndex = monthNames.indexOf(match[1]);
      const year = parseInt(match[2]);
      if (monthIndex >= 0) {
        return new Date(year, monthIndex, 1);
      }
    }
    return new Date(0);
  };

  if (loading) {
    return (
      <Card>
        <CardContent className="py-6">
          <div className="text-center text-muted-foreground">Loading analytics...</div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Source Breakdown */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Lead Sources</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {sourceStats.map((stat) => (
              <div
                key={stat.source}
                className="p-4 rounded-lg border bg-muted/30 text-center"
              >
                <div className="flex justify-center mb-2">
                  {sourceIcons[stat.source] || sourceIcons.OTHER}
                </div>
                <p className="text-2xl font-bold">{stat.count}</p>
                <p className="text-sm text-muted-foreground">
                  {sourceLabels[stat.source] || stat.source}
                </p>
                {stat.fundedCount > 0 && (
                  <Badge variant="secondary" className="mt-2">
                    {stat.fundedCount} funded
                  </Badge>
                )}
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Wolf Folder Timeline */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Wolf Folders (Monthly Batches)</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {folderStats.slice(0, 6).map((folder) => (
              <div
                key={folder.folder}
                className="flex items-center justify-between p-3 rounded-lg border"
              >
                <div>
                  <p className="font-medium">{folder.folder}</p>
                  <div className="flex gap-2 mt-1 flex-wrap">
                    {Object.entries(folder.sources).map(([src, count]) => (
                      <Badge key={src} variant="outline" className="text-xs">
                        {sourceLabels[src] || src}: {count}
                      </Badge>
                    ))}
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-2xl font-bold">{folder.count}</p>
                  <p className="text-xs text-muted-foreground">leads</p>
                </div>
              </div>
            ))}

            {folderStats.length === 0 && (
              <p className="text-center text-muted-foreground py-4">
                No lead data with folder labels yet
              </p>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
