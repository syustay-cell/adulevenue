import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import { 
  DollarSign, 
  Users, 
  Building2, 
  UserCheck, 
  Bot,
  RefreshCw,
  ChevronDown,
  ChevronUp
} from "lucide-react";

interface CommissionPayout {
  dealId: string;
  participantRole: string;
  participantId: string | null;
  amount: number;
  percentOfPool: number;
}

interface CommissionDebug {
  context: any;
  rules: any;
  payouts: CommissionPayout[];
  calculated_at: string;
  version: string;
}

interface DealCommissionBreakdownProps {
  dealId: string;
  grossCommissionPool?: number;
  onRecalculate?: () => void;
}

const roleLabels: Record<string, { label: string; icon: React.ReactNode; color: string }> = {
  HOUSE: { label: "House (Wolf)", icon: <Building2 className="w-4 h-4" />, color: "bg-primary" },
  OPENER: { label: "Opener", icon: <UserCheck className="w-4 h-4" />, color: "bg-blue-500" },
  CLOSER: { label: "Closer", icon: <UserCheck className="w-4 h-4" />, color: "bg-indigo-500" },
  WORKER_REFERRAL: { label: "Worker Referral", icon: <Users className="w-4 h-4" />, color: "bg-purple-500" },
  REFERRAL_PARTNER: { label: "Referral Partner", icon: <Users className="w-4 h-4" />, color: "bg-pink-500" },
  ISO_PARTNER: { label: "ISO Partner", icon: <Building2 className="w-4 h-4" />, color: "bg-orange-500" },
  AI_AUTOPILOT: { label: "AI Autopilot", icon: <Bot className="w-4 h-4" />, color: "bg-green-500" },
};

export function DealCommissionBreakdown({ 
  dealId, 
  grossCommissionPool = 0,
  onRecalculate 
}: DealCommissionBreakdownProps) {
  const [loading, setLoading] = useState(false);
  const [calculating, setCalculating] = useState(false);
  const [payouts, setPayouts] = useState<CommissionPayout[]>([]);
  const [debugInfo, setDebugInfo] = useState<CommissionDebug | null>(null);
  const [showDebug, setShowDebug] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    fetchPayouts();
  }, [dealId]);

  const fetchPayouts = async () => {
    setLoading(true);
    try {
      // Fetch from deal_participants
      const { data: participants, error } = await supabase
        .from("deal_participants")
        .select("*")
        .eq("deal_id", dealId)
        .order("amount", { ascending: false });

      if (error) throw error;

      // Map to payout format
      const mappedPayouts: CommissionPayout[] = (participants || []).map((p: any) => ({
        dealId: p.deal_id,
        participantRole: p.role,
        participantId: p.entity_id,
        amount: Number(p.amount),
        percentOfPool: Number(p.percent_of_pool),
      }));

      setPayouts(mappedPayouts);

      // Fetch debug info from deal
      const { data: deal } = await supabase
        .from("deals")
        .select("commission_debug_json")
        .eq("id", dealId)
        .single();

      if (deal?.commission_debug_json) {
        setDebugInfo(deal.commission_debug_json as unknown as CommissionDebug);
      }
    } catch (err) {
      console.error("Error fetching payouts:", err);
    } finally {
      setLoading(false);
    }
  };

  const recalculateCommissions = async () => {
    setCalculating(true);
    try {
      const { data, error } = await supabase.functions.invoke("calculate-deal-commissions", {
        body: { dealId, recalculate: true },
      });

      if (error) throw error;

      if (data?.ok) {
        toast({
          title: "Commissions Recalculated",
          description: `${data.payouts?.length || 0} participants calculated`,
        });
        setPayouts(data.payouts || []);
        setDebugInfo(data.debug || null);
        onRecalculate?.();
      } else {
        throw new Error(data?.message || "Calculation failed");
      }
    } catch (err: any) {
      toast({
        title: "Error",
        description: err.message,
        variant: "destructive",
      });
    } finally {
      setCalculating(false);
    }
  };

  const totalAmount = payouts.reduce((sum, p) => sum + p.amount, 0);

  if (loading) {
    return (
      <Card>
        <CardContent className="py-6">
          <div className="text-center text-muted-foreground">Loading commission breakdown...</div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg flex items-center gap-2">
            <DollarSign className="w-5 h-5" />
            Commission Breakdown
          </CardTitle>
          <Button
            size="sm"
            variant="outline"
            onClick={recalculateCommissions}
            disabled={calculating}
          >
            <RefreshCw className={`w-4 h-4 mr-2 ${calculating ? "animate-spin" : ""}`} />
            {calculating ? "Calculating..." : "Recalculate"}
          </Button>
        </div>
        {grossCommissionPool > 0 && (
          <p className="text-sm text-muted-foreground">
            Pool: ${grossCommissionPool.toLocaleString()}
          </p>
        )}
      </CardHeader>
      <CardContent>
        {payouts.length === 0 ? (
          <div className="text-center py-6">
            <p className="text-muted-foreground mb-4">No commissions calculated yet</p>
            <Button onClick={recalculateCommissions} disabled={calculating}>
              Calculate Commissions
            </Button>
          </div>
        ) : (
          <div className="space-y-3">
            {payouts.map((payout, idx) => {
              const roleInfo = roleLabels[payout.participantRole] || {
                label: payout.participantRole,
                icon: <DollarSign className="w-4 h-4" />,
                color: "bg-gray-500",
              };

              return (
                <div
                  key={idx}
                  className="flex items-center justify-between p-3 rounded-lg border bg-muted/30"
                >
                  <div className="flex items-center gap-3">
                    <Badge className={`${roleInfo.color} text-white`}>
                      {roleInfo.icon}
                    </Badge>
                    <div>
                      <p className="font-medium">{roleInfo.label}</p>
                      {payout.participantId && (
                        <p className="text-xs text-muted-foreground truncate max-w-[150px]">
                          ID: {payout.participantId.slice(0, 8)}...
                        </p>
                      )}
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-bold text-lg">${payout.amount.toLocaleString()}</p>
                    <p className="text-xs text-muted-foreground">
                      {(payout.percentOfPool * 100).toFixed(1)}%
                    </p>
                  </div>
                </div>
              );
            })}

            <Separator className="my-4" />

            <div className="flex items-center justify-between p-3 rounded-lg bg-primary/10">
              <p className="font-semibold">Total Distributed</p>
              <p className="font-bold text-xl">${totalAmount.toLocaleString()}</p>
            </div>

            {/* Debug Info Toggle */}
            {debugInfo && (
              <div className="mt-4">
                <Button
                  variant="ghost"
                  size="sm"
                  className="w-full justify-between"
                  onClick={() => setShowDebug(!showDebug)}
                >
                  <span className="text-xs text-muted-foreground">
                    Debug Info (v{debugInfo.version})
                  </span>
                  {showDebug ? (
                    <ChevronUp className="w-4 h-4" />
                  ) : (
                    <ChevronDown className="w-4 h-4" />
                  )}
                </Button>

                {showDebug && (
                  <div className="mt-2 p-3 rounded bg-muted text-xs font-mono overflow-auto max-h-[300px]">
                    <p className="text-muted-foreground mb-2">
                      Calculated: {new Date(debugInfo.calculated_at).toLocaleString()}
                    </p>
                    <pre>{JSON.stringify(debugInfo, null, 2)}</pre>
                  </div>
                )}
              </div>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
