import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useToast } from "@/hooks/use-toast";
import { TrendingUp, Users, DollarSign, Clock, Target, Award } from "lucide-react";

export const PerformanceDashboard = () => {
  const [stats, setStats] = useState<any>({
    totalApplications: 0,
    totalFunded: 0,
    totalRevenue: 0,
    avgProcessingTime: 0,
    conversionRate: 0,
    workerStats: [],
    monthlyTrends: [],
  });
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  useEffect(() => {
    fetchPerformanceData();
  }, []);

  const fetchPerformanceData = async () => {
    try {
      // Total applications
      const { count: fastTrackCount } = await supabase
        .from('fast_track_applications')
        .select('*', { count: 'exact', head: true });

      const { count: loanCount } = await supabase
        .from('loan_applications')
        .select('*', { count: 'exact', head: true });

      // Funded contracts
      const { data: fundedContracts, error: fundedError } = await supabase
        .from('funded_contracts')
        .select('funding_amount, created_at, application_id, application_type');

      if (fundedError) throw fundedError;

      const totalFunded = fundedContracts?.length || 0;
      const totalRevenue = fundedContracts?.reduce((sum, c) => sum + Number(c.funding_amount), 0) || 0;
      const conversionRate = ((fastTrackCount || 0) + (loanCount || 0)) > 0 
        ? (totalFunded / ((fastTrackCount || 0) + (loanCount || 0))) * 100 
        : 0;

      // Worker performance
      const { data: workers } = await supabase
        .from('user_roles')
        .select('user_id')
        .eq('role', 'worker')
        .eq('approved', true);

      const workerStats = await Promise.all((workers || []).map(async (worker) => {
        const { count: appCount } = await supabase
          .from('fast_track_applications')
          .select('*', { count: 'exact', head: true })
          .eq('user_id', worker.user_id);

        const { count: intakeCount } = await supabase
          .from('intake_logs')
          .select('*', { count: 'exact', head: true })
          .eq('worker_id', worker.user_id);

        const workerFunded = fundedContracts?.filter(
          c => c.application_type === 'fast_track'
        ) || [];

        return {
          worker_id: worker.user_id,
          applications: appCount || 0,
          intakes: intakeCount || 0,
          funded: workerFunded.length,
          revenue: workerFunded.reduce((sum, c) => sum + Number(c.funding_amount), 0),
        };
      }));

      // Monthly trends (last 6 months)
      const monthlyTrends = Array.from({ length: 6 }, (_, i) => {
        const date = new Date();
        date.setMonth(date.getMonth() - i);
        const monthStart = new Date(date.getFullYear(), date.getMonth(), 1).toISOString();
        const monthEnd = new Date(date.getFullYear(), date.getMonth() + 1, 0).toISOString();

        const monthFunded = fundedContracts?.filter(
          c => c.created_at >= monthStart && c.created_at <= monthEnd
        ) || [];

        return {
          month: date.toLocaleDateString('en-US', { month: 'short', year: 'numeric' }),
          applications: 0, // Would need to query each table with date filter
          funded: monthFunded.length,
          revenue: monthFunded.reduce((sum, c) => sum + Number(c.funding_amount), 0),
        };
      }).reverse();

      setStats({
        totalApplications: (fastTrackCount || 0) + (loanCount || 0),
        totalFunded,
        totalRevenue,
        avgProcessingTime: 3.5, // Mock data - would need timestamp tracking
        conversionRate,
        workerStats: workerStats.sort((a, b) => b.revenue - a.revenue),
        monthlyTrends,
      });
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return <div className="text-center py-8">Loading performance data...</div>;
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold">Performance Dashboard</h2>
        <p className="text-sm text-muted-foreground">Key performance indicators and metrics</p>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex flex-col items-center text-center">
              <Users className="w-8 h-8 text-blue-500 mb-2" />
              <p className="text-sm text-muted-foreground">Total Applications</p>
              <p className="text-2xl font-bold">{stats.totalApplications}</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex flex-col items-center text-center">
              <Target className="w-8 h-8 text-green-500 mb-2" />
              <p className="text-sm text-muted-foreground">Funded</p>
              <p className="text-2xl font-bold">{stats.totalFunded}</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex flex-col items-center text-center">
              <DollarSign className="w-8 h-8 text-primary mb-2" />
              <p className="text-sm text-muted-foreground">Total Revenue</p>
              <p className="text-2xl font-bold">${(stats.totalRevenue / 1000000).toFixed(1)}M</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex flex-col items-center text-center">
              <TrendingUp className="w-8 h-8 text-purple-500 mb-2" />
              <p className="text-sm text-muted-foreground">Conversion Rate</p>
              <p className="text-2xl font-bold">{stats.conversionRate.toFixed(1)}%</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex flex-col items-center text-center">
              <Clock className="w-8 h-8 text-yellow-500 mb-2" />
              <p className="text-sm text-muted-foreground">Avg Processing</p>
              <p className="text-2xl font-bold">{stats.avgProcessingTime} days</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex flex-col items-center text-center">
              <Award className="w-8 h-8 text-orange-500 mb-2" />
              <p className="text-sm text-muted-foreground">Active Workers</p>
              <p className="text-2xl font-bold">{stats.workerStats.length}</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Worker Leaderboard */}
      <Card>
        <CardHeader>
          <CardTitle>Worker Performance Leaderboard</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Rank</TableHead>
                <TableHead>Worker ID</TableHead>
                <TableHead>Applications</TableHead>
                <TableHead>Intakes</TableHead>
                <TableHead>Funded</TableHead>
                <TableHead>Total Revenue</TableHead>
                <TableHead>Performance</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {stats.workerStats.map((worker: any, index: number) => (
                <TableRow key={worker.worker_id}>
                  <TableCell>
                    <Badge className={index === 0 ? 'bg-yellow-500' : index === 1 ? 'bg-gray-400' : index === 2 ? 'bg-orange-600' : 'bg-gray-600'}>
                      #{index + 1}
                    </Badge>
                  </TableCell>
                  <TableCell className="font-mono text-xs">{worker.worker_id.slice(0, 8)}...</TableCell>
                  <TableCell>{worker.applications}</TableCell>
                  <TableCell>{worker.intakes}</TableCell>
                  <TableCell>{worker.funded}</TableCell>
                  <TableCell className="font-bold text-primary">${worker.revenue.toLocaleString()}</TableCell>
                  <TableCell>
                    <Badge className={worker.funded > 10 ? 'bg-green-500' : worker.funded > 5 ? 'bg-blue-500' : 'bg-gray-500'}>
                      {worker.funded > 10 ? 'Excellent' : worker.funded > 5 ? 'Good' : 'Fair'}
                    </Badge>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Monthly Trends */}
      <Card>
        <CardHeader>
          <CardTitle>Monthly Trends (Last 6 Months)</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Month</TableHead>
                <TableHead>Funded</TableHead>
                <TableHead>Revenue</TableHead>
                <TableHead>Trend</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {stats.monthlyTrends.map((trend: any, index: number) => {
                const prevRevenue = index > 0 ? stats.monthlyTrends[index - 1].revenue : trend.revenue;
                const change = prevRevenue > 0 ? ((trend.revenue - prevRevenue) / prevRevenue) * 100 : 0;
                
                return (
                  <TableRow key={trend.month}>
                    <TableCell className="font-medium">{trend.month}</TableCell>
                    <TableCell>{trend.funded}</TableCell>
                    <TableCell className="font-bold">${trend.revenue.toLocaleString()}</TableCell>
                    <TableCell>
                      <Badge className={change >= 0 ? 'bg-green-500' : 'bg-red-500'}>
                        {change >= 0 ? '↑' : '↓'} {Math.abs(change).toFixed(1)}%
                      </Badge>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
};
