import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { Plus, Edit, Trash2, Save, X, Eye, Printer } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import DOMPurify from "dompurify";

interface EmailTemplate {
  id: string;
  name: string;
  template_type: string;
  subject: string;
  body: string;
  is_default: boolean;
  created_at: string;
}

export const EmailTemplateManagement = () => {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isCreating, setIsCreating] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [previewTemplate, setPreviewTemplate] = useState<EmailTemplate | null>(null);
  const [formData, setFormData] = useState({
    name: "",
    template_type: "ai_outreach",
    subject: "",
    body: "",
  });

  const { data: templates, isLoading } = useQuery({
    queryKey: ["email-templates"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("email_templates")
        .select("*")
        .order("created_at", { ascending: false });
      
      if (error) throw error;
      return data as EmailTemplate[];
    },
  });

  const createMutation = useMutation({
    mutationFn: async (data: typeof formData) => {
      const { error } = await supabase.from("email_templates").insert(data);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["email-templates"] });
      toast({ title: "Template created successfully" });
      resetForm();
    },
    onError: () => toast({ variant: "destructive", title: "Failed to create template" }),
  });

  const updateMutation = useMutation({
    mutationFn: async ({ id, data }: { id: string; data: typeof formData }) => {
      const { error } = await supabase
        .from("email_templates")
        .update(data)
        .eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["email-templates"] });
      toast({ title: "Template updated successfully" });
      setEditingId(null);
      resetForm();
    },
    onError: () => toast({ variant: "destructive", title: "Failed to update template" }),
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("email_templates").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["email-templates"] });
      toast({ title: "Template deleted successfully" });
    },
    onError: () => toast({ variant: "destructive", title: "Failed to delete template" }),
  });

  const resetForm = () => {
    setFormData({ name: "", template_type: "ai_outreach", subject: "", body: "" });
    setIsCreating(false);
    setEditingId(null);
  };

  const handleEdit = (template: EmailTemplate) => {
    setFormData({
      name: template.name,
      template_type: template.template_type,
      subject: template.subject,
      body: template.body,
    });
    setEditingId(template.id);
    setIsCreating(false);
  };

  const handleSubmit = () => {
    if (!formData.name || !formData.subject || !formData.body) {
      toast({ variant: "destructive", title: "Please fill in all fields" });
      return;
    }

    if (editingId) {
      updateMutation.mutate({ id: editingId, data: formData });
    } else {
      createMutation.mutate(formData);
    }
  };

  const getTypeLabel = (type: string) => {
    const labels: Record<string, string> = {
      iso_approval: "ISO Approval",
      credit_repair: "Credit Repair",
      funder_notification: "Funder Notification",
      ai_outreach: "AI Outreach",
      reminder: "Reminder",
    };
    return labels[type] || type;
  };

  const handlePrint = (template: EmailTemplate) => {
    const printWindow = window.open('', '', 'width=900,height=700');
    if (!printWindow) return;
    
    printWindow.document.write(`
      <!DOCTYPE html>
      <html>
        <head>
          <title>${template.name} - Wolf Fund Corp™</title>
          <style>
            * { margin: 0; padding: 0; box-sizing: border-box; }
            body { 
              font-family: 'Inter', Arial, sans-serif; 
              padding: 40px; 
              background: #fff;
              color: #1D1E1F;
              line-height: 1.6;
            }
            .letterhead {
              border-bottom: 3px solid #1D1E1F;
              padding-bottom: 15px;
              margin-bottom: 30px;
            }
            .letterhead h1 {
              font-size: 20px;
              font-weight: 700;
              margin-bottom: 5px;
              color: #1D1E1F;
            }
            .letterhead p {
              font-size: 12px;
              color: #666;
            }
            .meta { 
              background: #f8f9fa;
              padding: 12px;
              border-radius: 6px;
              margin-bottom: 20px;
              font-size: 13px;
            }
            .meta strong { color: #1D1E1F; }
            .subject { 
              font-weight: 600;
              font-size: 15px;
              margin-bottom: 20px;
              color: #1D1E1F;
            }
            .body { 
              font-size: 14px;
              line-height: 1.8;
            }
            .body h2 {
              font-size: 16px;
              margin-top: 25px;
              margin-bottom: 10px;
              font-weight: 600;
              color: #1D1E1F;
            }
            .body table {
              width: 100%;
              border-collapse: collapse;
              margin: 15px 0;
            }
            .body table th,
            .body table td {
              border: 1px solid #ddd;
              padding: 8px;
              text-align: left;
              font-size: 13px;
            }
            .body table th {
              background: #f0f0f0;
              font-weight: 600;
            }
            .footer {
              margin-top: 40px;
              padding-top: 15px;
              border-top: 2px solid #e0e0e0;
              font-size: 11px;
              color: #666;
              text-align: center;
            }
            @media print {
              body { padding: 20px; }
              .no-print { display: none; }
            }
          </style>
        </head>
        <body>
          <div class="letterhead">
            <h1>WOLF FUND CORP™ | Credit Fix Back Office™</h1>
            <p>123 Main Ave, Suite 200, Huntington, NY 11746 | Tel: (631) XXX-XXXX | compliance@wolf-fund.com</p>
          </div>
          
          <div class="meta">
            <strong>Template:</strong> ${template.name}<br>
            <strong>Type:</strong> ${getTypeLabel(template.template_type)}<br>
            <strong>Generated:</strong> ${new Date().toLocaleDateString()}
          </div>
          
          <div class="subject">
            <strong>Subject:</strong> ${template.subject}
          </div>
          
          <div class="body">
            ${template.body}
          </div>
          
          <div class="footer">
            Wolf Fund Corp™ – Credit Fix Back Office™ | Confidential<br>
            Document Reference: WF-TEMPLATE-${template.id.substring(0, 8).toUpperCase()}
          </div>
        </body>
      </html>
    `);
    printWindow.document.close();
    printWindow.focus();
    setTimeout(() => {
      printWindow.print();
      printWindow.close();
    }, 250);
  };

  if (isLoading) return <div>Loading templates...</div>;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">Email Templates</h2>
          <p className="text-muted-foreground">Professional compliance-grade templates with Wolf Fund branding</p>
        </div>
        {!isCreating && !editingId && (
          <Button onClick={() => setIsCreating(true)}>
            <Plus className="h-4 w-4 mr-2" />
            New Template
          </Button>
        )}
      </div>

      {!isCreating && !editingId && (
        <Card className="bg-muted/30 border-primary/20">
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              📋 Professional Template Guidelines
            </CardTitle>
          </CardHeader>
          <CardContent className="text-sm space-y-2">
            <p className="font-medium">All templates must include:</p>
            <ul className="list-disc list-inside space-y-1 text-muted-foreground">
              <li>Wolf Fund Corp™ letterhead with full address and contact info</li>
              <li>Document reference ID (WF-CFB-{'{case_id}'})</li>
              <li>Structured sections with clear headers (H2 tags)</li>
              <li>Compliance tables for dispute letters (FCRA/Metro 2/FDCPA)</li>
              <li>Professional signature block with client name</li>
              <li>Footer with "Wolf Fund Corp™ – Credit Fix Back Office™ | Confidential"</li>
            </ul>
            <p className="text-xs mt-3 pt-3 border-t">
              💡 <strong>Tip:</strong> Use the placeholder example in the form below as your starting point.
            </p>
          </CardContent>
        </Card>
      )}

      {(isCreating || editingId) && (
        <Card>
          <CardHeader>
            <CardTitle>{editingId ? "Edit Template" : "Create New Template"}</CardTitle>
            <CardDescription>
              Use placeholders like {`{{client_name}}`}, {`{{business_name}}`}, {`{{funding_amount}}`}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label>Template Name</Label>
              <Input
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                placeholder="e.g., Bureau Dispute Letter - FCRA Verification"
              />
            </div>

            <div>
              <Label>Template Type</Label>
              <Select
                value={formData.template_type}
                onValueChange={(value) => setFormData({ ...formData, template_type: value })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="iso_approval">ISO Approval</SelectItem>
                  <SelectItem value="credit_repair">Credit Repair Dispute</SelectItem>
                  <SelectItem value="funder_notification">Funder Submission</SelectItem>
                  <SelectItem value="ai_outreach">AI Outreach</SelectItem>
                  <SelectItem value="reminder">Follow-Up Reminder</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label>Subject Line</Label>
              <Input
                value={formData.subject}
                onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                placeholder="e.g., FORMAL DISPUTE REQUEST – Account Verification"
              />
            </div>

            <div>
              <Label>Email Body (Structured HTML)</Label>
              <div className="text-xs text-muted-foreground mb-2 p-3 bg-muted/50 rounded border">
                <strong>Professional Format Required:</strong> Include Wolf Fund letterhead, section headers, compliance tables, and signature blocks.
                <br />Use placeholders: {`{{client_name}}, {{account_number}}, {{fcra_section}}, {{metro2_code}}`}
              </div>
              <Textarea
                value={formData.body}
                onChange={(e) => setFormData({ ...formData, body: e.target.value })}
                placeholder={`<div style="font-family: Arial, sans-serif; max-width: 800px; margin: 0 auto; padding: 20px;">
  <div style="border-bottom: 2px solid #333; padding-bottom: 10px; margin-bottom: 20px;">
    <h1 style="margin: 0; color: #1D1E1F;">WOLF FUND CORP™ | Credit Fix Back Office™</h1>
    <p style="margin: 5px 0; font-size: 14px;">123 Main Ave, Suite 200, Huntington, NY 11746</p>
  </div>
  
  <p><strong>DATE:</strong> {{today_date}}<br><strong>REF:</strong> WF-CFB-{{case_id}}</p>
  
  <h2>ACCOUNT INFORMATION</h2>
  <p><strong>Creditor:</strong> {{creditor_name}}<br><strong>Account:</strong> {{account_number}}</p>
  
  <h2>DISPUTE BASIS</h2>
  <p>{{dispute_reason}}</p>
  
  <p>Sincerely,<br>{{client_name}}</p>
  
  <div style="border-top: 1px solid #ccc; margin-top: 30px; padding-top: 10px; font-size: 12px; color: #666;">
    Wolf Fund Corp™ – Credit Fix Back Office™ | Confidential
  </div>
</div>`}
                rows={16}
                className="font-mono text-xs"
              />
            </div>

            <div className="flex gap-2">
              <Button onClick={handleSubmit}>
                <Save className="h-4 w-4 mr-2" />
                {editingId ? "Update" : "Create"}
              </Button>
              <Button variant="outline" onClick={resetForm}>
                <X className="h-4 w-4 mr-2" />
                Cancel
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      <div className="grid gap-4">
        {templates?.map((template) => (
          <Card key={template.id}>
            <CardHeader>
              <div className="flex items-start justify-between">
                <div>
                  <CardTitle className="flex items-center gap-2">
                    {template.name}
                    {template.is_default && (
                      <Badge variant="secondary">Default</Badge>
                    )}
                  </CardTitle>
                  <CardDescription>
                    <Badge variant="outline" className="mt-1">
                      {getTypeLabel(template.template_type)}
                    </Badge>
                  </CardDescription>
                </div>
                <div className="flex gap-2">
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => setPreviewTemplate(template)}
                  >
                    <Eye className="h-4 w-4" />
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => handlePrint(template)}
                  >
                    <Printer className="h-4 w-4" />
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => handleEdit(template)}
                  >
                    <Edit className="h-4 w-4" />
                  </Button>
                  {!template.is_default && (
                    <Button
                      size="sm"
                      variant="destructive"
                      onClick={() => deleteMutation.mutate(template.id)}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  )}
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-2 text-sm">
                <div>
                  <strong>Subject:</strong> {template.subject}
                </div>
                <div>
                  <strong>Body Preview:</strong>
                  <pre className="mt-1 p-2 bg-muted rounded text-xs overflow-x-auto max-h-32">
                    {template.body.substring(0, 300)}
                    {template.body.length > 300 && "..."}
                  </pre>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Dialog open={!!previewTemplate} onOpenChange={() => setPreviewTemplate(null)}>
        <DialogContent className="max-w-4xl max-h-[85vh] overflow-hidden flex flex-col">
          <DialogHeader>
            <DialogTitle className="text-xl font-bold">{previewTemplate?.name}</DialogTitle>
            <DialogDescription className="flex items-center gap-2">
              <Badge variant="outline" className="mt-1">
                {previewTemplate && getTypeLabel(previewTemplate.template_type)}
              </Badge>
              <span className="text-xs text-muted-foreground">• Document Preview</span>
            </DialogDescription>
          </DialogHeader>
          {previewTemplate && (
            <div className="flex-1 overflow-y-auto">
              <div className="bg-muted/30 p-4 rounded-lg mb-4 border">
                <strong className="text-sm font-semibold text-foreground">Subject Line:</strong>
                <p className="mt-1 text-sm text-muted-foreground font-medium">{previewTemplate.subject}</p>
              </div>
              
              <div className="bg-white border-2 border-border shadow-lg rounded-lg p-8 mx-auto" style={{ maxWidth: '850px' }}>
                <div 
                  className="prose prose-sm max-w-none"
                  style={{ 
                    fontFamily: 'Inter, system-ui, sans-serif',
                    fontSize: '14px',
                    lineHeight: '1.6',
                    color: '#1D1E1F'
                  }}
                  dangerouslySetInnerHTML={{ __html: DOMPurify.sanitize(previewTemplate.body) }}
                />
              </div>
              
              <div className="mt-4 text-xs text-center text-muted-foreground">
                This is a preview. Actual emails will render with placeholders replaced.
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
};
