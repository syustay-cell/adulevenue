import { useEffect, useState, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';

type ActivityFilters = {
  eventType: 'all' | 'funding' | 'credit_repair' | 'lead' | 'permission';
  decisionType: 'all' | 'approved' | 'denied' | 'pending';
};

interface ActivityItem {
  id: string;
  created_at: string;
  event_type: string;
  actor_email: string | null;
  actor_role: string | null;
  target_email: string | null;
  decision: string | null;
  summary: string;
  context_type: string | null;
  context_id: string | null;
}

const decisionColors: Record<string, string> = {
  approved: 'bg-emerald-100 text-emerald-700',
  denied: 'bg-rose-100 text-rose-700',
  pending: 'bg-amber-100 text-amber-700',
};

async function fetchActivity(filters: ActivityFilters) {
  let query = supabase
    .from('activity_feed')
    .select('id, created_at, event_type, actor_email, actor_role, target_email, decision, summary, context_type, context_id')
    .order('created_at', { ascending: false })
    .limit(100);

  // Map filter values to database values
  if (filters.eventType !== 'all') {
    // Map UI filter values to database event_type values
    const eventTypeMap: Record<string, string> = {
      funding: 'status_change',
      credit_repair: 'credit_case_update',
      lead: 'call_log',
      permission: 'permission_decision',
    };
    query = query.eq('event_type', eventTypeMap[filters.eventType] || filters.eventType);
  }
  
  if (filters.decisionType !== 'all') {
    query = query.eq('decision', filters.decisionType);
  }

  const { data, error } = await query;
  if (error) throw error;
  return data;
}

interface AdminActivityFeedProps {
  onOpenApplication?: (applicationId: string) => void;
}

export function AdminActivityFeed({ onOpenApplication }: AdminActivityFeedProps) {
  const [events, setEvents] = useState<ActivityItem[]>([]);
  const [loading, setLoading] = useState(false);
  const [isExpanded, setIsExpanded] = useState(false);
  const [filters, setFilters] = useState<ActivityFilters>({
    eventType: 'all',
    decisionType: 'all',
  });

  const handleRowClick = (event: ActivityItem) => {
    if (!event.context_id || !event.context_type) return;

    switch (event.context_type) {
      case 'funding_case':
      case 'application':
        // Open application details dialog
        if (onOpenApplication) {
          onOpenApplication(event.context_id);
        }
        break;
      
      case 'credit_case':
        // Navigate to credit specialist dashboard with case
        window.location.href = `/credit-specialist-dashboard?caseId=${event.context_id}`;
        break;
      
      case 'lead':
        // Navigate to lead gen dashboard with lead
        window.location.href = `/lead-gen-dashboard?leadId=${event.context_id}`;
        break;
      
      case 'user':
        // Could scroll to users section or show user details
        // For now, just log it
        console.log('Navigate to user:', event.context_id);
        break;
    }
  };

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const data = await fetchActivity(filters);
      setEvents(data ?? []);
    } catch (e) {
      console.error('Failed to load activity', e);
    } finally {
      setLoading(false);
    }
  }, [filters]);

  useEffect(() => {
    load();

    // Realtime subscription
    const channel = supabase
      .channel('activity-feed')
      .on(
        'postgres_changes',
        { event: 'INSERT', schema: 'public', table: 'activity_feed' },
        (payload) => {
          setEvents((prev) => [payload.new as ActivityItem, ...prev].slice(0, 100));
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [load]);

  return (
    <section className="mb-8 rounded-2xl bg-white p-4 shadow-sm sm:p-6">
      <div className="flex flex-col justify-between gap-3 sm:flex-row sm:items-center">
        <button 
          onClick={() => setIsExpanded(!isExpanded)}
          className="flex w-full items-center justify-between text-left sm:w-auto sm:cursor-default"
        >
          <div>
            <h2 className="text-sm font-semibold text-slate-900">
              Live Activity Command Center
            </h2>
            <p className="text-xs text-slate-500">
              Real-time events from funding, credit repair, leads & permissions.
            </p>
          </div>
          <span className="ml-2 text-slate-400 sm:hidden">
            {isExpanded ? '▼' : '▶'}
          </span>
        </button>

        {(isExpanded || (typeof window !== 'undefined' && window.innerWidth >= 768)) && (
          <div className="flex flex-wrap items-center gap-2">
            {/* Event type filter */}
            <select
              className="rounded-lg border border-slate-200 bg-slate-50 px-3 py-1.5 text-xs text-slate-700"
              value={filters.eventType}
              onChange={(e) =>
                setFilters((f) => ({ ...f, eventType: e.target.value as any }))
              }
            >
              <option value="all">All Events</option>
              <option value="funding">Funding</option>
              <option value="credit_repair">Credit Repair</option>
              <option value="lead">Leads</option>
              <option value="permission">Permissions</option>
            </select>

            {/* Decision filter */}
            <select
              className="rounded-lg border border-slate-200 bg-slate-50 px-3 py-1.5 text-xs text-slate-700"
              value={filters.decisionType}
              onChange={(e) =>
                setFilters((f) => ({ ...f, decisionType: e.target.value as any }))
              }
            >
              <option value="all">All Decisions</option>
              <option value="approved">Approved</option>
              <option value="denied">Denied</option>
              <option value="pending">Pending</option>
            </select>

            {/* Refresh button */}
            <button
              type="button"
              onClick={load}
              className="inline-flex items-center gap-1 rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50"
            >
              <svg
                className={`h-3.5 w-3.5 ${loading ? 'animate-spin' : ''}`}
                viewBox="0 0 20 20"
                fill="none"
              >
                <path
                  d="M4 4v4h4M16 16v-4h-4M5 11a5 5 0 0 0 8.66 3.54M15 9a5 5 0 0 0-8.66-3.54"
                  stroke="currentColor"
                  strokeWidth="1.5"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              </svg>
              Refresh
            </button>
          </div>
        )}
      </div>

      {(isExpanded || (typeof window !== 'undefined' && window.innerWidth >= 768)) && (
        <div className="mt-3 border-t border-slate-100 pt-3">
          {events.length === 0 ? (
            <p className="py-4 text-center text-xs text-slate-400">
              No recent activity yet. Events will appear here in real-time as they
              happen.
            </p>
          ) : (
            <div className="max-h-64 sm:max-h-80 overflow-y-auto pr-1">
              <ul className="space-y-2">
            {events.map((event) => {
              const decisionClass =
                (event.decision &&
                  decisionColors[event.decision]) ||
                'bg-slate-100 text-slate-600';

              const isClickable = event.context_id && event.context_type;
              
              return (
                <li
                  key={event.id}
                  onClick={() => handleRowClick(event)}
                  className={`flex flex-col gap-1 rounded-xl border border-slate-100 bg-slate-50 px-3 py-2 text-xs text-slate-700 sm:flex-row sm:items-center sm:justify-between transition-colors ${
                    isClickable ? 'cursor-pointer hover:bg-slate-100 hover:border-slate-200' : ''
                  }`}
                >
                  <div className="space-y-0.5">
                    <div className="flex flex-wrap items-center gap-1.5">
                      <span className="font-medium">
                        {event.actor_email || 'Unknown user'}
                      </span>
                      {event.actor_role && (
                        <span className="rounded-full bg-slate-200 px-2 py-0.5 text-[10px] uppercase tracking-wide text-slate-700">
                          {event.actor_role}
                        </span>
                      )}
                      {event.target_email && (
                        <span className="text-[11px] text-slate-500">
                          → {event.target_email}
                        </span>
                      )}
                    </div>
                    <div className="text-[11px] text-slate-600">
                      {event.summary}
                    </div>
                  </div>

                  <div className="flex flex-wrap items-center gap-2 pt-1 sm:pt-0">
                    <span className="text-[10px] text-slate-400">
                      {new Date(event.created_at).toLocaleString()}
                    </span>
                    <span
                      className={`rounded-full px-2 py-0.5 text-[10px] font-medium ${decisionClass}`}
                    >
                      {event.decision
                        ? event.decision.toUpperCase()
                        : 'INFO'}
                    </span>
                  </div>
                </li>
              );
            })}
              </ul>
            </div>
          )}
        </div>
      )}
    </section>
  );
}
