import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { Loader2 } from "lucide-react";

type ApplicationActionsCardProps = {
  applicationId: string;
  applicationType: string;
  clientEmail: string;
  currentStatus: string;
  onSuccess?: () => void;
};

export const ApplicationActionsCard = ({
  applicationId,
  applicationType,
  clientEmail,
  currentStatus,
  onSuccess,
}: ApplicationActionsCardProps) => {
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  const handleMoveToCreditRepair = async () => {
    setLoading(true);
    try {
      // Get user details first
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        toast({
          title: "Error",
          description: "You must be logged in to perform this action.",
          variant: "destructive",
        });
        return;
      }

      // Get application details based on type
      let appData: any = null;
      
      if (applicationType === 'fast_track') {
        const { data, error } = await supabase
          .from('fast_track_applications')
          .select('email, phone, business_name, user_id')
          .eq('id', applicationId)
          .single();
        if (error) {
          console.error('Error fetching fast_track application:', error);
          toast({
            title: "Error",
            description: "Could not find application details.",
            variant: "destructive",
          });
          return;
        }
        appData = data;
      } else if (applicationType === 'loan_application') {
        const { data, error } = await supabase
          .from('loan_applications')
          .select('email, phone, business_name, user_id')
          .eq('id', applicationId)
          .single();
        if (error) {
          console.error('Error fetching loan application:', error);
          toast({
            title: "Error",
            description: "Could not find application details.",
            variant: "destructive",
          });
          return;
        }
        appData = data;
      } else if (applicationType === 'credit_repair') {
        const { data, error } = await supabase
          .from('credit_repair_applications')
          .select('email, phone, full_name, user_id')
          .eq('id', applicationId)
          .single();
        if (error) {
          console.error('Error fetching credit_repair application:', error);
          toast({
            title: "Error",
            description: "Could not find application details.",
            variant: "destructive",
          });
          return;
        }
        appData = data;
      }

      if (!appData) {
        toast({
          title: "Error",
          description: "Invalid application type.",
          variant: "destructive",
        });
        return;
      }

      const name = appData.business_name || appData.full_name || 'Client';

      const { data, error } = await supabase.functions.invoke('move-to-credit-repair', {
        body: {
          applicationId,
          applicationType,
          userId: appData.user_id || user.id,
          email: appData.email || clientEmail,
          name,
          phone: appData.phone || ''
        }
      });

      if (error) {
        console.error('Error moving to credit repair:', error);
        toast({
          title: "Error",
          description: "Failed to move application to Credit Repair. Please try again.",
          variant: "destructive",
        });
        return;
      }

      const result = data as { success: boolean; caseId: string; message: string } | null;
      
      toast({
        title: "Success",
        description: result?.message || "Application moved to Credit Repair ✍🏼 workflow",
      });
      
      if (onSuccess) {
        onSuccess();
      }
    } catch (err) {
      console.error('Unexpected error:', err);
      toast({
        title: "Error",
        description: "An unexpected error occurred. Please try again.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="rounded-2xl border border-border bg-card p-4 shadow-sm">
      <div className="mb-3">
        <h3 className="text-sm font-semibold text-foreground mb-1">
          Application Actions
        </h3>
        <p className="text-xs text-muted-foreground">
          Manage this application's workflow and status
        </p>
      </div>

      <div className="flex flex-wrap gap-2">
        <button
          type="button"
          onClick={handleMoveToCreditRepair}
          disabled={loading || currentStatus === 'moved_to_credit_repair'}
          className="inline-flex items-center gap-2 rounded-lg bg-emerald-600 px-4 py-2 text-sm font-medium text-white shadow-sm transition-colors hover:bg-emerald-700 disabled:opacity-60 disabled:cursor-not-allowed"
        >
          {loading && <Loader2 className="h-4 w-4 animate-spin" />}
          {currentStatus === 'moved_to_credit_repair' ? 'In Credit Repair ✅' : 'Send to Credit Repair ✍🏼'}
        </button>
      </div>
    </div>
  );
};
