import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Search, Download } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export const AuditLogs = () => {
  const [logs, setLogs] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const { toast } = useToast();

  useEffect(() => {
    fetchLogs();
  }, []);

  const fetchLogs = async () => {
    try {
      const { data, error } = await supabase
        .from('audit_logs')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(100);

      if (error) throw error;
      setLogs(data || []);
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const exportLogs = () => {
    const csv = [
      ['Timestamp', 'User ID', 'Action', 'Resource Type', 'Resource ID', 'IP Address'].join(','),
      ...filteredLogs.map(log => [
        new Date(log.created_at).toISOString(),
        log.user_id,
        log.action_type,
        log.resource_type,
        log.resource_id,
        log.ip_address || 'N/A'
      ].join(','))
    ].join('\n');

    const blob = new Blob([csv], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `audit-logs-${new Date().toISOString()}.csv`;
    a.click();

    toast({
      title: "Export Complete",
      description: "Audit logs exported successfully",
    });
  };

  const getActionBadge = (action: string) => {
    const colors: Record<string, string> = {
      view: 'bg-blue-500',
      create: 'bg-green-500',
      update: 'bg-yellow-500',
      delete: 'bg-red-500',
      export: 'bg-purple-500',
      approve: 'bg-green-600',
      reject: 'bg-red-600',
      send: 'bg-blue-600',
      sign: 'bg-purple-600'
    };
    return <Badge className={colors[action] || 'bg-gray-500'}>{action.toUpperCase()}</Badge>;
  };

  const filteredLogs = logs.filter(log => 
    searchQuery === '' || 
    log.user_id.includes(searchQuery) ||
    log.action_type.includes(searchQuery) ||
    log.resource_type.includes(searchQuery) ||
    log.resource_id.includes(searchQuery)
  );

  if (loading) {
    return <div className="text-center py-8">Loading audit logs...</div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">Audit & Compliance Logs</h2>
          <p className="text-sm text-muted-foreground">Complete action history for regulatory compliance</p>
        </div>
        <Button onClick={exportLogs} className="gap-2">
          <Download className="w-4 h-4" />
          Export CSV
        </Button>
      </div>

      <Card>
        <CardHeader>
          <div className="flex items-center gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
              <Input
                placeholder="Search logs by user, action, resource..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Timestamp</TableHead>
                  <TableHead>User ID</TableHead>
                  <TableHead>Action</TableHead>
                  <TableHead>Resource</TableHead>
                  <TableHead>Resource ID</TableHead>
                  <TableHead>IP Address</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredLogs.map((log) => (
                  <TableRow key={log.id}>
                    <TableCell className="text-xs">
                      {new Date(log.created_at).toLocaleString()}
                    </TableCell>
                    <TableCell className="text-xs font-mono">
                      {log.user_id.slice(0, 8)}...
                    </TableCell>
                    <TableCell>{getActionBadge(log.action_type)}</TableCell>
                    <TableCell>
                      <Badge variant="outline">{log.resource_type}</Badge>
                    </TableCell>
                    <TableCell className="text-xs font-mono">
                      {log.resource_id.slice(0, 8)}...
                    </TableCell>
                    <TableCell className="text-xs">{log.ip_address || 'N/A'}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
          {filteredLogs.length === 0 && (
            <div className="text-center py-8 text-muted-foreground">
              No audit logs found matching your search criteria
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Compliance Summary</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="text-center">
              <p className="text-2xl font-bold">{logs.length}</p>
              <p className="text-sm text-muted-foreground">Total Actions</p>
            </div>
            <div className="text-center">
              <p className="text-2xl font-bold">{logs.filter(l => l.action_type === 'view').length}</p>
              <p className="text-sm text-muted-foreground">Data Access Events</p>
            </div>
            <div className="text-center">
              <p className="text-2xl font-bold">{logs.filter(l => ['create', 'update', 'delete'].includes(l.action_type)).length}</p>
              <p className="text-sm text-muted-foreground">Modifications</p>
            </div>
            <div className="text-center">
              <p className="text-2xl font-bold">{logs.filter(l => l.action_type === 'export').length}</p>
              <p className="text-sm text-muted-foreground">Export Events</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};