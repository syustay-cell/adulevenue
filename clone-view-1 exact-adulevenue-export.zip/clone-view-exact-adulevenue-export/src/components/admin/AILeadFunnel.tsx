import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { TrendingUp, Phone, Mail, Search, Sparkles, ArrowRight } from "lucide-react";

interface LeadFunnelStats {
  total_leads: number;
  dialer_leads: number;
  email_leads: number;
  research_leads: number;
  funding_first: number;
  credit_first: number;
  hybrid_path: number;
  do_not_work: number;
}

export const AILeadFunnel = () => {
  const navigate = useNavigate();
  const [stats, setStats] = useState<LeadFunnelStats>({
    total_leads: 0,
    dialer_leads: 0,
    email_leads: 0,
    research_leads: 0,
    funding_first: 0,
    credit_first: 0,
    hybrid_path: 0,
    do_not_work: 0,
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadStats();
  }, []);

  const loadStats = async () => {
    try {
      const { data: leads, error } = await supabase
        .from('leads')
        .select('route, research_status, ai_recommended_path, status');

      if (error) throw error;

      const newStats: LeadFunnelStats = {
        total_leads: leads?.length || 0,
        dialer_leads: leads?.filter(l => l.route === 'dialer').length || 0,
        email_leads: leads?.filter(l => l.route === 'email').length || 0,
        research_leads: leads?.filter(l => 
          l.route === 'research' && 
          (l.research_status === 'new' || l.research_status === 'in_progress')
        ).length || 0,
        funding_first: leads?.filter(l => l.ai_recommended_path === 'fast_track_funding').length || 0,
        credit_first: leads?.filter(l => l.ai_recommended_path === 'credit_fix_first').length || 0,
        hybrid_path: leads?.filter(l => l.ai_recommended_path === 'hybrid_path').length || 0,
        do_not_work: leads?.filter(l => l.ai_recommended_path === 'do_not_work').length || 0,
      };

      setStats(newStats);
    } catch (err) {
      console.error('Failed to load lead funnel stats:', err);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Sparkles className="h-5 w-5 text-primary" />
            AI Lead Funnel
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8 text-muted-foreground">Loading...</div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Sparkles className="h-5 w-5 text-primary" />
          AI Lead Funnel Overview
        </CardTitle>
        <CardDescription>
          Live overview of AI-classified leads by route and recommendation
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Route Distribution */}
        <div>
          <h4 className="text-sm font-semibold mb-3 text-foreground">Lead Routes</h4>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            <div className="text-center p-3 rounded-lg border bg-muted/50">
              <TrendingUp className="h-5 w-5 mx-auto mb-1 text-primary" />
              <div className="text-2xl font-bold">{stats.total_leads}</div>
              <div className="text-xs text-muted-foreground">Total Leads</div>
            </div>
            <div className="text-center p-3 rounded-lg border bg-muted/50">
              <Phone className="h-5 w-5 mx-auto mb-1 text-blue-600" />
              <div className="text-2xl font-bold">{stats.dialer_leads}</div>
              <div className="text-xs text-muted-foreground">Dialer Queue</div>
            </div>
            <div className="text-center p-3 rounded-lg border bg-muted/50">
              <Mail className="h-5 w-5 mx-auto mb-1 text-green-600" />
              <div className="text-2xl font-bold">{stats.email_leads}</div>
              <div className="text-xs text-muted-foreground">Email Queue</div>
            </div>
            <div className="text-center p-3 rounded-lg border bg-muted/50">
              <Search className="h-5 w-5 mx-auto mb-1 text-yellow-600" />
              <div className="text-2xl font-bold">{stats.research_leads}</div>
              <div className="text-xs text-muted-foreground">Research</div>
            </div>
          </div>
        </div>

        {/* AI Path Recommendations */}
        <div>
          <h4 className="text-sm font-semibold mb-3 text-foreground">AI Recommendations</h4>
          <div className="space-y-2">
            <div className="flex items-center justify-between p-2 rounded-lg border bg-muted/50">
              <span className="text-sm">Funding First</span>
              <span className="font-bold text-green-600">{stats.funding_first}</span>
            </div>
            <div className="flex items-center justify-between p-2 rounded-lg border bg-muted/50">
              <span className="text-sm">Credit Fix First</span>
              <span className="font-bold text-amber-600">{stats.credit_first}</span>
            </div>
            <div className="flex items-center justify-between p-2 rounded-lg border bg-muted/50">
              <span className="text-sm">Hybrid Path</span>
              <span className="font-bold text-blue-600">{stats.hybrid_path}</span>
            </div>
            <div className="flex items-center justify-between p-2 rounded-lg border bg-muted/50">
              <span className="text-sm">Do Not Work</span>
              <span className="font-bold text-red-600">{stats.do_not_work}</span>
            </div>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="flex flex-col gap-2 pt-2 border-t">
          <Button
            variant="outline"
            size="sm"
            onClick={() => navigate('/lead-engine/v4')}
            className="w-full justify-between"
          >
            <span>Open Lead Engine</span>
            <ArrowRight className="h-4 w-4" />
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => navigate('/lead-engine/v4?tab=research')}
            className="w-full justify-between"
          >
            <span>View Research Queue</span>
            <ArrowRight className="h-4 w-4" />
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => navigate('/lead-engine/v4?tab=call_queue')}
            className="w-full justify-between"
          >
            <span>Open Call Queue</span>
            <ArrowRight className="h-4 w-4" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};
