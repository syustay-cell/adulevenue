import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Loader2, TrendingUp, Users, DollarSign, Clock, Bot, Award } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

interface WorkerMetrics {
  worker_id: string;
  worker_email: string;
  total_leads: number;
  funded_deals: number;
  conversion_rate: number;
  avg_response_time_hours: number;
  total_funding_volume: number;
  ai_actions: number;
  human_actions: number;
  ai_ratio: number;
  projected_commission: number;
}

export const WorkerAnalytics = () => {
  const [loading, setLoading] = useState(true);
  const [metrics, setMetrics] = useState<WorkerMetrics[]>([]);
  const [summaryStats, setSummaryStats] = useState({
    total_workers: 0,
    total_leads: 0,
    total_funded: 0,
    avg_conversion: 0,
    total_volume: 0,
    avg_response_time: 0,
  });

  useEffect(() => {
    fetchWorkerAnalytics();
  }, []);

  const fetchWorkerAnalytics = async () => {
    try {
      setLoading(true);

      // Get all workers
      const { data: workers } = await supabase
        .from("user_roles")
        .select("user_id")
        .eq("role", "worker")
        .eq("approved", true);

      if (!workers) return;

      const workerMetrics: WorkerMetrics[] = [];

      for (const worker of workers) {
        // Get worker email
        const { data: userData } = await supabase.auth.admin.getUserById(worker.user_id);
        const worker_email = userData?.user?.email || "Unknown";

        // Total leads assigned
        const { count: total_leads } = await supabase
          .from("lead_assignments")
          .select("*", { count: "exact", head: true })
          .eq("assigned_worker_id", worker.user_id);

        // Funded deals (from fast_track_applications)
        const { data: fundedApps } = await supabase
          .from("fast_track_applications")
          .select("id")
          .eq("user_id", worker.user_id)
          .eq("status", "funded");

        const funded_deals = fundedApps?.length || 0;

        // Calculate conversion rate
        const conversion_rate = total_leads && total_leads > 0 
          ? (funded_deals / total_leads) * 100 
          : 0;

        // Get funding volume from application_transactions
        const { data: transactions } = await supabase
          .from("application_transactions")
          .select("amount")
          .eq("transaction_type", "funding")
          .in("application_id", fundedApps?.map(a => a.id) || []);

        const total_funding_volume = transactions?.reduce((sum, t) => sum + Number(t.amount), 0) || 0;

        // Get activity logs
        const { data: activities } = await supabase
          .from("worker_activity_logs")
          .select("created_at, worker_type, lead_id")
          .eq("worker_id", worker.user_id)
          .order("created_at", { ascending: true });

        // Calculate average response time (first contact after lead assignment)
        let total_response_time = 0;
        let response_count = 0;

        if (activities) {
          const leadFirstContact: Record<string, string> = {};
          activities.forEach(act => {
            if (act.lead_id && !leadFirstContact[act.lead_id]) {
              leadFirstContact[act.lead_id] = act.created_at;
            }
          });

          for (const lead_id of Object.keys(leadFirstContact)) {
            const { data: lead } = await supabase
              .from("lead_assignments")
              .select("assigned_at")
              .eq("id", lead_id)
              .single();

            if (lead?.assigned_at) {
              const assigned = new Date(lead.assigned_at).getTime();
              const contacted = new Date(leadFirstContact[lead_id]).getTime();
              const diff_hours = (contacted - assigned) / (1000 * 60 * 60);
              if (diff_hours > 0) {
                total_response_time += diff_hours;
                response_count++;
              }
            }
          }
        }

        const avg_response_time_hours = response_count > 0 
          ? total_response_time / response_count 
          : 0;

        // AI vs Human actions
        const ai_actions = activities?.filter(a => a.worker_type === "ai").length || 0;
        const human_actions = activities?.filter(a => a.worker_type === "human").length || 0;
        const total_actions = ai_actions + human_actions;
        const ai_ratio = total_actions > 0 ? (ai_actions / total_actions) * 100 : 0;

        // Projected commission (from iso_commissions)
        const { data: commissions } = await supabase
          .from("iso_commissions")
          .select("commission_amount")
          .eq("iso_partner_id", worker.user_id)
          .eq("payment_status", "pending");

        const projected_commission = commissions?.reduce((sum, c) => sum + Number(c.commission_amount), 0) || 0;

        workerMetrics.push({
          worker_id: worker.user_id,
          worker_email,
          total_leads: total_leads || 0,
          funded_deals,
          conversion_rate,
          avg_response_time_hours,
          total_funding_volume,
          ai_actions,
          human_actions,
          ai_ratio,
          projected_commission,
        });
      }

      setMetrics(workerMetrics);

      // Calculate summary stats
      const total_workers = workerMetrics.length;
      const total_leads = workerMetrics.reduce((sum, m) => sum + m.total_leads, 0);
      const total_funded = workerMetrics.reduce((sum, m) => sum + m.funded_deals, 0);
      const avg_conversion = total_leads > 0 ? (total_funded / total_leads) * 100 : 0;
      const total_volume = workerMetrics.reduce((sum, m) => sum + m.total_funding_volume, 0);
      const avg_response_time = workerMetrics.length > 0
        ? workerMetrics.reduce((sum, m) => sum + m.avg_response_time_hours, 0) / workerMetrics.length
        : 0;

      setSummaryStats({
        total_workers,
        total_leads,
        total_funded,
        avg_conversion,
        total_volume,
        avg_response_time,
      });

    } catch (error) {
      console.error("Error fetching worker analytics:", error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center p-12">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold tracking-tight">Worker Performance Analytics</h2>
        <p className="text-muted-foreground">
          Track productivity, conversion rates, and automation efficiency across your team
        </p>
      </div>

      {/* Summary Stats */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Workers</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{summaryStats.total_workers}</div>
            <p className="text-xs text-muted-foreground">Active approved workers</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Avg Conversion Rate</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{summaryStats.avg_conversion.toFixed(1)}%</div>
            <p className="text-xs text-muted-foreground">
              {summaryStats.total_funded} funded / {summaryStats.total_leads} leads
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Funding Volume</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              ${summaryStats.total_volume.toLocaleString()}
            </div>
            <p className="text-xs text-muted-foreground">Across all workers</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Avg Response Time</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {summaryStats.avg_response_time.toFixed(1)}h
            </div>
            <p className="text-xs text-muted-foreground">First contact after assignment</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">AI Automation</CardTitle>
            <Bot className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {metrics.length > 0
                ? (metrics.reduce((sum, m) => sum + m.ai_ratio, 0) / metrics.length).toFixed(1)
                : 0}%
            </div>
            <p className="text-xs text-muted-foreground">AI vs Human action ratio</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Projected Commissions</CardTitle>
            <Award className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              ${metrics.reduce((sum, m) => sum + m.projected_commission, 0).toLocaleString()}
            </div>
            <p className="text-xs text-muted-foreground">Pending payouts</p>
          </CardContent>
        </Card>
      </div>

      {/* Detailed Worker Table */}
      <Card>
        <CardHeader>
          <CardTitle>Individual Worker Performance</CardTitle>
          <CardDescription>
            Detailed breakdown of metrics per worker
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="overview">
            <TabsList>
              <TabsTrigger value="overview">Overview</TabsTrigger>
              <TabsTrigger value="automation">Automation</TabsTrigger>
              <TabsTrigger value="financial">Financial</TabsTrigger>
            </TabsList>

            <TabsContent value="overview" className="space-y-4">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Worker</TableHead>
                    <TableHead className="text-right">Leads</TableHead>
                    <TableHead className="text-right">Funded</TableHead>
                    <TableHead className="text-right">Conversion</TableHead>
                    <TableHead className="text-right">Avg Response</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {metrics.map((worker) => (
                    <TableRow key={worker.worker_id}>
                      <TableCell className="font-medium">{worker.worker_email}</TableCell>
                      <TableCell className="text-right">{worker.total_leads}</TableCell>
                      <TableCell className="text-right">{worker.funded_deals}</TableCell>
                      <TableCell className="text-right">
                        <Badge
                          variant={worker.conversion_rate > 20 ? "default" : "secondary"}
                        >
                          {worker.conversion_rate.toFixed(1)}%
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        {worker.avg_response_time_hours.toFixed(1)}h
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TabsContent>

            <TabsContent value="automation" className="space-y-4">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Worker</TableHead>
                    <TableHead className="text-right">AI Actions</TableHead>
                    <TableHead className="text-right">Human Actions</TableHead>
                    <TableHead className="text-right">AI Ratio</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {metrics.map((worker) => (
                    <TableRow key={worker.worker_id}>
                      <TableCell className="font-medium">{worker.worker_email}</TableCell>
                      <TableCell className="text-right">{worker.ai_actions}</TableCell>
                      <TableCell className="text-right">{worker.human_actions}</TableCell>
                      <TableCell className="text-right">
                        <Badge
                          variant={worker.ai_ratio > 50 ? "default" : "secondary"}
                        >
                          {worker.ai_ratio.toFixed(1)}%
                        </Badge>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TabsContent>

            <TabsContent value="financial" className="space-y-4">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Worker</TableHead>
                    <TableHead className="text-right">Total Volume</TableHead>
                    <TableHead className="text-right">Projected Commission</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {metrics.map((worker) => (
                    <TableRow key={worker.worker_id}>
                      <TableCell className="font-medium">{worker.worker_email}</TableCell>
                      <TableCell className="text-right">
                        ${worker.total_funding_volume.toLocaleString()}
                      </TableCell>
                      <TableCell className="text-right">
                        ${worker.projected_commission.toLocaleString()}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
};
