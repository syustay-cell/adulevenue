import React, { useEffect, useState } from 'react';
import {
  getSystemModeState,
  setExecutionMode,
  setStrategyProfile,
  setOwnerMode,
  verifyOptimizationPin,
  getModeDisplayInfo,
  type ExecutionMode,
  type StrategyProfile,
  type OwnerMode,
} from '@/lib/systemMode';
import { logActivityEvent } from '@/lib/activity';
import { useOptimizationSuggestions } from '@/hooks/useOptimizationSuggestions';
import { getSuggestionIcon, getSuggestionSeverity } from '@/lib/optimizationSuggestions';
import { Button } from '@/components/ui/button';
import { Select, SelectTrigger, SelectContent, SelectItem, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { toast } from 'sonner';
import { Loader2, Lock, Unlock, Zap, Hand, Settings2, Lightbulb, Check, X } from 'lucide-react';
interface SystemModePanelProps {
  onModeChange?: () => void;
}

export function SystemModePanel({ onModeChange }: SystemModePanelProps) {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [pin, setPin] = useState('');

  const [executionMode, setExecutionModeLocal] = useState<ExecutionMode>('AUTOPILOT');
  const [strategyProfile, setStrategyLocal] = useState<StrategyProfile>('STANDARD');
  const [ownerMode, setOwnerModeLocal] = useState<OwnerMode>('LOCKED');

  // 555 Optimization suggestions
  const { suggestions, loading: suggestionsLoading, processing, apply, reject, refresh } = useOptimizationSuggestions();

  useEffect(() => {
    load();
  }, []);

  async function load() {
    setLoading(true);
    try {
      const state = await getSystemModeState();
      setExecutionModeLocal(state.executionMode);
      setStrategyLocal(state.strategyProfile);
      setOwnerModeLocal(state.ownerMode);
    } catch (err) {
      console.error(err);
      toast.error('Failed to load mode state');
    } finally {
      setLoading(false);
    }
  }

  async function handleExecutionChange(next: ExecutionMode) {
    const prev = executionMode;
    setSaving(true);
    try {
      await setExecutionMode(next);
      setExecutionModeLocal(next);
      
      await logActivityEvent({
        actorType: 'ADMIN',
        scope: 'SYSTEM_MODE',
        eventType: 'MODE_CHANGE',
        decision: 'INFO',
        summary: `Execution mode changed from ${prev} to ${next}`,
        details: { from: prev, to: next },
      });
      
      toast.success(`Execution mode set to ${next === 'MANUAL' ? 'Manual' : 'Autopilot'}`);
      onModeChange?.();
    } catch (err) {
      console.error(err);
      toast.error('Failed to update execution mode');
    } finally {
      setSaving(false);
    }
  }

  async function handleStrategyChange(next: StrategyProfile) {
    const prev = strategyProfile;
    setSaving(true);
    try {
      await setStrategyProfile(next);
      setStrategyLocal(next);
      
      await logActivityEvent({
        actorType: 'ADMIN',
        scope: 'SYSTEM_MODE',
        eventType: 'MODE_CHANGE',
        decision: 'INFO',
        summary: `Strategy profile changed from ${prev} to ${next}`,
        details: { from: prev, to: next },
      });
      
      toast.success(`Strategy profile set to ${next}`);
      onModeChange?.();
    } catch (err) {
      console.error(err);
      toast.error('Failed to update strategy profile');
    } finally {
      setSaving(false);
    }
  }

  async function handleUnlockOwner() {
    if (!pin.trim()) {
      toast.error('Enter the 555 owner PIN');
      return;
    }

    setSaving(true);
    try {
      const ok = await verifyOptimizationPin(pin.trim());
      if (!ok) {
        toast.error('Invalid PIN');
        return;
      }

      await setOwnerMode('OPTIMIZATION');
      setOwnerModeLocal('OPTIMIZATION');
      
      await logActivityEvent({
        actorType: 'ADMIN',
        scope: 'SYSTEM_MODE',
        eventType: 'MODE_CHANGE',
        decision: 'INFO',
        severity: 'HIGH',
        summary: 'Owner optimization mode UNLOCKED with PIN 555',
      });
      
      toast.success('Owner optimization mode unlocked');
      setPin('');
    } catch (err) {
      console.error(err);
      toast.error('Failed to verify PIN');
    } finally {
      setSaving(false);
    }
  }

  async function handleLockOwner() {
    setSaving(true);
    try {
      await setOwnerMode('LOCKED');
      setOwnerModeLocal('LOCKED');
      
      await logActivityEvent({
        actorType: 'ADMIN',
        scope: 'SYSTEM_MODE',
        eventType: 'MODE_CHANGE',
        decision: 'INFO',
        summary: 'Owner optimization mode LOCKED',
      });
      
      toast.success('Owner optimization mode locked');
    } catch (err) {
      console.error(err);
      toast.error('Failed to lock owner mode');
    } finally {
      setSaving(false);
    }
  }

  if (loading) {
    return (
      <div className="rounded-lg border bg-card p-4">
        <div className="flex items-center gap-2">
          <Loader2 className="h-4 w-4 animate-spin" />
          <span className="text-sm text-muted-foreground">Loading system mode...</span>
        </div>
      </div>
    );
  }

  const display = getModeDisplayInfo({
    executionMode,
    strategyProfile,
    ownerMode,
  });

  return (
    <div className="rounded-lg border bg-card p-4 flex flex-col gap-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-semibold flex items-center gap-2">
            <Settings2 className="h-5 w-5" />
            System Mode
          </h2>
          <p className="text-sm text-muted-foreground">
            {display.description}
          </p>
        </div>
        <span className={`inline-flex items-center rounded-full border px-3 py-1 text-xs font-medium bg-muted ${display.color}`}>
          {display.chip}
        </span>
      </div>

      {/* Execution Mode */}
      <div className="flex flex-col gap-2">
        <label className="text-xs font-medium uppercase text-muted-foreground">
          Execution Mode
        </label>
        <div className="inline-flex gap-2">
          <Button
            type="button"
            variant={executionMode === 'MANUAL' ? 'default' : 'outline'}
            size="sm"
            disabled={saving}
            onClick={() => handleExecutionChange('MANUAL')}
          >
            <Hand className="h-4 w-4 mr-1" />
            Manual
          </Button>
          <Button
            type="button"
            variant={executionMode === 'AUTOPILOT' ? 'default' : 'outline'}
            size="sm"
            disabled={saving}
            onClick={() => handleExecutionChange('AUTOPILOT')}
          >
            <Zap className="h-4 w-4 mr-1" />
            Autopilot
          </Button>
        </div>
      </div>

      {/* Strategy Profile */}
      <div className="flex flex-col gap-2">
        <label className="text-xs font-medium uppercase text-muted-foreground">
          Strategy Profile
        </label>
        <Select
          value={strategyProfile}
          onValueChange={(v) => handleStrategyChange(v as StrategyProfile)}
          disabled={saving}
        >
          <SelectTrigger className="w-[220px]">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="STANDARD">Standard – balanced</SelectItem>
            <SelectItem value="ECO">Eco – conservative</SelectItem>
            <SelectItem value="AGGRESSIVE">Aggressive – high drive</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Owner 555 Mode */}
      <div className="flex flex-col gap-2 border-t pt-4">
        <div className="flex items-center justify-between gap-2">
          <div>
            <label className="text-xs font-medium uppercase text-muted-foreground">
              Owner Optimization (555)
            </label>
            <p className="text-xs text-muted-foreground">
              Unlocks advanced optimization controls (rules, caps, pricing).
            </p>
          </div>
          <span
            className={`inline-flex items-center gap-1 rounded-full px-2 py-1 text-[10px] font-semibold ${
              ownerMode === 'OPTIMIZATION'
                ? 'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-300'
                : 'bg-muted text-muted-foreground'
            }`}
          >
            {ownerMode === 'OPTIMIZATION' ? (
              <>
                <Unlock className="h-3 w-3" />
                UNLOCKED
              </>
            ) : (
              <>
                <Lock className="h-3 w-3" />
                LOCKED
              </>
            )}
          </span>
        </div>

        {ownerMode === 'LOCKED' ? (
          <div className="flex items-center gap-2">
            <Input
              type="password"
              placeholder="Enter PIN..."
              value={pin}
              onChange={(e) => setPin(e.target.value)}
              className="w-24"
              maxLength={6}
              onKeyDown={(e) => e.key === 'Enter' && handleUnlockOwner()}
            />
            <Button
              type="button"
              size="sm"
              disabled={saving}
              onClick={handleUnlockOwner}
            >
              {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : 'Unlock 555'}
            </Button>
          </div>
        ) : (
          <div className="flex items-center gap-2">
            <Button
              type="button"
              variant="outline"
              size="sm"
              disabled={saving}
              onClick={handleLockOwner}
            >
              <Lock className="h-4 w-4 mr-1" />
              Lock 555
            </Button>
            <p className="text-xs text-muted-foreground">
              Optimization Pilot is active. System changes may adjust how AI behaves.
            </p>
          </div>
        )}
      </div>

      {/* Optimization Suggestions - Only shown when 555 is unlocked */}
      {ownerMode === 'OPTIMIZATION' && (
        <div className="flex flex-col gap-3 border-t pt-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Lightbulb className="h-4 w-4 text-blue-600" />
              <span className="text-sm font-medium">Optimization Suggestions</span>
              {suggestions.length > 0 && (
                <span className="rounded-full bg-blue-100 text-blue-700 px-2 py-0.5 text-[10px] font-semibold dark:bg-blue-900/30 dark:text-blue-300">
                  {suggestions.length}
                </span>
              )}
            </div>
            <Button
              type="button"
              variant="ghost"
              size="sm"
              onClick={refresh}
              disabled={suggestionsLoading}
            >
              {suggestionsLoading ? <Loader2 className="h-3 w-3 animate-spin" /> : '⟳'}
            </Button>
          </div>

          {suggestionsLoading && suggestions.length === 0 ? (
            <div className="text-xs text-muted-foreground">Loading suggestions...</div>
          ) : suggestions.length === 0 ? (
            <div className="text-xs text-muted-foreground">
              No pending suggestions. The system analyzes activity and generates optimization recommendations.
            </div>
          ) : (
            <div className="flex flex-col gap-2">
              {suggestions.map((suggestion) => {
                const severity = getSuggestionSeverity(suggestion.scope);
                const severityColors = {
                  high: 'border-l-red-500',
                  medium: 'border-l-yellow-500',
                  low: 'border-l-green-500',
                };
                
                return (
                  <div
                    key={suggestion.id}
                    className={`rounded-md border bg-background p-3 text-sm border-l-4 ${severityColors[severity]}`}
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <span>{getSuggestionIcon(suggestion.suggestion_type)}</span>
                          <span className="font-medium">{suggestion.suggestion_type.replace(/_/g, ' ')}</span>
                          <span className="rounded-full bg-muted px-2 py-0.5 text-[10px] uppercase">
                            {suggestion.scope}
                          </span>
                        </div>
                        <p className="text-xs text-muted-foreground">{suggestion.rationale}</p>
                      </div>
                      <div className="flex items-center gap-1">
                        <Button
                          type="button"
                          variant="ghost"
                          size="sm"
                          className="h-7 w-7 p-0 text-green-600 hover:text-green-700 hover:bg-green-50"
                          disabled={processing === suggestion.id}
                          onClick={() => apply(suggestion.id)}
                        >
                          {processing === suggestion.id ? (
                            <Loader2 className="h-4 w-4 animate-spin" />
                          ) : (
                            <Check className="h-4 w-4" />
                          )}
                        </Button>
                        <Button
                          type="button"
                          variant="ghost"
                          size="sm"
                          className="h-7 w-7 p-0 text-red-600 hover:text-red-700 hover:bg-red-50"
                          disabled={processing === suggestion.id}
                          onClick={() => reject(suggestion.id)}
                        >
                          <X className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
