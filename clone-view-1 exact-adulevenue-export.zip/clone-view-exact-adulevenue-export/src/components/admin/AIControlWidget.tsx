import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Progress } from '@/components/ui/progress';
import { Leaf, Zap, Power, RefreshCw, DollarSign, AlertTriangle } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

interface AIControlWidgetProps {
  compact?: boolean;
}

export function AIControlWidget({ compact = false }: AIControlWidgetProps) {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [mode, setMode] = useState<'eco' | 'balanced' | 'off'>('balanced');
  const [aiEnabled, setAiEnabled] = useState(true);
  const [monthCost, setMonthCost] = useState(0);
  const [budget, setBudget] = useState(100);
  const [percentUsed, setPercentUsed] = useState(0);
  const [status, setStatus] = useState<'ok' | 'warning' | 'critical'>('ok');

  useEffect(() => {
    loadStatus();
  }, []);

  const loadStatus = async () => {
    setLoading(true);
    try {
      // Fetch AI mode config
      const { data: modeData } = await supabase.functions.invoke('wf-ai-mode-engine', {
        body: { action: 'get_config' }
      });
      
      if (modeData?.config) {
        const wsMode = modeData.config.workspace_mode;
        if (wsMode === 'manual') {
          setMode('off');
          setAiEnabled(false);
        } else if (wsMode === 'eco') {
          setMode('eco');
          setAiEnabled(true);
        } else {
          setMode('balanced');
          setAiEnabled(true);
        }
      }

      // Fetch AI cost summary
      const { data: costData } = await supabase.functions.invoke('wf-ai-cost-summary', {
        body: { provider: 'gateway' }
      });
      
      if (costData?.ok) {
        setMonthCost(costData.current_month?.cost_usd || 0);
        setBudget(costData.budget?.monthly_budget_usd || 100);
        setPercentUsed(costData.budget?.percent_used || 0);
        setStatus(costData.budget?.status || 'ok');
      }
    } catch (err) {
      console.error('Failed to load AI status:', err);
    } finally {
      setLoading(false);
    }
  };

  const updateMode = async (newMode: 'eco' | 'balanced' | 'off') => {
    setSaving(true);
    try {
      const wsMode = newMode === 'off' ? 'manual' : newMode;
      
      const { data, error } = await supabase.functions.invoke('wf-ai-mode-engine', {
        body: { 
          action: 'update_config', 
          config_updates: { workspace_mode: wsMode }
        }
      });

      if (error) throw error;

      setMode(newMode);
      setAiEnabled(newMode !== 'off');
      toast.success(`AI mode set to ${newMode === 'off' ? 'Manual (Off)' : newMode.toUpperCase()}`);
    } catch (err) {
      console.error('Failed to update mode:', err);
      toast.error('Failed to update AI mode');
    } finally {
      setSaving(false);
    }
  };

  const getModeIcon = () => {
    if (mode === 'eco') return <Leaf className="h-4 w-4 text-green-500" />;
    if (mode === 'balanced') return <Zap className="h-4 w-4 text-blue-500" />;
    return <Power className="h-4 w-4 text-muted-foreground" />;
  };

  const getModeColor = () => {
    if (mode === 'eco') return 'bg-green-500/10 text-green-600 border-green-500/20';
    if (mode === 'balanced') return 'bg-blue-500/10 text-blue-600 border-blue-500/20';
    return 'bg-muted text-muted-foreground';
  };

  if (loading) {
    return (
      <Card>
        <CardContent className="p-6 flex items-center justify-center">
          <RefreshCw className="h-5 w-5 animate-spin text-muted-foreground" />
        </CardContent>
      </Card>
    );
  }

  if (compact) {
    return (
      <Card>
        <CardContent className="p-4">
          <div className="flex items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              {getModeIcon()}
              <div>
                <p className="text-sm font-medium">AI Mode</p>
                <p className="text-xs text-muted-foreground">${monthCost.toFixed(2)} / ${budget}</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Button
                size="sm"
                variant={mode === 'eco' ? 'default' : 'outline'}
                className="h-7 text-xs"
                onClick={() => updateMode('eco')}
                disabled={saving}
              >
                Eco
              </Button>
              <Button
                size="sm"
                variant={mode === 'balanced' ? 'default' : 'outline'}
                className="h-7 text-xs"
                onClick={() => updateMode('balanced')}
                disabled={saving}
              >
                Normal
              </Button>
              <Button
                size="sm"
                variant={mode === 'off' ? 'destructive' : 'outline'}
                className="h-7 text-xs"
                onClick={() => updateMode('off')}
                disabled={saving}
              >
                Off
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-base flex items-center gap-2">
          {getModeIcon()}
          AI Control Panel
        </CardTitle>
        <CardDescription>Manage AI mode and monitor costs</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Mode Selection */}
        <div className="flex items-center gap-2">
          <Button
            variant={mode === 'eco' ? 'default' : 'outline'}
            onClick={() => updateMode('eco')}
            disabled={saving}
            className="flex-1"
          >
            <Leaf className="h-4 w-4 mr-2" />
            Eco Mode
          </Button>
          <Button
            variant={mode === 'balanced' ? 'default' : 'outline'}
            onClick={() => updateMode('balanced')}
            disabled={saving}
            className="flex-1"
          >
            <Zap className="h-4 w-4 mr-2" />
            Normal
          </Button>
          <Button
            variant={mode === 'off' ? 'destructive' : 'outline'}
            onClick={() => updateMode('off')}
            disabled={saving}
            className="flex-1"
          >
            <Power className="h-4 w-4 mr-2" />
            Off
          </Button>
        </div>

        {/* Cost Summary */}
        <div className="space-y-2">
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">Monthly Cost</span>
            <div className="flex items-center gap-2">
              <span className="font-medium">${monthCost.toFixed(2)}</span>
              <Badge 
                variant={status === 'ok' ? 'default' : status === 'warning' ? 'secondary' : 'destructive'}
                className="text-xs"
              >
                {status === 'ok' ? 'OK' : status === 'warning' ? 'Warning' : 'Critical'}
              </Badge>
            </div>
          </div>
          <Progress value={Math.min(percentUsed, 100)} />
          <div className="flex justify-between text-xs text-muted-foreground">
            <span>Budget: ${budget}</span>
            <span>{percentUsed.toFixed(0)}% used</span>
          </div>
        </div>

        {/* Status Indicator */}
        <div className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
          <div className="flex items-center gap-2">
            <span className="text-sm">Current Mode:</span>
            <Badge className={getModeColor()}>
              {mode === 'eco' ? '🌱 Eco (OpenAI)' : mode === 'balanced' ? '⚡ Normal (AI Gateway)' : '👤 Manual (Off)'}
            </Badge>
          </div>
          <Button variant="ghost" size="sm" onClick={loadStatus}>
            <RefreshCw className="h-4 w-4" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
