import { useState, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

type AIMode = 'eco' | 'balanced' | 'pro';

interface ModeInfo {
  mode: AIMode;
  emoji: string;
  label: string;
  description: string;
}

const MODE_INFO: Record<string, ModeInfo> = {
  '222': {
    mode: 'eco',
    emoji: '🌱',
    label: 'ECO',
    description: 'OpenAI – lowest cost'
  },
  '333': {
    mode: 'balanced',
    emoji: '⚡',
    label: 'BALANCED',
    description: 'AI Gateway'
  },
  '444': {
    mode: 'pro',
    emoji: '👑',
    label: 'PRO',
    description: 'AI Gateway – deepest analysis'
  }
};

interface UseChatModeSwitchOptions {
  isAdmin: boolean;
  sessionId: string;
}

export function useChatModeSwitch({ isAdmin, sessionId }: UseChatModeSwitchOptions) {
  const [currentMode, setCurrentMode] = useState<AIMode>('eco');
  const [isProcessing, setIsProcessing] = useState(false);
  const { toast } = useToast();

  // Check if message is a mode switch command
  const isModeCommand = useCallback((message: string): boolean => {
    const trimmed = message.trim();
    return ['222', '333', '444'].includes(trimmed);
  }, []);

  // Process mode switch command
  const processModeCommand = useCallback(async (command: string): Promise<string | null> => {
    const modeInfo = MODE_INFO[command];
    if (!modeInfo) return null;

    setIsProcessing(true);

    try {
      if (isAdmin) {
        // Admin: Update global config for chat features
        const { data: configData } = await supabase.functions.invoke('wf-ai-mode-engine', {
          body: { action: 'get_config' }
        });

        if (configData?.config) {
          const currentPerFeature = configData.config.per_feature || {};
          
          await supabase.functions.invoke('wf-ai-mode-engine', {
            body: {
              action: 'update_config',
              config_updates: {
                per_feature: {
                  ...currentPerFeature,
                  chat_assistant: modeInfo.mode,
                  wolf_assistant: modeInfo.mode
                }
              }
            }
          });
        }
      } else {
        // Non-admin: Store per-session override
        const { data: { user } } = await supabase.auth.getUser();
        
        if (user) {
          // Upsert session override
          await supabase
            .from('wf_chat_session_overrides')
            .upsert({
              user_id: user.id,
              session_id: sessionId,
              mode_override: modeInfo.mode,
              expires_at: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString() // 24 hours
            }, {
              onConflict: 'user_id,session_id'
            });
        }
      }

      setCurrentMode(modeInfo.mode);
      
      return `✅ AI mode switched to ${modeInfo.emoji} ${modeInfo.label} (${modeInfo.description}) for chat.`;
    } catch (error) {
      console.error('Mode switch error:', error);
      return `❌ Failed to switch mode. Please try again.`;
    } finally {
      setIsProcessing(false);
    }
  }, [isAdmin, sessionId]);

  // Check if a message seems complex (for upgrade prompts)
  const isComplexQuery = useCallback((message: string): boolean => {
    const complexKeywords = [
      'underwrite', 'underwriting', 'full analysis', 'deep dive',
      'legal', 'compliance', 'strategy', 'roadmap', 'multi-step',
      'audit', 'comprehensive', 'complete review', 'detailed analysis',
      'business plan', 'funding strategy', 'credit optimization'
    ];
    
    const lowerMessage = message.toLowerCase();
    
    // Check for complex keywords
    const hasComplexKeyword = complexKeywords.some(kw => lowerMessage.includes(kw));
    
    // Check for long messages (likely complex questions)
    const isLongMessage = message.length > 300;
    
    return hasComplexKeyword || isLongMessage;
  }, []);

  // Generate upgrade prompt for complex queries
  const getUpgradePrompt = useCallback((mode: AIMode): string | null => {
    if (mode !== 'eco') return null;
    
    return `\n\n💡 *This seems like a deep question. I can stay in 🌱 ECO mode or switch to ⚡ BALANCED / 👑 PRO for stronger analysis.*\n*Reply 222 to stay on Eco, 333 for Balanced, 444 for Pro.*`;
  }, []);

  return {
    currentMode,
    isProcessing,
    isModeCommand,
    processModeCommand,
    isComplexQuery,
    getUpgradePrompt,
    MODE_INFO
  };
}
