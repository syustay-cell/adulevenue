import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription } from '@/components/ui/sheet';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { FileText, Download, Loader2, Sparkles, Copy, Check, X, FileDown } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import jsPDF from 'jspdf';

interface PlaceholderDef {
  key: string;
  label: string;
  required: boolean;
  type?: string;
}

interface ContractTemplate {
  id: string;
  key: string;
  display_name: string;
  category: string;
  requires_ai: boolean;
  placeholders: PlaceholderDef[];
}

interface ContractLibraryProps {
  isOpen: boolean;
  onClose: () => void;
  preselectedTemplate?: string;
  prefillData?: Record<string, string>;
}

export function ContractLibrary({ isOpen, onClose, preselectedTemplate, prefillData }: ContractLibraryProps) {
  const [templates, setTemplates] = useState<ContractTemplate[]>([]);
  const [selectedTemplate, setSelectedTemplate] = useState<ContractTemplate | null>(null);
  const [formData, setFormData] = useState<Record<string, string>>({});
  const [generatedContent, setGeneratedContent] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [copied, setCopied] = useState(false);
  const { toast } = useToast();

  // Load templates
  useEffect(() => {
    const loadTemplates = async () => {
      setIsLoading(true);
      const { data, error } = await supabase
        .from('wf_contract_templates')
        .select('id, key, display_name, category, requires_ai, placeholders')
        .eq('is_active', true)
        .order('category', { ascending: true });

      if (error) {
        console.error('Error loading templates:', error);
        toast({
          title: "Error",
          description: "Failed to load contract templates.",
          variant: "destructive"
        });
      } else {
        setTemplates((data || []) as unknown as ContractTemplate[]);
        
        // Auto-select if preselectedTemplate provided
        if (preselectedTemplate && data) {
          const template = data.find(t => t.key === preselectedTemplate);
          if (template) {
            setSelectedTemplate(template as unknown as ContractTemplate);
            setFormData(prefillData || {});
          }
        }
      }
      setIsLoading(false);
    };

    if (isOpen) {
      loadTemplates();
    }
  }, [isOpen, preselectedTemplate, prefillData, toast]);

  const handleSelectTemplate = (template: ContractTemplate) => {
    setSelectedTemplate(template);
    setFormData({});
    setGeneratedContent(null);
  };

  const handleGenerate = async () => {
    if (!selectedTemplate) return;

    setIsGenerating(true);
    try {
      const { data, error } = await supabase.functions.invoke('wf-contract-generate', {
        body: {
          template_key: selectedTemplate.key,
          placeholders: formData
        }
      });

      if (error) throw error;

      if (data.ok) {
        setGeneratedContent(data.content);
        toast({
          title: "Contract Generated",
          description: data.ai_polished 
            ? "Contract generated and polished by AI." 
            : "Contract generated successfully."
        });
      } else {
        throw new Error(data.error || 'Generation failed');
      }
    } catch (error) {
      console.error('Contract generation error:', error);
      toast({
        title: "Generation Failed",
        description: error instanceof Error ? error.message : "Failed to generate contract.",
        variant: "destructive"
      });
    } finally {
      setIsGenerating(false);
    }
  };

  const handleCopy = () => {
    if (generatedContent) {
      navigator.clipboard.writeText(generatedContent);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleDownloadPDF = () => {
    if (!generatedContent || !selectedTemplate) return;

    const pdf = new jsPDF('p', 'mm', 'letter');
    const pageWidth = pdf.internal.pageSize.getWidth();
    const margin = 20;
    const maxWidth = pageWidth - margin * 2;
    
    // Header
    pdf.setFontSize(18);
    pdf.setFont('helvetica', 'bold');
    pdf.text('WOLF FUND', margin, 20);
    pdf.setFontSize(10);
    pdf.setFont('helvetica', 'normal');
    pdf.setTextColor(100);
    pdf.text('Business Funding & Credit Solutions', margin, 26);
    pdf.text('www.wolf-fund.com', margin, 31);
    
    // Line separator
    pdf.setDrawColor(200);
    pdf.line(margin, 35, pageWidth - margin, 35);
    
    // Document title
    pdf.setTextColor(0);
    pdf.setFontSize(14);
    pdf.setFont('helvetica', 'bold');
    pdf.text(selectedTemplate.display_name.toUpperCase(), margin, 45);
    
    // Date
    pdf.setFontSize(9);
    pdf.setFont('helvetica', 'normal');
    pdf.setTextColor(100);
    pdf.text(`Generated: ${new Date().toLocaleDateString()}`, margin, 51);
    
    // Content
    pdf.setTextColor(0);
    pdf.setFontSize(10);
    pdf.setFont('helvetica', 'normal');
    
    const lines = pdf.splitTextToSize(generatedContent, maxWidth);
    let yPosition = 60;
    const lineHeight = 5;
    const pageHeight = pdf.internal.pageSize.getHeight();
    
    lines.forEach((line: string) => {
      if (yPosition > pageHeight - 30) {
        pdf.addPage();
        yPosition = 20;
      }
      pdf.text(line, margin, yPosition);
      yPosition += lineHeight;
    });
    
    // Footer with signature lines
    if (yPosition < pageHeight - 50) {
      yPosition = pageHeight - 50;
    } else {
      pdf.addPage();
      yPosition = 40;
    }
    
    pdf.setDrawColor(0);
    pdf.line(margin, yPosition, margin + 60, yPosition);
    pdf.line(pageWidth - margin - 60, yPosition, pageWidth - margin, yPosition);
    
    pdf.setFontSize(8);
    pdf.text('Party A Signature', margin, yPosition + 5);
    pdf.text('Party B Signature', pageWidth - margin - 40, yPosition + 5);
    
    pdf.save(`${selectedTemplate.key}_${new Date().toISOString().split('T')[0]}.pdf`);
    
    toast({
      title: "PDF Downloaded",
      description: "Your contract has been saved as a PDF."
    });
  };

  const handleDownloadTxt = () => {
    if (!generatedContent || !selectedTemplate) return;

    const blob = new Blob([generatedContent], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${selectedTemplate.key}_${new Date().toISOString().split('T')[0]}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'funding': return '💰';
      case 'credit': return '📊';
      case 'partnership': return '🤝';
      default: return '📄';
    }
  };

  return (
    <Sheet open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <SheetContent side="right" className="w-full sm:max-w-2xl p-0 flex flex-col">
        <SheetHeader className="p-4 border-b">
          <div className="flex items-center justify-between">
            <SheetTitle className="flex items-center gap-2">
              <FileText className="h-5 w-5" />
              Contract Library
            </SheetTitle>
            <Button variant="ghost" size="icon" onClick={onClose}>
              <X className="h-4 w-4" />
            </Button>
          </div>
          <SheetDescription>
            Select a template and fill in the details to generate a contract instantly.
          </SheetDescription>
        </SheetHeader>

        <div className="flex-1 flex overflow-hidden">
          {/* Template Selection */}
          {!selectedTemplate && (
            <ScrollArea className="flex-1 p-4">
              {isLoading ? (
                <div className="flex items-center justify-center py-8">
                  <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
                </div>
              ) : (
                <div className="grid gap-3">
                  {templates.map((template) => (
                    <Card 
                      key={template.id}
                      className="cursor-pointer hover:border-primary transition-colors"
                      onClick={() => handleSelectTemplate(template)}
                    >
                      <CardHeader className="py-3 px-4">
                        <div className="flex items-center justify-between">
                          <CardTitle className="text-sm font-medium flex items-center gap-2">
                            <span>{getCategoryIcon(template.category)}</span>
                            {template.display_name}
                          </CardTitle>
                          <div className="flex gap-1">
                            <Badge variant="outline" className="text-xs">
                              {template.category}
                            </Badge>
                            {template.requires_ai && (
                              <Badge variant="secondary" className="text-xs">
                                <Sparkles className="h-3 w-3 mr-1" />
                                AI
                              </Badge>
                            )}
                          </div>
                        </div>
                      </CardHeader>
                    </Card>
                  ))}
                </div>
              )}
            </ScrollArea>
          )}

          {/* Form or Preview */}
          {selectedTemplate && !generatedContent && (
            <ScrollArea className="flex-1 p-4">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="font-semibold">{selectedTemplate.display_name}</h3>
                  <Button variant="ghost" size="sm" onClick={() => setSelectedTemplate(null)}>
                    ← Back
                  </Button>
                </div>

                <div className="grid gap-4">
                  {selectedTemplate.placeholders.map((placeholder) => (
                    <div key={placeholder.key} className="space-y-1">
                      <Label htmlFor={placeholder.key}>
                        {placeholder.label}
                        {placeholder.required && <span className="text-red-500 ml-1">*</span>}
                      </Label>
                      <Input
                        id={placeholder.key}
                        type={placeholder.type || 'text'}
                        value={formData[placeholder.key] || ''}
                        onChange={(e) => setFormData(prev => ({
                          ...prev,
                          [placeholder.key]: e.target.value
                        }))}
                        placeholder={placeholder.label}
                      />
                    </div>
                  ))}
                </div>

                <Button 
                  onClick={handleGenerate} 
                  disabled={isGenerating}
                  className="w-full"
                >
                  {isGenerating ? (
                    <>
                      <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                      Generating...
                    </>
                  ) : (
                    <>
                      <FileText className="h-4 w-4 mr-2" />
                      Generate Contract
                    </>
                  )}
                </Button>
              </div>
            </ScrollArea>
          )}

          {/* Generated Preview */}
          {generatedContent && (
            <div className="flex-1 flex flex-col overflow-hidden">
              <div className="p-3 border-b flex items-center justify-between bg-muted/50">
                <span className="font-medium text-sm">Generated Contract</span>
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" onClick={() => setGeneratedContent(null)}>
                    ← Edit
                  </Button>
                  <Button variant="outline" size="sm" onClick={handleCopy}>
                    {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                  </Button>
                  <Button variant="outline" size="sm" onClick={handleDownloadTxt}>
                    <Download className="h-4 w-4" />
                  </Button>
                  <Button size="sm" onClick={handleDownloadPDF}>
                    <FileDown className="h-4 w-4 mr-1" />
                    PDF
                  </Button>
                </div>
              </div>
              <ScrollArea className="flex-1 p-4">
                <Textarea
                  value={generatedContent}
                  onChange={(e) => setGeneratedContent(e.target.value)}
                  className="min-h-[500px] font-mono text-sm"
                />
              </ScrollArea>
            </div>
          )}
        </div>
      </SheetContent>
    </Sheet>
  );
}

// Quick command matcher for chat integration
export function matchContractCommand(message: string): { templateKey: string; prefill: Record<string, string> } | null {
  const lowerMessage = message.toLowerCase().trim();
  
  // Direct template key matches
  const directMatches: Record<string, string> = {
    'nda': 'nda',
    'iso_agreement': 'iso_agreement',
    'iso agreement': 'iso_agreement',
    'iso contract': 'iso_agreement',
    'funding_loi': 'funding_loi',
    'funding loi': 'funding_loi',
    'letter of intent': 'funding_loi',
    'credit_repair_service': 'credit_repair_service',
    'credit repair agreement': 'credit_repair_service',
    'credit repair contract': 'credit_repair_service'
  };

  for (const [keyword, templateKey] of Object.entries(directMatches)) {
    if (lowerMessage === keyword || lowerMessage.startsWith(`${keyword} `) || lowerMessage.includes(`make me an ${keyword}`) || lowerMessage.includes(`create ${keyword}`)) {
      return { templateKey, prefill: {} };
    }
  }

  return null;
}
