/**
 * ModeSwitcher — shared across Wolf Fund shell and ABG shell
 *
 * SEPARATION OF CONCERNS (enforced):
 *
 * Business context switcher (visible to any user with access):
 *   🐺 Wolf Fund  — always shown when user has Wolf Fund roles
 *   🏗 ABG        — shown only when user has ABG tenant membership
 *
 * System mode (super_owner only — strictly separated from business context):
 *   ⚡ God Mode   — ONLY for super_owner / owner role in user_roles
 *                   NEVER shown to Mike or non-super-owners
 *
 * Visibility rules:
 *   super_owner (Serg): Wolf Fund + ABG (if member) + God Mode — ALL THREE always
 *   ABG owner (Mike):   Wolf Fund + ABG — NO God Mode
 *   Sub portal users:   no switcher at all
 *
 * The dropdown trigger is visible on ALL screen sizes.
 * Wolf Fund layouts use <ModeDropdown /> which renders this component.
 * ABG shell renders this directly in the header (desktop) and
 * the mobile hamburger (mobile flat layout).
 */

import { useEffect, useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Button } from '@/components/ui/button';
import { getStoredMode, setStoredMode } from '@/contexts/OperationalContext';

const PORTAL_KEY = 'wolf_active_portal';

export type ActivePortal = 'wolf_fund' | 'abg';

export function getActivePortal(): ActivePortal {
  try {
    const v = window.localStorage.getItem(PORTAL_KEY);
    if (v === 'abg') return 'abg';
    return 'wolf_fund';
  } catch {
    return 'wolf_fund';
  }
}

export function setActivePortal(portal: ActivePortal) {
  try {
    window.localStorage.setItem(PORTAL_KEY, portal);
  } catch { /* ignore */ }
}

/**
 * Checks if user has ABG tenant membership.
 * Used for BUSINESS CONTEXT SWITCHER only.
 * Independent of isSuperOwner — Mike has ABG but is not super_owner.
 */
function useHasABGAccess() {
  const [hasABG, setHasABG] = useState<boolean | null>(null); // null = still loading

  useEffect(() => {
    let cancelled = false;
    const run = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      const userId = session?.user?.id;
      if (!userId) { if (!cancelled) setHasABG(false); return; }
      const { data } = await supabase
        .from('wf_tenant_users')
        .select('id, wf_tenants!inner(slug)')
        .eq('user_id', userId)
        .eq('wf_tenants.slug', 'abg')
        .maybeSingle();
      if (!cancelled) setHasABG(!!data);
    };
    run();
    return () => { cancelled = true; };
  }, []);

  return hasABG; // null while loading, true/false once resolved
}

/**
 * Checks if user is super_owner or owner in Wolf Fund user_roles.
 * Used EXCLUSIVELY for God Mode visibility.
 * Do NOT use this to gate ABG business switcher.
 *
 * syustay@gmail.com has super_owner + owner + admin → isSuperOwner = true → God Mode visible
 * michaelusto@gmail.com has only 'user' role → isSuperOwner = false → God Mode hidden
 */
function useIsSuperOwner() {
  const [isSuperOwner, setIsSuperOwner] = useState(false);

  useEffect(() => {
    let cancelled = false;
    const run = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      const userId = session?.user?.id;
      if (!userId) return;
      const { data: roles } = await supabase
        .from('user_roles')
        .select('role, approved')
        .eq('user_id', userId)
        .eq('approved', true);
      const ok = roles?.some((r) => r.role === 'super_owner' || r.role === 'owner') || false;
      if (!cancelled) setIsSuperOwner(ok);
    };
    run();
    return () => { cancelled = true; };
  }, []);

  return isSuperOwner;
}

interface ModeSwitcherProps {
  /** When true, renders as a flat button row (for inside mobile hamburger menu) */
  mobile?: boolean;
  onNavigate?: () => void;
}

export function ModeSwitcher({ mobile = false, onNavigate }: ModeSwitcherProps) {
  const navigate = useNavigate();
  const location = useLocation();

  // Business context — independent checks
  // hasABG is null while loading, true/false once resolved
  // Do not render ABG option until resolved — prevents flash of missing option for Mike
  const hasABG = useHasABGAccess();
  const isSuperOwner = useIsSuperOwner();     // ONLY for God Mode entry

  // While ABG access is still loading, show nothing for ABG option
  // This prevents Mike from seeing the dropdown without his ABG option
  const abgResolved = hasABG !== null;

  // Active context derived from current path
  const activePortal: ActivePortal = location.pathname.startsWith('/abg') ? 'abg' : 'wolf_fund';
  const isGodMode = getStoredMode() === 'GOD';

  const switchTo = (portal: ActivePortal, path: string) => {
    setActivePortal(portal);
    if (portal === 'wolf_fund') {
      setStoredMode('WOLF_FUND_CAPITAL', 'mode_switcher');
    }
    navigate(path);
    onNavigate?.();
  };

  const goGodMode = () => {
    setStoredMode('GOD', 'mode_switcher');
    navigate('/owner/motherboard');
    onNavigate?.();
  };

  // Trigger label: shows active context
  const triggerLabel = isGodMode ? 'God' : activePortal === 'abg' ? 'ABG' : 'Wolf Fund';

  // ── Mobile flat layout (inside hamburger) ────────────────────────────────
  if (mobile) {
    return (
      <div className="border border-white/10 rounded-lg overflow-hidden mb-3">
        <p className="text-[10px] uppercase tracking-widest text-gray-500 px-3 pt-2 pb-1">
          Switch Portal
        </p>

        {/* Wolf Fund — always shown */}
        <button
          onClick={() => switchTo('wolf_fund', '/')}
          className="w-full flex items-center gap-3 px-3 py-2.5 text-sm transition-colors hover:bg-white/10"
          style={{ color: activePortal === 'wolf_fund' && !isGodMode ? '#4A8DB7' : '#9CA3AF' }}
        >
          <span className="w-4 text-center text-xs font-bold">
            {activePortal === 'wolf_fund' && !isGodMode ? '✓' : ''}
          </span>
          🐺 Wolf Fund
        </button>

        {/* ABG — shown to ANY user with ABG membership (Mike + Serg) */}
        {abgResolved && hasABG && (
          <button
            onClick={() => switchTo('abg', '/abg/portal/today')}
            className="w-full flex items-center gap-3 px-3 py-2.5 text-sm transition-colors hover:bg-white/10"
            style={{ color: activePortal === 'abg' && !isGodMode ? '#4A8DB7' : '#9CA3AF' }}
          >
            <span className="w-4 text-center text-xs font-bold">
              {activePortal === 'abg' && !isGodMode ? '✓' : ''}
            </span>
            🏗 ABG
          </button>
        )}

        {/* God Mode separator — ONLY for super_owner. Never for Mike. */}
        {isSuperOwner && (
          <>
            <div className="border-t border-white/10 mx-3 my-1" />
            <button
              onClick={goGodMode}
              className="w-full flex items-center gap-3 px-3 py-2 text-xs hover:bg-white/10 transition-colors"
              style={{ color: isGodMode ? '#F59E0B' : '#6B7280' }}
            >
              <span className="w-4 text-center text-xs font-bold">
                {isGodMode ? '✓' : ''}
              </span>
              ⚡ God Mode
            </button>
          </>
        )}
      </div>
    );
  }

  // ── Desktop dropdown — visible on ALL screen sizes (not just md+) ────────
  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        {/* CRITICAL: no hidden md:flex — must be visible on mobile and desktop */}
        <Button
          size="sm"
          variant="outline"
          className="h-7 text-xs px-2.5"
        >
          Mode: {triggerLabel}
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="min-w-[190px]">

        {/* ── Business context section ─────────────────────────────── */}

        {/* Wolf Fund — always shown */}
        <DropdownMenuItem
          onClick={() => switchTo('wolf_fund', '/')}
          className="gap-2 cursor-pointer"
        >
          <span className="w-4 text-center text-xs">
            {activePortal === 'wolf_fund' && !isGodMode ? '✓' : ''}
          </span>
          🐺 Wolf Fund
        </DropdownMenuItem>

        {/* ABG — shown to ANY user with ABG membership */}
        {abgResolved && hasABG && (
          <DropdownMenuItem
            onClick={() => switchTo('abg', '/abg/portal/today')}
            className="gap-2 cursor-pointer"
          >
            <span className="w-4 text-center text-xs">
              {activePortal === 'abg' && !isGodMode ? '✓' : ''}
            </span>
            🏗 ABG
          </DropdownMenuItem>
        )}

        {/* ── System mode section — super_owner ONLY ──────────────── */}
        {isSuperOwner && (
          <>
            <DropdownMenuSeparator />
            <DropdownMenuItem
              onClick={goGodMode}
              className="gap-2 cursor-pointer"
              style={{ color: isGodMode ? '#F59E0B' : undefined }}
            >
              <span className="w-4 text-center text-xs font-bold">
                {isGodMode ? '✓' : ''}
              </span>
              ⚡ God Mode
            </DropdownMenuItem>
          </>
        )}

      </DropdownMenuContent>
    </DropdownMenu>
  );
}
