import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export type SearchResult = {
  id: string;
  vault_id: string | null;
  full_name: string | null;
  business_name: string | null;
  email_primary: string | null;
  phone_primary: string | null;
  primary_path: string | null;
  created_at: string;
  fta_count?: number;
  deal_count?: number;
  credit_count?: number;
};

function useDebouncedValue<T>(value: T, delay: number): T {
  const [debounced, setDebounced] = useState(value);

  useEffect(() => {
    const handle = setTimeout(() => setDebounced(value), delay);
    return () => clearTimeout(handle);
  }, [value, delay]);

  return debounced;
}

export function useGlobalSearch(term: string) {
  const debouncedTerm = useDebouncedValue(term.trim(), 300);

  const query = useQuery({
    queryKey: ["global-search", debouncedTerm],
    enabled: debouncedTerm.length >= 2,
    queryFn: async (): Promise<SearchResult[]> => {
      if (!debouncedTerm || debouncedTerm.length < 2) return [];

      const likeTerm = `%${debouncedTerm}%`;

      // Simple search on intake_clients - RLS handles visibility
      const { data, error } = await supabase
        .from("intake_clients")
        .select(`
          id,
          vault_id,
          full_name,
          business_name,
          email_primary,
          phone_primary,
          primary_path,
          created_at
        `)
        .or(
          `vault_id.ilike.${likeTerm},full_name.ilike.${likeTerm},business_name.ilike.${likeTerm},email_primary.ilike.${likeTerm},phone_primary.ilike.${likeTerm}`
        )
        .order("created_at", { ascending: false })
        .limit(20);

      if (error) throw error;

      // Return normalized results
      return (data || []).map((row) => ({
        id: row.id,
        vault_id: row.vault_id,
        full_name: row.full_name,
        business_name: row.business_name,
        email_primary: row.email_primary,
        phone_primary: row.phone_primary,
        primary_path: row.primary_path,
        created_at: row.created_at,
        // Counts will be fetched separately if needed
        fta_count: 0,
        deal_count: 0,
        credit_count: 0,
      }));
    },
  });

  return {
    ...query,
    term: debouncedTerm,
  };
}
