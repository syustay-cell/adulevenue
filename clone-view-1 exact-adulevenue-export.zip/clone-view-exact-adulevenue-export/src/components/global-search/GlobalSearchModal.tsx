import React, { useEffect, useRef, useState } from "react";
import { useGlobalSearch } from "./hooks/useGlobalSearch";
import { SearchResultRow } from "./SearchResultRow";
import { Search, X } from "lucide-react";

type GlobalSearchModalProps = {
  isOpen: boolean;
  onClose: () => void;
};

export function GlobalSearchModal({ isOpen, onClose }: GlobalSearchModalProps) {
  const [term, setTerm] = useState("");
  const inputRef = useRef<HTMLInputElement | null>(null);
  const { data, isLoading } = useGlobalSearch(term);

  useEffect(() => {
    if (isOpen && inputRef.current) {
      // small timeout to ensure focus after render
      const t = setTimeout(() => inputRef.current?.focus(), 50);
      return () => clearTimeout(t);
    }
  }, [isOpen]);

  // Reset search term when modal closes
  useEffect(() => {
    if (!isOpen) {
      setTerm("");
    }
  }, [isOpen]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center bg-background/80 backdrop-blur-sm">
      <div className="mt-24 w-full max-w-2xl bg-card border border-border rounded-lg shadow-lg overflow-hidden flex flex-col">
        {/* Header / Input */}
        <div className="border-b border-border px-4 py-3 flex items-center gap-2">
          <Search className="h-4 w-4 text-muted-foreground" />
          <input
            ref={inputRef}
            value={term}
            onChange={(e) => setTerm(e.target.value)}
            placeholder="Search by name, business, email, phone, or WF ID…"
            className="flex-1 outline-none text-sm bg-transparent text-foreground placeholder:text-muted-foreground"
          />
          <button
            className="text-xs text-muted-foreground hover:text-foreground flex items-center gap-1"
            onClick={onClose}
          >
            <X className="h-4 w-4" />
            <span className="hidden sm:inline">Esc</span>
          </button>
        </div>

        {/* Results */}
        <div className="max-h-[60vh] overflow-y-auto">
          {isLoading && (
            <div className="px-4 py-3 text-xs text-muted-foreground">
              Searching…
            </div>
          )}

          {!isLoading && term.length < 2 && (
            <div className="px-4 py-3 text-xs text-muted-foreground">
              Type at least 2 characters to search.
            </div>
          )}

          {!isLoading && term.length >= 2 && (!data || data.length === 0) && (
            <div className="px-4 py-3 text-xs text-muted-foreground">
              No clients found for "{term}".
            </div>
          )}

          {!isLoading &&
            data &&
            data.map((result) => (
              <div key={result.id} className="border-b border-border last:border-b-0">
                <SearchResultRow
                  result={result}
                  onSelect={onClose}
                />
              </div>
            ))}

          {!isLoading && data && data.length === 20 && (
            <div className="px-4 py-2 text-[11px] text-muted-foreground">
              Showing first 20 results. Refine your search for more specific matches.
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
