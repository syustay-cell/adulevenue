import React from "react";
import { usePuzzlePanelContext } from "@/components/puzzle-panel/PuzzlePanelContext";
import { Phone, Mail } from "lucide-react";
import type { SearchResult } from "./hooks/useGlobalSearch";
import { useUserRoles } from "@/hooks/useUserRoles";
import { canViewRawPii, maskEmail, maskPhone } from "@/lib/masking";
import type { AppRole } from "@/lib/permissions";

type SearchResultRowProps = {
  result: SearchResult;
  onSelect?: () => void;
};

export function SearchResultRow({ result, onSelect }: SearchResultRowProps) {
  const { openPanel } = usePuzzlePanelContext();
  const { roles } = useUserRoles();
  const canViewPii = canViewRawPii((roles as AppRole[]) || []);

  const hasFunding = (result.deal_count ?? 0) > 0 || (result.fta_count ?? 0) > 0;
  const hasCredit = (result.credit_count ?? 0) > 0;

  const handleClick = () => {
    openPanel(result.id);
    if (onSelect) onSelect();
  };

  return (
    <button
      type="button"
      onClick={handleClick}
      className="w-full text-left px-3 py-2 rounded hover:bg-muted/50 flex flex-col gap-1 transition-colors"
    >
      <div className="flex items-center justify-between gap-2">
        <div className="flex flex-col min-w-0">
          <div className="flex items-center gap-2">
            <span className="text-xs font-mono text-muted-foreground">
              {result.vault_id || "WF-??????"}
            </span>
            <span className="font-medium truncate text-foreground">
              {result.full_name || "Unknown Client"}
            </span>
          </div>
          {result.business_name && (
            <div className="text-xs text-muted-foreground truncate">
              {result.business_name}
            </div>
          )}
        </div>
      </div>

      <div className="flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
        {result.email_primary && (
          <span className="flex items-center gap-1">
            <Mail className="h-3 w-3" />
            {canViewPii ? result.email_primary : maskEmail(result.email_primary)}
          </span>
        )}
        {result.phone_primary && (
          <span className="flex items-center gap-1">
            <Phone className="h-3 w-3" />
            {canViewPii ? result.phone_primary : maskPhone(result.phone_primary)}
          </span>
        )}

        <span className="ml-auto flex gap-1">
          <Badge active={hasFunding} label="Funding" />
          <Badge active={hasCredit} label="Credit" />
        </span>
      </div>
    </button>
  );
}

function Badge({ active, label }: { active: boolean; label: string }) {
  return (
    <span
      className={`px-2 py-0.5 rounded-full border text-[10px] ${
        active
          ? "border-foreground text-foreground"
          : "border-border text-muted-foreground"
      }`}
    >
      {label}
    </span>
  );
}
