import { HelpCircle } from "lucide-react";

interface WolfHelpButtonProps {
  onClick: () => void;
}

export const WolfHelpButton = ({ onClick }: WolfHelpButtonProps) => {
  return (
    <button
      type="button"
      onClick={onClick}
      className="fixed bottom-6 right-6 z-40 flex h-12 w-12 items-center justify-center rounded-full bg-emerald-500 text-white shadow-lg shadow-emerald-500/30 transition-all hover:scale-105 hover:bg-emerald-400 hover:shadow-emerald-500/40"
      aria-label="Open Wolf Assistant"
    >
      <HelpCircle className="h-6 w-6" />
    </button>
  );
};
