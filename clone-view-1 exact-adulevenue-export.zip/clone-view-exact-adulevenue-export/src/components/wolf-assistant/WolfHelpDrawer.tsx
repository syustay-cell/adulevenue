import { useState } from "react";
import { X, Send, Loader2, Sparkles } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { ScrollArea } from "@/components/ui/scroll-area";

interface WolfHelpDrawerProps {
  open: boolean;
  onClose: () => void;
  userRole: string;
  userEmail: string;
  entity?: { type: string; id: string } | null;
}

interface Message {
  role: "user" | "assistant";
  content: string;
}

export const WolfHelpDrawer = ({
  open,
  onClose,
  userRole,
  userEmail,
  entity,
}: WolfHelpDrawerProps) => {
  const [question, setQuestion] = useState("");
  const [messages, setMessages] = useState<Message[]>([]);
  const [loading, setLoading] = useState(false);

  const ask = async () => {
    if (!question.trim() || loading) return;
    
    const userMessage = question.trim();
    setQuestion("");
    setMessages((prev) => [...prev, { role: "user", content: userMessage }]);
    setLoading(true);

    try {
      const page = window.location.pathname;

      const { data, error } = await supabase.functions.invoke("wolf-assistant", {
        body: {
          role: userRole,
          email: userEmail,
          page,
          entity: entity ?? null,
          question: userMessage,
        },
      });

      if (error) throw error;
      setMessages((prev) => [
        ...prev,
        { role: "assistant", content: data?.answer || "No response received." },
      ]);
    } catch (e: any) {
      setMessages((prev) => [
        ...prev,
        { role: "assistant", content: `Error: ${e.message || "Unknown error occurred."}` },
      ]);
    } finally {
      setLoading(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      ask();
    }
  };

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 flex justify-end">
      {/* Backdrop */}
      <div
        className="absolute inset-0 bg-black/60 backdrop-blur-sm"
        onClick={onClose}
      />

      {/* Drawer */}
      <div className="relative flex h-full w-full max-w-md flex-col bg-slate-950 shadow-2xl animate-in slide-in-from-right duration-300">
        {/* Header */}
        <header className="flex items-center justify-between border-b border-slate-800 px-4 py-4">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-gradient-to-br from-emerald-400 to-emerald-600">
              <Sparkles className="h-5 w-5 text-white" />
            </div>
            <div>
              <h2 className="text-sm font-semibold text-white">Wolf Assistant</h2>
              <p className="text-[11px] text-slate-400">
                {userRole} · {window.location.pathname}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="flex h-8 w-8 items-center justify-center rounded-full bg-slate-800 text-slate-400 transition-colors hover:bg-slate-700 hover:text-white"
          >
            <X className="h-4 w-4" />
          </button>
        </header>

        {/* Messages */}
        <ScrollArea className="flex-1 px-4 py-4">
          {messages.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-12 text-center">
              <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-slate-800">
                <Sparkles className="h-8 w-8 text-emerald-400" />
              </div>
              <h3 className="mb-2 text-sm font-medium text-white">
                How can I help?
              </h3>
              <p className="max-w-xs text-[12px] text-slate-400">
                Ask me about this page, how to process leads, what buttons do,
                or explain any workflow in the system.
              </p>
              
              {/* Quick actions */}
              <div className="mt-6 flex flex-wrap justify-center gap-2">
                {getQuickActions(userRole).map((action, i) => (
                  <button
                    key={i}
                    type="button"
                    onClick={() => {
                      setQuestion(action);
                    }}
                    className="rounded-full border border-slate-700 bg-slate-900 px-3 py-1.5 text-[11px] text-slate-300 transition-colors hover:border-emerald-500/50 hover:bg-slate-800"
                  >
                    {action}
                  </button>
                ))}
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              {messages.map((msg, i) => (
                <div
                  key={i}
                  className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}
                >
                  <div
                    className={`max-w-[85%] rounded-2xl px-4 py-2.5 text-[13px] ${
                      msg.role === "user"
                        ? "bg-emerald-500 text-white"
                        : "bg-slate-800 text-slate-100"
                    }`}
                  >
                    <p className="whitespace-pre-wrap">{msg.content}</p>
                  </div>
                </div>
              ))}
              {loading && (
                <div className="flex justify-start">
                  <div className="flex items-center gap-2 rounded-2xl bg-slate-800 px-4 py-2.5 text-slate-400">
                    <Loader2 className="h-4 w-4 animate-spin" />
                    <span className="text-[12px]">Thinking...</span>
                  </div>
                </div>
              )}
            </div>
          )}
        </ScrollArea>

        {/* Input */}
        <footer className="border-t border-slate-800 p-4">
          <div className="flex items-end gap-2">
            <textarea
              value={question}
              onChange={(e) => setQuestion(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Ask Wolf anything about this page..."
              className="flex-1 resize-none rounded-xl border border-slate-700 bg-slate-900 px-4 py-3 text-[13px] text-white placeholder:text-slate-500 focus:border-emerald-500 focus:outline-none focus:ring-1 focus:ring-emerald-500"
              rows={2}
            />
            <button
              type="button"
              onClick={ask}
              disabled={loading || !question.trim()}
              className="flex h-11 w-11 items-center justify-center rounded-xl bg-emerald-500 text-white transition-all hover:bg-emerald-400 disabled:opacity-50"
            >
              {loading ? (
                <Loader2 className="h-5 w-5 animate-spin" />
              ) : (
                <Send className="h-5 w-5" />
              )}
            </button>
          </div>
        </footer>
      </div>
    </div>
  );
};

function getQuickActions(role: string): string[] {
  switch (role) {
    case "admin":
      return [
        "What's on this page?",
        "How do I approve workers?",
        "Show underwriting steps",
      ];
    case "worker":
    case "iso":
      return [
        "How do I submit a deal?",
        "What do lead statuses mean?",
        "How do locks work?",
      ];
    case "credit_repair_specialist":
      return [
        "How do I generate disputes?",
        "Explain case statuses",
        "What's next for this case?",
      ];
    case "underwriter":
      return [
        "How do I start underwriting?",
        "Explain funding call flow",
        "What metrics matter?",
      ];
    default:
      return [
        "What can I do here?",
        "How does this work?",
        "Help me get started",
      ];
  }
}
