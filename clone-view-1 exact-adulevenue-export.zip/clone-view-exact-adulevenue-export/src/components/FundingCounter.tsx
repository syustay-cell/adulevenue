import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { DollarSign } from "lucide-react";

const FundingCounter = () => {
  const [totalFunded, setTotalFunded] = useState(345000); // 345 million in thousands
  const [monthlyFunded, setMonthlyFunded] = useState(11200); // 11.2 million in thousands
  const [yearlyFunded, setYearlyFunded] = useState(118000); // 118 million in thousands
  const [businessesHelped, setBusinessesHelped] = useState(10247);
  const [timeOfDay, setTimeOfDay] = useState("");

  const getTimeOfDay = () => {
    const hour = new Date().getHours();
    if (hour >= 6 && hour < 12) return "Morning";
    if (hour >= 12 && hour < 18) return "Afternoon";
    return "Evening";
  };

  useEffect(() => {
    setTimeOfDay(getTimeOfDay());
    
    // Update values based on time of day
    const updateValues = () => {
      const currentTime = getTimeOfDay();
      setTimeOfDay(currentTime);
      
      // Increment values realistically (in thousands)
      setTotalFunded(prev => prev + Math.floor(Math.random() * 50) + 25);
      setMonthlyFunded(prev => prev + Math.floor(Math.random() * 15) + 5);
      setYearlyFunded(prev => prev + Math.floor(Math.random() * 50) + 25);
      setBusinessesHelped(prev => prev + Math.floor(Math.random() * 3) + 1);
    };

    // Check every minute if we've entered a new period
    const interval = setInterval(() => {
      const newTimeOfDay = getTimeOfDay();
      if (newTimeOfDay !== timeOfDay) {
        updateValues();
      }
    }, 60000); // Check every minute

    return () => clearInterval(interval);
  }, [timeOfDay]);

  const formatMillionsFromThousands = (num: number) => {
    return `${Math.round(num / 1000)}M`;
  };

  const formatThousands = (num: number) => {
    return `${Math.floor(num / 1000)}K`;
  };

  const formatNumber = (num: number) => {
    return new Intl.NumberFormat("en-US").format(num);
  };

  return (
    <div className="bg-gradient-to-br from-secondary via-navy-light to-secondary p-8 rounded-2xl border border-primary/20 shadow-2xl">
      <div className="flex items-center justify-center mb-6">
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
          className="mr-3"
        >
          <DollarSign className="text-primary w-8 h-8" />
        </motion.div>
        <h3 className="text-2xl font-bold text-white">Funding Tracker</h3>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
        <motion.div
          className="text-center bg-background/10 backdrop-blur-sm rounded-lg p-4 border border-primary/10"
          key={totalFunded}
          initial={{ scale: 1 }}
          animate={{ scale: [1, 1.05, 1] }}
          transition={{ duration: 0.3 }}
        >
          <div className="text-3xl font-bold text-primary mb-1">
            ${formatMillionsFromThousands(totalFunded)}
          </div>
          <div className="text-sm text-white/80">Total Funded (Last 5 Years)</div>
        </motion.div>

        <motion.div
          className="text-center bg-background/10 backdrop-blur-sm rounded-lg p-4 border border-primary/10"
          key={monthlyFunded}
          initial={{ scale: 1 }}
          animate={{ scale: [1, 1.05, 1] }}
          transition={{ duration: 0.3 }}
        >
          <div className="text-3xl font-bold text-primary mb-1">
            ${formatMillionsFromThousands(monthlyFunded)}
          </div>
          <div className="text-sm text-white/80">Funded This Month</div>
        </motion.div>

        <motion.div
          className="text-center bg-background/10 backdrop-blur-sm rounded-lg p-4 border border-primary/10"
          key={yearlyFunded}
          initial={{ scale: 1 }}
          animate={{ scale: [1, 1.05, 1] }}
          transition={{ duration: 0.3 }}
        >
          <div className="text-3xl font-bold text-primary mb-1">
            ${formatMillionsFromThousands(yearlyFunded)}
          </div>
          <div className="text-sm text-white/80">Funded This Year</div>
        </motion.div>

        <motion.div
          className="text-center bg-background/10 backdrop-blur-sm rounded-lg p-4 border border-primary/10"
          key={businessesHelped}
          initial={{ scale: 1 }}
          animate={{ scale: [1, 1.05, 1] }}
          transition={{ duration: 0.3 }}
        >
          <div className="text-3xl font-bold text-primary mb-1">
            {formatNumber(businessesHelped)}+
          </div>
          <div className="text-sm text-white/80">Businesses Funded</div>
        </motion.div>
      </div>

      <motion.div
        className="mt-4 text-center"
        animate={{ opacity: [0.5, 1, 0.5] }}
        transition={{ duration: 2, repeat: Infinity }}
      >
        <span className="text-primary text-sm font-semibold">● UPDATED 3× DAILY</span>
        <span className="text-white/60 text-xs ml-2">{timeOfDay} Update</span>
      </motion.div>
    </div>
  );
};

export default FundingCounter;
