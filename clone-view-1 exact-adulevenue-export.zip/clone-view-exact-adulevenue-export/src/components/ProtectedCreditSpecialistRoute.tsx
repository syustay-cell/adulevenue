import { ReactNode } from "react";
import { Navigate, Link } from "react-router-dom";
import { useUserRoles, userHasRole } from "@/hooks/useUserRoles";
import { AuthGateError } from "@/components/auth/AuthGateError";

type Props = {
  children: ReactNode;
};

export const ProtectedCreditSpecialistRoute = ({ children }: Props) => {
  const { loading, user, roles, error } = useUserRoles();

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (error) {
    return <AuthGateError message={error} />;
  }

  if (!user) {
    return <Navigate to="/auth" replace />;
  }

  const allowed = userHasRole(roles, ["admin", "credit_repair_specialist"]);

  if (!allowed) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4">
        <div className="text-center">
          <h1 className="text-4xl font-bold text-foreground mb-4">Access Denied</h1>
          <p className="text-muted-foreground mb-4">You need credit repair specialist privileges to access this page.</p>
          <Link to="/" className="text-primary hover:underline">Go to homepage</Link>
        </div>
      </div>
    );
  }

  return <>{children}</>;
};

export default ProtectedCreditSpecialistRoute;
