import { useState, useEffect } from "react";
import { useLocation } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { HelpCircle, X, Loader2, Send, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";

interface Message {
  role: "user" | "assistant";
  content: string;
}

const quickActions: Record<string, { label: string; prompt: string }[]> = {
  admin: [
    { label: "Show unviewed apps", prompt: "Show all unviewed applications" },
    { label: "ISO performance", prompt: "View ISO performance report" },
  ],
  worker: [
    { label: "Start Fast Track", prompt: "Help me start a new Fast Track application" },
    { label: "Today's follow-ups", prompt: "Show my follow-ups for today" },
  ],
  credit_repair_specialist: [
    { label: "Generate dispute", prompt: "Generate a dispute letter for current case" },
    { label: "Overdue cases", prompt: "Show overdue credit repair cases" },
  ],
  default: [
    { label: "How does this work?", prompt: "How does Wolf Fund work?" },
    { label: "Get help", prompt: "I need help with this page" },
  ],
};

export function WolfAssistantGlobal() {
  const location = useLocation();
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [context, setContext] = useState<{
    role: string | null;
    email: string | null;
  }>({ role: null, email: null });

  useEffect(() => {
    loadUserContext();
  }, []);

  const loadUserContext = async () => {
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) return;

    const { data: roles } = await supabase
      .from("user_roles")
      .select("role")
      .eq("user_id", session.user.id)
      .eq("approved", true);

    const primaryRole = roles?.[0]?.role || "user";
    setContext({
      role: primaryRole,
      email: session.user.email || null,
    });
  };

  const sendMessage = async (text: string) => {
    if (!text.trim()) return;

    const userMessage: Message = { role: "user", content: text };
    setMessages((prev) => [...prev, userMessage]);
    setInput("");
    setLoading(true);

    try {
      const { data, error } = await supabase.functions.invoke("wolf-assistant", {
        body: {
          question: text,
          role: context.role,
          email: context.email,
          page: location.pathname,
        },
      });

      let content = "No response.";
      if (error) {
        content = "Sorry, I couldn't process that. Please try again.";
      } else if (!data?.ok && data?.error_code) {
        content = data.error_code === 'AI_PAUSED' 
          ? "Wolf AI is temporarily unavailable. Please try again later."
          : (data.message || "Sorry, something went wrong.");
      } else if (data?.answer) {
        content = data.answer;
      }

      setMessages((prev) => [...prev, { role: "assistant", content }]);
    } catch (err) {
      setMessages((prev) => [
        ...prev,
        { role: "assistant", content: "Something went wrong. Please try again." },
      ]);
    } finally {
      setLoading(false);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendMessage(input);
    }
  };

  const actions = quickActions[context.role || "default"] || quickActions.default;

  return (
    <>
      {/* Floating Button */}
      <button
        onClick={() => setOpen(true)}
        className={`fixed bottom-6 right-6 z-50 flex h-12 w-12 items-center justify-center rounded-full bg-primary text-primary-foreground shadow-lg transition-all hover:scale-105 hover:shadow-xl ${
          open ? "scale-0 opacity-0" : "scale-100 opacity-100"
        }`}
        aria-label="Open Wolf Assistant"
      >
        <HelpCircle className="h-5 w-5" />
      </button>

      {/* Chat Panel */}
      {open && (
        <div className="fixed bottom-6 right-6 z-50 w-80 sm:w-96 rounded-2xl border border-slate-800 bg-slate-950/95 shadow-2xl backdrop-blur-xl">
          {/* Header */}
          <div className="flex items-center justify-between border-b border-slate-800 px-4 py-3">
            <div className="flex items-center gap-2">
              <Sparkles className="h-4 w-4 text-primary" />
              <span className="text-sm font-medium text-slate-100">Wolf Assistant</span>
            </div>
            <button
              onClick={() => setOpen(false)}
              className="rounded-full p-1 text-slate-400 hover:bg-slate-800 hover:text-slate-100"
            >
              <X className="h-4 w-4" />
            </button>
          </div>

          {/* Context Badge */}
          <div className="border-b border-slate-800/50 px-4 py-2">
            <div className="flex flex-wrap gap-1.5 text-[10px]">
              {context.role && (
                <span className="rounded-full bg-primary/10 px-2 py-0.5 text-primary">
                  {context.role}
                </span>
              )}
              <span className="rounded-full bg-slate-800 px-2 py-0.5 text-slate-400">
                {location.pathname}
              </span>
            </div>
          </div>

          {/* Messages */}
          <ScrollArea className="h-64 px-4 py-3">
            {messages.length === 0 ? (
              <div className="space-y-3">
                <p className="text-xs text-slate-500">
                  Ask me anything about this page, your clients, or how Wolf Fund works.
                </p>
                <div className="flex flex-wrap gap-2">
                  {actions.map(({ label, prompt }) => (
                    <Button
                      key={label}
                      variant="outline"
                      size="sm"
                      onClick={() => sendMessage(prompt)}
                      className="h-7 text-[10px] border-slate-700 hover:border-primary/50"
                    >
                      {label}
                    </Button>
                  ))}
                </div>
              </div>
            ) : (
              <div className="space-y-3">
                {messages.map((msg, idx) => (
                  <div
                    key={idx}
                    className={`rounded-lg px-3 py-2 text-xs ${
                      msg.role === "user"
                        ? "bg-primary/10 text-primary ml-8"
                        : "bg-slate-800 text-slate-200 mr-8"
                    }`}
                  >
                    {msg.content}
                  </div>
                ))}
                {loading && (
                  <div className="flex items-center gap-2 text-xs text-slate-500">
                    <Loader2 className="h-3 w-3 animate-spin" />
                    Thinking...
                  </div>
                )}
              </div>
            )}
          </ScrollArea>

          {/* Input */}
          <div className="border-t border-slate-800 p-3">
            <div className="flex gap-2">
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyPress={handleKeyPress}
                placeholder="Ask Wolf..."
                className="flex-1 rounded-lg border border-slate-700 bg-slate-900 px-3 py-2 text-xs text-slate-100 placeholder:text-slate-500 focus:border-primary focus:outline-none"
              />
              <Button
                size="sm"
                onClick={() => sendMessage(input)}
                disabled={loading || !input.trim()}
                className="h-8 w-8 p-0"
              >
                <Send className="h-3.5 w-3.5" />
              </Button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
