import { useState } from "react";
import { useLocation } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Loader2, X } from "lucide-react";

export interface WolfAssistantContext {
  role: string | null;
  email: string | null;
  page: string;
  entity?: {
    type: "application" | "case" | "lead" | "user" | "unknown";
    id: string;
  } | null;
}

interface WolfAssistantDrawerProps {
  open: boolean;
  onClose: () => void;
  context: WolfAssistantContext;
}

export const WolfAssistantDrawer = ({
  open,
  onClose,
  context,
}: WolfAssistantDrawerProps) => {
  const [question, setQuestion] = useState("");
  const [answer, setAnswer] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!open) return null;

  const handleAsk = async () => {
    if (!question.trim()) return;
    setLoading(true);
    setError(null);
    setAnswer(null);

    try {
      const { data, error: invokeError } = await supabase.functions.invoke(
        "wolf-assistant",
        {
          body: {
            question,
            role: context.role,
            email: context.email,
            page: context.page,
            entity: context.entity ?? null,
          },
        }
      );

      if (invokeError) {
        console.error("Wolf Assistant transport error:", invokeError);
        setError("Connection issue. Please try again.");
      } else if (!data?.ok && data?.error_code) {
        setError(data.error_code === 'AI_PAUSED' 
          ? "Wolf AI is temporarily unavailable. Please try again later."
          : (data.message || "Something went wrong."));
      } else {
        setAnswer(data?.answer || "No answer returned.");
      }
    } catch (err: any) {
      console.error("Wolf Assistant error:", err);
      setError("Something went wrong asking Wolf. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleAsk();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex justify-end">
      {/* Backdrop */}
      <div
        className="flex-1 bg-black/30"
        onClick={onClose}
        aria-hidden="true"
      />
      
      {/* Drawer */}
      <aside className="w-full max-w-md bg-white shadow-xl flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-200 px-4 py-3">
          <div>
            <h2 className="text-sm font-semibold text-slate-900">
              Wolf Assistant
            </h2>
            <p className="text-xs text-slate-500">
              Context-aware help for Wolf Back Office.
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="rounded-full p-1 text-slate-500 hover:bg-slate-100"
          >
            <X className="h-4 w-4" />
            <span className="sr-only">Close</span>
          </button>
        </div>

        {/* Context chips */}
        <div className="border-b border-slate-100 px-4 py-2 text-[11px] text-slate-500 flex flex-wrap gap-2">
          {context.email && (
            <span className="rounded-full bg-slate-100 px-2 py-0.5">
              {context.email}
            </span>
          )}
          {context.role && (
            <span className="rounded-full bg-slate-100 px-2 py-0.5 uppercase">
              {context.role}
            </span>
          )}
          <span className="rounded-full bg-slate-100 px-2 py-0.5">
            {context.page}
          </span>
          {context.entity?.id && (
            <span className="rounded-full bg-amber-50 px-2 py-0.5 text-amber-700">
              {context.entity.type} #{context.entity.id.slice(0, 6)}…
            </span>
          )}
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto px-4 py-3 text-sm">
          {!answer && !error && !loading && (
            <p className="text-xs text-slate-500 mb-2">
              Ask how to use this screen, what to do next with a client, or how
              funding ↔ credit repair works.
            </p>
          )}

          {loading && (
            <div className="flex items-center gap-2 text-xs text-slate-500">
              <Loader2 className="h-3 w-3 animate-spin" />
              Wolf is thinking…
            </div>
          )}

          {error && (
            <p className="text-xs text-rose-600 bg-rose-50 border border-rose-100 rounded-lg px-3 py-2">
              {error}
            </p>
          )}

          {answer && (
            <div className="rounded-lg bg-slate-50 border border-slate-200 px-3 py-2 whitespace-pre-wrap text-xs text-slate-800">
              {answer}
            </div>
          )}
        </div>

        {/* Footer: question input */}
        <div className="border-t border-slate-200 px-4 py-3">
          <div className="flex flex-col gap-2">
            <textarea
              rows={2}
              className="w-full rounded-lg border border-slate-200 px-3 py-2 text-xs focus:outline-none focus:ring-2 focus:ring-amber-400"
              placeholder="Ask Wolf anything about this page, this client, or what to do next…"
              value={question}
              onChange={(e) => setQuestion(e.target.value)}
              onKeyPress={handleKeyPress}
            />
            <button
              type="button"
              onClick={handleAsk}
              disabled={loading || !question.trim()}
              className="inline-flex items-center justify-center rounded-lg bg-black px-3 py-2 text-xs font-medium text-white hover:bg-slate-900 disabled:opacity-60 disabled:cursor-not-allowed"
            >
              {loading ? "Asking…" : "Ask Wolf"}
            </button>
          </div>
        </div>
      </aside>
    </div>
  );
};
