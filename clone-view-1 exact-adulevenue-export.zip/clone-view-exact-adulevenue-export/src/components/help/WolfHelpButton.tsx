interface WolfHelpButtonProps {
  onClick: () => void;
}

export const WolfHelpButton = ({ onClick }: WolfHelpButtonProps) => {
  return (
    <button
      type="button"
      onClick={onClick}
      className="fixed bottom-5 right-5 z-40 inline-flex h-12 w-12 items-center justify-center rounded-full bg-black text-white shadow-lg hover:bg-slate-900 focus:outline-none focus:ring-2 focus:ring-amber-400"
      aria-label="Open Wolf Assistant"
    >
      <span className="text-xl font-bold">?</span>
    </button>
  );
};
