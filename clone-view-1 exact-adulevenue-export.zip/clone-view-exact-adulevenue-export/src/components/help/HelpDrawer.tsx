import { useState } from "react";
import { useLocation } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Loader2, X } from "lucide-react";

type HelpDrawerProps = {
  onClose: () => void;
};

export const HelpDrawer = ({ onClose }: HelpDrawerProps) => {
  const location = useLocation();
  const [question, setQuestion] = useState("");
  const [answer, setAnswer] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const handleAsk = async () => {
    if (!question.trim()) return;
    setLoading(true);
    setAnswer(null);

    try {
      const { data: userData } = await supabase.auth.getUser();
      const user = userData.user;

      // Get user role
      const { data: roleData } = await supabase
        .from("user_roles")
        .select("role")
        .eq("user_id", user?.id)
        .eq("approved", true)
        .single();

      const { data, error } = await supabase.functions.invoke("wolf-assistant", {
        body: {
          role: roleData?.role || "user",
          email: user?.email,
          page: location.pathname,
          question,
        },
      });

      if (error) {
        console.error("Wolf Assistant transport error:", error);
        setAnswer("Sorry, connection issue. Please try again.");
      } else if (!data?.ok && data?.error_code) {
        setAnswer(data.error_code === 'AI_PAUSED' 
          ? "Wolf AI is temporarily unavailable. Please try again later."
          : (data.message || "Sorry, something went wrong."));
      } else {
        setAnswer(data?.answer ?? "No response.");
      }
    } catch (err) {
      console.error(err);
      setAnswer("Sorry, something went wrong. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleAsk();
    }
  };

  return (
    <div className="fixed inset-y-0 right-0 z-50 flex w-full max-w-md flex-col border-l border-slate-200 bg-white shadow-xl">
      <div className="flex items-center justify-between border-b border-slate-200 px-4 py-3">
        <div>
          <h2 className="text-sm font-semibold text-slate-900">Wolf Assistant</h2>
          <p className="text-xs text-slate-500">
            Ask anything about this page or client. I'll answer in plain English.
          </p>
        </div>
        <button
          type="button"
          onClick={onClose}
          className="rounded-full p-1 text-slate-400 hover:bg-slate-100 hover:text-slate-600"
          aria-label="Close Wolf Assistant"
        >
          <X className="h-4 w-4" />
        </button>
      </div>

      <div className="flex-1 overflow-y-auto px-4 py-3 text-sm">
        {answer ? (
          <div className="rounded-lg bg-slate-50 p-3 text-slate-800 whitespace-pre-wrap">
            {answer}
          </div>
        ) : (
          <p className="text-xs text-slate-400">
            I'll use your role, page, and current record to give you the most useful answer.
          </p>
        )}
      </div>

      <div className="border-t border-slate-200 px-4 py-3">
        <textarea
          rows={3}
          className="w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-xs text-slate-800 outline-none focus:border-slate-400"
          placeholder="Ask a question, e.g. 'What's the next step for this case?'"
          value={question}
          onChange={(e) => setQuestion(e.target.value)}
          onKeyPress={handleKeyPress}
        />
        <div className="mt-2 flex justify-end">
          <button
            type="button"
            onClick={handleAsk}
            disabled={loading || !question.trim()}
            className="inline-flex items-center gap-2 rounded-lg bg-slate-900 px-3 py-1.5 text-xs font-medium text-white hover:bg-slate-800 disabled:opacity-60 disabled:cursor-not-allowed"
          >
            {loading && <Loader2 className="h-3 w-3 animate-spin" />}
            {loading ? "Thinking…" : "Ask Wolf"}
          </button>
        </div>
      </div>
    </div>
  );
};
