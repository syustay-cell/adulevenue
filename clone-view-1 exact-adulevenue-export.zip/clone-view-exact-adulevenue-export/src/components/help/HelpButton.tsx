import { useState } from "react";
import { HelpDrawer } from "./HelpDrawer";

export const HelpButton = () => {
  const [open, setOpen] = useState(false);

  return (
    <>
      <button
        type="button"
        onClick={() => setOpen(true)}
        className="fixed bottom-4 right-4 z-40 flex h-11 w-11 items-center justify-center rounded-full bg-slate-900 text-sm font-semibold text-white shadow-lg hover:bg-slate-800 transition-all"
        aria-label="Open Wolf Assistant"
      >
        ?
      </button>

      {open && <HelpDrawer onClose={() => setOpen(false)} />}
    </>
  );
};
