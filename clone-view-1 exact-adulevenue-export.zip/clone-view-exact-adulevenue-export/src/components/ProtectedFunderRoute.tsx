import { useEffect, useState } from "react";
import { Navigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { AuthGateError } from "@/components/auth/AuthGateError";

interface ProtectedFunderRouteProps {
  children: React.ReactNode;
}

export function ProtectedFunderRoute({ children }: ProtectedFunderRouteProps) {
  const [loading, setLoading] = useState(true);
  const [isFunder, setIsFunder] = useState(false);
  const [hasUser, setHasUser] = useState<boolean | null>(null);
  const [authError, setAuthError] = useState<string | null>(null);

  useEffect(() => {
    const checkFunderAccess = async () => {
      try {
        const { data: { user }, error: userError } = await supabase.auth.getUser();
        if (userError) {
          setAuthError(userError.message);
          setHasUser(false);
          return;
        }
        if (!user) {
          setHasUser(false);
          setLoading(false);
          return;
        }
        setHasUser(true);

        // Check if user is a funder (has a funder record linked to their user_id)
        const { data: funder, error: funderError } = await supabase
          .from("funders")
          .select("id")
          .eq("user_id", user.id)
          .single();

        if (funderError) {
          setAuthError(funderError.message);
          return;
        }

        setIsFunder(!!funder);
      } catch (error) {
        console.error("Error checking funder access:", error);
        setAuthError(error instanceof Error ? error.message : "Unknown error");
      } finally {
        setLoading(false);
      }
    };

    checkFunderAccess();
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (authError) {
    return <AuthGateError message={authError} />;
  }

  if (hasUser === false) {
    return <Navigate to="/auth" replace />;
  }

  if (!isFunder) {
    return <Navigate to="/auth" replace />;
  }

  return <>{children}</>;
}
