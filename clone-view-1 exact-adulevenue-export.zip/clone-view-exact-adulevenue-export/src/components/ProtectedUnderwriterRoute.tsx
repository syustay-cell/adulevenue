import { ReactNode } from "react";
import { Navigate } from "react-router-dom";
import { useUserRoles, userHasRole } from "@/hooks/useUserRoles";
import { AuthGateError } from "@/components/auth/AuthGateError";

type Props = {
  children: ReactNode;
};

export const ProtectedUnderwriterRoute = ({ children }: Props) => {
  const { loading, user, roles, error } = useUserRoles();

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (error) {
    return <AuthGateError message={error} />;
  }

  if (!user) {
    return <Navigate to="/auth" replace />;
  }

  const allowed = userHasRole(roles, ["admin", "underwriter"]);

  if (!allowed) {
    return <Navigate to="/" replace />;
  }

  return <>{children}</>;
};

export default ProtectedUnderwriterRoute;
