import { WolfCard } from "@/components/ui/WolfCard";
import { WolfStat } from "@/components/ui/WolfStat";
import type { LeadLane, FundingPath } from "@/types/leadEngine";

export interface ExecutiveIntelSummary {
  summary: string;
  riskFactors: string[];
  nextSteps: string[];
  missingInformation: string[];
  creditFixActions: string[];
  fundingPath: FundingPath;
  fundingScore: number | null;
  priorityBand: LeadLane["priorityBand"];
  creditRisk: LeadLane["creditRisk"];
}

interface ExecutiveIntelCardProps {
  data: ExecutiveIntelSummary;
  className?: string;
}

export function ExecutiveIntelCard({ data, className }: ExecutiveIntelCardProps) {
  const {
    summary,
    riskFactors,
    nextSteps,
    missingInformation,
    creditFixActions,
    fundingPath,
    fundingScore,
    priorityBand,
    creditRisk,
  } = data;

  const renderList = (title: string, items: string[]) => (
    <div>
      <h3 className="text-xs font-semibold uppercase tracking-wide text-muted-foreground mb-2">
        {title}
      </h3>
      {items.length > 0 ? (
        <ul className="space-y-1 text-xs text-foreground">
          {items.map((item, idx) => (
            <li key={`${title}-${idx}`} className="flex gap-2">
              <span className="text-muted-foreground">—</span>
              <span>{item}</span>
            </li>
          ))}
        </ul>
      ) : (
        <p className="text-xs text-muted-foreground">No items.</p>
      )}
    </div>
  );

  return (
    <WolfCard className={className}>
      <div className="space-y-4">
        <div>
          <p className="text-[11px] uppercase font-semibold tracking-wide text-muted-foreground">
            Executive Intelligence Summary
          </p>
          <p className="text-sm leading-relaxed text-foreground">{summary}</p>
        </div>

        <div className="grid gap-3 md:grid-cols-4 sm:grid-cols-2">
          <WolfStat label="Funding Path" value={fundingPath.replace(/_/g, " ")} />
          <WolfStat
            label="Funding Score"
            value={fundingScore !== null ? `${fundingScore}/100` : "—"}
          />
          <WolfStat label="Priority" value={priorityBand ?? "—"} />
          <WolfStat label="Credit Risk" value={creditRisk} />
        </div>

        <div className="grid gap-6 md:grid-cols-2">
          {renderList("Risk Factors", riskFactors)}
          {renderList("Next Steps", nextSteps)}
        </div>

        <div className="grid gap-6 md:grid-cols-2">
          {renderList("Missing Information", missingInformation)}
          {renderList("Credit Fix Actions", creditFixActions)}
        </div>
      </div>
    </WolfCard>
  );
}
