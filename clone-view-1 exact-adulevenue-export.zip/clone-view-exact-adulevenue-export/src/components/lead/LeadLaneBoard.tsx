import { LeadLane } from "@/types/leadEngine";
import { WolfCard } from "@/components/ui/WolfCard";

interface LeadLaneBoardProps {
  leads: LeadLane[];
}

const pathLabel: Record<LeadLane["fundingPath"], string> = {
  FUNDING_FIRST: "Funding First",
  CREDIT_FIRST: "Credit First",
  NEEDS_MORE_INFO: "Needs More Info",
};

function columnEmptyCopy(title: string) {
  return `No leads in ${title.toLowerCase()} lane.`;
}

export function LeadLaneBoard({ leads }: LeadLaneBoardProps) {
  const fundingFirst = leads.filter((lead) => lead.fundingPath === "FUNDING_FIRST");
  const creditFirst = leads.filter((lead) => lead.fundingPath === "CREDIT_FIRST");
  const needsMore = leads.filter((lead) => lead.fundingPath === "NEEDS_MORE_INFO");

  const renderColumn = (title: string, items: LeadLane[]) => (
    <div className="flex-1 min-w-[260px]">
      <h2 className="text-xs font-semibold uppercase tracking-wide mb-2 text-muted-foreground">
        {title}
      </h2>
      <div className="space-y-2">
        {items.map((lead) => (
          <WolfCard key={lead.id} className="p-3">
            <div className="flex items-center justify-between mb-1">
              <span className="text-xs font-semibold">{lead.businessName}</span>
              <span className="text-[10px] text-muted-foreground">
                {lead.priorityBand ? `Priority ${lead.priorityBand}` : "Unranked"}
              </span>
            </div>
            <p className="text-[11px] text-muted-foreground mb-1">
              {pathLabel[lead.fundingPath]} - Credit: {lead.creditRisk}
            </p>
            <p className="text-[10px] text-muted-foreground">
              Status: {lead.status.replace("_", " ")}
            </p>
          </WolfCard>
        ))}
        {items.length === 0 && (
          <p className="text-[11px] text-muted-foreground italic">
            {columnEmptyCopy(title)}
          </p>
        )}
      </div>
    </div>
  );

  return (
    <div className="flex gap-4 overflow-x-auto pb-2">
      {renderColumn("Funding First", fundingFirst)}
      {renderColumn("Credit First", creditFirst)}
      {renderColumn("Needs More Info", needsMore)}
    </div>
  );
}
