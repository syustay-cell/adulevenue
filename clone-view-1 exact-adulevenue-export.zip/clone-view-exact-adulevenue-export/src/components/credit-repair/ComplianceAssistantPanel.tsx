import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { AlertCircle, Scale, Shield } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";

interface ComplianceAssistantPanelProps {
  metro2Code?: string;
  fcraSection?: string;
  fdcpaSection?: string;
  standards?: Array<{
    standard_type: string;
    reference_code: string;
    description: string;
    jurisdiction: string;
  }>;
}

export const ComplianceAssistantPanel = ({
  metro2Code,
  fcraSection,
  fdcpaSection,
  standards = []
}: ComplianceAssistantPanelProps) => {
  
  // Filter standards based on selected compliance codes
  const relevantStandards = standards.filter(s => 
    (metro2Code && s.reference_code === metro2Code) ||
    (fcraSection && s.reference_code === fcraSection) ||
    (fdcpaSection && s.reference_code === fdcpaSection)
  );

  return (
    <Card className="border-primary/20">
      <CardHeader className="pb-3">
        <div className="flex items-center gap-2">
          <Scale className="h-5 w-5 text-primary" />
          <CardTitle className="text-lg">Legal & Compliance Assistant</CardTitle>
        </div>
        <CardDescription>
          AI-suggested compliance references for this dispute
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Compliance Code Badges */}
        <div className="space-y-2">
          {metro2Code && (
            <div className="flex items-center gap-2">
              <Badge variant="outline" className="bg-blue-50 border-blue-200">
                <Shield className="h-3 w-3 mr-1" />
                Metro 2: {metro2Code}
              </Badge>
            </div>
          )}
          {fcraSection && (
            <div className="flex items-center gap-2">
              <Badge variant="outline" className="bg-green-50 border-green-200">
                <Scale className="h-3 w-3 mr-1" />
                FCRA: {fcraSection}
              </Badge>
            </div>
          )}
          {fdcpaSection && (
            <div className="flex items-center gap-2">
              <Badge variant="outline" className="bg-amber-50 border-amber-200">
                <AlertCircle className="h-3 w-3 mr-1" />
                FDCPA: {fdcpaSection}
              </Badge>
            </div>
          )}
        </div>

        {/* Detailed Standards Information */}
        {relevantStandards.length > 0 && (
          <ScrollArea className="h-[200px] rounded-md border p-3">
            <div className="space-y-3">
              {relevantStandards.map((standard, idx) => (
                <div key={idx} className="space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="font-semibold text-sm">{standard.reference_code}</span>
                    <Badge variant="secondary" className="text-xs">
                      {standard.jurisdiction}
                    </Badge>
                  </div>
                  <p className="text-sm text-muted-foreground">{standard.description}</p>
                </div>
              ))}
            </div>
          </ScrollArea>
        )}

        {/* Legal Disclaimer */}
        <Alert variant="default" className="border-amber-200 bg-amber-50/50">
          <AlertCircle className="h-4 w-4 text-amber-600" />
          <AlertDescription className="text-xs text-amber-900">
            <strong>Disclaimer:</strong> This analysis is AI-assisted and based on published federal and industry standards.
            Information provided here is for dispute support and administrative processing only.
            Wolf Fund Corp does not provide legal advice. All actions must be reviewed by an authorized specialist before execution.
          </AlertDescription>
        </Alert>

        {/* All Standards Reference (Collapsed) */}
        {standards.length > 0 && (
          <details className="text-xs">
            <summary className="cursor-pointer text-muted-foreground hover:text-foreground">
              View All Standards Reference ({standards.length} total)
            </summary>
            <ScrollArea className="h-[150px] mt-2 rounded-md border p-2">
              <div className="space-y-2">
                {standards.map((standard, idx) => (
                  <div key={idx} className="pb-2 border-b last:border-0">
                    <div className="font-medium">{standard.reference_code}</div>
                    <div className="text-muted-foreground">{standard.description}</div>
                  </div>
                ))}
              </div>
            </ScrollArea>
          </details>
        )}
      </CardContent>
    </Card>
  );
};
