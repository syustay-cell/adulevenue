import { useState } from "react";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { Loader2, Sparkles, FileText, Lightbulb, Calendar } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

interface AIControlPanelProps {
  caseId: string;
  onAnalysisComplete?: () => void;
}

export const AIControlPanel = ({ caseId, onAnalysisComplete }: AIControlPanelProps) => {
  const { toast } = useToast();
  const [analyzing, setAnalyzing] = useState(false);
  const [generatingStrategy, setGeneratingStrategy] = useState(false);
  const [generatingLetters, setGeneratingLetters] = useState(false);
  const [suggestingFollowup, setSuggestingFollowup] = useState(false);
  const [suggestedItems, setSuggestedItems] = useState<any[]>([]);
  const [suggestedTasks, setSuggestedTasks] = useState<any[]>([]);

  const analyzeReport = async () => {
    setAnalyzing(true);
    try {
      const { data, error } = await supabase.functions.invoke('credit-repair-analyze-report', {
        body: { case_id: caseId }
      });

      if (error) {
        console.error('Analysis transport error:', error);
        toast({ title: "System Error", description: "Connection issue. Please try again.", variant: "destructive" });
        return;
      }

      if (!data?.ok) {
        toast({ 
          title: data?.error_code === 'AI_PAUSED' ? "AI Unavailable" : "Analysis Failed", 
          description: data?.message || 'Unable to analyze credit report',
          variant: data?.error_code === 'AI_PAUSED' ? "default" : "destructive"
        });
        return;
      }

      setSuggestedItems(data.suggested_items || []);
      toast({
        title: "Analysis Complete",
        description: `Found ${data.suggested_items?.length || 0} potential dispute items`
      });
      
      if (onAnalysisComplete) onAnalysisComplete();
    } catch (error: any) {
      console.error('Analysis error:', error);
      toast({ title: "Analysis Failed", description: 'Unexpected error occurred', variant: "destructive" });
    } finally {
      setAnalyzing(false);
    }
  };

  const generateStrategy = async () => {
    setGeneratingStrategy(true);
    try {
      // Get all items for this case
      const { data: items } = await supabase
        .from('credit_repair_items')
        .select('id')
        .eq('case_id', caseId);

      if (!items || items.length === 0) {
        toast({
          title: "No Items Found",
          description: "Add negative items before generating strategy",
          variant: "destructive"
        });
        return;
      }

      const itemIds = items.map(i => i.id);

      const { data, error } = await supabase.functions.invoke('credit-repair-generate-strategy', {
        body: { case_id: caseId, item_ids: itemIds }
      });

      if (error) {
        console.error('Strategy transport error:', error);
        toast({ title: "System Error", description: "Connection issue. Please try again.", variant: "destructive" });
        return;
      }

      if (!data?.ok) {
        toast({ 
          title: data?.error_code === 'AI_PAUSED' ? "AI Unavailable" : "Strategy Generation Failed", 
          description: data?.message || 'Unable to generate dispute strategy',
          variant: data?.error_code === 'AI_PAUSED' ? "default" : "destructive"
        });
        return;
      }

      toast({
        title: "Strategy Generated",
        description: `Updated ${data.updates?.length || 0} items with dispute strategies`
      });
      
      if (onAnalysisComplete) onAnalysisComplete();
    } catch (error: any) {
      console.error('Strategy error:', error);
      toast({ title: "Strategy Generation Failed", description: 'Unexpected error occurred', variant: "destructive" });
    } finally {
      setGeneratingStrategy(false);
    }
  };

  const generateLetters = async () => {
    setGeneratingLetters(true);
    try {
      const { data: items } = await supabase
        .from('credit_repair_items')
        .select('id')
        .eq('case_id', caseId);

      if (!items || items.length === 0) {
        toast({
          title: "No Items Found",
          description: "Add negative items before generating letters",
          variant: "destructive"
        });
        return;
      }

      const itemIds = items.map(i => i.id);

      const { data, error } = await supabase.functions.invoke('credit-repair-generate-letters', {
        body: { case_id: caseId, item_ids: itemIds }
      });

      if (error) {
        console.error('Letters transport error:', error);
        toast({ title: "System Error", description: "Connection issue. Please try again.", variant: "destructive" });
        return;
      }

      if (!data?.ok) {
        toast({ 
          title: data?.error_code === 'AI_PAUSED' ? "AI Unavailable" : "Letter Generation Failed", 
          description: data?.message || 'Unable to generate dispute letters',
          variant: data?.error_code === 'AI_PAUSED' ? "default" : "destructive"
        });
        return;
      }

      toast({
        title: "Letters Generated",
        description: `Created ${data.drafts_created || 0} dispute letter drafts`
      });
      
      if (onAnalysisComplete) onAnalysisComplete();
    } catch (error: any) {
      console.error('Letters error:', error);
      toast({ title: "Letter Generation Failed", description: 'Unexpected error occurred', variant: "destructive" });
    } finally {
      setGeneratingLetters(false);
    }
  };

  const suggestFollowup = async () => {
    setSuggestingFollowup(true);
    try {
      const { data, error } = await supabase.functions.invoke('credit-repair-suggest-followup', {
        body: { case_id: caseId }
      });

      if (error) throw error;

      setSuggestedTasks(data.suggested_tasks || []);
      toast({
        title: "Follow-Up Plan Generated",
        description: `${data.suggested_tasks?.length || 0} tasks suggested`
      });
    } catch (error: any) {
      console.error('Followup error:', error);
      toast({
        title: "Follow-Up Generation Failed",
        description: error.message || 'Unable to suggest follow-up plan',
        variant: "destructive"
      });
    } finally {
      setSuggestingFollowup(false);
    }
  };

  const addSuggestedItem = async (item: any) => {
    try {
      const { error } = await supabase.from('credit_repair_items').insert({
        case_id: caseId,
        item_type: item.item_type,
        creditor_name: item.creditor_name,
        account_number: item.account_number,
        status: 'identified',
        dispute_reason: item.dispute_reason,
        dispute_basis_code: item.dispute_basis_code,
        source_bureau: item.source_bureau,
        risk_tags: item.risk_tags,
        ai_generated: true,
        notes: item.notes
      });

      if (error) throw error;

      toast({ title: "Item Added" });
      setSuggestedItems(prev => prev.filter(i => i !== item));
      if (onAnalysisComplete) onAnalysisComplete();
    } catch (error: any) {
      toast({
        title: "Failed to Add Item",
        description: error.message,
        variant: "destructive"
      });
    }
  };

  const addSuggestedTask = async (task: any) => {
    try {
      const { error } = await supabase.from('credit_repair_tasks').insert({
        case_id: caseId,
        title: task.title,
        description: task.description,
        due_date: task.due_date,
        source: 'ai'
      });

      if (error) throw error;

      toast({ title: "Task Added" });
      setSuggestedTasks(prev => prev.filter(t => t !== task));
      if (onAnalysisComplete) onAnalysisComplete();
    } catch (error: any) {
      toast({
        title: "Failed to Add Task",
        description: error.message,
        variant: "destructive"
      });
    }
  };

  return (
    <Card className="sticky top-4">
      <CardHeader className="bg-gradient-to-r from-purple-50 to-blue-50 dark:from-purple-950/20 dark:to-blue-950/20">
        <CardTitle className="flex items-center gap-2 text-lg">
          <Sparkles className="w-5 h-5 text-purple-600" />
          AI Control Panel
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3 pt-4">
        <Button 
          onClick={analyzeReport}
          disabled={analyzing}
          className="w-full"
          variant="outline"
        >
          {analyzing ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <FileText className="w-4 h-4 mr-2" />}
          Analyze Credit Report
        </Button>

        <Button 
          onClick={generateStrategy}
          disabled={generatingStrategy}
          className="w-full"
          variant="outline"
        >
          {generatingStrategy ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Lightbulb className="w-4 h-4 mr-2" />}
          Generate Dispute Strategy
        </Button>

        <Button 
          onClick={generateLetters}
          disabled={generatingLetters}
          className="w-full"
          variant="outline"
        >
          {generatingLetters ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <FileText className="w-4 h-4 mr-2" />}
          Draft Dispute Letters
        </Button>

        <Button 
          onClick={suggestFollowup}
          disabled={suggestingFollowup}
          className="w-full"
          variant="outline"
        >
          {suggestingFollowup ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Calendar className="w-4 h-4 mr-2" />}
          Suggest Follow-Up Plan
        </Button>

        {/* Suggested Items */}
        {suggestedItems.length > 0 && (
          <div className="mt-4 space-y-2">
            <p className="text-sm font-semibold">AI Suggested Items:</p>
            {suggestedItems.map((item, idx) => (
              <div key={idx} className="p-2 border rounded bg-purple-50/50 dark:bg-purple-950/20 space-y-1">
                <p className="text-sm font-semibold">{item.item_type}</p>
                <p className="text-xs text-muted-foreground">{item.creditor_name}</p>
                <p className="text-xs">{item.dispute_reason}</p>
                <Button size="sm" onClick={() => addSuggestedItem(item)} className="mt-1">
                  Add to Case
                </Button>
              </div>
            ))}
          </div>
        )}

        {/* Suggested Tasks */}
        {suggestedTasks.length > 0 && (
          <div className="mt-4 space-y-2">
            <p className="text-sm font-semibold">AI Suggested Tasks:</p>
            {suggestedTasks.map((task, idx) => (
              <div key={idx} className="p-2 border rounded bg-blue-50/50 dark:bg-blue-950/20 space-y-1">
                <p className="text-sm font-semibold">{task.title}</p>
                <p className="text-xs text-muted-foreground">{task.description}</p>
                <Button size="sm" onClick={() => addSuggestedTask(task)} className="mt-1">
                  Add Task
                </Button>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
};