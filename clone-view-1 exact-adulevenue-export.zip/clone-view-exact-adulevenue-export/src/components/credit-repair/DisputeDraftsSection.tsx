import { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { FileText, Eye, Edit, CheckCircle, Archive, Printer, Send, Loader2 } from "lucide-react";
import { generateDisputeLetterPDF } from "@/lib/pdf-generator";

interface DisputeDraft {
  id: string;
  target: string;
  target_name: string;
  status: string;
  subject: string;
  body: string;
  signature: string | null;
  worker_type: string;
  created_at: string;
}

interface DisputeDraftsSectionProps {
  caseId: string;
}

export const DisputeDraftsSection = ({ caseId }: DisputeDraftsSectionProps) => {
  const { toast } = useToast();
  const [drafts, setDrafts] = useState<DisputeDraft[]>([]);
  const [selectedDraft, setSelectedDraft] = useState<DisputeDraft | null>(null);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editMode, setEditMode] = useState(false);
  const [editedSubject, setEditedSubject] = useState("");
  const [editedBody, setEditedBody] = useState("");
  const [editedSignature, setEditedSignature] = useState("");
  const [showSignatureInput, setShowSignatureInput] = useState(false);
  const [signatureName, setSignatureName] = useState("");
  const [selectedDraftIds, setSelectedDraftIds] = useState<Set<string>>(new Set());
  const [sendingAll, setSendingAll] = useState(false);
  const [sendingSelected, setSendingSelected] = useState(false);

  useEffect(() => {
    fetchDrafts();
  }, [caseId]);

  const fetchDrafts = async () => {
    const { data, error } = await supabase
      .from('credit_repair_dispute_drafts')
      .select('id, target, target_name, status, subject, body, signature, worker_type, created_at')
      .eq('case_id', caseId)
      .order('created_at', { ascending: false });

    if (!error && data) {
      setDrafts(data.map(d => ({
        ...d,
        signature: d.signature || null
      })) as DisputeDraft[]);
    }
  };

  const openDraft = (draft: DisputeDraft, edit: boolean = false) => {
    setSelectedDraft(draft);
    setEditedSubject(draft.subject);
    setEditedBody(draft.body);
    setEditedSignature(draft.signature || "");
    setSignatureName("");
    setShowSignatureInput(false);
    setEditMode(edit);
    setDialogOpen(true);
  };

  const generateSignature = () => {
    if (!signatureName.trim()) {
      toast({
        title: "Name Required",
        description: "Please enter a name for the signature",
        variant: "destructive"
      });
      return;
    }
    
    const signature = `Sincerely,\n\n${signatureName.trim()}\nAuthorized by Wolf Fund Corp™\nCredit Fix Back Office™`;
    
    setEditedSignature(signature);
    setShowSignatureInput(false);
    setSignatureName("");
    
    toast({
      title: "Signature Generated",
      description: "Signature has been added to the letter"
    });
  };

  const deleteDraft = async (draftId: string) => {
    const { error } = await supabase
      .from('credit_repair_dispute_drafts')
      .delete()
      .eq('id', draftId);

    if (error) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive"
      });
    } else {
      toast({ title: "Draft Deleted" });
      fetchDrafts();
      setDialogOpen(false);
    }
  };

  const updateDraftStatus = async (draftId: string, status: string) => {
    const { error } = await supabase
      .from('credit_repair_dispute_drafts')
      .update({ status })
      .eq('id', draftId);

    if (error) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive"
      });
    } else {
      toast({
        title: "Status Updated",
        description: `Draft ${status}`
      });
      fetchDrafts();
      setDialogOpen(false);
    }
  };

  const saveDraftEdits = async () => {
    if (!selectedDraft) return;

    const { error } = await supabase
      .from('credit_repair_dispute_drafts')
      .update({
        subject: editedSubject,
        body: editedBody,
        signature: editedSignature
      })
      .eq('id', selectedDraft.id);

    if (error) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive"
      });
    } else {
      toast({ title: "Draft Updated" });
      setEditMode(false);
      fetchDrafts();
    }
  };

  const getStatusColor = (status: string) => {
    const colors: Record<string, string> = {
      draft: 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-300',
      approved: 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300',
      archived: 'bg-gray-100 text-gray-800 dark:bg-gray-900/30 dark:text-gray-300'
    };
    return colors[status] || colors.draft;
  };

  const getTargetIcon = (target: string) => {
    return <FileText className="w-4 h-4" />;
  };

  const toggleDraftSelection = (draftId: string) => {
    setSelectedDraftIds(prev => {
      const newSet = new Set(prev);
      if (newSet.has(draftId)) {
        newSet.delete(draftId);
      } else {
        newSet.add(draftId);
      }
      return newSet;
    });
  };

  const handlePrint = async (draft: DisputeDraft) => {
    try {
      await generateDisputeLetterPDF(draft);
      toast({ title: "PDF Downloaded", description: "Letter downloaded successfully" });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to generate PDF",
        variant: "destructive"
      });
    }
  };

  const sendLetters = async (draftIds: string[]) => {
    try {
      const draftsToSend = drafts.filter(d => draftIds.includes(d.id) && d.status === 'approved');
      
      if (draftsToSend.length === 0) {
        toast({
          title: "No Letters to Send",
          description: "Only approved letters can be sent",
          variant: "destructive"
        });
        return;
      }

      const { data, error } = await supabase.functions.invoke('send-dispute-letters', {
        body: { caseId, draftIds: draftsToSend.map(d => d.id) }
      });

      if (error) throw error;

      toast({
        title: "Letters Sent",
        description: `Successfully sent ${draftsToSend.length} dispute letter(s)`
      });
      
      setSelectedDraftIds(new Set());
      fetchDrafts();
    } catch (error: any) {
      toast({
        title: "Error Sending Letters",
        description: error.message,
        variant: "destructive"
      });
    }
  };

  const handleSendSelected = async () => {
    if (selectedDraftIds.size === 0) {
      toast({
        title: "No Letters Selected",
        description: "Please select at least one letter to send",
        variant: "destructive"
      });
      return;
    }
    
    setSendingSelected(true);
    await sendLetters(Array.from(selectedDraftIds));
    setSendingSelected(false);
  };

  const handleSendAll = async () => {
    const approvedDrafts = drafts.filter(d => d.status === 'approved');
    if (approvedDrafts.length === 0) {
      toast({
        title: "No Approved Letters",
        description: "There are no approved letters to send",
        variant: "destructive"
      });
      return;
    }
    
    setSendingAll(true);
    await sendLetters(approvedDrafts.map(d => d.id));
    setSendingAll(false);
  };

  const groupedDrafts = drafts.reduce((acc, draft) => {
    if (!acc[draft.target]) acc[draft.target] = [];
    acc[draft.target].push(draft);
    return acc;
  }, {} as Record<string, DisputeDraft[]>);

  const approvedCount = drafts.filter(d => d.status === 'approved').length;

  return (
    <>
      <Card>
        <CardHeader>
          <CardTitle className="text-lg flex items-center gap-2">
            <FileText className="w-5 h-5" />
            Dispute Letter Drafts ({drafts.length})
          </CardTitle>
        </CardHeader>
        <CardContent>
          {drafts.length === 0 ? (
            <p className="text-sm text-muted-foreground">No dispute letter drafts yet. Use AI to generate drafts.</p>
          ) : (
            <div className="space-y-4">
              {Object.entries(groupedDrafts).map(([target, targetDrafts]) => (
                <div key={target} className="space-y-2">
                  <h4 className="text-sm font-semibold capitalize flex items-center gap-2">
                    {getTargetIcon(target)}
                    {target} Letters ({targetDrafts.length})
                  </h4>
                   {targetDrafts.map((draft) => (
                    <div key={draft.id} className={`flex items-center gap-3 p-3 border-2 rounded transition-all ${
                      selectedDraftIds.has(draft.id) 
                        ? 'border-primary bg-primary/5' 
                        : 'border-border hover:bg-muted/50'
                    }`}>
                      <div className="flex items-center justify-center w-5 h-5">
                        <Checkbox
                          checked={selectedDraftIds.has(draft.id)}
                          onCheckedChange={() => toggleDraftSelection(draft.id)}
                          disabled={draft.status !== 'approved'}
                          className="w-5 h-5"
                        />
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <p className="font-semibold text-sm">{draft.target_name}</p>
                          {draft.worker_type === 'ai' && (
                            <Badge variant="outline" className="text-xs">
                              AI Generated
                            </Badge>
                          )}
                        </div>
                        <p className="text-xs text-muted-foreground">{draft.subject}</p>
                        <Badge className={`mt-1 text-xs ${getStatusColor(draft.status)}`}>
                          {draft.status}
                        </Badge>
                      </div>
                      <div className="flex gap-1">
                        <Button 
                          size="sm" 
                          variant="ghost" 
                          onClick={() => openDraft(draft, false)}
                          title="View"
                        >
                          <Eye className="w-4 h-4" />
                        </Button>
                        <Button 
                          size="sm" 
                          variant="ghost" 
                          onClick={() => handlePrint(draft)}
                          title="Print/Download PDF"
                        >
                          <Printer className="w-4 h-4" />
                        </Button>
                        {draft.status === 'draft' && (
                          <>
                            <Button 
                              size="sm" 
                              variant="ghost" 
                              onClick={() => openDraft(draft, true)}
                              title="Edit"
                            >
                              <Edit className="w-4 h-4" />
                            </Button>
                            <Button 
                              size="sm" 
                              variant="ghost" 
                              onClick={() => deleteDraft(draft.id)}
                              title="Delete"
                              className="text-destructive hover:text-destructive"
                            >
                              <Archive className="w-4 h-4" />
                            </Button>
                          </>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              ))}
              
              {/* Send Controls - Always visible */}
              <div className="pt-4 border-t mt-4 bg-muted/30 p-4 rounded-lg space-y-3">
                <div className="flex items-center justify-between">
                  <div className="space-y-1">
                    <p className="text-sm font-medium">
                      {selectedDraftIds.size > 0 ? (
                        <span className="text-primary">{selectedDraftIds.size} letter(s) selected</span>
                      ) : (
                        <span className="text-muted-foreground">No letters selected</span>
                      )}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      {approvedCount > 0 ? (
                        `${approvedCount} approved letter(s) ready to send`
                      ) : (
                        "Approve letters above to enable sending"
                      )}
                    </p>
                  </div>
                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      onClick={handleSendSelected}
                      disabled={selectedDraftIds.size === 0 || sendingSelected}
                      className={selectedDraftIds.size > 0 ? "border-primary text-primary hover:bg-primary hover:text-primary-foreground" : ""}
                    >
                      {sendingSelected ? (
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      ) : (
                        <Send className="w-4 h-4 mr-2" />
                      )}
                      Send Selected
                    </Button>
                    <Button
                      onClick={handleSendAll}
                      disabled={approvedCount === 0 || sendingAll}
                      className={approvedCount > 0 ? "bg-primary hover:bg-primary/90" : ""}
                    >
                      {sendingAll ? (
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      ) : (
                        <Send className="w-4 h-4 mr-2" />
                      )}
                      Send All Approved ({approvedCount})
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Draft Detail Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[85vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {editMode ? 'Edit' : 'Review'} Dispute Letter Draft
            </DialogTitle>
          </DialogHeader>

          {selectedDraft && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <p className="text-muted-foreground">Target</p>
                  <p className="font-semibold capitalize">{selectedDraft.target}</p>
                </div>
                <div>
                  <p className="text-muted-foreground">Target Name</p>
                  <p className="font-semibold">{selectedDraft.target_name}</p>
                </div>
                <div>
                  <p className="text-muted-foreground">Status</p>
                  <Badge className={getStatusColor(selectedDraft.status)}>
                    {selectedDraft.status}
                  </Badge>
                </div>
                <div>
                  <p className="text-muted-foreground">Created</p>
                  <p className="text-sm">{new Date(selectedDraft.created_at).toLocaleDateString()}</p>
                </div>
              </div>

              <div className="space-y-2">
                <Label>Subject</Label>
                {editMode ? (
                  <Input
                    value={editedSubject}
                    onChange={(e) => setEditedSubject(e.target.value)}
                  />
                ) : (
                  <p className="p-2 border rounded bg-muted/30">{selectedDraft.subject}</p>
                )}
              </div>

              <div className="space-y-2">
                <Label>Letter Body</Label>
                {editMode ? (
                  <Textarea
                    value={editedBody}
                    onChange={(e) => setEditedBody(e.target.value)}
                    rows={12}
                    className="font-mono text-sm"
                  />
                ) : (
                  <div className="p-4 border rounded bg-muted/30 whitespace-pre-wrap text-sm">
                    {selectedDraft.body}
                  </div>
                )}
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label>Signature</Label>
                  {editMode && !showSignatureInput && (
                    <Button 
                      type="button" 
                      variant="outline" 
                      size="sm"
                      onClick={() => setShowSignatureInput(true)}
                    >
                      Generate Signature
                    </Button>
                  )}
                </div>
                
                {showSignatureInput && editMode && (
                  <div className="flex gap-2 mb-2">
                    <Input
                      value={signatureName}
                      onChange={(e) => setSignatureName(e.target.value)}
                      placeholder="Enter signer name..."
                      maxLength={100}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') {
                          e.preventDefault();
                          generateSignature();
                        }
                      }}
                    />
                    <Button 
                      type="button" 
                      size="sm"
                      onClick={generateSignature}
                    >
                      Generate
                    </Button>
                    <Button 
                      type="button" 
                      variant="ghost" 
                      size="sm"
                      onClick={() => {
                        setShowSignatureInput(false);
                        setSignatureName("");
                      }}
                    >
                      Cancel
                    </Button>
                  </div>
                )}
                
                {editMode ? (
                  <Textarea
                    value={editedSignature}
                    onChange={(e) => setEditedSignature(e.target.value)}
                    rows={4}
                    className="font-mono text-sm"
                    placeholder="Add signature..."
                  />
                ) : (
                  <div className="p-4 border rounded bg-muted/30 whitespace-pre-wrap text-sm">
                    {selectedDraft.signature || "No signature added"}
                  </div>
                )}
              </div>

              <div className="flex gap-2 justify-end">
                {editMode ? (
                  <>
                    <Button variant="outline" onClick={() => setEditMode(false)}>
                      Cancel
                    </Button>
                    <Button onClick={saveDraftEdits}>
                      Save Changes
                    </Button>
                  </>
                ) : (
                  <>
                    {selectedDraft.status === 'draft' && (
                      <>
                        <Button variant="outline" onClick={() => setEditMode(true)}>
                          <Edit className="w-4 h-4 mr-2" />
                          Edit
                        </Button>
                        <Button onClick={() => updateDraftStatus(selectedDraft.id, 'approved')}>
                          <CheckCircle className="w-4 h-4 mr-2" />
                          Approve
                        </Button>
                        <Button variant="destructive" onClick={() => updateDraftStatus(selectedDraft.id, 'archived')}>
                          <Archive className="w-4 h-4 mr-2" />
                          Archive
                        </Button>
                      </>
                    )}
                  </>
                )}
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
};