// src/components/guards/RoleGuards.tsx

import React from "react";
import { Navigate, useLocation } from "react-router-dom";
import { useUserRoles } from "@/hooks/useUserRoles";
import type { AppRole } from "@/lib/permissions";
import { getDefaultDashboard } from "@/lib/permissions";
import { AuthGateError } from "@/components/auth/AuthGateError";

/**
 * Generic role-based guard.
 * Wrap any route or layout in this to restrict by roles.
 * 
 * CRITICAL FIX: This guard now properly waits for loading to complete
 * before making any access decisions. It does NOT redirect while loading.
 */
type RoleGuardProps = {
  allowedRoles: AppRole[];
  children: React.ReactNode;
};

export function RoleGuard({ allowedRoles, children }: RoleGuardProps) {
  const { roles, loading, user, error } = useUserRoles();
  const location = useLocation();

  // Step 1: While loading, render nothing (wait for roles to load)
  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-sm text-muted-foreground">Loading…</div>
      </div>
    );
  }

  // Step 1b: Any auth/config error -> show inline persistent error (no redirect)
  if (error) {
    return <AuthGateError message={error} />;
  }

  // Step 2: No user session -> redirect to auth
  if (!user) {
    console.log("RoleGuard: No user, redirecting to /auth");
    return <Navigate to="/auth" replace state={{ from: location.pathname }} />;
  }

  // Step 3: User exists but has no roles -> they might be a new user
  // Still check if they're allowed (some routes allow 'user' role)
  if (!roles || roles.length === 0) {
    console.log("RoleGuard: User has no roles", { email: user.email, error });
    // If 'user' is in allowedRoles, let them through
    if (allowedRoles.includes('user')) {
      return <>{children}</>;
    }
    // Otherwise, redirect to their default dashboard (which is "/" for 'user')
    return <Navigate to="/" replace />;
  }

  // Step 4: Check if user has at least one allowed role
  const isAllowed = roles.some((role) => allowedRoles.includes(role));

  console.log("RoleGuard: Access check", {
    email: user.email,
    path: location.pathname,
    userRoles: roles,
    allowedRoles,
    isAllowed,
  });

  if (!isAllowed) {
    // Get the correct dashboard route based on their highest role
    const target = getDefaultDashboard(roles);
    console.log("RoleGuard: Not allowed, redirecting to", target);
    
    // Avoid redirect loops
    if (target && target !== location.pathname) {
      return <Navigate to={target} replace />;
    }
    
    // Fallback: show access denied
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-950 text-slate-100">
        <div className="max-w-md text-center space-y-3">
          <div className="text-xs uppercase tracking-wide text-slate-500">
            Access Denied
          </div>
          <div className="text-lg font-semibold">
            You don&apos;t have permission to view this page.
          </div>
          <div className="text-xs text-slate-500">
            Your roles: {roles.join(', ') || 'none'}. Required: {allowedRoles.join(' or ')}.
          </div>
        </div>
      </div>
    );
  }

  // Step 5: User is allowed → render the protected content
  return <>{children}</>;
}

/**
 * OWNER-ONLY GUARD
 * - For: /owner/motherboard
 */
type GuardProps = {
  children: React.ReactNode;
};

export function OwnerGuard({ children }: GuardProps) {
  return (
    <RoleGuard allowedRoles={["owner", "super_owner"]}>
      {children}
    </RoleGuard>
  );
}

/**
 * SUPER OWNER-ONLY GUARD
 * - For: /owner/motherboard (Motherboard command bus is SUPER OWNER ONLY)
 */
export function SuperOwnerGuard({ children }: GuardProps) {
  return (
    <RoleGuard allowedRoles={["super_owner"]}>
      {children}
    </RoleGuard>
  );
}

/**
 * ADMIN / TENANT ADMIN / OWNER GUARD
 * - For: /admin-dashboard and similar admin views
 */
export function AdminGuard({ children }: GuardProps) {
  return (
    <RoleGuard allowedRoles={["owner", "tenant_admin", "admin"]}>
      {children}
    </RoleGuard>
  );
}

/**
 * WORKER GUARD
 * - For: /worker-dashboard
 * - Owner/admin/tenant_admin can also see worker area if needed
 */
export function WorkerGuard({ children }: GuardProps) {
  return (
    <RoleGuard
      allowedRoles={["owner", "tenant_admin", "admin", "worker"]}
    >
      {children}
    </RoleGuard>
  );
}

/**
 * ISO PARTNER GUARD
 * - For: /iso-portal
 * - Owner/admin can also see ISO portal
 */
export function ISOGuard({ children }: GuardProps) {
  return (
    <RoleGuard
      allowedRoles={["owner", "admin", "iso_partner"]}
    >
      {children}
    </RoleGuard>
  );
}

/**
 * CREDIT SPECIALIST GUARD
 * - For: /credit-specialist-dashboard
 * - Owner/admin can also see this dashboard
 */
export function CreditSpecialistGuard({ children }: GuardProps) {
  return (
    <RoleGuard
      allowedRoles={["owner", "admin", "credit_repair_specialist"]}
    >
      {children}
    </RoleGuard>
  );
}
