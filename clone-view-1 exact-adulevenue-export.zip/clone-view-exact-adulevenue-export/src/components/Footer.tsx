import { Link } from "react-router-dom";
import { Mail, Phone, MapPin } from "lucide-react";

const Footer = () => {
  return (
    <footer className="bg-card border-t border-border mt-20">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Brand */}
          <div>
            <div className="flex items-center gap-2 mb-4">
              <div className="text-3xl">🐺</div>
              <div className="flex flex-col">
                <span className="text-xl font-bold text-primary">WOLF FUND</span>
                <span className="text-xs text-muted-foreground tracking-widest">CAPITAL</span>
              </div>
            </div>
            <p className="text-muted-foreground text-sm">
              Empowering businesses with fast, flexible financing solutions.
            </p>
          </div>

          {/* Services */}
          <div>
            <h3 className="font-semibold text-foreground mb-4">Services</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/services/mca" className="text-muted-foreground hover:text-primary transition-colors text-sm">
                  Merchant Cash Advance
                </Link>
              </li>
              <li>
                <Link to="/services/equipment" className="text-muted-foreground hover:text-primary transition-colors text-sm">
                  Equipment Financing
                </Link>
              </li>
              <li>
                <Link to="/services/business-lines" className="text-muted-foreground hover:text-primary transition-colors text-sm">
                  Business Lines of Credit
                </Link>
              </li>
              <li>
                <Link to="/services/sba" className="text-muted-foreground hover:text-primary transition-colors text-sm">
                  SBA Loans
                </Link>
              </li>
            </ul>
          </div>

          {/* Company */}
          <div>
            <h3 className="font-semibold text-foreground mb-4">Company</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/how-it-works" className="text-muted-foreground hover:text-primary transition-colors text-sm">
                  How It Works
                </Link>
              </li>
              <li>
                <Link to="/apply" className="text-muted-foreground hover:text-primary transition-colors text-sm">
                  Apply Now
                </Link>
              </li>
              <li>
                <Link to="/contact" className="text-muted-foreground hover:text-primary transition-colors text-sm">
                  Contact Us
                </Link>
              </li>
              <li>
                <Link to="/terms" className="text-muted-foreground hover:text-primary transition-colors text-sm">
                  Terms & Conditions
                </Link>
              </li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="font-semibold text-foreground mb-4">Contact</h3>
            <ul className="space-y-3">
              <li className="flex items-center gap-2 text-muted-foreground text-sm">
                <Phone size={16} className="text-primary" />
                <a href="tel:+16468269799" className="hover:text-primary transition-colors">
                  (646) 826-9799
                </a>
              </li>
              <li className="flex items-center gap-2 text-muted-foreground text-sm">
                <Mail size={16} className="text-primary" />
                <span>info@wolf-fund.com</span>
              </li>
              <li className="flex items-start gap-2 text-muted-foreground text-sm">
                <MapPin size={16} className="text-primary mt-0.5" />
                <span>105 Nassau St, Floor 2<br />New York, NY 10038</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-border mt-8 pt-8 space-y-3">
          <p className="text-center text-xs text-muted-foreground italic">
            Wolf Fund Credit Optimization services follow strict confidentiality and compliance standards. We focus on eligibility and results — not theoretical dispute steps.
          </p>
          <p className="text-center text-muted-foreground text-sm">
            &copy; {new Date().getFullYear()} Wolf Fund Capital. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
