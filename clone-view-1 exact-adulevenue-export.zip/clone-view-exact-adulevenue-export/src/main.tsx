import "./index.css";

import { createRoot } from "react-dom/client";

const rootEl = document.getElementById("root");

function escapeHtml(s: string) {
  return s
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function renderFatalError(err: unknown) {
  const message =
    err instanceof Error
      ? `${err.name}: ${err.message}`
      : `Unknown error: ${String(err)}`;
  const safeMessage = escapeHtml(message);

  console.error("[fatal] App bootstrap failed:", err);

  if (!rootEl) {
    // If there's no root, fall back to the full document.
    document.body.innerHTML = `<pre style="white-space:pre-wrap;color:#b91c1c;background:#fff;padding:16px;font:14px/1.4 ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, 'Liberation Mono', 'Courier New', monospace;">${safeMessage}</pre>`;
    return;
  }

  rootEl.innerHTML = `<div style="padding:16px;color:#b91c1c;font:14px/1.4 ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, 'Liberation Mono', 'Courier New', monospace;">
  <div style="font-weight:700;margin-bottom:8px;">Application failed to start</div>
  <pre style="white-space:pre-wrap;margin:0;">${safeMessage}</pre>
</div>`;
}

async function bootstrap() {
  try {
    const { default: App } = await import("./App.tsx");
    if (!rootEl) throw new Error("Missing #root element");
    createRoot(rootEl).render(<App />);
  } catch (err) {
    renderFatalError(err);
    throw err;
  }
}

void bootstrap();
