// src/integrations/underwriting/OCRIncome.ts
// WOLF-FUND.COM – OCR INCOME ANALYZER – 444 LOCKED

import { supabase } from '@/integrations/supabase/client';

export interface IncomeDocument {
  id: string;
  type: 'bank_statement' | 'tax_return' | 'invoice';
  filePath: string;
}

export interface IncomeAnalysisResult {
  averageMonthlyRevenue: number;
  monthlyBreakdown: { month: string; revenue: number }[];
  confidence: number;
}

export const OCRIncome = {
  async analyze(document: IncomeDocument): Promise<IncomeAnalysisResult> {
    const { data, error } = await supabase.functions.invoke('underwriting-ocr-income', {
      body: { documentId: document.id, filePath: document.filePath },
    });

    if (error) throw error;
    if (!data?.ok) throw new Error(data?.message || 'OCR analysis failed');

    return data.data as IncomeAnalysisResult;
  },

  async analyzeBankStatement(filePath: string): Promise<IncomeAnalysisResult> {
    const { data, error } = await supabase.functions.invoke('verify-bank-statement', {
      body: { filePath },
    });

    if (error) throw error;
    if (!data?.ok) throw new Error(data?.message || 'Bank statement analysis failed');

    return {
      averageMonthlyRevenue: data.data?.avg_monthly_revenue || 0,
      monthlyBreakdown: data.data?.monthly_breakdown || [],
      confidence: data.data?.confidence || 0,
    };
  },

  calculateAverageMonthlyRevenue(breakdown: { month: string; revenue: number }[]): number {
    if (breakdown.length === 0) return 0;
    return breakdown.reduce((sum, m) => sum + m.revenue, 0) / breakdown.length;
  },
};
