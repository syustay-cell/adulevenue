// src/integrations/underwriting/RiskModel.ts
// WOLF-FUND.COM – RISK MODEL – 444 LOCKED

export interface RiskFactor {
  name: string;
  weight: number;
  score: number;
  description: string;
}

export interface RiskAssessmentResult {
  overallScore: number;
  riskLevel: 'low' | 'medium' | 'high' | 'critical';
  factors: RiskFactor[];
  recommendation: string;
}

export const RiskModel = {
  assess(bankData?: Record<string, unknown>, legalData?: Record<string, unknown>): RiskAssessmentResult {
    const factors: RiskFactor[] = [
      { name: 'Revenue Stability', weight: 0.25, score: 75, description: 'Based on bank statement analysis' },
      { name: 'NSF History', weight: 0.20, score: 80, description: 'Low NSF occurrences' },
      { name: 'Existing Obligations', weight: 0.20, score: 60, description: 'Current MCA positions detected' },
      { name: 'Legal History', weight: 0.15, score: 90, description: 'No significant legal issues' },
      { name: 'Time in Business', weight: 0.10, score: 85, description: 'Established business' },
      { name: 'Industry Risk', weight: 0.10, score: 70, description: 'Moderate industry risk' },
    ];

    const overallScore = factors.reduce((sum, f) => sum + f.weight * f.score, 0);

    return {
      overallScore: Math.round(overallScore),
      riskLevel: this.getRiskLevel(overallScore),
      factors,
      recommendation: this.getRecommendation(overallScore),
    };
  },

  calculateScore(factors: RiskFactor[]): number {
    return factors.reduce((sum, f) => sum + f.weight * f.score, 0);
  },

  getRiskLevel(score: number): 'low' | 'medium' | 'high' | 'critical' {
    if (score >= 75) return 'low';
    if (score >= 50) return 'medium';
    if (score >= 25) return 'high';
    return 'critical';
  },

  getRecommendation(score: number): string {
    if (score >= 75) return 'Approve with standard terms';
    if (score >= 50) return 'Conditional approval - require additional docs';
    if (score >= 25) return 'High risk - senior review required';
    return 'Decline recommended';
  },
};
