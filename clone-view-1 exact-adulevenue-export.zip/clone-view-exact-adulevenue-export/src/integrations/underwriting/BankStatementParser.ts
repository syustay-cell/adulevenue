// src/integrations/underwriting/BankStatementParser.ts
// WOLF-FUND.COM – BANK STATEMENT PARSER – 444 LOCKED

export interface Transaction {
  date: string;
  description: string;
  amount: number;
  type: 'credit' | 'debit';
}

export interface BankSummary {
  totalDeposits: number;
  totalWithdrawals: number;
  averageDailyBalance: number;
  lowestBalance: number;
  negativeDays: number;
  nsfCount: number;
  mcaPayments: { vendor: string; amount: number; frequency: string }[];
  suspiciousDeposits: { date: string; amount: number; description: string }[];
}

const FUNDING_KEYWORDS = ['capital', 'funding', 'merchant', 'advance', 'holdings', 'investments', 'finance', 'credit', 'lending', 'factor', 'receivables'];

export const BankStatementParser = {
  parseCsv(csvContent: string): Transaction[] {
    // Placeholder - real implementation via AI/OCR
    return [];
  },

  calculateSummary(transactions: Transaction[], openingBalance: number, closingBalance: number): BankSummary {
    let totalDeposits = 0;
    let totalWithdrawals = 0;
    let nsfCount = 0;

    transactions.forEach(t => {
      if (t.type === 'credit') totalDeposits += t.amount;
      else totalWithdrawals += Math.abs(t.amount);

      if (t.description.toLowerCase().includes('nsf') || t.description.toLowerCase().includes('insufficient')) {
        nsfCount++;
      }
    });

    return {
      totalDeposits,
      totalWithdrawals,
      averageDailyBalance: (openingBalance + closingBalance) / 2,
      lowestBalance: Math.min(openingBalance, closingBalance),
      negativeDays: 0,
      nsfCount,
      mcaPayments: this.detectMcaPayments(transactions),
      suspiciousDeposits: this.detectSuspiciousDeposits(transactions),
    };
  },

  detectMcaPayments(transactions: Transaction[]): { vendor: string; amount: number; frequency: string }[] {
    const fundingDebits = transactions.filter(t => t.type === 'debit' && this.isFundingRelated(t.description));
    const grouped: Record<string, number[]> = {};

    fundingDebits.forEach(t => {
      const key = t.description.slice(0, 20);
      if (!grouped[key]) grouped[key] = [];
      grouped[key].push(Math.abs(t.amount));
    });

    return Object.entries(grouped).map(([vendor, amounts]) => ({
      vendor,
      amount: amounts.reduce((a, b) => a + b, 0) / amounts.length,
      frequency: amounts.length > 20 ? 'daily' : amounts.length > 4 ? 'weekly' : 'monthly',
    }));
  },

  detectSuspiciousDeposits(transactions: Transaction[]): { date: string; amount: number; description: string }[] {
    const deposits = transactions.filter(t => t.type === 'credit');
    if (deposits.length === 0) return [];

    const avgDeposit = deposits.reduce((sum, t) => sum + t.amount, 0) / deposits.length;

    return deposits
      .filter(t => t.amount > avgDeposit * 3)
      .map(t => ({ date: t.date, amount: t.amount, description: t.description }));
  },

  isFundingRelated(description: string): boolean {
    const lower = description.toLowerCase();
    return FUNDING_KEYWORDS.some(k => lower.includes(k));
  },
};
