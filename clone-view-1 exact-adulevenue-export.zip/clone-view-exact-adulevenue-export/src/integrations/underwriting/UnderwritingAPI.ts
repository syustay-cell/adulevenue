// src/integrations/underwriting/UnderwritingAPI.ts
// WOLF-FUND.COM – UNDERWRITING API – 444 LOCKED

import { supabase } from '@/integrations/supabase/client';

export interface UnderwritingCase {
  id: string;
  merchant_name: string;
  status: string;
  risk_score: number | null;
  requested_amount: number | null;
  created_at: string;
  updated_at: string;
}

export const UnderwritingAPI = {
  async listCases(): Promise<UnderwritingCase[]> {
    const { data, error } = await supabase
      .from('fast_track_applications')
      .select('id, business_name, status, created_at, updated_at')
      .order('created_at', { ascending: false });
    if (error) throw error;
    return (data || []).map(d => ({
      id: d.id,
      merchant_name: d.business_name || 'Unknown',
      status: d.status,
      risk_score: null,
      requested_amount: null,
      created_at: d.created_at,
      updated_at: d.updated_at,
    }));
  },

  async getCase(id: string): Promise<UnderwritingCase | null> {
    const { data, error } = await supabase
      .from('fast_track_applications')
      .select('*')
      .eq('id', id)
      .single();
    if (error) throw error;
    if (!data) return null;
    return {
      id: data.id,
      merchant_name: data.business_name || 'Unknown',
      status: data.status,
      risk_score: null,
      requested_amount: null,
      created_at: data.created_at,
      updated_at: data.updated_at,
    };
  },

  async getCaseStats() {
    const { data, error } = await supabase
      .from('fast_track_applications')
      .select('status');
    if (error) throw error;

    const stats = { total: 0, pending: 0, approved: 0, declined: 0, funded: 0 };
    (data || []).forEach(c => {
      stats.total++;
      if (c.status === 'pending' || c.status === 'submitted') stats.pending++;
      else if (c.status === 'approved') stats.approved++;
      else if (c.status === 'declined') stats.declined++;
      else if (c.status === 'funded') stats.funded++;
    });
    return stats;
  },

  async updateCaseStatus(id: string, status: string): Promise<void> {
    const { error } = await supabase
      .from('fast_track_applications')
      .update({ status })
      .eq('id', id);
    if (error) throw error;
  },
};
