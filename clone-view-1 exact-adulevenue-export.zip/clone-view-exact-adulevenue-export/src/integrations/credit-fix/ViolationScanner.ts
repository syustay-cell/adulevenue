// src/integrations/credit-fix/ViolationScanner.ts
// WOLF-FUND.COM – VIOLATION SCANNER – 444 LOCKED

import { supabase } from '@/integrations/supabase/client';

export interface ViolationScanRequest {
  clientId: string;
  reportData?: string;
}

export interface DetectedViolation {
  id: string;
  type: string;
  bureau: string;
  severity: 'low' | 'medium' | 'high' | 'critical';
  description: string;
  fcra_section?: string;
  fdcpa_section?: string;
  metro2_code?: string;
}

export interface ViolationScanResult {
  violations: DetectedViolation[];
  score: number;
  summary: string;
}

export const ViolationScanner = {
  async scanReport(request: ViolationScanRequest): Promise<ViolationScanResult> {
    const { data, error } = await supabase.functions.invoke('scan-credit-violations', {
      body: request,
    });

    if (error) throw error;
    if (!data?.ok) throw new Error(data?.message || 'Scan failed');

    return data.data as ViolationScanResult;
  },

  getViolationTypes(): string[] {
    return [
      'duplicate_account',
      'incorrect_balance',
      'incorrect_status',
      'outdated_information',
      'identity_mismatch',
      'unauthorized_inquiry',
      'mixed_file',
      'reinsertion',
    ];
  },

  async logScan(clientId: string, result: ViolationScanResult): Promise<void> {
    console.log('[ViolationScanner] Scan complete for', clientId, result.summary);
  },
};
