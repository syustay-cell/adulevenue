export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "13.0.5"
  }
  public: {
    Tables: {
      abg_project_funding_links: {
        Row: {
          application_id: string | null
          created_at: string | null
          funded_deal_id: string | null
          id: string
          link_type: string | null
          project_id: string | null
        }
        Insert: {
          application_id?: string | null
          created_at?: string | null
          funded_deal_id?: string | null
          id?: string
          link_type?: string | null
          project_id?: string | null
        }
        Update: {
          application_id?: string | null
          created_at?: string | null
          funded_deal_id?: string | null
          id?: string
          link_type?: string | null
          project_id?: string | null
        }
        Relationships: []
      }
      abg_projects: {
        Row: {
          created_at: string
          draw_schedule: Json | null
          external_ref: string | null
          funded_amount: number | null
          id: string
          location: string | null
          name: string
          notes: string | null
          project_type: string | null
          status: string
          total_budget: number | null
          updated_at: string
          wolf_funding_application_id: string | null
        }
        Insert: {
          created_at?: string
          draw_schedule?: Json | null
          external_ref?: string | null
          funded_amount?: number | null
          id?: string
          location?: string | null
          name: string
          notes?: string | null
          project_type?: string | null
          status?: string
          total_budget?: number | null
          updated_at?: string
          wolf_funding_application_id?: string | null
        }
        Update: {
          created_at?: string
          draw_schedule?: Json | null
          external_ref?: string | null
          funded_amount?: number | null
          id?: string
          location?: string | null
          name?: string
          notes?: string | null
          project_type?: string | null
          status?: string
          total_budget?: number | null
          updated_at?: string
          wolf_funding_application_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "abg_projects_wolf_funding_application_id_fkey"
            columns: ["wolf_funding_application_id"]
            isOneToOne: false
            referencedRelation: "fast_track_applications"
            referencedColumns: ["id"]
          },
        ]
      }
      activity_events: {
        Row: {
          actor_id: string | null
          actor_type: string
          created_at: string
          deal_id: string | null
          decision: string | null
          details_json: Json | null
          event_type: string
          execution_mode: string
          id: string
          iso_id: string | null
          lead_id: string | null
          owner_mode: string
          scope: string
          severity: string | null
          strategy_profile: string
          summary: string
        }
        Insert: {
          actor_id?: string | null
          actor_type: string
          created_at?: string
          deal_id?: string | null
          decision?: string | null
          details_json?: Json | null
          event_type: string
          execution_mode?: string
          id?: string
          iso_id?: string | null
          lead_id?: string | null
          owner_mode?: string
          scope: string
          severity?: string | null
          strategy_profile?: string
          summary: string
        }
        Update: {
          actor_id?: string | null
          actor_type?: string
          created_at?: string
          deal_id?: string | null
          decision?: string | null
          details_json?: Json | null
          event_type?: string
          execution_mode?: string
          id?: string
          iso_id?: string | null
          lead_id?: string | null
          owner_mode?: string
          scope?: string
          severity?: string | null
          strategy_profile?: string
          summary?: string
        }
        Relationships: []
      }
      activity_feed: {
        Row: {
          actor_email: string | null
          actor_role: string | null
          actor_user_id: string | null
          context_id: string | null
          context_type: string
          created_at: string
          decision: string | null
          decision_reason: string | null
          details: Json | null
          event_type: string
          id: string
          summary: string
          target_email: string | null
          target_user_id: string | null
        }
        Insert: {
          actor_email?: string | null
          actor_role?: string | null
          actor_user_id?: string | null
          context_id?: string | null
          context_type: string
          created_at?: string
          decision?: string | null
          decision_reason?: string | null
          details?: Json | null
          event_type: string
          id?: string
          summary: string
          target_email?: string | null
          target_user_id?: string | null
        }
        Update: {
          actor_email?: string | null
          actor_role?: string | null
          actor_user_id?: string | null
          context_id?: string | null
          context_type?: string
          created_at?: string
          decision?: string | null
          decision_reason?: string | null
          details?: Json | null
          event_type?: string
          id?: string
          summary?: string
          target_email?: string | null
          target_user_id?: string | null
        }
        Relationships: []
      }
      activity_log: {
        Row: {
          actor: string
          auto_executed: boolean | null
          created_at: string | null
          id: string
          metadata: Json | null
          mode: string
          module: string
          proposed_action: string | null
          severity: string
          summary: string
          title: string
        }
        Insert: {
          actor: string
          auto_executed?: boolean | null
          created_at?: string | null
          id?: string
          metadata?: Json | null
          mode: string
          module: string
          proposed_action?: string | null
          severity: string
          summary: string
          title: string
        }
        Update: {
          actor?: string
          auto_executed?: boolean | null
          created_at?: string | null
          id?: string
          metadata?: Json | null
          mode?: string
          module?: string
          proposed_action?: string | null
          severity?: string
          summary?: string
          title?: string
        }
        Relationships: []
      }
      admin_application_views: {
        Row: {
          admin_user_id: string
          application_id: string
          application_type: string
          id: string
          viewed_at: string
        }
        Insert: {
          admin_user_id: string
          application_id: string
          application_type: string
          id?: string
          viewed_at?: string
        }
        Update: {
          admin_user_id?: string
          application_id?: string
          application_type?: string
          id?: string
          viewed_at?: string
        }
        Relationships: []
      }
      admin_sensitive_data_access: {
        Row: {
          accessed_at: string
          accessed_table: string
          admin_user_id: string
          field_name: string
          id: string
          record_id: string
        }
        Insert: {
          accessed_at?: string
          accessed_table: string
          admin_user_id: string
          field_name: string
          id?: string
          record_id: string
        }
        Update: {
          accessed_at?: string
          accessed_table?: string
          admin_user_id?: string
          field_name?: string
          id?: string
          record_id?: string
        }
        Relationships: []
      }
      ai_events: {
        Row: {
          created_at: string | null
          entity_id: string
          entity_type: string
          event_type: string
          id: string
          model_name: string | null
          payload_in: Json | null
          payload_out: Json | null
        }
        Insert: {
          created_at?: string | null
          entity_id: string
          entity_type: string
          event_type: string
          id?: string
          model_name?: string | null
          payload_in?: Json | null
          payload_out?: Json | null
        }
        Update: {
          created_at?: string | null
          entity_id?: string
          entity_type?: string
          event_type?: string
          id?: string
          model_name?: string | null
          payload_in?: Json | null
          payload_out?: Json | null
        }
        Relationships: []
      }
      ai_reports: {
        Row: {
          ai_model: string | null
          created_at: string
          created_by: string | null
          entity_id: string
          entity_type: string
          first_run_at: string
          first_run_cost: number | null
          id: string
          last_run_at: string
          last_run_cost: number | null
          provider: string | null
          report_json: Json
          report_text: string | null
          report_type: Database["public"]["Enums"]["ai_report_type"]
          run_count: number
          title: string | null
          updated_at: string
          updated_by: string | null
        }
        Insert: {
          ai_model?: string | null
          created_at?: string
          created_by?: string | null
          entity_id: string
          entity_type: string
          first_run_at?: string
          first_run_cost?: number | null
          id?: string
          last_run_at?: string
          last_run_cost?: number | null
          provider?: string | null
          report_json: Json
          report_text?: string | null
          report_type: Database["public"]["Enums"]["ai_report_type"]
          run_count?: number
          title?: string | null
          updated_at?: string
          updated_by?: string | null
        }
        Update: {
          ai_model?: string | null
          created_at?: string
          created_by?: string | null
          entity_id?: string
          entity_type?: string
          first_run_at?: string
          first_run_cost?: number | null
          id?: string
          last_run_at?: string
          last_run_cost?: number | null
          provider?: string | null
          report_json?: Json
          report_text?: string | null
          report_type?: Database["public"]["Enums"]["ai_report_type"]
          run_count?: number
          title?: string | null
          updated_at?: string
          updated_by?: string | null
        }
        Relationships: []
      }
      application_comments: {
        Row: {
          admin_user_id: string
          application_id: string
          comment: string
          created_at: string
          id: string
          updated_at: string
        }
        Insert: {
          admin_user_id: string
          application_id: string
          comment: string
          created_at?: string
          id?: string
          updated_at?: string
        }
        Update: {
          admin_user_id?: string
          application_id?: string
          comment?: string
          created_at?: string
          id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "application_comments_application_id_fkey"
            columns: ["application_id"]
            isOneToOne: false
            referencedRelation: "fast_track_applications"
            referencedColumns: ["id"]
          },
        ]
      }
      application_transactions: {
        Row: {
          admin_user_id: string
          amount: number
          application_id: string
          created_at: string
          description: string | null
          id: string
          transaction_date: string
          transaction_type: string
        }
        Insert: {
          admin_user_id: string
          amount: number
          application_id: string
          created_at?: string
          description?: string | null
          id?: string
          transaction_date?: string
          transaction_type: string
        }
        Update: {
          admin_user_id?: string
          amount?: number
          application_id?: string
          created_at?: string
          description?: string | null
          id?: string
          transaction_date?: string
          transaction_type?: string
        }
        Relationships: [
          {
            foreignKeyName: "application_transactions_application_id_fkey"
            columns: ["application_id"]
            isOneToOne: false
            referencedRelation: "fast_track_applications"
            referencedColumns: ["id"]
          },
        ]
      }
      audit_logs: {
        Row: {
          action_type: string
          changes: Json | null
          created_at: string
          id: string
          intake_client_id: string | null
          ip_address: string | null
          previous_values: Json | null
          resource_id: string
          resource_type: string
          table_name: string | null
          tenant_id: string | null
          user_agent: string | null
          user_id: string
        }
        Insert: {
          action_type: string
          changes?: Json | null
          created_at?: string
          id?: string
          intake_client_id?: string | null
          ip_address?: string | null
          previous_values?: Json | null
          resource_id: string
          resource_type: string
          table_name?: string | null
          tenant_id?: string | null
          user_agent?: string | null
          user_id: string
        }
        Update: {
          action_type?: string
          changes?: Json | null
          created_at?: string
          id?: string
          intake_client_id?: string | null
          ip_address?: string | null
          previous_values?: Json | null
          resource_id?: string
          resource_type?: string
          table_name?: string | null
          tenant_id?: string | null
          user_agent?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "audit_logs_intake_client_id_fkey"
            columns: ["intake_client_id"]
            isOneToOne: false
            referencedRelation: "intake_clients"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "audit_logs_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "wf_tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      billing_plans: {
        Row: {
          created_at: string | null
          features: Json | null
          id: string
          is_active: boolean | null
          plan_name: string
          plan_type: string
          price: number
          stripe_price_id: string | null
          updated_at: string | null
        }
        Insert: {
          created_at?: string | null
          features?: Json | null
          id?: string
          is_active?: boolean | null
          plan_name: string
          plan_type: string
          price: number
          stripe_price_id?: string | null
          updated_at?: string | null
        }
        Update: {
          created_at?: string | null
          features?: Json | null
          id?: string
          is_active?: boolean | null
          plan_name?: string
          plan_type?: string
          price?: number
          stripe_price_id?: string | null
          updated_at?: string | null
        }
        Relationships: []
      }
      billing_subscriptions: {
        Row: {
          cancelled_at: string | null
          created_at: string | null
          current_period_end: string | null
          current_period_start: string | null
          id: string
          plan_id: string | null
          status: string
          stripe_customer_id: string | null
          stripe_subscription_id: string | null
          updated_at: string | null
          user_id: string
        }
        Insert: {
          cancelled_at?: string | null
          created_at?: string | null
          current_period_end?: string | null
          current_period_start?: string | null
          id?: string
          plan_id?: string | null
          status?: string
          stripe_customer_id?: string | null
          stripe_subscription_id?: string | null
          updated_at?: string | null
          user_id: string
        }
        Update: {
          cancelled_at?: string | null
          created_at?: string | null
          current_period_end?: string | null
          current_period_start?: string | null
          id?: string
          plan_id?: string | null
          status?: string
          stripe_customer_id?: string | null
          stripe_subscription_id?: string | null
          updated_at?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "billing_subscriptions_plan_id_fkey"
            columns: ["plan_id"]
            isOneToOne: false
            referencedRelation: "billing_plans"
            referencedColumns: ["id"]
          },
        ]
      }
      call_sessions: {
        Row: {
          ended_at: string | null
          id: string
          is_active: boolean
          started_at: string
          worker_id: string
        }
        Insert: {
          ended_at?: string | null
          id?: string
          is_active?: boolean
          started_at?: string
          worker_id: string
        }
        Update: {
          ended_at?: string | null
          id?: string
          is_active?: boolean
          started_at?: string
          worker_id?: string
        }
        Relationships: []
      }
      calls: {
        Row: {
          created_at: string | null
          duration_seconds: number | null
          id: string
          lead_id: string | null
          notes: string | null
          outcome: string
          scheduled_callback_at: string | null
          user_id: string | null
        }
        Insert: {
          created_at?: string | null
          duration_seconds?: number | null
          id?: string
          lead_id?: string | null
          notes?: string | null
          outcome: string
          scheduled_callback_at?: string | null
          user_id?: string | null
        }
        Update: {
          created_at?: string | null
          duration_seconds?: number | null
          id?: string
          lead_id?: string | null
          notes?: string | null
          outcome?: string
          scheduled_callback_at?: string | null
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "calls_lead_id_fkey"
            columns: ["lead_id"]
            isOneToOne: false
            referencedRelation: "leads"
            referencedColumns: ["id"]
          },
        ]
      }
      chat_messages: {
        Row: {
          body: string
          conversation_id: string
          created_at: string
          id: string
          is_internal_note: boolean
          sender_id: string
          sender_role: string
        }
        Insert: {
          body: string
          conversation_id: string
          created_at?: string
          id?: string
          is_internal_note?: boolean
          sender_id: string
          sender_role: string
        }
        Update: {
          body?: string
          conversation_id?: string
          created_at?: string
          id?: string
          is_internal_note?: boolean
          sender_id?: string
          sender_role?: string
        }
        Relationships: [
          {
            foreignKeyName: "chat_messages_conversation_id_fkey"
            columns: ["conversation_id"]
            isOneToOne: false
            referencedRelation: "conversations"
            referencedColumns: ["id"]
          },
        ]
      }
      client_activity: {
        Row: {
          body: string | null
          channel: string | null
          created_at: string | null
          direction: string | null
          id: string
          lead_id: string
          meta: Json | null
          subject: string | null
          type: string
          worker_id: string | null
        }
        Insert: {
          body?: string | null
          channel?: string | null
          created_at?: string | null
          direction?: string | null
          id?: string
          lead_id: string
          meta?: Json | null
          subject?: string | null
          type: string
          worker_id?: string | null
        }
        Update: {
          body?: string | null
          channel?: string | null
          created_at?: string | null
          direction?: string | null
          id?: string
          lead_id?: string
          meta?: Json | null
          subject?: string | null
          type?: string
          worker_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "client_activity_lead_id_fkey"
            columns: ["lead_id"]
            isOneToOne: false
            referencedRelation: "leads"
            referencedColumns: ["id"]
          },
        ]
      }
      client_communications: {
        Row: {
          body: string
          channel: string
          created_at: string
          delivered_at: string | null
          id: string
          lead_id: string
          metadata: Json | null
          recipient_email: string | null
          recipient_phone: string | null
          sent_at: string | null
          status: string
          subject: string | null
          template_type: string
          updated_at: string
          worker_email: string | null
          worker_id: string
        }
        Insert: {
          body: string
          channel: string
          created_at?: string
          delivered_at?: string | null
          id?: string
          lead_id: string
          metadata?: Json | null
          recipient_email?: string | null
          recipient_phone?: string | null
          sent_at?: string | null
          status?: string
          subject?: string | null
          template_type: string
          updated_at?: string
          worker_email?: string | null
          worker_id: string
        }
        Update: {
          body?: string
          channel?: string
          created_at?: string
          delivered_at?: string | null
          id?: string
          lead_id?: string
          metadata?: Json | null
          recipient_email?: string | null
          recipient_phone?: string | null
          sent_at?: string | null
          status?: string
          subject?: string | null
          template_type?: string
          updated_at?: string
          worker_email?: string | null
          worker_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "client_communications_lead_id_fkey"
            columns: ["lead_id"]
            isOneToOne: false
            referencedRelation: "leads"
            referencedColumns: ["id"]
          },
        ]
      }
      client_notes: {
        Row: {
          created_at: string
          id: string
          lead_id: string
          note: string
          note_type: string | null
          worker_email: string | null
          worker_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          lead_id: string
          note: string
          note_type?: string | null
          worker_email?: string | null
          worker_id: string
        }
        Update: {
          created_at?: string
          id?: string
          lead_id?: string
          note?: string
          note_type?: string | null
          worker_email?: string | null
          worker_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "client_notes_lead_id_fkey"
            columns: ["lead_id"]
            isOneToOne: false
            referencedRelation: "leads"
            referencedColumns: ["id"]
          },
        ]
      }
      client_vault: {
        Row: {
          application_id: string | null
          application_type: string | null
          created_at: string | null
          id: string
          intake_client_id: string | null
          lead_id: string | null
          masking_override: Json | null
          real_address: string | null
          real_city: string | null
          real_email: string | null
          real_name: string | null
          real_phone: string | null
          real_ssn_last4: string | null
          real_state: string | null
          real_zip: string | null
          tenant_id: string | null
          updated_at: string | null
          vault_id: string
        }
        Insert: {
          application_id?: string | null
          application_type?: string | null
          created_at?: string | null
          id?: string
          intake_client_id?: string | null
          lead_id?: string | null
          masking_override?: Json | null
          real_address?: string | null
          real_city?: string | null
          real_email?: string | null
          real_name?: string | null
          real_phone?: string | null
          real_ssn_last4?: string | null
          real_state?: string | null
          real_zip?: string | null
          tenant_id?: string | null
          updated_at?: string | null
          vault_id?: string
        }
        Update: {
          application_id?: string | null
          application_type?: string | null
          created_at?: string | null
          id?: string
          intake_client_id?: string | null
          lead_id?: string | null
          masking_override?: Json | null
          real_address?: string | null
          real_city?: string | null
          real_email?: string | null
          real_name?: string | null
          real_phone?: string | null
          real_ssn_last4?: string | null
          real_state?: string | null
          real_zip?: string | null
          tenant_id?: string | null
          updated_at?: string | null
          vault_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "client_vault_intake_client_id_fkey"
            columns: ["intake_client_id"]
            isOneToOne: false
            referencedRelation: "intake_clients"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "client_vault_lead_id_fkey"
            columns: ["lead_id"]
            isOneToOne: false
            referencedRelation: "leads"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "client_vault_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "wf_tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      collection_cases: {
        Row: {
          assigned_to: string | null
          created_at: string
          deal_id: string
          dpd: number
          id: string
          intake_client_id: string | null
          notes: string | null
          reason: string | null
          status: string
          strategy: string | null
          tenant_id: string | null
          updated_at: string
        }
        Insert: {
          assigned_to?: string | null
          created_at?: string
          deal_id: string
          dpd?: number
          id?: string
          intake_client_id?: string | null
          notes?: string | null
          reason?: string | null
          status?: string
          strategy?: string | null
          tenant_id?: string | null
          updated_at?: string
        }
        Update: {
          assigned_to?: string | null
          created_at?: string
          deal_id?: string
          dpd?: number
          id?: string
          intake_client_id?: string | null
          notes?: string | null
          reason?: string | null
          status?: string
          strategy?: string | null
          tenant_id?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "collection_cases_intake_client_id_fkey"
            columns: ["intake_client_id"]
            isOneToOne: false
            referencedRelation: "intake_clients"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "collection_cases_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "wf_tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      collection_events: {
        Row: {
          actor_id: string | null
          actor_type: string
          case_id: string
          channel: string | null
          created_at: string
          event_type: string
          id: string
          payload: Json | null
        }
        Insert: {
          actor_id?: string | null
          actor_type: string
          case_id: string
          channel?: string | null
          created_at?: string
          event_type: string
          id?: string
          payload?: Json | null
        }
        Update: {
          actor_id?: string | null
          actor_type?: string
          case_id?: string
          channel?: string | null
          created_at?: string
          event_type?: string
          id?: string
          payload?: Json | null
        }
        Relationships: [
          {
            foreignKeyName: "collection_events_case_id_fkey"
            columns: ["case_id"]
            isOneToOne: false
            referencedRelation: "collection_cases"
            referencedColumns: ["id"]
          },
        ]
      }
      commission_rules: {
        Row: {
          allow_negotiated_overrides: boolean
          autopilot_house_multiplier: number
          closer_pct_of_worker_pool: number
          created_at: string
          default_iso_pct: number
          default_referral_pct: number
          id: string
          is_active: boolean
          min_house_pct: number
          opener_pct_of_worker_pool: number
          rule_name: string
          updated_at: string
        }
        Insert: {
          allow_negotiated_overrides?: boolean
          autopilot_house_multiplier?: number
          closer_pct_of_worker_pool?: number
          created_at?: string
          default_iso_pct?: number
          default_referral_pct?: number
          id?: string
          is_active?: boolean
          min_house_pct?: number
          opener_pct_of_worker_pool?: number
          rule_name?: string
          updated_at?: string
        }
        Update: {
          allow_negotiated_overrides?: boolean
          autopilot_house_multiplier?: number
          closer_pct_of_worker_pool?: number
          created_at?: string
          default_iso_pct?: number
          default_referral_pct?: number
          id?: string
          is_active?: boolean
          min_house_pct?: number
          opener_pct_of_worker_pool?: number
          rule_name?: string
          updated_at?: string
        }
        Relationships: []
      }
      commissions: {
        Row: {
          created_at: string | null
          id: string
          lead_id: string | null
          owner_id: string | null
          partner_id: string | null
          split: number | null
        }
        Insert: {
          created_at?: string | null
          id?: string
          lead_id?: string | null
          owner_id?: string | null
          partner_id?: string | null
          split?: number | null
        }
        Update: {
          created_at?: string | null
          id?: string
          lead_id?: string | null
          owner_id?: string | null
          partner_id?: string | null
          split?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "commissions_lead_id_fkey"
            columns: ["lead_id"]
            isOneToOne: false
            referencedRelation: "leads"
            referencedColumns: ["id"]
          },
        ]
      }
      communication_logs: {
        Row: {
          communication_type: string
          content: string
          created_at: string
          delivered_at: string | null
          error_message: string | null
          id: string
          metadata: Json | null
          recipient_email: string | null
          recipient_id: string
          recipient_phone: string | null
          recipient_type: string
          sent_at: string | null
          status: string
          subject: string | null
          template_name: string | null
        }
        Insert: {
          communication_type: string
          content: string
          created_at?: string
          delivered_at?: string | null
          error_message?: string | null
          id?: string
          metadata?: Json | null
          recipient_email?: string | null
          recipient_id: string
          recipient_phone?: string | null
          recipient_type: string
          sent_at?: string | null
          status?: string
          subject?: string | null
          template_name?: string | null
        }
        Update: {
          communication_type?: string
          content?: string
          created_at?: string
          delivered_at?: string | null
          error_message?: string | null
          id?: string
          metadata?: Json | null
          recipient_email?: string | null
          recipient_id?: string
          recipient_phone?: string | null
          recipient_type?: string
          sent_at?: string | null
          status?: string
          subject?: string | null
          template_name?: string | null
        }
        Relationships: []
      }
      compliance_deal_checks: {
        Row: {
          check_key: string
          checked_at: string | null
          checked_by: string | null
          created_at: string
          deal_id: string
          id: string
          notes: string | null
          status: string
          updated_at: string
        }
        Insert: {
          check_key: string
          checked_at?: string | null
          checked_by?: string | null
          created_at?: string
          deal_id: string
          id?: string
          notes?: string | null
          status?: string
          updated_at?: string
        }
        Update: {
          check_key?: string
          checked_at?: string | null
          checked_by?: string | null
          created_at?: string
          deal_id?: string
          id?: string
          notes?: string | null
          status?: string
          updated_at?: string
        }
        Relationships: []
      }
      compliance_disclosure_templates: {
        Row: {
          body_markdown: string
          created_at: string
          id: string
          is_active: boolean
          name: string
          product_type: string
          state_code: string
          updated_at: string
          version: number
        }
        Insert: {
          body_markdown: string
          created_at?: string
          id?: string
          is_active?: boolean
          name: string
          product_type: string
          state_code: string
          updated_at?: string
          version?: number
        }
        Update: {
          body_markdown?: string
          created_at?: string
          id?: string
          is_active?: boolean
          name?: string
          product_type?: string
          state_code?: string
          updated_at?: string
          version?: number
        }
        Relationships: []
      }
      compliance_states: {
        Row: {
          broker_license_required: boolean
          created_at: string
          disclosure_template_id: string | null
          id: string
          is_active: boolean
          notes: string | null
          product_type: string
          prohibits_coj: boolean
          requires_apr_disclosure: boolean
          state_code: string
          updated_at: string
        }
        Insert: {
          broker_license_required?: boolean
          created_at?: string
          disclosure_template_id?: string | null
          id?: string
          is_active?: boolean
          notes?: string | null
          product_type: string
          prohibits_coj?: boolean
          requires_apr_disclosure?: boolean
          state_code: string
          updated_at?: string
        }
        Update: {
          broker_license_required?: boolean
          created_at?: string
          disclosure_template_id?: string | null
          id?: string
          is_active?: boolean
          notes?: string | null
          product_type?: string
          prohibits_coj?: boolean
          requires_apr_disclosure?: boolean
          state_code?: string
          updated_at?: string
        }
        Relationships: []
      }
      contract_templates: {
        Row: {
          created_at: string
          created_by: string | null
          id: string
          is_active: boolean
          template_content: string
          template_name: string
          template_type: string
          updated_at: string
          variables: Json | null
          version: number
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          id?: string
          is_active?: boolean
          template_content: string
          template_name: string
          template_type: string
          updated_at?: string
          variables?: Json | null
          version?: number
        }
        Update: {
          created_at?: string
          created_by?: string | null
          id?: string
          is_active?: boolean
          template_content?: string
          template_name?: string
          template_type?: string
          updated_at?: string
          variables?: Json | null
          version?: number
        }
        Relationships: []
      }
      conversation_participants: {
        Row: {
          can_reply: boolean
          conversation_id: string
          id: string
          joined_at: string
          role: string
          user_id: string
        }
        Insert: {
          can_reply?: boolean
          conversation_id: string
          id?: string
          joined_at?: string
          role: string
          user_id: string
        }
        Update: {
          can_reply?: boolean
          conversation_id?: string
          id?: string
          joined_at?: string
          role?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "conversation_participants_conversation_id_fkey"
            columns: ["conversation_id"]
            isOneToOne: false
            referencedRelation: "conversations"
            referencedColumns: ["id"]
          },
        ]
      }
      conversations: {
        Row: {
          assigned_worker_id: string | null
          client_user_id: string | null
          created_at: string
          credit_case_id: string | null
          department: string
          id: string
          lead_id: string | null
          status: string
          subject: string | null
          type: string
          updated_at: string
        }
        Insert: {
          assigned_worker_id?: string | null
          client_user_id?: string | null
          created_at?: string
          credit_case_id?: string | null
          department?: string
          id?: string
          lead_id?: string | null
          status?: string
          subject?: string | null
          type?: string
          updated_at?: string
        }
        Update: {
          assigned_worker_id?: string | null
          client_user_id?: string | null
          created_at?: string
          credit_case_id?: string | null
          department?: string
          id?: string
          lead_id?: string | null
          status?: string
          subject?: string | null
          type?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "conversations_credit_case_id_fkey"
            columns: ["credit_case_id"]
            isOneToOne: false
            referencedRelation: "credit_repair_cases"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "conversations_lead_id_fkey"
            columns: ["lead_id"]
            isOneToOne: false
            referencedRelation: "leads"
            referencedColumns: ["id"]
          },
        ]
      }
      credit_case_v2_activity: {
        Row: {
          actor_role: string | null
          actor_user_id: string | null
          case_id: string
          created_at: string
          event_type: string
          id: string
          message: string | null
          payload: Json
          tenant_id: string
        }
        Insert: {
          actor_role?: string | null
          actor_user_id?: string | null
          case_id: string
          created_at?: string
          event_type: string
          id?: string
          message?: string | null
          payload?: Json
          tenant_id: string
        }
        Update: {
          actor_role?: string | null
          actor_user_id?: string | null
          case_id?: string
          created_at?: string
          event_type?: string
          id?: string
          message?: string | null
          payload?: Json
          tenant_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "credit_case_v2_activity_case_id_fkey"
            columns: ["case_id"]
            isOneToOne: false
            referencedRelation: "credit_cases_v2"
            referencedColumns: ["id"]
          },
        ]
      }
      credit_cases_v2: {
        Row: {
          assigned_at: string | null
          assigned_to: string | null
          bureaus: string[] | null
          client_email: string | null
          client_full_name: string | null
          client_phone: string | null
          client_ssn_last4: string | null
          client_user_id: string | null
          client_zip: string | null
          created_at: string
          created_by: string | null
          documents_bucket: string | null
          documents_path_root: string | null
          has_identity_theft: boolean | null
          id: string
          identity_theft_notes: string | null
          initial_credit_score_range: string | null
          lead_id: string | null
          meta: Json
          priority: string
          status: string
          target_credit_score_range: string | null
          tenant_id: string
          updated_at: string
        }
        Insert: {
          assigned_at?: string | null
          assigned_to?: string | null
          bureaus?: string[] | null
          client_email?: string | null
          client_full_name?: string | null
          client_phone?: string | null
          client_ssn_last4?: string | null
          client_user_id?: string | null
          client_zip?: string | null
          created_at?: string
          created_by?: string | null
          documents_bucket?: string | null
          documents_path_root?: string | null
          has_identity_theft?: boolean | null
          id?: string
          identity_theft_notes?: string | null
          initial_credit_score_range?: string | null
          lead_id?: string | null
          meta?: Json
          priority?: string
          status?: string
          target_credit_score_range?: string | null
          tenant_id: string
          updated_at?: string
        }
        Update: {
          assigned_at?: string | null
          assigned_to?: string | null
          bureaus?: string[] | null
          client_email?: string | null
          client_full_name?: string | null
          client_phone?: string | null
          client_ssn_last4?: string | null
          client_user_id?: string | null
          client_zip?: string | null
          created_at?: string
          created_by?: string | null
          documents_bucket?: string | null
          documents_path_root?: string | null
          has_identity_theft?: boolean | null
          id?: string
          identity_theft_notes?: string | null
          initial_credit_score_range?: string | null
          lead_id?: string | null
          meta?: Json
          priority?: string
          status?: string
          target_credit_score_range?: string | null
          tenant_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "credit_cases_v2_lead_id_fkey"
            columns: ["lead_id"]
            isOneToOne: false
            referencedRelation: "wf_leads"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "credit_cases_v2_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "wf_tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      credit_dispute_drafts_v2: {
        Row: {
          ai_model: string | null
          ai_prompt_used: string | null
          body: string
          bureau: string
          case_id: string
          created_at: string
          created_by: string | null
          id: string
          items_included: string[] | null
          letter_type: string
          meta: Json
          response_notes: string | null
          response_received_at: string | null
          sent_at: string | null
          status: string
          subject: string | null
          tenant_id: string
          updated_at: string
        }
        Insert: {
          ai_model?: string | null
          ai_prompt_used?: string | null
          body: string
          bureau: string
          case_id: string
          created_at?: string
          created_by?: string | null
          id?: string
          items_included?: string[] | null
          letter_type?: string
          meta?: Json
          response_notes?: string | null
          response_received_at?: string | null
          sent_at?: string | null
          status?: string
          subject?: string | null
          tenant_id: string
          updated_at?: string
        }
        Update: {
          ai_model?: string | null
          ai_prompt_used?: string | null
          body?: string
          bureau?: string
          case_id?: string
          created_at?: string
          created_by?: string | null
          id?: string
          items_included?: string[] | null
          letter_type?: string
          meta?: Json
          response_notes?: string | null
          response_received_at?: string | null
          sent_at?: string | null
          status?: string
          subject?: string | null
          tenant_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "credit_dispute_drafts_v2_case_id_fkey"
            columns: ["case_id"]
            isOneToOne: false
            referencedRelation: "credit_cases_v2"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "credit_dispute_drafts_v2_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "wf_tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      credit_dispute_items_v2: {
        Row: {
          account_number: string | null
          account_type: string | null
          balance: number | null
          bureau: string
          case_id: string
          created_at: string
          created_by: string | null
          creditor_name: string | null
          date_opened: string | null
          date_reported: string | null
          dispute_reason: string | null
          dispute_status: string
          fcra_violation: string | null
          fdcpa_violation: string | null
          id: string
          meta: Json
          metro2_code: string | null
          notes: string | null
          tenant_id: string
          updated_at: string
        }
        Insert: {
          account_number?: string | null
          account_type?: string | null
          balance?: number | null
          bureau: string
          case_id: string
          created_at?: string
          created_by?: string | null
          creditor_name?: string | null
          date_opened?: string | null
          date_reported?: string | null
          dispute_reason?: string | null
          dispute_status?: string
          fcra_violation?: string | null
          fdcpa_violation?: string | null
          id?: string
          meta?: Json
          metro2_code?: string | null
          notes?: string | null
          tenant_id: string
          updated_at?: string
        }
        Update: {
          account_number?: string | null
          account_type?: string | null
          balance?: number | null
          bureau?: string
          case_id?: string
          created_at?: string
          created_by?: string | null
          creditor_name?: string | null
          date_opened?: string | null
          date_reported?: string | null
          dispute_reason?: string | null
          dispute_status?: string
          fcra_violation?: string | null
          fdcpa_violation?: string | null
          id?: string
          meta?: Json
          metro2_code?: string | null
          notes?: string | null
          tenant_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "credit_dispute_items_v2_case_id_fkey"
            columns: ["case_id"]
            isOneToOne: false
            referencedRelation: "credit_cases_v2"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "credit_dispute_items_v2_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "wf_tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      credit_disputes: {
        Row: {
          account_last4: string | null
          bureau: string
          created_at: string | null
          credit_case_id: string
          creditor_name: string | null
          id: string
          letter_url: string | null
          notes: string | null
          reason_code: string | null
          round_number: number | null
          status: string
          updated_at: string | null
        }
        Insert: {
          account_last4?: string | null
          bureau: string
          created_at?: string | null
          credit_case_id: string
          creditor_name?: string | null
          id?: string
          letter_url?: string | null
          notes?: string | null
          reason_code?: string | null
          round_number?: number | null
          status?: string
          updated_at?: string | null
        }
        Update: {
          account_last4?: string | null
          bureau?: string
          created_at?: string | null
          credit_case_id?: string
          creditor_name?: string | null
          id?: string
          letter_url?: string | null
          notes?: string | null
          reason_code?: string | null
          round_number?: number | null
          status?: string
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "credit_disputes_credit_case_id_fkey"
            columns: ["credit_case_id"]
            isOneToOne: false
            referencedRelation: "credit_repair_cases"
            referencedColumns: ["id"]
          },
        ]
      }
      credit_fix_required_docs: {
        Row: {
          created_at: string
          description: string | null
          display_name: string
          doc_type: string
          id: string
          is_active: boolean
          is_required: boolean
          sort_order: number
          stage_required: string
        }
        Insert: {
          created_at?: string
          description?: string | null
          display_name: string
          doc_type: string
          id?: string
          is_active?: boolean
          is_required?: boolean
          sort_order?: number
          stage_required?: string
        }
        Update: {
          created_at?: string
          description?: string | null
          display_name?: string
          doc_type?: string
          id?: string
          is_active?: boolean
          is_required?: boolean
          sort_order?: number
          stage_required?: string
        }
        Relationships: []
      }
      credit_fix_task_templates: {
        Row: {
          created_at: string
          default_due_days: number
          description: string | null
          id: string
          is_active: boolean
          is_required: boolean
          sort_order: number
          stage: string
          task_name: string
        }
        Insert: {
          created_at?: string
          default_due_days?: number
          description?: string | null
          id?: string
          is_active?: boolean
          is_required?: boolean
          sort_order?: number
          stage: string
          task_name: string
        }
        Update: {
          created_at?: string
          default_due_days?: number
          description?: string | null
          id?: string
          is_active?: boolean
          is_required?: boolean
          sort_order?: number
          stage?: string
          task_name?: string
        }
        Relationships: []
      }
      credit_public_checks: {
        Row: {
          address: string | null
          application_id: string | null
          case_id: string | null
          city: string | null
          created_at: string | null
          created_by: string | null
          eligibility_status: string | null
          email: string | null
          full_name: string | null
          id: string
          lead_id: string | null
          notes: Json | null
          phone: string | null
          postal_code: string | null
          risk_flags: string[] | null
          soft_score: number | null
          state: string | null
        }
        Insert: {
          address?: string | null
          application_id?: string | null
          case_id?: string | null
          city?: string | null
          created_at?: string | null
          created_by?: string | null
          eligibility_status?: string | null
          email?: string | null
          full_name?: string | null
          id?: string
          lead_id?: string | null
          notes?: Json | null
          phone?: string | null
          postal_code?: string | null
          risk_flags?: string[] | null
          soft_score?: number | null
          state?: string | null
        }
        Update: {
          address?: string | null
          application_id?: string | null
          case_id?: string | null
          city?: string | null
          created_at?: string | null
          created_by?: string | null
          eligibility_status?: string | null
          email?: string | null
          full_name?: string | null
          id?: string
          lead_id?: string | null
          notes?: Json | null
          phone?: string | null
          postal_code?: string | null
          risk_flags?: string[] | null
          soft_score?: number | null
          state?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "credit_public_checks_application_id_fkey"
            columns: ["application_id"]
            isOneToOne: false
            referencedRelation: "fast_track_applications"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "credit_public_checks_case_id_fkey"
            columns: ["case_id"]
            isOneToOne: false
            referencedRelation: "credit_repair_cases"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "credit_public_checks_lead_id_fkey"
            columns: ["lead_id"]
            isOneToOne: false
            referencedRelation: "leads"
            referencedColumns: ["id"]
          },
        ]
      }
      credit_public_snapshot: {
        Row: {
          address: string | null
          bankruptcy_filed_at: string | null
          city: string | null
          created_at: string | null
          dob: string | null
          full_name: string | null
          has_bankruptcy: boolean | null
          id: string
          judgment_count: number | null
          last4_ssn: string | null
          lead_id: string | null
          lien_count: number | null
          postal_code: string | null
          raw_vendor_payload: Json | null
          readiness_score: number | null
          recent_default: boolean | null
          recommended_path: string | null
          risk_level: string | null
          state: string | null
          ucc_count: number | null
          vendor_name: string | null
          vendor_reference: string | null
        }
        Insert: {
          address?: string | null
          bankruptcy_filed_at?: string | null
          city?: string | null
          created_at?: string | null
          dob?: string | null
          full_name?: string | null
          has_bankruptcy?: boolean | null
          id?: string
          judgment_count?: number | null
          last4_ssn?: string | null
          lead_id?: string | null
          lien_count?: number | null
          postal_code?: string | null
          raw_vendor_payload?: Json | null
          readiness_score?: number | null
          recent_default?: boolean | null
          recommended_path?: string | null
          risk_level?: string | null
          state?: string | null
          ucc_count?: number | null
          vendor_name?: string | null
          vendor_reference?: string | null
        }
        Update: {
          address?: string | null
          bankruptcy_filed_at?: string | null
          city?: string | null
          created_at?: string | null
          dob?: string | null
          full_name?: string | null
          has_bankruptcy?: boolean | null
          id?: string
          judgment_count?: number | null
          last4_ssn?: string | null
          lead_id?: string | null
          lien_count?: number | null
          postal_code?: string | null
          raw_vendor_payload?: Json | null
          readiness_score?: number | null
          recent_default?: boolean | null
          recommended_path?: string | null
          risk_level?: string | null
          state?: string | null
          ucc_count?: number | null
          vendor_name?: string | null
          vendor_reference?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "credit_public_snapshot_lead_id_fkey"
            columns: ["lead_id"]
            isOneToOne: false
            referencedRelation: "leads"
            referencedColumns: ["id"]
          },
        ]
      }
      credit_repair_activity_log: {
        Row: {
          activity_type: string
          case_id: string
          created_at: string
          description: string
          hidden_notes: string | null
          id: string
          metadata: Json | null
          user_id: string
        }
        Insert: {
          activity_type: string
          case_id: string
          created_at?: string
          description: string
          hidden_notes?: string | null
          id?: string
          metadata?: Json | null
          user_id: string
        }
        Update: {
          activity_type?: string
          case_id?: string
          created_at?: string
          description?: string
          hidden_notes?: string | null
          id?: string
          metadata?: Json | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "credit_repair_activity_log_case_id_fkey"
            columns: ["case_id"]
            isOneToOne: false
            referencedRelation: "credit_repair_cases"
            referencedColumns: ["id"]
          },
        ]
      }
      credit_repair_applications: {
        Row: {
          created_at: string
          current_credit_score: string | null
          desired_credit_score: string | null
          email: string
          experian_username: string | null
          follow_up_date: string | null
          full_name: string
          goals: string | null
          has_identity_theft: boolean | null
          id: string
          identity_theft_details: string | null
          negative_items: string | null
          origin_source: string | null
          phone: string
          referral_code: string | null
          status: string
          tenant_id: string | null
          updated_at: string
          user_id: string | null
        }
        Insert: {
          created_at?: string
          current_credit_score?: string | null
          desired_credit_score?: string | null
          email: string
          experian_username?: string | null
          follow_up_date?: string | null
          full_name: string
          goals?: string | null
          has_identity_theft?: boolean | null
          id?: string
          identity_theft_details?: string | null
          negative_items?: string | null
          origin_source?: string | null
          phone: string
          referral_code?: string | null
          status?: string
          tenant_id?: string | null
          updated_at?: string
          user_id?: string | null
        }
        Update: {
          created_at?: string
          current_credit_score?: string | null
          desired_credit_score?: string | null
          email?: string
          experian_username?: string | null
          follow_up_date?: string | null
          full_name?: string
          goals?: string | null
          has_identity_theft?: boolean | null
          id?: string
          identity_theft_details?: string | null
          negative_items?: string | null
          origin_source?: string | null
          phone?: string
          referral_code?: string | null
          status?: string
          tenant_id?: string | null
          updated_at?: string
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "credit_repair_applications_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "wf_tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      credit_repair_cases: {
        Row: {
          ai_last_evaluated_at: string | null
          ai_notes: Json | null
          ai_recommended_path: string | null
          ai_score: number | null
          assigned_specialist_id: string | null
          completed_at: string | null
          created_at: string
          credit_repair_application_id: string
          from_declined_funding: boolean | null
          id: string
          intake_client_id: string | null
          last_eligibility_status: string | null
          last_public_check_at: string | null
          last_scan_at: string | null
          last_soft_score: number | null
          next_scan_at: string | null
          original_application_id: string | null
          original_application_type: string | null
          status: string
          tenant_id: string | null
          updated_at: string
        }
        Insert: {
          ai_last_evaluated_at?: string | null
          ai_notes?: Json | null
          ai_recommended_path?: string | null
          ai_score?: number | null
          assigned_specialist_id?: string | null
          completed_at?: string | null
          created_at?: string
          credit_repair_application_id: string
          from_declined_funding?: boolean | null
          id?: string
          intake_client_id?: string | null
          last_eligibility_status?: string | null
          last_public_check_at?: string | null
          last_scan_at?: string | null
          last_soft_score?: number | null
          next_scan_at?: string | null
          original_application_id?: string | null
          original_application_type?: string | null
          status?: string
          tenant_id?: string | null
          updated_at?: string
        }
        Update: {
          ai_last_evaluated_at?: string | null
          ai_notes?: Json | null
          ai_recommended_path?: string | null
          ai_score?: number | null
          assigned_specialist_id?: string | null
          completed_at?: string | null
          created_at?: string
          credit_repair_application_id?: string
          from_declined_funding?: boolean | null
          id?: string
          intake_client_id?: string | null
          last_eligibility_status?: string | null
          last_public_check_at?: string | null
          last_scan_at?: string | null
          last_soft_score?: number | null
          next_scan_at?: string | null
          original_application_id?: string | null
          original_application_type?: string | null
          status?: string
          tenant_id?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "credit_repair_cases_credit_repair_application_id_fkey"
            columns: ["credit_repair_application_id"]
            isOneToOne: false
            referencedRelation: "credit_repair_applications"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "credit_repair_cases_intake_client_id_fkey"
            columns: ["intake_client_id"]
            isOneToOne: false
            referencedRelation: "intake_clients"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "credit_repair_cases_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "wf_tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      credit_repair_dispute_drafts: {
        Row: {
          body: string
          case_id: string
          created_at: string
          created_by: string
          id: string
          item_id: string | null
          signature: string | null
          status: string
          subject: string
          target: string
          target_name: string
          updated_at: string
          worker_type: string
        }
        Insert: {
          body: string
          case_id: string
          created_at?: string
          created_by: string
          id?: string
          item_id?: string | null
          signature?: string | null
          status?: string
          subject: string
          target: string
          target_name: string
          updated_at?: string
          worker_type?: string
        }
        Update: {
          body?: string
          case_id?: string
          created_at?: string
          created_by?: string
          id?: string
          item_id?: string | null
          signature?: string | null
          status?: string
          subject?: string
          target?: string
          target_name?: string
          updated_at?: string
          worker_type?: string
        }
        Relationships: [
          {
            foreignKeyName: "credit_repair_dispute_drafts_case_id_fkey"
            columns: ["case_id"]
            isOneToOne: false
            referencedRelation: "credit_repair_cases"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "credit_repair_dispute_drafts_item_id_fkey"
            columns: ["item_id"]
            isOneToOne: false
            referencedRelation: "credit_repair_items"
            referencedColumns: ["id"]
          },
        ]
      }
      credit_repair_items: {
        Row: {
          account_number: string | null
          ai_generated: boolean | null
          ai_last_reviewed_at: string | null
          case_id: string
          client_state: string | null
          collector_state: string | null
          created_at: string
          creditor_name: string | null
          dispute_basis_code: string | null
          dispute_date: string | null
          dispute_reason: string | null
          fcra_section: string | null
          fdcpa_section: string | null
          id: string
          item_type: string
          metro2_code: string | null
          notes: string | null
          resolution_date: string | null
          resolution_outcome: string | null
          risk_tags: string[] | null
          source_bureau: string | null
          status: string
          updated_at: string
        }
        Insert: {
          account_number?: string | null
          ai_generated?: boolean | null
          ai_last_reviewed_at?: string | null
          case_id: string
          client_state?: string | null
          collector_state?: string | null
          created_at?: string
          creditor_name?: string | null
          dispute_basis_code?: string | null
          dispute_date?: string | null
          dispute_reason?: string | null
          fcra_section?: string | null
          fdcpa_section?: string | null
          id?: string
          item_type: string
          metro2_code?: string | null
          notes?: string | null
          resolution_date?: string | null
          resolution_outcome?: string | null
          risk_tags?: string[] | null
          source_bureau?: string | null
          status?: string
          updated_at?: string
        }
        Update: {
          account_number?: string | null
          ai_generated?: boolean | null
          ai_last_reviewed_at?: string | null
          case_id?: string
          client_state?: string | null
          collector_state?: string | null
          created_at?: string
          creditor_name?: string | null
          dispute_basis_code?: string | null
          dispute_date?: string | null
          dispute_reason?: string | null
          fcra_section?: string | null
          fdcpa_section?: string | null
          id?: string
          item_type?: string
          metro2_code?: string | null
          notes?: string | null
          resolution_date?: string | null
          resolution_outcome?: string | null
          risk_tags?: string[] | null
          source_bureau?: string | null
          status?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "credit_repair_items_case_id_fkey"
            columns: ["case_id"]
            isOneToOne: false
            referencedRelation: "credit_repair_cases"
            referencedColumns: ["id"]
          },
        ]
      }
      credit_repair_tasks: {
        Row: {
          assigned_to: string | null
          case_id: string
          completed: boolean | null
          completed_at: string | null
          created_at: string
          description: string | null
          due_date: string | null
          id: string
          source: string | null
          title: string
          updated_at: string
        }
        Insert: {
          assigned_to?: string | null
          case_id: string
          completed?: boolean | null
          completed_at?: string | null
          created_at?: string
          description?: string | null
          due_date?: string | null
          id?: string
          source?: string | null
          title: string
          updated_at?: string
        }
        Update: {
          assigned_to?: string | null
          case_id?: string
          completed?: boolean | null
          completed_at?: string | null
          created_at?: string
          description?: string | null
          due_date?: string | null
          id?: string
          source?: string | null
          title?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "credit_repair_tasks_case_id_fkey"
            columns: ["case_id"]
            isOneToOne: false
            referencedRelation: "credit_repair_cases"
            referencedColumns: ["id"]
          },
        ]
      }
      credit_standards_reference: {
        Row: {
          created_at: string | null
          description: string | null
          id: string
          jurisdiction: string | null
          reference_code: string
          standard_type: string
        }
        Insert: {
          created_at?: string | null
          description?: string | null
          id?: string
          jurisdiction?: string | null
          reference_code: string
          standard_type: string
        }
        Update: {
          created_at?: string | null
          description?: string | null
          id?: string
          jurisdiction?: string | null
          reference_code?: string
          standard_type?: string
        }
        Relationships: []
      }
      deal_commissions: {
        Row: {
          base_amount: number
          beneficiary_tenant_id: string | null
          beneficiary_type: string
          beneficiary_user_id: string | null
          computed_amount: number | null
          created_at: string
          currency_code: string
          deal_id: string
          flat_amount: number | null
          id: string
          notes: string | null
          percent_of_funder_fee: number | null
          status: string
          tenant_id: string | null
          updated_at: string
        }
        Insert: {
          base_amount?: number
          beneficiary_tenant_id?: string | null
          beneficiary_type: string
          beneficiary_user_id?: string | null
          computed_amount?: number | null
          created_at?: string
          currency_code?: string
          deal_id: string
          flat_amount?: number | null
          id?: string
          notes?: string | null
          percent_of_funder_fee?: number | null
          status?: string
          tenant_id?: string | null
          updated_at?: string
        }
        Update: {
          base_amount?: number
          beneficiary_tenant_id?: string | null
          beneficiary_type?: string
          beneficiary_user_id?: string | null
          computed_amount?: number | null
          created_at?: string
          currency_code?: string
          deal_id?: string
          flat_amount?: number | null
          id?: string
          notes?: string | null
          percent_of_funder_fee?: number | null
          status?: string
          tenant_id?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "deal_commissions_deal_id_fkey"
            columns: ["deal_id"]
            isOneToOne: false
            referencedRelation: "deals"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "deal_commissions_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "wf_tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      deal_documents: {
        Row: {
          created_at: string | null
          deal_id: string | null
          doc_type: string | null
          extracted_data: Json | null
          id: string
          status: string | null
          tenant_id: string | null
          url: string | null
        }
        Insert: {
          created_at?: string | null
          deal_id?: string | null
          doc_type?: string | null
          extracted_data?: Json | null
          id?: string
          status?: string | null
          tenant_id?: string | null
          url?: string | null
        }
        Update: {
          created_at?: string | null
          deal_id?: string | null
          doc_type?: string | null
          extracted_data?: Json | null
          id?: string
          status?: string | null
          tenant_id?: string | null
          url?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "deal_documents_deal_id_fkey"
            columns: ["deal_id"]
            isOneToOne: false
            referencedRelation: "deals"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "deal_documents_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "wf_tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      deal_events: {
        Row: {
          created_at: string | null
          created_by: string | null
          deal_id: string | null
          event_type: string | null
          id: string
          metadata: Json | null
          tenant_id: string | null
        }
        Insert: {
          created_at?: string | null
          created_by?: string | null
          deal_id?: string | null
          event_type?: string | null
          id?: string
          metadata?: Json | null
          tenant_id?: string | null
        }
        Update: {
          created_at?: string | null
          created_by?: string | null
          deal_id?: string | null
          event_type?: string | null
          id?: string
          metadata?: Json | null
          tenant_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "deal_events_deal_id_fkey"
            columns: ["deal_id"]
            isOneToOne: false
            referencedRelation: "deals"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "deal_events_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "wf_tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      deal_funder_assignments: {
        Row: {
          assigned_at: string
          assigned_by: string
          created_at: string
          deal_id: string
          funder_tenant_id: string | null
          funder_user_id: string
          id: string
          offer_amount: number | null
          offer_factor_rate: number | null
          offer_notes: string | null
          status: string
          updated_at: string
        }
        Insert: {
          assigned_at?: string
          assigned_by: string
          created_at?: string
          deal_id: string
          funder_tenant_id?: string | null
          funder_user_id: string
          id?: string
          offer_amount?: number | null
          offer_factor_rate?: number | null
          offer_notes?: string | null
          status?: string
          updated_at?: string
        }
        Update: {
          assigned_at?: string
          assigned_by?: string
          created_at?: string
          deal_id?: string
          funder_tenant_id?: string | null
          funder_user_id?: string
          id?: string
          offer_amount?: number | null
          offer_factor_rate?: number | null
          offer_notes?: string | null
          status?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "deal_funder_assignments_deal_id_fkey"
            columns: ["deal_id"]
            isOneToOne: false
            referencedRelation: "deals"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "deal_funder_assignments_funder_tenant_id_fkey"
            columns: ["funder_tenant_id"]
            isOneToOne: false
            referencedRelation: "wf_tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      deal_offers: {
        Row: {
          approved_amount: number | null
          created_at: string | null
          daily_payment: number | null
          deal_id: string | null
          expires_at: string | null
          factor_rate: number | null
          funder_id: string | null
          id: string
          payback_amount: number | null
          payment_frequency: string | null
          status: string | null
          tenant_id: string | null
          term_days: number | null
          updated_at: string | null
        }
        Insert: {
          approved_amount?: number | null
          created_at?: string | null
          daily_payment?: number | null
          deal_id?: string | null
          expires_at?: string | null
          factor_rate?: number | null
          funder_id?: string | null
          id?: string
          payback_amount?: number | null
          payment_frequency?: string | null
          status?: string | null
          tenant_id?: string | null
          term_days?: number | null
          updated_at?: string | null
        }
        Update: {
          approved_amount?: number | null
          created_at?: string | null
          daily_payment?: number | null
          deal_id?: string | null
          expires_at?: string | null
          factor_rate?: number | null
          funder_id?: string | null
          id?: string
          payback_amount?: number | null
          payment_frequency?: string | null
          status?: string | null
          tenant_id?: string | null
          term_days?: number | null
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "deal_offers_deal_id_fkey"
            columns: ["deal_id"]
            isOneToOne: false
            referencedRelation: "deals"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "deal_offers_funder_id_fkey"
            columns: ["funder_id"]
            isOneToOne: false
            referencedRelation: "funders"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "deal_offers_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "wf_tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      deal_participants: {
        Row: {
          amount: number
          created_at: string
          deal_id: string
          entity_id: string | null
          entity_name: string | null
          entity_type: string | null
          id: string
          notes: string | null
          paid_at: string | null
          payment_status: string
          percent_of_pool: number
          role: string
        }
        Insert: {
          amount?: number
          created_at?: string
          deal_id: string
          entity_id?: string | null
          entity_name?: string | null
          entity_type?: string | null
          id?: string
          notes?: string | null
          paid_at?: string | null
          payment_status?: string
          percent_of_pool?: number
          role: string
        }
        Update: {
          amount?: number
          created_at?: string
          deal_id?: string
          entity_id?: string | null
          entity_name?: string | null
          entity_type?: string | null
          id?: string
          notes?: string | null
          paid_at?: string | null
          payment_status?: string
          percent_of_pool?: number
          role?: string
        }
        Relationships: [
          {
            foreignKeyName: "deal_participants_deal_id_fkey"
            columns: ["deal_id"]
            isOneToOne: false
            referencedRelation: "deals"
            referencedColumns: ["id"]
          },
        ]
      }
      deal_rooms: {
        Row: {
          can_send_contract: boolean | null
          can_send_offer: boolean | null
          can_view_bank_data: boolean | null
          communication_channel: string | null
          created_at: string | null
          expires_at: string | null
          funder_agreed_at: string | null
          funder_agreed_terms: boolean | null
          funder_id: string | null
          id: string
          last_funder_action_at: string | null
          no_backdoor_signed: boolean | null
          status: string
          total_communications: number | null
          updated_at: string | null
          vault_id: string
        }
        Insert: {
          can_send_contract?: boolean | null
          can_send_offer?: boolean | null
          can_view_bank_data?: boolean | null
          communication_channel?: string | null
          created_at?: string | null
          expires_at?: string | null
          funder_agreed_at?: string | null
          funder_agreed_terms?: boolean | null
          funder_id?: string | null
          id?: string
          last_funder_action_at?: string | null
          no_backdoor_signed?: boolean | null
          status?: string
          total_communications?: number | null
          updated_at?: string | null
          vault_id: string
        }
        Update: {
          can_send_contract?: boolean | null
          can_send_offer?: boolean | null
          can_view_bank_data?: boolean | null
          communication_channel?: string | null
          created_at?: string | null
          expires_at?: string | null
          funder_agreed_at?: string | null
          funder_agreed_terms?: boolean | null
          funder_id?: string | null
          id?: string
          last_funder_action_at?: string | null
          no_backdoor_signed?: boolean | null
          status?: string
          total_communications?: number | null
          updated_at?: string | null
          vault_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "deal_rooms_funder_id_fkey"
            columns: ["funder_id"]
            isOneToOne: false
            referencedRelation: "funders"
            referencedColumns: ["id"]
          },
        ]
      }
      deals: {
        Row: {
          amount_funded: number | null
          application_id: string | null
          application_type: string | null
          autopilot: boolean | null
          client_email: string | null
          closer_user_id: string | null
          commission_debug_json: Json | null
          created_at: string | null
          created_by: string | null
          funded_amount: number | null
          funded_at: string | null
          gross_commission_pool: number | null
          id: string
          intake_client_id: string | null
          iso_partner_id: string | null
          lead_id: string | null
          lead_source: string | null
          lead_source_label: string | null
          notes: string | null
          opener_user_id: string | null
          primary_closer_id: string | null
          referral_code: string | null
          referral_entity_id: string | null
          referral_owner_type: string | null
          secondary_closer_id: string | null
          split_primary_pct: number | null
          split_secondary_pct: number | null
          status: string
          tenant_id: string | null
          updated_at: string | null
        }
        Insert: {
          amount_funded?: number | null
          application_id?: string | null
          application_type?: string | null
          autopilot?: boolean | null
          client_email?: string | null
          closer_user_id?: string | null
          commission_debug_json?: Json | null
          created_at?: string | null
          created_by?: string | null
          funded_amount?: number | null
          funded_at?: string | null
          gross_commission_pool?: number | null
          id?: string
          intake_client_id?: string | null
          iso_partner_id?: string | null
          lead_id?: string | null
          lead_source?: string | null
          lead_source_label?: string | null
          notes?: string | null
          opener_user_id?: string | null
          primary_closer_id?: string | null
          referral_code?: string | null
          referral_entity_id?: string | null
          referral_owner_type?: string | null
          secondary_closer_id?: string | null
          split_primary_pct?: number | null
          split_secondary_pct?: number | null
          status?: string
          tenant_id?: string | null
          updated_at?: string | null
        }
        Update: {
          amount_funded?: number | null
          application_id?: string | null
          application_type?: string | null
          autopilot?: boolean | null
          client_email?: string | null
          closer_user_id?: string | null
          commission_debug_json?: Json | null
          created_at?: string | null
          created_by?: string | null
          funded_amount?: number | null
          funded_at?: string | null
          gross_commission_pool?: number | null
          id?: string
          intake_client_id?: string | null
          iso_partner_id?: string | null
          lead_id?: string | null
          lead_source?: string | null
          lead_source_label?: string | null
          notes?: string | null
          opener_user_id?: string | null
          primary_closer_id?: string | null
          referral_code?: string | null
          referral_entity_id?: string | null
          referral_owner_type?: string | null
          secondary_closer_id?: string | null
          split_primary_pct?: number | null
          split_secondary_pct?: number | null
          status?: string
          tenant_id?: string | null
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "deals_intake_client_id_fkey"
            columns: ["intake_client_id"]
            isOneToOne: false
            referencedRelation: "intake_clients"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "deals_iso_partner_id_fkey"
            columns: ["iso_partner_id"]
            isOneToOne: false
            referencedRelation: "iso_partners"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "deals_lead_id_fkey"
            columns: ["lead_id"]
            isOneToOne: false
            referencedRelation: "leads"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "deals_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "wf_tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      document_extractions: {
        Row: {
          application_id: string
          application_type: string
          created_at: string | null
          document_type: string
          id: string
          parsed_data: Json
          raw_text: string | null
        }
        Insert: {
          application_id: string
          application_type: string
          created_at?: string | null
          document_type: string
          id?: string
          parsed_data?: Json
          raw_text?: string | null
        }
        Update: {
          application_id?: string
          application_type?: string
          created_at?: string | null
          document_type?: string
          id?: string
          parsed_data?: Json
          raw_text?: string | null
        }
        Relationships: []
      }
      document_templates: {
        Row: {
          category: string
          created_at: string
          created_by: string | null
          description: string | null
          id: string
          is_active: boolean
          name: string
          placeholders: Json
          template_body: string
          updated_at: string
          updated_by: string | null
          version: number
        }
        Insert: {
          category: string
          created_at?: string
          created_by?: string | null
          description?: string | null
          id?: string
          is_active?: boolean
          name: string
          placeholders?: Json
          template_body: string
          updated_at?: string
          updated_by?: string | null
          version?: number
        }
        Update: {
          category?: string
          created_at?: string
          created_by?: string | null
          description?: string | null
          id?: string
          is_active?: boolean
          name?: string
          placeholders?: Json
          template_body?: string
          updated_at?: string
          updated_by?: string | null
          version?: number
        }
        Relationships: []
      }
      email_messages: {
        Row: {
          body: string | null
          channel: string | null
          client_id: string | null
          created_at: string | null
          created_by: string | null
          direction: string | null
          email_from: string | null
          email_to: string | null
          id: string
          lead_id: string | null
          status: string | null
          subject: string | null
        }
        Insert: {
          body?: string | null
          channel?: string | null
          client_id?: string | null
          created_at?: string | null
          created_by?: string | null
          direction?: string | null
          email_from?: string | null
          email_to?: string | null
          id?: string
          lead_id?: string | null
          status?: string | null
          subject?: string | null
        }
        Update: {
          body?: string | null
          channel?: string | null
          client_id?: string | null
          created_at?: string | null
          created_by?: string | null
          direction?: string | null
          email_from?: string | null
          email_to?: string | null
          id?: string
          lead_id?: string | null
          status?: string | null
          subject?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "email_messages_client_id_fkey"
            columns: ["client_id"]
            isOneToOne: false
            referencedRelation: "intake_clients"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "email_messages_lead_id_fkey"
            columns: ["lead_id"]
            isOneToOne: false
            referencedRelation: "leads"
            referencedColumns: ["id"]
          },
        ]
      }
      email_templates: {
        Row: {
          body: string
          created_at: string | null
          created_by: string | null
          id: string
          is_default: boolean | null
          name: string
          subject: string
          template_type: string
          updated_at: string | null
        }
        Insert: {
          body: string
          created_at?: string | null
          created_by?: string | null
          id?: string
          is_default?: boolean | null
          name: string
          subject: string
          template_type: string
          updated_at?: string | null
        }
        Update: {
          body?: string
          created_at?: string | null
          created_by?: string | null
          id?: string
          is_default?: boolean | null
          name?: string
          subject?: string
          template_type?: string
          updated_at?: string | null
        }
        Relationships: []
      }
      fast_track_applications: {
        Row: {
          ad_group: string | null
          ai_last_evaluated_at: string | null
          ai_notes: Json | null
          ai_recommended_path: string | null
          ai_score: number | null
          bank_statements: string[] | null
          business_name: string
          campaign: string | null
          client_name: string | null
          created_at: string
          creative_id: string | null
          credit_card_statement: string | null
          credit_score: string | null
          driver_license_back: string | null
          driver_license_front: string | null
          ein_document: string | null
          email: string
          follow_up_date: string | null
          has_previous_loan: boolean
          id: string
          in_business_over_6_months: boolean
          intake_client_id: string | null
          iso_partner_id: string | null
          last_scan_at: string | null
          next_scan_at: string | null
          origin_source: string | null
          originated_by_worker_id: string | null
          phone: string
          previous_loan_amount: string | null
          previous_loan_company: string | null
          referral_code: string | null
          source: string | null
          ssn_card: string | null
          status: string
          tenant_id: string | null
          updated_at: string
          user_id: string | null
          void_check: string | null
        }
        Insert: {
          ad_group?: string | null
          ai_last_evaluated_at?: string | null
          ai_notes?: Json | null
          ai_recommended_path?: string | null
          ai_score?: number | null
          bank_statements?: string[] | null
          business_name: string
          campaign?: string | null
          client_name?: string | null
          created_at?: string
          creative_id?: string | null
          credit_card_statement?: string | null
          credit_score?: string | null
          driver_license_back?: string | null
          driver_license_front?: string | null
          ein_document?: string | null
          email: string
          follow_up_date?: string | null
          has_previous_loan: boolean
          id?: string
          in_business_over_6_months: boolean
          intake_client_id?: string | null
          iso_partner_id?: string | null
          last_scan_at?: string | null
          next_scan_at?: string | null
          origin_source?: string | null
          originated_by_worker_id?: string | null
          phone: string
          previous_loan_amount?: string | null
          previous_loan_company?: string | null
          referral_code?: string | null
          source?: string | null
          ssn_card?: string | null
          status?: string
          tenant_id?: string | null
          updated_at?: string
          user_id?: string | null
          void_check?: string | null
        }
        Update: {
          ad_group?: string | null
          ai_last_evaluated_at?: string | null
          ai_notes?: Json | null
          ai_recommended_path?: string | null
          ai_score?: number | null
          bank_statements?: string[] | null
          business_name?: string
          campaign?: string | null
          client_name?: string | null
          created_at?: string
          creative_id?: string | null
          credit_card_statement?: string | null
          credit_score?: string | null
          driver_license_back?: string | null
          driver_license_front?: string | null
          ein_document?: string | null
          email?: string
          follow_up_date?: string | null
          has_previous_loan?: boolean
          id?: string
          in_business_over_6_months?: boolean
          intake_client_id?: string | null
          iso_partner_id?: string | null
          last_scan_at?: string | null
          next_scan_at?: string | null
          origin_source?: string | null
          originated_by_worker_id?: string | null
          phone?: string
          previous_loan_amount?: string | null
          previous_loan_company?: string | null
          referral_code?: string | null
          source?: string | null
          ssn_card?: string | null
          status?: string
          tenant_id?: string | null
          updated_at?: string
          user_id?: string | null
          void_check?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "fast_track_applications_intake_client_id_fkey"
            columns: ["intake_client_id"]
            isOneToOne: false
            referencedRelation: "intake_clients"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "fast_track_applications_iso_partner_id_fkey"
            columns: ["iso_partner_id"]
            isOneToOne: false
            referencedRelation: "iso_partner_applications"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "fast_track_applications_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "wf_tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      fund_deal_allocations: {
        Row: {
          allocated_principal: number
          created_at: string
          deal_id: string
          fund_id: string | null
          id: string
          participation_pct: number | null
          spv_id: string | null
        }
        Insert: {
          allocated_principal: number
          created_at?: string
          deal_id: string
          fund_id?: string | null
          id?: string
          participation_pct?: number | null
          spv_id?: string | null
        }
        Update: {
          allocated_principal?: number
          created_at?: string
          deal_id?: string
          fund_id?: string | null
          id?: string
          participation_pct?: number | null
          spv_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "fund_deal_allocations_fund_id_fkey"
            columns: ["fund_id"]
            isOneToOne: false
            referencedRelation: "funds"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "fund_deal_allocations_spv_id_fkey"
            columns: ["spv_id"]
            isOneToOne: false
            referencedRelation: "spvs"
            referencedColumns: ["id"]
          },
        ]
      }
      funded_contracts: {
        Row: {
          application_id: string
          application_type: string
          business_name: string
          client_name: string
          contract_end_date: string
          contract_start_date: string
          created_at: string | null
          daily_payment: number | null
          funding_amount: number
          id: string
          intake_client_id: string | null
          notes: string | null
          original_credit_score: string | null
          original_revenue: number | null
          renewal_eligible: boolean | null
          status: string
          tenant_id: string | null
          updated_at: string | null
        }
        Insert: {
          application_id: string
          application_type: string
          business_name: string
          client_name: string
          contract_end_date: string
          contract_start_date?: string
          created_at?: string | null
          daily_payment?: number | null
          funding_amount: number
          id?: string
          intake_client_id?: string | null
          notes?: string | null
          original_credit_score?: string | null
          original_revenue?: number | null
          renewal_eligible?: boolean | null
          status?: string
          tenant_id?: string | null
          updated_at?: string | null
        }
        Update: {
          application_id?: string
          application_type?: string
          business_name?: string
          client_name?: string
          contract_end_date?: string
          contract_start_date?: string
          created_at?: string | null
          daily_payment?: number | null
          funding_amount?: number
          id?: string
          intake_client_id?: string | null
          notes?: string | null
          original_credit_score?: string | null
          original_revenue?: number | null
          renewal_eligible?: boolean | null
          status?: string
          tenant_id?: string | null
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "funded_contracts_intake_client_id_fkey"
            columns: ["intake_client_id"]
            isOneToOne: false
            referencedRelation: "intake_clients"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "funded_contracts_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "wf_tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      funded_deals: {
        Row: {
          application_id: string
          commission_amount: number | null
          commission_rate: number | null
          created_at: string
          funded_amount: number
          funded_date: string
          funder_id: string | null
          id: string
          iso_partner_id: string | null
          notes: string | null
          originated_by_worker_id: string | null
          product_type: string | null
          source_type: string | null
          status: string
          updated_at: string
        }
        Insert: {
          application_id: string
          commission_amount?: number | null
          commission_rate?: number | null
          created_at?: string
          funded_amount: number
          funded_date?: string
          funder_id?: string | null
          id?: string
          iso_partner_id?: string | null
          notes?: string | null
          originated_by_worker_id?: string | null
          product_type?: string | null
          source_type?: string | null
          status?: string
          updated_at?: string
        }
        Update: {
          application_id?: string
          commission_amount?: number | null
          commission_rate?: number | null
          created_at?: string
          funded_amount?: number
          funded_date?: string
          funder_id?: string | null
          id?: string
          iso_partner_id?: string | null
          notes?: string | null
          originated_by_worker_id?: string | null
          product_type?: string | null
          source_type?: string | null
          status?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "funded_deals_application_id_fkey"
            columns: ["application_id"]
            isOneToOne: false
            referencedRelation: "fast_track_applications"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "funded_deals_funder_id_fkey"
            columns: ["funder_id"]
            isOneToOne: false
            referencedRelation: "funders"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "funded_deals_iso_partner_id_fkey"
            columns: ["iso_partner_id"]
            isOneToOne: false
            referencedRelation: "iso_partner_applications"
            referencedColumns: ["id"]
          },
        ]
      }
      funder_applications: {
        Row: {
          company_address: string | null
          company_email: string
          company_name: string
          company_phone: string | null
          company_type: string | null
          contact_email: string
          contact_name: string
          contact_phone: string | null
          contact_role: string | null
          created_at: string | null
          id: string
          industries_served: string[] | null
          lending_products: string[] | null
          max_deal_size: string | null
          min_deal_size: string | null
          monthly_capacity: string | null
          notes: string | null
          origin_source: string | null
          reviewed_at: string | null
          reviewed_by: string | null
          states_served: string[] | null
          status: string | null
          tenant_id: string | null
          updated_at: string | null
          user_id: string | null
        }
        Insert: {
          company_address?: string | null
          company_email: string
          company_name: string
          company_phone?: string | null
          company_type?: string | null
          contact_email: string
          contact_name: string
          contact_phone?: string | null
          contact_role?: string | null
          created_at?: string | null
          id?: string
          industries_served?: string[] | null
          lending_products?: string[] | null
          max_deal_size?: string | null
          min_deal_size?: string | null
          monthly_capacity?: string | null
          notes?: string | null
          origin_source?: string | null
          reviewed_at?: string | null
          reviewed_by?: string | null
          states_served?: string[] | null
          status?: string | null
          tenant_id?: string | null
          updated_at?: string | null
          user_id?: string | null
        }
        Update: {
          company_address?: string | null
          company_email?: string
          company_name?: string
          company_phone?: string | null
          company_type?: string | null
          contact_email?: string
          contact_name?: string
          contact_phone?: string | null
          contact_role?: string | null
          created_at?: string | null
          id?: string
          industries_served?: string[] | null
          lending_products?: string[] | null
          max_deal_size?: string | null
          min_deal_size?: string | null
          monthly_capacity?: string | null
          notes?: string | null
          origin_source?: string | null
          reviewed_at?: string | null
          reviewed_by?: string | null
          states_served?: string[] | null
          status?: string | null
          tenant_id?: string | null
          updated_at?: string | null
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "funder_applications_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "wf_tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      funder_communication_log: {
        Row: {
          communication_type: string
          created_at: string | null
          deal_room_id: string | null
          delivered_at: string | null
          direction: string
          funder_id: string | null
          id: string
          metadata: Json | null
          status: string | null
          summary: string | null
          vault_id: string
        }
        Insert: {
          communication_type: string
          created_at?: string | null
          deal_room_id?: string | null
          delivered_at?: string | null
          direction: string
          funder_id?: string | null
          id?: string
          metadata?: Json | null
          status?: string | null
          summary?: string | null
          vault_id: string
        }
        Update: {
          communication_type?: string
          created_at?: string | null
          deal_room_id?: string | null
          delivered_at?: string | null
          direction?: string
          funder_id?: string | null
          id?: string
          metadata?: Json | null
          status?: string | null
          summary?: string | null
          vault_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "funder_communication_log_deal_room_id_fkey"
            columns: ["deal_room_id"]
            isOneToOne: false
            referencedRelation: "deal_rooms"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "funder_communication_log_funder_id_fkey"
            columns: ["funder_id"]
            isOneToOne: false
            referencedRelation: "funders"
            referencedColumns: ["id"]
          },
        ]
      }
      funder_submissions: {
        Row: {
          application_id: string
          application_type: string
          attachments_included: Json | null
          created_at: string | null
          funder_id: string | null
          id: string
          mode: string
          sent_at: string | null
          status: string | null
        }
        Insert: {
          application_id: string
          application_type: string
          attachments_included?: Json | null
          created_at?: string | null
          funder_id?: string | null
          id?: string
          mode: string
          sent_at?: string | null
          status?: string | null
        }
        Update: {
          application_id?: string
          application_type?: string
          attachments_included?: Json | null
          created_at?: string | null
          funder_id?: string | null
          id?: string
          mode?: string
          sent_at?: string | null
          status?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "funder_submissions_funder_id_fkey"
            columns: ["funder_id"]
            isOneToOne: false
            referencedRelation: "funders"
            referencedColumns: ["id"]
          },
        ]
      }
      funders: {
        Row: {
          agreement_signed_at: string | null
          contact_email: string
          created_at: string | null
          id: string
          name: string
          no_backdoor_agreement: boolean | null
          portal_url: string | null
          preferences: Json | null
          tier: string | null
          updated_at: string | null
          user_id: string | null
        }
        Insert: {
          agreement_signed_at?: string | null
          contact_email: string
          created_at?: string | null
          id?: string
          name: string
          no_backdoor_agreement?: boolean | null
          portal_url?: string | null
          preferences?: Json | null
          tier?: string | null
          updated_at?: string | null
          user_id?: string | null
        }
        Update: {
          agreement_signed_at?: string | null
          contact_email?: string
          created_at?: string | null
          id?: string
          name?: string
          no_backdoor_agreement?: boolean | null
          portal_url?: string | null
          preferences?: Json | null
          tier?: string | null
          updated_at?: string | null
          user_id?: string | null
        }
        Relationships: []
      }
      funding_calls: {
        Row: {
          application_id: string
          created_at: string
          created_by: string | null
          dial_method: string | null
          id: string
          notes: string | null
          scheduled_for: string | null
          status: string
          updated_at: string
        }
        Insert: {
          application_id: string
          created_at?: string
          created_by?: string | null
          dial_method?: string | null
          id?: string
          notes?: string | null
          scheduled_for?: string | null
          status?: string
          updated_at?: string
        }
        Update: {
          application_id?: string
          created_at?: string
          created_by?: string | null
          dial_method?: string | null
          id?: string
          notes?: string | null
          scheduled_for?: string | null
          status?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "funding_calls_application_id_fkey"
            columns: ["application_id"]
            isOneToOne: false
            referencedRelation: "fast_track_applications"
            referencedColumns: ["id"]
          },
        ]
      }
      funds: {
        Row: {
          code: string
          created_at: string
          description: string | null
          id: string
          name: string
          status: string
          updated_at: string
        }
        Insert: {
          code: string
          created_at?: string
          description?: string | null
          id?: string
          name: string
          status?: string
          updated_at?: string
        }
        Update: {
          code?: string
          created_at?: string
          description?: string | null
          id?: string
          name?: string
          status?: string
          updated_at?: string
        }
        Relationships: []
      }
      industry_rules: {
        Row: {
          created_at: string
          excluded: boolean
          id: string
          industry_label: string
          naics_code: string | null
          notes: string | null
          product_allowed: boolean
          updated_at: string
        }
        Insert: {
          created_at?: string
          excluded?: boolean
          id?: string
          industry_label: string
          naics_code?: string | null
          notes?: string | null
          product_allowed?: boolean
          updated_at?: string
        }
        Update: {
          created_at?: string
          excluded?: boolean
          id?: string
          industry_label?: string
          naics_code?: string | null
          notes?: string | null
          product_allowed?: boolean
          updated_at?: string
        }
        Relationships: []
      }
      intake_clients: {
        Row: {
          address: string | null
          ai_created_at: string | null
          ai_credit_risk: string | null
          ai_funding_path: string | null
          ai_funding_score: number | null
          ai_identity_theft_risk: string | null
          ai_industry_risk: string | null
          ai_summary: Json | null
          business_name: string | null
          city: string | null
          created_at: string | null
          email_primary: string | null
          email_secondary: string | null
          full_name: string | null
          id: string
          intake_source: string | null
          lead_id: string | null
          phone_primary: string | null
          phone_secondary: string | null
          primary_path: string | null
          stage: string | null
          state: string | null
          tenant_id: string | null
          updated_at: string | null
          vault_id: string | null
          website: string | null
          zip: string | null
        }
        Insert: {
          address?: string | null
          ai_created_at?: string | null
          ai_credit_risk?: string | null
          ai_funding_path?: string | null
          ai_funding_score?: number | null
          ai_identity_theft_risk?: string | null
          ai_industry_risk?: string | null
          ai_summary?: Json | null
          business_name?: string | null
          city?: string | null
          created_at?: string | null
          email_primary?: string | null
          email_secondary?: string | null
          full_name?: string | null
          id?: string
          intake_source?: string | null
          lead_id?: string | null
          phone_primary?: string | null
          phone_secondary?: string | null
          primary_path?: string | null
          stage?: string | null
          state?: string | null
          tenant_id?: string | null
          updated_at?: string | null
          vault_id?: string | null
          website?: string | null
          zip?: string | null
        }
        Update: {
          address?: string | null
          ai_created_at?: string | null
          ai_credit_risk?: string | null
          ai_funding_path?: string | null
          ai_funding_score?: number | null
          ai_identity_theft_risk?: string | null
          ai_industry_risk?: string | null
          ai_summary?: Json | null
          business_name?: string | null
          city?: string | null
          created_at?: string | null
          email_primary?: string | null
          email_secondary?: string | null
          full_name?: string | null
          id?: string
          intake_source?: string | null
          lead_id?: string | null
          phone_primary?: string | null
          phone_secondary?: string | null
          primary_path?: string | null
          stage?: string | null
          state?: string | null
          tenant_id?: string | null
          updated_at?: string | null
          vault_id?: string | null
          website?: string | null
          zip?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "intake_clients_lead_id_fkey"
            columns: ["lead_id"]
            isOneToOne: false
            referencedRelation: "leads"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "intake_clients_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "wf_tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      intake_logs: {
        Row: {
          client_name: string
          created_at: string
          email: string
          follow_up_date: string | null
          id: string
          lead_type: string
          notes: string | null
          phone: string
          status: string
          updated_at: string
          worker_id: string
        }
        Insert: {
          client_name: string
          created_at?: string
          email: string
          follow_up_date?: string | null
          id?: string
          lead_type: string
          notes?: string | null
          phone: string
          status?: string
          updated_at?: string
          worker_id: string
        }
        Update: {
          client_name?: string
          created_at?: string
          email?: string
          follow_up_date?: string | null
          id?: string
          lead_type?: string
          notes?: string | null
          phone?: string
          status?: string
          updated_at?: string
          worker_id?: string
        }
        Relationships: []
      }
      investor_positions: {
        Row: {
          committed: number
          contributed: number
          created_at: string
          fund_id: string | null
          id: string
          investor_id: string
          preferred_return_pct: number | null
          returned: number
          spv_id: string | null
          updated_at: string
        }
        Insert: {
          committed: number
          contributed?: number
          created_at?: string
          fund_id?: string | null
          id?: string
          investor_id: string
          preferred_return_pct?: number | null
          returned?: number
          spv_id?: string | null
          updated_at?: string
        }
        Update: {
          committed?: number
          contributed?: number
          created_at?: string
          fund_id?: string | null
          id?: string
          investor_id?: string
          preferred_return_pct?: number | null
          returned?: number
          spv_id?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "investor_positions_fund_id_fkey"
            columns: ["fund_id"]
            isOneToOne: false
            referencedRelation: "funds"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "investor_positions_investor_id_fkey"
            columns: ["investor_id"]
            isOneToOne: false
            referencedRelation: "investors"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "investor_positions_spv_id_fkey"
            columns: ["spv_id"]
            isOneToOne: false
            referencedRelation: "spvs"
            referencedColumns: ["id"]
          },
        ]
      }
      investors: {
        Row: {
          created_at: string
          email: string | null
          entity_type: string
          id: string
          name: string
          notes: string | null
          phone: string | null
          updated_at: string
        }
        Insert: {
          created_at?: string
          email?: string | null
          entity_type?: string
          id?: string
          name: string
          notes?: string | null
          phone?: string | null
          updated_at?: string
        }
        Update: {
          created_at?: string
          email?: string | null
          entity_type?: string
          id?: string
          name?: string
          notes?: string | null
          phone?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      iso_commissions: {
        Row: {
          commission_amount: number
          commission_rate: number
          created_at: string
          funded_contract_id: string
          id: string
          iso_partner_id: string
          notes: string | null
          payment_date: string | null
          payment_method: string | null
          payment_status: string
          updated_at: string
        }
        Insert: {
          commission_amount: number
          commission_rate: number
          created_at?: string
          funded_contract_id: string
          id?: string
          iso_partner_id: string
          notes?: string | null
          payment_date?: string | null
          payment_method?: string | null
          payment_status?: string
          updated_at?: string
        }
        Update: {
          commission_amount?: number
          commission_rate?: number
          created_at?: string
          funded_contract_id?: string
          id?: string
          iso_partner_id?: string
          notes?: string | null
          payment_date?: string | null
          payment_method?: string | null
          payment_status?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "iso_commissions_funded_contract_id_fkey"
            columns: ["funded_contract_id"]
            isOneToOne: false
            referencedRelation: "funded_contracts"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "iso_commissions_funded_contract_id_fkey"
            columns: ["funded_contract_id"]
            isOneToOne: false
            referencedRelation: "funding_records"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "iso_commissions_iso_partner_id_fkey"
            columns: ["iso_partner_id"]
            isOneToOne: false
            referencedRelation: "iso_partner_applications"
            referencedColumns: ["id"]
          },
        ]
      }
      iso_partner_applications: {
        Row: {
          agreement_document: string | null
          approved: boolean | null
          approved_at: string | null
          approved_by: string | null
          commission_rate: number | null
          company_name: string
          created_at: string
          email: string
          full_name: string
          funding_type: string | null
          id: string
          iso_volume_history: string | null
          monthly_deals: string | null
          notes: string | null
          phone: string
          status: string
          updated_at: string
          user_id: string | null
        }
        Insert: {
          agreement_document?: string | null
          approved?: boolean | null
          approved_at?: string | null
          approved_by?: string | null
          commission_rate?: number | null
          company_name: string
          created_at?: string
          email: string
          full_name: string
          funding_type?: string | null
          id?: string
          iso_volume_history?: string | null
          monthly_deals?: string | null
          notes?: string | null
          phone: string
          status?: string
          updated_at?: string
          user_id?: string | null
        }
        Update: {
          agreement_document?: string | null
          approved?: boolean | null
          approved_at?: string | null
          approved_by?: string | null
          commission_rate?: number | null
          company_name?: string
          created_at?: string
          email?: string
          full_name?: string
          funding_type?: string | null
          id?: string
          iso_volume_history?: string | null
          monthly_deals?: string | null
          notes?: string | null
          phone?: string
          status?: string
          updated_at?: string
          user_id?: string | null
        }
        Relationships: []
      }
      iso_partners: {
        Row: {
          company_name: string | null
          contact_name: string | null
          created_at: string | null
          default_commission_rate: number | null
          email: string | null
          id: string
          phone: string | null
          referral_code: string | null
          status: string | null
          updated_at: string | null
          user_id: string | null
        }
        Insert: {
          company_name?: string | null
          contact_name?: string | null
          created_at?: string | null
          default_commission_rate?: number | null
          email?: string | null
          id?: string
          phone?: string | null
          referral_code?: string | null
          status?: string | null
          updated_at?: string | null
          user_id?: string | null
        }
        Update: {
          company_name?: string | null
          contact_name?: string | null
          created_at?: string | null
          default_commission_rate?: number | null
          email?: string | null
          id?: string
          phone?: string | null
          referral_code?: string | null
          status?: string | null
          updated_at?: string | null
          user_id?: string | null
        }
        Relationships: []
      }
      iso_statistics: {
        Row: {
          approval_rate: number | null
          avg_commission: number | null
          deals_funded: number
          deals_submitted: number
          id: string
          iso_id: string
          last_updated: string
        }
        Insert: {
          approval_rate?: number | null
          avg_commission?: number | null
          deals_funded?: number
          deals_submitted?: number
          id?: string
          iso_id: string
          last_updated?: string
        }
        Update: {
          approval_rate?: number | null
          avg_commission?: number | null
          deals_funded?: number
          deals_submitted?: number
          id?: string
          iso_id?: string
          last_updated?: string
        }
        Relationships: []
      }
      iso_training_completions: {
        Row: {
          completed_at: string
          created_at: string
          id: string
          iso_id: string
          module_id: string
          score: number | null
        }
        Insert: {
          completed_at?: string
          created_at?: string
          id?: string
          iso_id: string
          module_id: string
          score?: number | null
        }
        Update: {
          completed_at?: string
          created_at?: string
          id?: string
          iso_id?: string
          module_id?: string
          score?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "iso_training_completions_module_id_fkey"
            columns: ["module_id"]
            isOneToOne: false
            referencedRelation: "iso_training_modules"
            referencedColumns: ["id"]
          },
        ]
      }
      iso_training_modules: {
        Row: {
          content_md: string
          created_at: string
          description: string | null
          id: string
          is_required: boolean
          order_index: number
          slug: string
          title: string
          updated_at: string
        }
        Insert: {
          content_md: string
          created_at?: string
          description?: string | null
          id?: string
          is_required?: boolean
          order_index?: number
          slug: string
          title: string
          updated_at?: string
        }
        Update: {
          content_md?: string
          created_at?: string
          description?: string | null
          id?: string
          is_required?: boolean
          order_index?: number
          slug?: string
          title?: string
          updated_at?: string
        }
        Relationships: []
      }
      kyc_results: {
        Row: {
          created_at: string
          id: string
          merchant_id: string
          provider: string
          raw_json: Json | null
          result: string
          risk_band: string | null
          score: number | null
        }
        Insert: {
          created_at?: string
          id?: string
          merchant_id: string
          provider: string
          raw_json?: Json | null
          result: string
          risk_band?: string | null
          score?: number | null
        }
        Update: {
          created_at?: string
          id?: string
          merchant_id?: string
          provider?: string
          raw_json?: Json | null
          result?: string
          risk_band?: string | null
          score?: number | null
        }
        Relationships: []
      }
      lead_assignments: {
        Row: {
          assigned_at: string | null
          assigned_worker_id: string | null
          created_at: string | null
          id: string
          last_contact_at: string | null
          lead_business_name: string | null
          lead_email: string | null
          lead_name: string
          lead_phone: string | null
          lead_score: number | null
          lead_source: string | null
          lead_status: string | null
          metadata: Json | null
          next_follow_up_date: string | null
          notes: string | null
          updated_at: string | null
        }
        Insert: {
          assigned_at?: string | null
          assigned_worker_id?: string | null
          created_at?: string | null
          id?: string
          last_contact_at?: string | null
          lead_business_name?: string | null
          lead_email?: string | null
          lead_name: string
          lead_phone?: string | null
          lead_score?: number | null
          lead_source?: string | null
          lead_status?: string | null
          metadata?: Json | null
          next_follow_up_date?: string | null
          notes?: string | null
          updated_at?: string | null
        }
        Update: {
          assigned_at?: string | null
          assigned_worker_id?: string | null
          created_at?: string | null
          id?: string
          last_contact_at?: string | null
          lead_business_name?: string | null
          lead_email?: string | null
          lead_name?: string
          lead_phone?: string | null
          lead_score?: number | null
          lead_source?: string | null
          lead_status?: string | null
          metadata?: Json | null
          next_follow_up_date?: string | null
          notes?: string | null
          updated_at?: string | null
        }
        Relationships: []
      }
      lead_call_attempts: {
        Row: {
          agent_email: string
          agent_id: string
          created_at: string | null
          duration_seconds: number | null
          id: string
          lead_id: string
          notes: string | null
          outcome: string
        }
        Insert: {
          agent_email: string
          agent_id: string
          created_at?: string | null
          duration_seconds?: number | null
          id?: string
          lead_id: string
          notes?: string | null
          outcome: string
        }
        Update: {
          agent_email?: string
          agent_id?: string
          created_at?: string | null
          duration_seconds?: number | null
          id?: string
          lead_id?: string
          notes?: string | null
          outcome?: string
        }
        Relationships: [
          {
            foreignKeyName: "lead_call_attempts_lead_id_fkey"
            columns: ["lead_id"]
            isOneToOne: false
            referencedRelation: "leads"
            referencedColumns: ["id"]
          },
        ]
      }
      lead_call_logs: {
        Row: {
          created_at: string | null
          duration_seconds: number | null
          id: string
          lead_id: string | null
          notes: string | null
          outcome: string | null
          worker_id: string | null
        }
        Insert: {
          created_at?: string | null
          duration_seconds?: number | null
          id?: string
          lead_id?: string | null
          notes?: string | null
          outcome?: string | null
          worker_id?: string | null
        }
        Update: {
          created_at?: string | null
          duration_seconds?: number | null
          id?: string
          lead_id?: string | null
          notes?: string | null
          outcome?: string | null
          worker_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "lead_call_logs_lead_id_fkey"
            columns: ["lead_id"]
            isOneToOne: false
            referencedRelation: "leads"
            referencedColumns: ["id"]
          },
        ]
      }
      lead_conflict_requests: {
        Row: {
          created_at: string | null
          current_owner_id: string
          id: string
          lead_id: string
          requester_id: string
          resolution: Json | null
          status: string
          updated_at: string | null
        }
        Insert: {
          created_at?: string | null
          current_owner_id: string
          id?: string
          lead_id: string
          requester_id: string
          resolution?: Json | null
          status?: string
          updated_at?: string | null
        }
        Update: {
          created_at?: string | null
          current_owner_id?: string
          id?: string
          lead_id?: string
          requester_id?: string
          resolution?: Json | null
          status?: string
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "lead_conflict_requests_lead_id_fkey"
            columns: ["lead_id"]
            isOneToOne: false
            referencedRelation: "leads"
            referencedColumns: ["id"]
          },
        ]
      }
      lead_events: {
        Row: {
          created_at: string | null
          created_by: string | null
          event_type: string
          id: string
          lead_id: string
          metadata: Json | null
        }
        Insert: {
          created_at?: string | null
          created_by?: string | null
          event_type: string
          id?: string
          lead_id: string
          metadata?: Json | null
        }
        Update: {
          created_at?: string | null
          created_by?: string | null
          event_type?: string
          id?: string
          lead_id?: string
          metadata?: Json | null
        }
        Relationships: [
          {
            foreignKeyName: "lead_events_lead_id_fkey"
            columns: ["lead_id"]
            isOneToOne: false
            referencedRelation: "leads"
            referencedColumns: ["id"]
          },
        ]
      }
      lead_files: {
        Row: {
          file_name: string
          file_path: string
          file_size: number | null
          file_type: string
          id: string
          is_ai_generated: boolean | null
          lead_id: string
          notes: string | null
          uploaded_at: string | null
          uploaded_by: string | null
        }
        Insert: {
          file_name: string
          file_path: string
          file_size?: number | null
          file_type: string
          id?: string
          is_ai_generated?: boolean | null
          lead_id: string
          notes?: string | null
          uploaded_at?: string | null
          uploaded_by?: string | null
        }
        Update: {
          file_name?: string
          file_path?: string
          file_size?: number | null
          file_type?: string
          id?: string
          is_ai_generated?: boolean | null
          lead_id?: string
          notes?: string | null
          uploaded_at?: string | null
          uploaded_by?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "lead_files_lead_id_fkey"
            columns: ["lead_id"]
            isOneToOne: false
            referencedRelation: "leads"
            referencedColumns: ["id"]
          },
        ]
      }
      lead_import_batches: {
        Row: {
          completed_at: string | null
          created_at: string | null
          error_count: number | null
          error_log: Json | null
          file_name: string
          file_path: string
          id: string
          imported_rows: number | null
          source_id: string | null
          status: string
          total_rows: number | null
          uploaded_by: string
        }
        Insert: {
          completed_at?: string | null
          created_at?: string | null
          error_count?: number | null
          error_log?: Json | null
          file_name: string
          file_path: string
          id?: string
          imported_rows?: number | null
          source_id?: string | null
          status?: string
          total_rows?: number | null
          uploaded_by: string
        }
        Update: {
          completed_at?: string | null
          created_at?: string | null
          error_count?: number | null
          error_log?: Json | null
          file_name?: string
          file_path?: string
          id?: string
          imported_rows?: number | null
          source_id?: string | null
          status?: string
          total_rows?: number | null
          uploaded_by?: string
        }
        Relationships: [
          {
            foreignKeyName: "lead_import_batches_source_id_fkey"
            columns: ["source_id"]
            isOneToOne: false
            referencedRelation: "lead_sources"
            referencedColumns: ["id"]
          },
        ]
      }
      lead_import_errors: {
        Row: {
          created_at: string | null
          error_message: string | null
          id: string
          lead_list_id: string | null
          raw_row: Json | null
          row_index: number
        }
        Insert: {
          created_at?: string | null
          error_message?: string | null
          id?: string
          lead_list_id?: string | null
          raw_row?: Json | null
          row_index: number
        }
        Update: {
          created_at?: string | null
          error_message?: string | null
          id?: string
          lead_list_id?: string | null
          raw_row?: Json | null
          row_index?: number
        }
        Relationships: [
          {
            foreignKeyName: "lead_import_errors_lead_list_id_fkey"
            columns: ["lead_list_id"]
            isOneToOne: false
            referencedRelation: "lead_lists"
            referencedColumns: ["id"]
          },
        ]
      }
      lead_list_members: {
        Row: {
          created_at: string
          id: string
          lead_id: string
          lead_list_id: string
          position: number | null
          status_in_list: string | null
        }
        Insert: {
          created_at?: string
          id?: string
          lead_id: string
          lead_list_id: string
          position?: number | null
          status_in_list?: string | null
        }
        Update: {
          created_at?: string
          id?: string
          lead_id?: string
          lead_list_id?: string
          position?: number | null
          status_in_list?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "lead_list_members_lead_id_fkey"
            columns: ["lead_id"]
            isOneToOne: false
            referencedRelation: "leads"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "lead_list_members_lead_list_id_fkey"
            columns: ["lead_list_id"]
            isOneToOne: false
            referencedRelation: "lead_lists"
            referencedColumns: ["id"]
          },
        ]
      }
      lead_lists: {
        Row: {
          created_at: string | null
          created_by: string | null
          dialer_count: number | null
          email_count: number | null
          error_message: string | null
          field_coverage: number | null
          file_path: string
          header_confidence: number | null
          header_mapping: Json | null
          id: string
          import_quality_score: number | null
          name: string
          processed_rows: number | null
          processing_summary: Json | null
          raw_headers: Json | null
          rejected_count: number | null
          research_count: number | null
          source: string | null
          source_type: string | null
          status: string
          total_rows: number | null
        }
        Insert: {
          created_at?: string | null
          created_by?: string | null
          dialer_count?: number | null
          email_count?: number | null
          error_message?: string | null
          field_coverage?: number | null
          file_path: string
          header_confidence?: number | null
          header_mapping?: Json | null
          id?: string
          import_quality_score?: number | null
          name: string
          processed_rows?: number | null
          processing_summary?: Json | null
          raw_headers?: Json | null
          rejected_count?: number | null
          research_count?: number | null
          source?: string | null
          source_type?: string | null
          status?: string
          total_rows?: number | null
        }
        Update: {
          created_at?: string | null
          created_by?: string | null
          dialer_count?: number | null
          email_count?: number | null
          error_message?: string | null
          field_coverage?: number | null
          file_path?: string
          header_confidence?: number | null
          header_mapping?: Json | null
          id?: string
          import_quality_score?: number | null
          name?: string
          processed_rows?: number | null
          processing_summary?: Json | null
          raw_headers?: Json | null
          rejected_count?: number | null
          research_count?: number | null
          source?: string | null
          source_type?: string | null
          status?: string
          total_rows?: number | null
        }
        Relationships: []
      }
      lead_lock_requests: {
        Row: {
          created_at: string | null
          from_agent_email: string
          from_agent_id: string
          id: string
          lead_id: string
          message: string | null
          request_type: string
          resolved_at: string | null
          status: string
          to_agent_email: string
          to_agent_id: string
        }
        Insert: {
          created_at?: string | null
          from_agent_email: string
          from_agent_id: string
          id?: string
          lead_id: string
          message?: string | null
          request_type: string
          resolved_at?: string | null
          status?: string
          to_agent_email: string
          to_agent_id: string
        }
        Update: {
          created_at?: string | null
          from_agent_email?: string
          from_agent_id?: string
          id?: string
          lead_id?: string
          message?: string | null
          request_type?: string
          resolved_at?: string | null
          status?: string
          to_agent_email?: string
          to_agent_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "lead_lock_requests_lead_id_fkey"
            columns: ["lead_id"]
            isOneToOne: false
            referencedRelation: "leads"
            referencedColumns: ["id"]
          },
        ]
      }
      lead_locks: {
        Row: {
          co_agent_email: string | null
          co_agent_id: string | null
          created_at: string | null
          id: string
          lead_id: string
          lock_expires_at: string
          lock_status: string
          primary_agent_email: string
          primary_agent_id: string
          updated_at: string | null
        }
        Insert: {
          co_agent_email?: string | null
          co_agent_id?: string | null
          created_at?: string | null
          id?: string
          lead_id: string
          lock_expires_at: string
          lock_status?: string
          primary_agent_email: string
          primary_agent_id: string
          updated_at?: string | null
        }
        Update: {
          co_agent_email?: string | null
          co_agent_id?: string | null
          created_at?: string | null
          id?: string
          lead_id?: string
          lock_expires_at?: string
          lock_status?: string
          primary_agent_email?: string
          primary_agent_id?: string
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "lead_locks_lead_id_fkey"
            columns: ["lead_id"]
            isOneToOne: false
            referencedRelation: "leads"
            referencedColumns: ["id"]
          },
        ]
      }
      lead_notes: {
        Row: {
          author_id: string | null
          created_at: string | null
          id: string
          lead_id: string
          note: string
          note_type: string | null
        }
        Insert: {
          author_id?: string | null
          created_at?: string | null
          id?: string
          lead_id: string
          note: string
          note_type?: string | null
        }
        Update: {
          author_id?: string | null
          created_at?: string | null
          id?: string
          lead_id?: string
          note?: string
          note_type?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "lead_notes_lead_id_fkey"
            columns: ["lead_id"]
            isOneToOne: false
            referencedRelation: "leads"
            referencedColumns: ["id"]
          },
        ]
      }
      lead_ownership_requests: {
        Row: {
          created_at: string | null
          from_worker_id: string
          id: string
          lead_id: string
          message: string | null
          request_type: string
          resolved_at: string | null
          status: string | null
          to_worker_id: string
        }
        Insert: {
          created_at?: string | null
          from_worker_id: string
          id?: string
          lead_id: string
          message?: string | null
          request_type: string
          resolved_at?: string | null
          status?: string | null
          to_worker_id: string
        }
        Update: {
          created_at?: string | null
          from_worker_id?: string
          id?: string
          lead_id?: string
          message?: string | null
          request_type?: string
          resolved_at?: string | null
          status?: string | null
          to_worker_id?: string
        }
        Relationships: []
      }
      lead_ownerships: {
        Row: {
          created_at: string
          id: string
          is_active: boolean
          lead_id: string
          lock_expires_at: string
          lock_reason: string
          lock_start_at: string
          primary_owner_email: string
          primary_owner_id: string
          secondary_owner_email: string | null
          secondary_owner_id: string | null
          share_primary: number
          share_secondary: number
          updated_at: string
        }
        Insert: {
          created_at?: string
          id?: string
          is_active?: boolean
          lead_id: string
          lock_expires_at: string
          lock_reason: string
          lock_start_at?: string
          primary_owner_email: string
          primary_owner_id: string
          secondary_owner_email?: string | null
          secondary_owner_id?: string | null
          share_primary?: number
          share_secondary?: number
          updated_at?: string
        }
        Update: {
          created_at?: string
          id?: string
          is_active?: boolean
          lead_id?: string
          lock_expires_at?: string
          lock_reason?: string
          lock_start_at?: string
          primary_owner_email?: string
          primary_owner_id?: string
          secondary_owner_email?: string | null
          secondary_owner_id?: string | null
          share_primary?: number
          share_secondary?: number
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "lead_ownerships_lead_id_fkey"
            columns: ["lead_id"]
            isOneToOne: false
            referencedRelation: "leads"
            referencedColumns: ["id"]
          },
        ]
      }
      lead_release_requests: {
        Row: {
          created_at: string
          from_worker_email: string
          from_worker_id: string
          id: string
          lead_id: string
          resolution_notes: string | null
          resolved_at: string | null
          resolved_by: string | null
          resolved_by_email: string | null
          status: string
          to_worker_email: string
          to_worker_id: string
        }
        Insert: {
          created_at?: string
          from_worker_email: string
          from_worker_id: string
          id?: string
          lead_id: string
          resolution_notes?: string | null
          resolved_at?: string | null
          resolved_by?: string | null
          resolved_by_email?: string | null
          status?: string
          to_worker_email: string
          to_worker_id: string
        }
        Update: {
          created_at?: string
          from_worker_email?: string
          from_worker_id?: string
          id?: string
          lead_id?: string
          resolution_notes?: string | null
          resolved_at?: string | null
          resolved_by?: string | null
          resolved_by_email?: string | null
          status?: string
          to_worker_email?: string
          to_worker_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "lead_release_requests_lead_id_fkey"
            columns: ["lead_id"]
            isOneToOne: false
            referencedRelation: "leads"
            referencedColumns: ["id"]
          },
        ]
      }
      lead_research_logs: {
        Row: {
          action: string
          created_at: string | null
          details: Json | null
          id: string
          lead_id: string
          worker_id: string
        }
        Insert: {
          action: string
          created_at?: string | null
          details?: Json | null
          id?: string
          lead_id: string
          worker_id: string
        }
        Update: {
          action?: string
          created_at?: string | null
          details?: Json | null
          id?: string
          lead_id?: string
          worker_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "lead_research_logs_lead_id_fkey"
            columns: ["lead_id"]
            isOneToOne: false
            referencedRelation: "leads"
            referencedColumns: ["id"]
          },
        ]
      }
      lead_scoring_rules: {
        Row: {
          created_at: string
          field_name: string
          id: string
          is_active: boolean
          operator: string
          priority: number
          rule_name: string
          score_adjustment: number
          threshold_value: Json
          updated_at: string
        }
        Insert: {
          created_at?: string
          field_name: string
          id?: string
          is_active?: boolean
          operator: string
          priority?: number
          rule_name: string
          score_adjustment: number
          threshold_value: Json
          updated_at?: string
        }
        Update: {
          created_at?: string
          field_name?: string
          id?: string
          is_active?: boolean
          operator?: string
          priority?: number
          rule_name?: string
          score_adjustment?: number
          threshold_value?: Json
          updated_at?: string
        }
        Relationships: []
      }
      lead_share_requests: {
        Row: {
          created_at: string | null
          from_worker_id: string
          id: string
          lead_id: string
          message: string | null
          responded_at: string | null
          status: string
          to_worker_id: string
          type: string
        }
        Insert: {
          created_at?: string | null
          from_worker_id: string
          id?: string
          lead_id: string
          message?: string | null
          responded_at?: string | null
          status?: string
          to_worker_id: string
          type: string
        }
        Update: {
          created_at?: string | null
          from_worker_id?: string
          id?: string
          lead_id?: string
          message?: string | null
          responded_at?: string | null
          status?: string
          to_worker_id?: string
          type?: string
        }
        Relationships: [
          {
            foreignKeyName: "lead_share_requests_lead_id_fkey"
            columns: ["lead_id"]
            isOneToOne: false
            referencedRelation: "leads"
            referencedColumns: ["id"]
          },
        ]
      }
      lead_sources: {
        Row: {
          campaign: string | null
          channel: string
          created_at: string | null
          id: string
          meta: Json | null
          name: string
        }
        Insert: {
          campaign?: string | null
          channel: string
          created_at?: string | null
          id?: string
          meta?: Json | null
          name: string
        }
        Update: {
          campaign?: string | null
          channel?: string
          created_at?: string | null
          id?: string
          meta?: Json | null
          name?: string
        }
        Relationships: []
      }
      lead_strategy_files: {
        Row: {
          created_at: string | null
          description: string | null
          file_name: string
          file_type: string | null
          file_url: string
          id: string
          lead_id: string
          uploaded_by: string | null
        }
        Insert: {
          created_at?: string | null
          description?: string | null
          file_name: string
          file_type?: string | null
          file_url: string
          id?: string
          lead_id: string
          uploaded_by?: string | null
        }
        Update: {
          created_at?: string | null
          description?: string | null
          file_name?: string
          file_type?: string | null
          file_url?: string
          id?: string
          lead_id?: string
          uploaded_by?: string | null
        }
        Relationships: []
      }
      lead_tasks: {
        Row: {
          completed_at: string | null
          created_at: string | null
          due_at: string | null
          id: string
          lead_id: string | null
          notes: string | null
          status: string
          task_type: string
          worker_id: string | null
        }
        Insert: {
          completed_at?: string | null
          created_at?: string | null
          due_at?: string | null
          id?: string
          lead_id?: string | null
          notes?: string | null
          status?: string
          task_type: string
          worker_id?: string | null
        }
        Update: {
          completed_at?: string | null
          created_at?: string | null
          due_at?: string | null
          id?: string
          lead_id?: string | null
          notes?: string | null
          status?: string
          task_type?: string
          worker_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "lead_tasks_lead_id_fkey"
            columns: ["lead_id"]
            isOneToOne: false
            referencedRelation: "leads"
            referencedColumns: ["id"]
          },
        ]
      }
      leads: {
        Row: {
          ad_group: string | null
          address: string | null
          ai_last_evaluated_at: string | null
          ai_notes: Json | null
          ai_priority: string | null
          ai_recommended_path: string | null
          ai_risk_flags: Json | null
          ai_score: number | null
          app_sent_at: string | null
          application_status: string | null
          application_url: string | null
          assigned_to: string | null
          assigned_worker_id: string | null
          attempt_count: number | null
          attempt_history: Json | null
          bucket: string | null
          business_age_years: number | null
          business_name: string | null
          business_start_date: string | null
          business_type: string | null
          call_attempts: number
          campaign: string | null
          city: string | null
          created_at: string | null
          creative_id: string | null
          credit_fix_status: string | null
          credit_fix_worker_id: string | null
          credit_indicators: Json | null
          credit_risk: string | null
          current_owner_email: string | null
          current_owner_id: string | null
          defaults_flag: boolean | null
          dial_attempts: number | null
          dialer_status: string
          domain_age_years: number | null
          eco_mode: boolean | null
          ein: string | null
          email: string | null
          email_attempts: number | null
          email_invalid: boolean | null
          email_status: string | null
          email_template_used: string | null
          email_valid: boolean | null
          enriched_address: string | null
          enriched_business_age_years: number | null
          enriched_business_name: string | null
          enriched_city: string | null
          enriched_email: string | null
          enriched_industry: string | null
          enriched_name: string | null
          enriched_online_presence_score: number | null
          enriched_phone: string | null
          enriched_revenue_estimate: number | null
          enriched_state: string | null
          enriched_zip: string | null
          enrichment_completed: boolean | null
          enrichment_date: string | null
          est_credit_score: number | null
          estimated_employees: number | null
          estimated_monthly_revenue: number | null
          estimated_revenue: number | null
          file_age_code: string | null
          first_name: string | null
          follow_up_at: string | null
          full_name: string | null
          funded_at: string | null
          funding_recommendation: string | null
          funding_score: number | null
          google_rating: number | null
          has_social_media: boolean | null
          id: string
          identity_theft_risk: string | null
          import_bucket: string | null
          import_confidence_score: number | null
          industry_risk: string | null
          interested_at: string | null
          last_application_sent_at: string | null
          last_attempt_at: string | null
          last_call_at: string | null
          last_call_outcome: string | null
          last_called_at: string | null
          last_called_by: string | null
          last_dial_disposition: string | null
          last_email_event: string | null
          last_emailed_at: string | null
          last_name: string | null
          lead_list_id: string | null
          lead_type: string | null
          linkedin_url: string | null
          list_id: string | null
          lock_expires_at: string | null
          lock_reason: string | null
          lock_started_at: string | null
          locked_by: string | null
          locked_by_email: string | null
          locked_by_worker_email: string | null
          locked_by_worker_id: string | null
          locked_until: string | null
          missing_email: boolean | null
          missing_phone: boolean | null
          mystic_tips: Json | null
          naics_code: string | null
          need_type: string | null
          new_phone: string | null
          next_attempt_at: string | null
          normalized_fields: Json | null
          notes: string | null
          ocm_county: string | null
          ocm_expiration_date: string | null
          ocm_intel: Json | null
          ocm_license_id: string | null
          ocm_license_type: string | null
          ocm_municipality: string | null
          ocm_status: string | null
          outcome: string | null
          owner_birth_date: string | null
          owner_first_name: string | null
          owner_id: string | null
          owner_last_name: string | null
          owner_name: string | null
          owner_worker_id: string | null
          phone: string | null
          phone_carrier: string | null
          phone_invalid: boolean | null
          phone_line_type: string | null
          phone_valid: boolean | null
          postal_code: string | null
          priority_score: number | null
          problem_flags: string[] | null
          raw_data: Json | null
          requested_amount: number | null
          research_assigned_to: string | null
          research_attempts: number | null
          research_completed_at: string | null
          research_last_action_at: string | null
          research_last_run_at: string | null
          research_notes: string | null
          research_owner_id: string | null
          research_started_at: string | null
          research_status: string | null
          route: string | null
          secondary_worker_id: string | null
          sic_code: string | null
          source: string | null
          source_file_name: string | null
          source_folder_name: string | null
          source_id: string | null
          source_list_name: string | null
          source_platform_label: string | null
          ssn_masked: string | null
          state: string | null
          status: string
          updated_at: string | null
          website: string | null
          wolf_folder_label: string | null
          zip: string | null
        }
        Insert: {
          ad_group?: string | null
          address?: string | null
          ai_last_evaluated_at?: string | null
          ai_notes?: Json | null
          ai_priority?: string | null
          ai_recommended_path?: string | null
          ai_risk_flags?: Json | null
          ai_score?: number | null
          app_sent_at?: string | null
          application_status?: string | null
          application_url?: string | null
          assigned_to?: string | null
          assigned_worker_id?: string | null
          attempt_count?: number | null
          attempt_history?: Json | null
          bucket?: string | null
          business_age_years?: number | null
          business_name?: string | null
          business_start_date?: string | null
          business_type?: string | null
          call_attempts?: number
          campaign?: string | null
          city?: string | null
          created_at?: string | null
          creative_id?: string | null
          credit_fix_status?: string | null
          credit_fix_worker_id?: string | null
          credit_indicators?: Json | null
          credit_risk?: string | null
          current_owner_email?: string | null
          current_owner_id?: string | null
          defaults_flag?: boolean | null
          dial_attempts?: number | null
          dialer_status?: string
          domain_age_years?: number | null
          eco_mode?: boolean | null
          ein?: string | null
          email?: string | null
          email_attempts?: number | null
          email_invalid?: boolean | null
          email_status?: string | null
          email_template_used?: string | null
          email_valid?: boolean | null
          enriched_address?: string | null
          enriched_business_age_years?: number | null
          enriched_business_name?: string | null
          enriched_city?: string | null
          enriched_email?: string | null
          enriched_industry?: string | null
          enriched_name?: string | null
          enriched_online_presence_score?: number | null
          enriched_phone?: string | null
          enriched_revenue_estimate?: number | null
          enriched_state?: string | null
          enriched_zip?: string | null
          enrichment_completed?: boolean | null
          enrichment_date?: string | null
          est_credit_score?: number | null
          estimated_employees?: number | null
          estimated_monthly_revenue?: number | null
          estimated_revenue?: number | null
          file_age_code?: string | null
          first_name?: string | null
          follow_up_at?: string | null
          full_name?: string | null
          funded_at?: string | null
          funding_recommendation?: string | null
          funding_score?: number | null
          google_rating?: number | null
          has_social_media?: boolean | null
          id?: string
          identity_theft_risk?: string | null
          import_bucket?: string | null
          import_confidence_score?: number | null
          industry_risk?: string | null
          interested_at?: string | null
          last_application_sent_at?: string | null
          last_attempt_at?: string | null
          last_call_at?: string | null
          last_call_outcome?: string | null
          last_called_at?: string | null
          last_called_by?: string | null
          last_dial_disposition?: string | null
          last_email_event?: string | null
          last_emailed_at?: string | null
          last_name?: string | null
          lead_list_id?: string | null
          lead_type?: string | null
          linkedin_url?: string | null
          list_id?: string | null
          lock_expires_at?: string | null
          lock_reason?: string | null
          lock_started_at?: string | null
          locked_by?: string | null
          locked_by_email?: string | null
          locked_by_worker_email?: string | null
          locked_by_worker_id?: string | null
          locked_until?: string | null
          missing_email?: boolean | null
          missing_phone?: boolean | null
          mystic_tips?: Json | null
          naics_code?: string | null
          need_type?: string | null
          new_phone?: string | null
          next_attempt_at?: string | null
          normalized_fields?: Json | null
          notes?: string | null
          ocm_county?: string | null
          ocm_expiration_date?: string | null
          ocm_intel?: Json | null
          ocm_license_id?: string | null
          ocm_license_type?: string | null
          ocm_municipality?: string | null
          ocm_status?: string | null
          outcome?: string | null
          owner_birth_date?: string | null
          owner_first_name?: string | null
          owner_id?: string | null
          owner_last_name?: string | null
          owner_name?: string | null
          owner_worker_id?: string | null
          phone?: string | null
          phone_carrier?: string | null
          phone_invalid?: boolean | null
          phone_line_type?: string | null
          phone_valid?: boolean | null
          postal_code?: string | null
          priority_score?: number | null
          problem_flags?: string[] | null
          raw_data?: Json | null
          requested_amount?: number | null
          research_assigned_to?: string | null
          research_attempts?: number | null
          research_completed_at?: string | null
          research_last_action_at?: string | null
          research_last_run_at?: string | null
          research_notes?: string | null
          research_owner_id?: string | null
          research_started_at?: string | null
          research_status?: string | null
          route?: string | null
          secondary_worker_id?: string | null
          sic_code?: string | null
          source?: string | null
          source_file_name?: string | null
          source_folder_name?: string | null
          source_id?: string | null
          source_list_name?: string | null
          source_platform_label?: string | null
          ssn_masked?: string | null
          state?: string | null
          status?: string
          updated_at?: string | null
          website?: string | null
          wolf_folder_label?: string | null
          zip?: string | null
        }
        Update: {
          ad_group?: string | null
          address?: string | null
          ai_last_evaluated_at?: string | null
          ai_notes?: Json | null
          ai_priority?: string | null
          ai_recommended_path?: string | null
          ai_risk_flags?: Json | null
          ai_score?: number | null
          app_sent_at?: string | null
          application_status?: string | null
          application_url?: string | null
          assigned_to?: string | null
          assigned_worker_id?: string | null
          attempt_count?: number | null
          attempt_history?: Json | null
          bucket?: string | null
          business_age_years?: number | null
          business_name?: string | null
          business_start_date?: string | null
          business_type?: string | null
          call_attempts?: number
          campaign?: string | null
          city?: string | null
          created_at?: string | null
          creative_id?: string | null
          credit_fix_status?: string | null
          credit_fix_worker_id?: string | null
          credit_indicators?: Json | null
          credit_risk?: string | null
          current_owner_email?: string | null
          current_owner_id?: string | null
          defaults_flag?: boolean | null
          dial_attempts?: number | null
          dialer_status?: string
          domain_age_years?: number | null
          eco_mode?: boolean | null
          ein?: string | null
          email?: string | null
          email_attempts?: number | null
          email_invalid?: boolean | null
          email_status?: string | null
          email_template_used?: string | null
          email_valid?: boolean | null
          enriched_address?: string | null
          enriched_business_age_years?: number | null
          enriched_business_name?: string | null
          enriched_city?: string | null
          enriched_email?: string | null
          enriched_industry?: string | null
          enriched_name?: string | null
          enriched_online_presence_score?: number | null
          enriched_phone?: string | null
          enriched_revenue_estimate?: number | null
          enriched_state?: string | null
          enriched_zip?: string | null
          enrichment_completed?: boolean | null
          enrichment_date?: string | null
          est_credit_score?: number | null
          estimated_employees?: number | null
          estimated_monthly_revenue?: number | null
          estimated_revenue?: number | null
          file_age_code?: string | null
          first_name?: string | null
          follow_up_at?: string | null
          full_name?: string | null
          funded_at?: string | null
          funding_recommendation?: string | null
          funding_score?: number | null
          google_rating?: number | null
          has_social_media?: boolean | null
          id?: string
          identity_theft_risk?: string | null
          import_bucket?: string | null
          import_confidence_score?: number | null
          industry_risk?: string | null
          interested_at?: string | null
          last_application_sent_at?: string | null
          last_attempt_at?: string | null
          last_call_at?: string | null
          last_call_outcome?: string | null
          last_called_at?: string | null
          last_called_by?: string | null
          last_dial_disposition?: string | null
          last_email_event?: string | null
          last_emailed_at?: string | null
          last_name?: string | null
          lead_list_id?: string | null
          lead_type?: string | null
          linkedin_url?: string | null
          list_id?: string | null
          lock_expires_at?: string | null
          lock_reason?: string | null
          lock_started_at?: string | null
          locked_by?: string | null
          locked_by_email?: string | null
          locked_by_worker_email?: string | null
          locked_by_worker_id?: string | null
          locked_until?: string | null
          missing_email?: boolean | null
          missing_phone?: boolean | null
          mystic_tips?: Json | null
          naics_code?: string | null
          need_type?: string | null
          new_phone?: string | null
          next_attempt_at?: string | null
          normalized_fields?: Json | null
          notes?: string | null
          ocm_county?: string | null
          ocm_expiration_date?: string | null
          ocm_intel?: Json | null
          ocm_license_id?: string | null
          ocm_license_type?: string | null
          ocm_municipality?: string | null
          ocm_status?: string | null
          outcome?: string | null
          owner_birth_date?: string | null
          owner_first_name?: string | null
          owner_id?: string | null
          owner_last_name?: string | null
          owner_name?: string | null
          owner_worker_id?: string | null
          phone?: string | null
          phone_carrier?: string | null
          phone_invalid?: boolean | null
          phone_line_type?: string | null
          phone_valid?: boolean | null
          postal_code?: string | null
          priority_score?: number | null
          problem_flags?: string[] | null
          raw_data?: Json | null
          requested_amount?: number | null
          research_assigned_to?: string | null
          research_attempts?: number | null
          research_completed_at?: string | null
          research_last_action_at?: string | null
          research_last_run_at?: string | null
          research_notes?: string | null
          research_owner_id?: string | null
          research_started_at?: string | null
          research_status?: string | null
          route?: string | null
          secondary_worker_id?: string | null
          sic_code?: string | null
          source?: string | null
          source_file_name?: string | null
          source_folder_name?: string | null
          source_id?: string | null
          source_list_name?: string | null
          source_platform_label?: string | null
          ssn_masked?: string | null
          state?: string | null
          status?: string
          updated_at?: string | null
          website?: string | null
          wolf_folder_label?: string | null
          zip?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "leads_lead_list_id_fkey"
            columns: ["lead_list_id"]
            isOneToOne: false
            referencedRelation: "lead_lists"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "leads_source_id_fkey"
            columns: ["source_id"]
            isOneToOne: false
            referencedRelation: "lead_sources"
            referencedColumns: ["id"]
          },
        ]
      }
      legal_cases: {
        Row: {
          assigned_at: string | null
          assigned_to: string | null
          case_type: string
          created_at: string
          deal_id: string | null
          description: string | null
          id: string
          merchant_id: string | null
          metadata: Json
          priority: string
          status: string
          super_owner_id: string | null
          tenant_id: string | null
          title: string
          updated_at: string
        }
        Insert: {
          assigned_at?: string | null
          assigned_to?: string | null
          case_type: string
          created_at?: string
          deal_id?: string | null
          description?: string | null
          id?: string
          merchant_id?: string | null
          metadata?: Json
          priority?: string
          status?: string
          super_owner_id?: string | null
          tenant_id?: string | null
          title: string
          updated_at?: string
        }
        Update: {
          assigned_at?: string | null
          assigned_to?: string | null
          case_type?: string
          created_at?: string
          deal_id?: string | null
          description?: string | null
          id?: string
          merchant_id?: string | null
          metadata?: Json
          priority?: string
          status?: string
          super_owner_id?: string | null
          tenant_id?: string | null
          title?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "legal_cases_deal_id_fkey"
            columns: ["deal_id"]
            isOneToOne: false
            referencedRelation: "deals"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "legal_cases_merchant_id_fkey"
            columns: ["merchant_id"]
            isOneToOne: false
            referencedRelation: "merchants"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "legal_cases_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "wf_tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      legal_client_applications: {
        Row: {
          address: string | null
          assigned_to: string | null
          case_description: string | null
          case_type: string
          city: string | null
          created_at: string | null
          email: string
          full_name: string
          has_police_report: boolean | null
          id: string
          incident_date: string | null
          notes: string | null
          origin_source: string | null
          phone: string | null
          police_report_number: string | null
          referral_code: string | null
          reviewed_at: string | null
          reviewed_by: string | null
          state: string | null
          status: string | null
          supporting_documents: string[] | null
          tenant_id: string | null
          updated_at: string | null
          user_id: string | null
          zip: string | null
        }
        Insert: {
          address?: string | null
          assigned_to?: string | null
          case_description?: string | null
          case_type: string
          city?: string | null
          created_at?: string | null
          email: string
          full_name: string
          has_police_report?: boolean | null
          id?: string
          incident_date?: string | null
          notes?: string | null
          origin_source?: string | null
          phone?: string | null
          police_report_number?: string | null
          referral_code?: string | null
          reviewed_at?: string | null
          reviewed_by?: string | null
          state?: string | null
          status?: string | null
          supporting_documents?: string[] | null
          tenant_id?: string | null
          updated_at?: string | null
          user_id?: string | null
          zip?: string | null
        }
        Update: {
          address?: string | null
          assigned_to?: string | null
          case_description?: string | null
          case_type?: string
          city?: string | null
          created_at?: string | null
          email?: string
          full_name?: string
          has_police_report?: boolean | null
          id?: string
          incident_date?: string | null
          notes?: string | null
          origin_source?: string | null
          phone?: string | null
          police_report_number?: string | null
          referral_code?: string | null
          reviewed_at?: string | null
          reviewed_by?: string | null
          state?: string | null
          status?: string | null
          supporting_documents?: string[] | null
          tenant_id?: string | null
          updated_at?: string | null
          user_id?: string | null
          zip?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "legal_client_applications_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "wf_tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      legal_risk_feedback: {
        Row: {
          application_id: string
          application_type: string
          created_at: string | null
          created_by: string
          finding_id: string
          finding_type: string
          id: string
          is_relevant: boolean
          notes: string | null
        }
        Insert: {
          application_id: string
          application_type: string
          created_at?: string | null
          created_by: string
          finding_id: string
          finding_type: string
          id?: string
          is_relevant: boolean
          notes?: string | null
        }
        Update: {
          application_id?: string
          application_type?: string
          created_at?: string | null
          created_by?: string
          finding_id?: string
          finding_type?: string
          id?: string
          is_relevant?: boolean
          notes?: string | null
        }
        Relationships: []
      }
      loan_applications: {
        Row: {
          business_address: string | null
          business_name: string
          business_revenue: string | null
          created_at: string
          credit_score: string | null
          email: string
          follow_up_date: string | null
          id: string
          last_scan_at: string | null
          loan_amount: string | null
          loan_type: string
          next_scan_at: string | null
          origin_source: string | null
          owner_name: string | null
          phone: string
          purpose_of_loan: string | null
          referral_code: string | null
          status: string
          tenant_id: string | null
          time_in_business: string | null
          updated_at: string
          user_id: string | null
        }
        Insert: {
          business_address?: string | null
          business_name: string
          business_revenue?: string | null
          created_at?: string
          credit_score?: string | null
          email: string
          follow_up_date?: string | null
          id?: string
          last_scan_at?: string | null
          loan_amount?: string | null
          loan_type: string
          next_scan_at?: string | null
          origin_source?: string | null
          owner_name?: string | null
          phone: string
          purpose_of_loan?: string | null
          referral_code?: string | null
          status?: string
          tenant_id?: string | null
          time_in_business?: string | null
          updated_at?: string
          user_id?: string | null
        }
        Update: {
          business_address?: string | null
          business_name?: string
          business_revenue?: string | null
          created_at?: string
          credit_score?: string | null
          email?: string
          follow_up_date?: string | null
          id?: string
          last_scan_at?: string | null
          loan_amount?: string | null
          loan_type?: string
          next_scan_at?: string | null
          origin_source?: string | null
          owner_name?: string | null
          phone?: string
          purpose_of_loan?: string | null
          referral_code?: string | null
          status?: string
          tenant_id?: string | null
          time_in_business?: string | null
          updated_at?: string
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "loan_applications_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "wf_tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      mca_products: {
        Row: {
          code: string
          created_at: string
          description: string | null
          id: string
          is_active: boolean
          name: string
          updated_at: string
        }
        Insert: {
          code: string
          created_at?: string
          description?: string | null
          id?: string
          is_active?: boolean
          name: string
          updated_at?: string
        }
        Update: {
          code?: string
          created_at?: string
          description?: string | null
          id?: string
          is_active?: boolean
          name?: string
          updated_at?: string
        }
        Relationships: []
      }
      merchants: {
        Row: {
          contact_email: string | null
          contact_name: string | null
          contact_phone: string | null
          created_at: string
          created_by: string
          dba_name: string | null
          ein: string | null
          id: string
          legal_name: string
          metadata: Json
          owner_user_id: string
          status: string
          super_owner_id: string | null
          tenant_id: string | null
          updated_at: string
        }
        Insert: {
          contact_email?: string | null
          contact_name?: string | null
          contact_phone?: string | null
          created_at?: string
          created_by: string
          dba_name?: string | null
          ein?: string | null
          id?: string
          legal_name: string
          metadata?: Json
          owner_user_id: string
          status?: string
          super_owner_id?: string | null
          tenant_id?: string | null
          updated_at?: string
        }
        Update: {
          contact_email?: string | null
          contact_name?: string | null
          contact_phone?: string | null
          created_at?: string
          created_by?: string
          dba_name?: string | null
          ein?: string | null
          id?: string
          legal_name?: string
          metadata?: Json
          owner_user_id?: string
          status?: string
          super_owner_id?: string | null
          tenant_id?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "merchants_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "wf_tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      message_templates: {
        Row: {
          ai_prompt_hint: string | null
          audience: string
          body: string
          channel: string
          created_at: string | null
          created_by: string | null
          id: string
          is_active: boolean | null
          is_default: boolean | null
          name: string
          product_line: Database["public"]["Enums"]["product_line"]
          role_scope: string
          subject: string | null
          updated_at: string | null
        }
        Insert: {
          ai_prompt_hint?: string | null
          audience: string
          body: string
          channel: string
          created_at?: string | null
          created_by?: string | null
          id?: string
          is_active?: boolean | null
          is_default?: boolean | null
          name: string
          product_line?: Database["public"]["Enums"]["product_line"]
          role_scope?: string
          subject?: string | null
          updated_at?: string | null
        }
        Update: {
          ai_prompt_hint?: string | null
          audience?: string
          body?: string
          channel?: string
          created_at?: string | null
          created_by?: string | null
          id?: string
          is_active?: boolean | null
          is_default?: boolean | null
          name?: string
          product_line?: Database["public"]["Enums"]["product_line"]
          role_scope?: string
          subject?: string | null
          updated_at?: string | null
        }
        Relationships: []
      }
      messages_sent: {
        Row: {
          body: string
          case_id: string | null
          channel: string
          client_id: string | null
          created_at: string | null
          delivered_at: string | null
          direction: string
          id: string
          lead_id: string | null
          meta: Json | null
          provider_message_id: string | null
          provider_meta: Json | null
          recipient: string
          replied_at: string | null
          reply_due_at: string | null
          sender: string | null
          sent_at: string | null
          sent_by_user_id: string | null
          status: string
          subject: string | null
          template_id: string | null
        }
        Insert: {
          body: string
          case_id?: string | null
          channel: string
          client_id?: string | null
          created_at?: string | null
          delivered_at?: string | null
          direction?: string
          id?: string
          lead_id?: string | null
          meta?: Json | null
          provider_message_id?: string | null
          provider_meta?: Json | null
          recipient: string
          replied_at?: string | null
          reply_due_at?: string | null
          sender?: string | null
          sent_at?: string | null
          sent_by_user_id?: string | null
          status?: string
          subject?: string | null
          template_id?: string | null
        }
        Update: {
          body?: string
          case_id?: string | null
          channel?: string
          client_id?: string | null
          created_at?: string | null
          delivered_at?: string | null
          direction?: string
          id?: string
          lead_id?: string | null
          meta?: Json | null
          provider_message_id?: string | null
          provider_meta?: Json | null
          recipient?: string
          replied_at?: string | null
          reply_due_at?: string | null
          sender?: string | null
          sent_at?: string | null
          sent_by_user_id?: string | null
          status?: string
          subject?: string | null
          template_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "messages_sent_case_id_fkey"
            columns: ["case_id"]
            isOneToOne: false
            referencedRelation: "underwriting_cases"
            referencedColumns: ["id"]
          },
        ]
      }
      outbound_emails: {
        Row: {
          approval_status: string | null
          approved_at: string | null
          approved_by: string | null
          body: string
          created_at: string | null
          draft_status: string | null
          id: string
          lead_id: string | null
          metadata: Json | null
          opened_at: string | null
          recipient_email: string
          replied_at: string | null
          sent_at: string | null
          subject: string
          worker_id: string
          worker_type: string | null
        }
        Insert: {
          approval_status?: string | null
          approved_at?: string | null
          approved_by?: string | null
          body: string
          created_at?: string | null
          draft_status?: string | null
          id?: string
          lead_id?: string | null
          metadata?: Json | null
          opened_at?: string | null
          recipient_email: string
          replied_at?: string | null
          sent_at?: string | null
          subject: string
          worker_id: string
          worker_type?: string | null
        }
        Update: {
          approval_status?: string | null
          approved_at?: string | null
          approved_by?: string | null
          body?: string
          created_at?: string | null
          draft_status?: string | null
          id?: string
          lead_id?: string | null
          metadata?: Json | null
          opened_at?: string | null
          recipient_email?: string
          replied_at?: string | null
          sent_at?: string | null
          subject?: string
          worker_id?: string
          worker_type?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "outbound_emails_lead_id_fkey"
            columns: ["lead_id"]
            isOneToOne: false
            referencedRelation: "lead_assignments"
            referencedColumns: ["id"]
          },
        ]
      }
      outreach_campaigns: {
        Row: {
          created_at: string
          created_by: string | null
          daily_send_cap: number
          id: string
          inbox_id: string | null
          lead_list_id: string | null
          name: string
          sender_identity: string
          sequence_id: string
          status: string
          timezone: string
          updated_at: string
          updated_by: string | null
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          daily_send_cap?: number
          id?: string
          inbox_id?: string | null
          lead_list_id?: string | null
          name: string
          sender_identity: string
          sequence_id: string
          status?: string
          timezone?: string
          updated_at?: string
          updated_by?: string | null
        }
        Update: {
          created_at?: string
          created_by?: string | null
          daily_send_cap?: number
          id?: string
          inbox_id?: string | null
          lead_list_id?: string | null
          name?: string
          sender_identity?: string
          sequence_id?: string
          status?: string
          timezone?: string
          updated_at?: string
          updated_by?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "outreach_campaigns_inbox_id_fkey"
            columns: ["inbox_id"]
            isOneToOne: false
            referencedRelation: "outreach_inboxes"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "outreach_campaigns_lead_list_id_fkey"
            columns: ["lead_list_id"]
            isOneToOne: false
            referencedRelation: "lead_lists"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "outreach_campaigns_sequence_id_fkey"
            columns: ["sequence_id"]
            isOneToOne: false
            referencedRelation: "outreach_sequences"
            referencedColumns: ["id"]
          },
        ]
      }
      outreach_enrollments: {
        Row: {
          id: string
          last_sent_at: string | null
          last_step_sent: number | null
          lead_id: string | null
          sequence_id: string | null
          started_at: string | null
          status: string | null
          worker_id: string | null
        }
        Insert: {
          id?: string
          last_sent_at?: string | null
          last_step_sent?: number | null
          lead_id?: string | null
          sequence_id?: string | null
          started_at?: string | null
          status?: string | null
          worker_id?: string | null
        }
        Update: {
          id?: string
          last_sent_at?: string | null
          last_step_sent?: number | null
          lead_id?: string | null
          sequence_id?: string | null
          started_at?: string | null
          status?: string | null
          worker_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "outreach_enrollments_lead_id_fkey"
            columns: ["lead_id"]
            isOneToOne: false
            referencedRelation: "leads"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "outreach_enrollments_sequence_id_fkey"
            columns: ["sequence_id"]
            isOneToOne: false
            referencedRelation: "outreach_sequences"
            referencedColumns: ["id"]
          },
        ]
      }
      outreach_events: {
        Row: {
          campaign_id: string | null
          created_at: string | null
          enrollment_id: string | null
          event_type: string | null
          id: string
          lead_id: string | null
          meta: Json | null
          metadata: Json | null
          sequence_step: number | null
          step_id: string | null
          worker_id: string | null
        }
        Insert: {
          campaign_id?: string | null
          created_at?: string | null
          enrollment_id?: string | null
          event_type?: string | null
          id?: string
          lead_id?: string | null
          meta?: Json | null
          metadata?: Json | null
          sequence_step?: number | null
          step_id?: string | null
          worker_id?: string | null
        }
        Update: {
          campaign_id?: string | null
          created_at?: string | null
          enrollment_id?: string | null
          event_type?: string | null
          id?: string
          lead_id?: string | null
          meta?: Json | null
          metadata?: Json | null
          sequence_step?: number | null
          step_id?: string | null
          worker_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "outreach_events_campaign_id_fkey"
            columns: ["campaign_id"]
            isOneToOne: false
            referencedRelation: "outreach_campaigns"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "outreach_events_enrollment_id_fkey"
            columns: ["enrollment_id"]
            isOneToOne: false
            referencedRelation: "outreach_enrollments"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "outreach_events_lead_id_fkey"
            columns: ["lead_id"]
            isOneToOne: false
            referencedRelation: "leads"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "outreach_events_step_id_fkey"
            columns: ["step_id"]
            isOneToOne: false
            referencedRelation: "outreach_steps"
            referencedColumns: ["id"]
          },
        ]
      }
      outreach_inboxes: {
        Row: {
          created_at: string
          created_by: string | null
          email_address: string
          id: string
          label: string
          provider: string
          status: string
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          email_address: string
          id?: string
          label: string
          provider: string
          status?: string
        }
        Update: {
          created_at?: string
          created_by?: string | null
          email_address?: string
          id?: string
          label?: string
          provider?: string
          status?: string
        }
        Relationships: []
      }
      outreach_sequences: {
        Row: {
          channel: string | null
          created_at: string | null
          created_by: string | null
          description: string | null
          id: string
          is_active: boolean | null
          name: string
          steps: Json
          updated_at: string
          updated_by: string | null
        }
        Insert: {
          channel?: string | null
          created_at?: string | null
          created_by?: string | null
          description?: string | null
          id?: string
          is_active?: boolean | null
          name: string
          steps?: Json
          updated_at?: string
          updated_by?: string | null
        }
        Update: {
          channel?: string | null
          created_at?: string | null
          created_by?: string | null
          description?: string | null
          id?: string
          is_active?: boolean | null
          name?: string
          steps?: Json
          updated_at?: string
          updated_by?: string | null
        }
        Relationships: []
      }
      outreach_steps: {
        Row: {
          channel: string
          created_at: string | null
          delay_hours: number
          eco_mode_only: boolean | null
          id: string
          sequence_id: string | null
          step_order: number
          template_name: string | null
          use_ai: boolean | null
        }
        Insert: {
          channel: string
          created_at?: string | null
          delay_hours: number
          eco_mode_only?: boolean | null
          id?: string
          sequence_id?: string | null
          step_order: number
          template_name?: string | null
          use_ai?: boolean | null
        }
        Update: {
          channel?: string
          created_at?: string | null
          delay_hours?: number
          eco_mode_only?: boolean | null
          id?: string
          sequence_id?: string | null
          step_order?: number
          template_name?: string | null
          use_ai?: boolean | null
        }
        Relationships: [
          {
            foreignKeyName: "outreach_steps_sequence_id_fkey"
            columns: ["sequence_id"]
            isOneToOne: false
            referencedRelation: "outreach_sequences"
            referencedColumns: ["id"]
          },
        ]
      }
      outreach_tasks: {
        Row: {
          assigned_to_user_id: string | null
          case_id: string | null
          completed_at: string | null
          created_at: string | null
          description: string | null
          due_at: string | null
          id: string
          intake_client_id: string | null
          lead_id: string | null
          message_id: string | null
          meta: Json | null
          priority: string | null
          status: string
          task_type: string
          tenant_id: string | null
          title: string
          updated_at: string | null
        }
        Insert: {
          assigned_to_user_id?: string | null
          case_id?: string | null
          completed_at?: string | null
          created_at?: string | null
          description?: string | null
          due_at?: string | null
          id?: string
          intake_client_id?: string | null
          lead_id?: string | null
          message_id?: string | null
          meta?: Json | null
          priority?: string | null
          status?: string
          task_type: string
          tenant_id?: string | null
          title: string
          updated_at?: string | null
        }
        Update: {
          assigned_to_user_id?: string | null
          case_id?: string | null
          completed_at?: string | null
          created_at?: string | null
          description?: string | null
          due_at?: string | null
          id?: string
          intake_client_id?: string | null
          lead_id?: string | null
          message_id?: string | null
          meta?: Json | null
          priority?: string | null
          status?: string
          task_type?: string
          tenant_id?: string | null
          title?: string
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "outreach_tasks_case_id_fkey"
            columns: ["case_id"]
            isOneToOne: false
            referencedRelation: "underwriting_cases"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "outreach_tasks_intake_client_id_fkey"
            columns: ["intake_client_id"]
            isOneToOne: false
            referencedRelation: "intake_clients"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "outreach_tasks_lead_id_fkey"
            columns: ["lead_id"]
            isOneToOne: false
            referencedRelation: "leads"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "outreach_tasks_message_id_fkey"
            columns: ["message_id"]
            isOneToOne: false
            referencedRelation: "messages_sent"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "outreach_tasks_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "wf_tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      partner_applications: {
        Row: {
          agreement_accepted: boolean | null
          agreement_document: string | null
          agreement_signed_at: string | null
          company_address: string | null
          company_email: string
          company_name: string
          company_phone: string | null
          created_at: string | null
          current_funders: string | null
          ein_number: string | null
          funding_types: string[] | null
          id: string
          monthly_volume: string | null
          notes: string | null
          origin_source: string | null
          owner_email: string
          owner_name: string
          owner_phone: string | null
          referral_code: string | null
          reviewed_at: string | null
          reviewed_by: string | null
          status: string | null
          team_size: string | null
          tenant_id: string | null
          updated_at: string | null
          user_id: string | null
          years_in_industry: string | null
        }
        Insert: {
          agreement_accepted?: boolean | null
          agreement_document?: string | null
          agreement_signed_at?: string | null
          company_address?: string | null
          company_email: string
          company_name: string
          company_phone?: string | null
          created_at?: string | null
          current_funders?: string | null
          ein_number?: string | null
          funding_types?: string[] | null
          id?: string
          monthly_volume?: string | null
          notes?: string | null
          origin_source?: string | null
          owner_email: string
          owner_name: string
          owner_phone?: string | null
          referral_code?: string | null
          reviewed_at?: string | null
          reviewed_by?: string | null
          status?: string | null
          team_size?: string | null
          tenant_id?: string | null
          updated_at?: string | null
          user_id?: string | null
          years_in_industry?: string | null
        }
        Update: {
          agreement_accepted?: boolean | null
          agreement_document?: string | null
          agreement_signed_at?: string | null
          company_address?: string | null
          company_email?: string
          company_name?: string
          company_phone?: string | null
          created_at?: string | null
          current_funders?: string | null
          ein_number?: string | null
          funding_types?: string[] | null
          id?: string
          monthly_volume?: string | null
          notes?: string | null
          origin_source?: string | null
          owner_email?: string
          owner_name?: string
          owner_phone?: string | null
          referral_code?: string | null
          reviewed_at?: string | null
          reviewed_by?: string | null
          status?: string | null
          team_size?: string | null
          tenant_id?: string | null
          updated_at?: string | null
          user_id?: string | null
          years_in_industry?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "partner_applications_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "wf_tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      partner_invite_codes: {
        Row: {
          code: string
          created_at: string | null
          created_by: string | null
          current_uses: number | null
          expires_at: string | null
          id: string
          is_active: boolean | null
          max_uses: number | null
          partner_id: string
        }
        Insert: {
          code: string
          created_at?: string | null
          created_by?: string | null
          current_uses?: number | null
          expires_at?: string | null
          id?: string
          is_active?: boolean | null
          max_uses?: number | null
          partner_id: string
        }
        Update: {
          code?: string
          created_at?: string | null
          created_by?: string | null
          current_uses?: number | null
          expires_at?: string | null
          id?: string
          is_active?: boolean | null
          max_uses?: number | null
          partner_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "partner_invite_codes_partner_id_fkey"
            columns: ["partner_id"]
            isOneToOne: false
            referencedRelation: "partner_applications"
            referencedColumns: ["id"]
          },
        ]
      }
      portal_profiles: {
        Row: {
          callcenter_team_id: string | null
          client_business_id: string | null
          created_at: string
          funder_id: string | null
          id: string
          iso_id: string | null
          primary_role: string
          settings: Json | null
          updated_at: string
          user_id: string
        }
        Insert: {
          callcenter_team_id?: string | null
          client_business_id?: string | null
          created_at?: string
          funder_id?: string | null
          id?: string
          iso_id?: string | null
          primary_role: string
          settings?: Json | null
          updated_at?: string
          user_id: string
        }
        Update: {
          callcenter_team_id?: string | null
          client_business_id?: string | null
          created_at?: string
          funder_id?: string | null
          id?: string
          iso_id?: string | null
          primary_role?: string
          settings?: Json | null
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      product_pricing_rules: {
        Row: {
          created_at: string
          factor_max: number
          factor_min: number
          id: string
          is_active: boolean
          max_approval_pct_of_avg_monthly: number
          product_id: string
          risk_tier_id: string
          state_code: string | null
          term_max_days: number
          term_min_days: number
          updated_at: string
        }
        Insert: {
          created_at?: string
          factor_max: number
          factor_min: number
          id?: string
          is_active?: boolean
          max_approval_pct_of_avg_monthly?: number
          product_id: string
          risk_tier_id: string
          state_code?: string | null
          term_max_days: number
          term_min_days: number
          updated_at?: string
        }
        Update: {
          created_at?: string
          factor_max?: number
          factor_min?: number
          id?: string
          is_active?: boolean
          max_approval_pct_of_avg_monthly?: number
          product_id?: string
          risk_tier_id?: string
          state_code?: string | null
          term_max_days?: number
          term_min_days?: number
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "product_pricing_rules_product_id_fkey"
            columns: ["product_id"]
            isOneToOne: false
            referencedRelation: "mca_products"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "product_pricing_rules_risk_tier_id_fkey"
            columns: ["risk_tier_id"]
            isOneToOne: false
            referencedRelation: "risk_tiers"
            referencedColumns: ["id"]
          },
        ]
      }
      profiles: {
        Row: {
          avatar_url: string | null
          created_at: string | null
          email: string | null
          full_name: string | null
          id: string
          is_closer: boolean | null
          is_opener: boolean | null
          iso_id: string | null
          phone: string | null
          position: string | null
          referral_code: string | null
          role: string | null
          status: string | null
          updated_at: string | null
        }
        Insert: {
          avatar_url?: string | null
          created_at?: string | null
          email?: string | null
          full_name?: string | null
          id: string
          is_closer?: boolean | null
          is_opener?: boolean | null
          iso_id?: string | null
          phone?: string | null
          position?: string | null
          referral_code?: string | null
          role?: string | null
          status?: string | null
          updated_at?: string | null
        }
        Update: {
          avatar_url?: string | null
          created_at?: string | null
          email?: string | null
          full_name?: string | null
          id?: string
          is_closer?: boolean | null
          is_opener?: boolean | null
          iso_id?: string | null
          phone?: string | null
          position?: string | null
          referral_code?: string | null
          role?: string | null
          status?: string | null
          updated_at?: string | null
        }
        Relationships: []
      }
      referral_partners: {
        Row: {
          active: boolean
          contact_name: string | null
          created_at: string
          created_by: string | null
          default_commission_pct: number
          email: string | null
          id: string
          name: string
          notes: string | null
          phone: string | null
          referral_code: string
          updated_at: string
        }
        Insert: {
          active?: boolean
          contact_name?: string | null
          created_at?: string
          created_by?: string | null
          default_commission_pct?: number
          email?: string | null
          id?: string
          name: string
          notes?: string | null
          phone?: string | null
          referral_code: string
          updated_at?: string
        }
        Update: {
          active?: boolean
          contact_name?: string | null
          created_at?: string
          created_by?: string | null
          default_commission_pct?: number
          email?: string | null
          id?: string
          name?: string
          notes?: string | null
          phone?: string | null
          referral_code?: string
          updated_at?: string
        }
        Relationships: []
      }
      renewal_offers: {
        Row: {
          created_at: string
          created_by: string | null
          id: string
          iso_id: string | null
          lead_id: string
          notes: string | null
          offer_json: Json
          original_deal_id: string
          responded_at: string | null
          sent_at: string | null
          status: string
          triggered_at: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          id?: string
          iso_id?: string | null
          lead_id: string
          notes?: string | null
          offer_json: Json
          original_deal_id: string
          responded_at?: string | null
          sent_at?: string | null
          status?: string
          triggered_at?: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          created_by?: string | null
          id?: string
          iso_id?: string | null
          lead_id?: string
          notes?: string | null
          offer_json?: Json
          original_deal_id?: string
          responded_at?: string | null
          sent_at?: string | null
          status?: string
          triggered_at?: string
          updated_at?: string
        }
        Relationships: []
      }
      renewal_opportunities: {
        Row: {
          comparison_metrics: Json | null
          contacted_at: string | null
          created_at: string | null
          current_metrics: Json | null
          funded_contract_id: string
          id: string
          identified_at: string | null
          opportunity_type: string
          priority: string | null
          reason: string
          resolved_at: string | null
          status: string | null
          suggested_amount: number | null
        }
        Insert: {
          comparison_metrics?: Json | null
          contacted_at?: string | null
          created_at?: string | null
          current_metrics?: Json | null
          funded_contract_id: string
          id?: string
          identified_at?: string | null
          opportunity_type: string
          priority?: string | null
          reason: string
          resolved_at?: string | null
          status?: string | null
          suggested_amount?: number | null
        }
        Update: {
          comparison_metrics?: Json | null
          contacted_at?: string | null
          created_at?: string | null
          current_metrics?: Json | null
          funded_contract_id?: string
          id?: string
          identified_at?: string | null
          opportunity_type?: string
          priority?: string | null
          reason?: string
          resolved_at?: string | null
          status?: string | null
          suggested_amount?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "renewal_opportunities_funded_contract_id_fkey"
            columns: ["funded_contract_id"]
            isOneToOne: false
            referencedRelation: "funded_contracts"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "renewal_opportunities_funded_contract_id_fkey"
            columns: ["funded_contract_id"]
            isOneToOne: false
            referencedRelation: "funding_records"
            referencedColumns: ["id"]
          },
        ]
      }
      renewal_rules: {
        Row: {
          allow_stack: boolean
          created_at: string
          id: string
          is_active: boolean
          max_paid_pct: number
          min_days_since_fund: number
          min_paid_pct: number
          updated_at: string
        }
        Insert: {
          allow_stack?: boolean
          created_at?: string
          id?: string
          is_active?: boolean
          max_paid_pct?: number
          min_days_since_fund?: number
          min_paid_pct?: number
          updated_at?: string
        }
        Update: {
          allow_stack?: boolean
          created_at?: string
          id?: string
          is_active?: boolean
          max_paid_pct?: number
          min_days_since_fund?: number
          min_paid_pct?: number
          updated_at?: string
        }
        Relationships: []
      }
      risk_alerts: {
        Row: {
          alert_type: string
          assigned_to: string | null
          created_at: string
          description: string
          entity_id: string
          entity_type: string
          id: string
          metadata: Json | null
          resolution_notes: string | null
          resolved_at: string | null
          resolved_by: string | null
          severity: string
          status: string
          title: string
          updated_at: string
        }
        Insert: {
          alert_type: string
          assigned_to?: string | null
          created_at?: string
          description: string
          entity_id: string
          entity_type: string
          id?: string
          metadata?: Json | null
          resolution_notes?: string | null
          resolved_at?: string | null
          resolved_by?: string | null
          severity?: string
          status?: string
          title: string
          updated_at?: string
        }
        Update: {
          alert_type?: string
          assigned_to?: string | null
          created_at?: string
          description?: string
          entity_id?: string
          entity_type?: string
          id?: string
          metadata?: Json | null
          resolution_notes?: string | null
          resolved_at?: string | null
          resolved_by?: string | null
          severity?: string
          status?: string
          title?: string
          updated_at?: string
        }
        Relationships: []
      }
      risk_tiers: {
        Row: {
          code: string
          created_at: string
          default_factor_rate_max: number | null
          default_factor_rate_min: number | null
          default_term_max_days: number | null
          default_term_min_days: number | null
          description: string | null
          id: string
          max_score: number
          min_score: number
          updated_at: string
        }
        Insert: {
          code: string
          created_at?: string
          default_factor_rate_max?: number | null
          default_factor_rate_min?: number | null
          default_term_max_days?: number | null
          default_term_min_days?: number | null
          description?: string | null
          id?: string
          max_score: number
          min_score: number
          updated_at?: string
        }
        Update: {
          code?: string
          created_at?: string
          default_factor_rate_max?: number | null
          default_factor_rate_min?: number | null
          default_term_max_days?: number | null
          default_term_min_days?: number | null
          description?: string | null
          id?: string
          max_score?: number
          min_score?: number
          updated_at?: string
        }
        Relationships: []
      }
      settlements: {
        Row: {
          case_id: string | null
          created_at: string
          created_by: string | null
          deal_id: string
          discount_pct: number
          id: string
          original_balance: number
          payment_plan_json: Json | null
          settlement_amount: number
          status: string
          updated_at: string
        }
        Insert: {
          case_id?: string | null
          created_at?: string
          created_by?: string | null
          deal_id: string
          discount_pct: number
          id?: string
          original_balance: number
          payment_plan_json?: Json | null
          settlement_amount: number
          status?: string
          updated_at?: string
        }
        Update: {
          case_id?: string | null
          created_at?: string
          created_by?: string | null
          deal_id?: string
          discount_pct?: number
          id?: string
          original_balance?: number
          payment_plan_json?: Json | null
          settlement_amount?: number
          status?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "settlements_case_id_fkey"
            columns: ["case_id"]
            isOneToOne: false
            referencedRelation: "collection_cases"
            referencedColumns: ["id"]
          },
        ]
      }
      signature_requests: {
        Row: {
          application_id: string
          application_type: string
          completed_at: string | null
          created_at: string
          docusign_envelope_id: string | null
          id: string
          initiated_by: string
          recipient_email: string
          recipient_name: string
          signed_document_url: string | null
          status: string
        }
        Insert: {
          application_id: string
          application_type: string
          completed_at?: string | null
          created_at?: string
          docusign_envelope_id?: string | null
          id?: string
          initiated_by: string
          recipient_email: string
          recipient_name: string
          signed_document_url?: string | null
          status?: string
        }
        Update: {
          application_id?: string
          application_type?: string
          completed_at?: string | null
          created_at?: string
          docusign_envelope_id?: string | null
          id?: string
          initiated_by?: string
          recipient_email?: string
          recipient_name?: string
          signed_document_url?: string | null
          status?: string
        }
        Relationships: []
      }
      sms_messages: {
        Row: {
          body: string | null
          channel: string | null
          client_id: string | null
          created_at: string | null
          created_by: string | null
          direction: string | null
          id: string
          lead_id: string | null
          phone_from: string | null
          phone_to: string | null
          status: string | null
        }
        Insert: {
          body?: string | null
          channel?: string | null
          client_id?: string | null
          created_at?: string | null
          created_by?: string | null
          direction?: string | null
          id?: string
          lead_id?: string | null
          phone_from?: string | null
          phone_to?: string | null
          status?: string | null
        }
        Update: {
          body?: string | null
          channel?: string | null
          client_id?: string | null
          created_at?: string | null
          created_by?: string | null
          direction?: string | null
          id?: string
          lead_id?: string | null
          phone_from?: string | null
          phone_to?: string | null
          status?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "sms_messages_client_id_fkey"
            columns: ["client_id"]
            isOneToOne: false
            referencedRelation: "intake_clients"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "sms_messages_lead_id_fkey"
            columns: ["lead_id"]
            isOneToOne: false
            referencedRelation: "leads"
            referencedColumns: ["id"]
          },
        ]
      }
      spvs: {
        Row: {
          code: string
          created_at: string
          description: string | null
          fund_id: string
          id: string
          name: string
          status: string
          updated_at: string
        }
        Insert: {
          code: string
          created_at?: string
          description?: string | null
          fund_id: string
          id?: string
          name: string
          status?: string
          updated_at?: string
        }
        Update: {
          code?: string
          created_at?: string
          description?: string | null
          fund_id?: string
          id?: string
          name?: string
          status?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "spvs_fund_id_fkey"
            columns: ["fund_id"]
            isOneToOne: false
            referencedRelation: "funds"
            referencedColumns: ["id"]
          },
        ]
      }
      system_optimization_suggestions: {
        Row: {
          applied_at: string | null
          applied_by: string | null
          created_at: string | null
          current_value: Json | null
          id: string
          proposed_value: Json | null
          rationale: string | null
          scope: string
          status: string | null
          suggestion_type: string
        }
        Insert: {
          applied_at?: string | null
          applied_by?: string | null
          created_at?: string | null
          current_value?: Json | null
          id?: string
          proposed_value?: Json | null
          rationale?: string | null
          scope: string
          status?: string | null
          suggestion_type: string
        }
        Update: {
          applied_at?: string | null
          applied_by?: string | null
          created_at?: string | null
          current_value?: Json | null
          id?: string
          proposed_value?: Json | null
          rationale?: string | null
          scope?: string
          status?: string | null
          suggestion_type?: string
        }
        Relationships: []
      }
      system_settings: {
        Row: {
          id: string
          key: string
          updated_at: string | null
          value_json: Json
        }
        Insert: {
          id?: string
          key: string
          updated_at?: string | null
          value_json: Json
        }
        Update: {
          id?: string
          key?: string
          updated_at?: string | null
          value_json?: Json
        }
        Relationships: []
      }
      templates_master_library: {
        Row: {
          body: string | null
          category: string
          channel: string
          created_at: string | null
          id: string
          is_active: boolean | null
          mode: string | null
          name: string
          placeholders: Json
          storage_path: string | null
          subject: string | null
          updated_at: string | null
          version: number
        }
        Insert: {
          body?: string | null
          category: string
          channel: string
          created_at?: string | null
          id?: string
          is_active?: boolean | null
          mode?: string | null
          name: string
          placeholders?: Json
          storage_path?: string | null
          subject?: string | null
          updated_at?: string | null
          version?: number
        }
        Update: {
          body?: string | null
          category?: string
          channel?: string
          created_at?: string | null
          id?: string
          is_active?: boolean | null
          mode?: string | null
          name?: string
          placeholders?: Json
          storage_path?: string | null
          subject?: string | null
          updated_at?: string | null
          version?: number
        }
        Relationships: []
      }
      terminals: {
        Row: {
          actual_monthly_volume: number | null
          created_at: string
          created_by: string
          estimated_monthly_volume: number | null
          id: string
          merchant_id: string | null
          metadata: Json
          mid: string | null
          owner_user_id: string
          processor_name: string
          status: string
          super_owner_id: string | null
          tenant_id: string | null
          updated_at: string
        }
        Insert: {
          actual_monthly_volume?: number | null
          created_at?: string
          created_by: string
          estimated_monthly_volume?: number | null
          id?: string
          merchant_id?: string | null
          metadata?: Json
          mid?: string | null
          owner_user_id: string
          processor_name: string
          status?: string
          super_owner_id?: string | null
          tenant_id?: string | null
          updated_at?: string
        }
        Update: {
          actual_monthly_volume?: number | null
          created_at?: string
          created_by?: string
          estimated_monthly_volume?: number | null
          id?: string
          merchant_id?: string | null
          metadata?: Json
          mid?: string | null
          owner_user_id?: string
          processor_name?: string
          status?: string
          super_owner_id?: string | null
          tenant_id?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "terminals_merchant_id_fkey"
            columns: ["merchant_id"]
            isOneToOne: false
            referencedRelation: "merchants"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "terminals_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "wf_tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      underwriting_cases: {
        Row: {
          ai_priority: string | null
          ai_recommended_path: string | null
          ai_score: number | null
          application_id: string
          application_type: string
          assigned_underwriter_id: string | null
          client_id: string | null
          closer_id: string | null
          created_at: string | null
          credit_fix_user_id: string | null
          current_stage: Database["public"]["Enums"]["case_stage"] | null
          docs_package_url: string | null
          funding_call_needed: boolean | null
          funding_call_notes: string | null
          funding_call_status: string | null
          funding_score: number | null
          id: string
          last_scan_at: string | null
          lock_expires_at: string | null
          lock_owner_id: string | null
          next_scan_at: string | null
          opener_id: string | null
          origin_source: string | null
          product_line: Database["public"]["Enums"]["product_line"] | null
          revenue_share: Json | null
          status: string
          system_notes: Json | null
          updated_at: string | null
        }
        Insert: {
          ai_priority?: string | null
          ai_recommended_path?: string | null
          ai_score?: number | null
          application_id: string
          application_type: string
          assigned_underwriter_id?: string | null
          client_id?: string | null
          closer_id?: string | null
          created_at?: string | null
          credit_fix_user_id?: string | null
          current_stage?: Database["public"]["Enums"]["case_stage"] | null
          docs_package_url?: string | null
          funding_call_needed?: boolean | null
          funding_call_notes?: string | null
          funding_call_status?: string | null
          funding_score?: number | null
          id?: string
          last_scan_at?: string | null
          lock_expires_at?: string | null
          lock_owner_id?: string | null
          next_scan_at?: string | null
          opener_id?: string | null
          origin_source?: string | null
          product_line?: Database["public"]["Enums"]["product_line"] | null
          revenue_share?: Json | null
          status?: string
          system_notes?: Json | null
          updated_at?: string | null
        }
        Update: {
          ai_priority?: string | null
          ai_recommended_path?: string | null
          ai_score?: number | null
          application_id?: string
          application_type?: string
          assigned_underwriter_id?: string | null
          client_id?: string | null
          closer_id?: string | null
          created_at?: string | null
          credit_fix_user_id?: string | null
          current_stage?: Database["public"]["Enums"]["case_stage"] | null
          docs_package_url?: string | null
          funding_call_needed?: boolean | null
          funding_call_notes?: string | null
          funding_call_status?: string | null
          funding_score?: number | null
          id?: string
          last_scan_at?: string | null
          lock_expires_at?: string | null
          lock_owner_id?: string | null
          next_scan_at?: string | null
          opener_id?: string | null
          origin_source?: string | null
          product_line?: Database["public"]["Enums"]["product_line"] | null
          revenue_share?: Json | null
          status?: string
          system_notes?: Json | null
          updated_at?: string | null
        }
        Relationships: []
      }
      underwriting_feedback: {
        Row: {
          application_id: string
          application_type: string
          corrected_by: string
          corrected_value: string
          created_at: string | null
          feedback_type: string
          field: string
          id: string
          notes: string | null
          original_value: string | null
          underwriting_case_id: string
        }
        Insert: {
          application_id: string
          application_type: string
          corrected_by: string
          corrected_value: string
          created_at?: string | null
          feedback_type: string
          field: string
          id?: string
          notes?: string | null
          original_value?: string | null
          underwriting_case_id: string
        }
        Update: {
          application_id?: string
          application_type?: string
          corrected_by?: string
          corrected_value?: string
          created_at?: string | null
          feedback_type?: string
          field?: string
          id?: string
          notes?: string | null
          original_value?: string | null
          underwriting_case_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "underwriting_feedback_underwriting_case_id_fkey"
            columns: ["underwriting_case_id"]
            isOneToOne: false
            referencedRelation: "underwriting_cases"
            referencedColumns: ["id"]
          },
        ]
      }
      underwriting_files: {
        Row: {
          application_id: string
          created_at: string
          id: string
          status: string
          summary_json: Json | null
          underwriter_id: string | null
          updated_at: string
        }
        Insert: {
          application_id: string
          created_at?: string
          id?: string
          status?: string
          summary_json?: Json | null
          underwriter_id?: string | null
          updated_at?: string
        }
        Update: {
          application_id?: string
          created_at?: string
          id?: string
          status?: string
          summary_json?: Json | null
          underwriter_id?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "underwriting_files_application_id_fkey"
            columns: ["application_id"]
            isOneToOne: false
            referencedRelation: "fast_track_applications"
            referencedColumns: ["id"]
          },
        ]
      }
      underwriting_metrics: {
        Row: {
          avg_daily_balance: number | null
          avg_monthly_revenue: number | null
          cash_flow_stability: string | null
          concentration_risk: string | null
          created_at: string | null
          existing_advances_estimate: string | null
          funder_safe_summary: string | null
          highest_monthly_deposits: number | null
          id: string
          internal_summary: string | null
          missing_items: Json | null
          months_analyzed: Json | null
          negative_days: number | null
          nsf_count: number | null
          raw_metrics: Json | null
          recommended_label: string | null
          revenue_trend: string | null
          risk_level: string | null
          seasonality_flag: boolean | null
          summary: string | null
          underwriting_case_id: string
        }
        Insert: {
          avg_daily_balance?: number | null
          avg_monthly_revenue?: number | null
          cash_flow_stability?: string | null
          concentration_risk?: string | null
          created_at?: string | null
          existing_advances_estimate?: string | null
          funder_safe_summary?: string | null
          highest_monthly_deposits?: number | null
          id?: string
          internal_summary?: string | null
          missing_items?: Json | null
          months_analyzed?: Json | null
          negative_days?: number | null
          nsf_count?: number | null
          raw_metrics?: Json | null
          recommended_label?: string | null
          revenue_trend?: string | null
          risk_level?: string | null
          seasonality_flag?: boolean | null
          summary?: string | null
          underwriting_case_id: string
        }
        Update: {
          avg_daily_balance?: number | null
          avg_monthly_revenue?: number | null
          cash_flow_stability?: string | null
          concentration_risk?: string | null
          created_at?: string | null
          existing_advances_estimate?: string | null
          funder_safe_summary?: string | null
          highest_monthly_deposits?: number | null
          id?: string
          internal_summary?: string | null
          missing_items?: Json | null
          months_analyzed?: Json | null
          negative_days?: number | null
          nsf_count?: number | null
          raw_metrics?: Json | null
          recommended_label?: string | null
          revenue_trend?: string | null
          risk_level?: string | null
          seasonality_flag?: boolean | null
          summary?: string | null
          underwriting_case_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "underwriting_metrics_underwriting_case_id_fkey"
            columns: ["underwriting_case_id"]
            isOneToOne: false
            referencedRelation: "underwriting_cases"
            referencedColumns: ["id"]
          },
        ]
      }
      underwriting_notes: {
        Row: {
          created_at: string | null
          id: string
          message: string
          note_type: string
          underwriting_case_id: string
          user_id: string
        }
        Insert: {
          created_at?: string | null
          id?: string
          message: string
          note_type: string
          underwriting_case_id: string
          user_id: string
        }
        Update: {
          created_at?: string | null
          id?: string
          message?: string
          note_type?: string
          underwriting_case_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "underwriting_notes_underwriting_case_id_fkey"
            columns: ["underwriting_case_id"]
            isOneToOne: false
            referencedRelation: "underwriting_cases"
            referencedColumns: ["id"]
          },
        ]
      }
      underwriting_tasks: {
        Row: {
          application_id: string
          assigned_to: string | null
          checklist: Json | null
          completed_at: string | null
          created_at: string | null
          id: string
          notes: string | null
          status: string | null
          updated_at: string | null
        }
        Insert: {
          application_id: string
          assigned_to?: string | null
          checklist?: Json | null
          completed_at?: string | null
          created_at?: string | null
          id?: string
          notes?: string | null
          status?: string | null
          updated_at?: string | null
        }
        Update: {
          application_id?: string
          assigned_to?: string | null
          checklist?: Json | null
          completed_at?: string | null
          created_at?: string | null
          id?: string
          notes?: string | null
          status?: string | null
          updated_at?: string | null
        }
        Relationships: []
      }
      user_presence: {
        Row: {
          active_client_chats: number
          is_online: boolean
          last_active_at: string
          last_assigned_at: string | null
          user_id: string
        }
        Insert: {
          active_client_chats?: number
          is_online?: boolean
          last_active_at?: string
          last_assigned_at?: string | null
          user_id: string
        }
        Update: {
          active_client_chats?: number
          is_online?: boolean
          last_active_at?: string
          last_assigned_at?: string | null
          user_id?: string
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          approved: boolean | null
          approved_at: string | null
          approved_by: string | null
          created_at: string | null
          display_name: string | null
          id: string
          is_primary: boolean | null
          position: string | null
          position_label: string | null
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          approved?: boolean | null
          approved_at?: string | null
          approved_by?: string | null
          created_at?: string | null
          display_name?: string | null
          id?: string
          is_primary?: boolean | null
          position?: string | null
          position_label?: string | null
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          approved?: boolean | null
          approved_at?: string | null
          approved_by?: string | null
          created_at?: string | null
          display_name?: string | null
          id?: string
          is_primary?: boolean | null
          position?: string | null
          position_label?: string | null
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
      user_settings: {
        Row: {
          auto_tts_enabled: boolean
          created_at: string
          tts_speed: number | null
          tts_voice: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          auto_tts_enabled?: boolean
          created_at?: string
          tts_speed?: number | null
          tts_voice?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          auto_tts_enabled?: boolean
          created_at?: string
          tts_speed?: number | null
          tts_voice?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      uw_rule_sets: {
        Row: {
          created_at: string
          description: string | null
          id: string
          is_active: boolean
          name: string
          updated_at: string
          version: number
        }
        Insert: {
          created_at?: string
          description?: string | null
          id?: string
          is_active?: boolean
          name: string
          updated_at?: string
          version?: number
        }
        Update: {
          created_at?: string
          description?: string | null
          id?: string
          is_active?: boolean
          name?: string
          updated_at?: string
          version?: number
        }
        Relationships: []
      }
      uw_rules: {
        Row: {
          action: string
          created_at: string
          field: string
          id: string
          is_active: boolean
          operator: string
          params_json: Json | null
          priority: number
          rule_set_id: string
          scope: string
          updated_at: string
          value_json: Json
        }
        Insert: {
          action: string
          created_at?: string
          field: string
          id?: string
          is_active?: boolean
          operator: string
          params_json?: Json | null
          priority?: number
          rule_set_id: string
          scope: string
          updated_at?: string
          value_json: Json
        }
        Update: {
          action?: string
          created_at?: string
          field?: string
          id?: string
          is_active?: boolean
          operator?: string
          params_json?: Json | null
          priority?: number
          rule_set_id?: string
          scope?: string
          updated_at?: string
          value_json?: Json
        }
        Relationships: [
          {
            foreignKeyName: "uw_rules_rule_set_id_fkey"
            columns: ["rule_set_id"]
            isOneToOne: false
            referencedRelation: "uw_rule_sets"
            referencedColumns: ["id"]
          },
        ]
      }
      wf_ai_cost_summary: {
        Row: {
          created_at: string
          feature: string
          id: string
          period_end: string
          period_start: string
          provider: string
          total_calls: number
          total_estimated_cost_usd: number | null
          total_estimated_tokens: number | null
          total_input_chars: number | null
          total_output_chars: number | null
          updated_at: string
        }
        Insert: {
          created_at?: string
          feature: string
          id?: string
          period_end: string
          period_start: string
          provider: string
          total_calls?: number
          total_estimated_cost_usd?: number | null
          total_estimated_tokens?: number | null
          total_input_chars?: number | null
          total_output_chars?: number | null
          updated_at?: string
        }
        Update: {
          created_at?: string
          feature?: string
          id?: string
          period_end?: string
          period_start?: string
          provider?: string
          total_calls?: number
          total_estimated_cost_usd?: number | null
          total_estimated_tokens?: number | null
          total_input_chars?: number | null
          total_output_chars?: number | null
          updated_at?: string
        }
        Relationships: []
      }
      wf_ai_usage_events: {
        Row: {
          brand_key: string | null
          context_id: string | null
          context_type: string | null
          created_at: string
          error_code: string | null
          estimated_cost_usd: number | null
          estimated_tokens: number | null
          feature: string
          id: string
          input_chars: number | null
          output_chars: number | null
          provider: string
          status: string
          tenant_id: string | null
        }
        Insert: {
          brand_key?: string | null
          context_id?: string | null
          context_type?: string | null
          created_at?: string
          error_code?: string | null
          estimated_cost_usd?: number | null
          estimated_tokens?: number | null
          feature: string
          id?: string
          input_chars?: number | null
          output_chars?: number | null
          provider?: string
          status?: string
          tenant_id?: string | null
        }
        Update: {
          brand_key?: string | null
          context_id?: string | null
          context_type?: string | null
          created_at?: string
          error_code?: string | null
          estimated_cost_usd?: number | null
          estimated_tokens?: number | null
          feature?: string
          id?: string
          input_chars?: number | null
          output_chars?: number | null
          provider?: string
          status?: string
          tenant_id?: string | null
        }
        Relationships: []
      }
      wf_alert_channels: {
        Row: {
          created_at: string
          enabled: boolean
          id: string
          meta: Json
          target: string
          tenant_id: string
          type: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          enabled?: boolean
          id?: string
          meta?: Json
          target: string
          tenant_id: string
          type: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          enabled?: boolean
          id?: string
          meta?: Json
          target?: string
          tenant_id?: string
          type?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "wf_alert_channels_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "wf_tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      wf_alert_events: {
        Row: {
          body: string | null
          category: string
          created_at: string
          id: string
          meta: Json
          related_policy_id: string | null
          related_run_id: string | null
          severity: string
          source: string
          tenant_id: string
          title: string
        }
        Insert: {
          body?: string | null
          category: string
          created_at?: string
          id?: string
          meta?: Json
          related_policy_id?: string | null
          related_run_id?: string | null
          severity: string
          source?: string
          tenant_id: string
          title: string
        }
        Update: {
          body?: string | null
          category?: string
          created_at?: string
          id?: string
          meta?: Json
          related_policy_id?: string | null
          related_run_id?: string | null
          severity?: string
          source?: string
          tenant_id?: string
          title?: string
        }
        Relationships: [
          {
            foreignKeyName: "wf_alert_events_related_policy_id_fkey"
            columns: ["related_policy_id"]
            isOneToOne: false
            referencedRelation: "wf_autopilot_policies"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "wf_alert_events_related_run_id_fkey"
            columns: ["related_run_id"]
            isOneToOne: false
            referencedRelation: "wf_autopilot_runs"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "wf_alert_events_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "wf_tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      wf_autopilot_actions: {
        Row: {
          body: string | null
          category: string
          confidence_score: number | null
          created_at: string
          id: string
          impact_score: number | null
          meta: Json
          related_application_id: string | null
          related_collection_case_id: string | null
          related_credit_case_id: string | null
          related_deal_id: string | null
          related_task_id: string | null
          role: string | null
          run_id: string | null
          scope: string
          severity: string
          status: string
          tenant_id: string
          title: string
          updated_at: string
          user_id: string | null
        }
        Insert: {
          body?: string | null
          category: string
          confidence_score?: number | null
          created_at?: string
          id?: string
          impact_score?: number | null
          meta?: Json
          related_application_id?: string | null
          related_collection_case_id?: string | null
          related_credit_case_id?: string | null
          related_deal_id?: string | null
          related_task_id?: string | null
          role?: string | null
          run_id?: string | null
          scope: string
          severity?: string
          status?: string
          tenant_id: string
          title: string
          updated_at?: string
          user_id?: string | null
        }
        Update: {
          body?: string | null
          category?: string
          confidence_score?: number | null
          created_at?: string
          id?: string
          impact_score?: number | null
          meta?: Json
          related_application_id?: string | null
          related_collection_case_id?: string | null
          related_credit_case_id?: string | null
          related_deal_id?: string | null
          related_task_id?: string | null
          role?: string | null
          run_id?: string | null
          scope?: string
          severity?: string
          status?: string
          tenant_id?: string
          title?: string
          updated_at?: string
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "wf_autopilot_actions_run_id_fkey"
            columns: ["run_id"]
            isOneToOne: false
            referencedRelation: "wf_autopilot_runs"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "wf_autopilot_actions_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "wf_tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      wf_autopilot_policies: {
        Row: {
          autopilot_enabled: boolean
          created_at: string
          id: string
          last_manual_override_at: string | null
          max_critical_insights: number | null
          max_hours_since_last_run: number | null
          max_open_actions: number | null
          meta: Json
          schedule_time: string | null
          schedule_timezone: string | null
          schedule_type: string
          tenant_id: string
          updated_at: string
        }
        Insert: {
          autopilot_enabled?: boolean
          created_at?: string
          id?: string
          last_manual_override_at?: string | null
          max_critical_insights?: number | null
          max_hours_since_last_run?: number | null
          max_open_actions?: number | null
          meta?: Json
          schedule_time?: string | null
          schedule_timezone?: string | null
          schedule_type?: string
          tenant_id: string
          updated_at?: string
        }
        Update: {
          autopilot_enabled?: boolean
          created_at?: string
          id?: string
          last_manual_override_at?: string | null
          max_critical_insights?: number | null
          max_hours_since_last_run?: number | null
          max_open_actions?: number | null
          meta?: Json
          schedule_time?: string | null
          schedule_timezone?: string | null
          schedule_type?: string
          tenant_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "wf_autopilot_policies_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: true
            referencedRelation: "wf_tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      wf_autopilot_runs: {
        Row: {
          error_message: string | null
          finished_at: string | null
          id: string
          meta: Json
          started_at: string
          status: string
          tenant_id: string
          total_actions: number
          total_insights: number
          total_tags: number
        }
        Insert: {
          error_message?: string | null
          finished_at?: string | null
          id?: string
          meta?: Json
          started_at?: string
          status?: string
          tenant_id: string
          total_actions?: number
          total_insights?: number
          total_tags?: number
        }
        Update: {
          error_message?: string | null
          finished_at?: string | null
          id?: string
          meta?: Json
          started_at?: string
          status?: string
          tenant_id?: string
          total_actions?: number
          total_insights?: number
          total_tags?: number
        }
        Relationships: [
          {
            foreignKeyName: "wf_autopilot_runs_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "wf_tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      wf_billing_plans: {
        Row: {
          base_fee: number | null
          created_at: string
          description: string | null
          event_pricing: Json
          id: string
          is_active: boolean | null
          name: string
          plan_key: string
          updated_at: string
        }
        Insert: {
          base_fee?: number | null
          created_at?: string
          description?: string | null
          event_pricing?: Json
          id?: string
          is_active?: boolean | null
          name: string
          plan_key: string
          updated_at?: string
        }
        Update: {
          base_fee?: number | null
          created_at?: string
          description?: string | null
          event_pricing?: Json
          id?: string
          is_active?: boolean | null
          name?: string
          plan_key?: string
          updated_at?: string
        }
        Relationships: []
      }
      wf_chat_session_overrides: {
        Row: {
          created_at: string | null
          expires_at: string | null
          id: string
          mode_override: string | null
          session_id: string
          user_id: string | null
        }
        Insert: {
          created_at?: string | null
          expires_at?: string | null
          id?: string
          mode_override?: string | null
          session_id: string
          user_id?: string | null
        }
        Update: {
          created_at?: string | null
          expires_at?: string | null
          id?: string
          mode_override?: string | null
          session_id?: string
          user_id?: string | null
        }
        Relationships: []
      }
      wf_client_portal_tokens: {
        Row: {
          case_id: string
          client_email: string
          created_at: string
          expires_at: string
          id: string
          tenant_id: string
          token: string
          used_at: string | null
        }
        Insert: {
          case_id: string
          client_email: string
          created_at?: string
          expires_at: string
          id?: string
          tenant_id: string
          token: string
          used_at?: string | null
        }
        Update: {
          case_id?: string
          client_email?: string
          created_at?: string
          expires_at?: string
          id?: string
          tenant_id?: string
          token?: string
          used_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "wf_client_portal_tokens_case_id_fkey"
            columns: ["case_id"]
            isOneToOne: false
            referencedRelation: "credit_cases_v2"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "wf_client_portal_tokens_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "wf_tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      wf_contract_templates: {
        Row: {
          base_template: string
          category: string | null
          created_at: string | null
          display_name: string
          id: string
          is_active: boolean | null
          key: string
          placeholders: Json | null
          requires_ai: boolean | null
          updated_at: string | null
        }
        Insert: {
          base_template: string
          category?: string | null
          created_at?: string | null
          display_name: string
          id?: string
          is_active?: boolean | null
          key: string
          placeholders?: Json | null
          requires_ai?: boolean | null
          updated_at?: string | null
        }
        Update: {
          base_template?: string
          category?: string | null
          created_at?: string | null
          display_name?: string
          id?: string
          is_active?: boolean | null
          key?: string
          placeholders?: Json | null
          requires_ai?: boolean | null
          updated_at?: string | null
        }
        Relationships: []
      }
      wf_credit_status: {
        Row: {
          consecutive_errors: number | null
          id: string
          last_error_at: string | null
          last_success_at: string | null
          notes: string | null
          provider: string
          status: string
          updated_at: string | null
          updated_by: string | null
        }
        Insert: {
          consecutive_errors?: number | null
          id?: string
          last_error_at?: string | null
          last_success_at?: string | null
          notes?: string | null
          provider?: string
          status?: string
          updated_at?: string | null
          updated_by?: string | null
        }
        Update: {
          consecutive_errors?: number | null
          id?: string
          last_error_at?: string | null
          last_success_at?: string | null
          notes?: string | null
          provider?: string
          status?: string
          updated_at?: string | null
          updated_by?: string | null
        }
        Relationships: []
      }
      wf_dev_suggestion_events: {
        Row: {
          action: string
          area: string
          id: string
          metadata: Json | null
          performed_at: string | null
          performed_by: string | null
          source_check_id: string | null
          suggestion_id: string
          tenant_id: string
        }
        Insert: {
          action: string
          area: string
          id?: string
          metadata?: Json | null
          performed_at?: string | null
          performed_by?: string | null
          source_check_id?: string | null
          suggestion_id: string
          tenant_id: string
        }
        Update: {
          action?: string
          area?: string
          id?: string
          metadata?: Json | null
          performed_at?: string | null
          performed_by?: string | null
          source_check_id?: string | null
          suggestion_id?: string
          tenant_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "wf_dev_suggestion_events_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "wf_tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      wf_email_outbox: {
        Row: {
          attempt_count: number
          body: string
          case_id: string | null
          created_at: string
          id: string
          last_error: string | null
          lead_id: string | null
          meta: Json
          send_after: string
          sent_at: string | null
          status: string
          subject: string
          tenant_id: string
          to_email: string
          to_name: string | null
          updated_at: string
        }
        Insert: {
          attempt_count?: number
          body: string
          case_id?: string | null
          created_at?: string
          id?: string
          last_error?: string | null
          lead_id?: string | null
          meta?: Json
          send_after?: string
          sent_at?: string | null
          status?: string
          subject: string
          tenant_id: string
          to_email: string
          to_name?: string | null
          updated_at?: string
        }
        Update: {
          attempt_count?: number
          body?: string
          case_id?: string | null
          created_at?: string
          id?: string
          last_error?: string | null
          lead_id?: string | null
          meta?: Json
          send_after?: string
          sent_at?: string | null
          status?: string
          subject?: string
          tenant_id?: string
          to_email?: string
          to_name?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "wf_email_outbox_case_id_fkey"
            columns: ["case_id"]
            isOneToOne: false
            referencedRelation: "credit_cases_v2"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "wf_email_outbox_lead_id_fkey"
            columns: ["lead_id"]
            isOneToOne: false
            referencedRelation: "wf_leads"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "wf_email_outbox_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "wf_tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      wf_email_templates: {
        Row: {
          body: string
          channel: string
          created_at: string
          id: string
          is_active: boolean
          key: string
          meta: Json
          name: string
          subject: string
          tenant_id: string
          updated_at: string
        }
        Insert: {
          body: string
          channel?: string
          created_at?: string
          id?: string
          is_active?: boolean
          key: string
          meta?: Json
          name: string
          subject: string
          tenant_id: string
          updated_at?: string
        }
        Update: {
          body?: string
          channel?: string
          created_at?: string
          id?: string
          is_active?: boolean
          key?: string
          meta?: Json
          name?: string
          subject?: string
          tenant_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "wf_email_templates_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "wf_tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      wf_events: {
        Row: {
          application_id: string | null
          collection_case_id: string | null
          created_at: string
          credit_case_id: string | null
          deal_id: string | null
          description: string | null
          event_type: string
          id: string
          meta: Json | null
          role: string | null
          severity: string | null
          source: string
          task_id: string | null
          tenant_id: string | null
          title: string
          user_id: string | null
        }
        Insert: {
          application_id?: string | null
          collection_case_id?: string | null
          created_at?: string
          credit_case_id?: string | null
          deal_id?: string | null
          description?: string | null
          event_type: string
          id?: string
          meta?: Json | null
          role?: string | null
          severity?: string | null
          source: string
          task_id?: string | null
          tenant_id?: string | null
          title: string
          user_id?: string | null
        }
        Update: {
          application_id?: string | null
          collection_case_id?: string | null
          created_at?: string
          credit_case_id?: string | null
          deal_id?: string | null
          description?: string | null
          event_type?: string
          id?: string
          meta?: Json | null
          role?: string | null
          severity?: string | null
          source?: string
          task_id?: string | null
          tenant_id?: string | null
          title?: string
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "wf_events_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "wf_tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      wf_generated_contracts: {
        Row: {
          ai_polished: boolean | null
          application_id: string | null
          created_at: string | null
          generated_by: string | null
          generated_content: string
          id: string
          lead_id: string | null
          placeholders_used: Json | null
          template_key: string
        }
        Insert: {
          ai_polished?: boolean | null
          application_id?: string | null
          created_at?: string | null
          generated_by?: string | null
          generated_content: string
          id?: string
          lead_id?: string | null
          placeholders_used?: Json | null
          template_key: string
        }
        Update: {
          ai_polished?: boolean | null
          application_id?: string | null
          created_at?: string | null
          generated_by?: string | null
          generated_content?: string
          id?: string
          lead_id?: string | null
          placeholders_used?: Json | null
          template_key?: string
        }
        Relationships: []
      }
      wf_governance_actions: {
        Row: {
          action_type: string
          brand_key: string | null
          id: string
          metadata: Json | null
          new_state: Json | null
          notes: string | null
          performed_at: string | null
          performed_by: string | null
          previous_state: Json | null
          related_asset_id: string | null
          related_event_type: string | null
          source_check_id: string | null
          source_suggestion_id: string | null
          tenant_id: string
        }
        Insert: {
          action_type: string
          brand_key?: string | null
          id?: string
          metadata?: Json | null
          new_state?: Json | null
          notes?: string | null
          performed_at?: string | null
          performed_by?: string | null
          previous_state?: Json | null
          related_asset_id?: string | null
          related_event_type?: string | null
          source_check_id?: string | null
          source_suggestion_id?: string | null
          tenant_id: string
        }
        Update: {
          action_type?: string
          brand_key?: string | null
          id?: string
          metadata?: Json | null
          new_state?: Json | null
          notes?: string | null
          performed_at?: string | null
          performed_by?: string | null
          previous_state?: Json | null
          related_asset_id?: string | null
          related_event_type?: string | null
          source_check_id?: string | null
          source_suggestion_id?: string | null
          tenant_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "wf_governance_actions_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "wf_tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      wf_governance_alerts: {
        Row: {
          acknowledged_at: string | null
          acknowledged_by: string | null
          alert_type: string
          brand_key: string | null
          current_value: number | null
          id: string
          last_triggered_at: string | null
          metadata: Json | null
          metric_key: string | null
          resolved_at: string | null
          resolved_by: string | null
          status: string
          tenant_id: string
          threshold_value: number | null
        }
        Insert: {
          acknowledged_at?: string | null
          acknowledged_by?: string | null
          alert_type: string
          brand_key?: string | null
          current_value?: number | null
          id?: string
          last_triggered_at?: string | null
          metadata?: Json | null
          metric_key?: string | null
          resolved_at?: string | null
          resolved_by?: string | null
          status?: string
          tenant_id: string
          threshold_value?: number | null
        }
        Update: {
          acknowledged_at?: string | null
          acknowledged_by?: string | null
          alert_type?: string
          brand_key?: string | null
          current_value?: number | null
          id?: string
          last_triggered_at?: string | null
          metadata?: Json | null
          metric_key?: string | null
          resolved_at?: string | null
          resolved_by?: string | null
          status?: string
          tenant_id?: string
          threshold_value?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "wf_governance_alerts_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "wf_tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      wf_governance_reports: {
        Row: {
          checks: Json
          created_at: string | null
          id: string
          run_id: string | null
          run_type: string | null
          signals: Json
          summary: Json
          tenant_id: string
        }
        Insert: {
          checks?: Json
          created_at?: string | null
          id?: string
          run_id?: string | null
          run_type?: string | null
          signals?: Json
          summary?: Json
          tenant_id: string
        }
        Update: {
          checks?: Json
          created_at?: string | null
          id?: string
          run_id?: string | null
          run_type?: string | null
          signals?: Json
          summary?: Json
          tenant_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "wf_governance_reports_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "wf_tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      wf_insight_runs: {
        Row: {
          created_at: string
          id: string
          tenant_id: string | null
          total_candidates: number
          total_inserted: number
          user_id: string | null
        }
        Insert: {
          created_at?: string
          id?: string
          tenant_id?: string | null
          total_candidates?: number
          total_inserted?: number
          user_id?: string | null
        }
        Update: {
          created_at?: string
          id?: string
          tenant_id?: string | null
          total_candidates?: number
          total_inserted?: number
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "wf_insight_runs_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "wf_tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      wf_insights: {
        Row: {
          body: string | null
          category: string
          confidence_score: number | null
          created_at: string
          id: string
          impact_score: number | null
          meta: Json | null
          role: string | null
          run_id: string | null
          scope: string
          severity: string
          source: string
          status: string
          suggested_value: Json | null
          tenant_id: string | null
          title: string
          updated_at: string
          user_id: string | null
        }
        Insert: {
          body?: string | null
          category: string
          confidence_score?: number | null
          created_at?: string
          id?: string
          impact_score?: number | null
          meta?: Json | null
          role?: string | null
          run_id?: string | null
          scope: string
          severity?: string
          source?: string
          status?: string
          suggested_value?: Json | null
          tenant_id?: string | null
          title: string
          updated_at?: string
          user_id?: string | null
        }
        Update: {
          body?: string | null
          category?: string
          confidence_score?: number | null
          created_at?: string
          id?: string
          impact_score?: number | null
          meta?: Json | null
          role?: string | null
          run_id?: string | null
          scope?: string
          severity?: string
          source?: string
          status?: string
          suggested_value?: Json | null
          tenant_id?: string | null
          title?: string
          updated_at?: string
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "wf_insights_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "wf_tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      wf_ip_actions: {
        Row: {
          action_type: string
          assigned_to: string | null
          completed_at: string | null
          created_at: string
          draft_id: string | null
          id: string
          notes: string | null
          status: string | null
          tenant_id: string
        }
        Insert: {
          action_type: string
          assigned_to?: string | null
          completed_at?: string | null
          created_at?: string
          draft_id?: string | null
          id?: string
          notes?: string | null
          status?: string | null
          tenant_id: string
        }
        Update: {
          action_type?: string
          assigned_to?: string | null
          completed_at?: string | null
          created_at?: string
          draft_id?: string | null
          id?: string
          notes?: string | null
          status?: string | null
          tenant_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "wf_ip_actions_draft_id_fkey"
            columns: ["draft_id"]
            isOneToOne: false
            referencedRelation: "wf_ip_legal_drafts"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "wf_ip_actions_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "wf_tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      wf_ip_assets: {
        Row: {
          asset_type: string
          brand_key: string | null
          created_at: string
          defense_notes: string | null
          defense_status: string | null
          description: string | null
          hash_signature: string | null
          id: string
          legal_priority: string | null
          metadata: Json | null
          name: string
          source_path: string | null
          source_repo: string | null
          tags: string[] | null
          tenant_id: string
          updated_at: string
        }
        Insert: {
          asset_type: string
          brand_key?: string | null
          created_at?: string
          defense_notes?: string | null
          defense_status?: string | null
          description?: string | null
          hash_signature?: string | null
          id?: string
          legal_priority?: string | null
          metadata?: Json | null
          name: string
          source_path?: string | null
          source_repo?: string | null
          tags?: string[] | null
          tenant_id: string
          updated_at?: string
        }
        Update: {
          asset_type?: string
          brand_key?: string | null
          created_at?: string
          defense_notes?: string | null
          defense_status?: string | null
          description?: string | null
          hash_signature?: string | null
          id?: string
          legal_priority?: string | null
          metadata?: Json | null
          name?: string
          source_path?: string | null
          source_repo?: string | null
          tags?: string[] | null
          tenant_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "wf_ip_assets_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "wf_tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      wf_ip_events: {
        Row: {
          asset_id: string | null
          created_at: string
          description: string | null
          event_type: string
          id: string
          payload: Json | null
          source: string | null
          tenant_id: string
        }
        Insert: {
          asset_id?: string | null
          created_at?: string
          description?: string | null
          event_type: string
          id?: string
          payload?: Json | null
          source?: string | null
          tenant_id: string
        }
        Update: {
          asset_id?: string | null
          created_at?: string
          description?: string | null
          event_type?: string
          id?: string
          payload?: Json | null
          source?: string | null
          tenant_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "wf_ip_events_asset_id_fkey"
            columns: ["asset_id"]
            isOneToOne: false
            referencedRelation: "wf_ip_assets"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "wf_ip_events_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "wf_tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      wf_ip_evidence_bundles: {
        Row: {
          asset_id: string | null
          bundle_html: string | null
          bundle_type: string | null
          created_at: string | null
          generated_at: string | null
          generated_by: string | null
          id: string
          metadata: Json | null
          notes_for_attorney: string | null
          tenant_id: string
        }
        Insert: {
          asset_id?: string | null
          bundle_html?: string | null
          bundle_type?: string | null
          created_at?: string | null
          generated_at?: string | null
          generated_by?: string | null
          id?: string
          metadata?: Json | null
          notes_for_attorney?: string | null
          tenant_id: string
        }
        Update: {
          asset_id?: string | null
          bundle_html?: string | null
          bundle_type?: string | null
          created_at?: string | null
          generated_at?: string | null
          generated_by?: string | null
          id?: string
          metadata?: Json | null
          notes_for_attorney?: string | null
          tenant_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "wf_ip_evidence_bundles_asset_id_fkey"
            columns: ["asset_id"]
            isOneToOne: false
            referencedRelation: "wf_ip_assets"
            referencedColumns: ["id"]
          },
        ]
      }
      wf_ip_filing_packets: {
        Row: {
          asset_id: string | null
          attorney_name: string | null
          attorney_reviewed: boolean | null
          body: string
          checklist: Json | null
          created_at: string
          created_by: string | null
          external_filing_ref: string | null
          externally_filed: boolean | null
          filing_notes: string | null
          filing_region: string | null
          id: string
          metadata: Json | null
          packet_type: string
          status: string
          tenant_id: string
          title: string
          updated_at: string
        }
        Insert: {
          asset_id?: string | null
          attorney_name?: string | null
          attorney_reviewed?: boolean | null
          body: string
          checklist?: Json | null
          created_at?: string
          created_by?: string | null
          external_filing_ref?: string | null
          externally_filed?: boolean | null
          filing_notes?: string | null
          filing_region?: string | null
          id?: string
          metadata?: Json | null
          packet_type: string
          status?: string
          tenant_id: string
          title: string
          updated_at?: string
        }
        Update: {
          asset_id?: string | null
          attorney_name?: string | null
          attorney_reviewed?: boolean | null
          body?: string
          checklist?: Json | null
          created_at?: string
          created_by?: string | null
          external_filing_ref?: string | null
          externally_filed?: boolean | null
          filing_notes?: string | null
          filing_region?: string | null
          id?: string
          metadata?: Json | null
          packet_type?: string
          status?: string
          tenant_id?: string
          title?: string
          updated_at?: string
        }
        Relationships: []
      }
      wf_ip_legal_drafts: {
        Row: {
          ai_model: string | null
          asset_id: string | null
          body: string
          created_at: string
          doc_type: string
          id: string
          metadata: Json | null
          reviewed_at: string | null
          reviewed_by: string | null
          status: string | null
          tenant_id: string
          title: string
          updated_at: string
        }
        Insert: {
          ai_model?: string | null
          asset_id?: string | null
          body: string
          created_at?: string
          doc_type: string
          id?: string
          metadata?: Json | null
          reviewed_at?: string | null
          reviewed_by?: string | null
          status?: string | null
          tenant_id: string
          title: string
          updated_at?: string
        }
        Update: {
          ai_model?: string | null
          asset_id?: string | null
          body?: string
          created_at?: string
          doc_type?: string
          id?: string
          metadata?: Json | null
          reviewed_at?: string | null
          reviewed_by?: string | null
          status?: string | null
          tenant_id?: string
          title?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "wf_ip_legal_drafts_asset_id_fkey"
            columns: ["asset_id"]
            isOneToOne: false
            referencedRelation: "wf_ip_assets"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "wf_ip_legal_drafts_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "wf_tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      wf_ip_versions: {
        Row: {
          asset_id: string
          change_type: string | null
          created_at: string
          created_by: string | null
          diff_summary: string | null
          id: string
          metadata: Json | null
          snapshot_hash: string | null
          version_tag: string
        }
        Insert: {
          asset_id: string
          change_type?: string | null
          created_at?: string
          created_by?: string | null
          diff_summary?: string | null
          id?: string
          metadata?: Json | null
          snapshot_hash?: string | null
          version_tag: string
        }
        Update: {
          asset_id?: string
          change_type?: string | null
          created_at?: string
          created_by?: string | null
          diff_summary?: string | null
          id?: string
          metadata?: Json | null
          snapshot_hash?: string | null
          version_tag?: string
        }
        Relationships: [
          {
            foreignKeyName: "wf_ip_versions_asset_id_fkey"
            columns: ["asset_id"]
            isOneToOne: false
            referencedRelation: "wf_ip_assets"
            referencedColumns: ["id"]
          },
        ]
      }
      wf_leads: {
        Row: {
          assigned_at: string | null
          assigned_to: string | null
          channel: string | null
          converted_at: string | null
          created_at: string
          created_by: string | null
          credit_case_v2_id: string | null
          email: string | null
          estimated_credit_score: string | null
          fast_track_id: string | null
          first_name: string | null
          full_name: string | null
          id: string
          last_name: string | null
          lead_type: string
          legacy_credit_app_id: string | null
          loan_application_id: string | null
          meta: Json
          notes: string | null
          phone: string | null
          priority: string
          source: string
          status: string
          tenant_id: string
          updated_at: string
        }
        Insert: {
          assigned_at?: string | null
          assigned_to?: string | null
          channel?: string | null
          converted_at?: string | null
          created_at?: string
          created_by?: string | null
          credit_case_v2_id?: string | null
          email?: string | null
          estimated_credit_score?: string | null
          fast_track_id?: string | null
          first_name?: string | null
          full_name?: string | null
          id?: string
          last_name?: string | null
          lead_type: string
          legacy_credit_app_id?: string | null
          loan_application_id?: string | null
          meta?: Json
          notes?: string | null
          phone?: string | null
          priority?: string
          source: string
          status?: string
          tenant_id: string
          updated_at?: string
        }
        Update: {
          assigned_at?: string | null
          assigned_to?: string | null
          channel?: string | null
          converted_at?: string | null
          created_at?: string
          created_by?: string | null
          credit_case_v2_id?: string | null
          email?: string | null
          estimated_credit_score?: string | null
          fast_track_id?: string | null
          first_name?: string | null
          full_name?: string | null
          id?: string
          last_name?: string | null
          lead_type?: string
          legacy_credit_app_id?: string | null
          loan_application_id?: string | null
          meta?: Json
          notes?: string | null
          phone?: string | null
          priority?: string
          source?: string
          status?: string
          tenant_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "fk_wf_leads_credit_case_v2"
            columns: ["credit_case_v2_id"]
            isOneToOne: false
            referencedRelation: "credit_cases_v2"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "wf_leads_fast_track_id_fkey"
            columns: ["fast_track_id"]
            isOneToOne: false
            referencedRelation: "fast_track_applications"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "wf_leads_legacy_credit_app_id_fkey"
            columns: ["legacy_credit_app_id"]
            isOneToOne: false
            referencedRelation: "credit_repair_applications"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "wf_leads_loan_application_id_fkey"
            columns: ["loan_application_id"]
            isOneToOne: false
            referencedRelation: "loan_applications"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "wf_leads_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "wf_tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      wf_manual_tasks: {
        Row: {
          assigned_at: string | null
          assigned_to: string | null
          completed_at: string | null
          context_id: string | null
          context_type: string | null
          cost_usd: number | null
          created_at: string | null
          description: string | null
          feature: string
          id: string
          priority: string | null
          result: Json | null
          status: string | null
          task_type: string
          tenant_id: string | null
          time_spent_minutes: number | null
          updated_at: string | null
        }
        Insert: {
          assigned_at?: string | null
          assigned_to?: string | null
          completed_at?: string | null
          context_id?: string | null
          context_type?: string | null
          cost_usd?: number | null
          created_at?: string | null
          description?: string | null
          feature: string
          id?: string
          priority?: string | null
          result?: Json | null
          status?: string | null
          task_type?: string
          tenant_id?: string | null
          time_spent_minutes?: number | null
          updated_at?: string | null
        }
        Update: {
          assigned_at?: string | null
          assigned_to?: string | null
          completed_at?: string | null
          context_id?: string | null
          context_type?: string | null
          cost_usd?: number | null
          created_at?: string | null
          description?: string | null
          feature?: string
          id?: string
          priority?: string | null
          result?: Json | null
          status?: string | null
          task_type?: string
          tenant_id?: string | null
          time_spent_minutes?: number | null
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "wf_manual_tasks_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "wf_tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      wf_playbook_drift_items: {
        Row: {
          brand_key: string
          created_at: string
          detected_at: string
          drift_type: string
          id: string
          item_key: string
          item_label: string | null
          metadata: Json | null
          notes: string | null
          resolved_at: string | null
          resolved_by: string | null
          status: string
          tenant_id: string
          updated_at: string
        }
        Insert: {
          brand_key: string
          created_at?: string
          detected_at?: string
          drift_type: string
          id?: string
          item_key: string
          item_label?: string | null
          metadata?: Json | null
          notes?: string | null
          resolved_at?: string | null
          resolved_by?: string | null
          status?: string
          tenant_id: string
          updated_at?: string
        }
        Update: {
          brand_key?: string
          created_at?: string
          detected_at?: string
          drift_type?: string
          id?: string
          item_key?: string
          item_label?: string | null
          metadata?: Json | null
          notes?: string | null
          resolved_at?: string | null
          resolved_by?: string | null
          status?: string
          tenant_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "wf_playbook_drift_items_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "wf_tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      wf_playbook_runs: {
        Row: {
          error_message: string | null
          finished_at: string | null
          id: string
          meta: Json
          playbook_id: string
          related_alert_id: string | null
          related_insight_id: string | null
          started_at: string
          status: string
          steps_completed: number
          tenant_id: string
          total_steps: number
          triggered_by_source: string
          triggered_by_user: string | null
        }
        Insert: {
          error_message?: string | null
          finished_at?: string | null
          id?: string
          meta?: Json
          playbook_id: string
          related_alert_id?: string | null
          related_insight_id?: string | null
          started_at?: string
          status?: string
          steps_completed?: number
          tenant_id: string
          total_steps?: number
          triggered_by_source: string
          triggered_by_user?: string | null
        }
        Update: {
          error_message?: string | null
          finished_at?: string | null
          id?: string
          meta?: Json
          playbook_id?: string
          related_alert_id?: string | null
          related_insight_id?: string | null
          started_at?: string
          status?: string
          steps_completed?: number
          tenant_id?: string
          total_steps?: number
          triggered_by_source?: string
          triggered_by_user?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "wf_playbook_runs_playbook_id_fkey"
            columns: ["playbook_id"]
            isOneToOne: false
            referencedRelation: "wf_playbooks"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "wf_playbook_runs_related_alert_id_fkey"
            columns: ["related_alert_id"]
            isOneToOne: false
            referencedRelation: "wf_alert_events"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "wf_playbook_runs_related_insight_id_fkey"
            columns: ["related_insight_id"]
            isOneToOne: false
            referencedRelation: "wf_insights"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "wf_playbook_runs_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "wf_tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      wf_playbook_steps: {
        Row: {
          config: Json
          created_at: string
          description: string | null
          id: string
          meta: Json
          order_index: number
          playbook_id: string
          step_type: string
          tenant_id: string
          title: string
        }
        Insert: {
          config?: Json
          created_at?: string
          description?: string | null
          id?: string
          meta?: Json
          order_index: number
          playbook_id: string
          step_type: string
          tenant_id: string
          title: string
        }
        Update: {
          config?: Json
          created_at?: string
          description?: string | null
          id?: string
          meta?: Json
          order_index?: number
          playbook_id?: string
          step_type?: string
          tenant_id?: string
          title?: string
        }
        Relationships: [
          {
            foreignKeyName: "wf_playbook_steps_playbook_id_fkey"
            columns: ["playbook_id"]
            isOneToOne: false
            referencedRelation: "wf_playbooks"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "wf_playbook_steps_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "wf_tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      wf_playbook_triggers: {
        Row: {
          auto_run: boolean
          conditions: Json
          created_at: string
          id: string
          match_category: string | null
          match_type: string | null
          meta: Json
          min_severity: string | null
          playbook_id: string
          source_type: string
          tenant_id: string
        }
        Insert: {
          auto_run?: boolean
          conditions?: Json
          created_at?: string
          id?: string
          match_category?: string | null
          match_type?: string | null
          meta?: Json
          min_severity?: string | null
          playbook_id: string
          source_type: string
          tenant_id: string
        }
        Update: {
          auto_run?: boolean
          conditions?: Json
          created_at?: string
          id?: string
          match_category?: string | null
          match_type?: string | null
          meta?: Json
          min_severity?: string | null
          playbook_id?: string
          source_type?: string
          tenant_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "wf_playbook_triggers_playbook_id_fkey"
            columns: ["playbook_id"]
            isOneToOne: false
            referencedRelation: "wf_playbooks"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "wf_playbook_triggers_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "wf_tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      wf_playbooks: {
        Row: {
          created_at: string
          created_by: string | null
          description: string | null
          enabled: boolean
          id: string
          meta: Json
          name: string
          scope: string
          slug: string
          tenant_id: string
          trigger_mode: string
          updated_at: string
          updated_by: string | null
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          description?: string | null
          enabled?: boolean
          id?: string
          meta?: Json
          name: string
          scope?: string
          slug: string
          tenant_id: string
          trigger_mode?: string
          updated_at?: string
          updated_by?: string | null
        }
        Update: {
          created_at?: string
          created_by?: string | null
          description?: string | null
          enabled?: boolean
          id?: string
          meta?: Json
          name?: string
          scope?: string
          slug?: string
          tenant_id?: string
          trigger_mode?: string
          updated_at?: string
          updated_by?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "wf_playbooks_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "wf_tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      wf_suggestions: {
        Row: {
          application_id: string | null
          auto_apply: boolean | null
          body: string | null
          category: string
          collection_case_id: string | null
          created_at: string
          credit_case_id: string | null
          deal_id: string | null
          id: string
          role: string | null
          scope: string
          severity: string | null
          status: string
          suggested_value: Json | null
          task_id: string | null
          tenant_id: string | null
          title: string
          updated_at: string
          user_id: string | null
        }
        Insert: {
          application_id?: string | null
          auto_apply?: boolean | null
          body?: string | null
          category: string
          collection_case_id?: string | null
          created_at?: string
          credit_case_id?: string | null
          deal_id?: string | null
          id?: string
          role?: string | null
          scope: string
          severity?: string | null
          status?: string
          suggested_value?: Json | null
          task_id?: string | null
          tenant_id?: string | null
          title: string
          updated_at?: string
          user_id?: string | null
        }
        Update: {
          application_id?: string | null
          auto_apply?: boolean | null
          body?: string | null
          category?: string
          collection_case_id?: string | null
          created_at?: string
          credit_case_id?: string | null
          deal_id?: string | null
          id?: string
          role?: string | null
          scope?: string
          severity?: string | null
          status?: string
          suggested_value?: Json | null
          task_id?: string | null
          tenant_id?: string | null
          title?: string
          updated_at?: string
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "wf_suggestions_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "wf_tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      wf_tasks: {
        Row: {
          assigned_to: string | null
          auto_generated: boolean
          case_id: string | null
          completed_at: string | null
          created_at: string
          created_by: string | null
          description: string | null
          due_date: string | null
          id: string
          lead_id: string | null
          meta: Json
          priority: string
          source: string
          status: string
          task_type: string
          tenant_id: string
          title: string
          updated_at: string
        }
        Insert: {
          assigned_to?: string | null
          auto_generated?: boolean
          case_id?: string | null
          completed_at?: string | null
          created_at?: string
          created_by?: string | null
          description?: string | null
          due_date?: string | null
          id?: string
          lead_id?: string | null
          meta?: Json
          priority?: string
          source?: string
          status?: string
          task_type: string
          tenant_id: string
          title: string
          updated_at?: string
        }
        Update: {
          assigned_to?: string | null
          auto_generated?: boolean
          case_id?: string | null
          completed_at?: string | null
          created_at?: string
          created_by?: string | null
          description?: string | null
          due_date?: string | null
          id?: string
          lead_id?: string | null
          meta?: Json
          priority?: string
          source?: string
          status?: string
          task_type?: string
          tenant_id?: string
          title?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "wf_tasks_case_id_fkey"
            columns: ["case_id"]
            isOneToOne: false
            referencedRelation: "credit_cases_v2"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "wf_tasks_lead_id_fkey"
            columns: ["lead_id"]
            isOneToOne: false
            referencedRelation: "wf_leads"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "wf_tasks_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "wf_tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      wf_tenant_billing_state: {
        Row: {
          billing_email: string | null
          billing_status: string | null
          created_at: string
          current_period_end: string | null
          current_period_start: string | null
          id: string
          meta: Json | null
          plan_id: string | null
          stripe_customer_id: string | null
          tenant_id: string
          updated_at: string
        }
        Insert: {
          billing_email?: string | null
          billing_status?: string | null
          created_at?: string
          current_period_end?: string | null
          current_period_start?: string | null
          id?: string
          meta?: Json | null
          plan_id?: string | null
          stripe_customer_id?: string | null
          tenant_id: string
          updated_at?: string
        }
        Update: {
          billing_email?: string | null
          billing_status?: string | null
          created_at?: string
          current_period_end?: string | null
          current_period_start?: string | null
          id?: string
          meta?: Json | null
          plan_id?: string | null
          stripe_customer_id?: string | null
          tenant_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "wf_tenant_billing_state_plan_id_fkey"
            columns: ["plan_id"]
            isOneToOne: false
            referencedRelation: "wf_billing_plans"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "wf_tenant_billing_state_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: true
            referencedRelation: "wf_tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      wf_tenant_users: {
        Row: {
          created_at: string
          id: string
          invited_by: string | null
          is_primary: boolean
          role: string
          tenant_id: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          invited_by?: string | null
          is_primary?: boolean
          role: string
          tenant_id: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          invited_by?: string | null
          is_primary?: boolean
          role?: string
          tenant_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "wf_tenant_users_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "wf_tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      wf_tenants: {
        Row: {
          created_at: string
          id: string
          metadata: Json
          name: string
          slug: string
          status: string
          super_owner_id: string | null
          updated_at: string
        }
        Insert: {
          created_at?: string
          id?: string
          metadata?: Json
          name: string
          slug: string
          status?: string
          super_owner_id?: string | null
          updated_at?: string
        }
        Update: {
          created_at?: string
          id?: string
          metadata?: Json
          name?: string
          slug?: string
          status?: string
          super_owner_id?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      wf_usage_events: {
        Row: {
          brand_key: string | null
          case_id: string | null
          created_at: string
          event_type: string
          id: string
          idempotency_key: string | null
          iso_id: string | null
          lead_id: string | null
          meta: Json | null
          tenant_id: string | null
        }
        Insert: {
          brand_key?: string | null
          case_id?: string | null
          created_at?: string
          event_type: string
          id?: string
          idempotency_key?: string | null
          iso_id?: string | null
          lead_id?: string | null
          meta?: Json | null
          tenant_id?: string | null
        }
        Update: {
          brand_key?: string | null
          case_id?: string | null
          created_at?: string
          event_type?: string
          id?: string
          idempotency_key?: string | null
          iso_id?: string | null
          lead_id?: string | null
          meta?: Json | null
          tenant_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "wf_usage_events_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "wf_tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      wf_worker_tags: {
        Row: {
          id: string
          last_updated_at: string
          meta: Json
          score: number
          tag: string
          tenant_id: string
          user_id: string
        }
        Insert: {
          id?: string
          last_updated_at?: string
          meta?: Json
          score?: number
          tag: string
          tenant_id: string
          user_id: string
        }
        Update: {
          id?: string
          last_updated_at?: string
          meta?: Json
          score?: number
          tag?: string
          tenant_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "wf_worker_tags_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "wf_tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      wolf_ai_limits: {
        Row: {
          created_at: string
          current_daily_calls: number
          description: string | null
          feature_key: string
          force_template_mode: boolean
          id: string
          is_enabled: boolean
          last_reset_at: string | null
          max_daily_calls: number | null
          provider_override: string | null
          updated_at: string
        }
        Insert: {
          created_at?: string
          current_daily_calls?: number
          description?: string | null
          feature_key: string
          force_template_mode?: boolean
          id?: string
          is_enabled?: boolean
          last_reset_at?: string | null
          max_daily_calls?: number | null
          provider_override?: string | null
          updated_at?: string
        }
        Update: {
          created_at?: string
          current_daily_calls?: number
          description?: string | null
          feature_key?: string
          force_template_mode?: boolean
          id?: string
          is_enabled?: boolean
          last_reset_at?: string | null
          max_daily_calls?: number | null
          provider_override?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      wolf_credit_cases: {
        Row: {
          created_at: string
          deal_id: string | null
          deal_room_id: string | null
          engine_version: string
          id: string
          meta: Json | null
          notes: string | null
          plan: Json | null
          routing_trigger: string | null
          run_by_id: string | null
          run_by_type: string
          run_source: string
          run_ts: string
          snapshot_id: string | null
          status: string
          strategy: string | null
          updated_at: string
          vault_id: string | null
        }
        Insert: {
          created_at?: string
          deal_id?: string | null
          deal_room_id?: string | null
          engine_version?: string
          id?: string
          meta?: Json | null
          notes?: string | null
          plan?: Json | null
          routing_trigger?: string | null
          run_by_id?: string | null
          run_by_type: string
          run_source: string
          run_ts?: string
          snapshot_id?: string | null
          status?: string
          strategy?: string | null
          updated_at?: string
          vault_id?: string | null
        }
        Update: {
          created_at?: string
          deal_id?: string | null
          deal_room_id?: string | null
          engine_version?: string
          id?: string
          meta?: Json | null
          notes?: string | null
          plan?: Json | null
          routing_trigger?: string | null
          run_by_id?: string | null
          run_by_type?: string
          run_source?: string
          run_ts?: string
          snapshot_id?: string | null
          status?: string
          strategy?: string | null
          updated_at?: string
          vault_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "wolf_credit_cases_snapshot_id_fkey"
            columns: ["snapshot_id"]
            isOneToOne: false
            referencedRelation: "wolf_input_snapshots"
            referencedColumns: ["id"]
          },
        ]
      }
      wolf_devices: {
        Row: {
          device_fingerprint: string
          failed_attempts: number
          first_seen_at: string
          id: string
          ip_hash: string | null
          last_seen_at: string
          meta: Json | null
          trust_level: string
          user_agent: string | null
          user_id: string
        }
        Insert: {
          device_fingerprint: string
          failed_attempts?: number
          first_seen_at?: string
          id?: string
          ip_hash?: string | null
          last_seen_at?: string
          meta?: Json | null
          trust_level?: string
          user_agent?: string | null
          user_id: string
        }
        Update: {
          device_fingerprint?: string
          failed_attempts?: number
          first_seen_at?: string
          id?: string
          ip_hash?: string | null
          last_seen_at?: string
          meta?: Json | null
          trust_level?: string
          user_agent?: string | null
          user_id?: string
        }
        Relationships: []
      }
      wolf_documents: {
        Row: {
          category: string
          created_at: string
          description: string | null
          file_name: string
          file_type: string
          id: string
          is_active: boolean
          is_template: boolean
          storage_path: string
          tags: string[] | null
          updated_at: string
          uploaded_by: string | null
        }
        Insert: {
          category?: string
          created_at?: string
          description?: string | null
          file_name: string
          file_type?: string
          id?: string
          is_active?: boolean
          is_template?: boolean
          storage_path: string
          tags?: string[] | null
          updated_at?: string
          uploaded_by?: string | null
        }
        Update: {
          category?: string
          created_at?: string
          description?: string | null
          file_name?: string
          file_type?: string
          id?: string
          is_active?: boolean
          is_template?: boolean
          storage_path?: string
          tags?: string[] | null
          updated_at?: string
          uploaded_by?: string | null
        }
        Relationships: []
      }
      wolf_events: {
        Row: {
          actor_email: string | null
          actor_id: string | null
          actor_type: string | null
          context_id: string | null
          context_type: string | null
          created_at: string
          event_ts: string
          event_type: string
          id: string
          payload: Json | null
          severity: string
          source: string | null
        }
        Insert: {
          actor_email?: string | null
          actor_id?: string | null
          actor_type?: string | null
          context_id?: string | null
          context_type?: string | null
          created_at?: string
          event_ts?: string
          event_type: string
          id?: string
          payload?: Json | null
          severity?: string
          source?: string | null
        }
        Update: {
          actor_email?: string | null
          actor_id?: string | null
          actor_type?: string | null
          context_id?: string | null
          context_type?: string | null
          created_at?: string
          event_ts?: string
          event_type?: string
          id?: string
          payload?: Json | null
          severity?: string
          source?: string | null
        }
        Relationships: []
      }
      wolf_feature_flags: {
        Row: {
          auto_disabled: boolean | null
          created_at: string | null
          description: string | null
          disabled_at: string | null
          disabled_by: string | null
          disabled_reason: string | null
          feature_key: string
          id: string
          is_enabled: boolean | null
          updated_at: string | null
        }
        Insert: {
          auto_disabled?: boolean | null
          created_at?: string | null
          description?: string | null
          disabled_at?: string | null
          disabled_by?: string | null
          disabled_reason?: string | null
          feature_key: string
          id?: string
          is_enabled?: boolean | null
          updated_at?: string | null
        }
        Update: {
          auto_disabled?: boolean | null
          created_at?: string | null
          description?: string | null
          disabled_at?: string | null
          disabled_by?: string | null
          disabled_reason?: string | null
          feature_key?: string
          id?: string
          is_enabled?: boolean | null
          updated_at?: string | null
        }
        Relationships: []
      }
      wolf_flow_rules: {
        Row: {
          actions: Json
          conditions: Json
          created_at: string | null
          created_by: string | null
          description: string | null
          id: string
          is_active: boolean | null
          name: string
          priority: number | null
          rule_type: string
          updated_at: string | null
        }
        Insert: {
          actions?: Json
          conditions?: Json
          created_at?: string | null
          created_by?: string | null
          description?: string | null
          id?: string
          is_active?: boolean | null
          name: string
          priority?: number | null
          rule_type: string
          updated_at?: string | null
        }
        Update: {
          actions?: Json
          conditions?: Json
          created_at?: string | null
          created_by?: string | null
          description?: string | null
          id?: string
          is_active?: boolean | null
          name?: string
          priority?: number | null
          rule_type?: string
          updated_at?: string | null
        }
        Relationships: []
      }
      wolf_health_log: {
        Row: {
          component: string
          created_at: string | null
          details: Json | null
          id: string
          message: string
          resolved: boolean | null
          resolved_at: string | null
          resolved_by: string | null
          severity: string
        }
        Insert: {
          component: string
          created_at?: string | null
          details?: Json | null
          id?: string
          message: string
          resolved?: boolean | null
          resolved_at?: string | null
          resolved_by?: string | null
          severity: string
        }
        Update: {
          component?: string
          created_at?: string | null
          details?: Json | null
          id?: string
          message?: string
          resolved?: boolean | null
          resolved_at?: string | null
          resolved_by?: string | null
          severity?: string
        }
        Relationships: []
      }
      wolf_identity_verifications: {
        Row: {
          created_at: string
          evidence: Json | null
          id: string
          provider: string
          status: string
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          evidence?: Json | null
          id?: string
          provider: string
          status: string
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          evidence?: Json | null
          id?: string
          provider?: string
          status?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      wolf_input_snapshots: {
        Row: {
          created_at: string
          deal_id: string | null
          deal_room_id: string | null
          engine_version: string
          id: string
          lead_id: string | null
          snapshot: Json
          vault_id: string | null
        }
        Insert: {
          created_at?: string
          deal_id?: string | null
          deal_room_id?: string | null
          engine_version?: string
          id?: string
          lead_id?: string | null
          snapshot: Json
          vault_id?: string | null
        }
        Update: {
          created_at?: string
          deal_id?: string | null
          deal_room_id?: string | null
          engine_version?: string
          id?: string
          lead_id?: string | null
          snapshot?: Json
          vault_id?: string | null
        }
        Relationships: []
      }
      wolf_legal_scans: {
        Row: {
          clauses_summary: Json | null
          created_at: string
          deal_contract_id: string
          deal_id: string | null
          engine_version: string | null
          file_hash: string | null
          funder_id: string | null
          id: string
          issues: Json | null
          meta: Json | null
          raw_output: Json | null
          recommendations: Json | null
          risk_level: string | null
          risk_score: number | null
          run_by_id: string | null
          run_by_type: string
          run_source: string
          run_ts: string
          status: string
          storage_path: string
          updated_at: string
          vault_id: string | null
        }
        Insert: {
          clauses_summary?: Json | null
          created_at?: string
          deal_contract_id: string
          deal_id?: string | null
          engine_version?: string | null
          file_hash?: string | null
          funder_id?: string | null
          id?: string
          issues?: Json | null
          meta?: Json | null
          raw_output?: Json | null
          recommendations?: Json | null
          risk_level?: string | null
          risk_score?: number | null
          run_by_id?: string | null
          run_by_type: string
          run_source: string
          run_ts?: string
          status?: string
          storage_path: string
          updated_at?: string
          vault_id?: string | null
        }
        Update: {
          clauses_summary?: Json | null
          created_at?: string
          deal_contract_id?: string
          deal_id?: string | null
          engine_version?: string | null
          file_hash?: string | null
          funder_id?: string | null
          id?: string
          issues?: Json | null
          meta?: Json | null
          raw_output?: Json | null
          recommendations?: Json | null
          risk_level?: string | null
          risk_score?: number | null
          run_by_id?: string | null
          run_by_type?: string
          run_source?: string
          run_ts?: string
          status?: string
          storage_path?: string
          updated_at?: string
          vault_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "wolf_legal_scans_funder_id_fkey"
            columns: ["funder_id"]
            isOneToOne: false
            referencedRelation: "funders"
            referencedColumns: ["id"]
          },
        ]
      }
      wolf_master_config: {
        Row: {
          category: string | null
          created_at: string | null
          description: string | null
          id: string
          is_protected: boolean | null
          key: string
          updated_at: string | null
          value: Json
          version: number | null
        }
        Insert: {
          category?: string | null
          created_at?: string | null
          description?: string | null
          id?: string
          is_protected?: boolean | null
          key: string
          updated_at?: string | null
          value?: Json
          version?: number | null
        }
        Update: {
          category?: string | null
          created_at?: string | null
          description?: string | null
          id?: string
          is_protected?: boolean | null
          key?: string
          updated_at?: string | null
          value?: Json
          version?: number | null
        }
        Relationships: []
      }
      wolf_master_config_history: {
        Row: {
          applied_by_id: string | null
          applied_by_type: string
          applied_source: string
          category: string
          change_group_id: string
          comments: string | null
          created_at: string
          id: string
          is_rollback: boolean | null
          key: string
          new_value: Json | null
          old_value: Json | null
          path: string | null
          risk_score: number | null
          rollback_of: string | null
          suggestion_id: string | null
          version_after: number | null
          version_before: number | null
        }
        Insert: {
          applied_by_id?: string | null
          applied_by_type: string
          applied_source: string
          category: string
          change_group_id: string
          comments?: string | null
          created_at?: string
          id?: string
          is_rollback?: boolean | null
          key: string
          new_value?: Json | null
          old_value?: Json | null
          path?: string | null
          risk_score?: number | null
          rollback_of?: string | null
          suggestion_id?: string | null
          version_after?: number | null
          version_before?: number | null
        }
        Update: {
          applied_by_id?: string | null
          applied_by_type?: string
          applied_source?: string
          category?: string
          change_group_id?: string
          comments?: string | null
          created_at?: string
          id?: string
          is_rollback?: boolean | null
          key?: string
          new_value?: Json | null
          old_value?: Json | null
          path?: string | null
          risk_score?: number | null
          rollback_of?: string | null
          suggestion_id?: string | null
          version_after?: number | null
          version_before?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "wolf_master_config_history_rollback_of_fkey"
            columns: ["rollback_of"]
            isOneToOne: false
            referencedRelation: "wolf_master_config_history"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "wolf_master_config_history_suggestion_id_fkey"
            columns: ["suggestion_id"]
            isOneToOne: false
            referencedRelation: "wolf_suggestions"
            referencedColumns: ["id"]
          },
        ]
      }
      wolf_provider_health: {
        Row: {
          avg_latency_ms: number | null
          created_at: string
          error_count_today: number
          id: string
          last_check_at: string | null
          last_error: string | null
          last_success_at: string | null
          provider_key: string
          provider_name: string | null
          status: string
          success_count_today: number
          updated_at: string
        }
        Insert: {
          avg_latency_ms?: number | null
          created_at?: string
          error_count_today?: number
          id?: string
          last_check_at?: string | null
          last_error?: string | null
          last_success_at?: string | null
          provider_key: string
          provider_name?: string | null
          status?: string
          success_count_today?: number
          updated_at?: string
        }
        Update: {
          avg_latency_ms?: number | null
          created_at?: string
          error_count_today?: number
          id?: string
          last_check_at?: string | null
          last_error?: string | null
          last_success_at?: string | null
          provider_key?: string
          provider_name?: string | null
          status?: string
          success_count_today?: number
          updated_at?: string
        }
        Relationships: []
      }
      wolf_screenshot_attempts: {
        Row: {
          attempt_type: string
          created_at: string | null
          id: string
          ip_address: string | null
          page_url: string | null
          session_id: string | null
          user_agent: string | null
          user_id: string | null
        }
        Insert: {
          attempt_type: string
          created_at?: string | null
          id?: string
          ip_address?: string | null
          page_url?: string | null
          session_id?: string | null
          user_agent?: string | null
          user_id?: string | null
        }
        Update: {
          attempt_type?: string
          created_at?: string | null
          id?: string
          ip_address?: string | null
          page_url?: string | null
          session_id?: string | null
          user_agent?: string | null
          user_id?: string | null
        }
        Relationships: []
      }
      wolf_security_correlations: {
        Row: {
          combined_risk_score: number
          created_at: string
          device_id: string | null
          id: string
          ip_hash: string | null
          portal: string | null
          risk_sources: Json
          session_id: string
          user_id: string
        }
        Insert: {
          combined_risk_score?: number
          created_at?: string
          device_id?: string | null
          id?: string
          ip_hash?: string | null
          portal?: string | null
          risk_sources?: Json
          session_id: string
          user_id: string
        }
        Update: {
          combined_risk_score?: number
          created_at?: string
          device_id?: string | null
          id?: string
          ip_hash?: string | null
          portal?: string | null
          risk_sources?: Json
          session_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "wolf_security_correlations_session_id_fkey"
            columns: ["session_id"]
            isOneToOne: false
            referencedRelation: "wolf_sessions"
            referencedColumns: ["id"]
          },
        ]
      }
      wolf_security_events: {
        Row: {
          acknowledged_at: string | null
          acknowledged_by: string | null
          context: Json | null
          created_at: string
          device_id: string | null
          event_ts: string
          event_type: string
          id: string
          ip_hash: string | null
          portal: string | null
          severity: string
          source: string
          user_id: string | null
        }
        Insert: {
          acknowledged_at?: string | null
          acknowledged_by?: string | null
          context?: Json | null
          created_at?: string
          device_id?: string | null
          event_ts?: string
          event_type: string
          id?: string
          ip_hash?: string | null
          portal?: string | null
          severity?: string
          source: string
          user_id?: string | null
        }
        Update: {
          acknowledged_at?: string | null
          acknowledged_by?: string | null
          context?: Json | null
          created_at?: string
          device_id?: string | null
          event_ts?: string
          event_type?: string
          id?: string
          ip_hash?: string | null
          portal?: string | null
          severity?: string
          source?: string
          user_id?: string | null
        }
        Relationships: []
      }
      wolf_session_analytics: {
        Row: {
          created_at: string
          device_id: string | null
          duration_seconds: number | null
          end_time: string | null
          expired: boolean | null
          heartbeat_count: number | null
          id: string
          idle_seconds: number | null
          portal: string
          risk_level: string | null
          session_id: string
          start_time: string
          terminated: boolean | null
          user_id: string
        }
        Insert: {
          created_at?: string
          device_id?: string | null
          duration_seconds?: number | null
          end_time?: string | null
          expired?: boolean | null
          heartbeat_count?: number | null
          id?: string
          idle_seconds?: number | null
          portal: string
          risk_level?: string | null
          session_id: string
          start_time: string
          terminated?: boolean | null
          user_id: string
        }
        Update: {
          created_at?: string
          device_id?: string | null
          duration_seconds?: number | null
          end_time?: string | null
          expired?: boolean | null
          heartbeat_count?: number | null
          id?: string
          idle_seconds?: number | null
          portal?: string
          risk_level?: string | null
          session_id?: string
          start_time?: string
          terminated?: boolean | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "wolf_session_analytics_session_id_fkey"
            columns: ["session_id"]
            isOneToOne: false
            referencedRelation: "wolf_sessions"
            referencedColumns: ["id"]
          },
        ]
      }
      wolf_session_settings: {
        Row: {
          description: string | null
          id: string
          setting_key: string
          setting_value: Json
          updated_at: string
          updated_by: string | null
        }
        Insert: {
          description?: string | null
          id?: string
          setting_key: string
          setting_value: Json
          updated_at?: string
          updated_by?: string | null
        }
        Update: {
          description?: string | null
          id?: string
          setting_key?: string
          setting_value?: Json
          updated_at?: string
          updated_by?: string | null
        }
        Relationships: []
      }
      wolf_sessions: {
        Row: {
          cleanup_tag: string | null
          created_at: string
          device_fingerprint: string | null
          device_id: string | null
          expires_at: string | null
          geo_lat: number | null
          geo_lon: number | null
          id: string
          impossible_travel_flag: boolean | null
          ip_hash: string | null
          last_known_country: string | null
          last_seen_at: string
          meta: Json | null
          portal: string
          risk_score: number | null
          started_at: string
          status: string
          terminated_at: string | null
          terminated_by: string | null
          terminated_reason: string | null
          user_agent: string | null
          user_email: string | null
          user_id: string
        }
        Insert: {
          cleanup_tag?: string | null
          created_at?: string
          device_fingerprint?: string | null
          device_id?: string | null
          expires_at?: string | null
          geo_lat?: number | null
          geo_lon?: number | null
          id?: string
          impossible_travel_flag?: boolean | null
          ip_hash?: string | null
          last_known_country?: string | null
          last_seen_at?: string
          meta?: Json | null
          portal: string
          risk_score?: number | null
          started_at?: string
          status?: string
          terminated_at?: string | null
          terminated_by?: string | null
          terminated_reason?: string | null
          user_agent?: string | null
          user_email?: string | null
          user_id: string
        }
        Update: {
          cleanup_tag?: string | null
          created_at?: string
          device_fingerprint?: string | null
          device_id?: string | null
          expires_at?: string | null
          geo_lat?: number | null
          geo_lon?: number | null
          id?: string
          impossible_travel_flag?: boolean | null
          ip_hash?: string | null
          last_known_country?: string | null
          last_seen_at?: string
          meta?: Json | null
          portal?: string
          risk_score?: number | null
          started_at?: string
          status?: string
          terminated_at?: string | null
          terminated_by?: string | null
          terminated_reason?: string | null
          user_agent?: string | null
          user_email?: string | null
          user_id?: string
        }
        Relationships: []
      }
      wolf_suggestions: {
        Row: {
          applied_change_group_id: string | null
          auto_apply: boolean
          created_at: string
          created_by: string | null
          current_value: Json | null
          decided_at: string | null
          decided_by: string | null
          id: string
          meta: Json | null
          reason: string | null
          risk_score: number
          status: string
          suggested_value: Json
          target: string
          type: string
        }
        Insert: {
          applied_change_group_id?: string | null
          auto_apply?: boolean
          created_at?: string
          created_by?: string | null
          current_value?: Json | null
          decided_at?: string | null
          decided_by?: string | null
          id?: string
          meta?: Json | null
          reason?: string | null
          risk_score?: number
          status?: string
          suggested_value: Json
          target: string
          type: string
        }
        Update: {
          applied_change_group_id?: string | null
          auto_apply?: boolean
          created_at?: string
          created_by?: string | null
          current_value?: Json | null
          decided_at?: string | null
          decided_by?: string | null
          id?: string
          meta?: Json | null
          reason?: string | null
          risk_score?: number
          status?: string
          suggested_value?: Json
          target?: string
          type?: string
        }
        Relationships: []
      }
      wolf_underwriting_cases: {
        Row: {
          config_snapshot: Json | null
          created_at: string
          deal_id: string
          deal_room_id: string | null
          decision: string | null
          decision_reason: string | null
          engine_version: string | null
          flags: Json | null
          funder_id: string | null
          id: string
          input_snapshot: Json
          meta: Json | null
          recommended_funders: Json | null
          recommended_products: Json | null
          risk_buckets: Json | null
          risk_score: number | null
          run_by_id: string | null
          run_by_type: string
          run_source: string
          run_ts: string
          snapshot_id: string | null
          status: string
          updated_at: string
          vault_id: string | null
        }
        Insert: {
          config_snapshot?: Json | null
          created_at?: string
          deal_id: string
          deal_room_id?: string | null
          decision?: string | null
          decision_reason?: string | null
          engine_version?: string | null
          flags?: Json | null
          funder_id?: string | null
          id?: string
          input_snapshot?: Json
          meta?: Json | null
          recommended_funders?: Json | null
          recommended_products?: Json | null
          risk_buckets?: Json | null
          risk_score?: number | null
          run_by_id?: string | null
          run_by_type: string
          run_source: string
          run_ts?: string
          snapshot_id?: string | null
          status?: string
          updated_at?: string
          vault_id?: string | null
        }
        Update: {
          config_snapshot?: Json | null
          created_at?: string
          deal_id?: string
          deal_room_id?: string | null
          decision?: string | null
          decision_reason?: string | null
          engine_version?: string | null
          flags?: Json | null
          funder_id?: string | null
          id?: string
          input_snapshot?: Json
          meta?: Json | null
          recommended_funders?: Json | null
          recommended_products?: Json | null
          risk_buckets?: Json | null
          risk_score?: number | null
          run_by_id?: string | null
          run_by_type?: string
          run_source?: string
          run_ts?: string
          snapshot_id?: string | null
          status?: string
          updated_at?: string
          vault_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "wolf_underwriting_cases_deal_room_id_fkey"
            columns: ["deal_room_id"]
            isOneToOne: false
            referencedRelation: "deal_rooms"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "wolf_underwriting_cases_funder_id_fkey"
            columns: ["funder_id"]
            isOneToOne: false
            referencedRelation: "funders"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "wolf_underwriting_cases_snapshot_id_fkey"
            columns: ["snapshot_id"]
            isOneToOne: false
            referencedRelation: "wolf_input_snapshots"
            referencedColumns: ["id"]
          },
        ]
      }
      worker_activity_logs: {
        Row: {
          action_description: string
          activity_type: string
          approval_status: string | null
          approved_at: string | null
          approved_by: string | null
          created_at: string | null
          id: string
          lead_id: string | null
          metadata: Json | null
          worker_id: string
          worker_type: string | null
        }
        Insert: {
          action_description: string
          activity_type: string
          approval_status?: string | null
          approved_at?: string | null
          approved_by?: string | null
          created_at?: string | null
          id?: string
          lead_id?: string | null
          metadata?: Json | null
          worker_id: string
          worker_type?: string | null
        }
        Update: {
          action_description?: string
          activity_type?: string
          approval_status?: string | null
          approved_at?: string | null
          approved_by?: string | null
          created_at?: string | null
          id?: string
          lead_id?: string | null
          metadata?: Json | null
          worker_id?: string
          worker_type?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "worker_activity_logs_lead_id_fkey"
            columns: ["lead_id"]
            isOneToOne: false
            referencedRelation: "lead_assignments"
            referencedColumns: ["id"]
          },
        ]
      }
      worker_applications: {
        Row: {
          address: string | null
          created_at: string | null
          email: string
          employer_type: string
          full_name: string
          id: string
          invite_code: string | null
          monthly_deals_closed: string | null
          notes: string | null
          origin_source: string | null
          partner_id: string | null
          phone: string | null
          previous_companies: string | null
          referral_code: string | null
          resume_url: string | null
          reviewed_at: string | null
          reviewed_by: string | null
          specialization: string[] | null
          status: string | null
          tenant_id: string | null
          updated_at: string | null
          user_id: string | null
          years_experience: string | null
        }
        Insert: {
          address?: string | null
          created_at?: string | null
          email: string
          employer_type: string
          full_name: string
          id?: string
          invite_code?: string | null
          monthly_deals_closed?: string | null
          notes?: string | null
          origin_source?: string | null
          partner_id?: string | null
          phone?: string | null
          previous_companies?: string | null
          referral_code?: string | null
          resume_url?: string | null
          reviewed_at?: string | null
          reviewed_by?: string | null
          specialization?: string[] | null
          status?: string | null
          tenant_id?: string | null
          updated_at?: string | null
          user_id?: string | null
          years_experience?: string | null
        }
        Update: {
          address?: string | null
          created_at?: string | null
          email?: string
          employer_type?: string
          full_name?: string
          id?: string
          invite_code?: string | null
          monthly_deals_closed?: string | null
          notes?: string | null
          origin_source?: string | null
          partner_id?: string | null
          phone?: string | null
          previous_companies?: string | null
          referral_code?: string | null
          resume_url?: string | null
          reviewed_at?: string | null
          reviewed_by?: string | null
          specialization?: string[] | null
          status?: string | null
          tenant_id?: string | null
          updated_at?: string | null
          user_id?: string | null
          years_experience?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "worker_applications_partner_id_fkey"
            columns: ["partner_id"]
            isOneToOne: false
            referencedRelation: "partner_applications"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "worker_applications_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "wf_tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      worker_assignments: {
        Row: {
          application_id: string | null
          assigned_by: string | null
          assignment_type: string
          completed_at: string | null
          created_at: string
          due_at: string | null
          id: string
          lead_id: string | null
          notes: string | null
          priority: number | null
          status: string
          updated_at: string
          worker_id: string
        }
        Insert: {
          application_id?: string | null
          assigned_by?: string | null
          assignment_type?: string
          completed_at?: string | null
          created_at?: string
          due_at?: string | null
          id?: string
          lead_id?: string | null
          notes?: string | null
          priority?: number | null
          status?: string
          updated_at?: string
          worker_id: string
        }
        Update: {
          application_id?: string | null
          assigned_by?: string | null
          assignment_type?: string
          completed_at?: string | null
          created_at?: string
          due_at?: string | null
          id?: string
          lead_id?: string | null
          notes?: string | null
          priority?: number | null
          status?: string
          updated_at?: string
          worker_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "worker_assignments_application_id_fkey"
            columns: ["application_id"]
            isOneToOne: false
            referencedRelation: "fast_track_applications"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "worker_assignments_lead_id_fkey"
            columns: ["lead_id"]
            isOneToOne: false
            referencedRelation: "leads"
            referencedColumns: ["id"]
          },
        ]
      }
      worker_commission_splits: {
        Row: {
          created_at: string | null
          id: string
          lead_id: string
          primary_worker_id: string
          secondary_worker_id: string
          split_percentage: number | null
        }
        Insert: {
          created_at?: string | null
          id?: string
          lead_id: string
          primary_worker_id: string
          secondary_worker_id: string
          split_percentage?: number | null
        }
        Update: {
          created_at?: string | null
          id?: string
          lead_id?: string
          primary_worker_id?: string
          secondary_worker_id?: string
          split_percentage?: number | null
        }
        Relationships: []
      }
      workflow_tasks: {
        Row: {
          assigned_to_user_id: string | null
          case_id: string | null
          client_id: string | null
          completed_at: string | null
          created_at: string | null
          created_by: string
          created_by_user_id: string | null
          description: string | null
          due_at: string | null
          id: string
          lead_id: string | null
          meta: Json | null
          priority: string | null
          snoozed_until: string | null
          status: string
          task_type: string
          title: string
          updated_at: string | null
        }
        Insert: {
          assigned_to_user_id?: string | null
          case_id?: string | null
          client_id?: string | null
          completed_at?: string | null
          created_at?: string | null
          created_by?: string
          created_by_user_id?: string | null
          description?: string | null
          due_at?: string | null
          id?: string
          lead_id?: string | null
          meta?: Json | null
          priority?: string | null
          snoozed_until?: string | null
          status?: string
          task_type: string
          title: string
          updated_at?: string | null
        }
        Update: {
          assigned_to_user_id?: string | null
          case_id?: string | null
          client_id?: string | null
          completed_at?: string | null
          created_at?: string | null
          created_by?: string
          created_by_user_id?: string | null
          description?: string | null
          due_at?: string | null
          id?: string
          lead_id?: string | null
          meta?: Json | null
          priority?: string | null
          snoozed_until?: string | null
          status?: string
          task_type?: string
          title?: string
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "workflow_tasks_case_id_fkey"
            columns: ["case_id"]
            isOneToOne: false
            referencedRelation: "underwriting_cases"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Views: {
      funding_records: {
        Row: {
          amount_funded: number | null
          created_at: string | null
          date_funded: string | null
          id: string | null
          lead_id: string | null
          notes: string | null
          product_type: string | null
          underwriting_case_id: string | null
        }
        Insert: {
          amount_funded?: number | null
          created_at?: string | null
          date_funded?: string | null
          id?: string | null
          lead_id?: string | null
          notes?: string | null
          product_type?: string | null
          underwriting_case_id?: string | null
        }
        Update: {
          amount_funded?: number | null
          created_at?: string | null
          date_funded?: string | null
          id?: string | null
          lead_id?: string | null
          notes?: string | null
          product_type?: string | null
          underwriting_case_id?: string | null
        }
        Relationships: []
      }
      lead_share_requests_view: {
        Row: {
          created_at: string | null
          from_user_email: string | null
          from_worker_id: string | null
          id: string | null
          lead: Json | null
          lead_id: string | null
          message: string | null
          responded_at: string | null
          status: string | null
          to_worker_id: string | null
          type: string | null
        }
        Relationships: [
          {
            foreignKeyName: "lead_share_requests_lead_id_fkey"
            columns: ["lead_id"]
            isOneToOne: false
            referencedRelation: "leads"
            referencedColumns: ["id"]
          },
        ]
      }
      tasks: {
        Row: {
          assigned_to: string | null
          created_at: string | null
          due_at: string | null
          id: string | null
          lead_id: string | null
          notes: string | null
          source_table: string | null
          status: string | null
          type: string | null
        }
        Relationships: []
      }
    }
    Functions: {
      can_access_tenant: { Args: { tid: string }; Returns: boolean }
      can_access_vault: { Args: { _user_id: string }; Returns: boolean }
      claim_next_research_lead: {
        Args: { p_worker_id: string }
        Returns: {
          ad_group: string | null
          address: string | null
          ai_last_evaluated_at: string | null
          ai_notes: Json | null
          ai_priority: string | null
          ai_recommended_path: string | null
          ai_risk_flags: Json | null
          ai_score: number | null
          app_sent_at: string | null
          application_status: string | null
          application_url: string | null
          assigned_to: string | null
          assigned_worker_id: string | null
          attempt_count: number | null
          attempt_history: Json | null
          bucket: string | null
          business_age_years: number | null
          business_name: string | null
          business_start_date: string | null
          business_type: string | null
          call_attempts: number
          campaign: string | null
          city: string | null
          created_at: string | null
          creative_id: string | null
          credit_fix_status: string | null
          credit_fix_worker_id: string | null
          credit_indicators: Json | null
          credit_risk: string | null
          current_owner_email: string | null
          current_owner_id: string | null
          defaults_flag: boolean | null
          dial_attempts: number | null
          dialer_status: string
          domain_age_years: number | null
          eco_mode: boolean | null
          ein: string | null
          email: string | null
          email_attempts: number | null
          email_invalid: boolean | null
          email_status: string | null
          email_template_used: string | null
          email_valid: boolean | null
          enriched_address: string | null
          enriched_business_age_years: number | null
          enriched_business_name: string | null
          enriched_city: string | null
          enriched_email: string | null
          enriched_industry: string | null
          enriched_name: string | null
          enriched_online_presence_score: number | null
          enriched_phone: string | null
          enriched_revenue_estimate: number | null
          enriched_state: string | null
          enriched_zip: string | null
          enrichment_completed: boolean | null
          enrichment_date: string | null
          est_credit_score: number | null
          estimated_employees: number | null
          estimated_monthly_revenue: number | null
          estimated_revenue: number | null
          file_age_code: string | null
          first_name: string | null
          follow_up_at: string | null
          full_name: string | null
          funded_at: string | null
          funding_recommendation: string | null
          funding_score: number | null
          google_rating: number | null
          has_social_media: boolean | null
          id: string
          identity_theft_risk: string | null
          import_bucket: string | null
          import_confidence_score: number | null
          industry_risk: string | null
          interested_at: string | null
          last_application_sent_at: string | null
          last_attempt_at: string | null
          last_call_at: string | null
          last_call_outcome: string | null
          last_called_at: string | null
          last_called_by: string | null
          last_dial_disposition: string | null
          last_email_event: string | null
          last_emailed_at: string | null
          last_name: string | null
          lead_list_id: string | null
          lead_type: string | null
          linkedin_url: string | null
          list_id: string | null
          lock_expires_at: string | null
          lock_reason: string | null
          lock_started_at: string | null
          locked_by: string | null
          locked_by_email: string | null
          locked_by_worker_email: string | null
          locked_by_worker_id: string | null
          locked_until: string | null
          missing_email: boolean | null
          missing_phone: boolean | null
          mystic_tips: Json | null
          naics_code: string | null
          need_type: string | null
          new_phone: string | null
          next_attempt_at: string | null
          normalized_fields: Json | null
          notes: string | null
          ocm_county: string | null
          ocm_expiration_date: string | null
          ocm_intel: Json | null
          ocm_license_id: string | null
          ocm_license_type: string | null
          ocm_municipality: string | null
          ocm_status: string | null
          outcome: string | null
          owner_birth_date: string | null
          owner_first_name: string | null
          owner_id: string | null
          owner_last_name: string | null
          owner_name: string | null
          owner_worker_id: string | null
          phone: string | null
          phone_carrier: string | null
          phone_invalid: boolean | null
          phone_line_type: string | null
          phone_valid: boolean | null
          postal_code: string | null
          priority_score: number | null
          problem_flags: string[] | null
          raw_data: Json | null
          requested_amount: number | null
          research_assigned_to: string | null
          research_attempts: number | null
          research_completed_at: string | null
          research_last_action_at: string | null
          research_last_run_at: string | null
          research_notes: string | null
          research_owner_id: string | null
          research_started_at: string | null
          research_status: string | null
          route: string | null
          secondary_worker_id: string | null
          sic_code: string | null
          source: string | null
          source_file_name: string | null
          source_folder_name: string | null
          source_id: string | null
          source_list_name: string | null
          source_platform_label: string | null
          ssn_masked: string | null
          state: string | null
          status: string
          updated_at: string | null
          website: string | null
          wolf_folder_label: string | null
          zip: string | null
        }
        SetofOptions: {
          from: "*"
          to: "leads"
          isOneToOne: true
          isSetofReturn: false
        }
      }
      complete_funding_call: {
        Args: { p_case_id: string; p_notes: string; p_status: string }
        Returns: undefined
      }
      get_lead_lock_state: { Args: { p_lead_id: string }; Returns: Json }
      get_next_dialer_lead: {
        Args: { p_user_id: string }
        Returns: {
          ad_group: string | null
          address: string | null
          ai_last_evaluated_at: string | null
          ai_notes: Json | null
          ai_priority: string | null
          ai_recommended_path: string | null
          ai_risk_flags: Json | null
          ai_score: number | null
          app_sent_at: string | null
          application_status: string | null
          application_url: string | null
          assigned_to: string | null
          assigned_worker_id: string | null
          attempt_count: number | null
          attempt_history: Json | null
          bucket: string | null
          business_age_years: number | null
          business_name: string | null
          business_start_date: string | null
          business_type: string | null
          call_attempts: number
          campaign: string | null
          city: string | null
          created_at: string | null
          creative_id: string | null
          credit_fix_status: string | null
          credit_fix_worker_id: string | null
          credit_indicators: Json | null
          credit_risk: string | null
          current_owner_email: string | null
          current_owner_id: string | null
          defaults_flag: boolean | null
          dial_attempts: number | null
          dialer_status: string
          domain_age_years: number | null
          eco_mode: boolean | null
          ein: string | null
          email: string | null
          email_attempts: number | null
          email_invalid: boolean | null
          email_status: string | null
          email_template_used: string | null
          email_valid: boolean | null
          enriched_address: string | null
          enriched_business_age_years: number | null
          enriched_business_name: string | null
          enriched_city: string | null
          enriched_email: string | null
          enriched_industry: string | null
          enriched_name: string | null
          enriched_online_presence_score: number | null
          enriched_phone: string | null
          enriched_revenue_estimate: number | null
          enriched_state: string | null
          enriched_zip: string | null
          enrichment_completed: boolean | null
          enrichment_date: string | null
          est_credit_score: number | null
          estimated_employees: number | null
          estimated_monthly_revenue: number | null
          estimated_revenue: number | null
          file_age_code: string | null
          first_name: string | null
          follow_up_at: string | null
          full_name: string | null
          funded_at: string | null
          funding_recommendation: string | null
          funding_score: number | null
          google_rating: number | null
          has_social_media: boolean | null
          id: string
          identity_theft_risk: string | null
          import_bucket: string | null
          import_confidence_score: number | null
          industry_risk: string | null
          interested_at: string | null
          last_application_sent_at: string | null
          last_attempt_at: string | null
          last_call_at: string | null
          last_call_outcome: string | null
          last_called_at: string | null
          last_called_by: string | null
          last_dial_disposition: string | null
          last_email_event: string | null
          last_emailed_at: string | null
          last_name: string | null
          lead_list_id: string | null
          lead_type: string | null
          linkedin_url: string | null
          list_id: string | null
          lock_expires_at: string | null
          lock_reason: string | null
          lock_started_at: string | null
          locked_by: string | null
          locked_by_email: string | null
          locked_by_worker_email: string | null
          locked_by_worker_id: string | null
          locked_until: string | null
          missing_email: boolean | null
          missing_phone: boolean | null
          mystic_tips: Json | null
          naics_code: string | null
          need_type: string | null
          new_phone: string | null
          next_attempt_at: string | null
          normalized_fields: Json | null
          notes: string | null
          ocm_county: string | null
          ocm_expiration_date: string | null
          ocm_intel: Json | null
          ocm_license_id: string | null
          ocm_license_type: string | null
          ocm_municipality: string | null
          ocm_status: string | null
          outcome: string | null
          owner_birth_date: string | null
          owner_first_name: string | null
          owner_id: string | null
          owner_last_name: string | null
          owner_name: string | null
          owner_worker_id: string | null
          phone: string | null
          phone_carrier: string | null
          phone_invalid: boolean | null
          phone_line_type: string | null
          phone_valid: boolean | null
          postal_code: string | null
          priority_score: number | null
          problem_flags: string[] | null
          raw_data: Json | null
          requested_amount: number | null
          research_assigned_to: string | null
          research_attempts: number | null
          research_completed_at: string | null
          research_last_action_at: string | null
          research_last_run_at: string | null
          research_notes: string | null
          research_owner_id: string | null
          research_started_at: string | null
          research_status: string | null
          route: string | null
          secondary_worker_id: string | null
          sic_code: string | null
          source: string | null
          source_file_name: string | null
          source_folder_name: string | null
          source_id: string | null
          source_list_name: string | null
          source_platform_label: string | null
          ssn_masked: string | null
          state: string | null
          status: string
          updated_at: string | null
          website: string | null
          wolf_folder_label: string | null
          zip: string | null
        }
        SetofOptions: {
          from: "*"
          to: "leads"
          isOneToOne: true
          isSetofReturn: false
        }
      }
      get_next_email_lead: {
        Args: { p_user_id: string }
        Returns: {
          ad_group: string | null
          address: string | null
          ai_last_evaluated_at: string | null
          ai_notes: Json | null
          ai_priority: string | null
          ai_recommended_path: string | null
          ai_risk_flags: Json | null
          ai_score: number | null
          app_sent_at: string | null
          application_status: string | null
          application_url: string | null
          assigned_to: string | null
          assigned_worker_id: string | null
          attempt_count: number | null
          attempt_history: Json | null
          bucket: string | null
          business_age_years: number | null
          business_name: string | null
          business_start_date: string | null
          business_type: string | null
          call_attempts: number
          campaign: string | null
          city: string | null
          created_at: string | null
          creative_id: string | null
          credit_fix_status: string | null
          credit_fix_worker_id: string | null
          credit_indicators: Json | null
          credit_risk: string | null
          current_owner_email: string | null
          current_owner_id: string | null
          defaults_flag: boolean | null
          dial_attempts: number | null
          dialer_status: string
          domain_age_years: number | null
          eco_mode: boolean | null
          ein: string | null
          email: string | null
          email_attempts: number | null
          email_invalid: boolean | null
          email_status: string | null
          email_template_used: string | null
          email_valid: boolean | null
          enriched_address: string | null
          enriched_business_age_years: number | null
          enriched_business_name: string | null
          enriched_city: string | null
          enriched_email: string | null
          enriched_industry: string | null
          enriched_name: string | null
          enriched_online_presence_score: number | null
          enriched_phone: string | null
          enriched_revenue_estimate: number | null
          enriched_state: string | null
          enriched_zip: string | null
          enrichment_completed: boolean | null
          enrichment_date: string | null
          est_credit_score: number | null
          estimated_employees: number | null
          estimated_monthly_revenue: number | null
          estimated_revenue: number | null
          file_age_code: string | null
          first_name: string | null
          follow_up_at: string | null
          full_name: string | null
          funded_at: string | null
          funding_recommendation: string | null
          funding_score: number | null
          google_rating: number | null
          has_social_media: boolean | null
          id: string
          identity_theft_risk: string | null
          import_bucket: string | null
          import_confidence_score: number | null
          industry_risk: string | null
          interested_at: string | null
          last_application_sent_at: string | null
          last_attempt_at: string | null
          last_call_at: string | null
          last_call_outcome: string | null
          last_called_at: string | null
          last_called_by: string | null
          last_dial_disposition: string | null
          last_email_event: string | null
          last_emailed_at: string | null
          last_name: string | null
          lead_list_id: string | null
          lead_type: string | null
          linkedin_url: string | null
          list_id: string | null
          lock_expires_at: string | null
          lock_reason: string | null
          lock_started_at: string | null
          locked_by: string | null
          locked_by_email: string | null
          locked_by_worker_email: string | null
          locked_by_worker_id: string | null
          locked_until: string | null
          missing_email: boolean | null
          missing_phone: boolean | null
          mystic_tips: Json | null
          naics_code: string | null
          need_type: string | null
          new_phone: string | null
          next_attempt_at: string | null
          normalized_fields: Json | null
          notes: string | null
          ocm_county: string | null
          ocm_expiration_date: string | null
          ocm_intel: Json | null
          ocm_license_id: string | null
          ocm_license_type: string | null
          ocm_municipality: string | null
          ocm_status: string | null
          outcome: string | null
          owner_birth_date: string | null
          owner_first_name: string | null
          owner_id: string | null
          owner_last_name: string | null
          owner_name: string | null
          owner_worker_id: string | null
          phone: string | null
          phone_carrier: string | null
          phone_invalid: boolean | null
          phone_line_type: string | null
          phone_valid: boolean | null
          postal_code: string | null
          priority_score: number | null
          problem_flags: string[] | null
          raw_data: Json | null
          requested_amount: number | null
          research_assigned_to: string | null
          research_attempts: number | null
          research_completed_at: string | null
          research_last_action_at: string | null
          research_last_run_at: string | null
          research_notes: string | null
          research_owner_id: string | null
          research_started_at: string | null
          research_status: string | null
          route: string | null
          secondary_worker_id: string | null
          sic_code: string | null
          source: string | null
          source_file_name: string | null
          source_folder_name: string | null
          source_id: string | null
          source_list_name: string | null
          source_platform_label: string | null
          ssn_masked: string | null
          state: string | null
          status: string
          updated_at: string | null
          website: string | null
          wolf_folder_label: string | null
          zip: string | null
        }
        SetofOptions: {
          from: "*"
          to: "leads"
          isOneToOne: true
          isSetofReturn: false
        }
      }
      get_next_lead: {
        Args: { p_worker_id: string }
        Returns: {
          ad_group: string | null
          address: string | null
          ai_last_evaluated_at: string | null
          ai_notes: Json | null
          ai_priority: string | null
          ai_recommended_path: string | null
          ai_risk_flags: Json | null
          ai_score: number | null
          app_sent_at: string | null
          application_status: string | null
          application_url: string | null
          assigned_to: string | null
          assigned_worker_id: string | null
          attempt_count: number | null
          attempt_history: Json | null
          bucket: string | null
          business_age_years: number | null
          business_name: string | null
          business_start_date: string | null
          business_type: string | null
          call_attempts: number
          campaign: string | null
          city: string | null
          created_at: string | null
          creative_id: string | null
          credit_fix_status: string | null
          credit_fix_worker_id: string | null
          credit_indicators: Json | null
          credit_risk: string | null
          current_owner_email: string | null
          current_owner_id: string | null
          defaults_flag: boolean | null
          dial_attempts: number | null
          dialer_status: string
          domain_age_years: number | null
          eco_mode: boolean | null
          ein: string | null
          email: string | null
          email_attempts: number | null
          email_invalid: boolean | null
          email_status: string | null
          email_template_used: string | null
          email_valid: boolean | null
          enriched_address: string | null
          enriched_business_age_years: number | null
          enriched_business_name: string | null
          enriched_city: string | null
          enriched_email: string | null
          enriched_industry: string | null
          enriched_name: string | null
          enriched_online_presence_score: number | null
          enriched_phone: string | null
          enriched_revenue_estimate: number | null
          enriched_state: string | null
          enriched_zip: string | null
          enrichment_completed: boolean | null
          enrichment_date: string | null
          est_credit_score: number | null
          estimated_employees: number | null
          estimated_monthly_revenue: number | null
          estimated_revenue: number | null
          file_age_code: string | null
          first_name: string | null
          follow_up_at: string | null
          full_name: string | null
          funded_at: string | null
          funding_recommendation: string | null
          funding_score: number | null
          google_rating: number | null
          has_social_media: boolean | null
          id: string
          identity_theft_risk: string | null
          import_bucket: string | null
          import_confidence_score: number | null
          industry_risk: string | null
          interested_at: string | null
          last_application_sent_at: string | null
          last_attempt_at: string | null
          last_call_at: string | null
          last_call_outcome: string | null
          last_called_at: string | null
          last_called_by: string | null
          last_dial_disposition: string | null
          last_email_event: string | null
          last_emailed_at: string | null
          last_name: string | null
          lead_list_id: string | null
          lead_type: string | null
          linkedin_url: string | null
          list_id: string | null
          lock_expires_at: string | null
          lock_reason: string | null
          lock_started_at: string | null
          locked_by: string | null
          locked_by_email: string | null
          locked_by_worker_email: string | null
          locked_by_worker_id: string | null
          locked_until: string | null
          missing_email: boolean | null
          missing_phone: boolean | null
          mystic_tips: Json | null
          naics_code: string | null
          need_type: string | null
          new_phone: string | null
          next_attempt_at: string | null
          normalized_fields: Json | null
          notes: string | null
          ocm_county: string | null
          ocm_expiration_date: string | null
          ocm_intel: Json | null
          ocm_license_id: string | null
          ocm_license_type: string | null
          ocm_municipality: string | null
          ocm_status: string | null
          outcome: string | null
          owner_birth_date: string | null
          owner_first_name: string | null
          owner_id: string | null
          owner_last_name: string | null
          owner_name: string | null
          owner_worker_id: string | null
          phone: string | null
          phone_carrier: string | null
          phone_invalid: boolean | null
          phone_line_type: string | null
          phone_valid: boolean | null
          postal_code: string | null
          priority_score: number | null
          problem_flags: string[] | null
          raw_data: Json | null
          requested_amount: number | null
          research_assigned_to: string | null
          research_attempts: number | null
          research_completed_at: string | null
          research_last_action_at: string | null
          research_last_run_at: string | null
          research_notes: string | null
          research_owner_id: string | null
          research_started_at: string | null
          research_status: string | null
          route: string | null
          secondary_worker_id: string | null
          sic_code: string | null
          source: string | null
          source_file_name: string | null
          source_folder_name: string | null
          source_id: string | null
          source_list_name: string | null
          source_platform_label: string | null
          ssn_masked: string | null
          state: string | null
          status: string
          updated_at: string | null
          website: string | null
          wolf_folder_label: string | null
          zip: string | null
        }
        SetofOptions: {
          from: "*"
          to: "leads"
          isOneToOne: true
          isSetofReturn: false
        }
      }
      get_next_lead_for_agent: {
        Args: { p_agent_id: string }
        Returns: {
          ad_group: string | null
          address: string | null
          ai_last_evaluated_at: string | null
          ai_notes: Json | null
          ai_priority: string | null
          ai_recommended_path: string | null
          ai_risk_flags: Json | null
          ai_score: number | null
          app_sent_at: string | null
          application_status: string | null
          application_url: string | null
          assigned_to: string | null
          assigned_worker_id: string | null
          attempt_count: number | null
          attempt_history: Json | null
          bucket: string | null
          business_age_years: number | null
          business_name: string | null
          business_start_date: string | null
          business_type: string | null
          call_attempts: number
          campaign: string | null
          city: string | null
          created_at: string | null
          creative_id: string | null
          credit_fix_status: string | null
          credit_fix_worker_id: string | null
          credit_indicators: Json | null
          credit_risk: string | null
          current_owner_email: string | null
          current_owner_id: string | null
          defaults_flag: boolean | null
          dial_attempts: number | null
          dialer_status: string
          domain_age_years: number | null
          eco_mode: boolean | null
          ein: string | null
          email: string | null
          email_attempts: number | null
          email_invalid: boolean | null
          email_status: string | null
          email_template_used: string | null
          email_valid: boolean | null
          enriched_address: string | null
          enriched_business_age_years: number | null
          enriched_business_name: string | null
          enriched_city: string | null
          enriched_email: string | null
          enriched_industry: string | null
          enriched_name: string | null
          enriched_online_presence_score: number | null
          enriched_phone: string | null
          enriched_revenue_estimate: number | null
          enriched_state: string | null
          enriched_zip: string | null
          enrichment_completed: boolean | null
          enrichment_date: string | null
          est_credit_score: number | null
          estimated_employees: number | null
          estimated_monthly_revenue: number | null
          estimated_revenue: number | null
          file_age_code: string | null
          first_name: string | null
          follow_up_at: string | null
          full_name: string | null
          funded_at: string | null
          funding_recommendation: string | null
          funding_score: number | null
          google_rating: number | null
          has_social_media: boolean | null
          id: string
          identity_theft_risk: string | null
          import_bucket: string | null
          import_confidence_score: number | null
          industry_risk: string | null
          interested_at: string | null
          last_application_sent_at: string | null
          last_attempt_at: string | null
          last_call_at: string | null
          last_call_outcome: string | null
          last_called_at: string | null
          last_called_by: string | null
          last_dial_disposition: string | null
          last_email_event: string | null
          last_emailed_at: string | null
          last_name: string | null
          lead_list_id: string | null
          lead_type: string | null
          linkedin_url: string | null
          list_id: string | null
          lock_expires_at: string | null
          lock_reason: string | null
          lock_started_at: string | null
          locked_by: string | null
          locked_by_email: string | null
          locked_by_worker_email: string | null
          locked_by_worker_id: string | null
          locked_until: string | null
          missing_email: boolean | null
          missing_phone: boolean | null
          mystic_tips: Json | null
          naics_code: string | null
          need_type: string | null
          new_phone: string | null
          next_attempt_at: string | null
          normalized_fields: Json | null
          notes: string | null
          ocm_county: string | null
          ocm_expiration_date: string | null
          ocm_intel: Json | null
          ocm_license_id: string | null
          ocm_license_type: string | null
          ocm_municipality: string | null
          ocm_status: string | null
          outcome: string | null
          owner_birth_date: string | null
          owner_first_name: string | null
          owner_id: string | null
          owner_last_name: string | null
          owner_name: string | null
          owner_worker_id: string | null
          phone: string | null
          phone_carrier: string | null
          phone_invalid: boolean | null
          phone_line_type: string | null
          phone_valid: boolean | null
          postal_code: string | null
          priority_score: number | null
          problem_flags: string[] | null
          raw_data: Json | null
          requested_amount: number | null
          research_assigned_to: string | null
          research_attempts: number | null
          research_completed_at: string | null
          research_last_action_at: string | null
          research_last_run_at: string | null
          research_notes: string | null
          research_owner_id: string | null
          research_started_at: string | null
          research_status: string | null
          route: string | null
          secondary_worker_id: string | null
          sic_code: string | null
          source: string | null
          source_file_name: string | null
          source_folder_name: string | null
          source_id: string | null
          source_list_name: string | null
          source_platform_label: string | null
          ssn_masked: string | null
          state: string | null
          status: string
          updated_at: string | null
          website: string | null
          wolf_folder_label: string | null
          zip: string | null
        }[]
        SetofOptions: {
          from: "*"
          to: "leads"
          isOneToOne: false
          isSetofReturn: true
        }
      }
      get_next_lead_for_worker: {
        Args: { p_worker_id: string }
        Returns: {
          ad_group: string | null
          address: string | null
          ai_last_evaluated_at: string | null
          ai_notes: Json | null
          ai_priority: string | null
          ai_recommended_path: string | null
          ai_risk_flags: Json | null
          ai_score: number | null
          app_sent_at: string | null
          application_status: string | null
          application_url: string | null
          assigned_to: string | null
          assigned_worker_id: string | null
          attempt_count: number | null
          attempt_history: Json | null
          bucket: string | null
          business_age_years: number | null
          business_name: string | null
          business_start_date: string | null
          business_type: string | null
          call_attempts: number
          campaign: string | null
          city: string | null
          created_at: string | null
          creative_id: string | null
          credit_fix_status: string | null
          credit_fix_worker_id: string | null
          credit_indicators: Json | null
          credit_risk: string | null
          current_owner_email: string | null
          current_owner_id: string | null
          defaults_flag: boolean | null
          dial_attempts: number | null
          dialer_status: string
          domain_age_years: number | null
          eco_mode: boolean | null
          ein: string | null
          email: string | null
          email_attempts: number | null
          email_invalid: boolean | null
          email_status: string | null
          email_template_used: string | null
          email_valid: boolean | null
          enriched_address: string | null
          enriched_business_age_years: number | null
          enriched_business_name: string | null
          enriched_city: string | null
          enriched_email: string | null
          enriched_industry: string | null
          enriched_name: string | null
          enriched_online_presence_score: number | null
          enriched_phone: string | null
          enriched_revenue_estimate: number | null
          enriched_state: string | null
          enriched_zip: string | null
          enrichment_completed: boolean | null
          enrichment_date: string | null
          est_credit_score: number | null
          estimated_employees: number | null
          estimated_monthly_revenue: number | null
          estimated_revenue: number | null
          file_age_code: string | null
          first_name: string | null
          follow_up_at: string | null
          full_name: string | null
          funded_at: string | null
          funding_recommendation: string | null
          funding_score: number | null
          google_rating: number | null
          has_social_media: boolean | null
          id: string
          identity_theft_risk: string | null
          import_bucket: string | null
          import_confidence_score: number | null
          industry_risk: string | null
          interested_at: string | null
          last_application_sent_at: string | null
          last_attempt_at: string | null
          last_call_at: string | null
          last_call_outcome: string | null
          last_called_at: string | null
          last_called_by: string | null
          last_dial_disposition: string | null
          last_email_event: string | null
          last_emailed_at: string | null
          last_name: string | null
          lead_list_id: string | null
          lead_type: string | null
          linkedin_url: string | null
          list_id: string | null
          lock_expires_at: string | null
          lock_reason: string | null
          lock_started_at: string | null
          locked_by: string | null
          locked_by_email: string | null
          locked_by_worker_email: string | null
          locked_by_worker_id: string | null
          locked_until: string | null
          missing_email: boolean | null
          missing_phone: boolean | null
          mystic_tips: Json | null
          naics_code: string | null
          need_type: string | null
          new_phone: string | null
          next_attempt_at: string | null
          normalized_fields: Json | null
          notes: string | null
          ocm_county: string | null
          ocm_expiration_date: string | null
          ocm_intel: Json | null
          ocm_license_id: string | null
          ocm_license_type: string | null
          ocm_municipality: string | null
          ocm_status: string | null
          outcome: string | null
          owner_birth_date: string | null
          owner_first_name: string | null
          owner_id: string | null
          owner_last_name: string | null
          owner_name: string | null
          owner_worker_id: string | null
          phone: string | null
          phone_carrier: string | null
          phone_invalid: boolean | null
          phone_line_type: string | null
          phone_valid: boolean | null
          postal_code: string | null
          priority_score: number | null
          problem_flags: string[] | null
          raw_data: Json | null
          requested_amount: number | null
          research_assigned_to: string | null
          research_attempts: number | null
          research_completed_at: string | null
          research_last_action_at: string | null
          research_last_run_at: string | null
          research_notes: string | null
          research_owner_id: string | null
          research_started_at: string | null
          research_status: string | null
          route: string | null
          secondary_worker_id: string | null
          sic_code: string | null
          source: string | null
          source_file_name: string | null
          source_folder_name: string | null
          source_id: string | null
          source_list_name: string | null
          source_platform_label: string | null
          ssn_masked: string | null
          state: string | null
          status: string
          updated_at: string | null
          website: string | null
          wolf_folder_label: string | null
          zip: string | null
        }
        SetofOptions: {
          from: "*"
          to: "leads"
          isOneToOne: true
          isSetofReturn: false
        }
      }
      get_role_level: { Args: { role_name: string }; Returns: number }
      has_role:
        | {
            Args: {
              _role: Database["public"]["Enums"]["app_role"]
              _user_id: string
            }
            Returns: boolean
          }
        | { Args: { target_role: string }; Returns: boolean }
      has_role_or_higher: {
        Args: { _min_role: string; _user_id: string }
        Returns: boolean
      }
      is_legal: { Args: never; Returns: boolean }
      is_owner: { Args: never; Returns: boolean }
      is_owner_or_tenant_admin: { Args: { _user_id: string }; Returns: boolean }
      lock_lead_for_agent: {
        Args: { p_days?: number; p_lead_id: string }
        Returns: undefined
      }
      lock_lead_for_application: {
        Args: { p_days?: number; p_lead_id: string; p_worker_id: string }
        Returns: undefined
      }
      lock_lead_for_client_work: {
        Args: { p_lead_id: string; p_reason?: string; p_worker_id: string }
        Returns: undefined
      }
      lock_lead_for_opener: {
        Args: { p_days?: number; p_lead_id: string; p_opener_id: string }
        Returns: undefined
      }
      log_sensitive_access: {
        Args: { field: string; record_id: string; table_name: string }
        Returns: undefined
      }
      mark_call_outcome: {
        Args: {
          p_callback_at?: string
          p_lead_id: string
          p_next_action: string
          p_outcome: string
          p_worker_id: string
        }
        Returns: undefined
      }
      move_application_to_credit_repair:
        | {
            Args: { p_application_id: string; p_application_type: string }
            Returns: Json
          }
        | {
            Args: {
              p_application_id: string
              p_application_type: string
              p_email: string
              p_name: string
              p_phone: string
              p_user_id: string
            }
            Returns: Json
          }
      promote_to_worker: { Args: { _user_id: string }; Returns: undefined }
      record_call_attempt: {
        Args: {
          p_duration_seconds?: number
          p_lead_id: string
          p_notes?: string
          p_outcome: string
        }
        Returns: undefined
      }
      record_call_outcome: {
        Args: { p_lead_id: string; p_outcome: string; p_worker_id: string }
        Returns: {
          ad_group: string | null
          address: string | null
          ai_last_evaluated_at: string | null
          ai_notes: Json | null
          ai_priority: string | null
          ai_recommended_path: string | null
          ai_risk_flags: Json | null
          ai_score: number | null
          app_sent_at: string | null
          application_status: string | null
          application_url: string | null
          assigned_to: string | null
          assigned_worker_id: string | null
          attempt_count: number | null
          attempt_history: Json | null
          bucket: string | null
          business_age_years: number | null
          business_name: string | null
          business_start_date: string | null
          business_type: string | null
          call_attempts: number
          campaign: string | null
          city: string | null
          created_at: string | null
          creative_id: string | null
          credit_fix_status: string | null
          credit_fix_worker_id: string | null
          credit_indicators: Json | null
          credit_risk: string | null
          current_owner_email: string | null
          current_owner_id: string | null
          defaults_flag: boolean | null
          dial_attempts: number | null
          dialer_status: string
          domain_age_years: number | null
          eco_mode: boolean | null
          ein: string | null
          email: string | null
          email_attempts: number | null
          email_invalid: boolean | null
          email_status: string | null
          email_template_used: string | null
          email_valid: boolean | null
          enriched_address: string | null
          enriched_business_age_years: number | null
          enriched_business_name: string | null
          enriched_city: string | null
          enriched_email: string | null
          enriched_industry: string | null
          enriched_name: string | null
          enriched_online_presence_score: number | null
          enriched_phone: string | null
          enriched_revenue_estimate: number | null
          enriched_state: string | null
          enriched_zip: string | null
          enrichment_completed: boolean | null
          enrichment_date: string | null
          est_credit_score: number | null
          estimated_employees: number | null
          estimated_monthly_revenue: number | null
          estimated_revenue: number | null
          file_age_code: string | null
          first_name: string | null
          follow_up_at: string | null
          full_name: string | null
          funded_at: string | null
          funding_recommendation: string | null
          funding_score: number | null
          google_rating: number | null
          has_social_media: boolean | null
          id: string
          identity_theft_risk: string | null
          import_bucket: string | null
          import_confidence_score: number | null
          industry_risk: string | null
          interested_at: string | null
          last_application_sent_at: string | null
          last_attempt_at: string | null
          last_call_at: string | null
          last_call_outcome: string | null
          last_called_at: string | null
          last_called_by: string | null
          last_dial_disposition: string | null
          last_email_event: string | null
          last_emailed_at: string | null
          last_name: string | null
          lead_list_id: string | null
          lead_type: string | null
          linkedin_url: string | null
          list_id: string | null
          lock_expires_at: string | null
          lock_reason: string | null
          lock_started_at: string | null
          locked_by: string | null
          locked_by_email: string | null
          locked_by_worker_email: string | null
          locked_by_worker_id: string | null
          locked_until: string | null
          missing_email: boolean | null
          missing_phone: boolean | null
          mystic_tips: Json | null
          naics_code: string | null
          need_type: string | null
          new_phone: string | null
          next_attempt_at: string | null
          normalized_fields: Json | null
          notes: string | null
          ocm_county: string | null
          ocm_expiration_date: string | null
          ocm_intel: Json | null
          ocm_license_id: string | null
          ocm_license_type: string | null
          ocm_municipality: string | null
          ocm_status: string | null
          outcome: string | null
          owner_birth_date: string | null
          owner_first_name: string | null
          owner_id: string | null
          owner_last_name: string | null
          owner_name: string | null
          owner_worker_id: string | null
          phone: string | null
          phone_carrier: string | null
          phone_invalid: boolean | null
          phone_line_type: string | null
          phone_valid: boolean | null
          postal_code: string | null
          priority_score: number | null
          problem_flags: string[] | null
          raw_data: Json | null
          requested_amount: number | null
          research_assigned_to: string | null
          research_attempts: number | null
          research_completed_at: string | null
          research_last_action_at: string | null
          research_last_run_at: string | null
          research_notes: string | null
          research_owner_id: string | null
          research_started_at: string | null
          research_status: string | null
          route: string | null
          secondary_worker_id: string | null
          sic_code: string | null
          source: string | null
          source_file_name: string | null
          source_folder_name: string | null
          source_id: string | null
          source_list_name: string | null
          source_platform_label: string | null
          ssn_masked: string | null
          state: string | null
          status: string
          updated_at: string | null
          website: string | null
          wolf_folder_label: string | null
          zip: string | null
        }
        SetofOptions: {
          from: "*"
          to: "leads"
          isOneToOne: true
          isSetofReturn: false
        }
      }
      request_lead_conflict: {
        Args: { p_lead_id: string; p_requester_id: string }
        Returns: string
      }
      request_lead_release: {
        Args: { p_from_worker_id: string; p_lead_id: string }
        Returns: {
          created_at: string
          from_worker_email: string
          from_worker_id: string
          id: string
          lead_id: string
          resolution_notes: string | null
          resolved_at: string | null
          resolved_by: string | null
          resolved_by_email: string | null
          status: string
          to_worker_email: string
          to_worker_id: string
        }
        SetofOptions: {
          from: "*"
          to: "lead_release_requests"
          isOneToOne: true
          isSetofReturn: false
        }
      }
      request_lead_release_or_split: {
        Args: { p_lead_id: string; p_message?: string; p_request_type: string }
        Returns: undefined
      }
      request_lead_share: {
        Args: {
          p_from_worker_id: string
          p_lead_id: string
          p_message?: string
          p_type: string
        }
        Returns: {
          created_at: string | null
          from_worker_id: string
          id: string
          lead_id: string
          message: string | null
          responded_at: string | null
          status: string
          to_worker_id: string
          type: string
        }
        SetofOptions: {
          from: "*"
          to: "lead_share_requests"
          isOneToOne: true
          isSetofReturn: false
        }
      }
      research_center_stats: {
        Args: { p_lead_list_id?: string }
        Returns: Json
      }
      respond_lead_share: {
        Args: { p_decision: string; p_owner_id: string; p_request_id: string }
        Returns: undefined
      }
      respond_to_lead_lock_request: {
        Args: { p_decision: string; p_request_id: string }
        Returns: undefined
      }
      respond_to_lead_release: {
        Args: {
          p_request_id: string
          p_responder_id: string
          p_response: string
        }
        Returns: undefined
      }
      start_call_session: {
        Args: { p_worker_id: string }
        Returns: {
          ended_at: string | null
          id: string
          is_active: boolean
          started_at: string
          worker_id: string
        }
        SetofOptions: {
          from: "*"
          to: "call_sessions"
          isOneToOne: true
          isSetofReturn: false
        }
      }
      start_underwriting_case: {
        Args: { p_lead_id: string; p_underwriter_id: string }
        Returns: string
      }
      stop_call_session: { Args: { p_worker_id: string }; Returns: undefined }
      submit_underwriting_package: {
        Args: {
          p_case_id: string
          p_docs_url: string
          p_funding_call_needed: boolean
        }
        Returns: undefined
      }
      tenant_has_access: {
        Args: { tid: string; user_id: string }
        Returns: boolean
      }
      tenant_is_admin: {
        Args: { tid: string; user_id: string }
        Returns: boolean
      }
      update_case_stage: {
        Args: {
          p_actor_user_id?: string
          p_case_id: string
          p_new_stage: Database["public"]["Enums"]["case_stage"]
          p_notes?: string
        }
        Returns: undefined
      }
      user_tenant_id: { Args: never; Returns: string }
    }
    Enums: {
      ai_report_type:
        | "underwriting"
        | "legal_search"
        | "lien_bankruptcy"
        | "business_background"
        | "credit_analysis"
        | "lead_enrichment"
        | "research_summary"
      app_role:
        | "admin"
        | "user"
        | "worker"
        | "credit_repair_specialist"
        | "underwriter"
        | "owner"
        | "legal"
        | "tenant_admin"
        | "iso_partner"
      case_stage:
        | "lead_new"
        | "lead_contacted"
        | "docs_requested"
        | "docs_received"
        | "uw_in_review"
        | "uw_conditional"
        | "uw_approved"
        | "uw_declined"
        | "sent_to_credit_fix"
        | "credit_fix_in_progress"
        | "credit_fix_ready_for_uw"
        | "offer_sent"
        | "offer_accepted"
        | "funded"
        | "closed_lost"
      participant_role:
        | "OPENER"
        | "CLOSER"
        | "REFERRAL_PARTNER"
        | "ISO_PARTNER"
        | "HOUSE"
        | "AI_AUTOPILOT"
      product_line:
        | "mca"
        | "term_loan"
        | "loc"
        | "credit_fix_only"
        | "hybrid"
        | "general"
        | "credit_fix"
        | "loan"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      ai_report_type: [
        "underwriting",
        "legal_search",
        "lien_bankruptcy",
        "business_background",
        "credit_analysis",
        "lead_enrichment",
        "research_summary",
      ],
      app_role: [
        "admin",
        "user",
        "worker",
        "credit_repair_specialist",
        "underwriter",
        "owner",
        "legal",
        "tenant_admin",
        "iso_partner",
      ],
      case_stage: [
        "lead_new",
        "lead_contacted",
        "docs_requested",
        "docs_received",
        "uw_in_review",
        "uw_conditional",
        "uw_approved",
        "uw_declined",
        "sent_to_credit_fix",
        "credit_fix_in_progress",
        "credit_fix_ready_for_uw",
        "offer_sent",
        "offer_accepted",
        "funded",
        "closed_lost",
      ],
      participant_role: [
        "OPENER",
        "CLOSER",
        "REFERRAL_PARTNER",
        "ISO_PARTNER",
        "HOUSE",
        "AI_AUTOPILOT",
      ],
      product_line: [
        "mca",
        "term_loan",
        "loc",
        "credit_fix_only",
        "hybrid",
        "general",
        "credit_fix",
        "loan",
      ],
    },
  },
} as const
