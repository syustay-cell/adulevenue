// src/intel/IntelEventsLogger.ts
// WOLF-FUND.COM – 411 EVENTS LOGGER – 444 LOCKED

import { supabase } from '@/integrations/supabase/client';
import type { Json } from '@/integrations/supabase/types';

export type IntelEventType = 'user_action' | 'ai_decision' | 'routing_decision' | 'anomaly' | 'security' | 'system' | 'error';
export type IntelEventSeverity = 'info' | 'warning' | 'error' | 'critical';

export interface IntelEventPayload {
  type: IntelEventType;
  severity: IntelEventSeverity;
  source: string;
  message: string;
  meta?: Json;
}

export const IntelEventsLogger = {
  async log(event: IntelEventPayload): Promise<void> {
    try {
      await supabase.from('activity_log').insert([{
        actor: event.source,
        mode: 'INTEL',
        module: 'intel_411',
        severity: event.severity,
        title: event.type,
        summary: event.message,
        metadata: event.meta ?? null,
      }]);
    } catch (err) {
      console.warn('[IntelEventsLogger] Failed:', err);
    }
  },

  async logUserAction(userId: string, action: string, details?: Json): Promise<void> {
    await this.log({
      type: 'user_action',
      severity: 'info',
      source: userId,
      message: action,
      meta: details,
    });
  },

  async logAIDecision(model: string, decision: string, context?: Json): Promise<void> {
    await this.log({
      type: 'ai_decision',
      severity: 'info',
      source: model,
      message: decision,
      meta: context,
    });
  },

  async logRoutingDecision(from: string, to: string, reason: string): Promise<void> {
    await this.log({
      type: 'routing_decision',
      severity: 'info',
      source: 'router',
      message: `Routed from ${from} to ${to}: ${reason}`,
      meta: { from, to, reason },
    });
  },

  async logAnomaly(metric: string, expected: number, actual: number, severity: IntelEventSeverity = 'warning'): Promise<void> {
    await this.log({
      type: 'anomaly',
      severity,
      source: 'anomaly_detector',
      message: `Anomaly detected in ${metric}: expected ${expected}, got ${actual}`,
      meta: { metric, expected, actual },
    });
  },

  async logSecurityEvent(eventType: string, userId: string, details?: Json): Promise<void> {
    await this.log({
      type: 'security',
      severity: 'warning',
      source: userId,
      message: eventType,
      meta: details,
    });
  },
};

export default IntelEventsLogger;
