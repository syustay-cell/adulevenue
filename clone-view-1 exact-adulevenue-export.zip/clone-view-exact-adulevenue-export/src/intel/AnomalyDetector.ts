// src/intel/AnomalyDetector.ts
// WOLF-FUND.COM – 412 ANOMALY DETECTOR – 444 LOCKED

import { IntelEventsLogger } from './IntelEventsLogger';

export interface AnomalyRule {
  metric: string;
  threshold: number;
  direction: 'above' | 'below' | 'both';
  severity: 'low' | 'medium' | 'high' | 'critical';
}

export interface Anomaly {
  id: string;
  metric: string;
  expected: number;
  actual: number;
  deviation: number;
  severity: 'low' | 'medium' | 'high' | 'critical';
  detected_at: string;
}

const DEFAULT_RULES: AnomalyRule[] = [
  { metric: 'applications_per_hour', threshold: 50, direction: 'above', severity: 'medium' },
  { metric: 'error_rate', threshold: 0.05, direction: 'above', severity: 'high' },
  { metric: 'approval_rate', threshold: 0.3, direction: 'below', severity: 'medium' },
  { metric: 'avg_processing_time', threshold: 300, direction: 'above', severity: 'low' },
];

export const AnomalyDetector = {
  rules: [...DEFAULT_RULES],

  async detect(metrics: Record<string, number>): Promise<Anomaly[]> {
    const anomalies: Anomaly[] = [];
    const now = new Date().toISOString();

    for (const rule of this.rules) {
      const actual = metrics[rule.metric];
      if (actual === undefined) continue;

      const isAnomaly =
        (rule.direction === 'above' && actual > rule.threshold) ||
        (rule.direction === 'below' && actual < rule.threshold) ||
        (rule.direction === 'both' && Math.abs(actual - rule.threshold) > rule.threshold * 0.5);

      if (isAnomaly) {
        const deviation = ((actual - rule.threshold) / rule.threshold) * 100;
        const anomaly: Anomaly = {
          id: `${rule.metric}-${Date.now()}`,
          metric: rule.metric,
          expected: rule.threshold,
          actual,
          deviation: Math.round(deviation),
          severity: rule.severity,
          detected_at: now,
        };

        anomalies.push(anomaly);

        await IntelEventsLogger.logAnomaly(rule.metric, rule.threshold, actual, rule.severity);
      }
    }

    return anomalies;
  },

  addRule(rule: AnomalyRule): void {
    this.rules.push(rule);
  },

  removeRule(metric: string): void {
    this.rules = this.rules.filter(r => r.metric !== metric);
  },

  getRules(): AnomalyRule[] {
    return [...this.rules];
  },
};

export default AnomalyDetector;
