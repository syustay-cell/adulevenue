// src/intel/SuggestionEngine.ts
// WOLF-FUND.COM – 412 SUGGESTION ENGINE – 444 LOCKED

import { supabase } from '@/integrations/supabase/client';
import { IntelEventsLogger } from './IntelEventsLogger';

export type SuggestionStatus = 'open' | 'applied' | 'dismissed';

export interface Suggestion {
  id: string;
  type: string;
  priority: 'low' | 'medium' | 'high';
  status: SuggestionStatus;
  title: string;
  description: string;
  created_at: string;
}

export const SuggestionEngine = {
  async getOpenSuggestions(): Promise<Suggestion[]> {
    const { data, error } = await supabase
      .from('wolf_suggestions')
      .select('*')
      .eq('status', 'open')
      .order('created_at', { ascending: false });

    if (error) {
      console.warn('[SuggestionEngine] Failed to load:', error);
      return [];
    }

    return (data || []).map(row => ({
      id: row.id,
      type: row.type || 'general',
      priority: 'medium' as const,
      status: (row.status || 'open') as SuggestionStatus,
      title: row.reason?.slice(0, 50) || 'Suggestion',
      description: row.reason || '',
      created_at: row.created_at,
    }));
  },

  async applySuggestion(id: string): Promise<void> {
    const { error } = await supabase
      .from('wolf_suggestions')
      .update({ status: 'applied' })
      .eq('id', id);

    if (error) throw error;

    await IntelEventsLogger.log({
      type: 'user_action',
      severity: 'info',
      source: 'suggestion_engine',
      message: `Suggestion ${id} applied`,
      meta: { suggestionId: id, action: 'applied' },
    });
  },

  async dismissSuggestion(id: string): Promise<void> {
    const { error } = await supabase
      .from('wolf_suggestions')
      .update({ status: 'dismissed' })
      .eq('id', id);

    if (error) throw error;

    await IntelEventsLogger.log({
      type: 'user_action',
      severity: 'info',
      source: 'suggestion_engine',
      message: `Suggestion ${id} dismissed`,
      meta: { suggestionId: id, action: 'dismissed' },
    });
  },

  async generateSuggestions(): Promise<Suggestion[]> {
    // Placeholder - AI-powered suggestion generation
    return [];
  },
};

export default SuggestionEngine;
