// src/intel/TrendExtractor.ts
// WOLF-FUND.COM – 412 TREND EXTRACTOR – 444 LOCKED

export type TrendDirection = 'up' | 'down' | 'stable';

export interface TrendData {
  metric: string;
  direction: TrendDirection;
  changePercent: number;
  dataPoints: { timestamp: string; value: number }[];
}

export interface TrendInsight {
  metric: string;
  insight: string;
  confidence: number;
  actionable: boolean;
  suggestedAction?: string;
}

export const TrendExtractor = {
  extractTrend(dataPoints: { timestamp: string; value: number }[], metric: string): TrendData {
    if (dataPoints.length < 2) {
      return { metric, direction: 'stable', changePercent: 0, dataPoints };
    }

    const sorted = [...dataPoints].sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());
    const first = sorted[0].value;
    const last = sorted[sorted.length - 1].value;
    const changePercent = first !== 0 ? ((last - first) / first) * 100 : 0;

    let direction: TrendDirection = 'stable';
    if (changePercent > 5) direction = 'up';
    else if (changePercent < -5) direction = 'down';

    return {
      metric,
      direction,
      changePercent: Math.round(changePercent * 10) / 10,
      dataPoints: sorted,
    };
  },

  generateAnalysis(trends: TrendData[]): string {
    const summaries = trends.map(t => `${t.metric}: ${t.direction} (${t.changePercent}%)`);
    return summaries.join('; ');
  },

  generateInsights(trends: TrendData[]): TrendInsight[] {
    return trends.map(trend => {
      let insight = '';
      let suggestedAction: string | undefined;
      let actionable = false;

      if (trend.direction === 'up' && trend.changePercent > 20) {
        insight = `${trend.metric} increased significantly by ${trend.changePercent}%`;
        actionable = true;
        suggestedAction = 'Review capacity and scaling needs';
      } else if (trend.direction === 'down' && trend.changePercent < -20) {
        insight = `${trend.metric} dropped significantly by ${Math.abs(trend.changePercent)}%`;
        actionable = true;
        suggestedAction = 'Investigate root cause';
      } else {
        insight = `${trend.metric} is ${trend.direction} (${trend.changePercent}% change)`;
      }

      return {
        metric: trend.metric,
        insight,
        confidence: Math.min(100, 50 + trend.dataPoints.length * 2),
        actionable,
        suggestedAction,
      };
    });
  },

  compareToBaseline(current: number, baseline: number): { deviation: number; status: 'normal' | 'warning' | 'critical' } {
    const deviation = ((current - baseline) / baseline) * 100;
    let status: 'normal' | 'warning' | 'critical' = 'normal';
    if (Math.abs(deviation) > 50) status = 'critical';
    else if (Math.abs(deviation) > 20) status = 'warning';
    return { deviation: Math.round(deviation), status };
  },
};

export default TrendExtractor;
