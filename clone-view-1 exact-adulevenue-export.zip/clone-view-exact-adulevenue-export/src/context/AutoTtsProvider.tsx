import React, { createContext, useContext, useEffect, useState, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import * as tts from "@/lib/tts";

type TtsSettings = {
  enabled: boolean;
  voiceId: string;
  rate: number;
};

type GlobalVoiceSettings = {
  enabled: boolean;
  voice: string;
  speed: number;
  force_global: boolean;
};

type AutoTtsContextValue = {
  enabled: boolean;
  setEnabled: (value: boolean) => void;
  read: (text: string) => void;
  loading: boolean;
  voiceId: string;
  rate: number;
};

const DEFAULT_SETTINGS: TtsSettings = {
  enabled: false,
  voiceId: "nova",
  rate: 1.0,
};

const AutoTtsContext = createContext<AutoTtsContextValue | undefined>(undefined);

export function AutoTtsProvider({ children }: { children: React.ReactNode }) {
  const [settings, setSettings] = useState<TtsSettings>(DEFAULT_SETTINGS);
  const [loading, setLoading] = useState(true);
  const [userId, setUserId] = useState<string | null>(null);

  // Load user settings with global fallback hierarchy
  useEffect(() => {
    const loadSettings = async () => {
      try {
        const { data: { user } } = await supabase.auth.getUser();
        if (!user) {
          setLoading(false);
          return;
        }
        
        setUserId(user.id);

        // 1. Load global/org settings from wolf_master_config
        let globalSettings: GlobalVoiceSettings | null = null;
        const { data: globalConfig } = await supabase
          .from("wolf_master_config")
          .select("value")
          .eq("category", "tts")
          .eq("key", "global_voice_settings")
          .maybeSingle();

        if (globalConfig?.value) {
          globalSettings = globalConfig.value as GlobalVoiceSettings;
        }

        // 2. Load user-specific settings
        const { data: userSettings, error: userError } = await supabase
          .from("user_settings")
          .select("auto_tts_enabled, tts_voice, tts_speed")
          .eq("user_id", user.id)
          .maybeSingle();

        // 3. Apply hierarchy: force_global → user settings → global settings → defaults
        let effectiveSettings: TtsSettings;

        if (globalSettings?.force_global) {
          // Force global: ALWAYS use global settings, ignore user preferences
          effectiveSettings = {
            enabled: globalSettings.enabled,
            voiceId: globalSettings.voice,
            rate: globalSettings.speed,
          };
          console.log("[TTS] Force global mode - using org settings");
        } else if (!userError && userSettings && userSettings.tts_voice) {
          // User has personal settings - use those
          effectiveSettings = {
            enabled: userSettings.auto_tts_enabled ?? DEFAULT_SETTINGS.enabled,
            voiceId: userSettings.tts_voice ?? DEFAULT_SETTINGS.voiceId,
            rate: userSettings.tts_speed ?? DEFAULT_SETTINGS.rate,
          };
          console.log("[TTS] Using user personal settings");
        } else if (globalSettings) {
          // No user settings - fall back to global
          effectiveSettings = {
            enabled: globalSettings.enabled,
            voiceId: globalSettings.voice,
            rate: globalSettings.speed,
          };
          console.log("[TTS] No user settings - using global defaults");
        } else {
          // No global or user settings - use system defaults
          effectiveSettings = DEFAULT_SETTINGS;
          console.log("[TTS] Using system defaults");
        }

        setSettings(effectiveSettings);
        
        // Apply voice to tts module
        tts.setVoice(effectiveSettings.voiceId as any);
      } catch (err) {
        console.error("[TTS] Failed to load settings:", err);
        setSettings(DEFAULT_SETTINGS);
      } finally {
        setLoading(false);
      }
    };

    loadSettings();
  }, []);

  const setEnabled = useCallback(async (value: boolean) => {
    setSettings(prev => ({ ...prev, enabled: value }));
    
    if (!userId) return;

    // Upsert to database
    try {
      await supabase
        .from("user_settings")
        .upsert({ 
          user_id: userId, 
          auto_tts_enabled: value,
          updated_at: new Date().toISOString()
        });
    } catch (err) {
      console.error("Failed to save TTS setting:", err);
    }
  }, [userId]);

  const read = useCallback((text: string) => {
    if (!settings.enabled || !text?.trim()) return;
    tts.stop();
    tts.setVoice(settings.voiceId as any);
    tts.play(text, settings.rate);
  }, [settings.enabled, settings.voiceId, settings.rate]);

  return (
    <AutoTtsContext.Provider value={{ 
      enabled: settings.enabled, 
      setEnabled, 
      read, 
      loading,
      voiceId: settings.voiceId,
      rate: settings.rate,
    }}>
      {children}
    </AutoTtsContext.Provider>
  );
}

export function useAutoTts() {
  const ctx = useContext(AutoTtsContext);
  if (!ctx) {
    // Return a safe fallback if used outside provider
    return {
      enabled: false,
      setEnabled: () => {},
      read: () => {},
      loading: false,
      voiceId: "nova",
      rate: 1.0,
    };
  }
  return ctx;
}