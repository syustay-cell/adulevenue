# Wolf Fund Platform - Complete Architecture Documentation

## Overview
Wolf Fund is a comprehensive financial services platform handling business funding applications, credit repair services, ISO partner management, and AI-powered underwriting.

---

## System Architecture

### Frontend Stack
- **Framework**: React 18 + TypeScript
- **Routing**: React Router v6
- **Styling**: Tailwind CSS with custom design tokens
- **State Management**: React Query (TanStack Query)
- **UI Components**: Shadcn/ui + Radix UI
- **Animations**: Framer Motion
- **Build Tool**: Vite

### Backend Stack (Cloud hosting / Supabase)
- **Database**: PostgreSQL
- **Authentication**: Supabase Auth
- **Storage**: Supabase Storage (12 buckets)
- **Edge Functions**: Deno serverless functions
- **Real-time**: Supabase Realtime subscriptions
- **Email**: Resend API
- **SMS**: Twilio API
- **E-Signature**: DocuSign API
- **AI**: AI Gateway AI Gateway (Google Gemini models)

---

## User Roles & Permissions

### 1. **Client (Default)**
- Submit applications (Fast Track, Loan, Credit Repair)
- View own application statuses
- Upload additional documents
- Access: `/client-dashboard`

### 2. **Worker / ISO Partner**
- Submit applications on behalf of clients
- View only their own submissions
- Upload additional documents
- Cannot edit existing records
- Access: `/worker-dashboard`

### 3. **Credit Repair Specialist**
- Manage assigned credit repair cases
- Kanban board workflow (intake → completed)
- Update case status, add tasks, log activity
- Cannot access funding applications
- Access: `/credit-specialist-dashboard`

### 4. **Admin**
- Full platform access
- Application review and approval
- Worker/ISO approval
- AI underwriting analysis
- Funder distribution
- Legal risk scanning
- Access: `/admin`, `/admin-reports`, `/underwriting`

---

## Database Schema

### Core Application Tables

#### `fast_track_applications`
Primary funding application type requiring specific documents.
```
- id (uuid)
- user_id (uuid) - submitting user
- client_name (text) - NEW field for client name
- business_name (text)
- email (text)
- phone (text)
- credit_score (text)
- has_previous_loan (boolean)
- previous_loan_company (text)
- previous_loan_amount (text)
- in_business_over_6_months (boolean)
- bank_statements (text[]) - file paths
- driver_license_front (text)
- driver_license_back (text)
- ein_document (text)
- ssn_card (text)
- void_check (text)
- credit_card_statement (text)
- status (text)
- follow_up_date (timestamp)
- created_at (timestamp)
- updated_at (timestamp)
```

#### `loan_applications`
Standard loan application type.
```
- id (uuid)
- user_id (uuid)
- business_name (text)
- owner_name (text)
- email (text)
- phone (text)
- loan_type (text)
- loan_amount (text)
- business_revenue (text)
- time_in_business (text)
- business_address (text)
- purpose_of_loan (text)
- credit_score (text)
- status (text)
- follow_up_date (timestamp)
- created_at (timestamp)
- updated_at (timestamp)
```

#### `credit_repair_applications`
Credit repair service applications.
```
- id (uuid)
- user_id (uuid)
- full_name (text)
- email (text)
- phone (text)
- current_credit_score (text)
- desired_credit_score (text)
- negative_items (text)
- goals (text)
- has_identity_theft (boolean)
- identity_theft_details (text)
- experian_username (text)
- status (text)
- follow_up_date (timestamp)
- created_at (timestamp)
- updated_at (timestamp)
```

#### `credit_repair_cases`
Active credit repair case management.
```
- id (uuid)
- credit_repair_application_id (uuid)
- assigned_specialist_id (uuid)
- status (text) - intake, docs_pending, investigation, bureaus_pending, results_received, completed
- from_declined_funding (boolean) - closed-loop indicator
- original_application_id (uuid)
- original_application_type (text)
- completed_at (timestamp)
- created_at (timestamp)
- updated_at (timestamp)
```

#### `credit_repair_items`
Individual credit report items being disputed.
```
- id (uuid)
- case_id (uuid)
- item_type (text)
- creditor_name (text)
- account_number (text)
- status (text)
- dispute_date (timestamp)
- resolution_date (timestamp)
- resolution_outcome (text)
- notes (text)
- created_at (timestamp)
- updated_at (timestamp)
```

### Underwriting System

#### `underwriting_cases`
Links applications to AI underwriting analysis.
```
- id (uuid)
- application_type (text) - 'fast_track' or 'loan'
- application_id (uuid)
- client_id (uuid)
- assigned_underwriter_id (uuid)
- status (text) - pending, analyzing, awaiting_docs, review_ready, approved, declined
- created_at (timestamp)
- updated_at (timestamp)
```

#### `underwriting_metrics`
AI-extracted financial metrics from bank statements.
```
- id (uuid)
- underwriting_case_id (uuid)
- avg_monthly_revenue (numeric)
- highest_monthly_deposits (numeric)
- avg_daily_balance (numeric)
- negative_days (integer)
- nsf_count (integer)
- cash_flow_stability (text)
- revenue_trend (text)
- concentration_risk (text)
- seasonality_flag (boolean)
- months_analyzed (json)
- existing_advances_estimate (text)
- risk_level (text) - low, medium, high, borderline
- recommended_label (text) - Fundable, Conditional, Not Fundable
- summary (text) - AI-generated summary
- internal_summary (text) - detailed admin analysis
- funder_safe_summary (text) - sanitized for external distribution
- raw_metrics (json) - complete AI output
- missing_items (json)
- created_at (timestamp)
```

#### `underwriting_notes`
Admin/underwriter notes on cases.
```
- id (uuid)
- underwriting_case_id (uuid)
- user_id (uuid)
- note_type (text) - system, manual, ai_insight
- message (text)
- created_at (timestamp)
```

#### `underwriting_feedback`
AI learning system - stores corrections.
```
- id (uuid)
- underwriting_case_id (uuid)
- application_id (uuid)
- application_type (text)
- field (text)
- original_value (text)
- corrected_value (text)
- corrected_by (uuid)
- feedback_type (text) - false_positive, missed_detection, incorrect_value
- notes (text)
- created_at (timestamp)
```

### Funder CRM

#### `funders`
External funding partners.
```
- id (uuid)
- name (text)
- contact_email (text)
- portal_url (text)
- preferences (json)
- created_at (timestamp)
- updated_at (timestamp)
```

#### `funder_submissions`
Tracks applications sent to funders.
```
- id (uuid)
- application_id (uuid)
- application_type (text)
- funder_id (uuid)
- mode (text) - summary_only, summary_with_docs, full_package
- status (text) - draft, pending_admin_approval, approved_not_sent, sent_to_funder, funder_in_review, offer_received, declined, funded
- attachments_included (json)
- sent_at (timestamp)
- created_at (timestamp)
```

### User Management

#### `user_roles`
Role-based access control.
```
- id (uuid)
- user_id (uuid)
- role (app_role enum) - admin, user, worker, credit_repair_specialist
- approved (boolean)
- approved_by (uuid)
- approved_at (timestamp)
- created_at (timestamp)
```

#### `iso_partner_applications`
Public ISO partner application form submissions.
```
- id (uuid)
- user_id (uuid)
- full_name (text)
- company_name (text)
- email (text)
- phone (text)
- iso_volume_history (text)
- monthly_deals (text)
- funding_type (text)
- agreement_document (text) - storage path
- approved (boolean)
- approved_by (uuid)
- approved_at (timestamp)
- status (text)
- notes (text)
- created_at (timestamp)
- updated_at (timestamp)
```

### Document & E-Signature

#### `signature_requests`
DocuSign e-signature tracking.
```
- id (uuid)
- application_id (uuid)
- application_type (text) - iso_agreement, credit_repair_agreement, client_engagement_letter
- initiated_by (uuid)
- recipient_name (text)
- recipient_email (text)
- docusign_envelope_id (text)
- status (text) - sent, viewed, completed, declined, voided
- signed_document_url (text)
- completed_at (timestamp)
- created_at (timestamp)
```

#### `document_extractions`
OCR data from uploaded documents (driver licenses).
```
- id (uuid)
- application_id (uuid)
- application_type (text)
- document_type (text)
- parsed_data (json) - full_name, address, DOB, license_number, etc.
- raw_text (text)
- created_at (timestamp)
```

### Tracking & Analytics

#### `application_comments`
Admin comments on applications.
```
- id (uuid)
- application_id (uuid)
- admin_user_id (uuid)
- comment (text)
- created_at (timestamp)
- updated_at (timestamp)
```

#### `application_transactions`
Financial transaction log (funding events).
```
- id (uuid)
- application_id (uuid)
- admin_user_id (uuid)
- transaction_type (text)
- amount (numeric)
- transaction_date (timestamp)
- description (text)
- created_at (timestamp)
```

#### `intake_logs`
Worker-submitted prospect logs.
```
- id (uuid)
- worker_id (uuid)
- client_name (text)
- email (text)
- phone (text)
- lead_type (text)
- notes (text)
- status (text)
- follow_up_date (timestamp)
- created_at (timestamp)
- updated_at (timestamp)
```

#### `legal_risk_feedback`
Admin feedback on AI-detected legal risks.
```
- id (uuid)
- application_id (uuid)
- application_type (text)
- finding_type (text)
- finding_id (text)
- is_relevant (boolean)
- created_by (uuid)
- notes (text)
- created_at (timestamp)
```

---

## Routing Structure

### Public Routes
- `/` - Homepage (hero, services, testimonials, CTA)
- `/services` - Service offerings detail page
- `/how-it-works` - Process explanation
- `/contact` - Contact form
- `/terms` - Terms of Service
- `/apply` - Application type selector
- `/fast-track` - Fast Track application form
- `/loan-application` - Standard loan application
- `/credit-repair-application` - Credit repair intake
- `/iso-partner-application` - Public ISO application form
- `/iso-agreement-success` - Post-signature success page
- `/auth` - Login/signup page

### Protected Routes (Client)
- `/client-dashboard` - Client application status view

### Protected Routes (Worker)
- `/worker-dashboard` - Worker submission view

### Protected Routes (Credit Specialist)
- `/credit-specialist-dashboard` - Credit repair case Kanban board

### Protected Routes (Admin)
- `/admin` - Main admin dashboard (applications, intakes, users, follow-ups)
- `/admin-reports` - Analytics dashboard
- `/underwriting` - Legacy underwriting page (now integrated into `/admin`)
- `/underwriting-case/:id` - Individual case detail
- `/admin-users` - User management (legacy, now in `/admin`)

### Error Routes
- `/404` - Not found page

---

## Edge Functions

**Current inventory:** 156 functions in the latest export index (2025-12-14), while the repo currently contains 173 function directories (excluding `_shared`). See `exports/05_EDGE_FUNCTIONS_INDEX.md` for the authoritative export list and `supabase/functions/` for the live source.

### Authentication & Notifications
1. **`send-notification-email`** - Base email notification sender (Resend)
2. **`send-sms-notification`** - SMS sender (Twilio)
3. **`check-follow-ups`** - Scheduled job for 20-day follow-up reminders
4. **`notify-worker-approval`** - Worker approval notifications
5. **`notify-status-change`** - Application status change alerts
6. **`notify-credit-repair-assignment`** - Credit repair case assignment
7. **`send-test-notifications`** - Test email/SMS system

### Document Processing
8. **`verify-bank-statement`** - AI validation of uploaded bank statements (Gemini 2.5 Flash)
9. **`extract-id-fields`** - OCR for driver license data extraction (Vision AI)

### E-Signature
10. **`initiate-docusign`** - Sends DocuSign envelope
11. **`docusign-webhook`** - Receives signature completion callbacks

### Credit Repair
12. **`move-to-credit-repair`** - Transitions declined funding apps to credit repair track
13. **`complete-credit-repair-case`** - Closes credit repair case and re-funnels to funding (if score >= 600)

### Underwriting
14. **`underwriter-analyze-application`** - AI analysis of bank statements, generates metrics
15. **`legal-risk-scan`** - Public records check (court cases, liens, bankruptcies)
16. **`send-to-funder`** - Emails application packages to funders

### AI Assistant
17. **`chat-assistant`** - Context-aware AI chatbot (AI Gateway)

### ISO Partner
18. **`send-iso-confirmation-email`** - ISO approval confirmation

---

## Key Workflows

### 1. Fast Track Application Flow
```
User submits form with documents
  ↓
Bank statements validated via AI (verify-bank-statement)
  ↓
Application saved to fast_track_applications
  ↓
Underwriting case auto-created (trigger)
  ↓
Admin views in dashboard
  ↓
Admin runs AI underwriting (underwriter-analyze-application)
  ↓
AI extracts metrics, generates summaries
  ↓
Admin reviews fundability
  ↓
Decision:
  → Fundable: Send to funders (send-to-funder)
  → Not Fundable (credit issues): Move to Credit Repair (move-to-credit-repair)
```

### 2. Closed-Loop Funding Model
```
Application declined due to credit
  ↓
Admin clicks "Move to Credit Repair"
  ↓
Creates credit_repair_application
  ↓
Creates credit_repair_case (assigned to specialist)
  ↓
Specialist works case through Kanban stages
  ↓
Case marked completed
  ↓
System checks credit score:
  → If >= 600: Auto-create new Fast Track draft (complete-credit-repair-case)
  → If < 600: Auto-restart credit repair workflow
```

### 3. ISO Partner Onboarding
```
Prospect submits public ISO application form
  ↓
Admin reviews in ISO Partners tab
  ↓
Admin clicks "Send Agreement"
  ↓
DocuSign envelope sent (initiate-docusign)
  ↓
Prospect receives email, signs agreement
  ↓
DocuSign webhook fires (docusign-webhook)
  ↓
System auto-approves worker role
  ↓
Prospect moved from ISO Prospects to Workers
  ↓
Notification sent to ISO partner
```

### 4. Funder CRM Workflow
```
Admin/underwriter runs AI underwriting
  ↓
Selects multiple funders from list
  ↓
Chooses share level (summary_only, summary_with_docs, full_package)
  ↓
Status set to pending_admin_approval
  ↓
Admin reviews and approves
  ↓
send-to-funder edge function executes
  ↓
Emails sent to all selected funders with:
  - Funder-safe summary (no SSN/contact redacted)
  - Optional: Full metrics PDF
  - Optional: Document attachments
  ↓
Submission status tracked in funder_submissions
```

### 5. AI Learning Loop
```
AI analyzes bank statement, detects existing funding
  ↓
Admin sees detected position (e.g., "Capital Source - $500/day")
  ↓
Admin corrects: "Actually 'XYZ Lender' - $350/day"
  ↓
Correction stored in underwriting_feedback
  ↓
Next analysis incorporates past corrections in prompt
  ↓
AI improves accuracy over time
```

---

## AI Integration

### AI Gateway AI Models Used
- **google/gemini-2.5-flash** (default) - Bank statement parsing, underwriting analysis
- **google/gemini-2.5-pro** - Complex reasoning (optional upgrade)

### AI Functions
1. **Bank Statement Vision Analysis**
   - Extracts: monthly revenue, daily balances, NSF count, negative days
   - Detects: recurring funding debits, large deposits, cash flow patterns
   - Generates: internal summary + funder-safe summary

2. **Driver License OCR**
   - Extracts: name, address, DOB, license number, expiration

3. **Legal Risk Scanning**
   - Searches: court cases, liens, UCC filings, bankruptcies, news mentions
   - Returns: risk findings with source links

4. **Context-Aware Chatbot**
   - Role-based quick actions (Client, Worker, Credit Specialist, Admin)
   - Route-aware suggestions
   - Credit repair confidentiality guardrails

### AI Confidentiality Rules
- **Credit repair methods NEVER disclosed** to clients/workers/ISO partners
- Only admin sees internal tactics/dispute strategies
- Clients see only: stages, timelines, progress
- AI assistant enforces guardrails: no dispute templates, law codes, or bureau tactics

---

## Storage Buckets

### 1. `fast-track-documents` (private)
Bank statements, driver licenses, EIN, SSN, void checks, credit card statements

### 2. `loan-application-documents` (private)
Loan application supporting documents

### 3. `credit-repair-documents` (private)
Credit reports, dispute letters, bureau correspondence

### 4. `iso-partner-documents` (private)
ISO agreements, underwriting samples

### 5. `lead-imports` (private)
Lead import staging files

### 6. `lead-lists` (private)
Uploaded lead list files

### 7. `lead-files` (private)
Lead-related documents

### 8. `deal-contracts` (private)
Executed deal contracts

### 9. `wolf_documents` (private)
Internal Wolf system documents

### 10. `templates-library` (private)
Document and messaging templates

### 11. `generated-documents` (private)
Generated contracts and artifacts

### 12. `template-uploads` (private)
Template upload storage

**RLS Policies:**
- Authenticated users can INSERT (upload)
- Only admin role can SELECT (view) and DELETE

---

## Security & Authentication

### Row Level Security (RLS)
All tables have RLS enabled with role-based policies:
- Clients: see only their own data
- Workers: see only their own submissions
- Credit Specialists: see only assigned cases
- Admin: see all data

### Authentication Flow
1. User signs up → email verification required (6-digit code)
2. Default role: "client" (auto-approved)
3. Worker role: requires admin approval
4. Credit specialist role: manually assigned by admin
5. Admin role: manually assigned (only syustay@gmail.com initially)

### Secrets Management
All API keys stored as Supabase secrets:
- AI_GATEWAY_API_KEY (auto-provisioned)
- RESEND_API_KEY
- TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN, TWILIO_PHONE_NUMBER
- DOCUSIGN_INTEGRATION_KEY, DOCUSIGN_SECRET_KEY, DOCUSIGN_ACCOUNT_ID
- SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY (auto-provisioned)

### CAPTCHA
Google reCAPTCHA v2 on signup/login (site key in VITE_RECAPTCHA_SITE_KEY)

---

## Mobile Responsiveness

### Design Patterns
- Full-screen sheets on mobile (not centered modals)
- Safe area padding for iOS Safari bottom bar
- Stacked vertical buttons (44x44px minimum touch targets)
- Collapsible sections on small screens
- Floating Help widget with drag functionality

### Critical Mobile Fixes Applied
- Application details modal: full-screen on mobile
- Underwriting reports: scrollable with fixed action buttons
- Kanban board: horizontal scroll on mobile
- Navigation: hamburger menu

---

## Design System

### Color Tokens (HSL)
Defined in `src/index.css` and `tailwind.config.ts`:
- `--background` - soft off-white/light gray (220 20% 96%)
- `--foreground` - navy blue text
- `--primary` - vibrant gold accents
- `--secondary` - rich navy blue
- `--muted` - light gray surfaces
- `--accent` - gold highlights
- `--destructive` - error red
- `--border` - subtle borders

### Typography
- Headlines: bold, distinctive display font
- Body: refined sans-serif
- Semantic classes: `.text-foreground`, `.bg-background`

### Animations
- Framer Motion for page transitions
- Pulse animation on Help widget
- Hover scale effects on interactive elements

---

## Analytics & Reporting

### Admin Reports Dashboard (`/admin-reports`)
1. **Total Funding by Month** - from application_transactions
2. **New Applications by Type per Week** - intake flow tracking
3. **Active vs Completed Credit Repair Cases** - pipeline status
4. **Conversion Metric** - cases completed → new apps created (closed-loop effectiveness)

### AI Learning Stats
- Corrections by field (funding detection, risk level, company names)
- Accuracy improvement over time
- Recent corrections log

---

## Environment Variables

### Frontend (.env)
```
VITE_SUPABASE_URL=https://tdzuhcswrojlleeupqvd.supabase.co
VITE_SUPABASE_PUBLISHABLE_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
VITE_SUPABASE_PROJECT_ID=tdzuhcswrojlleeupqvd
VITE_RECAPTCHA_SITE_KEY=<production-recaptcha-key>
```

### Backend (Supabase Secrets)
Managed via Supabase dashboard, auto-injected into edge functions

---

## Deployment

### Frontend
- Hosted on Cloud hosting
- Auto-deploys on git push
- Custom domain support (requires paid plan)

### Backend
- Edge functions auto-deploy with code changes
- No manual deployment steps required
- JWT verification enabled on protected functions

### Database
- Managed by Cloud hosting (Supabase)
- Automatic backups
- Point-in-time recovery

---

## Future Enhancements

### Planned Features
- PDF report generation (Sprint 8)
- Advanced funder analytics
- Mobile app (React Native)
- Client portal self-service document upload
- Automated legal risk monitoring alerts

### Optimization Opportunities
- Implement Redis caching for underwriting results
- Optimize bank statement Vision AI token usage
- Batch email sending for funder notifications
- Real-time dashboard updates via WebSockets

---

## Support & Maintenance

### Super Admin
- Email: syustay@gmail.com
- Full platform access
- Hidden notes in credit repair activity log
- Override all permissions

### Monitoring
- Supabase logs for edge function errors
- Application status tracking
- Follow-up reminder system (20-day cadence)

### Backup Strategy
- Connect to GitHub for version control
- Export database via Supabase dashboard
- Document storage: automatic backups

---

## Contact
For technical questions or platform issues, contact the development team or refer to the AI Gateway documentation at https://docs.wolf-fund.com/
