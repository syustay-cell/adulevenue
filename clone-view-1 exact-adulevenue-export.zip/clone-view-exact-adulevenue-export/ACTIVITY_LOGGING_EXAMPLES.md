# Activity Logging Examples

The Live Activity Command Center on `/admin` now tracks all important events with actor roles, decisions, and target users.

## How to Log Activity

Import the activity logger:

```typescript
import { ActivityLogger } from '@/lib/activityLogger';
```

## Common Scenarios

### 1. New Application Submitted

```typescript
// When a user submits a Fast Track application
await ActivityLogger.newApplication({
  actor_email: user.email,
  actor_role: 'worker', // or 'user', 'admin'
  target_email: application.email,
  application_type: 'fast_track',
  application_id: application.id,
  business_name: application.business_name,
  amount: '50000',
});
```

### 2. Application Status Change

```typescript
// When admin changes application status
await ActivityLogger.statusChange({
  actor_email: 'admin@wolf-fund.com',
  actor_role: 'admin',
  target_email: application.email,
  application_id: application.id,
  from_status: 'pending',
  to_status: 'approved',
  application_type: 'fast_track',
});
```

### 3. Worker/ISO Approval

```typescript
// When admin approves an ISO partner
await ActivityLogger.workerApproval({
  admin_email: 'admin@wolf-fund.com',
  admin_role: 'admin',
  worker_email: 'newiso@example.com',
  worker_user_id: userId,
  approved: true,
  worker_type: 'iso',
});

// When admin denies a worker
await ActivityLogger.workerApproval({
  admin_email: 'admin@wolf-fund.com',
  admin_role: 'admin',
  worker_email: 'candidate@example.com',
  worker_user_id: userId,
  approved: false,
  reason: 'Insufficient experience',
  worker_type: 'worker',
});
```

### 4. Credit Repair Case Update

```typescript
// When specialist moves a case through the pipeline
await ActivityLogger.creditCaseUpdate({
  actor_email: 'specialist@wolf-fund.com',
  actor_role: 'credit_repair_specialist',
  target_email: case.client_email,
  case_id: case.id,
  from_status: 'intake',
  to_status: 'investigation',
  update_type: 'pipeline_progress',
});
```

### 5. Custom Activity (Direct logActivity)

```typescript
import { logActivity } from '@/lib/activityLogger';

// For custom events not covered by helpers
await logActivity({
  actor_email: 'admin@wolf-fund.com',
  actor_role: 'admin',
  target_email: 'client@example.com',
  event_type: 'funding', // or 'credit_repair', 'lead', 'permission'
  context_type: 'funding_case',
  context_id: applicationId,
  decision: 'approved', // or 'denied', 'pending', 'n/a'
  decision_reason: 'Optional reason if denied',
  summary: 'Approved $50,000 funding for Test Business Inc.',
  details: {
    // Any additional structured data
    funding_amount: 50000,
    funding_type: 'MCA',
  },
});
```

## Event Types

- `new_application` - New funding application submitted
- `status_change` - Application status changed
- `permission_decision` - Permission granted/denied
- `worker_approval` - Worker/ISO partner approval decision
- `iso_approval` - ISO partner approval decision
- `credit_case_update` - Credit repair case status change
- `document_upload` - Document uploaded to application
- `call_log` - Communication/call logged

## Decision Types

- `approved` - Action was approved (green badge)
- `denied` - Action was denied (red badge)
- `pending` - Awaiting decision (yellow badge)
- `n/a` - No decision applicable (gray badge)

## Actor Roles

The `actor_role` field helps identify who performed the action:

- `admin` - Platform administrator
- `worker` - ISO partner/worker
- `credit_repair_specialist` - Credit repair specialist
- `user` - Regular client user
- `system` - Automated system action

## Backend Logging (Edge Functions)

For logging from Supabase Edge Functions, use the shared helper:

```typescript
// Import at top of edge function
import { ActivityLogger } from '../_shared/logActivity.ts';

// Example: Log funding decision
await ActivityLogger.fundingDecision({
  actorEmail: adminEmail,
  actorRole: 'admin',
  applicationId: application.id,
  clientEmail: application.email,
  clientName: application.business_name,
  decision: 'approved',
  amount: 50000,
});

// Example: Log permission change
await ActivityLogger.permissionChange({
  actorEmail: adminEmail,
  actorRole: 'admin',
  targetUserId: userId,
  targetEmail: userEmail,
  action: 'granted',
  role: 'credit_repair_specialist',
  decision: 'approved',
});
```

## Viewing Activity

Admins can view the Live Activity Command Center at `/admin`:

- **Filter by Event Type**: See only funding, credit repair, leads, or permission events
- **Filter by Decision**: See only approved, denied, or pending actions
- **Refresh Button**: Manually reload the feed
- **Real-time Updates**: Feed updates automatically via Supabase realtime subscriptions

Each activity shows:
- Time ago (e.g., "2m ago", "1h ago")
- Actor email with role badge
- Target client/user email
- Summary of what happened
- Decision badge (approved/denied/pending)
- Decision reason (if denied)

## Click-Through Behavior

**NEW**: Activity rows are now clickable! When you click an activity event:

- **Funding Events** → Opens the application details dialog
- **Credit Repair Events** → Navigates to the Credit Specialist Dashboard with that case
- **Lead Events** → Navigates to the Lead Gen Dashboard with that lead
- **User/Permission Events** → Logs user ID (future: opens user management)

This turns the Activity Command Center into a **navigation hub** - click any event to jump directly to the related record.

To enable click-through, each log must include:
- `context_type`: The entity type ('funding_case', 'credit_case', 'lead', 'user')
- `context_id`: The UUID of the related record

The activity logger helpers automatically set these fields correctly.
