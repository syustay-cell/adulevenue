#!/usr/bin/env bash
set -euo pipefail

# EP-0002: Post-deploy smoke probe for missing-table errors.
#
# Required env:
#   SUPABASE_PROJECT_REF (e.g. ochuyydjomkpxbzrnptq)
#   SUPABASE_ANON_KEY    (do NOT echo this value; do NOT commit it)
#
# Optional:
#   TABLES (space-separated list; defaults to known failing tables)

: "${SUPABASE_PROJECT_REF:?Missing SUPABASE_PROJECT_REF}"
: "${SUPABASE_ANON_KEY:?Missing SUPABASE_ANON_KEY}"

TABLES="${TABLES:-loan_applications iso_partner_applications}"
BASE="https://${SUPABASE_PROJECT_REF}.supabase.co"

fail=0
for t in ${TABLES}; do
  resp="$(curl -sS -H "apikey: ${SUPABASE_ANON_KEY}" -H "Authorization: Bearer ${SUPABASE_ANON_KEY}" \
    "${BASE}/rest/v1/${t}?select=*&limit=1" || true)"

  if echo "$resp" | rg -q "\"code\"\\s*:\\s*\"PGRST205\""; then
    echo "FAIL missing table in schema cache: public.${t}"
    fail=1
    continue
  fi

  # If it's JSON array/object without PGRST205, consider it reachable.
  if echo "$resp" | rg -q '^\[|\{'; then
    echo "OK: ${t}"
  else
    echo "WARN: ${t} unexpected response (non-JSON)."
  fi
done

exit "$fail"

