// scripts/prebuild-check.ts
// V27: Pre-build safety check for Wolf-Fund OS
// Scans src/ for dangerous patterns that could break SSR

import fs from 'fs';
import path from 'path';

const SRC_DIR = path.join(process.cwd(), 'src');

// Patterns that are dangerous at module top-level (break SSR)
const forbiddenPatterns = [
  'window.',
  'document.',
  'localStorage',
  'sessionStorage',
  'navigator.',
];

// Files that are allowed to use these patterns (entry points, etc.)
const ignoreFiles = [
  path.join(SRC_DIR, 'main.tsx'),
];

// Patterns that indicate the usage is safe (inside functions/hooks)
const safeContextPatterns = [
  'useEffect',
  'useCallback',
  'useMemo',
  'useState',
  'if (typeof window',
  "if (typeof window",
  'typeof window !==',
  "typeof window !==",
];

interface Violation {
  file: string;
  line: number;
  pattern: string;
  content: string;
}

const violations: Violation[] = [];

function isIgnored(filePath: string): boolean {
  return ignoreFiles.some(p => filePath === p);
}

function scanFile(filePath: string): void {
  const content = fs.readFileSync(filePath, 'utf8');
  const lines = content.split('\n');
  
  // Check if file has SSR guards at the top
  const hasSSRGuard = safeContextPatterns.some(pattern => content.includes(pattern));
  
  lines.forEach((line, index) => {
    // Skip comments
    if (line.trim().startsWith('//') || line.trim().startsWith('*')) {
      return;
    }
    
    forbiddenPatterns.forEach(pattern => {
      if (line.includes(pattern) && !isIgnored(filePath)) {
        // Check if this line is inside a safe context
        const isSafeLine = safeContextPatterns.some(safe => line.includes(safe));
        
        // For Supabase client, check for getStorage pattern
        if (filePath.includes('supabase/client') && content.includes('getStorage')) {
          return; // Already fixed
        }
        
        if (!isSafeLine) {
          // Check surrounding context (simple heuristic)
          const contextStart = Math.max(0, index - 5);
          const contextEnd = Math.min(lines.length, index + 2);
          const context = lines.slice(contextStart, contextEnd).join('\n');
          
          const isSafeContext = safeContextPatterns.some(safe => context.includes(safe));
          
          if (!isSafeContext) {
            violations.push({
              file: filePath.replace(process.cwd(), ''),
              line: index + 1,
              pattern,
              content: line.trim().substring(0, 100),
            });
          }
        }
      }
    });
  });
}

function walkDir(dir: string): void {
  const entries = fs.readdirSync(dir, { withFileTypes: true });
  
  for (const entry of entries) {
    const full = path.join(dir, entry.name);
    
    // Skip node_modules and build directories
    if (entry.name === 'node_modules' || entry.name === 'dist' || entry.name === '.git') {
      continue;
    }
    
    if (entry.isDirectory()) {
      walkDir(full);
    } else if (entry.isFile() && (full.endsWith('.ts') || full.endsWith('.tsx'))) {
      scanFile(full);
    }
  }
}

function main(): void {
  console.log('[prebuild-check] Scanning src/ for dangerous SSR patterns...\n');
  
  if (!fs.existsSync(SRC_DIR)) {
    console.error('[prebuild-check] ERROR: src/ directory not found');
    process.exit(1);
  }
  
  walkDir(SRC_DIR);
  
  if (violations.length === 0) {
    console.log('[prebuild-check] ✅ No SSR violations found.\n');
    console.log('[prebuild-check] Done.');
    process.exit(0);
  } else {
    console.log(`[prebuild-check] ⚠️  Found ${violations.length} potential SSR issue(s):\n`);
    
    violations.forEach((v, i) => {
      console.log(`  ${i + 1}. ${v.file}:${v.line}`);
      console.log(`     Pattern: "${v.pattern}"`);
      console.log(`     Code: ${v.content}`);
      console.log('');
    });
    
    console.log('[prebuild-check] Review these manually. If they are inside useEffect/useCallback, they are likely safe.');
    console.log('[prebuild-check] Done.');
    
    // Exit with warning but don't fail the build
    process.exit(0);
  }
}

main();
