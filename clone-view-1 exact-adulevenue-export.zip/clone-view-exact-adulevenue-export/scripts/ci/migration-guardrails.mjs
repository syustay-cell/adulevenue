import { execSync } from "node:child_process";
import fs from "node:fs";

function sh(cmd) {
  return execSync(cmd, { encoding: "utf8", stdio: ["ignore", "pipe", "pipe"] }).trim();
}

function getDiffRange() {
  const base = process.env.BASE_SHA?.trim();
  const head = (process.env.HEAD_SHA?.trim() || "HEAD").trim();

  let diffRange;
  if (base && base !== "0000000000000000000000000000000000000000") {
    diffRange = `${base}..${head}`;
  } else {
    // Best-effort fallback (workflow_dispatch or unknown base)
    try {
      diffRange = `${sh("git rev-parse HEAD~1")}..${head}`;
    } catch {
      return null;
    }
  }
  return diffRange;
}

function getChangedMigrationFiles(diffRange) {
  if (!diffRange) return [];

  const files = sh(`git diff --name-only ${diffRange}`)
    .split("\n")
    .map((s) => s.trim())
    .filter(Boolean);

  return files.filter(
    (p) => p.startsWith("supabase/migrations/") && p.toLowerCase().endsWith(".sql"),
  );
}

function lineAt(text, idx) {
  const upto = text.slice(0, idx);
  const lineNo = upto.split("\n").length;
  const line = text.split("\n")[lineNo - 1] ?? "";
  return { lineNo, line: line.trimEnd() };
}

function addErr(errors, file, message, text, idx) {
  const { lineNo, line } = lineAt(text, idx);
  errors.push({ file, lineNo, message, line });
}

function stripSqlComments(sql) {
  // Best-effort removal of SQL comments to avoid false positives from docs/comments.
  // This is intentionally simple (not a full SQL parser).
  const noBlock = sql.replace(/\/\*[\s\S]*?\*\//g, "");
  return noBlock.replace(/--.*$/gm, "");
}

const diffRange = getDiffRange();
const files = getChangedMigrationFiles(diffRange);
if (files.length === 0) {
  process.exit(0);
}

const errors = [];

function safeGrep(cmd) {
  try {
    return sh(cmd);
  } catch (e) {
    // git grep returns exit code 1 when no matches.
    if (e && typeof e === "object" && "status" in e && e.status === 1) return "";
    throw e;
  }
}

for (const file of files) {
  // Only enforce guardrails on *newly added/modified lines* in this diff range,
  // so we don't break historical migrations that are already in production truth.
  const text = sh(`git diff -U0 ${diffRange} -- "${file}"`);
  const addedLines = text
    .split("\n")
    .filter((l) => l.startsWith("+") && !l.startsWith("+++"))
    .map((l) => l.slice(1));

  if (addedLines.length === 0) continue;

  const added = addedLines.join("\n");
  const code = stripSqlComments(added);

  // 1) Enforce canonical enum type: public.app_role (no ::app_role)
  for (const m of code.matchAll(/::\s*app_role\b/gi)) {
    addErr(
      errors,
      file,
      "Disallowed cast `::app_role`. Use `::public.app_role` (fully qualified).",
      added,
      m.index ?? 0,
    );
  }

  // 2) Enforce no text role columns for user_roles
  //    (public.user_roles.role must not be text)
  for (const m of code.matchAll(/\b(role)\s+text\b/gi)) {
    const around = code.slice(Math.max(0, (m.index ?? 0) - 2000), (m.index ?? 0) + 2000);
    if (/\bcreate\s+table\b[\s\S]*?\bpublic\.user_roles\b/i.test(around)) {
      addErr(errors, file, "public.user_roles.role must be public.app_role (not text).", added, m.index ?? 0);
    }
    if (/\balter\s+table\b[\s\S]*?\bpublic\.user_roles\b/i.test(around)) {
      addErr(errors, file, "public.user_roles.role must be public.app_role (not text).", added, m.index ?? 0);
    }
  }

  // 3) Policies/functions must never compare enum to text.
  //    Guard against the common failure shape: user_roles.role = 'admin' (missing ::public.app_role)
  for (const m of code.matchAll(/((?:public\.)?user_roles\.role)\s*=\s*'[^']+'\s*(?!::)/gi)) {
    addErr(
      errors,
      file,
      "Found untyped literal compared to user_roles.role. Use `'x'::public.app_role`.",
      added,
      m.index ?? 0,
    );
  }
  for (const m of code.matchAll(/\bur\.role\s*=\s*'[^']+'\s*(?!::)/gi)) {
    addErr(
      errors,
      file,
      "Found untyped literal compared to ur.role (enum). Use `'x'::public.app_role` or compare `ur.role::text` if absolutely necessary.",
      added,
      m.index ?? 0,
    );
  }

  // 4) Canonical helper: no new has_role(..., text) overloads.
  for (const m of code.matchAll(/create\s+or\s+replace\s+function\s+public\.has_role\s*\([^)]*\btext\b[^)]*\)/gi)) {
    addErr(
      errors,
      file,
      "Disallowed: introducing a has_role() text overload. Canonical is has_role(user_id uuid, required_role public.app_role).",
      added,
      m.index ?? 0,
    );
  }

  // 5) Calls must use typed enum literal in the second arg.
  //    Guard against has_role(auth.uid(), 'admin') and friends in new migrations.
  for (const m of code.matchAll(/has_role\s*\(\s*[^,]+,\s*'[^']+'\s*\)/gim)) {
    const snippet = m[0];
    if (!/::\s*public\.app_role\b/i.test(snippet)) {
      addErr(
        errors,
        file,
        "has_role() must be called with a typed enum literal: has_role(auth.uid(), 'admin'::public.app_role).",
        added,
        m.index ?? 0,
      );
    }
  }

  // 6) Policy dependency audit: any ALTER COLUMN ... TYPE should include policy drop/recreate scaffolding.
  const alters = [...code.matchAll(/\balter\s+table\b[\s\S]*?\balter\s+column\b[\s\S]*?\btype\b/gi)];
  if (alters.length > 0) {
    const hasPolicyHandling =
      /\bdrop\s+policy\b/i.test(code) || /\bpg_policy\b/i.test(code) || /\bpg_get_expr\b/i.test(code);
    if (!hasPolicyHandling) {
      addErr(
        errors,
        file,
        "ALTER COLUMN TYPE detected without any DROP POLICY / pg_policy capture logic. Add drop+recreate of dependent policies before the type change.",
        added,
        alters[0].index ?? 0,
      );
    }
  }
}

// Repo-wide preflight (fail if any forbidden patterns exist anywhere in supabase/**/*.sql)
// These are hard blockers because they can break after user_roles.role becomes enum.
const preflightChecks = [
  {
    cmd: `git grep -n -F "(?:" -- "supabase/migrations/*.sql"`,
    message: "Disallowed PCRE token '(?:' found in migrations (Postgres regex is not PCRE).",
  },
  {
    cmd: `git grep -n -F "(?=" -- "supabase/migrations/*.sql"`,
    message: "Disallowed PCRE lookahead '(?=' found in migrations (Postgres regex is not PCRE).",
  },
  {
    cmd: `git grep -n -F "(?!" -- "supabase/migrations/*.sql"`,
    message: "Disallowed PCRE negative lookahead '(?!' found in migrations (Postgres regex is not PCRE).",
  },
  {
    cmd: `git grep -n -F "(?<=" -- "supabase/migrations/*.sql"`,
    message: "Disallowed PCRE lookbehind '(?<=' found in migrations (Postgres regex is not PCRE).",
  },
  {
    cmd: `git grep -n -F "(?<!" -- "supabase/migrations/*.sql"`,
    message: "Disallowed PCRE negative lookbehind '(?<!' found in migrations (Postgres regex is not PCRE).",
  },
  {
    cmd: `git grep -n "user_roles\\\\.role[^;]*::text" -- "supabase/**/*.sql"`,
    message: "Disallowed ::text usage on/near user_roles.role in supabase SQL.",
  },
  {
    cmd: `git grep -n "user_roles\\\\.role\\\\s*=\\\\s*\\\\(auth\\\\.jwt\\\\(\\\\)\\\\s*->>\\\\s*'role'\\\\)" -- "supabase/**/*.sql"`,
    message: "Disallowed uncast jwt claim comparison to user_roles.role in supabase SQL.",
  },
  {
    cmd: `git grep -n "user_roles\\\\.role\\\\s*=\\\\s*auth\\\\.jwt\\\\(\\\\)\\\\s*->>\\\\s*'role'" -- "supabase/**/*.sql"`,
    message: "Disallowed uncast jwt claim comparison to user_roles.role in supabase SQL.",
  },
  {
    cmd: `git grep -n "user_roles\\\\.role\\\\s*=\\\\s*current_setting\\\\(\\\\s*'request\\\\.jwt\\\\.claim\\\\.role'\\\\s*,\\\\s*true\\\\s*\\\\)" -- "supabase/**/*.sql"`,
    message: "Disallowed uncast current_setting role comparison to user_roles.role in supabase SQL.",
  },
  {
    cmd: `git grep -n "app_role\\\\s*=\\\\s*text" -- "supabase/**/*.sql"`,
    message: "Disallowed app_role = text comparison pattern in supabase SQL.",
  },
];

for (const c of preflightChecks) {
  const out = safeGrep(c.cmd);
  if (out) {
    console.error(`\nPreflight failed: ${c.message}\n`);
    console.error(out);
    process.exit(1);
  }
}

if (errors.length > 0) {
  console.error("Migration guardrails failed. Fix these issues:\n");
  for (const e of errors) {
    console.error(`- ${e.file}:${e.lineNo} ${e.message}`);
    console.error(`    ${e.line}\n`);
  }
  process.exit(1);
}

process.exit(0);

