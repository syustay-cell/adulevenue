# Wolf Fund

## Project info

**URL**: https://wolf-fund.com/8d6ec2c3-29d7-4b0a-a70c-939f4a33d947

## How can I edit this code?

There are several ways of editing your application.

**Use the app**

Simply visit the [AI Gateway Project](https://wolf-fund.com/8d6ec2c3-29d7-4b0a-a70c-939f4a33d947) and start prompting.

Changes made via AI Gateway will be committed automatically to this repo.

**Use your preferred IDE**

If you want to work locally using your own IDE, you can clone this repo and push changes. Pushed changes will also be reflected in AI Gateway.

The only requirement is having Node.js & npm installed - [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating)

Follow these steps:

```sh
# Step 1: Clone the repository using the project's Git URL.
git clone <YOUR_GIT_URL>

# Step 2: Navigate to the project directory.
cd <YOUR_PROJECT_NAME>

# Step 3: Install the necessary dependencies.
npm i

# Step 4: Start the development server with auto-reloading and an instant preview.
npm run dev
```

**Edit a file directly in GitHub**

- Navigate to the desired file(s).
- Click the "Edit" button (pencil icon) at the top right of the file view.
- Make your changes and commit the changes.

**Use GitHub Codespaces**

- Navigate to the main page of your repository.
- Click on the "Code" button (green button) near the top right.
- Select the "Codespaces" tab.
- Click on "New codespace" to launch a new Codespace environment.
- Edit files directly within the Codespace and commit and push your changes once you're done.

## What technologies are used for this project?

This project is built with:

- Vite
- TypeScript
- React
- shadcn-ui
- Tailwind CSS

## How can I deploy this project?

Simply open [AI Gateway](https://wolf-fund.com/8d6ec2c3-29d7-4b0a-a70c-939f4a33d947) and click on Share -> Publish.

## Can I connect a custom domain to my AI Gateway project?

Yes, you can!

To connect a domain, navigate to Project > Settings > Domains and click Connect Domain.

Read more here: [Setting up a custom domain](https://docs.wolf-fund.com/features/custom-domain#custom-domain)
