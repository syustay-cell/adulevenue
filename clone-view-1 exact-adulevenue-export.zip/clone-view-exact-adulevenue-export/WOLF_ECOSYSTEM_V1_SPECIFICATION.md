# 🐺 WOLF ECOSYSTEM — VERSION 1 OFFICIAL SPECIFICATION

**Complete system blueprint for Wolf Fund Capital — Wolf Back Office**

> **Version:** 1.1 (Schema Aligned)  
> **Last Updated:** December 2, 2025  
> **Status:** ✅ PRODUCTION READY — Schema Aligned with Spec

---

## ⚡ IMPLEMENTATION STATUS — SCHEMA MAPPING

### ✅ Tables Created & Aligned

| Spec Name | Actual Table | Status |
|-----------|--------------|--------|
| `users` | `profiles` | ✅ Created - links to auth.users |
| `lead_lists` | `lead_lists` | ✅ Exists |
| `leads` | `leads` | ✅ Full spec columns |
| `calls` | `calls` | ✅ Created |
| `credit_cases` | `credit_repair_cases` | ✅ Exists |
| `fast_track_applications` | `fast_track_applications` | ✅ Exists |
| `ai_events` | `ai_events` | ✅ Exists |
| `underwriting_cases` | `underwriting_cases` | ✅ Exists |
| `lead_notes` | `lead_notes` | ✅ Created |
| `lead_events` | `lead_events` | ✅ Created |
| `funding_records` | `funding_records` (view) | ✅ View over funded_contracts |
| `tasks` | `tasks` (view) | ✅ Unified view over all task tables |

### ✅ Edge Functions (156 total in export)

| Function | Purpose | Status |
|----------|---------|--------|
| `process-lead-list` | Excel parsing, header mapping, routing | ✅ |
| `wolf-brain-lead-intake` | AI scoring & path recommendation | ✅ |
| `wolf-research-intel` | Deep enrichment & OCM intelligence | ✅ |
| `wolf-assistant` | In-app AI help | ✅ |
| `credit-repair-*` | 6 functions for credit workflow | ✅ |
| `underwriter-*` | Analysis & assistant | ✅ |
| `send-to-funder` | Funder CRM workflow | ✅ |
| Plus 140+ more | Notifications, DocuSign, billing, etc. | ✅ |

**Note:** The authoritative export list is `exports/05_EDGE_FUNCTIONS_INDEX.md` (156 functions as of 2025-12-14). The repo may include additional function directories not yet reflected in that export.

### 🗂️ Storage Buckets

- `fast-track-documents` - Application docs
- `loan-application-documents` - Loan docs
- `credit-repair-documents` - Credit docs
- `iso-partner-documents` - ISO agreements
- `lead-imports` - Import staging
- `lead-lists` - Lead file uploads
- `lead-files` - Lead documents
- `deal-contracts` - Executed contracts
- `wolf_documents` - Internal system documents
- `templates-library` - Template library assets
- `generated-documents` - Generated contract/doc outputs
- `template-uploads` - Template upload staging

**Source of truth:** `exports/02_STORAGE_BUCKETS.md` (12 buckets as of 2025-12-14).

---

## 0. System Overview

**Project:** Wolf Fund Capital — Wolf Back Office

**Goal:** One unified ecosystem combining:
- Public site (services, intake, ISO)
- Lead Engine V3 (imports, AI scoring, routing)
- Smart Dialer V3 (exclusive windows, lock logic)
- Research Q V3 (deep enrichment & OCM logic)
- Credit Fix Studio (credit cases)
- Fast Track Funding (apps + docs)
- Underwriter & Funding Cycle
- Shared pipeline dashboard + role-based access

Everything runs off the same Supabase project and shared leads/clients/applications tables.

---

## 1. User Roles & Permissions

| Role | Access |
|------|--------|
| **Admin** | Full control of platform, manage workers & ISOs, manage dialer queues, see all analytics & reports, override lead routing |
| **ISO Partner** | Gets their own leads only, can assign to Wolf dialers, can track their commissions, access to ISO dashboard |
| **Workers (Dialers)** | Work dialer queue, see enriched profile, log call outcomes, trigger intake send |
| **Researchers** | Work Research Q only, approve enriched results, fix mapping errors, mark duplicates/fraud/dead |
| **Underwriters** | See leads only once intake is complete, run pipeline: Review → Docs → Run File, send doc requests, create offers |
| **Funding Manager** | Tracks funded deals, oversees doc send, coordinates funding calls |
| **Credit Repair Staff** | Works leads tagged "credit_first" or "repair_needed", sends repair intake, tracks cases |
| **AI Worker** | Auto-follow-ups, auto-email replies, data enrichment, lead routing assistance |

---

## 2. Lead Lifecycle State Machine

Every lead follows this pipeline:

```
new → enriched → research_pending → research_completed → dialer_queue → dialer_connected → intake_sent → intake_completed → underwriting → docs_requested → docs_uploaded → file_run → offers_sent → funded → (if declined or poor credit → credit_repair)
```

This is a state machine controlled by backend rules. Workers don't manually move leads — the system does.

---

## 3. Core Database Schema (Supabase/Postgres)

### 3.1 users

```sql
create table users (
  id uuid primary key default gen_random_uuid(),
  email text unique not null,
  full_name text,
  role text not null check (role in ('admin','iso','worker','underwriter','viewer')),
  status text not null default 'active',
  phone text,
  created_at timestamptz default now()
);
```

### 3.2 lead_lists (uploaded files)

```sql
create table lead_lists (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  file_name text,
  status text not null default 'pending', -- pending|processing|completed|failed
  total_rows int,
  processed_rows int,
  dialer_count int,
  email_count int,
  research_count int,
  rejected_count int,
  header_confidence int,   -- 0–100
  field_coverage int,      -- 0–100
  header_mapping jsonb,
  processing_summary jsonb,
  source_type text,        -- 'ocm_upload' | 'generic' | ...
  raw_headers text[],
  import_quality_score int,
  created_by uuid references users(id),
  created_at timestamptz default now()
);
```

### 3.3 leads (Core Brain)

```sql
create table leads (
  id uuid primary key default gen_random_uuid(),
  lead_list_id uuid references lead_lists(id),

  -- basic identity
  full_name text,
  business_name text,
  email text,
  phone text,
  address text,
  city text,
  state text,
  zip text,

  -- routing + status
  status text not null default 'new',        -- new|contacted|working|disqualified|converted
  route text,                                -- dialer|email|research
  import_bucket text,                        -- mirrors route
  import_confidence_score int,               -- 0–100
  research_status text,                      -- pending|in_progress|done
  missing_phone boolean,
  missing_email boolean,

  -- AI lead brain
  ai_score int,
  ai_priority text,                          -- A|B|C
  ai_recommended_path text,                  -- fast_track_funding|credit_fix_first|hybrid_path|do_not_work
  ai_risk_flags text[],
  ai_last_evaluated_at timestamptz,
  ai_notes jsonb,

  -- Enriched profile (Research Q)
  enriched_name text,
  enriched_business_name text,
  enriched_phone text,
  enriched_email text,
  enriched_address text,
  enriched_city text,
  enriched_state text,
  enriched_zip text,
  enriched_business_age_years numeric,
  enriched_estimated_revenue numeric,
  enriched_industry text,
  funding_score numeric,
  funding_recommendation text,
  credit_risk text,
  identity_theft_risk text,
  industry_risk text,

  -- OCM / Cannabis fields
  ocm_license_id text,
  ocm_license_type text,
  ocm_status text,
  ocm_municipality text,
  ocm_expiration_date date,

  -- audit / raw
  normalized_fields jsonb,
  raw_data jsonb,
  source text,
  notes text,
  problem_flags text[],

  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

-- Indexes
CREATE INDEX idx_leads_status ON leads(status);
CREATE INDEX idx_leads_route ON leads(route);
CREATE INDEX idx_leads_ai_score ON leads(ai_score DESC);
CREATE INDEX idx_leads_lead_list_id ON leads(lead_list_id);
CREATE INDEX idx_leads_ocm_license_id ON leads(ocm_license_id);
```

### 3.4 calls (dialer logs)

```sql
create table calls (
  id uuid primary key default gen_random_uuid(),
  lead_id uuid references leads(id),
  user_id uuid references users(id),
  outcome text not null,        -- connected|no_answer|voicemail|not_interested|wrong_number|callback
  notes text,
  scheduled_callback_at timestamptz,
  created_at timestamptz default now()
);
```

### 3.5 credit_cases (Credit Fix Studio)

```sql
create table credit_cases (
  id uuid primary key default gen_random_uuid(),
  lead_id uuid references leads(id),
  client_id uuid,   -- optional if you split leads/clients later
  status text not null default 'intake',  -- intake|active|paused|completed
  plan text,        -- dispute only / identity theft / full clean
  ai_score int,
  ai_risk_flags text[],
  notes jsonb,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);
```

### 3.6 fast_track_applications

```sql
create table fast_track_applications (
  id uuid primary key default gen_random_uuid(),
  lead_id uuid references leads(id),
  iso_id uuid references users(id),
  status text not null default 'draft',      -- draft|submitted|underwriting|approved|declined|funded
  requested_amount numeric,
  product_type text,
  docs jsonb,               -- bank statements, IDs, etc.
  ai_score int,
  ai_recommended_path text,
  underwriter_id uuid references users(id),
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);
```

### 3.7 ai_events (audit log)

```sql
create table ai_events (
  id uuid primary key default gen_random_uuid(),
  entity_type text not null,                 -- 'lead'|'application'|'credit_case'
  entity_id uuid not null,
  model_name text,
  event_type text,                           -- 'intake'|'research'|'update'
  payload_in jsonb,
  payload_out jsonb,
  created_at timestamptz default now()
);
```

### 3.8 lead_events (Audit trail)

```sql
create table lead_events (
  id uuid primary key default gen_random_uuid(),
  lead_id uuid references leads(id),
  event_type text not null, -- created, research_run, call_logged, intake_sent, docs_uploaded, etc.
  created_by uuid references users(id),
  metadata jsonb,
  created_at timestamptz default now()
);
```

### 3.9 lead_notes

```sql
create table lead_notes (
  id uuid primary key default gen_random_uuid(),
  lead_id uuid references leads(id),
  author_id uuid references users(id),
  note text,
  type text, -- call_notes, underwriter_note, research_note, mystic_tips
  created_at timestamptz default now()
);
```

### 3.10 lead_documents

```sql
create table lead_documents (
  id uuid primary key default gen_random_uuid(),
  lead_id uuid references leads(id),
  category text, -- bank_statement, id, contract, proof_of_address, other
  url text,
  uploaded_by uuid references users(id),
  uploaded_at timestamptz default now(),
  status text default 'pending_review' -- pending_review, verified, rejected
);
```

### 3.11 underwriting_cases

```sql
create table underwriting_cases (
  id uuid primary key default gen_random_uuid(),
  lead_id uuid references leads(id),
  assigned_underwriter_id uuid references users(id),
  stage text default 'review', -- review, docs, file_run, offer, funded, declined
  reason_declined text,
  offer_data jsonb,
  lender_id uuid,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);
```

### 3.12 funding_records

```sql
create table funding_records (
  id uuid primary key default gen_random_uuid(),
  lead_id uuid references leads(id),
  underwriting_case_id uuid references underwriting_cases(id),
  amount_funded numeric,
  product_type text,
  date_funded timestamptz,
  iso_commission_amount numeric,
  worker_commission_amount numeric,
  notes text
);
```

### 3.13 tasks

```sql
create table tasks (
  id uuid primary key default gen_random_uuid(),
  lead_id uuid references leads(id),
  assigned_to uuid references users(id),
  type text, -- callback, funding_call, doc_followup
  due_at timestamptz,
  status text default 'open', -- open, done, cancelled
  created_by uuid references users(id),
  created_at timestamptz default now()
);
```

---

## 4. Key Edge Functions (TypeScript)

### 4.1 process-lead-list (Excel → leads)

**Responsible for:**
- Reading Excel/CSV
- Mapping headers smartly
- Building normalized_fields
- Assigning route (dialer / email / research)
- Computing rowConfidence and import_quality_score
- Filling OCM fields when source is OCM

```typescript
// supabase/functions/process-lead-list/index.ts
import { serve } from "https://deno.land/std/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import * as XLSX from "https://esm.sh/xlsx@0.18.5";

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { status: 204 });
  if (req.method !== "POST") return new Response("Method not allowed", { status: 405 });

  const { list_id, file_path } = await req.json();
  const supabase = createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
  );

  try {
    // 1) download file from storage
    const { data: file, error: fileError } = await supabase.storage
      .from("lead-lists")
      .download(file_path);
    if (fileError || !file) throw fileError;

    const buffer = await file.arrayBuffer();
    const workbook = XLSX.read(buffer, { type: "array" });
    const sheet = workbook.Sheets[workbook.SheetNames[0]];
    const rows = XLSX.utils.sheet_to_json<any[]>(sheet, { header: 1 });

    // 2) detect header row + headers
    const headerRowIdx = 0;
    const headers = (rows[headerRowIdx] || []).map((h) => String(h || "").trim());
    const dataRows = rows.slice(headerRowIdx + 1);

    const { mapping, confidence, details } = mapHeaders(headers);
    const sourceType = detectSourceType(headers, mapping);
    const rawHeaders = headers.filter((h) => h.length > 0);

    let dialerCount = 0, emailCount = 0, researchCount = 0, rejectedCount = 0;
    let hasPhoneCount = 0, hasEmailCount = 0;
    let totalRows = 0;

    for (const row of dataRows) {
      totalRows++;
      const normalized = buildNormalizedFields(row, headers, mapping, sourceType);
      const rowConfidence = computeRowConfidence({
        businessName: normalized.business_name,
        contactName: normalized.contact_name,
        phone: normalized.phone,
        email: normalized.email,
        city: normalized.city,
        state: normalized.state,
        licenseNumber: normalized.license_number,
        expiration: normalized.expiration_date,
      });

      const { route, reason } = decideRoute(normalized);
      if (route === "reject") {
        rejectedCount++;
        continue;
      }

      const rawData: Record<string, unknown> = {
        original_row: row,
        original_headers: headers,
        row_index: totalRows,
        mapping_used: details,
        normalized,
        routing: { route, reason },
        confidence_score: rowConfidence,
      };

      if (normalized.phone) hasPhoneCount++;
      if (normalized.email) hasEmailCount++;
      if (route === "dialer") dialerCount++;
      if (route === "email") emailCount++;
      if (route === "research") researchCount++;

      const leadPayload: any = {
        lead_list_id: list_id,
        full_name: normalized.contact_name,
        business_name: normalized.business_name,
        email: normalized.email,
        phone: normalized.phone,
        address: normalized.address,
        city: normalized.city,
        state: normalized.state,
        zip: normalized.zip,
        route,
        import_bucket: route,
        import_confidence_score: rowConfidence,
        normalized_fields: normalized,
        research_status: route === "research" ? "pending" : null,
        missing_phone: !normalized.phone,
        missing_email: !normalized.email,
        raw_data: rawData,
        source: sourceType,
        // Enriched initial mirror
        enriched_name: normalized.contact_name,
        enriched_business_name: normalized.business_name,
        enriched_phone: normalized.phone,
        enriched_email: normalized.email,
        enriched_address: normalized.address,
        enriched_city: normalized.city,
        enriched_state: normalized.state,
        enriched_zip: normalized.zip,
      };

      // OCM specific
      if (sourceType === "ocm_upload") {
        leadPayload.ocm_license_id = normalized.license_number;
        leadPayload.ocm_license_type = normalized.license_type;
        leadPayload.ocm_status = normalized.license_status;
        leadPayload.ocm_municipality = normalized.municipality;
        leadPayload.ocm_expiration_date = normalized.expiration_date;
      }

      const { error: insertError } = await supabase.from("leads").insert(leadPayload).single();
      if (insertError) console.error("Insert lead error", insertError);
    }

    const processedCount = dialerCount + emailCount + researchCount;
    const fieldCoverage = processedCount > 0
      ? Math.round(((hasPhoneCount + hasEmailCount) / (processedCount * 2)) * 100)
      : 0;
    const importQualityScore = processedCount > 0
      ? Math.round((dialerCount / processedCount) * 100 * 0.6 + fieldCoverage * 0.4)
      : 0;

    const processingSummary: Record<string, unknown> = {
      total_rows: totalRows,
      processed: processedCount,
      dialer: dialerCount,
      email_only: emailCount,
      research: researchCount,
      rejected: rejectedCount,
      with_valid_phone: hasPhoneCount,
      with_valid_email: hasEmailCount,
      coverage: {
        phone_pct: processedCount ? Math.round((hasPhoneCount / processedCount) * 100) : 0,
        email_pct: processedCount ? Math.round((hasEmailCount / processedCount) * 100) : 0,
      },
      header_mapping: details,
      header_confidence: confidence / 100,
      field_coverage: fieldCoverage / 100,
      source_detected: sourceType,
    };

    if (sourceType === "ocm_upload") {
      processingSummary["ocm_completion"] = {
        license_number: processedCount ? (processedCount - rejectedCount) / processedCount : 0,
      };
    }

    await supabase.from("lead_lists")
      .update({
        status: "completed",
        total_rows: totalRows,
        processed_rows: processedCount,
        dialer_count: dialerCount,
        email_count: emailCount,
        research_count: researchCount,
        rejected_count: rejectedCount,
        header_confidence: confidence,
        field_coverage: fieldCoverage,
        header_mapping: details,
        processing_summary: processingSummary,
        source_type: sourceType,
        raw_headers: rawHeaders,
        import_quality_score: importQualityScore,
      })
      .eq("id", list_id);

    return new Response(JSON.stringify({ ok: true }), { headers: { "Content-Type": "application/json" } });
  } catch (e) {
    console.error(e);
    return new Response(JSON.stringify({ error: String(e) }), { status: 500 });
  }
});

// Helper functions: mapHeaders, detectSourceType, buildNormalizedFields, computeRowConfidence, decideRoute
// (Implementation details in existing process-lead-list/index.ts)
```

### 4.2 wolf-brain-lead-intake (AI pathing)

```typescript
// supabase/functions/wolf-brain-lead-intake/index.ts
import { serve } from "https://deno.land/std/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

type LeadBrainInput = {
  lead_id: string;
  source: string;
  raw_data: Record<string, unknown>;
};

type LeadBrainOutput = {
  ai_score: number;
  ai_priority: "A" | "B" | "C";
  ai_recommended_path: "fast_track_funding" | "credit_fix_first" | "hybrid_path" | "do_not_work";
  ai_risk_flags: string[];
  ai_notes: Record<string, unknown>;
};

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { status: 204 });
  if (req.method !== "POST") return new Response("Method not allowed", { status: 405 });

  const supabase = createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
  );

  try {
    const payload = await req.json() as LeadBrainInput;

    const { data: lead, error: leadError } = await supabase
      .from("leads")
      .select("*")
      .eq("id", payload.lead_id)
      .maybeSingle();

    if (leadError || !lead) {
      return new Response(JSON.stringify({ error: "lead_not_found" }), { status: 404 });
    }

    const aiResult = await runLeadBrainLLM({
      lead,
      source: payload.source,
      raw_data: payload.raw_data,
    });

    await supabase.from("leads")
      .update({
        ai_score: aiResult.ai_score,
        ai_priority: aiResult.ai_priority,
        ai_recommended_path: aiResult.ai_recommended_path,
        ai_risk_flags: aiResult.ai_risk_flags,
        ai_notes: aiResult.ai_notes,
        ai_last_evaluated_at: new Date().toISOString(),
      })
      .eq("id", payload.lead_id);

    await supabase.from("ai_events").insert({
      entity_type: "lead",
      entity_id: lead.id,
      model_name: "wolf-brain-v1",
      event_type: "intake",
      payload_in: payload,
      payload_out: aiResult,
    });

    return new Response(JSON.stringify({ success: true, ai: aiResult }), {
      headers: { "Content-Type": "application/json" },
    });
  } catch (e) {
    console.error(e);
    return new Response(JSON.stringify({ error: String(e) }), { status: 500 });
  }
});

async function runLeadBrainLLM(ctx: {
  lead: any;
  source: string;
  raw_data: Record<string, unknown>;
}): Promise<LeadBrainOutput> {
  // Heuristic version or GPT-4 prompt integration
  // See existing implementation for full logic
  return {
    ai_score: 70,
    ai_priority: "B",
    ai_recommended_path: "fast_track_funding",
    ai_risk_flags: [],
    ai_notes: { reason: "placeholder" },
  };
}
```

### 4.3 wolf-research-intel (Research Q V3)

```typescript
// POST /functions/v1/wolf-research-intel
type ResearchInput = { lead_id: string };
type ResearchOutput = {
  funding_score: number;
  funding_recommendation: string;
  credit_risk: string;
  identity_theft_risk: string;
  business_age_years: number | null;
  estimated_revenue: number | null;
  enriched: Record<string, unknown>;
};
```

**Implementation:**
- Load leads row
- Call enrichment APIs (or stub them for now)
- Call OpenAI / heuristic computeIntelUsingAI
- Update leads enriched fields
- Log in ai_events
- Return JSON used by the Research Q modal

---

## 5. Frontend Architecture

### 5.1 Global Layout & Navigation

**Top nav:** Wolf logo, "Wolf Fund Capital"

**Main sections:**
- Services (public)
- How It Works (public)
- Credit Repair (public)
- Become an ISO Partner (public)
- Lead Engine
- Dialer
- Credit Fix Studio
- My Pipeline
- Admin (admins only)

Use role-based gating (admin vs iso vs worker vs underwriter).

### 5.2 Screen Specifications

#### 5.2.1 Lead Engine V3

**Tabs:**

1. **Call Queue**
   - Smart Dialer V3 card:
     - Start Calling / Stop Calling toggle
     - "Exclusive window: 7 days left" indicator
     - "Next Lead to Call" card (AI Score, Priority, Path)
     - "Up Next" list (sorted by ai_score desc, created_at asc)

2. **Lead Lists**
   - Table: Name, Status, Created Date, Source badge, Quality badge
   - Click row → side panel with processing summary

3. **Research Queue**
   - Table of leads with route='research' and research_status='pending'
   - Each row → "Run Research" button → opens Research Q modal

#### 5.2.2 Lead Dialer

- Top summary: Queue count, Today's calls, Status
- "Start Session" / "Stop Session" button
- Current Lead card with:
  - Skip must move to next lead
  - Outcome buttons update calls + leads.status

#### 5.2.3 Research Q Modal

Full profile display backed by real data from wolf-research-intel.

---

## 6. Flowcharts

### 6.1 Lead Lifecycle

```
1. Upload file → lead_lists row (status='pending')
2. Trigger process-lead-list:
   - Parse file → create leads
   - Update lead_lists metrics + import_quality_score
3. For each new lead:
   - Call wolf-brain-lead-intake → fill AI fields
4. Routing:
   - route='dialer' → Smart Dialer queue
   - route='email' → future email engine
   - route='research' → Research Queue
5. From Dialer:
   - Call outcome:
     - connected + interested → create fast_track_applications or credit_cases depending on AI path
     - not interested → status='disqualified'
     - callback → schedule in calls.scheduled_callback_at
6. From Research:
   - Run Research Q → enrich lead
   - If good → change route to dialer or email
```

### 6.2 Unified Dashboard Concept

**"My Pipeline" screen:**
- Cards for each client/lead where:
  - Has active fast-track app OR credit case OR both
- For each card:
  - Name, business, status tags: Funding, Credit Repair, Hybrid, Pending, Moved_to_credit_repair etc.
  - Buttons: Call Client, Open Application, Open Credit Case

**Backed by:**
- Join on leads + fast_track_applications + credit_cases

---

## 7. API Endpoints Summary

| Endpoint | Method | Purpose |
|----------|--------|---------|
| `/functions/v1/process-lead-list` | POST | Parse Excel/CSV, create leads, assign routes |
| `/functions/v1/wolf-brain-lead-intake` | POST | AI scoring and path recommendation |
| `/functions/v1/wolf-research-intel` | POST | Deep enrichment + AI intelligence |
| `/functions/v1/dialer-next-lead` | POST | Get next lead for worker with locking |
| `/functions/v1/dialer-log-call` | POST | Log call outcome, update lead status |
| `/functions/v1/send-intake` | POST | Send intake link to lead |
| `/functions/v1/intake-completed-webhook` | POST | Handle completed intake submissions |
| `/functions/v1/underwriting-transition` | POST | Move underwriting case through stages |
| `/functions/v1/credit-case-transition` | POST | Move credit repair case through stages |
| `/functions/v1/tasks-complete` | POST | Mark tasks as done |

---

## 8. System Rules (Automation)

### Auto-routing:
- Missing phone/email → research
- High funding score → dialer
- Low credit score → credit repair
- Completed intake → underwriting
- Docs uploaded → file_run
- Funded → archive

### Auto-deduplication:
- Email match
- Phone match
- Business name match
- License ID match

### Auto-sync:
All actions update all dashboards live.

---

## 9. UI Wireframes Summary

### 9.1 Global Layout (Back Office)

**Pattern:**
- Top bar: logo 🐺 WOLF FUND, user avatar, role switcher
- Left side nav (collapsible):
  - Home / Pipeline
  - Lead Engine
  - Research Q
  - Dialer
  - Underwriting
  - Credit Fix Studio
  - OCM Intel
  - ISO Partners
  - Admin
  - Settings

### 9.2 Home / Pipeline (/app/home)

**Layout:**
- Header row cards (4 big tiles): Total Leads, In Dialer Queue, In Underwriting, In Credit Repair
- Second row: funnel bar (New → Enriched → Dialer → Intake Sent → Underwriting → Docs → Funded)
- Main section: "My Pipeline" table
  - Columns: Lead/Business, Source, Stage, AI Path, Owner, Next Action
  - Row click → Lead Detail panel (slide-in from right)
- Right sidebar: Today's Tasks, Notifications

### 9.3 Underwriting – Queue & Case (/underwriting)

**Queue view:**
- Filters: Stage, Product type, Worker
- Table columns: Lead/Business, Path, Stage, ISO/Worker, Docs status, AI Risk, Last action

**Case view (split screen):**
- Left column: File Summary (lead profile, AI score, bank statements, existing advances)
- Middle column: Underwriter Actions (stage dropdown, buttons: Request Docs, Run File, Add Offer, Mark Declined)
- Right column: Timeline & Notes

### 9.4 Credit Fix Studio (/credit-fix)

- Top cards: Active cases, Ready for disputes, Waiting on client, Completed
- Case list: Client, Source lead, Est. score tier, Identity theft flag, Stage

### 9.5 OCM Intel (/ocm)

- Filters: County, Municipality, License type, Status
- Cards: Active licenses, Expiring in 90 days, Retail vs Micro
- Table: License holder, License ID, Expiration, Municipality, Match to Wolf leads?

### 9.6 ISO Portal (/iso)

- Metrics: Leads submitted, Leads in process, Funded deals, Commissions
- Table of their leads only

### 9.7 Admin: Users & Settings (/admin)

**Tabs:**
- Users & Roles
- Lead Routes
- System Settings

---

## 10. What's Still Missing / Next Modules

When ready, devs should implement:

1. **Underwriter 3-way cycle**
   - Exclusive assignment + share/50-50 logic
   - "Send to Underwriter" from Fast Track
   - Underwriters panel with: Run File, Send Docs, Funding Call

2. **ISO / Worker management**
   - On /admin/users:
     - User row → name, email, role, position (ISO / Worker / Underwriter)
     - Toggle permissions

3. **Real Tel provider integration**
   - Twilio / Aircall / Cloudtalk:
     - Replace tel: links with actual API calls & webhooks
     - Inbound status updates

4. **Email Engine**
   - Buckets: missing phone but email present → drip campaigns

5. **More powerful Research Q**
   - Plug in actual APIs (Clearbit etc.)
   - Better prompts for GPT-4o

---

## 11. Final Result

A system that:
- ✅ Feels like Salesforce + Nav + CreditRepairCloud + MerchantCenter in one app
- ✅ Runs an entire funding company end-to-end
- ✅ Workers only see what they need (no confusion)
- ✅ AI fills all missing information
- ✅ Dialer becomes fully automated
- ✅ Underwriting becomes fast
- ✅ OCM cannabis becomes a separate vertical
- ✅ ISO partners can be scaled
- ✅ Credit repair becomes integrated, not separate

---

**THIS IS THE WOLF ECOSYSTEM V1 SPECIFICATION.**

*Forward this document to your dev team for implementation.*
