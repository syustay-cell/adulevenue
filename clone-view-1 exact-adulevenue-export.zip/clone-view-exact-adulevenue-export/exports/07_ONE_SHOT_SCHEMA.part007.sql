-- =================================================================
-- MIGRATION: 20251203013241_c99f7c13-c387-4968-8654-32f3efafa68e.sql
-- =================================================================

-- Create outreach_tasks table for follow-up reminders (separate from existing tasks view)
CREATE TABLE IF NOT EXISTS public.outreach_tasks (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  task_type text NOT NULL,
  title text NOT NULL,
  description text,
  assigned_to_user_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  case_id uuid REFERENCES public.underwriting_cases(id) ON DELETE SET NULL,
  lead_id uuid REFERENCES public.leads(id) ON DELETE SET NULL,
  message_id uuid REFERENCES public.messages_sent(id) ON DELETE SET NULL,
  status text NOT NULL DEFAULT 'open' CHECK (status IN ('open', 'in_progress', 'completed', 'cancelled')),
  priority text DEFAULT 'normal' CHECK (priority IN ('low', 'normal', 'high', 'urgent')),
  due_at timestamptz,
  completed_at timestamptz,
  meta jsonb DEFAULT '{}'::jsonb,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS on outreach_tasks
ALTER TABLE public.outreach_tasks ENABLE ROW LEVEL SECURITY;

-- Outreach Tasks RLS Policies
CREATE POLICY "Admins can manage all outreach tasks"
  ON public.outreach_tasks FOR ALL
  USING (has_role(auth.uid(), 'admin'::public.app_role));

CREATE POLICY "Workers can view assigned outreach tasks"
  ON public.outreach_tasks FOR SELECT
  USING (assigned_to_user_id = auth.uid() OR has_role(auth.uid(), 'admin'::public.app_role) OR has_role(auth.uid(), 'worker'::public.app_role));

CREATE POLICY "Workers can update assigned outreach tasks"
  ON public.outreach_tasks FOR UPDATE
  USING (assigned_to_user_id = auth.uid() OR has_role(auth.uid(), 'admin'::public.app_role));

CREATE POLICY "System can insert outreach tasks"
  ON public.outreach_tasks FOR INSERT
  WITH CHECK (true);

-- Indexes for outreach_tasks
CREATE INDEX IF NOT EXISTS idx_outreach_tasks_assigned_to ON public.outreach_tasks(assigned_to_user_id);
CREATE INDEX IF NOT EXISTS idx_outreach_tasks_status ON public.outreach_tasks(status) WHERE status = 'open';
CREATE INDEX IF NOT EXISTS idx_outreach_tasks_due_at ON public.outreach_tasks(due_at) WHERE status = 'open';

-- Trigger for updated_at
CREATE TRIGGER update_outreach_tasks_updated_at
  BEFORE UPDATE ON public.outreach_tasks
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_updated_at();

-- Add trigger for messages_sent updated_at
CREATE TRIGGER update_messages_sent_updated_at
  BEFORE UPDATE ON public.messages_sent
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_updated_at();

-- =================================================================
-- MIGRATION: 20251203014114_7cfbf2ee-6154-4512-9b5a-fa6d81528f75.sql
-- =================================================================
-- V6: Add missing columns to messages_sent for full spec compliance
ALTER TABLE public.messages_sent 
ADD COLUMN IF NOT EXISTS subject text,
ADD COLUMN IF NOT EXISTS body text,
ADD COLUMN IF NOT EXISTS replied_at timestamptz;

-- Add provider columns if missing
ALTER TABLE public.messages_sent 
ADD COLUMN IF NOT EXISTS provider_message_id text,
ADD COLUMN IF NOT EXISTS provider_meta jsonb DEFAULT '{}'::jsonb;

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_messages_sent_reply_due_at ON public.messages_sent (reply_due_at) WHERE reply_due_at IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_messages_sent_status ON public.messages_sent (status);
CREATE INDEX IF NOT EXISTS idx_messages_sent_direction ON public.messages_sent (direction);
CREATE INDEX IF NOT EXISTS idx_messages_sent_lead_id ON public.messages_sent (lead_id);
CREATE INDEX IF NOT EXISTS idx_messages_sent_case_id ON public.messages_sent (case_id);

-- Add index on outreach_tasks for cron efficiency
CREATE INDEX IF NOT EXISTS idx_outreach_tasks_status ON public.outreach_tasks (status);
CREATE INDEX IF NOT EXISTS idx_outreach_tasks_message_id ON public.outreach_tasks (message_id);

-- =================================================================
-- MIGRATION: 20251203015235_2d327daf-92ac-4aaa-9ea5-ecca96febdbe.sql
-- =================================================================
-- Create outreach_tasks table for follow-up tracking
CREATE TABLE IF NOT EXISTS public.outreach_tasks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  message_id uuid REFERENCES public.messages_sent(id) ON DELETE CASCADE,
  case_id uuid,
  client_id uuid,
  lead_id uuid REFERENCES public.leads(id) ON DELETE SET NULL,
  
  assigned_to_user_id uuid,
  status text NOT NULL DEFAULT 'pending',
  type text NOT NULL DEFAULT 'follow_up',
  
  due_at timestamptz NOT NULL,
  completed_at timestamptz,
  meta jsonb DEFAULT '{}'::jsonb,
  
  created_at timestamptz NOT NULL DEFAULT now()
);

-- Indexes for efficient querying
CREATE INDEX IF NOT EXISTS idx_outreach_tasks_status_due ON public.outreach_tasks (status, due_at);
CREATE INDEX IF NOT EXISTS idx_outreach_tasks_assigned ON public.outreach_tasks (assigned_to_user_id, status);
CREATE INDEX IF NOT EXISTS idx_outreach_tasks_lead ON public.outreach_tasks (lead_id);
CREATE INDEX IF NOT EXISTS idx_outreach_tasks_message ON public.outreach_tasks (message_id);

-- Enable RLS
ALTER TABLE public.outreach_tasks ENABLE ROW LEVEL SECURITY;

-- Admin full access
CREATE POLICY "outreach_tasks_admin_full" ON public.outreach_tasks
FOR ALL USING (
  EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = auth.uid() AND role = 'admin')
);

-- Workers can see their assigned tasks
CREATE POLICY "outreach_tasks_workers_own" ON public.outreach_tasks
FOR SELECT USING (assigned_to_user_id = auth.uid());

-- Workers can update their own tasks
CREATE POLICY "outreach_tasks_workers_update" ON public.outreach_tasks
FOR UPDATE USING (assigned_to_user_id = auth.uid());

-- =================================================================
-- MIGRATION: 20251203024056_9b503f94-d08b-4764-8c8c-5396e8fe3046.sql
-- =================================================================
-- Add new_phone column for AI-discovered phone numbers
ALTER TABLE public.leads ADD COLUMN IF NOT EXISTS new_phone TEXT;

-- =================================================================
-- MIGRATION: 20251203025404_56689448-12f5-472f-9e10-cca7a887726f.sql
-- =================================================================
-- Create research_center_stats RPC function
CREATE OR REPLACE FUNCTION research_center_stats(p_lead_list_id uuid DEFAULT NULL)
RETURNS json
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  result json;
  today_start timestamp with time zone := date_trunc('day', now());
BEGIN
  SELECT json_build_object(
    'in_research', (
      SELECT count(*) FROM leads
      WHERE (email IS NULL OR email = '')
        AND (p_lead_list_id IS NULL OR lead_list_id = p_lead_list_id)
    ),
    'fixed_today', (
      SELECT count(*) FROM leads
      WHERE updated_at >= today_start
        AND email IS NOT NULL AND email <> ''
        AND (import_bucket IN ('dialer', 'email') OR route IN ('dialer', 'email', 'credit_fix'))
        AND (p_lead_list_id IS NULL OR lead_list_id = p_lead_list_id)
    ),
    'routed_dialer', (
      SELECT count(*) FROM leads
      WHERE updated_at >= today_start
        AND (import_bucket = 'dialer' OR route = 'dialer')
        AND (p_lead_list_id IS NULL OR lead_list_id = p_lead_list_id)
    ),
    'routed_email', (
      SELECT count(*) FROM leads
      WHERE updated_at >= today_start
        AND (import_bucket = 'email' OR route = 'email')
        AND (p_lead_list_id IS NULL OR lead_list_id = p_lead_list_id)
    )
  ) INTO result;
  
  RETURN result;
END;
$$;

-- Grant execute permission
GRANT EXECUTE ON FUNCTION research_center_stats(uuid) TO authenticated;

-- =================================================================
-- MIGRATION: 20251203033732_26b51e9e-2b2c-4bc0-b038-7a4bcb7f4eab.sql
-- =================================================================
-- intake_clients (master client record from research)
CREATE TABLE IF NOT EXISTS intake_clients (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id uuid REFERENCES leads(id),

  -- Identity
  full_name text,
  business_name text,
  phone_primary text,
  phone_secondary text,
  email_primary text,
  email_secondary text,
  website text,

  -- Location
  address text,
  city text,
  state text,
  zip text,

  -- Source & routing
  intake_source text,
  stage text,
  primary_path text,

  -- AI intel snapshot
  ai_funding_score int,
  ai_funding_path text,
  ai_credit_risk text,
  ai_identity_theft_risk text,
  ai_industry_risk text,

  ai_summary jsonb,
  ai_created_at timestamptz DEFAULT now(),

  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_intake_clients_lead_id ON intake_clients(lead_id);
CREATE INDEX IF NOT EXISTS idx_intake_clients_stage ON intake_clients(stage);

-- Enable RLS
ALTER TABLE intake_clients ENABLE ROW LEVEL SECURITY;

-- RLS policies for intake_clients
CREATE POLICY "Admins can manage intake_clients" ON intake_clients
  FOR ALL USING (has_role(auth.uid(), 'admin'::public.app_role));

CREATE POLICY "Workers can view intake_clients" ON intake_clients
  FOR SELECT USING (has_role(auth.uid(), 'worker'::public.app_role) OR has_role(auth.uid(), 'admin'::public.app_role));

CREATE POLICY "System can insert intake_clients" ON intake_clients
  FOR INSERT WITH CHECK (true);

CREATE POLICY "System can update intake_clients" ON intake_clients
  FOR UPDATE USING (true);

-- sms_messages
CREATE TABLE IF NOT EXISTS sms_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id uuid REFERENCES leads(id),
  client_id uuid REFERENCES intake_clients(id),

  direction text CHECK (direction IN ('outbound','inbound')) DEFAULT 'outbound',
  phone_from text,
  phone_to text,
  body text,

  status text,
  channel text,

  created_at timestamptz DEFAULT now(),
  created_by uuid REFERENCES auth.users(id)
);

CREATE INDEX IF NOT EXISTS idx_sms_lead ON sms_messages(lead_id);
CREATE INDEX IF NOT EXISTS idx_sms_client ON sms_messages(client_id);

-- Enable RLS
ALTER TABLE sms_messages ENABLE ROW LEVEL SECURITY;

-- RLS policies for sms_messages
CREATE POLICY "Workers can view sms_messages" ON sms_messages
  FOR SELECT USING (has_role(auth.uid(), 'worker'::public.app_role) OR has_role(auth.uid(), 'admin'::public.app_role));

CREATE POLICY "Workers can insert sms_messages" ON sms_messages
  FOR INSERT WITH CHECK (has_role(auth.uid(), 'worker'::public.app_role) OR has_role(auth.uid(), 'admin'::public.app_role));

CREATE POLICY "System can insert sms_messages" ON sms_messages
  FOR INSERT WITH CHECK (true);

-- email_messages
CREATE TABLE IF NOT EXISTS email_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id uuid REFERENCES leads(id),
  client_id uuid REFERENCES intake_clients(id),

  direction text CHECK (direction IN ('outbound','inbound')) DEFAULT 'outbound',
  email_from text,
  email_to text,
  subject text,
  body text,

  status text,
  channel text,

  created_at timestamptz DEFAULT now(),
  created_by uuid REFERENCES auth.users(id)
);

CREATE INDEX IF NOT EXISTS idx_email_lead ON email_messages(lead_id);
CREATE INDEX IF NOT EXISTS idx_email_client ON email_messages(client_id);

-- Enable RLS
ALTER TABLE email_messages ENABLE ROW LEVEL SECURITY;

-- RLS policies for email_messages
CREATE POLICY "Workers can view email_messages" ON email_messages
  FOR SELECT USING (has_role(auth.uid(), 'worker'::public.app_role) OR has_role(auth.uid(), 'admin'::public.app_role));

CREATE POLICY "Workers can insert email_messages" ON email_messages
  FOR INSERT WITH CHECK (has_role(auth.uid(), 'worker'::public.app_role) OR has_role(auth.uid(), 'admin'::public.app_role));

CREATE POLICY "System can insert email_messages" ON email_messages
  FOR INSERT WITH CHECK (true);

-- =================================================================
-- MIGRATION: 20251203035945_58796b61-38fa-4b06-9f44-5af15b1cf1b7.sql
-- =================================================================
-- Wolf Hub Chat System Tables

-- Conversations table
CREATE TABLE IF NOT EXISTS public.conversations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  type text NOT NULL CHECK (type IN ('client', 'internal')) DEFAULT 'client',
  client_user_id uuid REFERENCES auth.users(id),
  lead_id uuid REFERENCES public.leads(id),
  credit_case_id uuid REFERENCES public.credit_repair_cases(id),
  department text NOT NULL CHECK (department IN ('admin', 'funding', 'underwriting', 'credit_fix', 'general')) DEFAULT 'general',
  assigned_worker_id uuid REFERENCES auth.users(id),
  status text NOT NULL CHECK (status IN ('open', 'pending', 'closed')) DEFAULT 'open',
  subject text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- Conversation participants
CREATE TABLE IF NOT EXISTS public.conversation_participants (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  conversation_id uuid NOT NULL REFERENCES public.conversations(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES auth.users(id),
  role text NOT NULL CHECK (role IN ('client', 'admin', 'worker', 'underwriter', 'credit_fix')),
  can_reply boolean NOT NULL DEFAULT true,
  joined_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(conversation_id, user_id)
);

-- Chat messages
CREATE TABLE IF NOT EXISTS public.chat_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  conversation_id uuid NOT NULL REFERENCES public.conversations(id) ON DELETE CASCADE,
  sender_id uuid NOT NULL REFERENCES auth.users(id),
  sender_role text NOT NULL,
  body text NOT NULL,
  is_internal_note boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);

-- User online status tracking (extend profiles or create new)
CREATE TABLE IF NOT EXISTS public.user_presence (
  user_id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  is_online boolean NOT NULL DEFAULT false,
  last_active_at timestamptz NOT NULL DEFAULT now(),
  active_client_chats integer NOT NULL DEFAULT 0,
  last_assigned_at timestamptz
);

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_conversations_client ON public.conversations(client_user_id);
CREATE INDEX IF NOT EXISTS idx_conversations_department ON public.conversations(department);
CREATE INDEX IF NOT EXISTS idx_conversations_status ON public.conversations(status);
CREATE INDEX IF NOT EXISTS idx_conversations_assigned ON public.conversations(assigned_worker_id);
CREATE INDEX IF NOT EXISTS idx_chat_messages_conversation ON public.chat_messages(conversation_id);
CREATE INDEX IF NOT EXISTS idx_chat_messages_created ON public.chat_messages(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_user_presence_online ON public.user_presence(is_online, last_active_at);

-- Enable RLS
ALTER TABLE public.conversations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.conversation_participants ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.chat_messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_presence ENABLE ROW LEVEL SECURITY;

-- RLS Policies for conversations
CREATE POLICY "Clients can view own conversations" ON public.conversations
  FOR SELECT USING (client_user_id = auth.uid());

CREATE POLICY "Admins can view all conversations" ON public.conversations
  FOR SELECT USING (has_role(auth.uid(), 'admin'::public.app_role));

CREATE POLICY "Workers can view assigned conversations" ON public.conversations
  FOR SELECT USING (
    assigned_worker_id = auth.uid() OR
    EXISTS (
      SELECT 1 FROM conversation_participants cp 
      WHERE cp.conversation_id = id AND cp.user_id = auth.uid()
    )
  );

CREATE POLICY "System can insert conversations" ON public.conversations
  FOR INSERT WITH CHECK (true);

CREATE POLICY "System can update conversations" ON public.conversations
  FOR UPDATE USING (true);

-- RLS Policies for participants
CREATE POLICY "Users can view participants of their conversations" ON public.conversation_participants
  FOR SELECT USING (
    user_id = auth.uid() OR
    EXISTS (
      SELECT 1 FROM conversations c 
      WHERE c.id = conversation_id AND (
        c.client_user_id = auth.uid() OR
        c.assigned_worker_id = auth.uid() OR
        has_role(auth.uid(), 'admin'::public.app_role)
      )
    )
  );

CREATE POLICY "System can manage participants" ON public.conversation_participants
  FOR ALL USING (true);

-- RLS Policies for messages
CREATE POLICY "Users can view messages in their conversations" ON public.chat_messages
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM conversation_participants cp 
      WHERE cp.conversation_id = chat_messages.conversation_id 
      AND cp.user_id = auth.uid()
    ) OR
    EXISTS (
      SELECT 1 FROM conversations c 
      WHERE c.id = chat_messages.conversation_id 
      AND (c.client_user_id = auth.uid() OR has_role(auth.uid(), 'admin'::public.app_role))
    )
  );

CREATE POLICY "Participants can send messages" ON public.chat_messages
  FOR INSERT WITH CHECK (
    sender_id = auth.uid() AND
    EXISTS (
      SELECT 1 FROM conversation_participants cp 
      WHERE cp.conversation_id = chat_messages.conversation_id 
      AND cp.user_id = auth.uid() 
      AND cp.can_reply = true
    )
  );

CREATE POLICY "System can insert messages" ON public.chat_messages
  FOR INSERT WITH CHECK (true);

-- RLS for user presence
CREATE POLICY "Users can view online status" ON public.user_presence
  FOR SELECT USING (true);

CREATE POLICY "Users can update own presence" ON public.user_presence
  FOR ALL USING (user_id = auth.uid() OR has_role(auth.uid(), 'admin'::public.app_role));

-- Enable realtime for chat
ALTER PUBLICATION supabase_realtime ADD TABLE public.chat_messages;
ALTER PUBLICATION supabase_realtime ADD TABLE public.conversations;

-- Trigger for updated_at
CREATE TRIGGER update_conversations_updated_at
  BEFORE UPDATE ON public.conversations
  FOR EACH ROW EXECUTE FUNCTION public.handle_updated_at();

-- =================================================================
-- MIGRATION: 20251204035040_45729880-9721-46b2-8c2b-69baef6820eb.sql
-- =================================================================
-- Wolf Motherboard Phase 1: Central Control System

-- Master configuration table (global settings/switches)
CREATE TABLE IF NOT EXISTS public.wolf_master_config (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  key TEXT UNIQUE NOT NULL,
  value JSONB NOT NULL DEFAULT '{}'::jsonb,
  description TEXT,
  category TEXT DEFAULT 'general',
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- Flow rules table (routing/security/funder rules)
CREATE TABLE IF NOT EXISTS public.wolf_flow_rules (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  is_active BOOLEAN DEFAULT true,
  rule_type TEXT NOT NULL, -- 'routing', 'funder', 'security', 'deal_protection'
  priority INTEGER DEFAULT 100,
  conditions JSONB NOT NULL DEFAULT '{}'::jsonb,
  actions JSONB NOT NULL DEFAULT '{}'::jsonb,
  description TEXT,
  created_by UUID REFERENCES auth.users(id),
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- Health log table (system diagnostics)
CREATE TABLE IF NOT EXISTS public.wolf_health_log (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  component TEXT NOT NULL,
  severity TEXT NOT NULL CHECK (severity IN ('info', 'warning', 'error', 'critical')),
  message TEXT NOT NULL,
  details JSONB,
  resolved BOOLEAN DEFAULT false,
  resolved_at TIMESTAMPTZ,
  resolved_by UUID REFERENCES auth.users(id),
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Feature flags table
CREATE TABLE IF NOT EXISTS public.wolf_feature_flags (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  feature_key TEXT UNIQUE NOT NULL,
  is_enabled BOOLEAN DEFAULT true,
  disabled_reason TEXT,
  disabled_at TIMESTAMPTZ,
  disabled_by UUID REFERENCES auth.users(id),
  auto_disabled BOOLEAN DEFAULT false,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.wolf_master_config ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.wolf_flow_rules ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.wolf_health_log ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.wolf_feature_flags ENABLE ROW LEVEL SECURITY;

-- RLS Policies - Admin only
CREATE POLICY "Admin full access to wolf_master_config" ON public.wolf_master_config
  FOR ALL USING (has_role(auth.uid(), 'admin'::public.app_role));

CREATE POLICY "Admin full access to wolf_flow_rules" ON public.wolf_flow_rules
  FOR ALL USING (has_role(auth.uid(), 'admin'::public.app_role));

CREATE POLICY "Admin full access to wolf_health_log" ON public.wolf_health_log
  FOR ALL USING (has_role(auth.uid(), 'admin'::public.app_role));

CREATE POLICY "Admin full access to wolf_feature_flags" ON public.wolf_feature_flags
  FOR ALL USING (has_role(auth.uid(), 'admin'::public.app_role));

-- System can insert health logs
CREATE POLICY "System can insert health logs" ON public.wolf_health_log
  FOR INSERT WITH CHECK (true);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_wolf_health_log_component ON public.wolf_health_log(component);
CREATE INDEX IF NOT EXISTS idx_wolf_health_log_severity ON public.wolf_health_log(severity);
CREATE INDEX IF NOT EXISTS idx_wolf_health_log_created_at ON public.wolf_health_log(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_wolf_flow_rules_type ON public.wolf_flow_rules(rule_type);
CREATE INDEX IF NOT EXISTS idx_wolf_flow_rules_active ON public.wolf_flow_rules(is_active);
CREATE INDEX IF NOT EXISTS idx_wolf_feature_flags_key ON public.wolf_feature_flags(feature_key);

-- Insert default config values
INSERT INTO public.wolf_master_config (key, value, description, category) VALUES
  ('ai_summary_version', '"v5"', 'Current AI summary version to use', 'ai'),
  ('max_funders_per_submission', '3', 'Maximum funders a deal can be sent to at once', 'funder'),
  ('min_credit_score_for_funding', '580', 'Minimum credit score to route directly to funding', 'routing'),
  ('max_existing_advances', '2', 'Maximum existing advances before blocking Tier A funders', 'funder'),
  ('enable_auto_credit_fix_routing', 'true', 'Automatically route low-score leads to credit fix', 'routing'),
  ('mask_client_email_for_funders', 'true', 'Hide full email from funders', 'security'),
  ('mask_client_phone_for_funders', 'true', 'Hide full phone from funders (show last 4)', 'security'),
  ('mask_client_ssn_for_funders', 'true', 'Always mask SSN for funders', 'security')
ON CONFLICT (key) DO NOTHING;

-- Insert default feature flags
INSERT INTO public.wolf_feature_flags (feature_key, is_enabled) VALUES
  ('save_intake_route', true),
  ('research_copilot', true),
  ('credit_fix_strategy', true),
  ('send_to_funder', true),
  ('ai_underwriting', true),
  ('smart_sms', true),
  ('smart_email', true),
  ('legal_lab_scan', true)
ON CONFLICT (feature_key) DO NOTHING;

-- Insert default flow rules
INSERT INTO public.wolf_flow_rules (name, rule_type, priority, conditions, actions, description) VALUES
  ('Low Credit to Credit Fix', 'routing', 10, 
   '{"credit_score_below": 580}', 
   '{"route_to": "credit_fix_first"}',
   'Route leads with credit score below 580 to credit fix first'),
  ('High Advances Block Tier A', 'funder', 20,
   '{"existing_advances_above": 2, "nsf_count_above": 3}',
   '{"block_tiers": ["tier_a", "tier_b"]}',
   'Block Tier A/B funders when client has too many advances'),
  ('Max Funder Blast Protection', 'deal_protection', 5,
   '{"always": true}',
   '{"max_simultaneous_submissions": 3}',
   'Never send a client to more than 3 funders at once'),
  ('Funder Info Masking', 'security', 1,
   '{"recipient_type": "funder"}',
   '{"mask_fields": ["email", "phone", "ssn", "full_address"]}',
   'Always mask sensitive client info from funders')
ON CONFLICT DO NOTHING;

-- =================================================================
-- MIGRATION: 20251204040703_ee3f7435-7cec-41cc-82fa-2de08ad7cbb7.sql
-- =================================================================
-- Phase 2.1: Routing Brain - Add description column and seed data

-- Add description column to wolf_feature_flags if missing
ALTER TABLE public.wolf_feature_flags ADD COLUMN IF NOT EXISTS description TEXT;

-- Insert default routing rules into wolf_flow_rules
INSERT INTO public.wolf_flow_rules (name, is_active, rule_type, priority, conditions, actions, description) VALUES
-- Credit score routing
('Credit Score Under 550 → Credit Fix First', true, 'routing', 10, 
 '{"field": "credit_score", "operator": "<", "value": 550}',
 '{"route_to": "credit_fix", "block_funding": true, "reason": "Credit score too low for direct funding"}',
 'Clients with credit score under 550 must go through credit repair before funding'),

('Credit Score 550-620 → Hybrid Path', true, 'routing', 20,
 '{"field": "credit_score", "operator": "between", "min": 550, "max": 620}',
 '{"route_to": "hybrid", "flag_for_review": true, "reason": "Borderline credit - may need credit work"}',
 'Borderline credit clients flagged for manual review'),

('Credit Score 620+ → Funding Eligible', true, 'routing', 30,
 '{"field": "credit_score", "operator": ">=", "value": 620}',
 '{"route_to": "funding_first", "block_funding": false}',
 'Good credit clients can proceed to funding'),

-- Over-leverage protection
('Over 3 Open Advances → Block Tier A/B Funders', true, 'funder_restriction', 40,
 '{"field": "existing_advances_count", "operator": ">", "value": 3}',
 '{"block_funder_tiers": ["A", "B"], "max_funder_exposure": 2, "reason": "Over-leveraged client"}',
 'Clients with 3+ open advances restricted from premium funders'),

('Over 2 Open Advances → Limit Funder Exposure', true, 'funder_restriction', 50,
 '{"field": "existing_advances_count", "operator": ">", "value": 2}',
 '{"max_funder_exposure": 3, "reason": "Multiple existing positions"}',
 'Limit simultaneous funder exposure for clients with existing debt'),

-- NSF protection
('High NSF Count → Credit Fix Required', true, 'routing', 60,
 '{"field": "nsf_count_90d", "operator": ">", "value": 5}',
 '{"route_to": "credit_fix", "flag_risk": "high_nsf", "reason": "Too many NSFs in last 90 days"}',
 'High NSF activity requires credit stabilization first'),

-- Funder exposure limits
('Max 5 Funders Per Deal', true, 'security', 70,
 '{"field": "active_funder_submissions", "operator": ">", "value": 5}',
 '{"block_new_submissions": true, "reason": "Maximum funder exposure reached"}',
 'Prevent blasting deals to too many funders'),

-- Anti-backdoor rule
('Funder Contact Restriction', true, 'security', 80,
 '{"always": true}',
 '{"require_wolf_communication": true, "block_direct_contact": true, "mask_client_identity": true}',
 'All funder-client communication must go through Wolf')

ON CONFLICT DO NOTHING;

-- Insert Wolf Vault config settings
INSERT INTO public.wolf_master_config (key, value, description, category) VALUES
('funder_default_masking', '{"mask_name": true, "mask_phone": true, "mask_email": true, "mask_address": true, "show_last4_phone": true}', 
 'Default masking settings for funder portal', 'wolf_vault'),

('funder_export_allowed', 'false', 
 'Whether funders can export client data (default: no)', 'wolf_vault'),

('max_funder_exposure', '5', 
 'Maximum number of funders a single deal can be sent to', 'deal_protection'),

('routing_credit_threshold_low', '550', 
 'Credit score below this requires credit fix first', 'routing'),

('routing_credit_threshold_medium', '620', 
 'Credit score below this is hybrid path', 'routing'),

('max_open_advances_for_premium', '3', 
 'Max open advances allowed for Tier A/B funders', 'deal_protection'),

('require_wolf_communication', 'true', 
 'Require all funder-client communication through Wolf', 'wolf_vault')

ON CONFLICT (key) DO NOTHING;

-- Insert Wolf Vault feature flags (without description since we just added it)
INSERT INTO public.wolf_feature_flags (feature_key, is_enabled, description) VALUES
('funder_vault_masking', true, 'Enable identity masking for funder portal'),
('funder_export_block', true, 'Block all client data exports for funders'),
('routing_brain_active', true, 'Enable automatic routing based on flow rules'),
('funder_call_bridge', false, 'Route funder calls through Wolf dialer (Phase 2.3)'),
('funder_contract_delivery', false, 'Wolf-controlled contract delivery (Phase 2.3)')
ON CONFLICT (feature_key) DO NOTHING;

-- =================================================================
-- MIGRATION: 20251204040754_2629bc00-61de-4b26-860a-8e97ca4d9413.sql
-- =================================================================
-- Phase 2.2: Wolf Vault - Client identity protection layer (FIXED ORDER)

-- First: Add columns to funders table for RLS
ALTER TABLE public.funders ADD COLUMN IF NOT EXISTS user_id UUID;
ALTER TABLE public.funders ADD COLUMN IF NOT EXISTS tier TEXT DEFAULT 'bronze';
ALTER TABLE public.funders ADD COLUMN IF NOT EXISTS no_backdoor_agreement BOOLEAN DEFAULT false;
ALTER TABLE public.funders ADD COLUMN IF NOT EXISTS agreement_signed_at TIMESTAMPTZ;

-- Client Vault: stores the true identity, funders only see vault_id
CREATE TABLE IF NOT EXISTS public.client_vault (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  vault_id TEXT UNIQUE NOT NULL DEFAULT ('WV-' || LPAD(FLOOR(RANDOM() * 100000)::TEXT, 5, '0')),
  
  -- Real client identity (NEVER exposed to funders)
  real_name TEXT,
  real_phone TEXT,
  real_email TEXT,
  real_address TEXT,
  real_city TEXT,
  real_state TEXT,
  real_zip TEXT,
  real_ssn_last4 TEXT,
  
  -- Links
  lead_id UUID REFERENCES public.leads(id),
  intake_client_id UUID REFERENCES public.intake_clients(id),
  application_id UUID,
  application_type TEXT,
  
  -- Vault settings (can override global config per client)
  masking_override JSONB DEFAULT '{}',
  
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- Deal Rooms: tracks funder-client attachments and prevents backdooring
CREATE TABLE IF NOT EXISTS public.deal_rooms (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  vault_id TEXT NOT NULL,
  funder_id UUID REFERENCES public.funders(id),
  
  -- Deal status
  status TEXT NOT NULL DEFAULT 'active',
  
  -- Funder access controls
  can_view_bank_data BOOLEAN DEFAULT false,
  can_send_offer BOOLEAN DEFAULT true,
  can_send_contract BOOLEAN DEFAULT false,
  communication_channel TEXT DEFAULT 'wolf_only',
  
  -- Anti-backdoor tracking
  funder_agreed_terms BOOLEAN DEFAULT false,
  funder_agreed_at TIMESTAMPTZ,
  no_backdoor_signed BOOLEAN DEFAULT false,
  
  -- Activity tracking
  last_funder_action_at TIMESTAMPTZ,
  total_communications INTEGER DEFAULT 0,
  
  -- Expiration
  expires_at TIMESTAMPTZ DEFAULT (now() + INTERVAL '30 days'),
  
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- Funder Communication Log: all funder-client communication through Wolf
CREATE TABLE IF NOT EXISTS public.funder_communication_log (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  deal_room_id UUID REFERENCES public.deal_rooms(id),
  funder_id UUID REFERENCES public.funders(id),
  vault_id TEXT NOT NULL,
  
  -- Communication details
  communication_type TEXT NOT NULL,
  direction TEXT NOT NULL,
  
  -- Content (sanitized, no PII in logs)
  summary TEXT,
  metadata JSONB DEFAULT '{}',
  
  -- Status
  status TEXT DEFAULT 'pending',
  delivered_at TIMESTAMPTZ,
  
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.client_vault ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.deal_rooms ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.funder_communication_log ENABLE ROW LEVEL SECURITY;

-- RLS: Client Vault - ONLY admins and system can see real data
DROP POLICY IF EXISTS "Only admins can view client vault" ON public.client_vault;
CREATE POLICY "Only admins can view client vault" ON public.client_vault
  FOR SELECT USING (has_role(auth.uid(), 'admin'::public.app_role));

DROP POLICY IF EXISTS "Only admins can manage client vault" ON public.client_vault;
CREATE POLICY "Only admins can manage client vault" ON public.client_vault
  FOR ALL USING (has_role(auth.uid(), 'admin'::public.app_role));

-- RLS: Deal Rooms - funders see only their rooms
DROP POLICY IF EXISTS "Funders see own deal rooms" ON public.deal_rooms;
CREATE POLICY "Funders see own deal rooms" ON public.deal_rooms
  FOR SELECT USING (
    has_role(auth.uid(), 'admin'::public.app_role) OR
    funder_id IN (SELECT id FROM public.funders WHERE funders.user_id = auth.uid())
  );

DROP POLICY IF EXISTS "Admins manage deal rooms" ON public.deal_rooms;
CREATE POLICY "Admins manage deal rooms" ON public.deal_rooms
  FOR ALL USING (has_role(auth.uid(), 'admin'::public.app_role));

-- RLS: Communication Log - funders see only their communications
DROP POLICY IF EXISTS "Funders see own communications" ON public.funder_communication_log;
CREATE POLICY "Funders see own communications" ON public.funder_communication_log
  FOR SELECT USING (
    has_role(auth.uid(), 'admin'::public.app_role) OR
    funder_id IN (SELECT id FROM public.funders WHERE funders.user_id = auth.uid())
  );

DROP POLICY IF EXISTS "System can insert communications" ON public.funder_communication_log;
CREATE POLICY "System can insert communications" ON public.funder_communication_log
  FOR INSERT WITH CHECK (true);

DROP POLICY IF EXISTS "Admins manage communications" ON public.funder_communication_log;
CREATE POLICY "Admins manage communications" ON public.funder_communication_log
  FOR ALL USING (has_role(auth.uid(), 'admin'::public.app_role));

-- Indexes
CREATE INDEX IF NOT EXISTS idx_client_vault_lead ON public.client_vault(lead_id);
CREATE INDEX IF NOT EXISTS idx_client_vault_vault_id ON public.client_vault(vault_id);
CREATE INDEX IF NOT EXISTS idx_deal_rooms_vault ON public.deal_rooms(vault_id);
CREATE INDEX IF NOT EXISTS idx_deal_rooms_funder ON public.deal_rooms(funder_id);

-- =================================================================
-- MIGRATION: 20251204041818_6591831f-3e20-4b6a-b8c8-3d1fd062ab2e.sql
-- =================================================================
-- Phase 2.3: Add feature flags and config for Secure Funding Bundle

-- Feature flags (correct columns: feature_key, description, is_enabled)
INSERT INTO public.wolf_feature_flags (feature_key, description, is_enabled)
VALUES 
  ('funder_call_bridge', 'Enable Twilio-based call bridging between funders and clients', false),
  ('bank_mirror_view', 'Enable sanitized bank data view for funders', false),
  ('secure_contract_flow', 'Enable AI-scanned contract upload and signing workflow', false)
ON CONFLICT (feature_key) DO NOTHING;

-- Config values (correct columns: key, value as jsonb, description, category)
INSERT INTO public.wolf_master_config (key, value, description, category)
VALUES 
  ('twilio_bridge_timeout_seconds', '"30"', 'Seconds to wait for each party to answer bridge call', 'call_bridge'),
  ('contract_ai_review_enabled', 'true', 'Whether contracts go through AI review before sending', 'contracts'),
  ('contract_expiry_days', '"7"', 'Days before unsigned contract expires', 'contracts'),
  ('max_contract_amount', '"500000"', 'Maximum contract amount allowed (fraud protection)', 'contracts'),
  ('min_factor_rate', '"1.10"', 'Minimum factor rate (predatory term detection)', 'contracts'),
  ('max_factor_rate', '"1.60"', 'Maximum factor rate (predatory term detection)', 'contracts')
ON CONFLICT (key) DO NOTHING;

-- =================================================================
-- MIGRATION: 20251204042825_2b47c96c-3590-46e2-b318-f45d7174fbf1.sql
-- =================================================================
-- Create storage bucket for deal contracts
INSERT INTO storage.buckets (id, name, public)
VALUES ('deal-contracts', 'deal-contracts', false)
ON CONFLICT (id) DO NOTHING;

-- Create storage policy for funders to upload
CREATE POLICY "Funders can upload contracts" 
ON storage.objects 
FOR INSERT 
TO authenticated
WITH CHECK (bucket_id = 'deal-contracts');

-- Create storage policy for authenticated users to read
CREATE POLICY "Authenticated users can read contracts" 
ON storage.objects 
FOR SELECT 
TO authenticated
USING (bucket_id = 'deal-contracts');

-- =================================================================
-- MIGRATION: 20251204044425_2dedddd3-037c-4dfe-a832-4de2c129818e.sql
-- =================================================================
-- Wolf Suggestions table for AI/system recommendations
CREATE TABLE IF NOT EXISTS wolf_suggestions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  type text NOT NULL,
  target text NOT NULL,
  current_value jsonb,
  suggested_value jsonb NOT NULL,
  reason text,
  risk_score int NOT NULL DEFAULT 50,
  auto_apply boolean NOT NULL DEFAULT false,
  status text NOT NULL DEFAULT 'pending',
  created_by text DEFAULT 'ai',
  created_at timestamptz NOT NULL DEFAULT now(),
  decided_by text,
  decided_at timestamptz,
  meta jsonb
);

CREATE INDEX IF NOT EXISTS idx_wolf_suggestions_status ON wolf_suggestions (status);
CREATE INDEX IF NOT EXISTS idx_wolf_suggestions_type ON wolf_suggestions (type);

-- Enable RLS
ALTER TABLE wolf_suggestions ENABLE ROW LEVEL SECURITY;

-- Only admins can access suggestions
CREATE POLICY "Admins can manage suggestions" ON wolf_suggestions
  FOR ALL USING (has_role(auth.uid(), 'admin'::public.app_role));

-- Seed wolf_master_config with real keys
INSERT INTO wolf_master_config (key, value) VALUES
('login_policy', jsonb_build_object(
  'max_sessions_per_user', 5,
  'lockout_threshold', 10,
  'lockout_window_minutes', 15,
  'mfa_required_for_admin', true,
  'mfa_required_for_funder', false,
  'allowed_domains_admin', jsonb_build_array('wolf-fund.com')
)) ON CONFLICT (key) DO NOTHING;

INSERT INTO wolf_master_config (key, value) VALUES
('deal_protection', jsonb_build_object(
  'max_factor_rate', 1.6,
  'min_factor_rate', 1.05,
  'max_term_months', 24,
  'max_amount', 500000,
  'require_ai_review_over_risk', 50,
  'block_auto_send_over_risk', 70
)) ON CONFLICT (key) DO NOTHING;

INSERT INTO wolf_master_config (key, value) VALUES
('funder_tiers', jsonb_build_object(
  'default_tier', 'bronze',
  'tiers', jsonb_build_array(
    jsonb_build_object('id', 'bronze', 'min_points', 0, 'max_points', 999, 'max_parallel_deals', 10, 'features', jsonb_build_array('view_bank_mirror')),
    jsonb_build_object('id', 'silver', 'min_points', 1000, 'max_points', 4999, 'max_parallel_deals', 25, 'features', jsonb_build_array('view_bank_mirror', 'call_bridge')),
    jsonb_build_object('id', 'gold', 'min_points', 5000, 'max_points', 999999, 'max_parallel_deals', 100, 'features', jsonb_build_array('view_bank_mirror', 'call_bridge', 'priority_routing'))
  )
)) ON CONFLICT (key) DO NOTHING;

INSERT INTO wolf_master_config (key, value) VALUES
('backdoor_protection', jsonb_build_object(
  'max_direct_contact_attempts_per_day', 3,
  'block_if_detected', true,
  'notify_admin_on_violation', true,
  'penalty_points', 500,
  'auto_suspend_over_violations', 3
)) ON CONFLICT (key) DO NOTHING;

INSERT INTO wolf_master_config (key, value) VALUES
('routing_profiles', jsonb_build_object(
  'default', jsonb_build_object(
    'credit_first_min_score', 650,
    'funding_first_max_dti', 0.45,
    'prefer_term_if_monthly_rev_over', 80000,
    'prefer_mca_if_chargebacks_high', true
  ),
  'high_risk', jsonb_build_object(
    'credit_first_min_score', 680,
    'funding_first_max_dti', 0.35,
    'route_only_to_tiers', jsonb_build_array('gold')
  )
)) ON CONFLICT (key) DO NOTHING;

