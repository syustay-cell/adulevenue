-- =================================================================
-- MIGRATION: 20251205062806_523d63c8-d147-41d3-b945-78126d5799be.sql
-- =================================================================
-- V19: Governance Automation Engine Tables

-- 1. wf_governance_reports - Scan snapshots
CREATE TABLE IF NOT EXISTS wf_governance_reports (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES wf_tenants(id) ON DELETE CASCADE,
  run_id text,
  run_type text DEFAULT 'scheduled',
  summary jsonb NOT NULL DEFAULT '{}',
  checks jsonb NOT NULL DEFAULT '[]',
  signals jsonb NOT NULL DEFAULT '{}',
  created_at timestamptz DEFAULT now()
);

-- 2. wf_governance_actions - Remediation audit trail
CREATE TABLE IF NOT EXISTS wf_governance_actions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES wf_tenants(id) ON DELETE CASCADE,
  action_type text NOT NULL,
  source_check_id text,
  source_suggestion_id text,
  brand_key text,
  related_asset_id uuid,
  related_event_type text,
  previous_state jsonb,
  new_state jsonb,
  performed_by uuid,
  performed_at timestamptz DEFAULT now(),
  notes text,
  metadata jsonb DEFAULT '{}'
);

-- 3. wf_governance_alerts - Threshold breach alerts
CREATE TABLE IF NOT EXISTS wf_governance_alerts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES wf_tenants(id) ON DELETE CASCADE,
  alert_type text NOT NULL,
  brand_key text,
  metric_key text,
  current_value numeric,
  threshold_value numeric,
  status text NOT NULL DEFAULT 'open',
  acknowledged_by uuid,
  acknowledged_at timestamptz,
  resolved_by uuid,
  resolved_at timestamptz,
  last_triggered_at timestamptz DEFAULT now(),
  metadata jsonb DEFAULT '{}'
);

-- Enable RLS
ALTER TABLE wf_governance_reports ENABLE ROW LEVEL SECURITY;
ALTER TABLE wf_governance_actions ENABLE ROW LEVEL SECURITY;
ALTER TABLE wf_governance_alerts ENABLE ROW LEVEL SECURITY;

-- RLS Policies for wf_governance_reports
CREATE POLICY "Admins manage wf_governance_reports"
  ON wf_governance_reports FOR ALL
  USING (has_role(auth.uid(), 'admin'::public.app_role));

CREATE POLICY "Tenant users view wf_governance_reports"
  ON wf_governance_reports FOR SELECT
  USING (EXISTS (
    SELECT 1 FROM wf_tenant_users tu 
    WHERE tu.user_id = auth.uid() AND tu.tenant_id = wf_governance_reports.tenant_id
  ));

-- RLS Policies for wf_governance_actions
CREATE POLICY "Admins manage wf_governance_actions"
  ON wf_governance_actions FOR ALL
  USING (has_role(auth.uid(), 'admin'::public.app_role));

CREATE POLICY "Tenant users view wf_governance_actions"
  ON wf_governance_actions FOR SELECT
  USING (EXISTS (
    SELECT 1 FROM wf_tenant_users tu 
    WHERE tu.user_id = auth.uid() AND tu.tenant_id = wf_governance_actions.tenant_id
  ));

CREATE POLICY "Tenant users insert wf_governance_actions"
  ON wf_governance_actions FOR INSERT
  WITH CHECK (EXISTS (
    SELECT 1 FROM wf_tenant_users tu 
    WHERE tu.user_id = auth.uid() AND tu.tenant_id = wf_governance_actions.tenant_id
  ));

-- RLS Policies for wf_governance_alerts
CREATE POLICY "Admins manage wf_governance_alerts"
  ON wf_governance_alerts FOR ALL
  USING (has_role(auth.uid(), 'admin'::public.app_role));

CREATE POLICY "Tenant users view wf_governance_alerts"
  ON wf_governance_alerts FOR SELECT
  USING (EXISTS (
    SELECT 1 FROM wf_tenant_users tu 
    WHERE tu.user_id = auth.uid() AND tu.tenant_id = wf_governance_alerts.tenant_id
  ));

CREATE POLICY "Tenant users update wf_governance_alerts"
  ON wf_governance_alerts FOR UPDATE
  USING (EXISTS (
    SELECT 1 FROM wf_tenant_users tu 
    WHERE tu.user_id = auth.uid() AND tu.tenant_id = wf_governance_alerts.tenant_id
  ));

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_governance_reports_tenant ON wf_governance_reports(tenant_id);
CREATE INDEX IF NOT EXISTS idx_governance_reports_created ON wf_governance_reports(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_governance_actions_tenant ON wf_governance_actions(tenant_id);
CREATE INDEX IF NOT EXISTS idx_governance_actions_performed ON wf_governance_actions(performed_at DESC);
CREATE INDEX IF NOT EXISTS idx_governance_alerts_tenant ON wf_governance_alerts(tenant_id);
CREATE INDEX IF NOT EXISTS idx_governance_alerts_status ON wf_governance_alerts(status);

-- Seed default alert thresholds config
INSERT INTO wolf_master_config (category, key, value, description)
VALUES (
  'governance',
  'alert_thresholds',
  '{
    "ip_defense_score_min": 70,
    "unpriced_events_max": 0,
    "playbook_pending_drift_max": 0,
    "legal_backlog_max": 5
  }'::jsonb,
  'Threshold values for governance alerts'
)
ON CONFLICT (category, key) DO NOTHING;

-- =================================================================
-- MIGRATION: 20251205065045_3d737ac7-228b-4ab1-8f4c-e2752c95197c.sql
-- =================================================================
-- V20: Dev Autopilot & Live Suggestions

-- Table: wf_dev_suggestion_events - tracks developer actions on suggestions
CREATE TABLE IF NOT EXISTS public.wf_dev_suggestion_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.wf_tenants(id) ON DELETE CASCADE,
  suggestion_id text NOT NULL,
  action text NOT NULL CHECK (action IN ('opened', 'applied', 'ignored')),
  area text NOT NULL CHECK (area IN ('billing', 'ip', 'playbook', 'defense', 'ai_change')),
  source_check_id text,
  performed_by uuid,
  performed_at timestamptz DEFAULT now(),
  metadata jsonb DEFAULT '{}'
);

-- Enable RLS
ALTER TABLE public.wf_dev_suggestion_events ENABLE ROW LEVEL SECURITY;

-- RLS Policies
CREATE POLICY "Tenant users can view dev suggestion events"
  ON public.wf_dev_suggestion_events
  FOR SELECT
  USING (tenant_has_access(auth.uid(), tenant_id));

CREATE POLICY "Tenant users can insert dev suggestion events"
  ON public.wf_dev_suggestion_events
  FOR INSERT
  WITH CHECK (tenant_has_access(auth.uid(), tenant_id));

-- Index for performance
CREATE INDEX IF NOT EXISTS idx_wf_dev_suggestion_events_tenant_id ON public.wf_dev_suggestion_events(tenant_id);
CREATE INDEX IF NOT EXISTS idx_wf_dev_suggestion_events_performed_at ON public.wf_dev_suggestion_events(performed_at DESC);

-- =================================================================
-- MIGRATION: 20251205065914_e8ca821d-9a89-47a7-a4cf-4cd752cf98bc.sql
-- =================================================================
-- V20 Fixes: Add indexes for wf_dev_suggestion_events + known_routes config

-- Add indexes for common queries on dev suggestion events
CREATE INDEX IF NOT EXISTS idx_dev_suggestion_events_tenant_performed 
ON wf_dev_suggestion_events(tenant_id, performed_at DESC);

CREATE INDEX IF NOT EXISTS idx_dev_suggestion_events_tenant_suggestion 
ON wf_dev_suggestion_events(tenant_id, suggestion_id);

-- Insert known application routes into wolf_master_config (without updated_by)
INSERT INTO wolf_master_config (category, key, value)
VALUES (
  'app',
  'known_routes',
  '{
    "routes": [
      "/admin",
      "/admin/billing", 
      "/admin/reports",
      "/admin/users",
      "/credit-specialist-dashboard",
      "/lead-engine",
      "/worker-dashboard",
      "/funder-portal",
      "/underwriting",
      "/ip-guardian",
      "/wolf-motherboard",
      "/dialer-v3",
      "/credit-fix-studio",
      "/credit-fix-studio-v2",
      "/apply",
      "/fast-track",
      "/auth",
      "/client-dashboard",
      "/services",
      "/contact",
      "/terms"
    ],
    "updated_at": "2024-12-05"
  }'::jsonb
)
ON CONFLICT (category, key) 
DO UPDATE SET 
  value = EXCLUDED.value,
  updated_at = now();

-- =================================================================
-- MIGRATION: 20251205194750_a0b24eb1-0a43-415b-a19b-d7750da16fa6.sql
-- =================================================================
-- Create credit status tracking table
CREATE TABLE IF NOT EXISTS public.wf_credit_status (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  provider TEXT NOT NULL DEFAULT 'gateway',
  status TEXT NOT NULL DEFAULT 'ok' CHECK (status IN ('ok', 'warning', 'critical', 'halt')),
  last_error_at TIMESTAMPTZ,
  last_success_at TIMESTAMPTZ,
  consecutive_errors INTEGER DEFAULT 0,
  updated_at TIMESTAMPTZ DEFAULT now(),
  updated_by UUID,
  notes TEXT
);

-- Enable RLS
ALTER TABLE public.wf_credit_status ENABLE ROW LEVEL SECURITY;

-- Admin read/write policy
CREATE POLICY "Admins can manage credit status" ON public.wf_credit_status
  FOR ALL USING (
    EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = auth.uid() AND role = 'admin')
  );

-- Insert default row
INSERT INTO public.wf_credit_status (provider, status)
VALUES ('gateway', 'ok')
ON CONFLICT DO NOTHING;

-- Add credit monitor config to wolf_master_config
INSERT INTO public.wolf_master_config (category, key, value)
VALUES (
  'credits',
  'gateway_monitor',
  '{
    "warn_threshold": 0.20,
    "critical_threshold": 0.10,
    "halt_threshold": 0.05,
    "auto_pause_heavy": true,
    "consecutive_errors_for_halt": 3
  }'::jsonb
)
ON CONFLICT (category, key) DO UPDATE SET value = EXCLUDED.value;

-- =================================================================
-- MIGRATION: 20251205200232_47b96be3-9088-4b56-a3da-f291b8bd3ca2.sql
-- =================================================================
-- V22: AI Usage Events table for cost tracking
CREATE TABLE IF NOT EXISTS public.wf_ai_usage_events (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  provider TEXT NOT NULL DEFAULT 'gateway',
  tenant_id UUID,
  brand_key TEXT DEFAULT 'wolf-fund',
  feature TEXT NOT NULL,
  context_type TEXT,
  context_id TEXT,
  status TEXT NOT NULL DEFAULT 'success',
  error_code TEXT,
  input_chars INTEGER DEFAULT 0,
  output_chars INTEGER DEFAULT 0,
  estimated_tokens INTEGER DEFAULT 0,
  estimated_cost_usd NUMERIC(10,4) DEFAULT 0
);

-- Index for efficient queries
CREATE INDEX IF NOT EXISTS idx_wf_ai_usage_events_created_at ON public.wf_ai_usage_events(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_wf_ai_usage_events_provider ON public.wf_ai_usage_events(provider);
CREATE INDEX IF NOT EXISTS idx_wf_ai_usage_events_feature ON public.wf_ai_usage_events(feature);
CREATE INDEX IF NOT EXISTS idx_wf_ai_usage_events_brand_key ON public.wf_ai_usage_events(brand_key);

-- Enable RLS
ALTER TABLE public.wf_ai_usage_events ENABLE ROW LEVEL SECURITY;

-- Admin read policy
CREATE POLICY "Admins can read AI usage events"
ON public.wf_ai_usage_events
FOR SELECT
USING (
  EXISTS (
    SELECT 1 FROM public.user_roles
    WHERE user_roles.user_id = auth.uid()
    AND user_roles.role = 'admin'
  )
);

-- Service role insert policy (edge functions)
CREATE POLICY "Service role can insert AI usage events"
ON public.wf_ai_usage_events
FOR INSERT
WITH CHECK (true);

-- Add pricing config to wolf_master_config
INSERT INTO public.wolf_master_config (category, key, value, description)
VALUES (
  'credits',
  'gateway_pricing',
  '{"pricing_model": "per_1k_tokens", "input_price_per_1k": 0.002, "output_price_per_1k": 0.006, "min_per_call": 0.001}'::jsonb,
  'AI Gateway pricing model for cost estimation'
)
ON CONFLICT (category, key) DO NOTHING;

-- Add budget config
INSERT INTO public.wolf_master_config (category, key, value, description)
VALUES (
  'credits',
  'gateway_budget',
  '{"monthly_budget_usd": 200, "warn_at_usd": 150, "critical_at_usd": 190}'::jsonb,
  'AI Gateway monthly budget thresholds'
)
ON CONFLICT (category, key) DO NOTHING;

-- =================================================================
-- MIGRATION: 20251205205104_2bf9ad12-1b33-4b94-8f1b-78392d0ac8e4.sql
-- =================================================================
-- V23: AI Mode System Config
-- Seed the ai_control configuration

INSERT INTO wolf_master_config (category, key, value, description, is_protected)
VALUES (
  'ai_control',
  'ai_mode',
  '{
    "workspace_mode": "balanced",
    "per_feature": {
      "underwriting": "pro",
      "credit_repair": "balanced",
      "research": "eco",
      "marketing_leads": "manual",
      "wolf_assistant": "eco",
      "dispute_generator": "balanced"
    },
    "outsourced_providers": {
      "marketing_leads": {
        "provider_id": null,
        "price_per_lead": 0,
        "price_structure": "per_unit",
        "active": false
      }
    },
    "worker_costs": {
      "default_hourly_rate": 25.00,
      "avg_minutes_per_task": {
        "underwriting": 45,
        "credit_repair": 30,
        "research": 15,
        "marketing_leads": 10
      }
    },
    "mode_definitions": {
      "eco": {
        "model": "google/gemini-2.5-flash-lite",
        "max_tokens": 2000,
        "temperature": 0.3,
        "cost_multiplier": 0.3
      },
      "balanced": {
        "model": "google/gemini-2.5-flash",
        "max_tokens": 4000,
        "temperature": 0.5,
        "cost_multiplier": 1.0
      },
      "pro": {
        "model": "google/gemini-2.5-pro",
        "max_tokens": 8000,
        "temperature": 0.7,
        "cost_multiplier": 3.0
      },
      "manual": {
        "model": null,
        "behavior": "manual_only"
      }
    },
    "safety_rules": {
      "downgrade_on_warning": true,
      "manual_on_critical": true,
      "protected_features": ["compliance"]
    }
  }'::jsonb,
  'AI Mode System configuration - controls eco/balanced/pro/manual lanes and outsourced providers',
  false
)
ON CONFLICT (category, key) DO UPDATE SET
  value = EXCLUDED.value,
  description = EXCLUDED.description,
  updated_at = now();

-- Worker task queue for manual lane
CREATE TABLE IF NOT EXISTS wf_manual_tasks (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID REFERENCES wf_tenants(id),
  task_type TEXT NOT NULL DEFAULT 'manual_review',
  feature TEXT NOT NULL,
  description TEXT,
  context_type TEXT,
  context_id TEXT,
  priority TEXT DEFAULT 'normal',
  status TEXT DEFAULT 'pending',
  assigned_to UUID,
  assigned_at TIMESTAMPTZ,
  completed_at TIMESTAMPTZ,
  time_spent_minutes INTEGER,
  cost_usd NUMERIC(10,4),
  result JSONB,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- Enable RLS
ALTER TABLE wf_manual_tasks ENABLE ROW LEVEL SECURITY;

-- RLS policies
CREATE POLICY "Admins can manage all manual tasks"
  ON wf_manual_tasks FOR ALL
  USING (has_role(auth.uid(), 'admin'::public.app_role));

CREATE POLICY "Workers can view assigned tasks"
  ON wf_manual_tasks FOR SELECT
  USING (assigned_to = auth.uid() OR has_role(auth.uid(), 'worker'::public.app_role));

CREATE POLICY "Workers can update assigned tasks"
  ON wf_manual_tasks FOR UPDATE
  USING (assigned_to = auth.uid())
  WITH CHECK (assigned_to = auth.uid());

-- Index for performance
CREATE INDEX IF NOT EXISTS idx_manual_tasks_status ON wf_manual_tasks(status);
CREATE INDEX IF NOT EXISTS idx_manual_tasks_assigned ON wf_manual_tasks(assigned_to);
CREATE INDEX IF NOT EXISTS idx_manual_tasks_feature ON wf_manual_tasks(feature);

-- =================================================================
-- MIGRATION: 20251205220152_268945d3-2e09-44e6-9f8d-6e3fa758d5ae.sql
-- =================================================================
-- V23.2: Add OpenAI pricing configuration and update per-feature defaults
-- Insert OpenAI pricing config
INSERT INTO wolf_master_config (category, key, value, description)
VALUES (
  'credits',
  'openai_pricing',
  '{
    "pricing_model": "per_1k_tokens",
    "input_price_per_1k": 0.0015,
    "output_price_per_1k": 0.002,
    "min_per_call_usd": 0.0005
  }'::jsonb,
  'OpenAI API pricing for ECO mode cost calculations'
)
ON CONFLICT (category, key) DO UPDATE SET 
  value = EXCLUDED.value,
  updated_at = now();

-- Update ai_mode config with hybrid provider settings and per-feature defaults
UPDATE wolf_master_config 
SET value = jsonb_build_object(
  'workspace_mode', 'balanced',
  'per_feature', jsonb_build_object(
    'ai_draft_outreach', 'eco',
    'ai_lead_worker', 'eco',
    'credit_fix_strategy', 'eco',
    'simple_research', 'eco',
    'client_education', 'eco',
    'research_intel', 'eco',
    'underwriter_analyze', 'pro',
    'underwriter_analyze_vision', 'pro',
    'vision_bank_statements', 'pro',
    'credit_dispute_generate', 'balanced',
    'credit_repair_letters', 'balanced',
    'ip_guardian_draft', 'balanced',
    'wolf_assistant', 'balanced',
    'chat_assistant', 'balanced',
    'outreach_followups', 'manual',
    'low_priority_tasks', 'manual',
    'marketing_leads', 'manual'
  ),
  'outsourced_providers', jsonb_build_object(
    'marketing_leads', jsonb_build_object(
      'provider_id', null,
      'price_per_lead', 2.00,
      'price_structure', 'per_unit',
      'active', false
    )
  ),
  'worker_costs', jsonb_build_object(
    'default_hourly_rate', 25.00,
    'avg_minutes_per_task', jsonb_build_object(
      'underwriting', 15,
      'credit_repair', 20,
      'marketing_leads', 25,
      'research', 10,
      'outreach', 5,
      'dispute_letters', 30
    )
  ),
  'mode_definitions', jsonb_build_object(
    'eco', jsonb_build_object(
      'model', 'gpt-4.1-mini-2025-04-14',
      'provider', 'openai',
      'max_tokens', 2000,
      'temperature', 0.3,
      'cost_multiplier', 0.3
    ),
    'balanced', jsonb_build_object(
      'model', 'google/gemini-2.5-flash',
      'provider', 'gateway',
      'max_tokens', 4000,
      'temperature', 0.5,
      'cost_multiplier', 1.0
    ),
    'pro', jsonb_build_object(
      'model', 'google/gemini-2.5-pro',
      'provider', 'gateway',
      'max_tokens', 8000,
      'temperature', 0.7,
      'cost_multiplier', 3.0
    ),
    'manual', jsonb_build_object(
      'model', null,
      'provider', 'manual',
      'behavior', 'manual_only'
    )
  ),
  'safety_rules', jsonb_build_object(
    'downgrade_on_warning', true,
    'manual_on_critical', true,
    'protected_features', jsonb_build_array('compliance', 'underwriter_analyze', 'vision_bank_statements')
  )
),
updated_at = now()
WHERE category = 'ai_control' AND key = 'ai_mode';

-- =================================================================
-- MIGRATION: 20251205235806_66e483ad-b123-4b41-bca7-69856956b243.sql
-- =================================================================
-- V24: Chat UX Upgrade - Contract Templates + Audio Settings

-- 1. Create contract templates table
CREATE TABLE IF NOT EXISTS public.wf_contract_templates (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  key TEXT NOT NULL UNIQUE, -- nda, iso_agreement, funding_loi, credit_repair_service
  display_name TEXT NOT NULL,
  category TEXT DEFAULT 'general', -- general, funding, credit, partnership
  base_template TEXT NOT NULL,
  requires_ai BOOLEAN DEFAULT false,
  placeholders JSONB DEFAULT '[]', -- [{key: "party_a", label: "Party A Name", required: true}]
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.wf_contract_templates ENABLE ROW LEVEL SECURITY;

-- Admin can manage templates
CREATE POLICY "Admins can manage contract templates"
  ON public.wf_contract_templates FOR ALL
  USING (EXISTS (
    SELECT 1 FROM user_roles
    WHERE user_id = auth.uid() AND role = 'admin' AND approved = true
  ));

-- Workers and admins can read templates
CREATE POLICY "Workers can read contract templates"
  ON public.wf_contract_templates FOR SELECT
  USING (EXISTS (
    SELECT 1 FROM user_roles
    WHERE user_id = auth.uid() AND role IN ('admin', 'worker') AND approved = true
  ));

-- 2. Create generated contracts log
CREATE TABLE IF NOT EXISTS public.wf_generated_contracts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  template_key TEXT NOT NULL,
  generated_by UUID REFERENCES auth.users(id),
  placeholders_used JSONB,
  generated_content TEXT NOT NULL,
  ai_polished BOOLEAN DEFAULT false,
  lead_id UUID,
  application_id UUID,
  created_at TIMESTAMPTZ DEFAULT now()
);

ALTER TABLE public.wf_generated_contracts ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can read their generated contracts"
  ON public.wf_generated_contracts FOR SELECT
  USING (generated_by = auth.uid() OR EXISTS (
    SELECT 1 FROM user_roles
    WHERE user_id = auth.uid() AND role = 'admin' AND approved = true
  ));

CREATE POLICY "Users can create contracts"
  ON public.wf_generated_contracts FOR INSERT
  WITH CHECK (auth.uid() IS NOT NULL);

-- 3. Create chat session overrides table (for per-conversation mode switching)
CREATE TABLE IF NOT EXISTS public.wf_chat_session_overrides (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id),
  session_id TEXT NOT NULL, -- browser session or conversation ID
  mode_override TEXT CHECK (mode_override IN ('eco', 'balanced', 'pro')),
  created_at TIMESTAMPTZ DEFAULT now(),
  expires_at TIMESTAMPTZ DEFAULT now() + INTERVAL '24 hours'
);

ALTER TABLE public.wf_chat_session_overrides ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can manage their session overrides"
  ON public.wf_chat_session_overrides FOR ALL
  USING (user_id = auth.uid());

-- 4. Seed default contract templates
INSERT INTO public.wf_contract_templates (key, display_name, category, base_template, requires_ai, placeholders) VALUES
('nda', 'Non-Disclosure Agreement', 'general', 
'NON-DISCLOSURE AGREEMENT

This Non-Disclosure Agreement ("Agreement") is entered into as of {{effective_date}} by and between:

DISCLOSING PARTY: {{party_a_name}}, {{party_a_company}}
Address: {{party_a_address}}

RECEIVING PARTY: {{party_b_name}}, {{party_b_company}}
Address: {{party_b_address}}

1. DEFINITION OF CONFIDENTIAL INFORMATION
"Confidential Information" means any data or information, oral or written, disclosed by the Disclosing Party that is designated as confidential or that reasonably should be understood to be confidential.

2. OBLIGATIONS
The Receiving Party agrees to:
(a) Hold the Confidential Information in strict confidence
(b) Not disclose the Confidential Information to any third parties without prior written consent
(c) Use the Confidential Information solely for the purpose of {{purpose}}

3. TERM
This Agreement shall remain in effect for {{term_years}} year(s) from the Effective Date.

4. GOVERNING LAW
This Agreement shall be governed by the laws of the State of {{governing_state}}.

IN WITNESS WHEREOF, the parties have executed this Agreement.

_________________________          _________________________
{{party_a_name}}                   {{party_b_name}}
Date: _______________              Date: _______________',
false,
'[{"key":"effective_date","label":"Effective Date","required":true,"type":"date"},{"key":"party_a_name","label":"Party A Name","required":true},{"key":"party_a_company","label":"Party A Company","required":false},{"key":"party_a_address","label":"Party A Address","required":true},{"key":"party_b_name","label":"Party B Name","required":true},{"key":"party_b_company","label":"Party B Company","required":false},{"key":"party_b_address","label":"Party B Address","required":true},{"key":"purpose","label":"Purpose","required":true},{"key":"term_years","label":"Term (Years)","required":true,"type":"number"},{"key":"governing_state","label":"Governing State","required":true}]'
),
('iso_agreement', 'ISO Partner Agreement', 'partnership',
'INDEPENDENT SALES ORGANIZATION AGREEMENT

This ISO Agreement ("Agreement") is entered into as of {{effective_date}} by and between:

Wolf Fund ("Company")
Address: {{company_address}}

AND

ISO Partner: {{iso_name}}
Company: {{iso_company}}
Address: {{iso_address}}
Phone: {{iso_phone}}
Email: {{iso_email}}

1. APPOINTMENT
Company hereby appoints ISO as an independent sales organization to refer potential merchant clients for business funding products.

2. COMMISSION STRUCTURE
ISO shall receive the following commission on funded deals:
- Standard Rate: {{commission_rate}}% of funded amount
- Payment Terms: Net {{payment_terms}} days after merchant receives funding

3. ISO RESPONSIBILITIES
(a) Submit qualified merchant applications
(b) Maintain compliance with all applicable laws
(c) Not represent themselves as employees of Company

4. TERM AND TERMINATION
This Agreement shall commence on the Effective Date and continue for {{term_months}} months, with automatic renewal unless terminated with {{notice_days}} days written notice.

5. GOVERNING LAW
This Agreement shall be governed by the laws of the State of {{governing_state}}.

AGREED AND ACCEPTED:

Wolf Fund                          ISO Partner
_________________________          _________________________
Authorized Signature               {{iso_name}}
Date: _______________              Date: _______________',
false,
'[{"key":"effective_date","label":"Effective Date","required":true,"type":"date"},{"key":"company_address","label":"Company Address","required":true},{"key":"iso_name","label":"ISO Contact Name","required":true},{"key":"iso_company","label":"ISO Company Name","required":false},{"key":"iso_address","label":"ISO Address","required":true},{"key":"iso_phone","label":"ISO Phone","required":true},{"key":"iso_email","label":"ISO Email","required":true},{"key":"commission_rate","label":"Commission Rate (%)","required":true,"type":"number"},{"key":"payment_terms","label":"Payment Terms (Days)","required":true,"type":"number"},{"key":"term_months","label":"Term (Months)","required":true,"type":"number"},{"key":"notice_days","label":"Termination Notice (Days)","required":true,"type":"number"},{"key":"governing_state","label":"Governing State","required":true}]'
),
('funding_loi', 'Funding Letter of Intent', 'funding',
'LETTER OF INTENT - BUSINESS FUNDING

Date: {{date}}

To: {{business_name}}
Attn: {{owner_name}}
Address: {{business_address}}

RE: Funding Offer

Dear {{owner_name}},

Wolf Fund is pleased to provide the following preliminary funding offer:

FUNDING DETAILS:
- Approved Amount: ${{funding_amount}}
- Factor Rate: {{factor_rate}}
- Term: {{term_weeks}} weeks
- Payment Frequency: {{payment_frequency}}
- Estimated Daily Payment: ${{daily_payment}}

REQUIREMENTS:
1. Completed application with all required documentation
2. Valid government-issued ID
3. Voided business check
4. Last 3 months of business bank statements

This Letter of Intent is subject to final underwriting approval and execution of a formal Merchant Cash Advance Agreement.

This offer expires on {{expiration_date}}.

Sincerely,

Wolf Fund
_________________________
Authorized Representative',
true,
'[{"key":"date","label":"Date","required":true,"type":"date"},{"key":"business_name","label":"Business Name","required":true},{"key":"owner_name","label":"Owner Name","required":true},{"key":"business_address","label":"Business Address","required":true},{"key":"funding_amount","label":"Funding Amount ($)","required":true,"type":"number"},{"key":"factor_rate","label":"Factor Rate","required":true},{"key":"term_weeks","label":"Term (Weeks)","required":true,"type":"number"},{"key":"payment_frequency","label":"Payment Frequency","required":true},{"key":"daily_payment","label":"Daily Payment ($)","required":true,"type":"number"},{"key":"expiration_date","label":"Offer Expiration Date","required":true,"type":"date"}]'
),
('credit_repair_service', 'Credit Repair Service Agreement', 'credit',
'CREDIT REPAIR SERVICE AGREEMENT

This Credit Repair Service Agreement ("Agreement") is entered into as of {{effective_date}} by and between:

Wolf Fund ("Company")

AND

Client: {{client_name}}
Address: {{client_address}}
Phone: {{client_phone}}
Email: {{client_email}}
SSN Last 4: {{ssn_last4}}

1. SERVICES
Company agrees to provide credit repair and optimization services including:
- Credit report analysis and review
- Dispute preparation and submission to credit bureaus
- Monitoring of dispute responses
- Credit improvement strategy recommendations

2. CLIENT RESPONSIBILITIES
Client agrees to:
- Provide accurate and complete information
- Respond promptly to requests for documentation
- Not open new credit accounts during the dispute process unless advised

3. FEES AND PAYMENT
- Initial Fee: ${{initial_fee}}
- Monthly Fee: ${{monthly_fee}} (billed on the {{billing_day}}th of each month)
- Payment Method: {{payment_method}}

4. CANCELLATION
Client may cancel this Agreement at any time with {{notice_days}} days written notice. No refunds will be provided for services already rendered.

5. DISCLAIMERS
Company cannot guarantee specific results. Credit improvement depends on various factors including client compliance and creditor responses.

6. GOVERNING LAW
This Agreement shall be governed by the laws of the State of {{governing_state}}.

By signing below, both parties agree to the terms of this Agreement.

Wolf Fund                          Client
_________________________          _________________________
Authorized Signature               {{client_name}}
Date: _______________              Date: _______________',
false,
'[{"key":"effective_date","label":"Effective Date","required":true,"type":"date"},{"key":"client_name","label":"Client Name","required":true},{"key":"client_address","label":"Client Address","required":true},{"key":"client_phone","label":"Client Phone","required":true},{"key":"client_email","label":"Client Email","required":true},{"key":"ssn_last4","label":"SSN Last 4","required":true},{"key":"initial_fee","label":"Initial Fee ($)","required":true,"type":"number"},{"key":"monthly_fee","label":"Monthly Fee ($)","required":true,"type":"number"},{"key":"billing_day","label":"Billing Day","required":true,"type":"number"},{"key":"payment_method","label":"Payment Method","required":true},{"key":"notice_days","label":"Cancellation Notice (Days)","required":true,"type":"number"},{"key":"governing_state","label":"Governing State","required":true}]'
)
ON CONFLICT (key) DO NOTHING;

-- 5. Update AI mode config to force chat features to ECO by default
UPDATE wolf_master_config 
SET value = jsonb_set(
  value,
  '{per_feature}',
  value->'per_feature' || '{"chat_assistant": "eco", "wolf_assistant": "eco", "client_education": "eco", "simple_research": "eco"}'::jsonb
),
updated_at = now()
WHERE category = 'ai_control' AND key = 'ai_mode';

-- =================================================================
-- MIGRATION: 20251206030117_ca506833-7dc7-468d-9304-17bf0ab48f26.sql
-- =================================================================
-- =====================================================
-- WOLF FUND PART 2 - SPRINT 1: DATABASE MIGRATIONS
-- =====================================================
-- This migration adds:
-- 1. ISO partner linking to fast_track_applications
-- 2. Campaign/source tracking fields
-- 3. worker_assignments table for task management
-- 4. funded_deals table for reporting
-- 5. abg_projects table for ABG integration
-- 6. lead_list_members junction table
-- =====================================================

-- 1. Extend fast_track_applications with ISO partner link and campaign tracking
ALTER TABLE public.fast_track_applications 
ADD COLUMN IF NOT EXISTS iso_partner_id UUID REFERENCES public.iso_partner_applications(id),
ADD COLUMN IF NOT EXISTS source TEXT DEFAULT 'direct',
ADD COLUMN IF NOT EXISTS campaign TEXT,
ADD COLUMN IF NOT EXISTS ad_group TEXT,
ADD COLUMN IF NOT EXISTS creative_id TEXT,
ADD COLUMN IF NOT EXISTS originated_by_worker_id UUID;

-- Add index for ISO partner lookup
CREATE INDEX IF NOT EXISTS idx_fast_track_iso_partner ON public.fast_track_applications(iso_partner_id);
CREATE INDEX IF NOT EXISTS idx_fast_track_source ON public.fast_track_applications(source);

-- 2. Create worker_assignments table for task/assignment management
CREATE TABLE IF NOT EXISTS public.worker_assignments (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  worker_id UUID NOT NULL,
  lead_id UUID REFERENCES public.leads(id),
  application_id UUID REFERENCES public.fast_track_applications(id),
  assignment_type TEXT NOT NULL DEFAULT 'dial', -- 'dial', 'email', 'follow_up', 'review'
  priority INTEGER DEFAULT 5, -- 1-10, lower is higher priority
  status TEXT NOT NULL DEFAULT 'pending', -- 'pending', 'in_progress', 'done', 'skipped'
  due_at TIMESTAMPTZ,
  notes TEXT,
  assigned_by UUID,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  completed_at TIMESTAMPTZ,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Indexes for worker_assignments
CREATE INDEX IF NOT EXISTS idx_worker_assignments_worker ON public.worker_assignments(worker_id);
CREATE INDEX IF NOT EXISTS idx_worker_assignments_lead ON public.worker_assignments(lead_id);
CREATE INDEX IF NOT EXISTS idx_worker_assignments_status ON public.worker_assignments(status);
CREATE INDEX IF NOT EXISTS idx_worker_assignments_due ON public.worker_assignments(due_at);

-- Enable RLS
ALTER TABLE public.worker_assignments ENABLE ROW LEVEL SECURITY;

-- Workers can see their own assignments
CREATE POLICY "Workers can view their own assignments"
ON public.worker_assignments FOR SELECT
USING (auth.uid() = worker_id);

-- Workers can update their own assignments (mark done, etc.)
CREATE POLICY "Workers can update their own assignments"
ON public.worker_assignments FOR UPDATE
USING (auth.uid() = worker_id);

-- Admins can manage all assignments
CREATE POLICY "Admins can manage all assignments"
ON public.worker_assignments FOR ALL
USING (
  EXISTS (
    SELECT 1 FROM public.user_roles 
    WHERE user_id = auth.uid() AND role = 'admin'::public.app_role
  )
);

-- 3. Create funded_deals table for reporting
CREATE TABLE IF NOT EXISTS public.funded_deals (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  application_id UUID NOT NULL REFERENCES public.fast_track_applications(id),
  iso_partner_id UUID REFERENCES public.iso_partner_applications(id),
  originated_by_worker_id UUID,
  source_type TEXT DEFAULT 'direct', -- 'direct', 'iso', 'knight_campaign', 'referral'
  product_type TEXT DEFAULT 'mca', -- 'mca', 'loc', 'term_loan'
  funded_amount NUMERIC NOT NULL,
  funded_date TIMESTAMPTZ NOT NULL DEFAULT now(),
  funder_id UUID REFERENCES public.funders(id),
  commission_rate NUMERIC,
  commission_amount NUMERIC,
  status TEXT NOT NULL DEFAULT 'funded', -- 'funded', 'in_repayment', 'paid_off', 'default'
  notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Indexes for funded_deals
CREATE INDEX IF NOT EXISTS idx_funded_deals_application ON public.funded_deals(application_id);
CREATE INDEX IF NOT EXISTS idx_funded_deals_iso ON public.funded_deals(iso_partner_id);
CREATE INDEX IF NOT EXISTS idx_funded_deals_date ON public.funded_deals(funded_date);
CREATE INDEX IF NOT EXISTS idx_funded_deals_source ON public.funded_deals(source_type);

-- Enable RLS
ALTER TABLE public.funded_deals ENABLE ROW LEVEL SECURITY;

-- Admins can manage all funded deals
CREATE POLICY "Admins can manage funded deals"
ON public.funded_deals FOR ALL
USING (
  EXISTS (
    SELECT 1 FROM public.user_roles 
    WHERE user_id = auth.uid() AND role = 'admin'::public.app_role
  )
);

-- ISO partners can view their own deals
CREATE POLICY "ISO partners can view their funded deals"
ON public.funded_deals FOR SELECT
USING (
  iso_partner_id IN (
    SELECT id FROM public.iso_partner_applications 
    WHERE user_id = auth.uid()
  )
);

-- 4. Create abg_projects table for ABG integration
CREATE TABLE IF NOT EXISTS public.abg_projects (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  external_ref TEXT, -- ABG system ID if separate
  name TEXT NOT NULL,
  location TEXT,
  project_type TEXT, -- 'multifamily', 'rehab', 'tlc_campus', 'commercial', 'residential'
  status TEXT NOT NULL DEFAULT 'planning', -- 'planning', 'in_progress', 'completed', 'on_hold'
  total_budget NUMERIC,
  wolf_funding_application_id UUID REFERENCES public.fast_track_applications(id),
  funded_amount NUMERIC,
  draw_schedule JSONB,
  notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Indexes for abg_projects
CREATE INDEX IF NOT EXISTS idx_abg_projects_application ON public.abg_projects(wolf_funding_application_id);
CREATE INDEX IF NOT EXISTS idx_abg_projects_status ON public.abg_projects(status);
CREATE INDEX IF NOT EXISTS idx_abg_projects_type ON public.abg_projects(project_type);

-- Enable RLS
ALTER TABLE public.abg_projects ENABLE ROW LEVEL SECURITY;

-- Admins can manage all ABG projects
CREATE POLICY "Admins can manage ABG projects"
ON public.abg_projects FOR ALL
USING (
  EXISTS (
    SELECT 1 FROM public.user_roles 
    WHERE user_id = auth.uid() AND role = 'admin'::public.app_role
  )
);

-- 5. Create lead_list_members junction table (if not exists)
CREATE TABLE IF NOT EXISTS public.lead_list_members (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  lead_list_id UUID NOT NULL REFERENCES public.lead_lists(id) ON DELETE CASCADE,
  lead_id UUID NOT NULL REFERENCES public.leads(id) ON DELETE CASCADE,
  position INTEGER,
  status_in_list TEXT DEFAULT 'pending', -- 'pending', 'in_progress', 'completed', 'skipped'
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(lead_list_id, lead_id)
);

-- Indexes for lead_list_members
CREATE INDEX IF NOT EXISTS idx_lead_list_members_list ON public.lead_list_members(lead_list_id);
CREATE INDEX IF NOT EXISTS idx_lead_list_members_lead ON public.lead_list_members(lead_id);

-- Enable RLS
ALTER TABLE public.lead_list_members ENABLE ROW LEVEL SECURITY;

-- Staff can view lead list members
CREATE POLICY "Staff can view lead list members"
ON public.lead_list_members FOR SELECT
USING (
  EXISTS (
    SELECT 1 FROM public.user_roles 
    WHERE user_id = auth.uid() AND role IN ('admin'::public.app_role, 'worker'::public.app_role)
  )
);

-- Admins can manage lead list members
CREATE POLICY "Admins can manage lead list members"
ON public.lead_list_members FOR ALL
USING (
  EXISTS (
    SELECT 1 FROM public.user_roles 
    WHERE user_id = auth.uid() AND role = 'admin'::public.app_role
  )
);

-- 6. Add campaign tracking to leads table (some may already exist)
ALTER TABLE public.leads
ADD COLUMN IF NOT EXISTS source TEXT,
ADD COLUMN IF NOT EXISTS campaign TEXT,
ADD COLUMN IF NOT EXISTS ad_group TEXT,
ADD COLUMN IF NOT EXISTS creative_id TEXT;

-- Index for campaign tracking on leads
CREATE INDEX IF NOT EXISTS idx_leads_campaign ON public.leads(campaign);
CREATE INDEX IF NOT EXISTS idx_leads_source_col ON public.leads(source);

-- 7. Update trigger for timestamps
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SET search_path = public;

-- Apply triggers to new tables
DROP TRIGGER IF EXISTS update_worker_assignments_updated_at ON public.worker_assignments;
CREATE TRIGGER update_worker_assignments_updated_at
BEFORE UPDATE ON public.worker_assignments
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

DROP TRIGGER IF EXISTS update_funded_deals_updated_at ON public.funded_deals;
CREATE TRIGGER update_funded_deals_updated_at
BEFORE UPDATE ON public.funded_deals
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

DROP TRIGGER IF EXISTS update_abg_projects_updated_at ON public.abg_projects;
CREATE TRIGGER update_abg_projects_updated_at
BEFORE UPDATE ON public.abg_projects
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

