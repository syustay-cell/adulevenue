# Shared Edge Function Modules

**Project Ref:** tdzuhcswrojlleeupqvd  
**Export Date:** 2025-12-14  

## safeResponse.ts
```typescript
/**
 * Safe Response Helpers - V25
 * RULE: All edge functions return HTTP 200 with { ok: true/false }
 * Never bubble 4xx/5xx to the UI
 */

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

export type WolfResponse<T> =
  | { ok: true; data: T }
  | { ok: false; error_code: string; message: string };

export function success<T>(data: T): Response {
  return new Response(JSON.stringify({ ok: true, ...data }), {
    status: 200,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}

export function failure(code: string, message: string, extra?: Record<string, unknown>): Response {
  return new Response(JSON.stringify({ ok: false, error_code: code, message, ...extra }), {
    status: 200,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}

export function optionsOk(): Response {
  return new Response(null, { status: 200, headers: corsHeaders });
}

export function json(body: unknown, status = 200): Response {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}
```

## response.ts
```typescript
export type JsonBody = {
  ok: boolean;
  data?: unknown;
  error?: string;
  meta?: Record<string, unknown>;
};

export function json(body: JsonBody, init?: ResponseInit): Response {
  const status = init?.status ?? (body.ok ? 200 : 400);
  return new Response(JSON.stringify(body), {
    status,
    headers: {
      "Content-Type": "application/json",
      ...(init?.headers ?? {}),
    },
  });
}

export function methodNotAllowed(): Response {
  return json({ ok: false, error: "Method not allowed" }, { status: 405 });
}

export function notImplemented(fn: string): Response {
  return json(
    {
      ok: false,
      error: "Not implemented",
      meta: {
        function: fn,
        phase: "2",
        layer: "edge-scaffolding",
      },
    },
    { status: 501 },
  );
}
```

---
**Note:** Full safeAIRequest.ts and other shared modules are available in `supabase/functions/_shared/` directory.
