-- =================================================================
-- MIGRATION: 20251202185017_9edfe4dc-fffc-4b25-a445-0bf6b35f4a7f.sql
-- =================================================================
-- Create missing spec-aligned tables

-- 1. Create profiles table (public users table)
CREATE TABLE IF NOT EXISTS public.profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email text,
  full_name text,
  phone text,
  role text DEFAULT 'user',
  position text,
  status text DEFAULT 'active',
  iso_id uuid,
  avatar_url text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "profiles_select_own" ON public.profiles
  FOR SELECT USING (auth.uid() = id);

CREATE POLICY "profiles_update_own" ON public.profiles
  FOR UPDATE USING (auth.uid() = id);

CREATE POLICY "profiles_admin_all" ON public.profiles
  FOR ALL USING (has_role(auth.uid(), 'admin'::public.app_role));

-- Auto-create profile on signup
CREATE OR REPLACE FUNCTION public.handle_new_user_profile()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
BEGIN
  INSERT INTO public.profiles (id, email, full_name)
  VALUES (NEW.id, NEW.email, COALESCE(NEW.raw_user_meta_data ->> 'full_name', NEW.email));
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS on_auth_user_created_profile ON auth.users;
CREATE TRIGGER on_auth_user_created_profile
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user_profile();

-- 2. Create calls table
CREATE TABLE IF NOT EXISTS public.calls (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id uuid REFERENCES leads(id) ON DELETE CASCADE,
  user_id uuid REFERENCES auth.users(id),
  outcome text NOT NULL,
  notes text,
  duration_seconds integer,
  scheduled_callback_at timestamptz,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE public.calls ENABLE ROW LEVEL SECURITY;

CREATE POLICY "calls_worker_select" ON public.calls
  FOR SELECT USING (user_id = auth.uid() OR has_role(auth.uid(), 'admin'::public.app_role));

CREATE POLICY "calls_worker_insert" ON public.calls
  FOR INSERT WITH CHECK (user_id = auth.uid() OR has_role(auth.uid(), 'admin'::public.app_role));

CREATE INDEX IF NOT EXISTS idx_calls_lead_id ON public.calls(lead_id);
CREATE INDEX IF NOT EXISTS idx_calls_user_id ON public.calls(user_id);

-- 3. Create lead_notes table
CREATE TABLE IF NOT EXISTS public.lead_notes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id uuid NOT NULL REFERENCES leads(id) ON DELETE CASCADE,
  author_id uuid REFERENCES auth.users(id),
  note text NOT NULL,
  note_type text DEFAULT 'general',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE public.lead_notes ENABLE ROW LEVEL SECURITY;

CREATE POLICY "lead_notes_worker_select" ON public.lead_notes
  FOR SELECT USING (has_role(auth.uid(), 'worker'::public.app_role) OR has_role(auth.uid(), 'admin'::public.app_role));

CREATE POLICY "lead_notes_worker_insert" ON public.lead_notes
  FOR INSERT WITH CHECK (author_id = auth.uid());

CREATE INDEX IF NOT EXISTS idx_lead_notes_lead_id ON public.lead_notes(lead_id);

-- 4. Create lead_events table
CREATE TABLE IF NOT EXISTS public.lead_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id uuid NOT NULL REFERENCES leads(id) ON DELETE CASCADE,
  event_type text NOT NULL,
  created_by uuid REFERENCES auth.users(id),
  metadata jsonb DEFAULT '{}'::jsonb,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE public.lead_events ENABLE ROW LEVEL SECURITY;

CREATE POLICY "lead_events_worker_select" ON public.lead_events
  FOR SELECT USING (has_role(auth.uid(), 'worker'::public.app_role) OR has_role(auth.uid(), 'admin'::public.app_role));

CREATE POLICY "lead_events_system_insert" ON public.lead_events
  FOR INSERT WITH CHECK (true);

CREATE INDEX IF NOT EXISTS idx_lead_events_lead_id ON public.lead_events(lead_id);
CREATE INDEX IF NOT EXISTS idx_lead_events_type ON public.lead_events(event_type);

-- =================================================================
-- MIGRATION: 20251202191720_47c5fba8-3c4f-43b2-a29b-2e180bd76461.sql
-- =================================================================
-- 1.1 Extend user_roles with position_label
ALTER TABLE public.user_roles
ADD COLUMN IF NOT EXISTS position_label text;

-- 1.2 Create credit_disputes table for individual dispute lines
CREATE TABLE IF NOT EXISTS public.credit_disputes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  credit_case_id uuid NOT NULL REFERENCES public.credit_repair_cases(id) ON DELETE CASCADE,
  bureau text NOT NULL,
  creditor_name text,
  account_last4 text,
  reason_code text,
  status text NOT NULL DEFAULT 'pending',
  round_number int DEFAULT 1,
  letter_url text,
  notes text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_credit_disputes_case ON public.credit_disputes(credit_case_id);

-- 1.3 Extend underwriting_cases for opener/closer logic
ALTER TABLE public.underwriting_cases
ADD COLUMN IF NOT EXISTS opener_id uuid,
ADD COLUMN IF NOT EXISTS closer_id uuid,
ADD COLUMN IF NOT EXISTS lock_owner_id uuid,
ADD COLUMN IF NOT EXISTS lock_expires_at timestamptz,
ADD COLUMN IF NOT EXISTS revenue_share jsonb,
ADD COLUMN IF NOT EXISTS docs_package_url text,
ADD COLUMN IF NOT EXISTS funding_call_needed boolean DEFAULT false,
ADD COLUMN IF NOT EXISTS funding_call_status text,
ADD COLUMN IF NOT EXISTS funding_call_notes text;

-- 1.4 Create lead_conflict_requests table
CREATE TABLE IF NOT EXISTS public.lead_conflict_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id uuid NOT NULL REFERENCES public.leads(id) ON DELETE CASCADE,
  requester_id uuid NOT NULL,
  current_owner_id uuid NOT NULL,
  status text NOT NULL DEFAULT 'pending',
  resolution jsonb,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_lead_conflict_lead ON public.lead_conflict_requests(lead_id);
CREATE INDEX IF NOT EXISTS idx_lead_conflict_status ON public.lead_conflict_requests(status);

-- Enable RLS
ALTER TABLE public.credit_disputes ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.lead_conflict_requests ENABLE ROW LEVEL SECURITY;

-- RLS for credit_disputes
CREATE POLICY "Credit specialists can manage disputes for assigned cases"
ON public.credit_disputes FOR ALL
USING (EXISTS (
  SELECT 1 FROM credit_repair_cases
  WHERE credit_repair_cases.id = credit_disputes.credit_case_id
  AND ((has_role(auth.uid(), 'credit_repair_specialist'::public.app_role) AND credit_repair_cases.assigned_specialist_id = auth.uid())
       OR has_role(auth.uid(), 'admin'::public.app_role))
));

-- RLS for lead_conflict_requests
CREATE POLICY "Users can view their conflict requests"
ON public.lead_conflict_requests FOR SELECT
USING (requester_id = auth.uid() OR current_owner_id = auth.uid() OR has_role(auth.uid(), 'admin'::public.app_role));

CREATE POLICY "Users can create conflict requests"
ON public.lead_conflict_requests FOR INSERT
WITH CHECK (requester_id = auth.uid());

CREATE POLICY "Admins and owners can update conflict requests"
ON public.lead_conflict_requests FOR UPDATE
USING (current_owner_id = auth.uid() OR has_role(auth.uid(), 'admin'::public.app_role));

-- 2.1 RPC: lock lead for opener
CREATE OR REPLACE FUNCTION public.lock_lead_for_opener(
  p_lead_id uuid,
  p_opener_id uuid,
  p_days int DEFAULT 7
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  UPDATE public.leads
  SET 
    owner_id = p_opener_id,
    locked_by = p_opener_id,
    locked_until = now() + (p_days || ' days')::interval,
    updated_at = now()
  WHERE id = p_lead_id;
END;
$$;

-- 2.2 RPC: request lead conflict
CREATE OR REPLACE FUNCTION public.request_lead_conflict(
  p_lead_id uuid,
  p_requester_id uuid
)
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_owner uuid;
  v_id uuid;
BEGIN
  SELECT owner_id INTO v_owner FROM public.leads WHERE id = p_lead_id;

  IF v_owner IS NULL THEN
    UPDATE public.leads
    SET owner_id = p_requester_id,
        locked_by = p_requester_id,
        locked_until = now() + interval '7 days',
        updated_at = now()
    WHERE id = p_lead_id;
    RETURN NULL;
  END IF;

  INSERT INTO public.lead_conflict_requests(
    lead_id, requester_id, current_owner_id
  ) VALUES (
    p_lead_id, p_requester_id, v_owner
  )
  RETURNING id INTO v_id;

  RETURN v_id;
END;
$$;

-- 2.3 RPC: start underwriting case
CREATE OR REPLACE FUNCTION public.start_underwriting_case(
  p_lead_id uuid,
  p_underwriter_id uuid
)
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_case_id uuid;
BEGIN
  INSERT INTO public.underwriting_cases(
    application_id, assigned_underwriter_id, status, application_type
  ) VALUES (
    p_lead_id, p_underwriter_id, 'intake', 'lead'
  )
  RETURNING id INTO v_case_id;

  UPDATE public.leads
  SET status = 'in_progress', updated_at = now()
  WHERE id = p_lead_id;

  RETURN v_case_id;
END;
$$;

-- 2.4 RPC: submit docs package
CREATE OR REPLACE FUNCTION public.submit_underwriting_package(
  p_case_id uuid,
  p_docs_url text,
  p_funding_call_needed boolean
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  UPDATE public.underwriting_cases
  SET
    docs_package_url = p_docs_url,
    funding_call_needed = p_funding_call_needed,
    status = CASE 
      WHEN p_funding_call_needed THEN 'in_review'
      ELSE 'docs_pending'
    END,
    updated_at = now()
  WHERE id = p_case_id;
END;
$$;

-- 2.5 RPC: complete funding call
CREATE OR REPLACE FUNCTION public.complete_funding_call(
  p_case_id uuid,
  p_status text,
  p_notes text
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  UPDATE public.underwriting_cases
  SET
    funding_call_status = 'completed',
    funding_call_notes = p_notes,
    status = CASE 
      WHEN p_status = 'approved' THEN 'approved'
      WHEN p_status = 'declined' THEN 'declined'
      ELSE 'docs_pending'
    END,
    updated_at = now()
  WHERE id = p_case_id;
END;
$$;

-- =================================================================
-- MIGRATION: 20251202192837_3a2d05ae-6933-4b6e-87b2-877256453a65.sql
-- =================================================================
-- Add missing columns to lead_lists table
ALTER TABLE public.lead_lists
ADD COLUMN IF NOT EXISTS dialer_count integer,
ADD COLUMN IF NOT EXISTS email_count integer,
ADD COLUMN IF NOT EXISTS research_count integer,
ADD COLUMN IF NOT EXISTS rejected_count integer,
ADD COLUMN IF NOT EXISTS header_confidence integer,
ADD COLUMN IF NOT EXISTS field_coverage integer,
ADD COLUMN IF NOT EXISTS header_mapping jsonb,
ADD COLUMN IF NOT EXISTS processing_summary jsonb,
ADD COLUMN IF NOT EXISTS source_type text,
ADD COLUMN IF NOT EXISTS raw_headers text[],
ADD COLUMN IF NOT EXISTS import_quality_score integer;

-- Add missing columns to leads table for enrichment and OCM
ALTER TABLE public.leads
ADD COLUMN IF NOT EXISTS need_type text,
ADD COLUMN IF NOT EXISTS import_bucket text,
ADD COLUMN IF NOT EXISTS import_confidence_score integer,
ADD COLUMN IF NOT EXISTS research_status text,
ADD COLUMN IF NOT EXISTS missing_phone boolean DEFAULT false,
ADD COLUMN IF NOT EXISTS missing_email boolean DEFAULT false,
ADD COLUMN IF NOT EXISTS normalized_fields jsonb,
ADD COLUMN IF NOT EXISTS raw_data jsonb,
ADD COLUMN IF NOT EXISTS enriched_business_name text,
ADD COLUMN IF NOT EXISTS enriched_name text,
ADD COLUMN IF NOT EXISTS enriched_phone text,
ADD COLUMN IF NOT EXISTS enriched_email text,
ADD COLUMN IF NOT EXISTS enriched_address text,
ADD COLUMN IF NOT EXISTS enriched_city text,
ADD COLUMN IF NOT EXISTS enriched_state text,
ADD COLUMN IF NOT EXISTS enriched_zip text,
ADD COLUMN IF NOT EXISTS funding_score numeric,
ADD COLUMN IF NOT EXISTS funding_recommendation text,
ADD COLUMN IF NOT EXISTS credit_risk text,
ADD COLUMN IF NOT EXISTS identity_theft_risk text,
ADD COLUMN IF NOT EXISTS business_age_years numeric,
ADD COLUMN IF NOT EXISTS estimated_revenue numeric,
ADD COLUMN IF NOT EXISTS industry_risk text,
ADD COLUMN IF NOT EXISTS ocm_license_id text,
ADD COLUMN IF NOT EXISTS ocm_license_type text,
ADD COLUMN IF NOT EXISTS ocm_status text,
ADD COLUMN IF NOT EXISTS ocm_municipality text,
ADD COLUMN IF NOT EXISTS ocm_expiration_date date,
ADD COLUMN IF NOT EXISTS city text,
ADD COLUMN IF NOT EXISTS state text,
ADD COLUMN IF NOT EXISTS zip text,
ADD COLUMN IF NOT EXISTS address text;

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_leads_route ON public.leads(route);
CREATE INDEX IF NOT EXISTS idx_leads_research_status ON public.leads(research_status);
CREATE INDEX IF NOT EXISTS idx_leads_import_bucket ON public.leads(import_bucket);

-- =================================================================
-- MIGRATION: 20251202200111_4214012c-ce48-47d7-a6a8-4f4950ea23be.sql
-- =================================================================
CREATE OR REPLACE FUNCTION public.get_next_lead_for_worker(p_worker_id uuid)
 RETURNS leads
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  v_lead leads;
BEGIN
  -- Try "new" leads from dialer queue that nobody owns yet
  SELECT *
  INTO v_lead
  FROM leads
  WHERE (route = 'dialer' OR import_bucket = 'dialer')
    AND dialer_status = 'new'
    AND (current_owner_id IS NULL OR current_owner_id = p_worker_id)
  ORDER BY ai_score DESC NULLS LAST, created_at ASC
  LIMIT 1
  FOR UPDATE SKIP LOCKED;

  IF NOT FOUND THEN
    -- Try callback leads scheduled for this worker
    SELECT *
    INTO v_lead
    FROM leads
    WHERE (route = 'dialer' OR import_bucket = 'dialer')
      AND dialer_status = 'callback'
      AND current_owner_id = p_worker_id
    ORDER BY last_call_at ASC NULLS LAST
    LIMIT 1
    FOR UPDATE SKIP LOCKED;
  END IF;

  IF NOT FOUND THEN
    RETURN NULL;
  END IF;

  -- Lock as in progress
  UPDATE leads
  SET 
    dialer_status = 'in_progress',
    last_called_by = p_worker_id
  WHERE id = v_lead.id;

  -- Return updated lead
  SELECT * INTO v_lead FROM leads WHERE id = v_lead.id;
  
  RETURN v_lead;
END;
$function$;

-- =================================================================
-- MIGRATION: 20251202200639_b9d14c4c-78c0-4550-9d73-46c3cd4c9eac.sql
-- =================================================================
-- Drop and recreate get_next_lead_for_agent
DROP FUNCTION IF EXISTS public.get_next_lead_for_agent(uuid);

CREATE FUNCTION public.get_next_lead_for_agent(p_agent_id uuid)
RETURNS SETOF leads
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  RETURN QUERY
  SELECT *
  FROM leads
  WHERE (
    -- Agent's own locked leads
    (owner_id = p_agent_id AND lock_expires_at > NOW())
    OR
    -- Unlocked leads available for anyone
    (owner_id IS NULL OR lock_expires_at IS NULL OR lock_expires_at <= NOW())
  )
  AND status IN ('new', 'assigned', 'no_answer')
  ORDER BY 
    -- Prioritize agent's own leads first
    CASE WHEN owner_id = p_agent_id THEN 0 ELSE 1 END,
    -- Then by AI score
    ai_score DESC NULLS LAST,
    -- Then by created date
    created_at ASC
  LIMIT 1;
END;
$$;

-- =================================================================
-- MIGRATION: 20251202200939_cd1b3ef1-c3da-4f1e-aed7-435247ae5df3.sql
-- =================================================================
-- Fix record_call_attempt to use ONLY valid status values
CREATE OR REPLACE FUNCTION public.record_call_attempt(
  p_lead_id uuid,
  p_outcome text,
  p_duration_seconds integer DEFAULT NULL,
  p_notes text DEFAULT NULL
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_user_id uuid;
  v_email text;
  v_new_status text;
BEGIN
  v_user_id := auth.uid();
  v_email := (SELECT email FROM auth.users WHERE id = v_user_id);

  -- Map outcome to VALID status values only
  v_new_status := CASE p_outcome
    WHEN 'interested' THEN 'contacted'
    WHEN 'answered' THEN 'contacted'
    WHEN 'not_interested' THEN 'not_qualified'
    WHEN 'bad_number' THEN 'do_not_contact'
    WHEN 'no_answer' THEN 'assigned'
    WHEN 'voicemail' THEN 'assigned'
    ELSE 'assigned'
  END;

  -- Insert call record
  INSERT INTO calls (lead_id, outcome, duration_seconds, notes, user_id)
  VALUES (p_lead_id, p_outcome, p_duration_seconds, p_notes, v_user_id);

  -- Update lead with call attempt info
  UPDATE leads
  SET 
    status = v_new_status,
    call_attempts = COALESCE(call_attempts, 0) + 1,
    last_call_outcome = p_outcome,
    last_called_at = NOW(),
    last_called_by = v_user_id,
    updated_at = NOW()
  WHERE id = p_lead_id;
END;
$$;

-- =================================================================
-- MIGRATION: 20251202202207_e8acdaf0-fa21-40d9-a2b4-0f3130e7e1aa.sql
-- =================================================================
-- =========================================
-- WOLF FUND – LEAD ENGINE V3 MIGRATION
-- Safe: uses IF NOT EXISTS where possible
-- =========================================

-- 1) leads table enhancements (add missing columns)
ALTER TABLE public.leads
  ADD COLUMN IF NOT EXISTS enriched_name text,
  ADD COLUMN IF NOT EXISTS enriched_business_name text,
  ADD COLUMN IF NOT EXISTS enriched_phone text,
  ADD COLUMN IF NOT EXISTS enriched_email text,
  ADD COLUMN IF NOT EXISTS enriched_address text,
  ADD COLUMN IF NOT EXISTS enriched_city text,
  ADD COLUMN IF NOT EXISTS enriched_state text,
  ADD COLUMN IF NOT EXISTS enriched_zip text,
  ADD COLUMN IF NOT EXISTS ocm_license_id text,
  ADD COLUMN IF NOT EXISTS ocm_license_type text,
  ADD COLUMN IF NOT EXISTS ocm_status text,
  ADD COLUMN IF NOT EXISTS ocm_municipality text,
  ADD COLUMN IF NOT EXISTS ocm_expiration_date date,
  ADD COLUMN IF NOT EXISTS funding_score integer,
  ADD COLUMN IF NOT EXISTS funding_recommendation text,
  ADD COLUMN IF NOT EXISTS credit_risk text,
  ADD COLUMN IF NOT EXISTS identity_theft_risk text,
  ADD COLUMN IF NOT EXISTS business_age_years numeric,
  ADD COLUMN IF NOT EXISTS estimated_revenue numeric,
  ADD COLUMN IF NOT EXISTS industry_risk text,
  ADD COLUMN IF NOT EXISTS research_status text,
  ADD COLUMN IF NOT EXISTS missing_phone boolean,
  ADD COLUMN IF NOT EXISTS missing_email boolean,
  ADD COLUMN IF NOT EXISTS import_bucket text,
  ADD COLUMN IF NOT EXISTS import_confidence_score integer,
  ADD COLUMN IF NOT EXISTS normalized_fields jsonb;

-- 2) Indexes for performance
CREATE INDEX IF NOT EXISTS idx_leads_research_status ON public.leads(research_status);
CREATE INDEX IF NOT EXISTS idx_leads_funding_score ON public.leads(funding_score);
CREATE INDEX IF NOT EXISTS idx_leads_funding_recommendation ON public.leads(funding_recommendation);

-- =================================================================
-- MIGRATION: 20251202210843_461aec21-2066-4567-a43b-27ee78d65f14.sql
-- =================================================================
-- SMART EMAILER FIELDS
ALTER TABLE public.leads
  ADD COLUMN IF NOT EXISTS email_status text DEFAULT 'not_sent',
  ADD COLUMN IF NOT EXISTS last_emailed_at timestamptz,
  ADD COLUMN IF NOT EXISTS email_attempts integer DEFAULT 0,
  ADD COLUMN IF NOT EXISTS email_template_used text;

CREATE INDEX IF NOT EXISTS idx_leads_email_status ON public.leads(email_status);

-- RPC: get_next_dialer_lead (phone leads)
CREATE OR REPLACE FUNCTION public.get_next_dialer_lead(p_user_id uuid)
RETURNS public.leads AS $$
DECLARE
  v_lead public.leads;
BEGIN
  SELECT *
  INTO v_lead
  FROM public.leads
  WHERE (route = 'dialer' OR import_bucket = 'dialer')
    AND phone IS NOT NULL
    AND status = 'new'
  ORDER BY ai_score DESC NULLS LAST, created_at ASC
  LIMIT 1;

  RETURN v_lead;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

-- RPC: get_next_email_lead (email-only leads)
CREATE OR REPLACE FUNCTION public.get_next_email_lead(p_user_id uuid)
RETURNS public.leads AS $$
DECLARE
  v_lead public.leads;
BEGIN
  SELECT *
  INTO v_lead
  FROM public.leads
  WHERE (route = 'email' OR (email IS NOT NULL AND phone IS NULL))
    AND email IS NOT NULL
    AND (email_status IS NULL OR email_status = 'not_sent')
    AND status = 'new'
  ORDER BY ai_score DESC NULLS LAST, created_at ASC
  LIMIT 1;

  RETURN v_lead;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

-- =================================================================
-- MIGRATION: 20251202234523_8cf6ea82-1c9f-45b5-9df9-13c75b4ec586.sql
-- =================================================================
-- Add Nisim-style columns to leads table for comprehensive lead data

-- Sensitive data columns
ALTER TABLE public.leads ADD COLUMN IF NOT EXISTS ein text;
ALTER TABLE public.leads ADD COLUMN IF NOT EXISTS ssn_masked text;

-- Business info columns  
ALTER TABLE public.leads ADD COLUMN IF NOT EXISTS business_start_date text;
ALTER TABLE public.leads ADD COLUMN IF NOT EXISTS estimated_monthly_revenue numeric;
ALTER TABLE public.leads ADD COLUMN IF NOT EXISTS defaults_flag boolean DEFAULT false;
ALTER TABLE public.leads ADD COLUMN IF NOT EXISTS file_age_code text;

-- Owner info columns
ALTER TABLE public.leads ADD COLUMN IF NOT EXISTS owner_birth_date text;
ALTER TABLE public.leads ADD COLUMN IF NOT EXISTS owner_first_name text;
ALTER TABLE public.leads ADD COLUMN IF NOT EXISTS owner_last_name text;

-- Contact info columns
ALTER TABLE public.leads ADD COLUMN IF NOT EXISTS phone_line_type text;
ALTER TABLE public.leads ADD COLUMN IF NOT EXISTS phone_carrier text;

-- Source tracking columns
ALTER TABLE public.leads ADD COLUMN IF NOT EXISTS source_list_name text;
ALTER TABLE public.leads ADD COLUMN IF NOT EXISTS source_file_name text;
ALTER TABLE public.leads ADD COLUMN IF NOT EXISTS source_folder_name text;

-- Location columns (if not exist)
ALTER TABLE public.leads ADD COLUMN IF NOT EXISTS address text;
ALTER TABLE public.leads ADD COLUMN IF NOT EXISTS city text;
ALTER TABLE public.leads ADD COLUMN IF NOT EXISTS state text;
ALTER TABLE public.leads ADD COLUMN IF NOT EXISTS postal_code text;

-- Import bucket column
ALTER TABLE public.leads ADD COLUMN IF NOT EXISTS import_bucket text;
ALTER TABLE public.leads ADD COLUMN IF NOT EXISTS import_confidence_score integer;
ALTER TABLE public.leads ADD COLUMN IF NOT EXISTS normalized_fields jsonb;

-- Enrichment columns
ALTER TABLE public.leads ADD COLUMN IF NOT EXISTS enriched_name text;
ALTER TABLE public.leads ADD COLUMN IF NOT EXISTS enriched_phone text;
ALTER TABLE public.leads ADD COLUMN IF NOT EXISTS enriched_email text;
ALTER TABLE public.leads ADD COLUMN IF NOT EXISTS enriched_business_name text;
ALTER TABLE public.leads ADD COLUMN IF NOT EXISTS enriched_address text;
ALTER TABLE public.leads ADD COLUMN IF NOT EXISTS enriched_city text;
ALTER TABLE public.leads ADD COLUMN IF NOT EXISTS enriched_state text;
ALTER TABLE public.leads ADD COLUMN IF NOT EXISTS enriched_zip text;

-- OCM-specific columns
ALTER TABLE public.leads ADD COLUMN IF NOT EXISTS ocm_license_id text;
ALTER TABLE public.leads ADD COLUMN IF NOT EXISTS ocm_license_type text;
ALTER TABLE public.leads ADD COLUMN IF NOT EXISTS ocm_status text;
ALTER TABLE public.leads ADD COLUMN IF NOT EXISTS ocm_municipality text;
ALTER TABLE public.leads ADD COLUMN IF NOT EXISTS ocm_expiration_date text;

-- Create lead_import_errors table for tracking failed row imports
CREATE TABLE IF NOT EXISTS public.lead_import_errors (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  lead_list_id uuid REFERENCES public.lead_lists(id) ON DELETE CASCADE,
  row_index integer NOT NULL,
  raw_row jsonb,
  error_message text,
  created_at timestamp with time zone DEFAULT now()
);

-- Enable RLS on lead_import_errors
ALTER TABLE public.lead_import_errors ENABLE ROW LEVEL SECURITY;

-- Admin can view all import errors
CREATE POLICY "Admin can view lead import errors" ON public.lead_import_errors
  FOR SELECT USING (
    EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = auth.uid() AND role = 'admin')
  );

-- Admin can insert import errors
CREATE POLICY "Admin can insert lead import errors" ON public.lead_import_errors
  FOR INSERT WITH CHECK (true);

-- Create index for faster lookups
CREATE INDEX IF NOT EXISTS idx_leads_source_list_name ON public.leads(source_list_name);
CREATE INDEX IF NOT EXISTS idx_leads_import_bucket ON public.leads(import_bucket);
CREATE INDEX IF NOT EXISTS idx_lead_import_errors_list_id ON public.lead_import_errors(lead_list_id);

-- =================================================================
-- MIGRATION: 20251203000129_10ee26c1-0376-4d42-982b-fa02f81f63fe.sql
-- =================================================================
-- Add bounce-back tracking fields to leads table
ALTER TABLE public.leads 
ADD COLUMN IF NOT EXISTS phone_invalid boolean DEFAULT false,
ADD COLUMN IF NOT EXISTS email_invalid boolean DEFAULT false,
ADD COLUMN IF NOT EXISTS missing_phone boolean DEFAULT false,
ADD COLUMN IF NOT EXISTS missing_email boolean DEFAULT false,
ADD COLUMN IF NOT EXISTS last_dial_disposition text,
ADD COLUMN IF NOT EXISTS dial_attempts integer DEFAULT 0,
ADD COLUMN IF NOT EXISTS last_email_event text,
ADD COLUMN IF NOT EXISTS email_attempts integer DEFAULT 0;

-- Create index for research queue filtering
CREATE INDEX IF NOT EXISTS idx_leads_research_bounce ON public.leads (import_bucket, research_status, phone_invalid, email_invalid, missing_phone, missing_email);

-- =================================================================
-- MIGRATION: 20251203001810_e88382f9-0105-46c6-8ad7-4c59c329f7e4.sql
-- =================================================================
-- Add locking columns to leads table for Client Engine V4
ALTER TABLE public.leads
ADD COLUMN IF NOT EXISTS locked_by_worker_id uuid REFERENCES auth.users(id),
ADD COLUMN IF NOT EXISTS locked_by_worker_email text,
ADD COLUMN IF NOT EXISTS lock_reason text,
ADD COLUMN IF NOT EXISTS lock_started_at timestamptz;

-- Create SMS/Email logs table for Client Engine V4
CREATE TABLE IF NOT EXISTS public.client_communications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id uuid NOT NULL REFERENCES public.leads(id) ON DELETE CASCADE,
  worker_id uuid NOT NULL REFERENCES auth.users(id),
  worker_email text,
  channel text NOT NULL CHECK (channel IN ('sms', 'email')),
  template_type text NOT NULL,
  recipient_phone text,
  recipient_email text,
  subject text,
  body text NOT NULL,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'sent', 'delivered', 'failed', 'opened', 'clicked', 'bounced')),
  sent_at timestamptz,
  delivered_at timestamptz,
  metadata jsonb DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- Create index for fast lookups
CREATE INDEX IF NOT EXISTS idx_client_communications_lead_id ON public.client_communications(lead_id);
CREATE INDEX IF NOT EXISTS idx_client_communications_worker_id ON public.client_communications(worker_id);
CREATE INDEX IF NOT EXISTS idx_leads_locked_by_worker ON public.leads(locked_by_worker_id) WHERE locked_by_worker_id IS NOT NULL;

-- Enable RLS
ALTER TABLE public.client_communications ENABLE ROW LEVEL SECURITY;

-- RLS policies for client_communications
CREATE POLICY "Workers can view their own communications"
ON public.client_communications FOR SELECT
USING (worker_id = auth.uid() OR has_role(auth.uid(), 'admin'::public.app_role));

CREATE POLICY "Workers can insert communications"
ON public.client_communications FOR INSERT
WITH CHECK (worker_id = auth.uid() OR has_role(auth.uid(), 'admin'::public.app_role));

CREATE POLICY "System can update communications"
ON public.client_communications FOR UPDATE
USING (true);

-- Create client_notes table for timeline
CREATE TABLE IF NOT EXISTS public.client_notes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id uuid NOT NULL REFERENCES public.leads(id) ON DELETE CASCADE,
  worker_id uuid NOT NULL REFERENCES auth.users(id),
  worker_email text,
  note text NOT NULL,
  note_type text DEFAULT 'general',
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_client_notes_lead_id ON public.client_notes(lead_id);

ALTER TABLE public.client_notes ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Workers can view notes for their leads"
ON public.client_notes FOR SELECT
USING (worker_id = auth.uid() OR has_role(auth.uid(), 'admin'::public.app_role));

CREATE POLICY "Workers can insert notes"
ON public.client_notes FOR INSERT
WITH CHECK (worker_id = auth.uid() OR has_role(auth.uid(), 'admin'::public.app_role));

-- Create function to lock lead on send info or application start
CREATE OR REPLACE FUNCTION public.lock_lead_for_client_work(
  p_lead_id uuid,
  p_worker_id uuid,
  p_reason text DEFAULT 'in_funding'
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE
  v_worker_email text;
  v_lock_expires timestamptz;
BEGIN
  SELECT email INTO v_worker_email FROM auth.users WHERE id = p_worker_id;
  v_lock_expires := now() + INTERVAL '7 days';

  UPDATE leads
  SET
    locked_by_worker_id = p_worker_id,
    locked_by_worker_email = v_worker_email,
    lock_expires_at = v_lock_expires,
    lock_reason = p_reason,
    lock_started_at = now(),
    current_owner_id = p_worker_id,
    current_owner_email = v_worker_email,
    updated_at = now()
  WHERE id = p_lead_id;
END;
$$;

-- =================================================================
-- MIGRATION: 20251203002918_60097559-99fb-47a9-8b9d-2f94b58a6401.sql
-- =================================================================
-- 1. Create client_activity table for unified timeline
CREATE TABLE IF NOT EXISTS client_activity (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id uuid NOT NULL REFERENCES leads(id) ON DELETE CASCADE,
  worker_id uuid,
  type text NOT NULL,
  channel text,
  direction text,
  subject text,
  body text,
  meta jsonb DEFAULT '{}'::jsonb,
  created_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_client_activity_lead ON client_activity(lead_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_client_activity_worker ON client_activity(worker_id, created_at DESC);

-- 2. Add missing fields to leads table
ALTER TABLE leads ADD COLUMN IF NOT EXISTS phone_valid boolean;
ALTER TABLE leads ADD COLUMN IF NOT EXISTS email_valid boolean;
ALTER TABLE leads ADD COLUMN IF NOT EXISTS credit_fix_status text;
ALTER TABLE leads ADD COLUMN IF NOT EXISTS credit_fix_worker_id uuid;
ALTER TABLE leads ADD COLUMN IF NOT EXISTS application_url text;
ALTER TABLE leads ADD COLUMN IF NOT EXISTS application_status text;
ALTER TABLE leads ADD COLUMN IF NOT EXISTS last_application_sent_at timestamptz;

-- 3. Enable RLS on client_activity
ALTER TABLE client_activity ENABLE ROW LEVEL SECURITY;

-- 4. RLS policies for client_activity
CREATE POLICY "Workers can view activity for their leads"
ON client_activity FOR SELECT
USING (
  worker_id = auth.uid() 
  OR has_role(auth.uid(), 'admin'::public.app_role)
  OR has_role(auth.uid(), 'worker'::public.app_role)
);

CREATE POLICY "Workers can insert activity"
ON client_activity FOR INSERT
WITH CHECK (
  worker_id = auth.uid() 
  OR has_role(auth.uid(), 'admin'::public.app_role)
  OR has_role(auth.uid(), 'worker'::public.app_role)
);

CREATE POLICY "System can insert activity"
ON client_activity FOR INSERT
WITH CHECK (true);

-- =================================================================
-- MIGRATION: 20251203011126_768cb84a-44c0-45e4-9ff8-de1164251240.sql
-- =================================================================
-- Complete migration: Create all missing tables and enums

-- 1. Create enums if they don't exist
DO $$ BEGIN
  CREATE TYPE public.case_stage AS ENUM (
    'lead_new', 'lead_contacted', 'docs_requested', 'docs_received',
    'uw_in_review', 'uw_conditional', 'uw_approved', 'uw_declined',
    'sent_to_credit_fix', 'credit_fix_in_progress', 'credit_fix_ready_for_uw',
    'offer_sent', 'offer_accepted', 'funded', 'closed_lost'
  );
EXCEPTION WHEN duplicate_object THEN NULL;
END $$;

DO $$ BEGIN
  CREATE TYPE public.product_line AS ENUM (
    'mca', 'term_loan', 'loc', 'credit_fix_only', 'hybrid', 'general'
  );
EXCEPTION WHEN duplicate_object THEN NULL;
END $$;

-- 2. Add columns to underwriting_cases if not exists
DO $$ BEGIN
  ALTER TABLE public.underwriting_cases ADD COLUMN current_stage public.case_stage DEFAULT 'lead_new';
EXCEPTION WHEN duplicate_column THEN NULL;
END $$;

DO $$ BEGIN
  ALTER TABLE public.underwriting_cases ADD COLUMN product_line public.product_line DEFAULT 'mca';
EXCEPTION WHEN duplicate_column THEN NULL;
END $$;

DO $$ BEGIN
  ALTER TABLE public.underwriting_cases ADD COLUMN origin_source text;
EXCEPTION WHEN duplicate_column THEN NULL;
END $$;

DO $$ BEGIN
  ALTER TABLE public.underwriting_cases ADD COLUMN ai_score integer;
EXCEPTION WHEN duplicate_column THEN NULL;
END $$;

DO $$ BEGIN
  ALTER TABLE public.underwriting_cases ADD COLUMN funding_score integer;
EXCEPTION WHEN duplicate_column THEN NULL;
END $$;

DO $$ BEGIN
  ALTER TABLE public.underwriting_cases ADD COLUMN ai_priority text;
EXCEPTION WHEN duplicate_column THEN NULL;
END $$;

DO $$ BEGIN
  ALTER TABLE public.underwriting_cases ADD COLUMN ai_recommended_path text;
EXCEPTION WHEN duplicate_column THEN NULL;
END $$;

DO $$ BEGIN
  ALTER TABLE public.underwriting_cases ADD COLUMN credit_fix_user_id uuid;
EXCEPTION WHEN duplicate_column THEN NULL;
END $$;

DO $$ BEGIN
  ALTER TABLE public.underwriting_cases ADD COLUMN system_notes jsonb DEFAULT '[]'::jsonb;
EXCEPTION WHEN duplicate_column THEN NULL;
END $$;

-- 3. Create message_templates table
CREATE TABLE public.message_templates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  product_line public.product_line NOT NULL DEFAULT 'general',
  channel text NOT NULL CHECK (channel IN ('sms', 'email')),
  audience text NOT NULL CHECK (audience IN ('client', 'iso', 'funder', 'internal')),
  role_scope text NOT NULL DEFAULT 'any' CHECK (role_scope IN ('worker', 'underwriter', 'admin', 'credit_specialist', 'any')),
  subject text,
  body text NOT NULL,
  ai_prompt_hint text,
  is_default boolean DEFAULT false,
  is_active boolean DEFAULT true,
  created_by uuid,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- 4. Create messages_sent table
CREATE TABLE public.messages_sent (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  case_id uuid REFERENCES public.underwriting_cases(id),
  client_id uuid,
  lead_id uuid,
  template_id uuid,
  channel text NOT NULL CHECK (channel IN ('sms', 'email')),
  direction text NOT NULL DEFAULT 'outbound' CHECK (direction IN ('outbound', 'inbound')),
  recipient text NOT NULL,
  sender text,
  subject text,
  body text NOT NULL,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'sent', 'delivered', 'bounced', 'failed', 'replied')),
  sent_by_user_id uuid,
  sent_at timestamptz,
  delivered_at timestamptz,
  reply_due_at timestamptz,
  replied_at timestamptz,
  meta jsonb DEFAULT '{}'::jsonb,
  created_at timestamptz DEFAULT now()
);

-- 5. Create workflow_tasks table
CREATE TABLE public.workflow_tasks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  case_id uuid REFERENCES public.underwriting_cases(id),
  client_id uuid,
  lead_id uuid,
  assigned_to_user_id uuid,
  created_by text NOT NULL DEFAULT 'system' CHECK (created_by IN ('system', 'ai', 'user')),
  created_by_user_id uuid,
  task_type text NOT NULL,
  title text NOT NULL,
  description text,
  status text NOT NULL DEFAULT 'open' CHECK (status IN ('open', 'in_progress', 'done', 'snoozed', 'cancelled')),
  priority text DEFAULT 'medium' CHECK (priority IN ('low', 'medium', 'high', 'urgent')),
  due_at timestamptz,
  snoozed_until timestamptz,
  completed_at timestamptz,
  meta jsonb DEFAULT '{}'::jsonb,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- 6. Enable RLS
ALTER TABLE public.message_templates ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.messages_sent ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.workflow_tasks ENABLE ROW LEVEL SECURITY;

-- 7. RLS for message_templates
CREATE POLICY "mt_admin_all" ON public.message_templates FOR ALL
USING (has_role(auth.uid(), 'admin'::public.app_role));

CREATE POLICY "mt_view" ON public.message_templates FOR SELECT
USING (has_role(auth.uid(), 'worker'::public.app_role) OR has_role(auth.uid(), 'underwriter'::public.app_role) OR has_role(auth.uid(), 'credit_repair_specialist'::public.app_role) OR has_role(auth.uid(), 'admin'::public.app_role));

-- 8. RLS for messages_sent
CREATE POLICY "ms_view" ON public.messages_sent FOR SELECT
USING (sent_by_user_id = auth.uid() OR has_role(auth.uid(), 'admin'::public.app_role));

CREATE POLICY "ms_insert" ON public.messages_sent FOR INSERT
WITH CHECK (true);

CREATE POLICY "ms_update" ON public.messages_sent FOR UPDATE
USING (true);

-- 9. RLS for workflow_tasks
CREATE POLICY "wt_view" ON public.workflow_tasks FOR SELECT
USING (assigned_to_user_id = auth.uid() OR has_role(auth.uid(), 'admin'::public.app_role));

CREATE POLICY "wt_update" ON public.workflow_tasks FOR UPDATE
USING (assigned_to_user_id = auth.uid() OR has_role(auth.uid(), 'admin'::public.app_role));

CREATE POLICY "wt_insert" ON public.workflow_tasks FOR INSERT
WITH CHECK (true);

-- 10. Indexes
CREATE INDEX idx_ms_case ON public.messages_sent(case_id);
CREATE INDEX idx_ms_lead ON public.messages_sent(lead_id);
CREATE INDEX idx_ms_status ON public.messages_sent(status);
CREATE INDEX idx_wt_assigned ON public.workflow_tasks(assigned_to_user_id);
CREATE INDEX idx_wt_status ON public.workflow_tasks(status);
CREATE INDEX idx_wt_due ON public.workflow_tasks(due_at);
CREATE INDEX idx_uc_stage ON public.underwriting_cases(current_stage);

-- 11. Triggers
CREATE TRIGGER tr_wt_updated BEFORE UPDATE ON public.workflow_tasks FOR EACH ROW EXECUTE FUNCTION public.handle_updated_at();
CREATE TRIGGER tr_mt_updated BEFORE UPDATE ON public.message_templates FOR EACH ROW EXECUTE FUNCTION public.handle_updated_at();

-- =================================================================
-- MIGRATION: 20251203011543_d11124cf-9e77-4e14-9a2d-d397a5e0c21c.sql
-- =================================================================
-- Function to update case stage with automatic activity logging
CREATE OR REPLACE FUNCTION public.update_case_stage(
  p_case_id uuid,
  p_new_stage case_stage,
  p_actor_user_id uuid DEFAULT NULL,
  p_notes text DEFAULT NULL
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_old_stage case_stage;
  v_actor_email text;
BEGIN
  -- Get current stage
  SELECT current_stage INTO v_old_stage
  FROM underwriting_cases
  WHERE id = p_case_id;

  -- Get actor email
  IF p_actor_user_id IS NOT NULL THEN
    SELECT email INTO v_actor_email FROM auth.users WHERE id = p_actor_user_id;
  END IF;

  -- Update case
  UPDATE underwriting_cases
  SET 
    current_stage = p_new_stage,
    updated_at = now()
  WHERE id = p_case_id;

  -- Log to client_activity
  INSERT INTO client_activity (
    type,
    body,
    channel,
    direction,
    worker_id,
    meta
  ) VALUES (
    'stage_change',
    COALESCE(p_notes, format('Case stage changed from %s to %s', v_old_stage, p_new_stage)),
    'system',
    'internal',
    p_actor_user_id,
    jsonb_build_object(
      'case_id', p_case_id,
      'old_stage', v_old_stage,
      'new_stage', p_new_stage,
      'actor_email', v_actor_email
    )
  );
END;
$$;

-- Add underwriter role to app_role enum if not exists
DO $$ BEGIN
  ALTER TYPE public.app_role ADD VALUE IF NOT EXISTS 'underwriter';
EXCEPTION WHEN duplicate_object THEN NULL;
END $$;

-- =================================================================
-- MIGRATION: 20251203011912_0d9707c7-eddd-400f-8a77-16fd6dabbecd.sql
-- =================================================================

-- Add missing product_line enum values
ALTER TYPE product_line ADD VALUE IF NOT EXISTS 'credit_fix';
ALTER TYPE product_line ADD VALUE IF NOT EXISTS 'loan';

