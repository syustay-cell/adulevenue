-- =================================================================
-- MIGRATION: 20251202034351_58157ce2-4c14-4069-89e3-520411705d00.sql
-- =================================================================
-- Dialer V3: Data Model Changes

-- 1. Extend leads table with ownership and dialer status
ALTER TABLE leads
ADD COLUMN IF NOT EXISTS current_owner_id uuid,
ADD COLUMN IF NOT EXISTS current_owner_email text,
ADD COLUMN IF NOT EXISTS lock_expires_at timestamptz,
ADD COLUMN IF NOT EXISTS lock_reason text,
ADD COLUMN IF NOT EXISTS dialer_status text NOT NULL DEFAULT 'new',
ADD COLUMN IF NOT EXISTS last_call_at timestamptz,
ADD COLUMN IF NOT EXISTS last_call_outcome text,
ADD COLUMN IF NOT EXISTS last_called_by uuid;

-- Create index for dialer queries
CREATE INDEX IF NOT EXISTS idx_leads_dialer_status ON leads(dialer_status);
CREATE INDEX IF NOT EXISTS idx_leads_current_owner ON leads(current_owner_id);

-- 2. Create lead_ownerships table
CREATE TABLE IF NOT EXISTS lead_ownerships (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id uuid NOT NULL REFERENCES leads(id) ON DELETE CASCADE,
  primary_owner_id uuid NOT NULL,
  primary_owner_email text NOT NULL,
  secondary_owner_id uuid,
  secondary_owner_email text,
  share_primary numeric(5,2) NOT NULL DEFAULT 1.00,
  share_secondary numeric(5,2) NOT NULL DEFAULT 0.00,
  lock_start_at timestamptz NOT NULL DEFAULT now(),
  lock_expires_at timestamptz NOT NULL,
  lock_reason text NOT NULL,
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_lead_ownerships_lead_id ON lead_ownerships(lead_id);
CREATE INDEX IF NOT EXISTS idx_lead_ownerships_primary ON lead_ownerships(primary_owner_id);
CREATE INDEX IF NOT EXISTS idx_lead_ownerships_active ON lead_ownerships(is_active);

-- 3. Create lead_release_requests table
CREATE TABLE IF NOT EXISTS lead_release_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id uuid NOT NULL REFERENCES leads(id) ON DELETE CASCADE,
  from_worker_id uuid NOT NULL,
  from_worker_email text NOT NULL,
  to_worker_id uuid NOT NULL,
  to_worker_email text NOT NULL,
  status text NOT NULL DEFAULT 'pending',
  resolution_notes text,
  created_at timestamptz NOT NULL DEFAULT now(),
  resolved_at timestamptz,
  resolved_by uuid,
  resolved_by_email text
);

CREATE INDEX IF NOT EXISTS idx_lead_release_requests_lead ON lead_release_requests(lead_id);
CREATE INDEX IF NOT EXISTS idx_lead_release_requests_from ON lead_release_requests(from_worker_id);
CREATE INDEX IF NOT EXISTS idx_lead_release_requests_to ON lead_release_requests(to_worker_id);
CREATE INDEX IF NOT EXISTS idx_lead_release_requests_status ON lead_release_requests(status);

-- RLS for lead_ownerships
ALTER TABLE lead_ownerships ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Workers can view their ownerships"
ON lead_ownerships FOR SELECT
USING (
  primary_owner_id = auth.uid() OR 
  secondary_owner_id = auth.uid() OR
  has_role(auth.uid(), 'admin'::public.app_role)
);

CREATE POLICY "System can insert ownerships"
ON lead_ownerships FOR INSERT
WITH CHECK (true);

CREATE POLICY "System can update ownerships"
ON lead_ownerships FOR UPDATE
USING (true);

-- RLS for lead_release_requests
ALTER TABLE lead_release_requests ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Workers can view their release requests"
ON lead_release_requests FOR SELECT
USING (
  from_worker_id = auth.uid() OR 
  to_worker_id = auth.uid() OR
  has_role(auth.uid(), 'admin'::public.app_role)
);

CREATE POLICY "Workers can create release requests"
ON lead_release_requests FOR INSERT
WITH CHECK (from_worker_id = auth.uid());

CREATE POLICY "Owners can update release requests"
ON lead_release_requests FOR UPDATE
USING (to_worker_id = auth.uid() OR has_role(auth.uid(), 'admin'::public.app_role));

-- RPC: get_next_lead_for_worker
CREATE OR REPLACE FUNCTION get_next_lead_for_worker(p_worker_id uuid)
RETURNS leads AS $$
DECLARE
  v_lead leads;
BEGIN
  -- Try "new" leads that nobody owns yet
  SELECT *
  INTO v_lead
  FROM leads
  WHERE dialer_status = 'new'
    AND (current_owner_id IS NULL OR current_owner_id = p_worker_id)
  ORDER BY ai_score DESC NULLS LAST, created_at ASC
  LIMIT 1
  FOR UPDATE SKIP LOCKED;

  IF NOT FOUND THEN
    -- Try callback leads scheduled for this worker
    SELECT *
    INTO v_lead
    FROM leads
    WHERE dialer_status = 'callback'
      AND current_owner_id = p_worker_id
    ORDER BY last_call_at ASC NULLS LAST
    LIMIT 1
    FOR UPDATE SKIP LOCKED;
  END IF;

  IF NOT FOUND THEN
    RETURN NULL;
  END IF;

  -- Lock as in progress
  UPDATE leads
  SET 
    dialer_status = 'in_progress',
    last_called_by = p_worker_id
  WHERE id = v_lead.id;

  -- Return updated lead
  SELECT * INTO v_lead FROM leads WHERE id = v_lead.id;
  
  RETURN v_lead;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

-- RPC: mark_call_outcome
CREATE OR REPLACE FUNCTION mark_call_outcome(
  p_lead_id uuid,
  p_worker_id uuid,
  p_outcome text,
  p_next_action text,
  p_callback_at timestamptz DEFAULT NULL
)
RETURNS void AS $$
BEGIN
  UPDATE leads
  SET
    last_call_at = now(),
    last_call_outcome = p_outcome,
    last_called_by = p_worker_id,
    dialer_status = CASE
      WHEN p_next_action = 'schedule_callback' THEN 'callback'
      WHEN p_next_action = 'not_interested' THEN 'not_interested'
      WHEN p_next_action = 'dead' THEN 'dead'
      WHEN p_next_action = 'convert_to_application' THEN 'converted'
      ELSE 'new'
    END
  WHERE id = p_lead_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

-- RPC: lock_lead_for_application
CREATE OR REPLACE FUNCTION lock_lead_for_application(
  p_lead_id uuid,
  p_worker_id uuid,
  p_days integer DEFAULT 7
)
RETURNS void AS $$
DECLARE
  v_worker_email text;
  v_lock_expires timestamptz;
BEGIN
  -- Get worker email
  SELECT email INTO v_worker_email FROM auth.users WHERE id = p_worker_id;
  v_lock_expires := now() + (p_days || ' days')::interval;

  -- Deactivate any existing ownerships for this lead
  UPDATE lead_ownerships
  SET is_active = false
  WHERE lead_id = p_lead_id AND is_active = true;

  -- Insert new ownership
  INSERT INTO lead_ownerships (
    lead_id,
    primary_owner_id,
    primary_owner_email,
    lock_expires_at,
    lock_reason,
    is_active
  ) VALUES (
    p_lead_id,
    p_worker_id,
    v_worker_email,
    v_lock_expires,
    'application_submitted',
    true
  );

  -- Update leads table
  UPDATE leads
  SET
    current_owner_id = p_worker_id,
    current_owner_email = v_worker_email,
    lock_expires_at = v_lock_expires,
    lock_reason = 'application_submitted'
  WHERE id = p_lead_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

-- RPC: request_lead_release
CREATE OR REPLACE FUNCTION request_lead_release(
  p_lead_id uuid,
  p_from_worker_id uuid
)
RETURNS lead_release_requests AS $$
DECLARE
  v_current_owner uuid;
  v_current_owner_email text;
  v_from_worker_email text;
  v_request lead_release_requests;
BEGIN
  -- Get current owner
  SELECT current_owner_id, current_owner_email 
  INTO v_current_owner, v_current_owner_email
  FROM leads
  WHERE id = p_lead_id;

  IF v_current_owner IS NULL THEN
    RAISE EXCEPTION 'Lead has no current owner';
  END IF;

  -- Get requesting worker email
  SELECT email INTO v_from_worker_email FROM auth.users WHERE id = p_from_worker_id;

  -- Create request
  INSERT INTO lead_release_requests (
    lead_id,
    from_worker_id,
    from_worker_email,
    to_worker_id,
    to_worker_email,
    status
  ) VALUES (
    p_lead_id,
    p_from_worker_id,
    v_from_worker_email,
    v_current_owner,
    v_current_owner_email,
    'pending'
  )
  RETURNING * INTO v_request;

  RETURN v_request;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

-- RPC: respond_to_lead_release
CREATE OR REPLACE FUNCTION respond_to_lead_release(
  p_request_id uuid,
  p_responder_id uuid,
  p_response text
)
RETURNS void AS $$
DECLARE
  v_request lead_release_requests;
  v_responder_email text;
BEGIN
  -- Get request
  SELECT * INTO v_request
  FROM lead_release_requests
  WHERE id = p_request_id;

  IF v_request IS NULL THEN
    RAISE EXCEPTION 'Request not found';
  END IF;

  IF v_request.to_worker_id != p_responder_id THEN
    RAISE EXCEPTION 'Only the current owner can respond';
  END IF;

  -- Get responder email
  SELECT email INTO v_responder_email FROM auth.users WHERE id = p_responder_id;

  -- Handle response
  IF p_response = 'release' THEN
    -- Deactivate old ownership
    UPDATE lead_ownerships
    SET is_active = false
    WHERE lead_id = v_request.lead_id AND is_active = true;

    -- Create new ownership for requester
    INSERT INTO lead_ownerships (
      lead_id,
      primary_owner_id,
      primary_owner_email,
      lock_expires_at,
      lock_reason,
      is_active
    ) VALUES (
      v_request.lead_id,
      v_request.from_worker_id,
      v_request.from_worker_email,
      now() + INTERVAL '7 days',
      'transferred_ownership',
      true
    );

    -- Update lead
    UPDATE leads
    SET
      current_owner_id = v_request.from_worker_id,
      current_owner_email = v_request.from_worker_email,
      lock_expires_at = now() + INTERVAL '7 days',
      lock_reason = 'transferred_ownership'
    WHERE id = v_request.lead_id;

  ELSIF p_response = 'split_50_50' THEN
    -- Update existing ownership to 50/50
    UPDATE lead_ownerships
    SET
      secondary_owner_id = v_request.from_worker_id,
      secondary_owner_email = v_request.from_worker_email,
      share_primary = 0.50,
      share_secondary = 0.50
    WHERE lead_id = v_request.lead_id AND is_active = true;

  END IF;

  -- Update request
  UPDATE lead_release_requests
  SET
    status = p_response,
    resolved_at = now(),
    resolved_by = p_responder_id,
    resolved_by_email = v_responder_email
  WHERE id = p_request_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

-- =================================================================
-- MIGRATION: 20251202042502_14dbc5d6-a983-4925-b375-ad85f10a6669.sql
-- =================================================================
-- Add research-related columns to leads table
ALTER TABLE leads
  ADD COLUMN IF NOT EXISTS route text DEFAULT 'unsorted',
  ADD COLUMN IF NOT EXISTS research_status text,
  ADD COLUMN IF NOT EXISTS research_owner_id uuid,
  ADD COLUMN IF NOT EXISTS research_notes text,
  ADD COLUMN IF NOT EXISTS research_last_action_at timestamptz;

-- Create index for research queries
CREATE INDEX IF NOT EXISTS idx_leads_route_research 
  ON leads(route, research_status) 
  WHERE route = 'research';

-- Create lead_research_logs table for audit trail
CREATE TABLE IF NOT EXISTS lead_research_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id uuid NOT NULL REFERENCES leads(id) ON DELETE CASCADE,
  worker_id uuid NOT NULL,
  action text NOT NULL,
  details jsonb,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS on lead_research_logs
ALTER TABLE lead_research_logs ENABLE ROW LEVEL SECURITY;

-- Workers can see research logs for their leads and admins can see all
CREATE POLICY "Workers can view research logs"
  ON lead_research_logs
  FOR SELECT
  USING (
    worker_id = auth.uid()
    OR EXISTS (
      SELECT 1 FROM user_roles 
      WHERE user_id = auth.uid() 
      AND role = 'admin' 
      AND approved = true
    )
  );

-- Workers can insert research logs
CREATE POLICY "Workers can create research logs"
  ON lead_research_logs
  FOR INSERT
  WITH CHECK (worker_id = auth.uid());

-- =================================================================
-- MIGRATION: 20251202043749_17c9b52f-3404-4663-8055-97225b5314f0.sql
-- =================================================================
-- Add raw_data column to leads table for storing complete dissected row
ALTER TABLE leads
ADD COLUMN IF NOT EXISTS raw_data jsonb DEFAULT '{}'::jsonb;

-- =================================================================
-- MIGRATION: 20251202044036_8e33efde-a2d4-4328-a801-037d917e91fe.sql
-- =================================================================
-- Add research workflow columns to leads table
ALTER TABLE leads
ADD COLUMN IF NOT EXISTS research_status text DEFAULT 'pending',
ADD COLUMN IF NOT EXISTS research_assigned_to uuid,
ADD COLUMN IF NOT EXISTS research_started_at timestamptz,
ADD COLUMN IF NOT EXISTS research_completed_at timestamptz,
ADD COLUMN IF NOT EXISTS research_notes text,
ADD COLUMN IF NOT EXISTS research_attempts int DEFAULT 0;

-- Create RPC to claim next research lead (atomic lock)
CREATE OR REPLACE FUNCTION claim_next_research_lead(p_worker_id uuid)
RETURNS leads AS $$
DECLARE
  v_lead leads;
BEGIN
  UPDATE leads
  SET
    research_status = 'in_progress',
    research_assigned_to = p_worker_id,
    research_started_at = NOW(),
    research_attempts = COALESCE(research_attempts, 0) + 1
  WHERE id = (
    SELECT id FROM leads
    WHERE route = 'research'
      AND (research_status = 'pending' OR research_status IS NULL)
    ORDER BY created_at ASC
    LIMIT 1
    FOR UPDATE SKIP LOCKED
  )
  RETURNING * INTO v_lead;

  RETURN v_lead;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- =================================================================
-- MIGRATION: 20251202044056_777a9892-6176-448e-952d-c06eb8a5800e.sql
-- =================================================================
-- Fix search_path security warning for claim_next_research_lead
CREATE OR REPLACE FUNCTION claim_next_research_lead(p_worker_id uuid)
RETURNS leads AS $$
DECLARE
  v_lead leads;
BEGIN
  UPDATE leads
  SET
    research_status = 'in_progress',
    research_assigned_to = p_worker_id,
    research_started_at = NOW(),
    research_attempts = COALESCE(research_attempts, 0) + 1
  WHERE id = (
    SELECT id FROM leads
    WHERE route = 'research'
      AND (research_status = 'pending' OR research_status IS NULL)
    ORDER BY created_at ASC
    LIMIT 1
    FOR UPDATE SKIP LOCKED
  )
  RETURNING * INTO v_lead;

  RETURN v_lead;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = 'public';

-- =================================================================
-- MIGRATION: 20251202045703_bea19c3a-ecdc-49aa-8dac-e7be939030c2.sql
-- =================================================================
-- Add route classification columns to leads table
ALTER TABLE leads
  ADD COLUMN IF NOT EXISTS route text CHECK (route IN ('dialer','email','research','parked')) DEFAULT 'dialer',
  ADD COLUMN IF NOT EXISTS missing_phone boolean DEFAULT false,
  ADD COLUMN IF NOT EXISTS missing_email boolean DEFAULT false;

-- Create index for route queries
CREATE INDEX IF NOT EXISTS idx_leads_route ON leads(route);
CREATE INDEX IF NOT EXISTS idx_leads_route_status ON leads(route, status);

-- =================================================================
-- MIGRATION: 20251202045830_5fcd677a-2049-4c73-8d81-c489ccd51214.sql
-- =================================================================
-- Update claim_next_research_lead to filter by route='research'
CREATE OR REPLACE FUNCTION public.claim_next_research_lead(p_worker_id uuid)
RETURNS leads
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = 'public'
AS $$
DECLARE
  v_lead leads;
BEGIN
  UPDATE leads
  SET
    research_status = 'in_progress',
    research_assigned_to = p_worker_id,
    research_started_at = NOW(),
    research_attempts = COALESCE(research_attempts, 0) + 1
  WHERE id = (
    SELECT id FROM leads
    WHERE route = 'research'
      AND (research_status = 'pending' OR research_status IS NULL)
      AND status = 'new'
    ORDER BY created_at ASC
    LIMIT 1
    FOR UPDATE SKIP LOCKED
  )
  RETURNING * INTO v_lead;

  RETURN v_lead;
END;
$$;

-- =================================================================
-- MIGRATION: 20251202051130_710eaa20-9665-4a8a-bca5-8085def20086.sql
-- =================================================================
-- V4 AI Dissection: Add enrichment fields to leads table
ALTER TABLE leads
  ADD COLUMN IF NOT EXISTS website text,
  ADD COLUMN IF NOT EXISTS linkedin_url text,
  ADD COLUMN IF NOT EXISTS owner_name text,
  ADD COLUMN IF NOT EXISTS estimated_revenue numeric,
  ADD COLUMN IF NOT EXISTS estimated_employees integer,
  ADD COLUMN IF NOT EXISTS business_type text,
  ADD COLUMN IF NOT EXISTS sic_code text,
  ADD COLUMN IF NOT EXISTS naics_code text,
  ADD COLUMN IF NOT EXISTS google_rating numeric,
  ADD COLUMN IF NOT EXISTS domain_age_years integer,
  ADD COLUMN IF NOT EXISTS has_social_media boolean DEFAULT false,
  ADD COLUMN IF NOT EXISTS enrichment_completed boolean DEFAULT false,
  ADD COLUMN IF NOT EXISTS enrichment_date timestamptz,
  ADD COLUMN IF NOT EXISTS credit_indicators jsonb,
  ADD COLUMN IF NOT EXISTS mystic_tips jsonb;

-- Create lead_files table for file attachments ("Mystic Tips")
CREATE TABLE IF NOT EXISTS lead_files (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id uuid NOT NULL REFERENCES leads(id) ON DELETE CASCADE,
  file_name text NOT NULL,
  file_path text NOT NULL,
  file_type text NOT NULL,
  file_size integer,
  uploaded_by uuid REFERENCES auth.users(id),
  uploaded_at timestamptz DEFAULT now(),
  notes text,
  is_ai_generated boolean DEFAULT false
);

CREATE INDEX IF NOT EXISTS idx_lead_files_lead_id ON lead_files(lead_id);
CREATE INDEX IF NOT EXISTS idx_leads_enrichment_completed ON leads(enrichment_completed);

-- Enable RLS on lead_files
ALTER TABLE lead_files ENABLE ROW LEVEL SECURITY;

-- Admin and workers can view all lead files
CREATE POLICY "Admin and workers can view lead files"
  ON lead_files FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM user_roles
      WHERE user_id = auth.uid()
      AND role IN ('admin', 'worker')
      AND approved = true
    )
  );

-- Admin and workers can upload lead files
CREATE POLICY "Admin and workers can upload lead files"
  ON lead_files FOR INSERT
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM user_roles
      WHERE user_id = auth.uid()
      AND role IN ('admin', 'worker')
      AND approved = true
    )
  );

-- Admin and workers can delete lead files
CREATE POLICY "Admin and workers can delete lead files"
  ON lead_files FOR DELETE
  USING (
    EXISTS (
      SELECT 1 FROM user_roles
      WHERE user_id = auth.uid()
      AND role IN ('admin', 'worker')
      AND approved = true
    )
  );

COMMENT ON COLUMN leads.mystic_tips IS 'AI-generated worker guidance: call script, questions, weak points, credit issues, recommended offer';
COMMENT ON COLUMN leads.credit_indicators IS 'AI-detected credit flags: liens, judgments, bankruptcies, address mismatches, license problems';
COMMENT ON TABLE lead_files IS 'File attachments per lead - PDFs, notes, docs, images uploaded by workers or generated by AI';

-- =================================================================
-- MIGRATION: 20251202051300_82c52444-f67a-4978-961c-5615e7a869d5.sql
-- =================================================================
-- Create storage bucket for lead files
INSERT INTO storage.buckets (id, name, public)
VALUES ('lead-files', 'lead-files', false)
ON CONFLICT (id) DO NOTHING;

-- Enable RLS on storage.objects for lead-files bucket
CREATE POLICY "Admin and workers can view lead files in storage"
  ON storage.objects FOR SELECT
  USING (
    bucket_id = 'lead-files'
    AND EXISTS (
      SELECT 1 FROM user_roles
      WHERE user_id = auth.uid()
      AND role IN ('admin', 'worker')
      AND approved = true
    )
  );

CREATE POLICY "Admin and workers can upload lead files to storage"
  ON storage.objects FOR INSERT
  WITH CHECK (
    bucket_id = 'lead-files'
    AND EXISTS (
      SELECT 1 FROM user_roles
      WHERE user_id = auth.uid()
      AND role IN ('admin', 'worker')
      AND approved = true
    )
  );

CREATE POLICY "Admin and workers can delete lead files from storage"
  ON storage.objects FOR DELETE
  USING (
    bucket_id = 'lead-files'
    AND EXISTS (
      SELECT 1 FROM user_roles
      WHERE user_id = auth.uid()
      AND role IN ('admin', 'worker')
      AND approved = true
    )
  );

-- =================================================================
-- MIGRATION: 20251202052624_565e57ae-c633-4880-8255-cb12f766166f.sql
-- =================================================================
-- 1. underwriting_files: one "UW pass" per application
CREATE TABLE IF NOT EXISTS public.underwriting_files (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  application_id UUID NOT NULL REFERENCES public.fast_track_applications(id) ON DELETE CASCADE,
  underwriter_id UUID REFERENCES auth.users(id),
  status TEXT NOT NULL DEFAULT 'intake', -- 'intake' | 'running' | 'ready_for_funding' | 'needs_more_docs'
  summary_json JSONB DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_underwriting_files_app_id
  ON public.underwriting_files (application_id);

CREATE INDEX IF NOT EXISTS idx_underwriting_files_status
  ON public.underwriting_files (status);

-- 2. funding_calls: schedules/records the funding call
CREATE TABLE IF NOT EXISTS public.funding_calls (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  application_id UUID NOT NULL REFERENCES public.fast_track_applications(id) ON DELETE CASCADE,
  scheduled_for TIMESTAMPTZ,
  dial_method TEXT DEFAULT 'phone', -- 'phone' | 'zoom' | 'teams' | 'other'
  status TEXT NOT NULL DEFAULT 'scheduled', -- 'scheduled' | 'completed' | 'no_show' | 'cancelled'
  notes TEXT,
  created_by UUID REFERENCES auth.users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_funding_calls_app_id
  ON public.funding_calls (application_id);

CREATE INDEX IF NOT EXISTS idx_funding_calls_status
  ON public.funding_calls (status);

-- 3. RLS policies - admin only for now (add underwriter role later if needed)
ALTER TABLE public.underwriting_files ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.funding_calls ENABLE ROW LEVEL SECURITY;

-- Admins can read underwriting files
CREATE POLICY "uw_files_admin_read"
ON public.underwriting_files
FOR SELECT
USING (has_role(auth.uid(), 'admin'::public.app_role));

-- Admins can write underwriting files
CREATE POLICY "uw_files_admin_write"
ON public.underwriting_files
FOR ALL
USING (has_role(auth.uid(), 'admin'::public.app_role))
WITH CHECK (has_role(auth.uid(), 'admin'::public.app_role));

-- Admins can read funding calls
CREATE POLICY "funding_calls_admin_read"
ON public.funding_calls
FOR SELECT
USING (has_role(auth.uid(), 'admin'::public.app_role));

-- Admins can write funding calls
CREATE POLICY "funding_calls_admin_write"
ON public.funding_calls
FOR ALL
USING (has_role(auth.uid(), 'admin'::public.app_role))
WITH CHECK (has_role(auth.uid(), 'admin'::public.app_role));

-- =================================================================
-- MIGRATION: 20251202053014_c1000b23-1f53-4393-a7f2-f83980d6a283.sql
-- =================================================================
-- Add underwriter role to app_role enum
ALTER TYPE public.app_role ADD VALUE IF NOT EXISTS 'underwriter';

-- =================================================================
-- MIGRATION: 20251202053902_180db81d-7088-4cf3-bb7c-07571d242f60.sql
-- =================================================================
-- Add missing columns to user_roles
ALTER TABLE user_roles ADD COLUMN IF NOT EXISTS display_name text;
ALTER TABLE user_roles ADD COLUMN IF NOT EXISTS position text;

-- Add missing columns to leads
ALTER TABLE leads ADD COLUMN IF NOT EXISTS list_id uuid;
ALTER TABLE leads ADD COLUMN IF NOT EXISTS ai_score integer;
ALTER TABLE leads ADD COLUMN IF NOT EXISTS ai_priority text;
ALTER TABLE leads ADD COLUMN IF NOT EXISTS ai_recommended_path text;
ALTER TABLE leads ADD COLUMN IF NOT EXISTS ai_risk_flags text[];
ALTER TABLE leads ADD COLUMN IF NOT EXISTS ai_notes jsonb DEFAULT '{}'::jsonb;
ALTER TABLE leads ADD COLUMN IF NOT EXISTS owner_worker_id uuid;
ALTER TABLE leads ADD COLUMN IF NOT EXISTS secondary_worker_id uuid;
ALTER TABLE leads ADD COLUMN IF NOT EXISTS lock_expires_at timestamptz;
ALTER TABLE leads ADD COLUMN IF NOT EXISTS bucket text DEFAULT 'new';

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_leads_ai_score ON leads(ai_score DESC NULLS LAST);
CREATE INDEX IF NOT EXISTS idx_leads_bucket ON leads(bucket);
CREATE INDEX IF NOT EXISTS idx_leads_owner ON leads(owner_worker_id);

-- Create new tables only if they don't exist
CREATE TABLE IF NOT EXISTS lead_import_batches (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  uploaded_by uuid,
  file_name text NOT NULL,
  source text,
  total_count integer DEFAULT 0,
  success_count integer DEFAULT 0,
  error_count integer DEFAULT 0,
  status text DEFAULT 'processing',
  error_log jsonb DEFAULT '[]'::jsonb,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS lead_ownership_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id uuid NOT NULL,
  from_worker_id uuid NOT NULL,
  to_worker_id uuid NOT NULL,
  request_type text NOT NULL,
  status text DEFAULT 'pending',
  message text,
  created_at timestamptz DEFAULT now(),
  resolved_at timestamptz
);

CREATE TABLE IF NOT EXISTS worker_commission_splits (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id uuid NOT NULL,
  primary_worker_id uuid NOT NULL,
  secondary_worker_id uuid NOT NULL,
  split_percentage integer DEFAULT 50,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS underwriting_tasks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  application_id uuid NOT NULL,
  assigned_to uuid,
  status text DEFAULT 'pending',
  checklist jsonb DEFAULT '[]'::jsonb,
  notes text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  completed_at timestamptz
);

CREATE TABLE IF NOT EXISTS lead_strategy_files (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id uuid NOT NULL,
  file_name text NOT NULL,
  file_url text NOT NULL,
  file_type text DEFAULT 'strategy',
  uploaded_by uuid,
  description text,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE lead_import_batches ENABLE ROW LEVEL SECURITY;
ALTER TABLE lead_ownership_requests ENABLE ROW LEVEL SECURITY;
ALTER TABLE worker_commission_splits ENABLE ROW LEVEL SECURITY;
ALTER TABLE underwriting_tasks ENABLE ROW LEVEL SECURITY;
ALTER TABLE lead_strategy_files ENABLE ROW LEVEL SECURITY;

-- RLS Policies
CREATE POLICY "batches_admin_read" ON lead_import_batches FOR SELECT USING (has_role(auth.uid(), 'admin'));
CREATE POLICY "batches_admin_write" ON lead_import_batches FOR INSERT WITH CHECK (has_role(auth.uid(), 'admin'));

CREATE POLICY "ownership_requests_worker_read" ON lead_ownership_requests FOR SELECT USING (from_worker_id = auth.uid() OR to_worker_id = auth.uid() OR has_role(auth.uid(), 'admin'));
CREATE POLICY "ownership_requests_worker_write" ON lead_ownership_requests FOR INSERT WITH CHECK (from_worker_id = auth.uid());
CREATE POLICY "ownership_requests_owner_resolve" ON lead_ownership_requests FOR UPDATE USING (to_worker_id = auth.uid() OR has_role(auth.uid(), 'admin'));

CREATE POLICY "splits_worker_read" ON worker_commission_splits FOR SELECT USING (primary_worker_id = auth.uid() OR secondary_worker_id = auth.uid() OR has_role(auth.uid(), 'admin'));

CREATE POLICY "uw_tasks_read" ON underwriting_tasks FOR SELECT USING (assigned_to = auth.uid() OR has_role(auth.uid(), 'admin') OR has_role(auth.uid(), 'underwriter'));
CREATE POLICY "uw_tasks_write" ON underwriting_tasks FOR ALL USING (has_role(auth.uid(), 'admin') OR has_role(auth.uid(), 'underwriter'));

CREATE POLICY "strategy_files_read" ON lead_strategy_files FOR SELECT USING (has_role(auth.uid(), 'admin') OR has_role(auth.uid(), 'worker'));
CREATE POLICY "strategy_files_write" ON lead_strategy_files FOR INSERT WITH CHECK (has_role(auth.uid(), 'admin') OR has_role(auth.uid(), 'worker'));

-- =================================================================
-- MIGRATION: 20251202062057_01418f7c-8a69-46cb-9b4c-350029010e54.sql
-- =================================================================
-- Fix Dialer V3 status constraint issue

-- 1. Add CHECK constraint to dialer_status column
ALTER TABLE leads
DROP CONSTRAINT IF EXISTS leads_dialer_status_check;

ALTER TABLE leads
ADD CONSTRAINT leads_dialer_status_check
CHECK (dialer_status IN ('new', 'in_progress', 'callback', 'not_interested', 'dead', 'converted', 'skip'));

-- 2. Ensure mark_call_outcome function is correct
CREATE OR REPLACE FUNCTION mark_call_outcome(
  p_lead_id uuid,
  p_worker_id uuid,
  p_outcome text,
  p_next_action text,
  p_callback_at timestamptz DEFAULT NULL
)
RETURNS void AS $$
DECLARE
  v_new_dialer_status text;
BEGIN
  -- Determine new dialer_status based on next_action
  v_new_dialer_status := CASE
    WHEN p_next_action = 'schedule_callback' THEN 'callback'
    WHEN p_next_action = 'not_interested' THEN 'not_interested'
    WHEN p_next_action = 'dead' THEN 'dead'
    WHEN p_next_action = 'convert_to_application' THEN 'converted'
    WHEN p_next_action = 'next' THEN 'new'
    ELSE 'new'
  END;

  -- Update the lead with call outcome
  UPDATE leads
  SET
    last_call_at = now(),
    last_call_outcome = p_outcome,
    last_called_by = p_worker_id,
    dialer_status = v_new_dialer_status,
    status = CASE 
      WHEN p_next_action = 'convert_to_application' THEN 'converted'
      WHEN p_next_action = 'not_interested' THEN 'not_qualified'
      WHEN status = 'new' THEN 'contacted'
      ELSE status
    END
  WHERE id = p_lead_id;

  -- Log the call
  INSERT INTO lead_call_attempts (
    lead_id,
    agent_id,
    agent_email,
    outcome,
    duration_seconds
  ) VALUES (
    p_lead_id,
    p_worker_id,
    (SELECT email FROM auth.users WHERE id = p_worker_id),
    p_outcome,
    0
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

-- =================================================================
-- MIGRATION: 20251202070904_5bc1a4d3-2638-4844-b149-a5af3d74a4f1.sql
-- =================================================================
-- Research Q V2: Add enrichment and AI intelligence columns to leads table

ALTER TABLE leads
ADD COLUMN IF NOT EXISTS enriched_name text,
ADD COLUMN IF NOT EXISTS enriched_phone text,
ADD COLUMN IF NOT EXISTS enriched_email text,
ADD COLUMN IF NOT EXISTS enriched_business_name text,
ADD COLUMN IF NOT EXISTS enriched_business_age_years numeric,
ADD COLUMN IF NOT EXISTS enriched_revenue_estimate numeric,
ADD COLUMN IF NOT EXISTS enriched_address text,
ADD COLUMN IF NOT EXISTS enriched_industry text,
ADD COLUMN IF NOT EXISTS enriched_online_presence_score numeric,

ADD COLUMN IF NOT EXISTS funding_score numeric,
ADD COLUMN IF NOT EXISTS funding_recommendation text,
ADD COLUMN IF NOT EXISTS credit_risk text,
ADD COLUMN IF NOT EXISTS identity_theft_risk text,
ADD COLUMN IF NOT EXISTS industry_risk text,

ADD COLUMN IF NOT EXISTS research_last_run_at timestamptz;

-- Add constraints for valid values
ALTER TABLE leads
DROP CONSTRAINT IF EXISTS leads_funding_recommendation_check;

ALTER TABLE leads
ADD CONSTRAINT leads_funding_recommendation_check
CHECK (funding_recommendation IN ('funding_first', 'credit_first', 'hybrid', 'do_not_work'));

ALTER TABLE leads
DROP CONSTRAINT IF EXISTS leads_credit_risk_check;

ALTER TABLE leads
ADD CONSTRAINT leads_credit_risk_check
CHECK (credit_risk IN ('low', 'medium', 'high'));

ALTER TABLE leads
DROP CONSTRAINT IF EXISTS leads_identity_theft_risk_check;

ALTER TABLE leads
ADD CONSTRAINT leads_identity_theft_risk_check
CHECK (identity_theft_risk IN ('low', 'medium', 'high'));

ALTER TABLE leads
DROP CONSTRAINT IF EXISTS leads_industry_risk_check;

ALTER TABLE leads
ADD CONSTRAINT leads_industry_risk_check
CHECK (industry_risk IN ('low', 'medium', 'high'));

-- =================================================================
-- MIGRATION: 20251202153700_aaa54dc0-0df2-4561-9c1f-0a7a76dd7936.sql
-- =================================================================
-- Add OCM-specific intel bucket and raw_data columns to leads
ALTER TABLE leads
  ADD COLUMN IF NOT EXISTS ocm_intel jsonb,
  ADD COLUMN IF NOT EXISTS raw_data jsonb;

-- =================================================================
-- MIGRATION: 20251202160136_74f166ee-fc65-4b01-bf04-a2fd3d99af09.sql
-- =================================================================
-- Add processing stats/summary fields to lead_lists
ALTER TABLE lead_lists
  ADD COLUMN IF NOT EXISTS dialer_count integer DEFAULT 0,
  ADD COLUMN IF NOT EXISTS email_count integer DEFAULT 0,
  ADD COLUMN IF NOT EXISTS research_count integer DEFAULT 0,
  ADD COLUMN IF NOT EXISTS rejected_count integer DEFAULT 0,
  ADD COLUMN IF NOT EXISTS header_confidence integer DEFAULT 0,
  ADD COLUMN IF NOT EXISTS field_coverage integer DEFAULT 0,
  ADD COLUMN IF NOT EXISTS header_mapping jsonb,
  ADD COLUMN IF NOT EXISTS processing_summary jsonb,
  ADD COLUMN IF NOT EXISTS source_type text DEFAULT 'generic';

-- Index for quick filtering
CREATE INDEX IF NOT EXISTS idx_lead_lists_source_type ON lead_lists(source_type);

-- =================================================================
-- MIGRATION: 20251202160540_4c1e4c07-8cdb-467b-a5ac-0dc8c68177ba.sql
-- =================================================================
-- Add V3 extraction fields to leads table
ALTER TABLE leads
  ADD COLUMN IF NOT EXISTS import_bucket text,
  ADD COLUMN IF NOT EXISTS import_confidence_score numeric,
  ADD COLUMN IF NOT EXISTS normalized_fields jsonb,
  ADD COLUMN IF NOT EXISTS ocm_license_id text,
  ADD COLUMN IF NOT EXISTS ocm_license_type text,
  ADD COLUMN IF NOT EXISTS ocm_status text,
  ADD COLUMN IF NOT EXISTS ocm_municipality text,
  ADD COLUMN IF NOT EXISTS ocm_county text,
  ADD COLUMN IF NOT EXISTS ocm_expiration_date date,
  ADD COLUMN IF NOT EXISTS enriched_name text,
  ADD COLUMN IF NOT EXISTS enriched_phone text,
  ADD COLUMN IF NOT EXISTS enriched_email text,
  ADD COLUMN IF NOT EXISTS enriched_business_name text,
  ADD COLUMN IF NOT EXISTS enriched_address text,
  ADD COLUMN IF NOT EXISTS enriched_city text,
  ADD COLUMN IF NOT EXISTS enriched_state text,
  ADD COLUMN IF NOT EXISTS enriched_zip text;

-- Add V3 fields to lead_lists table
ALTER TABLE lead_lists
  ADD COLUMN IF NOT EXISTS raw_headers jsonb,
  ADD COLUMN IF NOT EXISTS import_quality_score numeric;

-- Create indexes for new bucket field
CREATE INDEX IF NOT EXISTS idx_leads_import_bucket ON leads (import_bucket);
CREATE INDEX IF NOT EXISTS idx_leads_import_confidence ON leads (import_confidence_score DESC NULLS LAST);

-- =================================================================
-- MIGRATION: 20251202184904_9aa67ecc-d575-4670-ad1e-296b79ed073c.sql
-- =================================================================
-- WOLF ECOSYSTEM V1 - Schema Alignment (Part 2 - Views & Indexes)
-- Fix views with correct column names

-- 1. Create funding_records view (alias to funded_contracts)
CREATE OR REPLACE VIEW public.funding_records AS
SELECT 
  id,
  application_id AS lead_id,
  application_id AS underwriting_case_id,
  funding_amount AS amount_funded,
  application_type AS product_type,
  contract_start_date AS date_funded,
  notes,
  created_at
FROM public.funded_contracts;

-- 2. Create unified tasks view with correct column names
CREATE OR REPLACE VIEW public.tasks AS
SELECT 
  id,
  lead_id,
  worker_id as assigned_to,
  task_type AS type,
  due_at,
  status,
  notes,
  created_at,
  'lead' as source_table
FROM public.lead_tasks
UNION ALL
SELECT 
  id,
  NULL as lead_id,
  assigned_to,
  'underwriting' AS type,
  NULL as due_at,
  status,
  notes,
  created_at,
  'underwriting' as source_table
FROM public.underwriting_tasks
UNION ALL
SELECT 
  id,
  NULL as lead_id,
  assigned_to,
  title AS type,
  due_date as due_at,
  CASE WHEN completed THEN 'done' ELSE 'open' END as status,
  description as notes,
  created_at,
  'credit_repair' as source_table
FROM public.credit_repair_tasks;

-- 3. Add missing columns to leads table for full spec alignment
ALTER TABLE public.leads 
ADD COLUMN IF NOT EXISTS normalized_fields jsonb,
ADD COLUMN IF NOT EXISTS problem_flags text[];

-- 4. Create performance indexes
CREATE INDEX IF NOT EXISTS idx_leads_status ON public.leads(status);
CREATE INDEX IF NOT EXISTS idx_leads_ai_score ON public.leads(ai_score DESC NULLS LAST);
CREATE INDEX IF NOT EXISTS idx_leads_lead_list_id ON public.leads(lead_list_id);

-- =================================================================
-- MIGRATION: 20251202184919_35ca3dc3-13a1-4b97-82f8-2446eb6ce34d.sql
-- =================================================================
-- Fix SECURITY DEFINER views by making them SECURITY INVOKER
-- This ensures RLS policies are respected based on querying user

DROP VIEW IF EXISTS public.funding_records;
CREATE VIEW public.funding_records 
WITH (security_invoker = true)
AS
SELECT 
  id,
  application_id AS lead_id,
  application_id AS underwriting_case_id,
  funding_amount AS amount_funded,
  application_type AS product_type,
  contract_start_date AS date_funded,
  notes,
  created_at
FROM public.funded_contracts;

DROP VIEW IF EXISTS public.tasks;
CREATE VIEW public.tasks 
WITH (security_invoker = true)
AS
SELECT 
  id,
  lead_id,
  worker_id as assigned_to,
  task_type AS type,
  due_at,
  status,
  notes,
  created_at,
  'lead' as source_table
FROM public.lead_tasks
UNION ALL
SELECT 
  id,
  NULL as lead_id,
  assigned_to,
  'underwriting' AS type,
  NULL as due_at,
  status,
  notes,
  created_at,
  'underwriting' as source_table
FROM public.underwriting_tasks
UNION ALL
SELECT 
  id,
  NULL as lead_id,
  assigned_to,
  title AS type,
  due_date as due_at,
  CASE WHEN completed THEN 'done' ELSE 'open' END as status,
  description as notes,
  created_at,
  'credit_repair' as source_table
FROM public.credit_repair_tasks;

