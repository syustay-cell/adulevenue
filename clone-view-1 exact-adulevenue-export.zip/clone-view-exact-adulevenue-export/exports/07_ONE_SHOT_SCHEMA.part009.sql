-- =================================================================
-- MIGRATION: 20251204222049_59ffb53c-670d-4591-bedb-346ad41858d4.sql
-- =================================================================
-- V2.1 Credit Dispute Engine Tables

-- Tradelines / negative items per case
CREATE TABLE IF NOT EXISTS public.credit_dispute_items_v2 (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  case_id         uuid NOT NULL REFERENCES public.credit_cases_v2(id) ON DELETE CASCADE,
  tenant_id       uuid NOT NULL REFERENCES public.wf_tenants(id) ON DELETE CASCADE,
  
  bureau          text NOT NULL,  -- 'experian' | 'equifax' | 'transunion'
  creditor_name   text,
  account_number  text,
  account_type    text,           -- 'collection' | 'charge_off' | 'late_payment' | 'inquiry' | 'public_record'
  balance         numeric,
  date_opened     date,
  date_reported   date,
  
  dispute_reason  text,           -- 'not_mine' | 'inaccurate' | 'outdated' | 'fraud' | 'paid'
  dispute_status  text NOT NULL DEFAULT 'pending', -- 'pending' | 'disputed' | 'verified' | 'deleted' | 'updated'
  
  fcra_violation  text,           -- e.g. '§611', '§609'
  fdcpa_violation text,           -- e.g. '§807', '§806'
  metro2_code     text,
  
  notes           text,
  meta            jsonb NOT NULL DEFAULT '{}'::jsonb,
  
  created_by      uuid,
  created_at      timestamptz NOT NULL DEFAULT now(),
  updated_at      timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.credit_dispute_items_v2 ENABLE ROW LEVEL SECURITY;

CREATE INDEX IF NOT EXISTS idx_credit_dispute_items_v2_case ON public.credit_dispute_items_v2(case_id);
CREATE INDEX IF NOT EXISTS idx_credit_dispute_items_v2_tenant ON public.credit_dispute_items_v2(tenant_id);
CREATE INDEX IF NOT EXISTS idx_credit_dispute_items_v2_bureau ON public.credit_dispute_items_v2(bureau);

-- RLS for credit_dispute_items_v2
CREATE POLICY "Admins manage credit_dispute_items_v2"
  ON public.credit_dispute_items_v2
  FOR ALL
  USING (has_role(auth.uid(), 'admin'::public.app_role));

CREATE POLICY "Tenant workers view credit_dispute_items_v2"
  ON public.credit_dispute_items_v2
  FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM public.wf_tenant_users tu
      WHERE tu.user_id = auth.uid()
        AND tu.tenant_id = credit_dispute_items_v2.tenant_id
    )
  );

CREATE POLICY "Tenant workers insert credit_dispute_items_v2"
  ON public.credit_dispute_items_v2
  FOR INSERT
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.wf_tenant_users tu
      WHERE tu.user_id = auth.uid()
        AND tu.tenant_id = credit_dispute_items_v2.tenant_id
    )
  );

CREATE POLICY "Tenant workers update credit_dispute_items_v2"
  ON public.credit_dispute_items_v2
  FOR UPDATE
  USING (
    EXISTS (
      SELECT 1 FROM public.wf_tenant_users tu
      WHERE tu.user_id = auth.uid()
        AND tu.tenant_id = credit_dispute_items_v2.tenant_id
    )
  );

-- AI-generated dispute letter drafts
CREATE TABLE IF NOT EXISTS public.credit_dispute_drafts_v2 (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  case_id         uuid NOT NULL REFERENCES public.credit_cases_v2(id) ON DELETE CASCADE,
  tenant_id       uuid NOT NULL REFERENCES public.wf_tenants(id) ON DELETE CASCADE,
  
  bureau          text NOT NULL,  -- 'experian' | 'equifax' | 'transunion'
  letter_type     text NOT NULL DEFAULT 'dispute', -- 'dispute' | 'validation' | 'goodwill' | 'cease_desist'
  
  subject         text,
  body            text NOT NULL,
  
  items_included  uuid[] DEFAULT ARRAY[]::uuid[], -- references credit_dispute_items_v2.id
  
  status          text NOT NULL DEFAULT 'draft', -- 'draft' | 'approved' | 'sent' | 'responded'
  sent_at         timestamptz,
  response_received_at timestamptz,
  response_notes  text,
  
  ai_model        text,           -- e.g. 'gemini-2.5-flash'
  ai_prompt_used  text,
  
  meta            jsonb NOT NULL DEFAULT '{}'::jsonb,
  
  created_by      uuid,
  created_at      timestamptz NOT NULL DEFAULT now(),
  updated_at      timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.credit_dispute_drafts_v2 ENABLE ROW LEVEL SECURITY;

CREATE INDEX IF NOT EXISTS idx_credit_dispute_drafts_v2_case ON public.credit_dispute_drafts_v2(case_id);
CREATE INDEX IF NOT EXISTS idx_credit_dispute_drafts_v2_tenant ON public.credit_dispute_drafts_v2(tenant_id);
CREATE INDEX IF NOT EXISTS idx_credit_dispute_drafts_v2_status ON public.credit_dispute_drafts_v2(status);

-- RLS for credit_dispute_drafts_v2
CREATE POLICY "Admins manage credit_dispute_drafts_v2"
  ON public.credit_dispute_drafts_v2
  FOR ALL
  USING (has_role(auth.uid(), 'admin'::public.app_role));

CREATE POLICY "Tenant workers view credit_dispute_drafts_v2"
  ON public.credit_dispute_drafts_v2
  FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM public.wf_tenant_users tu
      WHERE tu.user_id = auth.uid()
        AND tu.tenant_id = credit_dispute_drafts_v2.tenant_id
    )
  );

CREATE POLICY "Tenant workers insert credit_dispute_drafts_v2"
  ON public.credit_dispute_drafts_v2
  FOR INSERT
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.wf_tenant_users tu
      WHERE tu.user_id = auth.uid()
        AND tu.tenant_id = credit_dispute_drafts_v2.tenant_id
    )
  );

CREATE POLICY "Tenant workers update credit_dispute_drafts_v2"
  ON public.credit_dispute_drafts_v2
  FOR UPDATE
  USING (
    EXISTS (
      SELECT 1 FROM public.wf_tenant_users tu
      WHERE tu.user_id = auth.uid()
        AND tu.tenant_id = credit_dispute_drafts_v2.tenant_id
    )
  );

-- V2.2 Tasks table
CREATE TABLE IF NOT EXISTS public.wf_tasks (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id       uuid NOT NULL REFERENCES public.wf_tenants(id) ON DELETE CASCADE,
  
  case_id         uuid REFERENCES public.credit_cases_v2(id) ON DELETE CASCADE,
  lead_id         uuid REFERENCES public.wf_leads(id) ON DELETE CASCADE,
  
  assigned_to     uuid,
  
  task_type       text NOT NULL, -- 'follow_up' | 'review' | 'call' | 'email' | 'document' | 'dispute' | 'manual'
  title           text NOT NULL,
  description     text,
  
  status          text NOT NULL DEFAULT 'pending', -- 'pending' | 'in_progress' | 'completed' | 'cancelled'
  priority        text NOT NULL DEFAULT 'medium', -- 'low' | 'medium' | 'high' | 'urgent'
  
  due_date        timestamptz,
  completed_at    timestamptz,
  
  source          text NOT NULL DEFAULT 'manual', -- 'manual' | 'auto' | 'ai'
  auto_generated  boolean NOT NULL DEFAULT false,
  
  meta            jsonb NOT NULL DEFAULT '{}'::jsonb,
  
  created_by      uuid,
  created_at      timestamptz NOT NULL DEFAULT now(),
  updated_at      timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.wf_tasks ENABLE ROW LEVEL SECURITY;

CREATE INDEX IF NOT EXISTS idx_wf_tasks_tenant ON public.wf_tasks(tenant_id);
CREATE INDEX IF NOT EXISTS idx_wf_tasks_case ON public.wf_tasks(case_id);
CREATE INDEX IF NOT EXISTS idx_wf_tasks_assigned ON public.wf_tasks(assigned_to);
CREATE INDEX IF NOT EXISTS idx_wf_tasks_status ON public.wf_tasks(status);
CREATE INDEX IF NOT EXISTS idx_wf_tasks_due ON public.wf_tasks(due_date);

-- RLS for wf_tasks
CREATE POLICY "Admins manage wf_tasks"
  ON public.wf_tasks
  FOR ALL
  USING (has_role(auth.uid(), 'admin'::public.app_role));

CREATE POLICY "Tenant workers view wf_tasks"
  ON public.wf_tasks
  FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM public.wf_tenant_users tu
      WHERE tu.user_id = auth.uid()
        AND tu.tenant_id = wf_tasks.tenant_id
    )
  );

CREATE POLICY "Tenant workers insert wf_tasks"
  ON public.wf_tasks
  FOR INSERT
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.wf_tenant_users tu
      WHERE tu.user_id = auth.uid()
        AND tu.tenant_id = wf_tasks.tenant_id
    )
  );

CREATE POLICY "Tenant workers update wf_tasks"
  ON public.wf_tasks
  FOR UPDATE
  USING (
    EXISTS (
      SELECT 1 FROM public.wf_tenant_users tu
      WHERE tu.user_id = auth.uid()
        AND tu.tenant_id = wf_tasks.tenant_id
    )
  );

-- Triggers for updated_at
CREATE TRIGGER set_credit_dispute_items_v2_updated_at
  BEFORE UPDATE ON public.credit_dispute_items_v2
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_updated_at();

CREATE TRIGGER set_credit_dispute_drafts_v2_updated_at
  BEFORE UPDATE ON public.credit_dispute_drafts_v2
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_updated_at();

CREATE TRIGGER set_wf_tasks_updated_at
  BEFORE UPDATE ON public.wf_tasks
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_updated_at();

-- =================================================================
-- MIGRATION: 20251204235918_4292dc0d-7e3e-4dc7-bc99-036d096dd50a.sql
-- =================================================================
-- =========================================
-- V2.3 – Email Templates + Outbox
-- =========================================

-- Helper functions if not exists
CREATE OR REPLACE FUNCTION public.tenant_has_access(user_id uuid, tid uuid)
RETURNS boolean AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 FROM public.wf_tenant_users 
    WHERE wf_tenant_users.user_id = $1 
    AND wf_tenant_users.tenant_id = $2
  ) OR has_role($1, 'admin'::public.app_role);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

CREATE OR REPLACE FUNCTION public.tenant_is_admin(user_id uuid, tid uuid)
RETURNS boolean AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 FROM public.wf_tenant_users 
    WHERE wf_tenant_users.user_id = $1 
    AND wf_tenant_users.tenant_id = $2
    AND wf_tenant_users.role IN ('admin', 'owner')
  ) OR has_role($1, 'admin'::public.app_role);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

-- Email Templates
CREATE TABLE IF NOT EXISTS public.wf_email_templates (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id   uuid NOT NULL REFERENCES public.wf_tenants(id) ON DELETE CASCADE,
  key         text NOT NULL,
  name        text NOT NULL,
  channel     text NOT NULL DEFAULT 'client',
  subject     text NOT NULL,
  body        text NOT NULL,
  is_active   boolean NOT NULL DEFAULT true,
  meta        jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at  timestamptz NOT NULL DEFAULT now(),
  updated_at  timestamptz NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX IF NOT EXISTS idx_wf_email_templates_tenant_key
  ON public.wf_email_templates(tenant_id, key);

ALTER TABLE public.wf_email_templates ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Tenant admins workers can view templates"
  ON public.wf_email_templates FOR SELECT
  USING (tenant_has_access(auth.uid(), tenant_id));

CREATE POLICY "Tenant admins can manage templates"
  ON public.wf_email_templates FOR ALL
  USING (tenant_is_admin(auth.uid(), tenant_id));

-- Email Outbox Queue
CREATE TABLE IF NOT EXISTS public.wf_email_outbox (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id     uuid NOT NULL REFERENCES public.wf_tenants(id) ON DELETE CASCADE,
  case_id       uuid REFERENCES public.credit_cases_v2(id) ON DELETE CASCADE,
  lead_id       uuid REFERENCES public.wf_leads(id) ON DELETE CASCADE,
  to_email      text NOT NULL,
  to_name       text,
  subject       text NOT NULL,
  body          text NOT NULL,
  status        text NOT NULL DEFAULT 'queued',
  send_after    timestamptz NOT NULL DEFAULT now(),
  sent_at       timestamptz,
  attempt_count integer NOT NULL DEFAULT 0,
  last_error    text,
  meta          jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_wf_email_outbox_status_send_after
  ON public.wf_email_outbox(status, send_after);

ALTER TABLE public.wf_email_outbox ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Tenant admins workers can view outbox"
  ON public.wf_email_outbox FOR SELECT
  USING (tenant_has_access(auth.uid(), tenant_id));

CREATE POLICY "Tenant admins workers can insert outbox"
  ON public.wf_email_outbox FOR INSERT
  WITH CHECK (tenant_has_access(auth.uid(), tenant_id));

CREATE POLICY "Service role can manage outbox"
  ON public.wf_email_outbox FOR ALL
  USING (auth.role() = 'service_role');

-- =========================================
-- V2.4 – Client Portal Tokens
-- =========================================

CREATE TABLE IF NOT EXISTS public.wf_client_portal_tokens (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id     uuid NOT NULL REFERENCES public.wf_tenants(id) ON DELETE CASCADE,
  case_id       uuid NOT NULL REFERENCES public.credit_cases_v2(id) ON DELETE CASCADE,
  client_email  text NOT NULL,
  token         text NOT NULL,
  expires_at    timestamptz NOT NULL,
  used_at       timestamptz,
  created_at    timestamptz NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX IF NOT EXISTS idx_wf_client_portal_tokens_token
  ON public.wf_client_portal_tokens(token);

ALTER TABLE public.wf_client_portal_tokens ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Service role only client portal tokens"
  ON public.wf_client_portal_tokens
  FOR ALL
  USING (auth.role() = 'service_role')
  WITH CHECK (auth.role() = 'service_role');

-- Seed default email templates for wolf-fund tenant
INSERT INTO public.wf_email_templates (tenant_id, key, name, channel, subject, body)
SELECT 
  t.id,
  template.key,
  template.name,
  template.channel,
  template.subject,
  template.body
FROM public.wf_tenants t
CROSS JOIN (VALUES
  ('credit_welcome', 'Credit Welcome Email', 'client', 
   'Welcome to Wolf Fund Credit Repair - {{client_name}}',
   'Hi {{client_name}},\n\nWelcome to Wolf Fund Credit Repair! We''re excited to help you improve your credit.\n\nYour case status: {{case_status}}\n\nWe''ll be in touch soon with next steps.\n\nBest,\nWolf Fund Team'),
  ('case_update', 'Case Status Update', 'client',
   'Update on Your Credit Case - {{client_name}}',
   'Hi {{client_name}},\n\nWe wanted to update you on your credit repair case.\n\nCurrent status: {{case_status}}\n\nIf you have questions, please reply to this email.\n\nBest,\nWolf Fund Team'),
  ('client_portal_link', 'Client Portal Access Link', 'client',
   'Access Your Credit Case Portal - {{client_name}}',
   'Hi {{client_name}},\n\nClick the link below to access your secure client portal:\n\n{{portal_url}}\n\nThis link expires in 72 hours.\n\nBest,\nWolf Fund Team'),
  ('overdue_task', 'Overdue Task Notification', 'internal',
   'Overdue Task Alert - Case {{case_id}}',
   'A task for case {{case_id}} is now overdue.\n\nClient: {{client_name}}\nStatus: {{case_status}}\n\nPlease review and take action.')
) AS template(key, name, channel, subject, body)
WHERE t.slug = 'wolf-fund'
ON CONFLICT DO NOTHING;

-- =================================================================
-- MIGRATION: 20251205030810_9598b332-1f61-4e7f-9fbe-7bf37270b4a8.sql
-- =================================================================
-- V100 IP Guardian Foundation Tables

-- 1. IP Assets - Core registry of all intellectual property
CREATE TABLE IF NOT EXISTS public.wf_ip_assets (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  tenant_id UUID NOT NULL REFERENCES public.wf_tenants(id),
  asset_type TEXT NOT NULL CHECK (asset_type IN ('code', 'ui', 'workflow', 'prompt', 'brand', 'document', 'model', 'config')),
  name TEXT NOT NULL,
  description TEXT,
  source_path TEXT,
  source_repo TEXT DEFAULT 'gateway',
  hash_signature TEXT,
  tags TEXT[] DEFAULT ARRAY[]::TEXT[],
  legal_priority TEXT DEFAULT 'medium' CHECK (legal_priority IN ('low', 'medium', 'high', 'critical')),
  brand_key TEXT,
  metadata JSONB DEFAULT '{}'::JSONB,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- 2. IP Versions - Version history for each asset
CREATE TABLE IF NOT EXISTS public.wf_ip_versions (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  asset_id UUID NOT NULL REFERENCES public.wf_ip_assets(id) ON DELETE CASCADE,
  version_tag TEXT NOT NULL,
  change_type TEXT DEFAULT 'update' CHECK (change_type IN ('create', 'update', 'refactor', 'branch', 'deprecate')),
  snapshot_hash TEXT,
  diff_summary TEXT,
  metadata JSONB DEFAULT '{}'::JSONB,
  created_by UUID,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- 3. IP Events - Legal-relevant events timeline
CREATE TABLE IF NOT EXISTS public.wf_ip_events (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  tenant_id UUID NOT NULL REFERENCES public.wf_tenants(id),
  asset_id UUID REFERENCES public.wf_ip_assets(id) ON DELETE SET NULL,
  event_type TEXT NOT NULL CHECK (event_type IN ('first_use', 'deployed', 'branched', 'refactored', 'ai_generated', 'registered', 'legal_review', 'exported')),
  source TEXT DEFAULT 'system',
  description TEXT,
  payload JSONB DEFAULT '{}'::JSONB,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- 4. IP Legal Drafts - Auto-generated legal documentation
CREATE TABLE IF NOT EXISTS public.wf_ip_legal_drafts (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  tenant_id UUID NOT NULL REFERENCES public.wf_tenants(id),
  asset_id UUID REFERENCES public.wf_ip_assets(id) ON DELETE SET NULL,
  doc_type TEXT NOT NULL CHECK (doc_type IN ('copyright_summary', 'trademark_summary', 'patent_description', 'ownership_statement', 'cease_desist_draft', 'evidence_pack')),
  title TEXT NOT NULL,
  body TEXT NOT NULL,
  status TEXT DEFAULT 'draft' CHECK (status IN ('draft', 'needs_review', 'approved', 'archived', 'sent')),
  ai_model TEXT,
  metadata JSONB DEFAULT '{}'::JSONB,
  reviewed_by UUID,
  reviewed_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- 5. IP Actions - Future manual actions (human-triggered only)
CREATE TABLE IF NOT EXISTS public.wf_ip_actions (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  tenant_id UUID NOT NULL REFERENCES public.wf_tenants(id),
  draft_id UUID REFERENCES public.wf_ip_legal_drafts(id) ON DELETE SET NULL,
  action_type TEXT NOT NULL CHECK (action_type IN ('internal_review', 'lawyer_review', 'prepare_notice', 'prepare_takedown', 'archive', 'escalate')),
  status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'in_progress', 'completed', 'cancelled')),
  assigned_to UUID,
  notes TEXT,
  completed_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_wf_ip_assets_tenant ON public.wf_ip_assets(tenant_id);
CREATE INDEX IF NOT EXISTS idx_wf_ip_assets_type ON public.wf_ip_assets(asset_type);
CREATE INDEX IF NOT EXISTS idx_wf_ip_assets_brand ON public.wf_ip_assets(brand_key);
CREATE INDEX IF NOT EXISTS idx_wf_ip_versions_asset ON public.wf_ip_versions(asset_id);
CREATE INDEX IF NOT EXISTS idx_wf_ip_events_tenant ON public.wf_ip_events(tenant_id);
CREATE INDEX IF NOT EXISTS idx_wf_ip_events_asset ON public.wf_ip_events(asset_id);
CREATE INDEX IF NOT EXISTS idx_wf_ip_legal_drafts_tenant ON public.wf_ip_legal_drafts(tenant_id);
CREATE INDEX IF NOT EXISTS idx_wf_ip_legal_drafts_status ON public.wf_ip_legal_drafts(status);

-- Enable RLS
ALTER TABLE public.wf_ip_assets ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.wf_ip_versions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.wf_ip_events ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.wf_ip_legal_drafts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.wf_ip_actions ENABLE ROW LEVEL SECURITY;

-- RLS Policies for wf_ip_assets
CREATE POLICY "Admins manage wf_ip_assets" ON public.wf_ip_assets
  FOR ALL USING (has_role(auth.uid(), 'admin'::public.app_role));

CREATE POLICY "Tenant users view wf_ip_assets" ON public.wf_ip_assets
  FOR SELECT USING (EXISTS (
    SELECT 1 FROM wf_tenant_users tu 
    WHERE tu.user_id = auth.uid() AND tu.tenant_id = wf_ip_assets.tenant_id
  ));

CREATE POLICY "System insert wf_ip_assets" ON public.wf_ip_assets
  FOR INSERT WITH CHECK (true);

-- RLS Policies for wf_ip_versions
CREATE POLICY "Admins manage wf_ip_versions" ON public.wf_ip_versions
  FOR ALL USING (has_role(auth.uid(), 'admin'::public.app_role));

CREATE POLICY "Tenant users view wf_ip_versions" ON public.wf_ip_versions
  FOR SELECT USING (EXISTS (
    SELECT 1 FROM wf_ip_assets a
    JOIN wf_tenant_users tu ON tu.tenant_id = a.tenant_id
    WHERE a.id = wf_ip_versions.asset_id AND tu.user_id = auth.uid()
  ));

CREATE POLICY "System insert wf_ip_versions" ON public.wf_ip_versions
  FOR INSERT WITH CHECK (true);

-- RLS Policies for wf_ip_events
CREATE POLICY "Admins manage wf_ip_events" ON public.wf_ip_events
  FOR ALL USING (has_role(auth.uid(), 'admin'::public.app_role));

CREATE POLICY "Tenant users view wf_ip_events" ON public.wf_ip_events
  FOR SELECT USING (EXISTS (
    SELECT 1 FROM wf_tenant_users tu 
    WHERE tu.user_id = auth.uid() AND tu.tenant_id = wf_ip_events.tenant_id
  ));

CREATE POLICY "System insert wf_ip_events" ON public.wf_ip_events
  FOR INSERT WITH CHECK (true);

-- RLS Policies for wf_ip_legal_drafts
CREATE POLICY "Admins manage wf_ip_legal_drafts" ON public.wf_ip_legal_drafts
  FOR ALL USING (has_role(auth.uid(), 'admin'::public.app_role));

CREATE POLICY "Tenant users view wf_ip_legal_drafts" ON public.wf_ip_legal_drafts
  FOR SELECT USING (EXISTS (
    SELECT 1 FROM wf_tenant_users tu 
    WHERE tu.user_id = auth.uid() AND tu.tenant_id = wf_ip_legal_drafts.tenant_id
  ));

CREATE POLICY "System insert wf_ip_legal_drafts" ON public.wf_ip_legal_drafts
  FOR INSERT WITH CHECK (true);

-- RLS Policies for wf_ip_actions
CREATE POLICY "Admins manage wf_ip_actions" ON public.wf_ip_actions
  FOR ALL USING (has_role(auth.uid(), 'admin'::public.app_role));

CREATE POLICY "Tenant users view wf_ip_actions" ON public.wf_ip_actions
  FOR SELECT USING (EXISTS (
    SELECT 1 FROM wf_tenant_users tu 
    WHERE tu.user_id = auth.uid() AND tu.tenant_id = wf_ip_actions.tenant_id
  ));

-- Updated_at triggers
CREATE OR REPLACE FUNCTION update_wf_ip_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_wf_ip_assets_updated_at
  BEFORE UPDATE ON public.wf_ip_assets
  FOR EACH ROW EXECUTE FUNCTION update_wf_ip_updated_at();

CREATE TRIGGER update_wf_ip_legal_drafts_updated_at
  BEFORE UPDATE ON public.wf_ip_legal_drafts
  FOR EACH ROW EXECUTE FUNCTION update_wf_ip_updated_at();

-- =================================================================
-- MIGRATION: 20251205033317_7a08ec6f-79a0-40c3-ae56-2a5160e7a0b1.sql
-- =================================================================
-- V13: Billing & Usage Infrastructure

-- Usage Events table (if not exists)
CREATE TABLE IF NOT EXISTS public.wf_usage_events (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  tenant_id UUID REFERENCES public.wf_tenants(id),
  event_type TEXT NOT NULL,
  case_id UUID,
  lead_id UUID,
  iso_id UUID,
  brand_key TEXT DEFAULT 'wolf-fund',
  meta JSONB DEFAULT '{}'::jsonb,
  idempotency_key TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Index for efficient queries
CREATE INDEX IF NOT EXISTS idx_wf_usage_events_tenant_type ON public.wf_usage_events(tenant_id, event_type);
CREATE INDEX IF NOT EXISTS idx_wf_usage_events_created ON public.wf_usage_events(created_at);
CREATE INDEX IF NOT EXISTS idx_wf_usage_events_brand ON public.wf_usage_events(brand_key);
CREATE UNIQUE INDEX IF NOT EXISTS idx_wf_usage_events_idempotency ON public.wf_usage_events(idempotency_key) WHERE idempotency_key IS NOT NULL;

-- Billing Plans table
CREATE TABLE IF NOT EXISTS public.wf_billing_plans (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  plan_key TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  description TEXT,
  event_pricing JSONB NOT NULL DEFAULT '{}'::jsonb, -- {"ai_call": 0.02, "dispute_sent": 1.5}
  base_fee NUMERIC(10,2) DEFAULT 0,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Tenant Billing State table
CREATE TABLE IF NOT EXISTS public.wf_tenant_billing_state (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  tenant_id UUID NOT NULL REFERENCES public.wf_tenants(id),
  plan_id UUID REFERENCES public.wf_billing_plans(id),
  billing_email TEXT,
  stripe_customer_id TEXT,
  billing_status TEXT DEFAULT 'trial', -- trial, active, suspended, cancelled
  current_period_start TIMESTAMPTZ,
  current_period_end TIMESTAMPTZ,
  meta JSONB DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(tenant_id)
);

-- Enable RLS
ALTER TABLE public.wf_usage_events ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.wf_billing_plans ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.wf_tenant_billing_state ENABLE ROW LEVEL SECURITY;

-- RLS Policies for wf_usage_events
DROP POLICY IF EXISTS "Admin can read all usage events" ON public.wf_usage_events;
CREATE POLICY "Admin can read all usage events" ON public.wf_usage_events
  FOR SELECT USING (
    EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = auth.uid() AND role = 'admin' AND approved = true)
  );

DROP POLICY IF EXISTS "Service role can insert usage events" ON public.wf_usage_events;
CREATE POLICY "Service role can insert usage events" ON public.wf_usage_events
  FOR INSERT WITH CHECK (true);

-- RLS Policies for wf_billing_plans
DROP POLICY IF EXISTS "Anyone can read active billing plans" ON public.wf_billing_plans;
CREATE POLICY "Anyone can read active billing plans" ON public.wf_billing_plans
  FOR SELECT USING (is_active = true);

DROP POLICY IF EXISTS "Admin can manage billing plans" ON public.wf_billing_plans;
CREATE POLICY "Admin can manage billing plans" ON public.wf_billing_plans
  FOR ALL USING (
    EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = auth.uid() AND role = 'admin' AND approved = true)
  );

-- RLS Policies for wf_tenant_billing_state
DROP POLICY IF EXISTS "Admin can manage billing state" ON public.wf_tenant_billing_state;
CREATE POLICY "Admin can manage billing state" ON public.wf_tenant_billing_state
  FOR ALL USING (
    EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = auth.uid() AND role = 'admin' AND approved = true)
  );

-- Insert default billing plan
INSERT INTO public.wf_billing_plans (plan_key, name, description, event_pricing, base_fee)
VALUES (
  'standard',
  'Standard Plan',
  'Default billing plan with per-event pricing',
  '{
    "case_created": 5.00,
    "case_closed": 0,
    "dispute_generated": 1.00,
    "dispute_sent": 1.50,
    "lead_created": 0.50,
    "email_sent": 0.05,
    "portal_link_sent": 0.10,
    "ai_call": 0.02,
    "ai_research": 0.15,
    "asset_deployed": 0,
    "ip_registered": 0
  }'::jsonb,
  0
) ON CONFLICT (plan_key) DO UPDATE SET
  event_pricing = EXCLUDED.event_pricing,
  updated_at = now();

-- =================================================================
-- MIGRATION: 20251205034108_bcdec6f4-0eaa-49db-b8b9-4cbd9dcc93da.sql
-- =================================================================
-- Seed standard billing plan for V13
INSERT INTO wf_billing_plans (plan_key, name, description, event_pricing, base_fee, is_active)
VALUES (
  'standard',
  'Standard Plan',
  'Standard Wolf Fund plan - base tier',
  '{
    "case_created": 0,
    "case_closed": 0,
    "dispute_generated": 0.50,
    "dispute_sent": 1.00,
    "lead_created": 0,
    "email_sent": 0.01,
    "portal_link_sent": 0,
    "ai_call": 0.02,
    "ai_research": 0.05,
    "ip_registered": 0,
    "asset_deployed": 0
  }'::jsonb,
  0,
  true
)
ON CONFLICT (plan_key) DO NOTHING;

-- =================================================================
-- MIGRATION: 20251205041715_a8886877-8cc6-4c0c-9eda-f83dfb715b9a.sql
-- =================================================================
-- V14.1: Seed billing plan with complete event pricing coverage
-- Update the standard billing plan to include pricing for all known event types

UPDATE wf_billing_plans
SET event_pricing = jsonb_build_object(
  'case_created', 0,
  'case_closed', 0,
  'dispute_generated', 0,
  'dispute_sent', 0,
  'lead_created', 0,
  'email_sent', 0,
  'portal_link_sent', 0,
  'ai_call', 0,
  'ai_research', 0,
  'asset_deployed', 0,
  'ip_registered', 0,
  'abg_application_created', 0,
  'abg_application_submitted', 0,
  'abg_funding_decision', 0,
  'sms_sent', 0,
  'document_uploaded', 0
),
updated_at = now()
WHERE plan_key = 'standard';

-- If no standard plan exists, create one
INSERT INTO wf_billing_plans (plan_key, name, description, base_fee, is_active, event_pricing)
SELECT 
  'standard',
  'Standard Plan',
  'Default billing plan with all event types priced at 0 (preview mode)',
  0,
  true,
  jsonb_build_object(
    'case_created', 0,
    'case_closed', 0,
    'dispute_generated', 0,
    'dispute_sent', 0,
    'lead_created', 0,
    'email_sent', 0,
    'portal_link_sent', 0,
    'ai_call', 0,
    'ai_research', 0,
    'asset_deployed', 0,
    'ip_registered', 0,
    'abg_application_created', 0,
    'abg_application_submitted', 0,
    'abg_funding_decision', 0,
    'sms_sent', 0,
    'document_uploaded', 0
  )
WHERE NOT EXISTS (SELECT 1 FROM wf_billing_plans WHERE plan_key = 'standard');

-- =================================================================
-- MIGRATION: 20251205045804_66baec48-a655-4544-9b11-2d8d4f00685c.sql
-- =================================================================
-- V16: Filing Prep Mode + Brand Playbooks

-- Create wf_ip_filing_packets table
CREATE TABLE IF NOT EXISTS public.wf_ip_filing_packets (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  tenant_id UUID NOT NULL,
  asset_id UUID,
  packet_type TEXT NOT NULL CHECK (packet_type IN ('copyright', 'trademark', 'patent_brief')),
  status TEXT NOT NULL DEFAULT 'draft' CHECK (status IN ('draft', 'ready_for_review', 'shared_with_attorney', 'archived')),
  title TEXT NOT NULL,
  body TEXT NOT NULL,
  checklist JSONB DEFAULT '[]'::jsonb,
  filing_region TEXT DEFAULT 'US',
  filing_notes TEXT,
  metadata JSONB DEFAULT '{}'::jsonb,
  created_by UUID,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.wf_ip_filing_packets ENABLE ROW LEVEL SECURITY;

-- RLS policies for filing packets (authenticated users can read/write)
CREATE POLICY "Authenticated users can read filing packets" 
  ON public.wf_ip_filing_packets 
  FOR SELECT 
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated users can insert filing packets" 
  ON public.wf_ip_filing_packets 
  FOR INSERT 
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Authenticated users can update filing packets" 
  ON public.wf_ip_filing_packets 
  FOR UPDATE 
  TO authenticated
  USING (true);

-- Insert brand playbooks into wolf_master_config
INSERT INTO public.wolf_master_config (category, key, value, description)
VALUES (
  'governance',
  'brand_playbooks',
  '{
    "wolf-fund": {
      "label": "Wolf Fund Core",
      "required_usage_events": ["case_created", "dispute_generated", "dispute_sent", "email_sent", "portal_link_sent", "ai_call", "ip_registered", "lead_created"],
      "expected_ip_assets": ["Credit Repair Engine", "Wolf Motherboard", "Billing Spine", "Client Portal Exchange", "Governance Scanner", "IP Guardian System"],
      "expected_ui_routes": ["/admin", "/credit-specialist-dashboard", "/lead-engine", "/wolf-motherboard", "/ip-guardian"],
      "billing_rules": { "plan_key": "standard", "enabled": false },
      "sop_links": {
        "credit_repair": "https://docs.wolffund.com/sop/credit-repair",
        "underwriting": "https://docs.wolffund.com/sop/underwriting",
        "lead_intake": "https://docs.wolffund.com/sop/lead-intake"
      }
    },
    "abg": {
      "label": "Advance Builders Group",
      "required_usage_events": ["abg_application_created", "abg_application_submitted", "abg_funding_decision", "email_sent", "ai_call"],
      "expected_ip_assets": ["ABG Brand Package", "ABG Home Page", "ABG Application Form", "ABG Dashboard", "ABG Services Page"],
      "expected_ui_routes": ["/abg", "/abg/dashboard", "/abg/apply", "/abg/services"],
      "billing_rules": { "plan_key": "standard", "enabled": false },
      "sop_links": {
        "applications": "https://docs.abg.com/sop/applications",
        "funding": "https://docs.abg.com/sop/funding"
      }
    }
  }'::jsonb,
  'Brand playbooks defining expected usage events, IP assets, routes, and SOPs per brand'
)
ON CONFLICT (category, key) DO UPDATE SET
  value = EXCLUDED.value,
  updated_at = now();

-- =================================================================
-- MIGRATION: 20251205051903_92a99310-db60-4c35-a150-d9d373e32c48.sql
-- =================================================================
-- V17: Playbook Drift & SOP Awareness
-- New table for tracking drift items

CREATE TABLE IF NOT EXISTS public.wf_playbook_drift_items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES public.wf_tenants(id) ON DELETE CASCADE,
  brand_key TEXT NOT NULL,
  drift_type TEXT NOT NULL CHECK (drift_type IN ('usage_event', 'ip_asset', 'ui_route', 'workflow')),
  item_key TEXT NOT NULL,
  item_label TEXT,
  detected_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  status TEXT NOT NULL DEFAULT 'detected' CHECK (status IN ('detected', 'approved', 'ignored')),
  resolved_at TIMESTAMPTZ,
  resolved_by UUID,
  notes TEXT,
  metadata JSONB DEFAULT '{}',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_wf_playbook_drift_tenant ON public.wf_playbook_drift_items(tenant_id);
CREATE INDEX IF NOT EXISTS idx_wf_playbook_drift_brand ON public.wf_playbook_drift_items(brand_key);
CREATE INDEX IF NOT EXISTS idx_wf_playbook_drift_status ON public.wf_playbook_drift_items(status);
CREATE UNIQUE INDEX IF NOT EXISTS idx_wf_playbook_drift_unique ON public.wf_playbook_drift_items(tenant_id, brand_key, drift_type, item_key);

-- RLS
ALTER TABLE public.wf_playbook_drift_items ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated users can read drift items"
  ON public.wf_playbook_drift_items FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated users can insert drift items"
  ON public.wf_playbook_drift_items FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Authenticated users can update drift items"
  ON public.wf_playbook_drift_items FOR UPDATE
  TO authenticated
  USING (true);

-- Trigger for updated_at
CREATE TRIGGER update_wf_playbook_drift_updated_at
  BEFORE UPDATE ON public.wf_playbook_drift_items
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_updated_at();

-- =================================================================
-- MIGRATION: 20251205055236_c477e2a0-23a6-4044-94a3-6a5da07dae1a.sql
-- =================================================================
-- V18: IP Defense War Room + Evidence Locker

-- Add defense columns to wf_ip_assets
ALTER TABLE wf_ip_assets ADD COLUMN IF NOT EXISTS defense_status text DEFAULT 'draft';
ALTER TABLE wf_ip_assets ADD COLUMN IF NOT EXISTS defense_notes text;

-- Add attorney tracking columns to wf_ip_filing_packets
ALTER TABLE wf_ip_filing_packets ADD COLUMN IF NOT EXISTS attorney_reviewed boolean DEFAULT false;
ALTER TABLE wf_ip_filing_packets ADD COLUMN IF NOT EXISTS attorney_name text;
ALTER TABLE wf_ip_filing_packets ADD COLUMN IF NOT EXISTS externally_filed boolean DEFAULT false;
ALTER TABLE wf_ip_filing_packets ADD COLUMN IF NOT EXISTS external_filing_ref text;

-- Create evidence bundles table
CREATE TABLE IF NOT EXISTS wf_ip_evidence_bundles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL,
  asset_id uuid REFERENCES wf_ip_assets(id) ON DELETE CASCADE,
  bundle_type text DEFAULT 'dispute_prep',
  bundle_html text,
  notes_for_attorney text,
  generated_at timestamptz DEFAULT now(),
  generated_by uuid,
  metadata jsonb DEFAULT '{}',
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE wf_ip_evidence_bundles ENABLE ROW LEVEL SECURITY;

-- RLS policies for evidence bundles
CREATE POLICY "Admins manage evidence bundles" ON wf_ip_evidence_bundles
  FOR ALL USING (has_role(auth.uid(), 'admin'::public.app_role));

CREATE POLICY "Tenant users view evidence bundles" ON wf_ip_evidence_bundles
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM wf_tenant_users tu
      WHERE tu.user_id = auth.uid() AND tu.tenant_id = wf_ip_evidence_bundles.tenant_id
    )
  );

CREATE POLICY "Tenant users insert evidence bundles" ON wf_ip_evidence_bundles
  FOR INSERT WITH CHECK (
    EXISTS (
      SELECT 1 FROM wf_tenant_users tu
      WHERE tu.user_id = auth.uid() AND tu.tenant_id = wf_ip_evidence_bundles.tenant_id
    )
  );

-- Index for faster lookups
CREATE INDEX IF NOT EXISTS idx_evidence_bundles_asset ON wf_ip_evidence_bundles(asset_id);
CREATE INDEX IF NOT EXISTS idx_evidence_bundles_tenant ON wf_ip_evidence_bundles(tenant_id);

