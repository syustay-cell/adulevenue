-- =================================================================
-- MIGRATION: 20251207211253_6b0a6bc4-7664-429d-a852-49c975d2d18d.sql
-- =================================================================
-- Phase 7: AI Playbook Engine Tables + RLS

-- ============================================
-- 1. wf_playbooks - Master playbook registry
-- ============================================
CREATE TABLE public.wf_playbooks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.wf_tenants(id) ON DELETE CASCADE,
  name text NOT NULL,
  slug text NOT NULL,
  description text NULL,
  enabled boolean NOT NULL DEFAULT true,
  scope text NOT NULL DEFAULT 'admin',
  trigger_mode text NOT NULL DEFAULT 'manual',
  created_by uuid NULL REFERENCES auth.users(id),
  updated_by uuid NULL REFERENCES auth.users(id),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  meta jsonb NOT NULL DEFAULT '{}'::jsonb,
  UNIQUE (tenant_id, slug)
);

CREATE INDEX idx_wf_playbooks_tenant ON public.wf_playbooks (tenant_id);

-- Trigger for updated_at
CREATE TRIGGER set_wf_playbooks_updated_at
  BEFORE UPDATE ON public.wf_playbooks
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

-- ============================================
-- 2. wf_playbook_steps - Ordered steps per playbook
-- ============================================
CREATE TABLE public.wf_playbook_steps (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  playbook_id uuid NOT NULL REFERENCES public.wf_playbooks(id) ON DELETE CASCADE,
  tenant_id uuid NOT NULL REFERENCES public.wf_tenants(id) ON DELETE CASCADE,
  order_index integer NOT NULL,
  step_type text NOT NULL,
  title text NOT NULL,
  description text NULL,
  config jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  meta jsonb NOT NULL DEFAULT '{}'::jsonb
);

CREATE INDEX idx_wf_playbook_steps_playbook ON public.wf_playbook_steps (playbook_id, order_index);

-- ============================================
-- 3. wf_playbook_triggers - Conditions that fire playbooks
-- ============================================
CREATE TABLE public.wf_playbook_triggers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.wf_tenants(id) ON DELETE CASCADE,
  playbook_id uuid NOT NULL REFERENCES public.wf_playbooks(id) ON DELETE CASCADE,
  source_type text NOT NULL,
  match_category text NULL,
  match_type text NULL,
  min_severity text NULL,
  conditions jsonb NOT NULL DEFAULT '{}'::jsonb,
  auto_run boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  meta jsonb NOT NULL DEFAULT '{}'::jsonb
);

CREATE INDEX idx_wf_playbook_triggers_tenant ON public.wf_playbook_triggers(tenant_id);
CREATE INDEX idx_wf_playbook_triggers_playbook ON public.wf_playbook_triggers(playbook_id);

-- ============================================
-- 4. wf_playbook_runs - Execution log
-- ============================================
CREATE TABLE public.wf_playbook_runs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.wf_tenants(id) ON DELETE CASCADE,
  playbook_id uuid NOT NULL REFERENCES public.wf_playbooks(id) ON DELETE CASCADE,
  triggered_by_user uuid NULL REFERENCES auth.users(id),
  triggered_by_source text NOT NULL,
  related_alert_id uuid NULL REFERENCES public.wf_alert_events(id) ON DELETE SET NULL,
  related_insight_id uuid NULL REFERENCES public.wf_insights(id) ON DELETE SET NULL,
  status text NOT NULL DEFAULT 'running',
  started_at timestamptz NOT NULL DEFAULT now(),
  finished_at timestamptz NULL,
  total_steps integer NOT NULL DEFAULT 0,
  steps_completed integer NOT NULL DEFAULT 0,
  error_message text NULL,
  meta jsonb NOT NULL DEFAULT '{}'::jsonb
);

CREATE INDEX idx_wf_playbook_runs_tenant ON public.wf_playbook_runs (tenant_id, started_at DESC);

-- ============================================
-- RLS POLICIES
-- ============================================

-- wf_playbooks RLS
ALTER TABLE public.wf_playbooks ENABLE ROW LEVEL SECURITY;

CREATE POLICY wf_playbooks_owner_admin_select
ON public.wf_playbooks FOR SELECT
USING (
  auth.uid() IS NOT NULL
  AND tenant_id IN (
    SELECT tu.tenant_id
    FROM public.wf_tenant_users tu
    JOIN public.user_roles ur ON ur.user_id = tu.user_id
    WHERE tu.user_id = auth.uid()
      AND ur.role IN ('owner', 'admin')
      AND ur.approved = true
  )
);

CREATE POLICY wf_playbooks_owner_admin_update
ON public.wf_playbooks FOR UPDATE
USING (EXISTS (
  SELECT 1 FROM public.wf_tenant_users tu
  JOIN public.user_roles ur ON ur.user_id = tu.user_id
  WHERE tu.user_id = auth.uid()
    AND tu.tenant_id = wf_playbooks.tenant_id
    AND ur.role IN ('owner', 'admin')
    AND ur.approved = true
));

CREATE POLICY wf_playbooks_owner_admin_insert
ON public.wf_playbooks FOR INSERT
WITH CHECK (EXISTS (
  SELECT 1 FROM public.wf_tenant_users tu
  JOIN public.user_roles ur ON ur.user_id = tu.user_id
  WHERE tu.user_id = auth.uid()
    AND tu.tenant_id = tenant_id
    AND ur.role IN ('owner', 'admin')
    AND ur.approved = true
));

CREATE POLICY wf_playbooks_owner_admin_delete
ON public.wf_playbooks FOR DELETE
USING (EXISTS (
  SELECT 1 FROM public.wf_tenant_users tu
  JOIN public.user_roles ur ON ur.user_id = tu.user_id
  WHERE tu.user_id = auth.uid()
    AND tu.tenant_id = wf_playbooks.tenant_id
    AND ur.role IN ('owner', 'admin')
    AND ur.approved = true
));

CREATE POLICY wf_playbooks_system_all
ON public.wf_playbooks FOR ALL
USING (auth.jwt() ->> 'role' = 'service_role')
WITH CHECK (auth.jwt() ->> 'role' = 'service_role');

-- wf_playbook_steps RLS
ALTER TABLE public.wf_playbook_steps ENABLE ROW LEVEL SECURITY;

CREATE POLICY wf_playbook_steps_owner_admin_select
ON public.wf_playbook_steps FOR SELECT
USING (
  auth.uid() IS NOT NULL
  AND tenant_id IN (
    SELECT tu.tenant_id
    FROM public.wf_tenant_users tu
    JOIN public.user_roles ur ON ur.user_id = tu.user_id
    WHERE tu.user_id = auth.uid()
      AND ur.role IN ('owner', 'admin')
      AND ur.approved = true
  )
);

CREATE POLICY wf_playbook_steps_owner_admin_insert
ON public.wf_playbook_steps FOR INSERT
WITH CHECK (EXISTS (
  SELECT 1 FROM public.wf_tenant_users tu
  JOIN public.user_roles ur ON ur.user_id = tu.user_id
  WHERE tu.user_id = auth.uid()
    AND tu.tenant_id = tenant_id
    AND ur.role IN ('owner', 'admin')
    AND ur.approved = true
));

CREATE POLICY wf_playbook_steps_owner_admin_update
ON public.wf_playbook_steps FOR UPDATE
USING (EXISTS (
  SELECT 1 FROM public.wf_tenant_users tu
  JOIN public.user_roles ur ON ur.user_id = tu.user_id
  WHERE tu.user_id = auth.uid()
    AND tu.tenant_id = wf_playbook_steps.tenant_id
    AND ur.role IN ('owner', 'admin')
    AND ur.approved = true
));

CREATE POLICY wf_playbook_steps_owner_admin_delete
ON public.wf_playbook_steps FOR DELETE
USING (EXISTS (
  SELECT 1 FROM public.wf_tenant_users tu
  JOIN public.user_roles ur ON ur.user_id = tu.user_id
  WHERE tu.user_id = auth.uid()
    AND tu.tenant_id = wf_playbook_steps.tenant_id
    AND ur.role IN ('owner', 'admin')
    AND ur.approved = true
));

CREATE POLICY wf_playbook_steps_system_all
ON public.wf_playbook_steps FOR ALL
USING (auth.jwt() ->> 'role' = 'service_role')
WITH CHECK (auth.jwt() ->> 'role' = 'service_role');

-- wf_playbook_triggers RLS
ALTER TABLE public.wf_playbook_triggers ENABLE ROW LEVEL SECURITY;

CREATE POLICY wf_playbook_triggers_owner_admin_select
ON public.wf_playbook_triggers FOR SELECT
USING (
  auth.uid() IS NOT NULL
  AND tenant_id IN (
    SELECT tu.tenant_id
    FROM public.wf_tenant_users tu
    JOIN public.user_roles ur ON ur.user_id = tu.user_id
    WHERE tu.user_id = auth.uid()
      AND ur.role IN ('owner', 'admin')
      AND ur.approved = true
  )
);

CREATE POLICY wf_playbook_triggers_owner_admin_insert
ON public.wf_playbook_triggers FOR INSERT
WITH CHECK (EXISTS (
  SELECT 1 FROM public.wf_tenant_users tu
  JOIN public.user_roles ur ON ur.user_id = tu.user_id
  WHERE tu.user_id = auth.uid()
    AND tu.tenant_id = tenant_id
    AND ur.role IN ('owner', 'admin')
    AND ur.approved = true
));

CREATE POLICY wf_playbook_triggers_owner_admin_update
ON public.wf_playbook_triggers FOR UPDATE
USING (EXISTS (
  SELECT 1 FROM public.wf_tenant_users tu
  JOIN public.user_roles ur ON ur.user_id = tu.user_id
  WHERE tu.user_id = auth.uid()
    AND tu.tenant_id = wf_playbook_triggers.tenant_id
    AND ur.role IN ('owner', 'admin')
    AND ur.approved = true
));

CREATE POLICY wf_playbook_triggers_owner_admin_delete
ON public.wf_playbook_triggers FOR DELETE
USING (EXISTS (
  SELECT 1 FROM public.wf_tenant_users tu
  JOIN public.user_roles ur ON ur.user_id = tu.user_id
  WHERE tu.user_id = auth.uid()
    AND tu.tenant_id = wf_playbook_triggers.tenant_id
    AND ur.role IN ('owner', 'admin')
    AND ur.approved = true
));

CREATE POLICY wf_playbook_triggers_system_all
ON public.wf_playbook_triggers FOR ALL
USING (auth.jwt() ->> 'role' = 'service_role')
WITH CHECK (auth.jwt() ->> 'role' = 'service_role');

-- wf_playbook_runs RLS
ALTER TABLE public.wf_playbook_runs ENABLE ROW LEVEL SECURITY;

CREATE POLICY wf_playbook_runs_owner_admin_select
ON public.wf_playbook_runs FOR SELECT
USING (
  auth.uid() IS NOT NULL
  AND tenant_id IN (
    SELECT tu.tenant_id
    FROM public.wf_tenant_users tu
    JOIN public.user_roles ur ON ur.user_id = tu.user_id
    WHERE tu.user_id = auth.uid()
      AND ur.role IN ('owner', 'admin')
      AND ur.approved = true
  )
);

CREATE POLICY wf_playbook_runs_worker_select
ON public.wf_playbook_runs FOR SELECT
USING (
  auth.uid() IS NOT NULL
  AND tenant_id IN (
    SELECT tu.tenant_id
    FROM public.wf_tenant_users tu
    JOIN public.user_roles ur ON ur.user_id = tu.user_id
    WHERE tu.user_id = auth.uid()
      AND ur.role = 'worker'
      AND ur.approved = true
  )
);

CREATE POLICY wf_playbook_runs_system_all
ON public.wf_playbook_runs FOR ALL
USING (auth.jwt() ->> 'role' = 'service_role')
WITH CHECK (auth.jwt() ->> 'role' = 'service_role');

-- =================================================================
-- MIGRATION: 20251208030206_257dab04-6f2c-482f-bd90-ece929d45935.sql
-- =================================================================

-- V25 Part 1: Tables and Columns Only (no enum references in functions)

-- Wolf Session Settings table
CREATE TABLE IF NOT EXISTS public.wolf_session_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  setting_key text UNIQUE NOT NULL,
  setting_value jsonb NOT NULL DEFAULT '{}',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Insert default settings
INSERT INTO public.wolf_session_settings (setting_key, setting_value) VALUES
  ('idle_timeout_minutes', '30'),
  ('max_session_hours', '24'),
  ('impossible_travel_threshold_km', '500'),
  ('impossible_travel_window_minutes', '60'),
  ('high_risk_threshold', '70'),
  ('auto_revoke_high_risk', 'true')
ON CONFLICT (setting_key) DO NOTHING;

-- Wolf Screenshot Attempts table
CREATE TABLE IF NOT EXISTS public.wolf_screenshot_attempts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  session_id uuid,
  attempt_type text NOT NULL,
  page_url text,
  user_agent text,
  ip_address text,
  created_at timestamptz DEFAULT now()
);

-- Add security columns to wolf_sessions if they don't exist
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'wolf_sessions' AND column_name = 'device_fingerprint') THEN
    ALTER TABLE public.wolf_sessions ADD COLUMN device_fingerprint text;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'wolf_sessions' AND column_name = 'ip_hash') THEN
    ALTER TABLE public.wolf_sessions ADD COLUMN ip_hash text;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'wolf_sessions' AND column_name = 'risk_score') THEN
    ALTER TABLE public.wolf_sessions ADD COLUMN risk_score integer DEFAULT 0;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'wolf_sessions' AND column_name = 'impossible_travel_flag') THEN
    ALTER TABLE public.wolf_sessions ADD COLUMN impossible_travel_flag boolean DEFAULT false;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'wolf_sessions' AND column_name = 'last_known_country') THEN
    ALTER TABLE public.wolf_sessions ADD COLUMN last_known_country text;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'wolf_sessions' AND column_name = 'geo_lat') THEN
    ALTER TABLE public.wolf_sessions ADD COLUMN geo_lat numeric;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'wolf_sessions' AND column_name = 'geo_lon') THEN
    ALTER TABLE public.wolf_sessions ADD COLUMN geo_lon numeric;
  END IF;
END $$;

-- Role level function using text comparison (avoids enum commit issue)
CREATE OR REPLACE FUNCTION public.get_role_level(role_name text)
RETURNS integer
LANGUAGE sql
IMMUTABLE
AS $$
  SELECT CASE role_name
    WHEN 'owner' THEN 100
    WHEN 'tenant_admin' THEN 90
    WHEN 'admin' THEN 80
    WHEN 'underwriter' THEN 70
    WHEN 'credit_repair_specialist' THEN 65
    WHEN 'legal' THEN 60
    WHEN 'worker' THEN 50
    WHEN 'iso' THEN 40
    WHEN 'iso_partner' THEN 35
    WHEN 'client' THEN 20
    WHEN 'user' THEN 10
    ELSE 0
  END;
$$;

-- Check if user has role at or above specified level
CREATE OR REPLACE FUNCTION public.has_role_or_higher(_user_id uuid, _min_role text)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.user_roles
    WHERE user_id = _user_id
      AND approved = true
      AND get_role_level(role::text) >= get_role_level(_min_role)
  );
$$;

-- Check if user is owner or tenant_admin
CREATE OR REPLACE FUNCTION public.is_owner_or_tenant_admin(_user_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.user_roles
    WHERE user_id = _user_id
      AND approved = true
      AND role IN ('owner'::public.app_role, 'tenant_admin'::public.app_role)
  );
$$;

-- Check if user can access vault (owner or legal only)
CREATE OR REPLACE FUNCTION public.can_access_vault(_user_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.user_roles
    WHERE user_id = _user_id
      AND approved = true
      AND role IN ('owner'::public.app_role, 'legal'::public.app_role)
  );
$$;

-- RLS for wolf_session_settings
ALTER TABLE public.wolf_session_settings ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "wolf_session_settings_owner_only" ON public.wolf_session_settings;
CREATE POLICY "wolf_session_settings_owner_only" ON public.wolf_session_settings
  FOR ALL USING (public.has_role(auth.uid(), 'owner'));

-- RLS for wolf_screenshot_attempts
ALTER TABLE public.wolf_screenshot_attempts ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "screenshot_attempts_admin_read" ON public.wolf_screenshot_attempts;
CREATE POLICY "screenshot_attempts_admin_read" ON public.wolf_screenshot_attempts
  FOR SELECT USING (public.has_role_or_higher(auth.uid(), 'admin'));

DROP POLICY IF EXISTS "screenshot_attempts_insert_any" ON public.wolf_screenshot_attempts;
CREATE POLICY "screenshot_attempts_insert_any" ON public.wolf_screenshot_attempts
  FOR INSERT WITH CHECK (true);

-- RLS for client_vault (vault_owner_legal_only)
DROP POLICY IF EXISTS "vault_owner_legal_only" ON public.client_vault;
CREATE POLICY "vault_owner_legal_only" ON public.client_vault
  FOR ALL USING (public.can_access_vault(auth.uid()));

-- =================================================================
-- MIGRATION: 20251208203830_915accfc-1c3d-4a6c-95b5-d3803c4dd7c5.sql
-- =================================================================
-- Add global voice settings columns to wolf_master_config for org-wide TTS control
-- Using wolf_master_config as the org_settings table (already exists for Motherboard)

-- Insert global voice config if not exists
INSERT INTO wolf_master_config (category, key, value, description, updated_at)
VALUES (
  'tts',
  'global_voice_settings',
  '{"enabled": true, "voice": "nova", "speed": 1.0, "force_global": false}'::jsonb,
  'Owner-controlled global TTS voice settings for all users',
  now()
)
ON CONFLICT (category, key) DO NOTHING;

-- =================================================================
-- MIGRATION: 20251208225826_e41b6972-f680-4382-8b3f-942b75db8019.sql
-- =================================================================
-- =============================================
-- MEMBERSHIP OS - DATABASE MIGRATION
-- Partner applications, worker applications, funder applications, legal client applications
-- =============================================

-- Partner Company Applications (ISO/Partner Owner applications)
CREATE TABLE IF NOT EXISTS public.partner_applications (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id),
  -- Company Info
  company_name TEXT NOT NULL,
  company_address TEXT,
  company_phone TEXT,
  company_email TEXT NOT NULL,
  ein_number TEXT,
  -- Owner Info
  owner_name TEXT NOT NULL,
  owner_email TEXT NOT NULL,
  owner_phone TEXT,
  -- Experience
  years_in_industry TEXT,
  monthly_volume TEXT,
  funding_types TEXT[], -- ['mca', 'equipment', 'sba', etc.]
  team_size TEXT,
  current_funders TEXT,
  -- Agreement
  agreement_accepted BOOLEAN DEFAULT false,
  agreement_signed_at TIMESTAMPTZ,
  agreement_document TEXT,
  -- Status & Tracking
  status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'in_review', 'approved', 'rejected')),
  reviewed_by UUID,
  reviewed_at TIMESTAMPTZ,
  notes TEXT,
  -- Tenant tracking
  tenant_id UUID REFERENCES wf_tenants(id),
  origin_source TEXT DEFAULT 'website',
  referral_code TEXT,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- Worker Applications (apply to work for Wolf OS or a Partner)
CREATE TABLE IF NOT EXISTS public.worker_applications (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id),
  -- Personal Info
  full_name TEXT NOT NULL,
  email TEXT NOT NULL,
  phone TEXT,
  address TEXT,
  -- Employment Choice
  employer_type TEXT NOT NULL CHECK (employer_type IN ('wolf_fund', 'partner')),
  partner_id UUID REFERENCES partner_applications(id), -- if applying to partner
  invite_code TEXT, -- if joining via partner invite
  -- Experience
  years_experience TEXT,
  previous_companies TEXT,
  specialization TEXT[], -- ['sales', 'closer', 'processor', 'underwriter', etc.]
  monthly_deals_closed TEXT,
  resume_url TEXT,
  -- Status & Tracking
  status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'in_review', 'approved', 'rejected')),
  reviewed_by UUID,
  reviewed_at TIMESTAMPTZ,
  notes TEXT,
  -- Tenant tracking
  tenant_id UUID REFERENCES wf_tenants(id),
  origin_source TEXT DEFAULT 'website',
  referral_code TEXT,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- Partner Invite Codes (for partners to invite workers)
CREATE TABLE IF NOT EXISTS public.partner_invite_codes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  partner_id UUID NOT NULL REFERENCES partner_applications(id),
  code TEXT NOT NULL UNIQUE,
  created_by UUID REFERENCES auth.users(id),
  max_uses INTEGER DEFAULT 10,
  current_uses INTEGER DEFAULT 0,
  expires_at TIMESTAMPTZ,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Funder/Lender Applications
CREATE TABLE IF NOT EXISTS public.funder_applications (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id),
  -- Company Info
  company_name TEXT NOT NULL,
  company_type TEXT, -- 'direct_lender', 'broker', 'fund', etc.
  company_address TEXT,
  company_phone TEXT,
  company_email TEXT NOT NULL,
  -- Contact Info
  contact_name TEXT NOT NULL,
  contact_email TEXT NOT NULL,
  contact_phone TEXT,
  contact_role TEXT,
  -- Lending Profile
  lending_products TEXT[], -- ['mca', 'term_loan', 'equipment', 'sba', etc.]
  min_deal_size TEXT,
  max_deal_size TEXT,
  states_served TEXT[],
  industries_served TEXT[],
  monthly_capacity TEXT,
  -- Status & Tracking
  status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'in_review', 'approved', 'rejected')),
  reviewed_by UUID,
  reviewed_at TIMESTAMPTZ,
  notes TEXT,
  -- Tenant tracking
  tenant_id UUID REFERENCES wf_tenants(id),
  origin_source TEXT DEFAULT 'website',
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- Legal/ID Theft Client Applications
CREATE TABLE IF NOT EXISTS public.legal_client_applications (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id),
  -- Personal Info
  full_name TEXT NOT NULL,
  email TEXT NOT NULL,
  phone TEXT,
  address TEXT,
  city TEXT,
  state TEXT,
  zip TEXT,
  -- Case Info
  case_type TEXT NOT NULL CHECK (case_type IN ('identity_theft', 'debt_collection', 'credit_report_errors', 'other')),
  case_description TEXT,
  incident_date DATE,
  has_police_report BOOLEAN DEFAULT false,
  police_report_number TEXT,
  -- Documentation
  supporting_documents TEXT[],
  -- Status & Tracking
  status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'in_review', 'approved', 'rejected', 'referred')),
  assigned_to UUID,
  reviewed_by UUID,
  reviewed_at TIMESTAMPTZ,
  notes TEXT,
  -- Tenant tracking
  tenant_id UUID REFERENCES wf_tenants(id),
  origin_source TEXT DEFAULT 'website',
  referral_code TEXT,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- Add tenant_id and origin_source to existing tables
ALTER TABLE public.fast_track_applications 
  ADD COLUMN IF NOT EXISTS tenant_id UUID REFERENCES wf_tenants(id),
  ADD COLUMN IF NOT EXISTS origin_source TEXT DEFAULT 'website',
  ADD COLUMN IF NOT EXISTS referral_code TEXT;

ALTER TABLE public.loan_applications 
  ADD COLUMN IF NOT EXISTS tenant_id UUID REFERENCES wf_tenants(id),
  ADD COLUMN IF NOT EXISTS origin_source TEXT DEFAULT 'website',
  ADD COLUMN IF NOT EXISTS referral_code TEXT;

ALTER TABLE public.credit_repair_applications 
  ADD COLUMN IF NOT EXISTS tenant_id UUID REFERENCES wf_tenants(id),
  ADD COLUMN IF NOT EXISTS origin_source TEXT DEFAULT 'website',
  ADD COLUMN IF NOT EXISTS referral_code TEXT;

-- Enable RLS on new tables
ALTER TABLE public.partner_applications ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.worker_applications ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.partner_invite_codes ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.funder_applications ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.legal_client_applications ENABLE ROW LEVEL SECURITY;

-- RLS Policies for partner_applications
CREATE POLICY "Users can view their own partner applications" ON public.partner_applications
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own partner applications" ON public.partner_applications
  FOR INSERT WITH CHECK (auth.uid() = user_id OR user_id IS NULL);

CREATE POLICY "Admins can view all partner applications" ON public.partner_applications
  FOR SELECT USING (has_role(auth.uid(), 'admin'::public.app_role) OR has_role(auth.uid(), 'owner'::public.app_role));

CREATE POLICY "Admins can update partner applications" ON public.partner_applications
  FOR UPDATE USING (has_role(auth.uid(), 'admin'::public.app_role) OR has_role(auth.uid(), 'owner'::public.app_role));

-- RLS Policies for worker_applications
CREATE POLICY "Users can view their own worker applications" ON public.worker_applications
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own worker applications" ON public.worker_applications
  FOR INSERT WITH CHECK (auth.uid() = user_id OR user_id IS NULL);

CREATE POLICY "Admins can view all worker applications" ON public.worker_applications
  FOR SELECT USING (has_role(auth.uid(), 'admin'::public.app_role) OR has_role(auth.uid(), 'owner'::public.app_role));

CREATE POLICY "Admins can update worker applications" ON public.worker_applications
  FOR UPDATE USING (has_role(auth.uid(), 'admin'::public.app_role) OR has_role(auth.uid(), 'owner'::public.app_role));

-- RLS Policies for partner_invite_codes
CREATE POLICY "Partners can view their own invite codes" ON public.partner_invite_codes
  FOR SELECT USING (created_by = auth.uid());

CREATE POLICY "Partners can create invite codes" ON public.partner_invite_codes
  FOR INSERT WITH CHECK (created_by = auth.uid());

CREATE POLICY "Anyone can read active invite codes for validation" ON public.partner_invite_codes
  FOR SELECT USING (is_active = true);

-- RLS Policies for funder_applications
CREATE POLICY "Users can view their own funder applications" ON public.funder_applications
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own funder applications" ON public.funder_applications
  FOR INSERT WITH CHECK (auth.uid() = user_id OR user_id IS NULL);

CREATE POLICY "Admins can view all funder applications" ON public.funder_applications
  FOR SELECT USING (has_role(auth.uid(), 'admin'::public.app_role) OR has_role(auth.uid(), 'owner'::public.app_role));

CREATE POLICY "Admins can update funder applications" ON public.funder_applications
  FOR UPDATE USING (has_role(auth.uid(), 'admin'::public.app_role) OR has_role(auth.uid(), 'owner'::public.app_role));

-- RLS Policies for legal_client_applications
CREATE POLICY "Users can view their own legal applications" ON public.legal_client_applications
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own legal applications" ON public.legal_client_applications
  FOR INSERT WITH CHECK (auth.uid() = user_id OR user_id IS NULL);

CREATE POLICY "Admins can view all legal applications" ON public.legal_client_applications
  FOR SELECT USING (has_role(auth.uid(), 'admin'::public.app_role) OR has_role(auth.uid(), 'owner'::public.app_role));

CREATE POLICY "Admins can update legal applications" ON public.legal_client_applications
  FOR UPDATE USING (has_role(auth.uid(), 'admin'::public.app_role) OR has_role(auth.uid(), 'owner'::public.app_role));

-- Updated_at triggers
CREATE TRIGGER update_partner_applications_updated_at
  BEFORE UPDATE ON public.partner_applications
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_worker_applications_updated_at
  BEFORE UPDATE ON public.worker_applications
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_funder_applications_updated_at
  BEFORE UPDATE ON public.funder_applications
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_legal_client_applications_updated_at
  BEFORE UPDATE ON public.legal_client_applications
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- =================================================================
-- MIGRATION: 20251209022437_77bdc8b8-ad7f-4ed2-95f9-4c6caf513275.sql
-- =================================================================
-- Tenant Data Model - Step 2 (avoiding existing deals table)

-- 1) Extend wf_tenants
ALTER TABLE public.wf_tenants 
ADD COLUMN IF NOT EXISTS super_owner_id uuid,
ADD COLUMN IF NOT EXISTS metadata jsonb NOT NULL DEFAULT '{}'::jsonb;

-- 2) Extend wf_tenant_users
ALTER TABLE public.wf_tenant_users
ADD COLUMN IF NOT EXISTS invited_by uuid,
ADD COLUMN IF NOT EXISTS is_primary boolean NOT NULL DEFAULT false;

-- 3) Create merchants table
CREATE TABLE IF NOT EXISTS public.merchants (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid REFERENCES public.wf_tenants(id) ON DELETE RESTRICT,
  super_owner_id uuid,
  owner_user_id uuid NOT NULL,
  created_by uuid NOT NULL,
  legal_name text NOT NULL,
  dba_name text,
  ein text,
  contact_name text,
  contact_email text,
  contact_phone text,
  status text NOT NULL DEFAULT 'lead',
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.merchants ENABLE ROW LEVEL SECURITY;

-- 4) Create deal_commissions table
CREATE TABLE IF NOT EXISTS public.deal_commissions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  deal_id uuid NOT NULL REFERENCES public.deals(id) ON DELETE CASCADE,
  tenant_id uuid REFERENCES public.wf_tenants(id) ON DELETE RESTRICT,
  beneficiary_type text NOT NULL,
  beneficiary_tenant_id uuid,
  beneficiary_user_id uuid,
  base_amount numeric(14,2) NOT NULL DEFAULT 0,
  percent_of_funder_fee numeric(6,3),
  flat_amount numeric(14,2),
  computed_amount numeric(14,2),
  currency_code text NOT NULL DEFAULT 'USD',
  status text NOT NULL DEFAULT 'pending',
  notes text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.deal_commissions ENABLE ROW LEVEL SECURITY;

-- 5) Create deal_funder_assignments table
CREATE TABLE IF NOT EXISTS public.deal_funder_assignments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  deal_id uuid NOT NULL REFERENCES public.deals(id) ON DELETE CASCADE,
  funder_user_id uuid NOT NULL,
  funder_tenant_id uuid REFERENCES public.wf_tenants(id),
  assigned_by uuid NOT NULL,
  assigned_at timestamptz NOT NULL DEFAULT now(),
  status text NOT NULL DEFAULT 'pending',
  offer_amount numeric(14,2),
  offer_factor_rate numeric(8,5),
  offer_notes text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.deal_funder_assignments ENABLE ROW LEVEL SECURITY;

-- 6) Create terminals table
CREATE TABLE IF NOT EXISTS public.terminals (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid REFERENCES public.wf_tenants(id) ON DELETE RESTRICT,
  super_owner_id uuid,
  owner_user_id uuid NOT NULL,
  created_by uuid NOT NULL,
  merchant_id uuid REFERENCES public.merchants(id) ON DELETE CASCADE,
  processor_name text NOT NULL,
  mid text,
  status text NOT NULL DEFAULT 'pending_activation',
  estimated_monthly_volume numeric(14,2),
  actual_monthly_volume numeric(14,2),
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.terminals ENABLE ROW LEVEL SECURITY;

-- 7) Create legal_cases table
CREATE TABLE IF NOT EXISTS public.legal_cases (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid REFERENCES public.wf_tenants(id) ON DELETE RESTRICT,
  super_owner_id uuid,
  deal_id uuid REFERENCES public.deals(id) ON DELETE SET NULL,
  merchant_id uuid REFERENCES public.merchants(id) ON DELETE SET NULL,
  assigned_to uuid,
  assigned_at timestamptz,
  case_type text NOT NULL,
  status text NOT NULL DEFAULT 'open',
  priority text NOT NULL DEFAULT 'normal',
  title text NOT NULL,
  description text,
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.legal_cases ENABLE ROW LEVEL SECURITY;

-- RLS Policies
CREATE POLICY "merchants_tenant_isolation" ON public.merchants FOR ALL USING (public.is_owner() OR public.tenant_has_access(auth.uid(), tenant_id));
CREATE POLICY "deal_commissions_tenant_isolation" ON public.deal_commissions FOR ALL USING (public.is_owner() OR public.tenant_has_access(auth.uid(), tenant_id) OR beneficiary_user_id = auth.uid());
CREATE POLICY "deal_funder_assignments_access" ON public.deal_funder_assignments FOR ALL USING (public.is_owner() OR funder_user_id = auth.uid());
CREATE POLICY "terminals_tenant_isolation" ON public.terminals FOR ALL USING (public.is_owner() OR public.tenant_has_access(auth.uid(), tenant_id));
CREATE POLICY "legal_cases_access" ON public.legal_cases FOR ALL USING (public.is_owner() OR public.is_legal() OR assigned_to = auth.uid());

-- Indexes
CREATE INDEX IF NOT EXISTS idx_merchants_tenant_id ON public.merchants(tenant_id);
CREATE INDEX IF NOT EXISTS idx_deal_commissions_deal_id ON public.deal_commissions(deal_id);
CREATE INDEX IF NOT EXISTS idx_deal_funder_assignments_funder ON public.deal_funder_assignments(funder_user_id);
CREATE INDEX IF NOT EXISTS idx_terminals_merchant_id ON public.terminals(merchant_id);
CREATE INDEX IF NOT EXISTS idx_legal_cases_assigned_to ON public.legal_cases(assigned_to);

-- =================================================================
-- MIGRATION: 20251209055325_edae05f3-d461-416c-b029-a1d5b08daabe.sql
-- =================================================================
-- ======================================================
-- PILLAR 1: CORE MISSING TABLES FOR DEAL / FUNDER / AUDIT
-- ======================================================

-- 1) DEAL OFFERS – one row per funder offer on a deal
CREATE TABLE IF NOT EXISTS public.deal_offers (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  deal_id UUID REFERENCES deals(id) ON DELETE CASCADE,
  funder_id UUID REFERENCES funders(id) ON DELETE CASCADE,
  tenant_id UUID REFERENCES wf_tenants(id),

  approved_amount NUMERIC,
  factor_rate NUMERIC,
  payback_amount NUMERIC,
  term_days INTEGER,
  payment_frequency TEXT DEFAULT 'daily',
  daily_payment NUMERIC,

  status TEXT DEFAULT 'pending',
  expires_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

ALTER TABLE public.deal_offers ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Funder sees own offers"
  ON public.deal_offers FOR SELECT
  USING (
    funder_id IN (
      SELECT id FROM funders WHERE user_id = auth.uid()
    )
  );

CREATE POLICY "Owner/Admin sees all offers"
  ON public.deal_offers FOR ALL
  USING (
    EXISTS (
      SELECT 1
      FROM user_roles
      WHERE user_id = auth.uid()
      AND role IN ('owner', 'admin')
      AND approved = true
    )
  );

CREATE POLICY "Tenant members can view tenant offers"
  ON public.deal_offers FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM wf_tenant_users
      WHERE wf_tenant_users.tenant_id = deal_offers.tenant_id
      AND wf_tenant_users.user_id = auth.uid()
    )
  );

----------------------------------------------------------
-- 2) DEAL DOCUMENTS – document tracking per deal
----------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.deal_documents (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  deal_id UUID REFERENCES deals(id) ON DELETE CASCADE,
  tenant_id UUID REFERENCES wf_tenants(id),

  doc_type TEXT,
  url TEXT,
  extracted_data JSONB,
  status TEXT DEFAULT 'pending',
  created_at TIMESTAMPTZ DEFAULT now()
);

ALTER TABLE public.deal_documents ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Tenant scope deal_documents"
  ON public.deal_documents FOR SELECT
  USING (
    EXISTS (
      SELECT 1
      FROM wf_tenant_users
      WHERE wf_tenant_users.tenant_id = deal_documents.tenant_id
      AND wf_tenant_users.user_id = auth.uid()
    )
    OR
    EXISTS (
      SELECT 1 FROM user_roles
      WHERE user_id = auth.uid()
      AND role IN ('owner', 'admin')
      AND approved = true
    )
  );

CREATE POLICY "Tenant members can insert deal_documents"
  ON public.deal_documents FOR INSERT
  WITH CHECK (
    EXISTS (
      SELECT 1
      FROM wf_tenant_users
      WHERE wf_tenant_users.tenant_id = deal_documents.tenant_id
      AND wf_tenant_users.user_id = auth.uid()
    )
    OR
    EXISTS (
      SELECT 1 FROM user_roles
      WHERE user_id = auth.uid()
      AND role IN ('owner', 'admin')
      AND approved = true
    )
  );

----------------------------------------------------------
-- 3) DEAL EVENTS – timeline & audit per deal
----------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.deal_events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  deal_id UUID REFERENCES deals(id) ON DELETE CASCADE,
  tenant_id UUID REFERENCES wf_tenants(id),
  event_type TEXT,
  metadata JSONB,
  created_by UUID,
  created_at TIMESTAMPTZ DEFAULT now()
);

ALTER TABLE public.deal_events ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Tenant scope deal_events select"
  ON public.deal_events FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM wf_tenant_users
      WHERE wf_tenant_users.tenant_id = deal_events.tenant_id
      AND wf_tenant_users.user_id = auth.uid()
    )
    OR
    EXISTS (
      SELECT 1 FROM user_roles
      WHERE user_id = auth.uid()
      AND role IN ('owner', 'admin')
      AND approved = true
    )
  );

CREATE POLICY "System can insert deal_events"
  ON public.deal_events FOR INSERT
  WITH CHECK (true);

-- =================================================================
-- MIGRATION: 20251210090000_phase1_identity_tenant_os.sql
-- =================================================================
-- Phase 1: Wolf ID + Tenant OS Core Scaffolding

-- 1. Expand wolf_identity_verifications to support Wolf ID workflow
ALTER TABLE public.wolf_identity_verifications
  ADD COLUMN IF NOT EXISTS method TEXT NOT NULL DEFAULT 'wolf_id',
  ADD COLUMN IF NOT EXISTS documents JSONB NOT NULL DEFAULT '[]'::jsonb,
  ADD COLUMN IF NOT EXISTS reviewed_by UUID,
  ADD COLUMN IF NOT EXISTS reviewed_at TIMESTAMPTZ,
  ADD COLUMN IF NOT EXISTS notes TEXT,
  ADD COLUMN IF NOT EXISTS correlation_id UUID,
  ADD COLUMN IF NOT EXISTS metadata JSONB NOT NULL DEFAULT '{}'::jsonb;

ALTER TABLE public.wolf_identity_verifications
  ALTER COLUMN status SET DEFAULT 'pending';

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint
    WHERE conname = 'wolf_identity_verifications_status_check'
  ) THEN
    ALTER TABLE public.wolf_identity_verifications
      ADD CONSTRAINT wolf_identity_verifications_status_check
      CHECK (status IN ('pending', 'requires_review', 'verified', 'rejected', 'suspended'));
  END IF;
END
$$;

-- 2. Tenant OS Core Tables
CREATE TABLE IF NOT EXISTS public.wolf_tenants (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  slug TEXT UNIQUE NOT NULL,
  name TEXT NOT NULL,
  display_name TEXT,
  tenant_type TEXT NOT NULL DEFAULT 'tenant',
  status TEXT NOT NULL DEFAULT 'active',
  metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_by UUID,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.wolf_tenant_users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES public.wolf_tenants(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  role TEXT NOT NULL CHECK (role IN ('tenant_owner', 'tenant_admin', 'tenant_worker', 'tenant_viewer')),
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'active', 'suspended', 'invited')),
  invited_by UUID,
  invited_at TIMESTAMPTZ DEFAULT now(),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, user_id)
);

CREATE TABLE IF NOT EXISTS public.wolf_tenant_feature_flags (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES public.wolf_tenants(id) ON DELETE CASCADE,
  feature_key TEXT NOT NULL REFERENCES public.wolf_feature_flags(feature_key) ON DELETE CASCADE,
  is_enabled BOOLEAN NOT NULL DEFAULT false,
  notes TEXT,
  created_by UUID,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, feature_key)
);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_wolf_tenant_users_tenant ON public.wolf_tenant_users(tenant_id);
CREATE INDEX IF NOT EXISTS idx_wolf_tenant_users_user ON public.wolf_tenant_users(user_id);
CREATE INDEX IF NOT EXISTS idx_wolf_tenant_feature_flags_tenant ON public.wolf_tenant_feature_flags(tenant_id);

-- Enable RLS
ALTER TABLE public.wolf_tenants ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.wolf_tenant_users ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.wolf_tenant_feature_flags ENABLE ROW LEVEL SECURITY;

-- Policies for wolf_tenants
CREATE POLICY "Admins manage wolf_tenants"
  ON public.wolf_tenants
  FOR ALL
  USING (has_role(auth.uid(), 'admin'::public.app_role))
  WITH CHECK (has_role(auth.uid(), 'admin'::public.app_role));

CREATE POLICY "Members can view their tenant"
  ON public.wolf_tenants
  FOR SELECT
  USING (
    EXISTS (
      SELECT 1
      FROM public.wolf_tenant_users mtu
      WHERE mtu.tenant_id = public.wolf_tenants.id
        AND mtu.user_id = auth.uid()
        AND mtu.status = 'active'
    )
    OR has_role(auth.uid(), 'admin'::public.app_role)
  );

-- Policies for wolf_tenant_users
CREATE POLICY "Admins manage wolf_tenant_users"
  ON public.wolf_tenant_users
  FOR ALL
  USING (has_role(auth.uid(), 'admin'::public.app_role))
  WITH CHECK (has_role(auth.uid(), 'admin'::public.app_role));

CREATE POLICY "Users can view their own memberships"
  ON public.wolf_tenant_users
  FOR SELECT
  USING (
    user_id = auth.uid()
    OR EXISTS (
      SELECT 1
      FROM public.wolf_tenant_users mtu
      WHERE mtu.tenant_id = public.wolf_tenant_users.tenant_id
        AND mtu.user_id = auth.uid()
        AND mtu.role IN ('tenant_owner', 'tenant_admin')
        AND mtu.status = 'active'
    )
  );

CREATE POLICY "Tenant owners manage their tenant users"
  ON public.wolf_tenant_users
  FOR ALL
  USING (
    EXISTS (
      SELECT 1
      FROM public.wolf_tenant_users mtu
      WHERE mtu.tenant_id = public.wolf_tenant_users.tenant_id
        AND mtu.user_id = auth.uid()
        AND mtu.role = 'tenant_owner'
        AND mtu.status = 'active'
    )
    OR has_role(auth.uid(), 'admin'::public.app_role)
  )
  WITH CHECK (
    EXISTS (
      SELECT 1
      FROM public.wolf_tenant_users mtu
      WHERE mtu.tenant_id = public.wolf_tenant_users.tenant_id
        AND mtu.user_id = auth.uid()
        AND mtu.role = 'tenant_owner'
        AND mtu.status = 'active'
    )
    OR has_role(auth.uid(), 'admin'::public.app_role)
  );

-- Policies for wolf_tenant_feature_flags
CREATE POLICY "Admins manage tenant feature flags"
  ON public.wolf_tenant_feature_flags
  FOR ALL
  USING (has_role(auth.uid(), 'admin'::public.app_role))
  WITH CHECK (has_role(auth.uid(), 'admin'::public.app_role));

CREATE POLICY "Tenant owners view feature flags"
  ON public.wolf_tenant_feature_flags
  FOR SELECT
  USING (
    EXISTS (
      SELECT 1
      FROM public.wolf_tenant_users mtu
      WHERE mtu.tenant_id = public.wolf_tenant_feature_flags.tenant_id
        AND mtu.user_id = auth.uid()
        AND mtu.role IN ('tenant_owner', 'tenant_admin')
        AND mtu.status = 'active'
    )
    OR has_role(auth.uid(), 'admin'::public.app_role)
  );

-- 3. Seed default internal tenant
INSERT INTO public.wolf_tenants (id, slug, name, display_name, tenant_type, status, metadata)
VALUES (
  '00000000-0000-0000-0000-000000000001',
  'wolf-fund',
  'Wolf Fund',
  'Wolf Fund OS',
  'internal',
  'active',
  '{"system": true}'::jsonb
);
ON CONFLICT (slug) DO UPDATE
SET name = EXCLUDED.name,
    display_name = EXCLUDED.display_name;

-- 4. Feature flag definitions for Phase 1
INSERT INTO public.wolf_feature_flags (feature_key, is_enabled, description)
VALUES 
  ('ff_wolf_id', false, 'Enables Wolf ID verification flows'),
  ('ff_tenant_os_bootstrap', false, 'Enables Tenant OS bootstrap UI & API')
ON CONFLICT (feature_key) DO UPDATE
SET description = EXCLUDED.description;

-- 5. Default tenant feature flag records (shadow mode)
INSERT INTO public.wolf_tenant_feature_flags (tenant_id, feature_key, is_enabled, created_by)
SELECT
  '00000000-0000-0000-0000-000000000001',
  feature_key,
  false,
  NULL
FROM public.wolf_feature_flags
WHERE feature_key IN ('ff_wolf_id', 'ff_tenant_os_bootstrap')
ON CONFLICT (tenant_id, feature_key) DO NOTHING;

-- 6. Ledger logging trigger helpers
CREATE OR REPLACE FUNCTION public.log_identity_verification_event()
RETURNS trigger
LANGUAGE plpgsql
AS $$
DECLARE
  v_event text;
  v_severity text;
BEGIN
  v_event := CASE WHEN TG_OP = 'INSERT' THEN 'identity.created' ELSE 'identity.updated' END;
  v_severity := CASE 
    WHEN NEW.status = 'rejected' THEN 'warning'
    WHEN NEW.status = 'suspended' THEN 'error'
    ELSE 'info'
  END;

  INSERT INTO public.wolf_events (
    event_type,
    severity,
    actor_type,
    actor_id,
    context_type,
    context_id,
    source,
    payload
  )
  VALUES (
    v_event,
    v_severity,
    'system',
    NEW.reviewed_by,
    'user',
    NEW.user_id::text,
    'wolf_identity_verifications',
    jsonb_build_object(
      'verification_id', NEW.id,
      'status', NEW.status,
      'method', NEW.method,
      'reviewed_by', NEW.reviewed_by,
      'correlation_id', NEW.correlation_id
    )
  );

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_log_identity_verification_event ON public.wolf_identity_verifications;
CREATE TRIGGER trg_log_identity_verification_event
AFTER INSERT OR UPDATE ON public.wolf_identity_verifications
FOR EACH ROW EXECUTE FUNCTION public.log_identity_verification_event();

CREATE OR REPLACE FUNCTION public.log_wolf_tenant_event()
RETURNS trigger
LANGUAGE plpgsql
AS $$
DECLARE
  v_event text;
BEGIN
  v_event := CASE WHEN TG_OP = 'INSERT' THEN 'tenant.created' ELSE 'tenant.updated' END;

  INSERT INTO public.wolf_events (event_type, severity, context_type, context_id, source, payload)
  VALUES (
    v_event,
    'info',
    'tenant',
    NEW.id::text,
    'wolf_tenants',
    jsonb_build_object(
      'tenant_id', NEW.id,
      'slug', NEW.slug,
      'status', NEW.status,
      'tenant_type', NEW.tenant_type
    )
  );

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_log_wolf_tenant_event ON public.wolf_tenants;
CREATE TRIGGER trg_log_wolf_tenant_event
AFTER INSERT OR UPDATE ON public.wolf_tenants
FOR EACH ROW EXECUTE FUNCTION public.log_wolf_tenant_event();

CREATE OR REPLACE FUNCTION public.log_wolf_tenant_user_event()
RETURNS trigger
LANGUAGE plpgsql
AS $$
DECLARE
  v_event text;
  v_payload jsonb;
  v_row public.wolf_tenant_users;
BEGIN
  IF TG_OP = 'DELETE' THEN
    v_event := 'tenant.user_removed';
    v_row := OLD;
  ELSIF TG_OP = 'INSERT' THEN
    v_event := 'tenant.user_added';
    v_row := NEW;
  ELSE
    v_event := 'tenant.user_updated';
    v_row := NEW;
  END IF;

  v_payload := jsonb_build_object(
    'tenant_id', v_row.tenant_id,
    'user_id', v_row.user_id,
    'role', v_row.role,
    'status', v_row.status
  );

  INSERT INTO public.wolf_events (event_type, severity, context_type, context_id, source, payload)
  VALUES (
    v_event,
    'info',
    'tenant',
    v_row.tenant_id::text,
    'wolf_tenant_users',
    v_payload
  );

  IF TG_OP = 'DELETE' THEN
    RETURN OLD;
  ELSE
    RETURN NEW;
  END IF;
END;
$$;

DROP TRIGGER IF EXISTS trg_log_wolf_tenant_user_event ON public.wolf_tenant_users;
CREATE TRIGGER trg_log_wolf_tenant_user_event
AFTER INSERT OR UPDATE OR DELETE ON public.wolf_tenant_users
FOR EACH ROW EXECUTE FUNCTION public.log_wolf_tenant_user_event();

CREATE OR REPLACE FUNCTION public.log_wolf_tenant_feature_flag_event()
RETURNS trigger
LANGUAGE plpgsql
AS $$
DECLARE
  v_event text;
  v_row public.wolf_tenant_feature_flags;
BEGIN
  IF TG_OP = 'DELETE' THEN
    v_event := 'feature_flag.removed';
    v_row := OLD;
  ELSIF TG_OP = 'INSERT' THEN
    v_event := 'feature_flag.assigned';
    v_row := NEW;
  ELSE
    v_event := 'feature_flag.updated';
    v_row := NEW;
  END IF;

  INSERT INTO public.wolf_events (event_type, severity, context_type, context_id, source, payload)
  VALUES (
    v_event,
    'info',
    'tenant',
    v_row.tenant_id::text,
    'wolf_tenant_feature_flags',
    jsonb_build_object(
      'tenant_id', v_row.tenant_id,
      'feature_key', v_row.feature_key,
      'is_enabled', v_row.is_enabled
    )
  );

  IF TG_OP = 'DELETE' THEN
    RETURN OLD;
  ELSE
    RETURN NEW;
  END IF;
END;
$$;

DROP TRIGGER IF EXISTS trg_log_wolf_tenant_feature_flag_event ON public.wolf_tenant_feature_flags;
CREATE TRIGGER trg_log_wolf_tenant_feature_flag_event
AFTER INSERT OR UPDATE OR DELETE ON public.wolf_tenant_feature_flags
FOR EACH ROW EXECUTE FUNCTION public.log_wolf_tenant_feature_flag_event();

-- =================================================================
-- MIGRATION: 20251210120000_phase2_core_tables.sql
-- =================================================================
-- Phase 2 Core Schema: Lead Engine V3, Credit Fix V2, Funder / God Mode / Merchant layers

------------------------------------------------------------
-- Lead Engine V3 tables
------------------------------------------------------------

CREATE TABLE IF NOT EXISTS public.lead_pipeline (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES public.wolf_tenants(id),
  lead_id UUID NOT NULL REFERENCES public.leads(id),
  lane TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'active',
  priority INTEGER NOT NULL DEFAULT 50,
  meta JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_lead_pipeline_tenant_lane
  ON public.lead_pipeline (tenant_id, lane);

CREATE INDEX IF NOT EXISTS idx_lead_pipeline_lead
  ON public.lead_pipeline (lead_id);

CREATE TABLE IF NOT EXISTS public.lead_lane_events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  pipeline_id UUID NOT NULL REFERENCES public.lead_pipeline(id) ON DELETE CASCADE,
  lane TEXT NOT NULL,
  event_type TEXT NOT NULL,
  payload JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_lead_lane_events_pipeline
  ON public.lead_lane_events (pipeline_id, created_at DESC);

CREATE TABLE IF NOT EXISTS public.lead_lane_assignments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  pipeline_id UUID NOT NULL REFERENCES public.lead_pipeline(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES auth.users(id),
  role TEXT NOT NULL DEFAULT 'owner',
  status TEXT NOT NULL DEFAULT 'active',
  assigned_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX IF NOT EXISTS uq_lead_lane_assignments_pipeline_user
  ON public.lead_lane_assignments (pipeline_id, user_id);

CREATE TABLE IF NOT EXISTS public.lead_action_queue (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  pipeline_id UUID NOT NULL REFERENCES public.lead_pipeline(id) ON DELETE CASCADE,
  action_type TEXT NOT NULL,
  payload JSONB NOT NULL DEFAULT '{}'::jsonb,
  scheduled_at TIMESTAMPTZ NOT NULL,
  run_after TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  processed_at TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS idx_lead_action_queue_schedule
  ON public.lead_action_queue (scheduled_at, processed_at);

------------------------------------------------------------
-- Credit Fix V2 tables
------------------------------------------------------------

CREATE TABLE IF NOT EXISTS public.credit_dispute_cases_v2 (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES public.wolf_tenants(id),
  client_user_id UUID NOT NULL REFERENCES auth.users(id),
  status TEXT NOT NULL DEFAULT 'intake',
  score_at_open INTEGER,
  case_meta JSONB NOT NULL DEFAULT '{}'::jsonb,
  opened_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_credit_cases_v2_tenant_status
  ON public.credit_dispute_cases_v2 (tenant_id, status);

CREATE TABLE IF NOT EXISTS public.credit_violation_templates (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES public.wolf_tenants(id),
  violation_code TEXT NOT NULL,
  title TEXT NOT NULL,
  letter_template TEXT NOT NULL,
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX IF NOT EXISTS uq_credit_violation_templates
  ON public.credit_violation_templates (tenant_id, violation_code);

CREATE TABLE IF NOT EXISTS public.credit_documents_vault (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES public.wolf_tenants(id),
  case_id UUID NOT NULL REFERENCES public.credit_dispute_cases_v2(id) ON DELETE CASCADE,
  storage_path TEXT NOT NULL,
  doc_type TEXT NOT NULL,
  metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_credit_documents_vault_case
  ON public.credit_documents_vault (case_id);

CREATE TABLE IF NOT EXISTS public.credit_attorney_reviews (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  case_id UUID NOT NULL REFERENCES public.credit_dispute_cases_v2(id) ON DELETE CASCADE,
  attorney_user_id UUID NOT NULL REFERENCES auth.users(id),
  status TEXT NOT NULL DEFAULT 'pending',
  notes TEXT,
  reviewed_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

------------------------------------------------------------
-- Funder & underwriting sync
------------------------------------------------------------

CREATE TABLE IF NOT EXISTS public.funder_pipeline (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES public.wolf_tenants(id),
  deal_id UUID NOT NULL REFERENCES public.deals(id),
  stage TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'active',
  last_funder_touch TIMESTAMPTZ,
  stage_notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_funder_pipeline_tenant_stage
  ON public.funder_pipeline (tenant_id, stage);

CREATE TABLE IF NOT EXISTS public.bank_verification_sessions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES public.wolf_tenants(id),
  deal_id UUID NOT NULL REFERENCES public.deals(id),
  provider TEXT NOT NULL,
  state TEXT NOT NULL DEFAULT 'pending',
  session_meta JSONB NOT NULL DEFAULT '{}'::jsonb,
  expires_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_bank_verification_sessions_deal
  ON public.bank_verification_sessions (deal_id);

CREATE TABLE IF NOT EXISTS public.syndication_partners (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES public.wolf_tenants(id),
  partner_name TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending',
  risk_score INTEGER NOT NULL DEFAULT 50,
  metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX IF NOT EXISTS uq_syndication_partners_name
  ON public.syndication_partners (tenant_id, partner_name);

CREATE TABLE IF NOT EXISTS public.deal_protection_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES public.wolf_tenants(id),
  deal_id UUID NOT NULL REFERENCES public.deals(id),
  event_type TEXT NOT NULL,
  details JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_deal_protection_logs_deal
  ON public.deal_protection_logs (deal_id, created_at DESC);

------------------------------------------------------------
-- SuperOwner GOD mode + Autopilot
------------------------------------------------------------

CREATE TABLE IF NOT EXISTS public.god_mode_alerts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID REFERENCES public.wolf_tenants(id),
  alert_type TEXT NOT NULL,
  severity TEXT NOT NULL DEFAULT 'info',
  payload JSONB NOT NULL DEFAULT '{}'::jsonb,
  acknowledged BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.system_anomalies (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  source TEXT NOT NULL,
  description TEXT NOT NULL,
  severity TEXT NOT NULL DEFAULT 'warning',
  resolved BOOLEAN NOT NULL DEFAULT false,
  resolved_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_system_anomalies_resolved
  ON public.system_anomalies (resolved, created_at DESC);

CREATE TABLE IF NOT EXISTS public.autopilot_actions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID REFERENCES public.wolf_tenants(id),
  action_type TEXT NOT NULL,
  target_entity TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending',
  payload JSONB NOT NULL DEFAULT '{}'::jsonb,
  run_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

------------------------------------------------------------
-- Merchant processing layer
------------------------------------------------------------

CREATE TABLE IF NOT EXISTS public.merchant_profiles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES public.wolf_tenants(id),
  business_name TEXT NOT NULL,
  processing_volume NUMERIC,
  preferred_vendor TEXT,
  settings JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.processing_vendor_rates (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  vendor_name TEXT NOT NULL,
  rate_structure JSONB NOT NULL DEFAULT '{}'::jsonb,
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX IF NOT EXISTS uq_processing_vendor_rates_name
  ON public.processing_vendor_rates (vendor_name);

------------------------------------------------------------
-- Ledger trigger helpers
------------------------------------------------------------

CREATE OR REPLACE FUNCTION public.log_lead_pipeline_event()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
DECLARE
  v_event TEXT;
  v_row public.lead_pipeline;
BEGIN
  IF TG_OP = 'DELETE' THEN
    v_event := 'lead.pipeline.deleted';
    v_row := OLD;
  ELSIF TG_OP = 'UPDATE' THEN
    v_event := 'lead.pipeline.updated';
    v_row := NEW;
  ELSE
    v_event := 'lead.pipeline.created';
    v_row := NEW;
  END IF;

  INSERT INTO public.wolf_events (
    event_type,
    severity,
    actor_type,
    context_type,
    context_id,
    source,
    payload
  ) VALUES (
    v_event,
    'info',
    'system',
    'lead',
    v_row.lead_id::text,
    'lead_pipeline',
    jsonb_build_object(
      'pipeline_id', v_row.id,
      'tenant_id', v_row.tenant_id,
      'lane', v_row.lane,
      'status', v_row.status,
      'priority', v_row.priority
    )
  );

  IF TG_OP = 'DELETE' THEN
    RETURN OLD;
  ELSE
    RETURN NEW;
  END IF;
END;
$$;

DROP TRIGGER IF EXISTS trg_log_lead_pipeline_event ON public.lead_pipeline;
CREATE TRIGGER trg_log_lead_pipeline_event
AFTER INSERT OR UPDATE OR DELETE ON public.lead_pipeline
FOR EACH ROW EXECUTE FUNCTION public.log_lead_pipeline_event();

CREATE OR REPLACE FUNCTION public.log_credit_case_v2_event()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
DECLARE
  v_event TEXT;
  v_row public.credit_dispute_cases_v2;
BEGIN
  IF TG_OP = 'DELETE' THEN
    v_event := 'credit.case_v2.deleted';
    v_row := OLD;
  ELSIF TG_OP = 'UPDATE' THEN
    v_event := 'credit.case_v2.updated';
    v_row := NEW;
  ELSE
    v_event := 'credit.case_v2.created';
    v_row := NEW;
  END IF;

  INSERT INTO public.wolf_events (
    event_type,
    severity,
    actor_type,
    context_type,
    context_id,
    source,
    payload
  ) VALUES (
    v_event,
    'info',
    'system',
    'credit_case_v2',
    v_row.id::text,
    'credit_dispute_cases_v2',
    jsonb_build_object(
      'tenant_id', v_row.tenant_id,
      'client_user_id', v_row.client_user_id,
      'status', v_row.status
    )
  );

  IF TG_OP = 'DELETE' THEN
    RETURN OLD;
  ELSE
    RETURN NEW;
  END IF;
END;
$$;

DROP TRIGGER IF EXISTS trg_log_credit_case_v2_event ON public.credit_dispute_cases_v2;
CREATE TRIGGER trg_log_credit_case_v2_event
AFTER INSERT OR UPDATE OR DELETE ON public.credit_dispute_cases_v2
FOR EACH ROW EXECUTE FUNCTION public.log_credit_case_v2_event();

CREATE OR REPLACE FUNCTION public.log_funder_pipeline_event()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
DECLARE
  v_event TEXT;
  v_row public.funder_pipeline;
BEGIN
  IF TG_OP = 'DELETE' THEN
    v_event := 'funder.pipeline.deleted';
    v_row := OLD;
  ELSIF TG_OP = 'UPDATE' THEN
    v_event := 'funder.pipeline.updated';
    v_row := NEW;
  ELSE
    v_event := 'funder.pipeline.created';
    v_row := NEW;
  END IF;

  INSERT INTO public.wolf_events (
    event_type,
    severity,
    actor_type,
    context_type,
    context_id,
    source,
    payload
  ) VALUES (
    v_event,
    'info',
    'system',
    'deal',
    v_row.deal_id::text,
    'funder_pipeline',
    jsonb_build_object(
      'tenant_id', v_row.tenant_id,
      'stage', v_row.stage,
      'status', v_row.status
    )
  );

  IF TG_OP = 'DELETE' THEN
    RETURN OLD;
  ELSE
    RETURN NEW;
  END IF;
END;
$$;

DROP TRIGGER IF EXISTS trg_log_funder_pipeline_event ON public.funder_pipeline;
CREATE TRIGGER trg_log_funder_pipeline_event
AFTER INSERT OR UPDATE OR DELETE ON public.funder_pipeline
FOR EACH ROW EXECUTE FUNCTION public.log_funder_pipeline_event();

CREATE OR REPLACE FUNCTION public.log_god_mode_alert_event()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
DECLARE
  v_event TEXT;
  v_row public.god_mode_alerts;
BEGIN
  IF TG_OP = 'DELETE' THEN
    v_event := 'god_mode.alert.deleted';
    v_row := OLD;
  ELSIF TG_OP = 'UPDATE' THEN
    v_event := 'god_mode.alert.updated';
    v_row := NEW;
  ELSE
    v_event := 'god_mode.alert.created';
    v_row := NEW;
  END IF;

  INSERT INTO public.wolf_events (
    event_type,
    severity,
    actor_type,
    context_type,
    context_id,
    source,
    payload
  ) VALUES (
    v_event,
    v_row.severity,
    'system',
    'god_mode_alert',
    v_row.id::text,
    'god_mode_alerts',
    jsonb_build_object(
      'tenant_id', v_row.tenant_id,
      'alert_type', v_row.alert_type,
      'acknowledged', v_row.acknowledged
    )
  );

  IF TG_OP = 'DELETE' THEN
    RETURN OLD;
  ELSE
    RETURN NEW;
  END IF;
END;
$$;

DROP TRIGGER IF EXISTS trg_log_god_mode_alert_event ON public.god_mode_alerts;
CREATE TRIGGER trg_log_god_mode_alert_event
AFTER INSERT OR UPDATE OR DELETE ON public.god_mode_alerts
FOR EACH ROW EXECUTE FUNCTION public.log_god_mode_alert_event();

CREATE OR REPLACE FUNCTION public.log_autopilot_action_event()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
DECLARE
  v_event TEXT;
  v_row public.autopilot_actions;
BEGIN
  IF TG_OP = 'DELETE' THEN
    v_event := 'autopilot.action.deleted';
    v_row := OLD;
  ELSIF TG_OP = 'UPDATE' THEN
    v_event := 'autopilot.action.updated';
    v_row := NEW;
  ELSE
    v_event := 'autopilot.action.created';
    v_row := NEW;
  END IF;

  INSERT INTO public.wolf_events (
    event_type,
    severity,
    actor_type,
    context_type,
    context_id,
    source,
    payload
  ) VALUES (
    v_event,
    'info',
    'system',
    'autopilot_action',
    v_row.id::text,
    'autopilot_actions',
    jsonb_build_object(
      'tenant_id', v_row.tenant_id,
      'action_type', v_row.action_type,
      'status', v_row.status
    )
  );

  IF TG_OP = 'DELETE' THEN
    RETURN OLD;
  ELSE
    RETURN NEW;
  END IF;
END;
$$;

DROP TRIGGER IF EXISTS trg_log_autopilot_action_event ON public.autopilot_actions;
CREATE TRIGGER trg_log_autopilot_action_event
AFTER INSERT OR UPDATE OR DELETE ON public.autopilot_actions
FOR EACH ROW EXECUTE FUNCTION public.log_autopilot_action_event();

CREATE OR REPLACE FUNCTION public.log_merchant_profile_event()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
DECLARE
  v_event TEXT;
  v_row public.merchant_profiles;
BEGIN
  IF TG_OP = 'DELETE' THEN
    v_event := 'merchant.profile.deleted';
    v_row := OLD;
  ELSIF TG_OP = 'UPDATE' THEN
    v_event := 'merchant.profile.updated';
    v_row := NEW;
  ELSE
    v_event := 'merchant.profile.created';
    v_row := NEW;
  END IF;

  INSERT INTO public.wolf_events (
    event_type,
    severity,
    actor_type,
    context_type,
    context_id,
    source,
    payload
  ) VALUES (
    v_event,
    'info',
    'system',
    'merchant_profile',
    v_row.id::text,
    'merchant_profiles',
    jsonb_build_object(
      'tenant_id', v_row.tenant_id,
      'business_name', v_row.business_name,
      'preferred_vendor', v_row.preferred_vendor
    )
  );

  IF TG_OP = 'DELETE' THEN
    RETURN OLD;
  ELSE
    RETURN NEW;
  END IF;
END;
$$;

DROP TRIGGER IF EXISTS trg_log_merchant_profile_event ON public.merchant_profiles;
CREATE TRIGGER trg_log_merchant_profile_event
AFTER INSERT OR UPDATE OR DELETE ON public.merchant_profiles
FOR EACH ROW EXECUTE FUNCTION public.log_merchant_profile_event();

CREATE OR REPLACE FUNCTION public.log_system_anomaly_event()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
DECLARE
  v_event TEXT;
  v_row public.system_anomalies;
BEGIN
  IF TG_OP = 'DELETE' THEN
    v_event := 'system.anomaly.deleted';
    v_row := OLD;
  ELSIF TG_OP = 'UPDATE' THEN
    v_event := 'system.anomaly.updated';
    v_row := NEW;
  ELSE
    v_event := 'system.anomaly.created';
    v_row := NEW;
  END IF;

  INSERT INTO public.wolf_events (
    event_type,
    severity,
    actor_type,
    context_type,
    context_id,
    source,
    payload
  ) VALUES (
    v_event,
    v_row.severity,
    'system',
    'system_anomaly',
    v_row.id::text,
    'system_anomalies',
    jsonb_build_object(
      'source', v_row.source,
      'resolved', v_row.resolved,
      'resolved_at', v_row.resolved_at
    )
  );

  IF TG_OP = 'DELETE' THEN
    RETURN OLD;
  ELSE
    RETURN NEW;
  END IF;
END;
$$;

DROP TRIGGER IF EXISTS trg_log_system_anomaly_event ON public.system_anomalies;
CREATE TRIGGER trg_log_system_anomaly_event
AFTER INSERT OR UPDATE OR DELETE ON public.system_anomalies
FOR EACH ROW EXECUTE FUNCTION public.log_system_anomaly_event();

------------------------------------------------------------
-- Helpful additional indexes (Phase 2)
------------------------------------------------------------

CREATE INDEX IF NOT EXISTS idx_credit_attorney_reviews_case
  ON public.credit_attorney_reviews (case_id);

CREATE INDEX IF NOT EXISTS idx_god_mode_alerts_tenant_severity
  ON public.god_mode_alerts (tenant_id, severity, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_merchant_profiles_tenant
  ON public.merchant_profiles (tenant_id);


-- =================================================================
-- MIGRATION: 20251210123000_phase2_rls_feature_flags.sql
-- =================================================================
-- ============================================================
-- Phase 2 – RLS + Feature Flags
-- DO NOT TOUCH phase2_core_tables.sql – this file only adds
--   - helper functions
--   - RLS policies
--   - feature flag seeds
-- ============================================================

------------------------------------------------------------
-- Helper: role + tenant membership helpers
------------------------------------------------------------

-- NOTE: legacy public.has_role(text) overload removed.
-- Canonical production signature is:
--   public.has_role(user_id uuid, required_role public.app_role) RETURNS boolean

-- Tenant membership helper – used by all tenant-scoped tables.
CREATE OR REPLACE FUNCTION public.is_tenant_member(target_tenant uuid)
RETURNS boolean
LANGUAGE sql
STABLE
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.wolf_tenant_users tu
    WHERE tu.tenant_id = target_tenant
      AND tu.user_id = auth.uid()
      AND tu.status = 'active'
  );
$$;

-- SuperOwner / Owner helper (for GOD mode & cross-tenant views).
CREATE OR REPLACE FUNCTION public.is_superowner()
RETURNS boolean
LANGUAGE sql
STABLE
AS $$
  SELECT
    public.has_role(auth.uid(), 'super_owner'::public.app_role)
    OR public.has_role(auth.uid(), 'owner'::public.app_role);
$$;

------------------------------------------------------------
-- RLS: Lead Engine V3 tables
------------------------------------------------------------

ALTER TABLE public.lead_pipeline ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.lead_lane_events ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.lead_lane_assignments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.lead_action_queue ENABLE ROW LEVEL SECURITY;

-- lead_pipeline
CREATE POLICY lead_pipeline_tenant_select
ON public.lead_pipeline
FOR SELECT
USING (public.is_tenant_member(tenant_id));

CREATE POLICY lead_pipeline_tenant_insert
ON public.lead_pipeline
FOR INSERT
WITH CHECK (public.is_tenant_member(tenant_id));

CREATE POLICY lead_pipeline_tenant_update
ON public.lead_pipeline
FOR UPDATE
USING (public.is_tenant_member(tenant_id))
WITH CHECK (public.is_tenant_member(tenant_id));

CREATE POLICY lead_pipeline_tenant_delete
ON public.lead_pipeline
FOR DELETE
USING (public.is_tenant_member(tenant_id));

-- lead_lane_events (inherits tenant via pipeline)
CREATE POLICY lead_lane_events_tenant_select
ON public.lead_lane_events
FOR SELECT
USING (
  EXISTS (
    SELECT 1
    FROM public.lead_pipeline p
    WHERE p.id = lead_lane_events.pipeline_id
      AND public.is_tenant_member(p.tenant_id)
  )
);

CREATE POLICY lead_lane_events_tenant_insert
ON public.lead_lane_events
FOR INSERT
WITH CHECK (
  EXISTS (
    SELECT 1
    FROM public.lead_pipeline p
    WHERE p.id = lead_lane_events.pipeline_id
      AND public.is_tenant_member(p.tenant_id)
  )
);

CREATE POLICY lead_lane_events_tenant_update
ON public.lead_lane_events
FOR UPDATE
USING (
  EXISTS (
    SELECT 1
    FROM public.lead_pipeline p
    WHERE p.id = lead_lane_events.pipeline_id
      AND public.is_tenant_member(p.tenant_id)
  )
)
WITH CHECK (
  EXISTS (
    SELECT 1
    FROM public.lead_pipeline p
    WHERE p.id = lead_lane_events.pipeline_id
      AND public.is_tenant_member(p.tenant_id)
  )
);

CREATE POLICY lead_lane_events_tenant_delete
ON public.lead_lane_events
FOR DELETE
USING (
  EXISTS (
    SELECT 1
    FROM public.lead_pipeline p
    WHERE p.id = lead_lane_events.pipeline_id
      AND public.is_tenant_member(p.tenant_id)
  )
);

-- lead_lane_assignments
CREATE POLICY lead_lane_assignments_tenant_select
ON public.lead_lane_assignments
FOR SELECT
USING (
  EXISTS (
    SELECT 1
    FROM public.lead_pipeline p
    WHERE p.id = lead_lane_assignments.pipeline_id
      AND public.is_tenant_member(p.tenant_id)
  )
);

CREATE POLICY lead_lane_assignments_tenant_insert
ON public.lead_lane_assignments
FOR INSERT
WITH CHECK (
  EXISTS (
    SELECT 1
    FROM public.lead_pipeline p
    WHERE p.id = lead_lane_assignments.pipeline_id
      AND public.is_tenant_member(p.tenant_id)
  )
);

CREATE POLICY lead_lane_assignments_tenant_update
ON public.lead_lane_assignments
FOR UPDATE
USING (
  EXISTS (
    SELECT 1
    FROM public.lead_pipeline p
    WHERE p.id = lead_lane_assignments.pipeline_id
      AND public.is_tenant_member(p.tenant_id)
  )
)
WITH CHECK (
  EXISTS (
    SELECT 1
    FROM public.lead_pipeline p
    WHERE p.id = lead_lane_assignments.pipeline_id
      AND public.is_tenant_member(p.tenant_id)
  )
);

CREATE POLICY lead_lane_assignments_tenant_delete
ON public.lead_lane_assignments
FOR DELETE
USING (
  EXISTS (
    SELECT 1
    FROM public.lead_pipeline p
    WHERE p.id = lead_lane_assignments.pipeline_id
      AND public.is_tenant_member(p.tenant_id)
  )
);

-- lead_action_queue
CREATE POLICY lead_action_queue_tenant_select
ON public.lead_action_queue
FOR SELECT
USING (
  EXISTS (
    SELECT 1
    FROM public.lead_pipeline p
    WHERE p.id = lead_action_queue.pipeline_id
      AND public.is_tenant_member(p.tenant_id)
  )
);

CREATE POLICY lead_action_queue_tenant_insert
ON public.lead_action_queue
FOR INSERT
WITH CHECK (
  EXISTS (
    SELECT 1
    FROM public.lead_pipeline p
    WHERE p.id = lead_action_queue.pipeline_id
      AND public.is_tenant_member(p.tenant_id)
  )
);

CREATE POLICY lead_action_queue_tenant_update
ON public.lead_action_queue
FOR UPDATE
USING (
  EXISTS (
    SELECT 1
    FROM public.lead_pipeline p
    WHERE p.id = lead_action_queue.pipeline_id
      AND public.is_tenant_member(p.tenant_id)
  )
)
WITH CHECK (
  EXISTS (
    SELECT 1
    FROM public.lead_pipeline p
    WHERE p.id = lead_action_queue.pipeline_id
      AND public.is_tenant_member(p.tenant_id)
  )
);

CREATE POLICY lead_action_queue_tenant_delete
ON public.lead_action_queue
FOR DELETE
USING (
  EXISTS (
    SELECT 1
    FROM public.lead_pipeline p
    WHERE p.id = lead_action_queue.pipeline_id
      AND public.is_tenant_member(p.tenant_id)
  )
);

------------------------------------------------------------
-- RLS: Credit Fix V2 tables
------------------------------------------------------------

ALTER TABLE public.credit_dispute_cases_v2 ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.credit_violation_templates ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.credit_documents_vault ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.credit_attorney_reviews ENABLE ROW LEVEL SECURITY;

-- credit_dispute_cases_v2
CREATE POLICY credit_cases_v2_tenant_select
ON public.credit_dispute_cases_v2
FOR SELECT
USING (public.is_tenant_member(tenant_id));

CREATE POLICY credit_cases_v2_tenant_insert
ON public.credit_dispute_cases_v2
FOR INSERT
WITH CHECK (public.is_tenant_member(tenant_id));

CREATE POLICY credit_cases_v2_tenant_update
ON public.credit_dispute_cases_v2
FOR UPDATE
USING (public.is_tenant_member(tenant_id))
WITH CHECK (public.is_tenant_member(tenant_id));

CREATE POLICY credit_cases_v2_tenant_delete
ON public.credit_dispute_cases_v2
FOR DELETE
USING (public.is_tenant_member(tenant_id));

-- credit_violation_templates
CREATE POLICY credit_violation_templates_tenant_select
ON public.credit_violation_templates
FOR SELECT
USING (public.is_tenant_member(tenant_id));

CREATE POLICY credit_violation_templates_tenant_insert
ON public.credit_violation_templates
FOR INSERT
WITH CHECK (public.is_tenant_member(tenant_id));

CREATE POLICY credit_violation_templates_tenant_update
ON public.credit_violation_templates
FOR UPDATE
USING (public.is_tenant_member(tenant_id))
WITH CHECK (public.is_tenant_member(tenant_id));

CREATE POLICY credit_violation_templates_tenant_delete
ON public.credit_violation_templates
FOR DELETE
USING (public.is_tenant_member(tenant_id));

-- credit_documents_vault
CREATE POLICY credit_documents_vault_tenant_select
ON public.credit_documents_vault
FOR SELECT
USING (public.is_tenant_member(tenant_id));

CREATE POLICY credit_documents_vault_tenant_insert
ON public.credit_documents_vault
FOR INSERT
WITH CHECK (public.is_tenant_member(tenant_id));

CREATE POLICY credit_documents_vault_tenant_update
ON public.credit_documents_vault
FOR UPDATE
USING (public.is_tenant_member(tenant_id))
WITH CHECK (public.is_tenant_member(tenant_id));

CREATE POLICY credit_documents_vault_tenant_delete
ON public.credit_documents_vault
FOR DELETE
USING (public.is_tenant_member(tenant_id));

-- credit_attorney_reviews (tenant via joined case)
CREATE POLICY credit_attorney_reviews_tenant_select
ON public.credit_attorney_reviews
FOR SELECT
USING (
  EXISTS (
    SELECT 1
    FROM public.credit_dispute_cases_v2 c
    JOIN public.wolf_tenant_users tu
      ON tu.tenant_id = c.tenant_id
     AND tu.user_id = auth.uid()
     AND tu.status = 'active'
    WHERE c.id = credit_attorney_reviews.case_id
  )
);

CREATE POLICY credit_attorney_reviews_tenant_insert
ON public.credit_attorney_reviews
FOR INSERT
WITH CHECK (
  EXISTS (
    SELECT 1
    FROM public.credit_dispute_cases_v2 c
    JOIN public.wolf_tenant_users tu
      ON tu.tenant_id = c.tenant_id
     AND tu.user_id = auth.uid()
     AND tu.status = 'active'
    WHERE c.id = credit_attorney_reviews.case_id
  )
);

CREATE POLICY credit_attorney_reviews_tenant_update
ON public.credit_attorney_reviews
FOR UPDATE
USING (
  EXISTS (
    SELECT 1
    FROM public.credit_dispute_cases_v2 c
    JOIN public.wolf_tenant_users tu
      ON tu.tenant_id = c.tenant_id
     AND tu.user_id = auth.uid()
     AND tu.status = 'active'
    WHERE c.id = credit_attorney_reviews.case_id
  )
)
WITH CHECK (
  EXISTS (
    SELECT 1
    FROM public.credit_dispute_cases_v2 c
    JOIN public.wolf_tenant_users tu
      ON tu.tenant_id = c.tenant_id
     AND tu.user_id = auth.uid()
     AND tu.status = 'active'
    WHERE c.id = credit_attorney_reviews.case_id
  )
);

------------------------------------------------------------
-- RLS: Funder & underwriting sync
------------------------------------------------------------

ALTER TABLE public.funder_pipeline ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.bank_verification_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.syndication_partners ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.deal_protection_logs ENABLE ROW LEVEL SECURITY;

CREATE POLICY funder_pipeline_tenant_select
ON public.funder_pipeline
FOR SELECT
USING (public.is_tenant_member(tenant_id));

CREATE POLICY funder_pipeline_tenant_write
ON public.funder_pipeline
FOR INSERT, UPDATE, DELETE
USING (public.is_tenant_member(tenant_id))
WITH CHECK (public.is_tenant_member(tenant_id));

CREATE POLICY bank_verification_sessions_tenant_select
ON public.bank_verification_sessions
FOR SELECT
USING (public.is_tenant_member(tenant_id));

CREATE POLICY bank_verification_sessions_tenant_write
ON public.bank_verification_sessions
FOR INSERT, UPDATE, DELETE
USING (public.is_tenant_member(tenant_id))
WITH CHECK (public.is_tenant_member(tenant_id));

CREATE POLICY syndication_partners_tenant_select
ON public.syndication_partners
FOR SELECT
USING (public.is_tenant_member(tenant_id));

CREATE POLICY syndication_partners_tenant_write
ON public.syndication_partners
FOR INSERT, UPDATE, DELETE
USING (public.is_tenant_member(tenant_id))
WITH CHECK (public.is_tenant_member(tenant_id));

CREATE POLICY deal_protection_logs_tenant_select
ON public.deal_protection_logs
FOR SELECT
USING (public.is_tenant_member(tenant_id));

CREATE POLICY deal_protection_logs_tenant_insert
ON public.deal_protection_logs
FOR INSERT
WITH CHECK (public.is_tenant_member(tenant_id));

------------------------------------------------------------
-- RLS: SuperOwner GOD mode + Autopilot
------------------------------------------------------------

ALTER TABLE public.god_mode_alerts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.system_anomalies ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.autopilot_actions ENABLE ROW LEVEL SECURITY;

-- god_mode_alerts – tenant members see their own, SuperOwner sees all
CREATE POLICY god_mode_alerts_tenant_select
ON public.god_mode_alerts
FOR SELECT
USING (
  (tenant_id IS NOT NULL AND public.is_tenant_member(tenant_id))
  OR public.is_superowner()
);

CREATE POLICY god_mode_alerts_tenant_write
ON public.god_mode_alerts
FOR INSERT, UPDATE, DELETE
USING (
  (tenant_id IS NOT NULL AND public.is_tenant_member(tenant_id))
  OR public.is_superowner()
)
WITH CHECK (
  (tenant_id IS NOT NULL AND public.is_tenant_member(tenant_id))
  OR public.is_superowner()
);

-- system_anomalies – SuperOwner/system only
CREATE POLICY system_anomalies_superowner_select
ON public.system_anomalies
FOR SELECT
USING (public.is_superowner());

CREATE POLICY system_anomalies_superowner_write
ON public.system_anomalies
FOR INSERT, UPDATE, DELETE
USING (public.is_superowner())
WITH CHECK (public.is_superowner());

-- autopilot_actions – tenant members see their own; SuperOwner sees all
CREATE POLICY autopilot_actions_tenant_select
ON public.autopilot_actions
FOR SELECT
USING (
  (tenant_id IS NOT NULL AND public.is_tenant_member(tenant_id))
  OR public.is_superowner()
);

CREATE POLICY autopilot_actions_tenant_write
ON public.autopilot_actions
FOR INSERT, UPDATE, DELETE
USING (
  (tenant_id IS NOT NULL AND public.is_tenant_member(tenant_id))
  OR public.is_superowner()
)
WITH CHECK (
  (tenant_id IS NOT NULL AND public.is_tenant_member(tenant_id))
  OR public.is_superowner()
);

------------------------------------------------------------
-- RLS: Merchant processing layer
------------------------------------------------------------

ALTER TABLE public.merchant_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.processing_vendor_rates ENABLE ROW LEVEL SECURITY;

-- merchant_profiles – tenant-scoped
CREATE POLICY merchant_profiles_tenant_select
ON public.merchant_profiles
FOR SELECT
USING (public.is_tenant_member(tenant_id));

CREATE POLICY merchant_profiles_tenant_write
ON public.merchant_profiles
FOR INSERT, UPDATE, DELETE
USING (public.is_tenant_member(tenant_id))
WITH CHECK (public.is_tenant_member(tenant_id));

-- processing_vendor_rates – SuperOwner manage; tenants never hit directly,
-- they go through edge functions that run as service_role.
CREATE POLICY processing_vendor_rates_superowner_select
ON public.processing_vendor_rates
FOR SELECT
USING (public.is_superowner());

CREATE POLICY processing_vendor_rates_superowner_write
ON public.processing_vendor_rates
FOR INSERT, UPDATE, DELETE
USING (public.is_superowner())
WITH CHECK (public.is_superowner());

------------------------------------------------------------
-- Feature flag seeds
------------------------------------------------------------

INSERT INTO public.wolf_feature_flags (feature_key, description)
VALUES
  ('ff_lead_engine_v3',        'Lead Engine V3 tenant pipelines'),
  ('ff_creditfix_v2',          'Credit Fix Back Office V2'),
  ('ff_funder_pipeline_v2',    'Funder + underwriting pipeline V2'),
  ('ff_anti_backdoor_v1',      'Anti-backdoor monitoring rules'),
  ('ff_syndication_core',      'Syndication partners core'),
  ('ff_god_autopilot',         'SuperOwner GOD Mode + Autopilot'),
  ('ff_processing_layer_v1',   'Merchant processing layer')
ON CONFLICT (feature_key) DO NOTHING;

-- Per-tenant feature flags – default FALSE (disabled) for all tenants.
INSERT INTO public.wolf_tenant_feature_flags (tenant_id, feature_key, is_enabled)
SELECT t.id, f.feature_key, FALSE
FROM public.wolf_tenants t
CROSS JOIN public.wolf_feature_flags f
WHERE f.feature_key IN (
  'ff_lead_engine_v3',
  'ff_creditfix_v2',
  'ff_funder_pipeline_v2',
  'ff_anti_backdoor_v1',
  'ff_syndication_core',
  'ff_god_autopilot',
  'ff_processing_layer_v1'
)
ON CONFLICT (tenant_id, feature_key) DO NOTHING;

