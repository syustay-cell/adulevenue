-- =================================================================
-- MIGRATION: 20251206033341_ed347fd6-e58c-47b1-b150-367d5a446fe7.sql
-- =================================================================
-- Part 1.1: Complete Foundation Tables
-- Section 1: AI Feature Flags / Kill Switch
CREATE TABLE IF NOT EXISTS public.wolf_ai_limits (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  feature_key text UNIQUE NOT NULL,
  is_enabled boolean NOT NULL DEFAULT true,
  force_template_mode boolean NOT NULL DEFAULT false,
  max_daily_calls integer DEFAULT NULL,
  current_daily_calls integer NOT NULL DEFAULT 0,
  last_reset_at timestamptz DEFAULT now(),
  provider_override text DEFAULT NULL, -- 'openai', 'gateway', 'manual'
  description text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.wolf_ai_limits ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins can manage AI limits"
  ON public.wolf_ai_limits FOR ALL
  USING (has_role(auth.uid(), 'admin'::public.app_role));

CREATE POLICY "Workers can view AI limits"
  ON public.wolf_ai_limits FOR SELECT
  USING (has_role(auth.uid(), 'worker'::public.app_role) OR has_role(auth.uid(), 'credit_repair_specialist'::public.app_role));

-- Section 2: Document Templates Engine
CREATE TABLE IF NOT EXISTS public.document_templates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  category text NOT NULL, -- 'credit_letter', 'contract', 'outreach_email', 'sms_script', 'onboarding'
  name text NOT NULL,
  description text,
  template_body text NOT NULL, -- Contains {{placeholder}} variables
  placeholders jsonb NOT NULL DEFAULT '[]'::jsonb, -- Array of placeholder names
  is_active boolean NOT NULL DEFAULT true,
  version integer NOT NULL DEFAULT 1,
  created_by uuid REFERENCES auth.users(id),
  updated_by uuid REFERENCES auth.users(id),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.document_templates ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins can manage document templates"
  ON public.document_templates FOR ALL
  USING (has_role(auth.uid(), 'admin'::public.app_role));

CREATE POLICY "Workers can view active templates"
  ON public.document_templates FOR SELECT
  USING (is_active = true AND (has_role(auth.uid(), 'worker'::public.app_role) OR has_role(auth.uid(), 'credit_repair_specialist'::public.app_role)));

-- Section 3: Provider Health Status
CREATE TABLE IF NOT EXISTS public.wolf_provider_health (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  provider_key text UNIQUE NOT NULL, -- 'openai', 'gateway', 'twilio_sms', 'resend_email', 'database'
  status text NOT NULL DEFAULT 'unknown', -- 'online', 'offline', 'degraded', 'unknown'
  last_check_at timestamptz,
  last_success_at timestamptz,
  last_error text,
  error_count_today integer NOT NULL DEFAULT 0,
  success_count_today integer NOT NULL DEFAULT 0,
  avg_latency_ms integer,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.wolf_provider_health ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins can manage provider health"
  ON public.wolf_provider_health FOR ALL
  USING (has_role(auth.uid(), 'admin'::public.app_role));

CREATE POLICY "Workers can view provider health"
  ON public.wolf_provider_health FOR SELECT
  USING (has_role(auth.uid(), 'worker'::public.app_role) OR has_role(auth.uid(), 'credit_repair_specialist'::public.app_role));

-- Section 4: Session Management (Timeout tracking)
CREATE TABLE IF NOT EXISTS public.wolf_session_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  setting_key text UNIQUE NOT NULL,
  setting_value jsonb NOT NULL,
  description text,
  updated_by uuid,
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.wolf_session_settings ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins can manage session settings"
  ON public.wolf_session_settings FOR ALL
  USING (has_role(auth.uid(), 'admin'::public.app_role));

-- Section 5: Lead Scoring Model
CREATE TABLE IF NOT EXISTS public.lead_scoring_rules (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  rule_name text NOT NULL,
  field_name text NOT NULL, -- 'monthly_revenue', 'time_in_business', 'credit_score', etc.
  operator text NOT NULL, -- 'gte', 'lte', 'eq', 'contains', 'between'
  threshold_value jsonb NOT NULL, -- Can be number, string, or range object
  score_adjustment integer NOT NULL, -- +10, -5, etc.
  is_active boolean NOT NULL DEFAULT true,
  priority integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.lead_scoring_rules ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins can manage scoring rules"
  ON public.lead_scoring_rules FOR ALL
  USING (has_role(auth.uid(), 'admin'::public.app_role));

CREATE POLICY "Workers can view scoring rules"
  ON public.lead_scoring_rules FOR SELECT
  USING (has_role(auth.uid(), 'worker'::public.app_role));

-- Section 6: Credit Fix Required Docs Checklist
CREATE TABLE IF NOT EXISTS public.credit_fix_required_docs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  doc_type text NOT NULL, -- 'id_front', 'id_back', 'utility_bill', 'credit_report', etc.
  display_name text NOT NULL,
  description text,
  is_required boolean NOT NULL DEFAULT true,
  stage_required text NOT NULL DEFAULT 'intake', -- Which stage this doc is required at
  sort_order integer NOT NULL DEFAULT 0,
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.credit_fix_required_docs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view required docs"
  ON public.credit_fix_required_docs FOR SELECT
  USING (is_active = true);

CREATE POLICY "Admins can manage required docs"
  ON public.credit_fix_required_docs FOR ALL
  USING (has_role(auth.uid(), 'admin'::public.app_role));

-- Section 7: Credit Fix Task Templates
CREATE TABLE IF NOT EXISTS public.credit_fix_task_templates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  stage text NOT NULL, -- 'intake', 'docs_pending', 'investigation', 'dispute', 'results', 'complete'
  task_name text NOT NULL,
  description text,
  default_due_days integer NOT NULL DEFAULT 3, -- Days from stage start
  is_required boolean NOT NULL DEFAULT false,
  sort_order integer NOT NULL DEFAULT 0,
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.credit_fix_task_templates ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view task templates"
  ON public.credit_fix_task_templates FOR SELECT
  USING (is_active = true);

CREATE POLICY "Admins can manage task templates"
  ON public.credit_fix_task_templates FOR ALL
  USING (has_role(auth.uid(), 'admin'::public.app_role));

-- Insert default AI feature limits
INSERT INTO public.wolf_ai_limits (feature_key, is_enabled, description) VALUES
  ('credit_repair_analyze', true, 'Credit report AI analysis'),
  ('credit_repair_strategy', true, 'Dispute strategy generation'),
  ('credit_repair_letters', true, 'Dispute letter generation'),
  ('ai_draft_outreach', true, 'Email/SMS AI drafting'),
  ('wolf_assistant', true, 'Wolf Assistant chat'),
  ('research_copilot', true, 'Lead research AI'),
  ('underwriting_analyze', true, 'Underwriting analysis')
ON CONFLICT (feature_key) DO NOTHING;

-- Insert default provider health entries
INSERT INTO public.wolf_provider_health (provider_key, status) VALUES
  ('openai', 'unknown'),
  ('gateway', 'unknown'),
  ('twilio_sms', 'unknown'),
  ('resend_email', 'unknown'),
  ('database', 'unknown')
ON CONFLICT (provider_key) DO NOTHING;

-- Insert default session settings
INSERT INTO public.wolf_session_settings (setting_key, setting_value, description) VALUES
  ('session_timeout_minutes', '30'::jsonb, 'Inactivity timeout in minutes'),
  ('max_concurrent_sessions', '3'::jsonb, 'Max concurrent sessions per user'),
  ('force_logout_on_role_change', 'true'::jsonb, 'Force logout when user role changes')
ON CONFLICT (setting_key) DO NOTHING;

-- Insert default credit fix required docs
INSERT INTO public.credit_fix_required_docs (doc_type, display_name, description, stage_required, sort_order) VALUES
  ('id_front', 'Government ID (Front)', 'Front of drivers license or state ID', 'intake', 1),
  ('id_back', 'Government ID (Back)', 'Back of drivers license or state ID', 'intake', 2),
  ('utility_bill', 'Proof of Address', 'Recent utility bill or bank statement showing address', 'intake', 3),
  ('ssn_card', 'Social Security Card', 'Photo of SSN card', 'intake', 4),
  ('credit_report', 'Full Credit Report', '3-bureau credit report from all bureaus', 'docs_pending', 5)
ON CONFLICT DO NOTHING;

-- Insert default credit fix task templates
INSERT INTO public.credit_fix_task_templates (stage, task_name, description, default_due_days, is_required, sort_order) VALUES
  ('intake', 'Initial client call', 'Introduction call with client to review case', 1, true, 1),
  ('intake', 'Request documents', 'Send document request to client', 1, true, 2),
  ('docs_pending', 'Follow up on missing docs', 'Contact client about missing documents', 3, false, 1),
  ('investigation', 'Analyze credit report', 'Run AI analysis on credit report', 1, true, 1),
  ('investigation', 'Generate dispute strategy', 'Create dispute strategy using AI', 2, true, 2),
  ('dispute', 'Draft dispute letters', 'Generate dispute letters for bureaus', 1, true, 1),
  ('dispute', 'Send disputes', 'Mail or submit disputes electronically', 2, true, 2),
  ('results', 'Review bureau responses', 'Analyze responses from credit bureaus', 1, true, 1),
  ('results', 'Update client on results', 'Call client to discuss results', 2, true, 2),
  ('complete', 'Final review call', 'Review final credit status with client', 1, true, 1)
ON CONFLICT DO NOTHING;

-- Add triggers for updated_at
CREATE TRIGGER update_wolf_ai_limits_updated_at
  BEFORE UPDATE ON public.wolf_ai_limits
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_document_templates_updated_at
  BEFORE UPDATE ON public.document_templates
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_wolf_provider_health_updated_at
  BEFORE UPDATE ON public.wolf_provider_health
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_lead_scoring_rules_updated_at
  BEFORE UPDATE ON public.lead_scoring_rules
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- =================================================================
-- MIGRATION: 20251206035737_d376680e-ab03-4ab1-89a6-0eb09083cea5.sql
-- =================================================================
-- Part 1.1 Fix: Add provider_name column and seed data

-- Add missing column to wolf_provider_health
ALTER TABLE wolf_provider_health ADD COLUMN IF NOT EXISTS provider_name text;

-- Seed provider health entries (without provider_name in insert)
INSERT INTO wolf_provider_health (provider_key, status)
VALUES 
  ('openai', 'unknown'),
  ('gateway', 'unknown'),
  ('twilio_sms', 'unknown'),
  ('resend_email', 'unknown')
ON CONFLICT (provider_key) DO NOTHING;

-- Update provider names
UPDATE wolf_provider_health SET provider_name = 'OpenAI' WHERE provider_key = 'openai';
UPDATE wolf_provider_health SET provider_name = 'AI Gateway' WHERE provider_key = 'gateway';
UPDATE wolf_provider_health SET provider_name = 'Twilio SMS' WHERE provider_key = 'twilio_sms';
UPDATE wolf_provider_health SET provider_name = 'Resend Email' WHERE provider_key = 'resend_email';

-- =================================================================
-- MIGRATION: 20251206040706_e24ba4e7-0dc9-4ed6-9d8c-b9c7f61b2574.sql
-- =================================================================
-- Create wolf_documents storage bucket
INSERT INTO storage.buckets (id, name, public, file_size_limit)
VALUES ('wolf_documents', 'wolf_documents', false, 52428800)
ON CONFLICT (id) DO NOTHING;

-- Storage policies for wolf_documents bucket
CREATE POLICY "Authenticated users can upload to wolf_documents" 
ON storage.objects FOR INSERT 
TO authenticated 
WITH CHECK (bucket_id = 'wolf_documents');

CREATE POLICY "Authenticated users can read wolf_documents" 
ON storage.objects FOR SELECT 
TO authenticated 
USING (bucket_id = 'wolf_documents');

CREATE POLICY "Admins can delete from wolf_documents" 
ON storage.objects FOR DELETE 
TO authenticated 
USING (
  bucket_id = 'wolf_documents' 
  AND EXISTS (
    SELECT 1 FROM profiles 
    WHERE profiles.id = auth.uid() 
    AND profiles.role = 'admin'
  )
);

-- =================================================================
-- MIGRATION: 20251206042622_6bd394c4-726d-4864-983b-abde637bac91.sql
-- =================================================================
-- Part 2: Complete Schema - Create tables in correct order

-- 1.1 Extend leads table (columns that may not exist yet)
ALTER TABLE leads
  ADD COLUMN IF NOT EXISTS source text,
  ADD COLUMN IF NOT EXISTS campaign text,
  ADD COLUMN IF NOT EXISTS ad_group text,
  ADD COLUMN IF NOT EXISTS creative_id text,
  ADD COLUMN IF NOT EXISTS lock_reason text,
  ADD COLUMN IF NOT EXISTS eco_mode boolean DEFAULT false;

-- 1.3 lead_list_members junction table
CREATE TABLE IF NOT EXISTS lead_list_members (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_list_id uuid REFERENCES lead_lists(id) ON DELETE CASCADE,
  lead_id uuid REFERENCES leads(id) ON DELETE CASCADE,
  position integer,
  status text DEFAULT 'new',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE lead_list_members ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "lead_list_members_admin" ON lead_list_members;
CREATE POLICY "lead_list_members_admin" ON lead_list_members
  FOR ALL USING (has_role(auth.uid(), 'admin'::public.app_role));

DROP POLICY IF EXISTS "lead_list_members_worker" ON lead_list_members;
CREATE POLICY "lead_list_members_worker" ON lead_list_members
  FOR SELECT USING (has_role(auth.uid(), 'worker'::public.app_role));

-- 1.4 worker_assignments table
CREATE TABLE IF NOT EXISTS worker_assignments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  worker_id uuid NOT NULL,
  lead_id uuid REFERENCES leads(id),
  case_id uuid,
  task_type text NOT NULL,
  title text NOT NULL,
  description text,
  due_at timestamptz,
  completed_at timestamptz,
  status text DEFAULT 'pending',
  created_at timestamptz DEFAULT now(),
  created_by uuid
);

ALTER TABLE worker_assignments ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "worker_can_see_own_assignments" ON worker_assignments;
CREATE POLICY "worker_can_see_own_assignments" ON worker_assignments
  FOR SELECT USING (auth.uid() = worker_id);

DROP POLICY IF EXISTS "worker_can_update_own_assignments" ON worker_assignments;
CREATE POLICY "worker_can_update_own_assignments" ON worker_assignments
  FOR UPDATE USING (auth.uid() = worker_id);

DROP POLICY IF EXISTS "admin_manage_assignments" ON worker_assignments;
CREATE POLICY "admin_manage_assignments" ON worker_assignments
  FOR ALL USING (has_role(auth.uid(), 'admin'::public.app_role));

-- 1.5.1 Create iso_partners table if not exists
CREATE TABLE IF NOT EXISTS iso_partners (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid,
  company_name text,
  contact_name text,
  email text,
  phone text,
  default_commission_rate numeric DEFAULT 0.08,
  status text DEFAULT 'active',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE iso_partners ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "admin_manage_iso_partners" ON iso_partners;
CREATE POLICY "admin_manage_iso_partners" ON iso_partners
  FOR ALL USING (has_role(auth.uid(), 'admin'::public.app_role));

DROP POLICY IF EXISTS "iso_view_self" ON iso_partners;
CREATE POLICY "iso_view_self" ON iso_partners
  FOR SELECT USING (user_id = auth.uid());

-- 1.5.2 Extend fast_track_applications (only add columns that don't exist)
ALTER TABLE fast_track_applications
  ADD COLUMN IF NOT EXISTS iso_partner_id uuid,
  ADD COLUMN IF NOT EXISTS source text,
  ADD COLUMN IF NOT EXISTS campaign text,
  ADD COLUMN IF NOT EXISTS ad_group text,
  ADD COLUMN IF NOT EXISTS creative_id text;

-- 1.5.3 funded_deals table
CREATE TABLE IF NOT EXISTS funded_deals (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  application_id uuid NOT NULL,
  iso_partner_id uuid,
  funded_amount numeric,
  product_type text,
  funded_date date,
  funder_id uuid,
  commission_rate numeric,
  commission_amount numeric,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE funded_deals ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "admin_manage_funded_deals" ON funded_deals;
CREATE POLICY "admin_manage_funded_deals" ON funded_deals
  FOR ALL USING (has_role(auth.uid(), 'admin'::public.app_role));

DROP POLICY IF EXISTS "iso_view_own_funded_deals" ON funded_deals;
CREATE POLICY "iso_view_own_funded_deals" ON funded_deals
  FOR SELECT USING (
    iso_partner_id IN (
      SELECT id FROM iso_partners WHERE user_id = auth.uid()
    )
  );

-- 1.6.2 ABG project funding links
CREATE TABLE IF NOT EXISTS abg_project_funding_links (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id uuid,
  funded_deal_id uuid,
  application_id uuid,
  link_type text DEFAULT 'primary',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE abg_project_funding_links ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "admin_manage_abg_links" ON abg_project_funding_links;
CREATE POLICY "admin_manage_abg_links" ON abg_project_funding_links
  FOR ALL USING (has_role(auth.uid(), 'admin'::public.app_role));

-- 1.7 Outreach sequences tables
CREATE TABLE IF NOT EXISTS outreach_sequences (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text,
  channel text DEFAULT 'mixed',
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE outreach_sequences ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "admin_manage_sequences" ON outreach_sequences;
CREATE POLICY "admin_manage_sequences" ON outreach_sequences
  FOR ALL USING (has_role(auth.uid(), 'admin'::public.app_role));

DROP POLICY IF EXISTS "worker_view_sequences" ON outreach_sequences;
CREATE POLICY "worker_view_sequences" ON outreach_sequences
  FOR SELECT USING (is_active = true AND has_role(auth.uid(), 'worker'::public.app_role));

CREATE TABLE IF NOT EXISTS outreach_steps (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  sequence_id uuid REFERENCES outreach_sequences(id) ON DELETE CASCADE,
  step_order integer NOT NULL,
  delay_hours integer NOT NULL,
  channel text NOT NULL,
  template_name text,
  use_ai boolean DEFAULT false,
  eco_mode_only boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE outreach_steps ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "admin_manage_steps" ON outreach_steps;
CREATE POLICY "admin_manage_steps" ON outreach_steps
  FOR ALL USING (has_role(auth.uid(), 'admin'::public.app_role));

DROP POLICY IF EXISTS "worker_view_steps" ON outreach_steps;
CREATE POLICY "worker_view_steps" ON outreach_steps
  FOR SELECT USING (has_role(auth.uid(), 'worker'::public.app_role));

CREATE TABLE IF NOT EXISTS outreach_enrollments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id uuid REFERENCES leads(id),
  sequence_id uuid REFERENCES outreach_sequences(id),
  worker_id uuid,
  status text DEFAULT 'active',
  started_at timestamptz DEFAULT now(),
  last_step_sent integer DEFAULT 0,
  last_sent_at timestamptz
);

ALTER TABLE outreach_enrollments ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "admin_manage_enrollments" ON outreach_enrollments;
CREATE POLICY "admin_manage_enrollments" ON outreach_enrollments
  FOR ALL USING (has_role(auth.uid(), 'admin'::public.app_role));

DROP POLICY IF EXISTS "worker_manage_own_enrollments" ON outreach_enrollments;
CREATE POLICY "worker_manage_own_enrollments" ON outreach_enrollments
  FOR ALL USING (worker_id = auth.uid());

CREATE TABLE IF NOT EXISTS outreach_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  enrollment_id uuid REFERENCES outreach_enrollments(id) ON DELETE CASCADE,
  step_id uuid REFERENCES outreach_steps(id) ON DELETE SET NULL,
  event_type text,
  meta jsonb,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE outreach_events ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "admin_view_outreach_events" ON outreach_events;
CREATE POLICY "admin_view_outreach_events" ON outreach_events
  FOR SELECT USING (has_role(auth.uid(), 'admin'::public.app_role));

DROP POLICY IF EXISTS "worker_view_own_outreach_events" ON outreach_events;
CREATE POLICY "worker_view_own_outreach_events" ON outreach_events
  FOR SELECT USING (
    enrollment_id IN (
      SELECT id FROM outreach_enrollments WHERE worker_id = auth.uid()
    )
  );

-- iso_commissions table (if not exists)
CREATE TABLE IF NOT EXISTS iso_commissions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  iso_partner_id uuid REFERENCES iso_partners(id),
  funded_deal_id uuid REFERENCES funded_deals(id),
  amount numeric,
  status text DEFAULT 'pending',
  paid_at timestamptz,
  notes text,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE iso_commissions ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "admin_manage_iso_commissions" ON iso_commissions;
CREATE POLICY "admin_manage_iso_commissions" ON iso_commissions
  FOR ALL USING (has_role(auth.uid(), 'admin'::public.app_role));

DROP POLICY IF EXISTS "iso_view_own_commissions" ON iso_commissions;
CREATE POLICY "iso_view_own_commissions" ON iso_commissions
  FOR SELECT USING (
    iso_partner_id IN (
      SELECT id FROM iso_partners WHERE user_id = auth.uid()
    )
  );

-- =================================================================
-- MIGRATION: 20251206054759_4ec8f2c2-0f41-4565-98b4-924b499c2a4f.sql
-- =================================================================

-- Create wolf_documents table for Document Library
CREATE TABLE IF NOT EXISTS public.wolf_documents (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  file_name TEXT NOT NULL,
  storage_path TEXT NOT NULL,
  file_type TEXT NOT NULL DEFAULT 'pdf',
  category TEXT NOT NULL DEFAULT 'other',
  tags TEXT[] DEFAULT '{}',
  is_template BOOLEAN NOT NULL DEFAULT false,
  is_active BOOLEAN NOT NULL DEFAULT true,
  description TEXT,
  uploaded_by UUID,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Create wf_ai_cost_summary table for AI cost tracking
CREATE TABLE IF NOT EXISTS public.wf_ai_cost_summary (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  period_start DATE NOT NULL,
  period_end DATE NOT NULL,
  feature TEXT NOT NULL,
  provider TEXT NOT NULL,
  total_calls INTEGER NOT NULL DEFAULT 0,
  total_input_chars BIGINT DEFAULT 0,
  total_output_chars BIGINT DEFAULT 0,
  total_estimated_tokens BIGINT DEFAULT 0,
  total_estimated_cost_usd NUMERIC(10, 4) DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(period_start, period_end, feature, provider)
);

-- Enable RLS on both tables
ALTER TABLE public.wolf_documents ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.wf_ai_cost_summary ENABLE ROW LEVEL SECURITY;

-- RLS for wolf_documents: Admin can manage all, workers can read active docs
CREATE POLICY "wolf_documents_admin_all" ON public.wolf_documents
  FOR ALL USING (has_role(auth.uid(), 'admin'::public.app_role));

CREATE POLICY "wolf_documents_worker_select" ON public.wolf_documents
  FOR SELECT USING (
    is_active = true AND (
      has_role(auth.uid(), 'worker'::public.app_role) OR 
      has_role(auth.uid(), 'credit_repair_specialist'::public.app_role) OR
      has_role(auth.uid(), 'underwriter'::public.app_role)
    )
  );

-- RLS for wf_ai_cost_summary: Admin only
CREATE POLICY "wf_ai_cost_summary_admin" ON public.wf_ai_cost_summary
  FOR ALL USING (has_role(auth.uid(), 'admin'::public.app_role));

-- Add index for performance
CREATE INDEX IF NOT EXISTS idx_wolf_documents_category ON public.wolf_documents(category);
CREATE INDEX IF NOT EXISTS idx_wolf_documents_active ON public.wolf_documents(is_active);
CREATE INDEX IF NOT EXISTS idx_wf_ai_cost_summary_period ON public.wf_ai_cost_summary(period_start, period_end);

-- =================================================================
-- MIGRATION: 20251206070336_1764648c-242d-4c26-b2eb-2fbd74cd9ba8.sql
-- =================================================================
-- EPIC 3.1 – Complete missing outreach tables and columns

-- Add missing columns to outreach_sequences
ALTER TABLE public.outreach_sequences 
ADD COLUMN IF NOT EXISTS steps jsonb NOT NULL DEFAULT '[]'::jsonb,
ADD COLUMN IF NOT EXISTS created_by uuid REFERENCES auth.users(id),
ADD COLUMN IF NOT EXISTS updated_by uuid REFERENCES auth.users(id),
ADD COLUMN IF NOT EXISTS updated_at timestamptz NOT NULL DEFAULT now();

-- Create outreach_inboxes table
CREATE TABLE IF NOT EXISTS public.outreach_inboxes (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  label           text NOT NULL,
  email_address   text NOT NULL,
  provider        text NOT NULL,
  status          text NOT NULL DEFAULT 'active' CHECK (status IN ('active','paused','disabled')),
  created_by      uuid REFERENCES auth.users(id),
  created_at      timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.outreach_inboxes ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "outreach_inboxes_admin_select" ON public.outreach_inboxes;
CREATE POLICY "outreach_inboxes_admin_select"
  ON public.outreach_inboxes FOR SELECT
  USING (has_role(auth.uid(), 'admin'::public.app_role) OR has_role(auth.uid(), 'credit_repair_specialist'::public.app_role));

DROP POLICY IF EXISTS "outreach_inboxes_admin_insert" ON public.outreach_inboxes;
CREATE POLICY "outreach_inboxes_admin_insert"
  ON public.outreach_inboxes FOR INSERT
  WITH CHECK (has_role(auth.uid(), 'admin'::public.app_role));

DROP POLICY IF EXISTS "outreach_inboxes_admin_update" ON public.outreach_inboxes;
CREATE POLICY "outreach_inboxes_admin_update"
  ON public.outreach_inboxes FOR UPDATE
  USING (has_role(auth.uid(), 'admin'::public.app_role));

DROP POLICY IF EXISTS "outreach_inboxes_admin_delete" ON public.outreach_inboxes;
CREATE POLICY "outreach_inboxes_admin_delete"
  ON public.outreach_inboxes FOR DELETE
  USING (has_role(auth.uid(), 'admin'::public.app_role));

-- Create outreach_campaigns table
CREATE TABLE IF NOT EXISTS public.outreach_campaigns (
  id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name             text NOT NULL,
  lead_list_id     uuid REFERENCES public.lead_lists(id) ON DELETE CASCADE,
  sequence_id      uuid NOT NULL REFERENCES public.outreach_sequences(id),
  inbox_id         uuid REFERENCES public.outreach_inboxes(id),
  sender_identity  text NOT NULL,
  status           text NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','running','paused','completed')),
  daily_send_cap   integer NOT NULL DEFAULT 200,
  timezone         text NOT NULL DEFAULT 'America/New_York',
  created_by       uuid REFERENCES auth.users(id),
  updated_by       uuid REFERENCES auth.users(id),
  created_at       timestamptz NOT NULL DEFAULT now(),
  updated_at       timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.outreach_campaigns ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "outreach_campaigns_admin_select" ON public.outreach_campaigns;
CREATE POLICY "outreach_campaigns_admin_select"
  ON public.outreach_campaigns FOR SELECT
  USING (has_role(auth.uid(), 'admin'::public.app_role) OR has_role(auth.uid(), 'credit_repair_specialist'::public.app_role));

DROP POLICY IF EXISTS "outreach_campaigns_admin_insert" ON public.outreach_campaigns;
CREATE POLICY "outreach_campaigns_admin_insert"
  ON public.outreach_campaigns FOR INSERT
  WITH CHECK (has_role(auth.uid(), 'admin'::public.app_role));

DROP POLICY IF EXISTS "outreach_campaigns_admin_update" ON public.outreach_campaigns;
CREATE POLICY "outreach_campaigns_admin_update"
  ON public.outreach_campaigns FOR UPDATE
  USING (has_role(auth.uid(), 'admin'::public.app_role));

DROP POLICY IF EXISTS "outreach_campaigns_admin_delete" ON public.outreach_campaigns;
CREATE POLICY "outreach_campaigns_admin_delete"
  ON public.outreach_campaigns FOR DELETE
  USING (has_role(auth.uid(), 'admin'::public.app_role));

-- Add missing columns to outreach_events (upgrade from existing schema)
ALTER TABLE public.outreach_events
ADD COLUMN IF NOT EXISTS campaign_id uuid REFERENCES public.outreach_campaigns(id) ON DELETE CASCADE,
ADD COLUMN IF NOT EXISTS lead_id uuid REFERENCES public.leads(id) ON DELETE CASCADE,
ADD COLUMN IF NOT EXISTS worker_id uuid REFERENCES auth.users(id),
ADD COLUMN IF NOT EXISTS sequence_step integer,
ADD COLUMN IF NOT EXISTS metadata jsonb DEFAULT '{}'::jsonb;

-- Create indexes
CREATE INDEX IF NOT EXISTS outreach_events_campaign_idx ON public.outreach_events(campaign_id);
CREATE INDEX IF NOT EXISTS outreach_events_lead_idx ON public.outreach_events(lead_id);
CREATE INDEX IF NOT EXISTS outreach_events_type_idx ON public.outreach_events(event_type);

-- Update RLS policies on outreach_events
DROP POLICY IF EXISTS "outreach_events_admin_select" ON public.outreach_events;
CREATE POLICY "outreach_events_admin_select"
  ON public.outreach_events FOR SELECT
  USING (has_role(auth.uid(), 'admin'::public.app_role) OR has_role(auth.uid(), 'credit_repair_specialist'::public.app_role));

DROP POLICY IF EXISTS "outreach_events_system_insert" ON public.outreach_events;
CREATE POLICY "outreach_events_system_insert"
  ON public.outreach_events FOR INSERT
  WITH CHECK (true);

DROP POLICY IF EXISTS "outreach_events_system_update" ON public.outreach_events;
CREATE POLICY "outreach_events_system_update"
  ON public.outreach_events FOR UPDATE
  USING (true);

DROP POLICY IF EXISTS "outreach_events_worker_read_own" ON public.outreach_events;
CREATE POLICY "outreach_events_worker_read_own"
  ON public.outreach_events FOR SELECT
  USING (worker_id = auth.uid());

-- Update outreach_sequences RLS
DROP POLICY IF EXISTS "outreach_sequences_admin_select" ON public.outreach_sequences;
CREATE POLICY "outreach_sequences_admin_select"
  ON public.outreach_sequences FOR SELECT
  USING (has_role(auth.uid(), 'admin'::public.app_role) OR has_role(auth.uid(), 'credit_repair_specialist'::public.app_role));

DROP POLICY IF EXISTS "outreach_sequences_admin_insert" ON public.outreach_sequences;
CREATE POLICY "outreach_sequences_admin_insert"
  ON public.outreach_sequences FOR INSERT
  WITH CHECK (has_role(auth.uid(), 'admin'::public.app_role));

DROP POLICY IF EXISTS "outreach_sequences_admin_update" ON public.outreach_sequences;
CREATE POLICY "outreach_sequences_admin_update"
  ON public.outreach_sequences FOR UPDATE
  USING (has_role(auth.uid(), 'admin'::public.app_role));

DROP POLICY IF EXISTS "outreach_sequences_admin_delete" ON public.outreach_sequences;
CREATE POLICY "outreach_sequences_admin_delete"
  ON public.outreach_sequences FOR DELETE
  USING (has_role(auth.uid(), 'admin'::public.app_role));

-- =================================================================
-- MIGRATION: 20251206080408_8146dfae-0815-43e1-98ec-cb2a1a3c16f3.sql
-- =================================================================
-- EPIC 3.2 – Role & Permission Hardening (Fixed for app_role enum)

--------------------------------------------------------------------------------
-- 1) Helper function: has_role(target_role text) - cast to app_role enum
--------------------------------------------------------------------------------
create or replace function public.has_role(target_role text)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1
    from public.user_roles ur
    where ur.user_id = auth.uid()
      and ur.approved = true
      and ur.role = target_role::public.app_role
  );
$$;

comment on function public.has_role(text) is
  'Returns true if the current authenticated user has the given app role';

--------------------------------------------------------------------------------
-- 2) AI Reports – lock down to backend + approved roles
--------------------------------------------------------------------------------
alter table public.ai_reports enable row level security;

drop policy if exists "ai_reports_select_roles" on public.ai_reports;
drop policy if exists "ai_reports_insert_service" on public.ai_reports;
drop policy if exists "ai_reports_update_service" on public.ai_reports;

create policy "ai_reports_select_roles"
  on public.ai_reports
  for select
  using (
    auth.role() = 'service_role'
    or has_role('admin')
    or has_role('credit_repair_specialist')
    or has_role('underwriter')
  );

create policy "ai_reports_insert_service"
  on public.ai_reports
  for insert
  with check (auth.role() = 'service_role');

create policy "ai_reports_update_service"
  on public.ai_reports
  for update
  using (auth.role() = 'service_role')
  with check (auth.role() = 'service_role');

--------------------------------------------------------------------------------
-- 3) Outreach tables – tighten with has_role helper
--------------------------------------------------------------------------------

-- outreach_sequences
alter table public.outreach_sequences enable row level security;

drop policy if exists "outreach_sequences_admin_read" on public.outreach_sequences;
drop policy if exists "outreach_sequences_admin_write" on public.outreach_sequences;

create policy "outreach_sequences_admin_read"
  on public.outreach_sequences
  for select
  using (
    auth.role() = 'service_role'
    or has_role('admin')
    or has_role('credit_repair_specialist')
  );

create policy "outreach_sequences_admin_write"
  on public.outreach_sequences
  for all
  using (
    auth.role() = 'service_role'
    or has_role('admin')
    or has_role('credit_repair_specialist')
  )
  with check (
    auth.role() = 'service_role'
    or has_role('admin')
    or has_role('credit_repair_specialist')
  );

-- outreach_inboxes
alter table public.outreach_inboxes enable row level security;

drop policy if exists "outreach_inboxes_admin_read" on public.outreach_inboxes;
drop policy if exists "outreach_inboxes_admin_write" on public.outreach_inboxes;

create policy "outreach_inboxes_admin_read"
  on public.outreach_inboxes
  for select
  using (
    auth.role() = 'service_role'
    or has_role('admin')
    or has_role('credit_repair_specialist')
  );

create policy "outreach_inboxes_admin_write"
  on public.outreach_inboxes
  for all
  using (
    auth.role() = 'service_role'
    or has_role('admin')
    or has_role('credit_repair_specialist')
  )
  with check (
    auth.role() = 'service_role'
    or has_role('admin')
    or has_role('credit_repair_specialist')
  );

-- outreach_campaigns
alter table public.outreach_campaigns enable row level security;

drop policy if exists "outreach_campaigns_admin_read" on public.outreach_campaigns;
drop policy if exists "outreach_campaigns_admin_write" on public.outreach_campaigns;

create policy "outreach_campaigns_admin_read"
  on public.outreach_campaigns
  for select
  using (
    auth.role() = 'service_role'
    or has_role('admin')
    or has_role('credit_repair_specialist')
  );

create policy "outreach_campaigns_admin_write"
  on public.outreach_campaigns
  for all
  using (
    auth.role() = 'service_role'
    or has_role('admin')
    or has_role('credit_repair_specialist')
  )
  with check (
    auth.role() = 'service_role'
    or has_role('admin')
    or has_role('credit_repair_specialist')
  );

-- outreach_events
alter table public.outreach_events enable row level security;

drop policy if exists "outreach_events_admin_read" on public.outreach_events;
drop policy if exists "outreach_events_service_insert" on public.outreach_events;
drop policy if exists "outreach_events_service_update" on public.outreach_events;

create policy "outreach_events_admin_read"
  on public.outreach_events
  for select
  using (
    auth.role() = 'service_role'
    or has_role('admin')
    or has_role('credit_repair_specialist')
  );

create policy "outreach_events_service_insert"
  on public.outreach_events
  for insert
  with check (auth.role() = 'service_role');

create policy "outreach_events_service_update"
  on public.outreach_events
  for update
  using (auth.role() = 'service_role')
  with check (auth.role() = 'service_role');

-- =================================================================
-- MIGRATION: 20251206083041_44ed2b6c-f96d-4e49-a68f-09bf6363c0e9.sql
-- =================================================================
-- Commission Engine v1.1 Final Migration
-- Add remaining columns that weren't created in first migration

-- 1. Add wolf_folder_label and source_platform_label to leads
ALTER TABLE public.leads 
ADD COLUMN IF NOT EXISTS source_platform_label text,
ADD COLUMN IF NOT EXISTS wolf_folder_label text;

-- 2. Add commission_debug_json to deals
ALTER TABLE public.deals 
ADD COLUMN IF NOT EXISTS commission_debug_json jsonb;

-- 3. Add referral_code to profiles
ALTER TABLE public.profiles 
ADD COLUMN IF NOT EXISTS referral_code text;

-- 4. Create index on profiles.referral_code for fast lookups
CREATE INDEX IF NOT EXISTS idx_profiles_referral_code ON public.profiles(referral_code) WHERE referral_code IS NOT NULL;

-- 5. Backfill wolf_folder_label for existing leads
UPDATE public.leads 
SET wolf_folder_label = 'Wolf ' || to_char(created_at, 'FMMonth YYYY')
WHERE wolf_folder_label IS NULL AND created_at IS NOT NULL;

-- 6. Add comments
COMMENT ON COLUMN public.leads.source_platform_label IS 'Human-readable platform: Instagram, Facebook, TikTok, etc.';
COMMENT ON COLUMN public.leads.wolf_folder_label IS 'Pattern: Wolf {Month} {Year} - for grouping leads';
COMMENT ON COLUMN public.deals.commission_debug_json IS 'Full audit snapshot: context, rules, payouts, calculated_at, version';
COMMENT ON COLUMN public.profiles.referral_code IS 'Unique referral code for worker referral tracking';

