-- =================================================================
-- MIGRATION: 20251202022651_1cc61510-b04c-405e-ab25-eed692579568.sql
-- =================================================================
-- ============================================
-- DIALER V3: Start/Stop, Locking, Share/Split
-- ============================================

-- 1. Extend leads table with locking + session fields
ALTER TABLE leads
  ADD COLUMN IF NOT EXISTS owner_id uuid REFERENCES auth.users(id),
  ADD COLUMN IF NOT EXISTS lock_expires_at timestamptz,
  ADD COLUMN IF NOT EXISTS last_called_at timestamptz,
  ADD COLUMN IF NOT EXISTS call_attempts integer NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS last_call_outcome text,
  ADD COLUMN IF NOT EXISTS last_called_by uuid REFERENCES auth.users(id);

-- Update status column to allow new values if not already present
-- (keeping existing statuses, adding new ones)

CREATE INDEX IF NOT EXISTS idx_leads_status_owner ON leads (status, owner_id);
CREATE INDEX IF NOT EXISTS idx_leads_lock_expires ON leads (lock_expires_at);

-- 2. Create deals table for commission tracking
CREATE TABLE IF NOT EXISTS deals (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id uuid REFERENCES leads(id) ON DELETE SET NULL,
  client_email text,
  amount_funded numeric,
  status text NOT NULL DEFAULT 'open',
  
  primary_closer_id uuid REFERENCES auth.users(id),
  secondary_closer_id uuid REFERENCES auth.users(id),
  split_primary_pct integer DEFAULT 100,
  split_secondary_pct integer DEFAULT 0,
  
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_deals_lead_id ON deals (lead_id);
CREATE INDEX IF NOT EXISTS idx_deals_primary_closer ON deals (primary_closer_id);

-- 3. Create lead share/release requests table
CREATE TABLE IF NOT EXISTS lead_share_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id uuid NOT NULL REFERENCES leads(id) ON DELETE CASCADE,
  from_worker_id uuid NOT NULL REFERENCES auth.users(id),
  to_worker_id uuid NOT NULL REFERENCES auth.users(id),
  type text NOT NULL CHECK (type IN ('release', 'split_50_50')),
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'accepted', 'rejected')),
  message text,
  created_at timestamptz DEFAULT now(),
  responded_at timestamptz
);

CREATE INDEX IF NOT EXISTS idx_share_requests_lead ON lead_share_requests(lead_id);
CREATE INDEX IF NOT EXISTS idx_share_requests_to_worker ON lead_share_requests(to_worker_id);
CREATE INDEX IF NOT EXISTS idx_share_requests_from_worker ON lead_share_requests(from_worker_id);

-- 4. Create call sessions table (for analytics)
CREATE TABLE IF NOT EXISTS call_sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  worker_id uuid NOT NULL REFERENCES auth.users(id),
  started_at timestamptz NOT NULL DEFAULT now(),
  ended_at timestamptz,
  is_active boolean NOT NULL DEFAULT true
);

CREATE INDEX IF NOT EXISTS idx_call_sessions_worker_active ON call_sessions(worker_id, is_active);

-- ============================================
-- RPC FUNCTIONS
-- ============================================

-- RPC: start_call_session
CREATE OR REPLACE FUNCTION start_call_session(p_worker_id uuid)
RETURNS call_sessions AS $$
DECLARE
  new_session call_sessions;
BEGIN
  -- Close any active sessions first
  UPDATE call_sessions
     SET is_active = false, ended_at = now()
   WHERE worker_id = p_worker_id
     AND is_active = true;

  -- Create new session
  INSERT INTO call_sessions(worker_id)
  VALUES (p_worker_id)
  RETURNING * INTO new_session;

  RETURN new_session;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

-- RPC: stop_call_session
CREATE OR REPLACE FUNCTION stop_call_session(p_worker_id uuid)
RETURNS void AS $$
BEGIN
  UPDATE call_sessions
     SET is_active = false, ended_at = now()
   WHERE worker_id = p_worker_id
     AND is_active = true;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

-- RPC: get_next_lead (with row locking to prevent collisions)
CREATE OR REPLACE FUNCTION get_next_lead(p_worker_id uuid)
RETURNS leads AS $$
DECLARE
  result leads;
  lock_days integer := 7;
BEGIN
  -- Free expired locks
  UPDATE leads
     SET owner_id = NULL, lock_expires_at = NULL
   WHERE lock_expires_at IS NOT NULL
     AND lock_expires_at < now();

  -- Get next lead (prefer worker's own leads, then unassigned)
  SELECT *
    INTO result
    FROM leads
   WHERE status IN ('new', 'assigned', 'no_answer')
     AND (owner_id IS NULL OR owner_id = p_worker_id)
   ORDER BY
     (owner_id = p_worker_id) DESC,  -- prioritize own leads
     ai_score DESC NULLS LAST,
     created_at ASC
   FOR UPDATE SKIP LOCKED
   LIMIT 1;

  IF NOT FOUND THEN
    RETURN NULL;
  END IF;

  -- Lock the lead to this worker
  UPDATE leads
     SET owner_id = p_worker_id,
         lock_expires_at = now() + (lock_days || ' days')::interval
   WHERE id = result.id;

  -- Return updated lead
  SELECT * INTO result FROM leads WHERE id = result.id;

  RETURN result;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

-- RPC: record_call_outcome
CREATE OR REPLACE FUNCTION record_call_outcome(
  p_lead_id uuid,
  p_worker_id uuid,
  p_outcome text
)
RETURNS leads AS $$
DECLARE
  lead_row leads;
BEGIN
  UPDATE leads
     SET last_called_at = now(),
         call_attempts = call_attempts + 1,
         last_call_outcome = p_outcome,
         last_called_by = p_worker_id,
         owner_id = p_worker_id,
         lock_expires_at = now() + interval '7 days',
         status =
           CASE p_outcome
             WHEN 'interested'      THEN 'interested'
             WHEN 'no_answer'       THEN status  -- stays as is
             WHEN 'not_interested'  THEN 'dead'
             WHEN 'bad_number'      THEN 'dead'
             ELSE status
           END
   WHERE id = p_lead_id
   RETURNING * INTO lead_row;

  RETURN lead_row;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

-- RPC: request_lead_share (for release or 50/50 split)
CREATE OR REPLACE FUNCTION request_lead_share(
  p_lead_id uuid,
  p_from_worker_id uuid,
  p_type text,
  p_message text DEFAULT NULL
)
RETURNS lead_share_requests AS $$
DECLARE
  current_owner uuid;
  req lead_share_requests;
BEGIN
  SELECT owner_id INTO current_owner FROM leads WHERE id = p_lead_id;

  IF current_owner IS NULL THEN
    RAISE EXCEPTION 'Lead has no owner';
  END IF;

  IF current_owner = p_from_worker_id THEN
    RAISE EXCEPTION 'Cannot request share from yourself';
  END IF;

  INSERT INTO lead_share_requests(
    lead_id, from_worker_id, to_worker_id, type, message
  )
  VALUES (p_lead_id, p_from_worker_id, current_owner, p_type, p_message)
  RETURNING * INTO req;

  RETURN req;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

-- RPC: respond_lead_share (owner accepts/rejects)
CREATE OR REPLACE FUNCTION respond_lead_share(
  p_request_id uuid,
  p_owner_id uuid,
  p_decision text
)
RETURNS void AS $$
DECLARE
  req lead_share_requests;
BEGIN
  SELECT * INTO req
    FROM lead_share_requests
   WHERE id = p_request_id
     AND to_worker_id = p_owner_id
     AND status = 'pending';

  IF NOT FOUND THEN
    RAISE EXCEPTION 'Request not found or already responded';
  END IF;

  -- Update request status
  UPDATE lead_share_requests
     SET status = p_decision,
         responded_at = now()
   WHERE id = p_request_id;

  -- Apply the decision
  IF p_decision = 'accepted' THEN
    IF req.type = 'release' THEN
      -- Transfer ownership
      UPDATE leads
         SET owner_id = req.from_worker_id,
             lock_expires_at = now() + interval '7 days'
       WHERE id = req.lead_id;

    ELSIF req.type = 'split_50_50' THEN
      -- Create/update deal with 50/50 split
      INSERT INTO deals (lead_id, primary_closer_id, split_primary_pct, secondary_closer_id, split_secondary_pct)
      VALUES (req.lead_id, p_owner_id, 50, req.from_worker_id, 50)
      ON CONFLICT (lead_id) DO UPDATE
        SET secondary_closer_id = req.from_worker_id,
            split_primary_pct = 50,
            split_secondary_pct = 50;
    END IF;
  END IF;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

-- ============================================
-- RLS POLICIES
-- ============================================

-- Enable RLS
ALTER TABLE deals ENABLE ROW LEVEL SECURITY;
ALTER TABLE lead_share_requests ENABLE ROW LEVEL SECURITY;
ALTER TABLE call_sessions ENABLE ROW LEVEL SECURITY;

-- Deals: admins see all, workers see their own
DROP POLICY IF EXISTS "Admins can manage all deals" ON deals;
CREATE POLICY "Admins can manage all deals" ON deals
  FOR ALL USING (has_role(auth.uid(), 'admin'::public.app_role));

DROP POLICY IF EXISTS "Workers can view their deals" ON deals;
CREATE POLICY "Workers can view their deals" ON deals
  FOR SELECT USING (
    primary_closer_id = auth.uid() OR
    secondary_closer_id = auth.uid()
  );

-- Share requests: involved parties + admins
DROP POLICY IF EXISTS "Workers can view share requests" ON lead_share_requests;
CREATE POLICY "Workers can view share requests" ON lead_share_requests
  FOR SELECT USING (
    from_worker_id = auth.uid() OR
    to_worker_id = auth.uid() OR
    has_role(auth.uid(), 'admin'::public.app_role)
  );

DROP POLICY IF EXISTS "Workers can create share requests" ON lead_share_requests;
CREATE POLICY "Workers can create share requests" ON lead_share_requests
  FOR INSERT WITH CHECK (from_worker_id = auth.uid());

-- Call sessions: workers see own, admins see all
DROP POLICY IF EXISTS "Workers can view own sessions" ON call_sessions;
CREATE POLICY "Workers can view own sessions" ON call_sessions
  FOR SELECT USING (
    worker_id = auth.uid() OR
    has_role(auth.uid(), 'admin'::public.app_role)
  );

-- =================================================================
-- MIGRATION: 20251202023354_74ed41a7-583c-40d4-9da7-c1f0570d6080.sql
-- =================================================================
-- Create view for share requests with lead and user details
CREATE OR REPLACE VIEW lead_share_requests_view AS
SELECT
  r.*,
  jsonb_build_object(
    'id', l.id,
    'full_name', l.full_name,
    'business_name', l.business_name,
    'email', l.email,
    'phone', l.phone
  ) AS lead,
  u.email AS from_user_email
FROM lead_share_requests r
JOIN leads l ON l.id = r.lead_id
LEFT JOIN auth.users u ON u.id = r.from_worker_id;

-- =================================================================
-- MIGRATION: 20251202023414_cb0dc6ce-95ea-4e00-bd5b-cd1df09b4c3d.sql
-- =================================================================
-- Add RLS to lead_share_requests_view
ALTER VIEW lead_share_requests_view SET (security_invoker = true);

-- Grant access to authenticated users
GRANT SELECT ON lead_share_requests_view TO authenticated;

-- =================================================================
-- MIGRATION: 20251202030149_26b102c0-4907-435b-84e7-8d10fbb3ade5.sql
-- =================================================================
-- Dialer V3: Enhanced leads table for attempt tracking and automation
ALTER TABLE leads 
ADD COLUMN IF NOT EXISTS attempt_count INTEGER DEFAULT 0,
ADD COLUMN IF NOT EXISTS attempt_history JSONB DEFAULT '[]'::jsonb,
ADD COLUMN IF NOT EXISTS next_attempt_at TIMESTAMPTZ,
ADD COLUMN IF NOT EXISTS last_called_by UUID,
ADD COLUMN IF NOT EXISTS interested_at TIMESTAMPTZ,
ADD COLUMN IF NOT EXISTS app_sent_at TIMESTAMPTZ,
ADD COLUMN IF NOT EXISTS funded_at TIMESTAMPTZ,
ADD COLUMN IF NOT EXISTS follow_up_at TIMESTAMPTZ;

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_leads_next_attempt ON leads(next_attempt_at) WHERE next_attempt_at IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_leads_attempt_count ON leads(attempt_count);
CREATE INDEX IF NOT EXISTS idx_leads_last_called_by ON leads(last_called_by);

-- Commissions table for 50/50 splits
CREATE TABLE IF NOT EXISTS commissions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id UUID REFERENCES leads(id) ON DELETE CASCADE,
  owner_id UUID REFERENCES auth.users(id),
  partner_id UUID REFERENCES auth.users(id),
  split NUMERIC DEFAULT 50,
  created_at TIMESTAMPTZ DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_commissions_lead ON commissions(lead_id);
CREATE INDEX IF NOT EXISTS idx_commissions_owner ON commissions(owner_id);
CREATE INDEX IF NOT EXISTS idx_commissions_partner ON commissions(partner_id);

-- RLS for commissions
ALTER TABLE commissions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Workers can view their commissions"
ON commissions FOR SELECT
USING (
  auth.uid() = owner_id 
  OR auth.uid() = partner_id 
  OR has_role(auth.uid(), 'admin'::public.app_role)
);

-- Enhanced record_call_outcome with attempt tracking and cadence logic
CREATE OR REPLACE FUNCTION record_call_outcome(
  p_lead_id UUID,
  p_worker_id UUID,
  p_outcome TEXT
)
RETURNS leads
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  lead_row leads;
  new_attempt INTEGER;
  next_attempt TIMESTAMPTZ;
BEGIN
  SELECT * INTO lead_row FROM leads WHERE id = p_lead_id;
  new_attempt := COALESCE(lead_row.attempt_count, 0) + 1;

  -- Calculate next attempt time based on cadence
  IF p_outcome = 'no_answer' THEN
    IF new_attempt = 1 THEN
      next_attempt := now() + INTERVAL '1 hour';
    ELSIF new_attempt = 2 THEN
      next_attempt := now() + INTERVAL '4 hours';
    ELSIF new_attempt = 3 THEN
      next_attempt := now() + INTERVAL '1 day';
    ELSIF new_attempt = 4 THEN
      next_attempt := now() + INTERVAL '2 days';
    ELSE
      next_attempt := now() + INTERVAL '7 days'; -- cooldown
    END IF;
  END IF;

  -- Update lead with outcome
  UPDATE leads
  SET 
    last_called_at = now(),
    last_called_by = p_worker_id,
    attempt_count = CASE 
      WHEN p_outcome = 'no_answer' THEN new_attempt
      ELSE attempt_count 
    END,
    attempt_history = COALESCE(attempt_history, '[]'::jsonb) || jsonb_build_object(
      'time', now(),
      'worker_id', p_worker_id,
      'outcome', p_outcome,
      'attempt', new_attempt
    ),
    next_attempt_at = CASE 
      WHEN p_outcome = 'no_answer' THEN next_attempt
      ELSE NULL 
    END,
    lock_expires_at = CASE
      WHEN p_outcome = 'interested' THEN now() + INTERVAL '7 days'
      ELSE lock_expires_at
    END,
    status = CASE
      WHEN p_outcome = 'interested' THEN 'interested'
      WHEN p_outcome = 'bad_number' THEN 'dead'
      WHEN p_outcome = 'not_interested' THEN 'dead'
      WHEN p_outcome = 'no_answer' AND new_attempt >= 5 THEN 'no_answer'
      ELSE status
    END,
    interested_at = CASE 
      WHEN p_outcome = 'interested' THEN now() 
      ELSE interested_at 
    END
  WHERE id = p_lead_id
  RETURNING * INTO lead_row;

  RETURN lead_row;
END;
$$;

-- Update respond_lead_share to handle 50/50 splits
CREATE OR REPLACE FUNCTION respond_lead_share(
  p_request_id UUID,
  p_owner_id UUID,
  p_decision TEXT
)
RETURNS VOID
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  req lead_share_requests;
BEGIN
  SELECT * INTO req
  FROM lead_share_requests
  WHERE id = p_request_id
    AND to_worker_id = p_owner_id
    AND status = 'pending';

  IF NOT FOUND THEN
    RAISE EXCEPTION 'Request not found or already responded';
  END IF;

  -- Update request status
  UPDATE lead_share_requests
  SET status = p_decision,
      responded_at = now()
  WHERE id = p_request_id;

  -- Apply the decision
  IF p_decision = 'accepted' THEN
    IF req.type = 'release' THEN
      -- Transfer ownership
      UPDATE leads
      SET owner_id = req.from_worker_id,
          lock_expires_at = now() + INTERVAL '7 days'
      WHERE id = req.lead_id;
    ELSIF req.type = 'split_50_50' THEN
      -- Create commission split
      INSERT INTO commissions (lead_id, owner_id, partner_id, split)
      VALUES (req.lead_id, req.to_worker_id, req.from_worker_id, 50);
      
      -- Keep original owner but mark as shared
      UPDATE leads
      SET lock_expires_at = now() + INTERVAL '7 days'
      WHERE id = req.lead_id;
    END IF;
  END IF;
END;
$$;

-- =================================================================
-- MIGRATION: 20251202031808_bcf48dc8-754b-48ee-a826-41120b31d071.sql
-- =================================================================
-- ============================================
-- DIALER V3 - COMPLETE DATABASE SCHEMA
-- ============================================

-- 1. Ensure leads table has all required AI + locking fields
ALTER TABLE leads
ADD COLUMN IF NOT EXISTS ai_score integer,
ADD COLUMN IF NOT EXISTS ai_priority text,
ADD COLUMN IF NOT EXISTS ai_recommended_path text,
ADD COLUMN IF NOT EXISTS ai_risk_flags text[],
ADD COLUMN IF NOT EXISTS ai_last_evaluated_at timestamptz,
ADD COLUMN IF NOT EXISTS locked_by uuid,
ADD COLUMN IF NOT EXISTS locked_by_email text,
ADD COLUMN IF NOT EXISTS locked_until timestamptz;

-- Update status column to use proper default if needed
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'leads' AND column_name = 'status'
  ) THEN
    ALTER TABLE leads ADD COLUMN status text NOT NULL DEFAULT 'new';
  END IF;
END $$;

-- 2. Create lead_call_attempts table
CREATE TABLE IF NOT EXISTS lead_call_attempts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id uuid NOT NULL REFERENCES leads(id) ON DELETE CASCADE,
  agent_id uuid NOT NULL,
  agent_email text NOT NULL,
  outcome text NOT NULL, -- 'no_answer' | 'voicemail' | 'answered' | 'bad_number'
  duration_seconds integer,
  notes text,
  created_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_lead_call_attempts_lead_id ON lead_call_attempts(lead_id);
CREATE INDEX IF NOT EXISTS idx_lead_call_attempts_agent_id ON lead_call_attempts(agent_id);

-- 3. Create lead_locks table
CREATE TABLE IF NOT EXISTS lead_locks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id uuid NOT NULL REFERENCES leads(id) ON DELETE CASCADE,
  primary_agent_id uuid NOT NULL,
  primary_agent_email text NOT NULL,
  co_agent_id uuid,
  co_agent_email text,
  lock_status text NOT NULL DEFAULT 'active', -- active | released | expired
  lock_expires_at timestamptz NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_lead_locks_lead_id ON lead_locks(lead_id);
CREATE INDEX IF NOT EXISTS idx_lead_locks_primary_agent ON lead_locks(primary_agent_id);
CREATE INDEX IF NOT EXISTS idx_lead_locks_status ON lead_locks(lock_status);

-- 4. Create lead_lock_requests table
CREATE TABLE IF NOT EXISTS lead_lock_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id uuid NOT NULL REFERENCES leads(id) ON DELETE CASCADE,
  from_agent_id uuid NOT NULL,
  from_agent_email text NOT NULL,
  to_agent_id uuid NOT NULL,
  to_agent_email text NOT NULL,
  request_type text NOT NULL, -- 'release' | 'split_50_50'
  status text NOT NULL DEFAULT 'pending', -- pending | approved | rejected
  message text,
  created_at timestamptz DEFAULT now(),
  resolved_at timestamptz
);

CREATE INDEX IF NOT EXISTS idx_lead_lock_requests_to_agent ON lead_lock_requests(to_agent_id);
CREATE INDEX IF NOT EXISTS idx_lead_lock_requests_status ON lead_lock_requests(status);

-- ============================================
-- RLS POLICIES
-- ============================================

-- lead_call_attempts: agents see their own, admins see all
ALTER TABLE lead_call_attempts ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Agents can view own call attempts" ON lead_call_attempts;
CREATE POLICY "Agents can view own call attempts" ON lead_call_attempts
  FOR SELECT USING (agent_id = auth.uid() OR has_role(auth.uid(), 'admin'::public.app_role));

DROP POLICY IF EXISTS "Agents can insert own call attempts" ON lead_call_attempts;
CREATE POLICY "Agents can insert own call attempts" ON lead_call_attempts
  FOR INSERT WITH CHECK (agent_id = auth.uid());

-- lead_locks: agents see their own, admins see all
ALTER TABLE lead_locks ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Agents can view own locks" ON lead_locks;
CREATE POLICY "Agents can view own locks" ON lead_locks
  FOR SELECT USING (
    primary_agent_id = auth.uid() 
    OR co_agent_id = auth.uid() 
    OR has_role(auth.uid(), 'admin'::public.app_role)
  );

DROP POLICY IF EXISTS "Agents can create locks" ON lead_locks;
CREATE POLICY "Agents can create locks" ON lead_locks
  FOR INSERT WITH CHECK (primary_agent_id = auth.uid());

-- lead_lock_requests: requestor and recipient can view
ALTER TABLE lead_lock_requests ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Agents can view own requests" ON lead_lock_requests;
CREATE POLICY "Agents can view own requests" ON lead_lock_requests
  FOR SELECT USING (
    from_agent_id = auth.uid() 
    OR to_agent_id = auth.uid() 
    OR has_role(auth.uid(), 'admin'::public.app_role)
  );

DROP POLICY IF EXISTS "Agents can create requests" ON lead_lock_requests;
CREATE POLICY "Agents can create requests" ON lead_lock_requests
  FOR INSERT WITH CHECK (from_agent_id = auth.uid());

DROP POLICY IF EXISTS "Agents can update own requests" ON lead_lock_requests;
CREATE POLICY "Agents can update own requests" ON lead_lock_requests
  FOR UPDATE USING (to_agent_id = auth.uid() OR has_role(auth.uid(), 'admin'::public.app_role));

-- ============================================
-- RPC FUNCTIONS
-- ============================================

-- 1. Get next lead for agent
CREATE OR REPLACE FUNCTION get_next_lead_for_agent(p_agent_id uuid DEFAULT NULL)
RETURNS leads
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_lead leads;
  v_agent_id uuid;
BEGIN
  v_agent_id := COALESCE(p_agent_id, auth.uid());
  
  SELECT l.*
  INTO v_lead
  FROM leads l
  LEFT JOIN lead_locks ll
    ON ll.lead_id = l.id
   AND ll.lock_status = 'active'
   AND ll.lock_expires_at > now()
  WHERE
    (l.status IN ('new', 'assigned', 'no_answer'))
    AND (
      ll.id IS NULL
      OR ll.primary_agent_id = v_agent_id
      OR ll.co_agent_id = v_agent_id
    )
  ORDER BY
    l.ai_score DESC NULLS LAST,
    l.priority_score DESC NULLS LAST,
    l.created_at ASC
  LIMIT 1;

  RETURN v_lead;
END;
$$;

-- 2. Record call attempt
CREATE OR REPLACE FUNCTION record_call_attempt(
  p_lead_id uuid,
  p_outcome text,
  p_duration_seconds integer DEFAULT NULL,
  p_notes text DEFAULT NULL
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_user_id uuid;
  v_email text;
BEGIN
  v_user_id := auth.uid();
  v_email := (SELECT email FROM auth.users WHERE id = v_user_id);

  INSERT INTO lead_call_attempts (
    lead_id,
    agent_id,
    agent_email,
    outcome,
    duration_seconds,
    notes
  ) VALUES (
    p_lead_id,
    v_user_id,
    v_email,
    p_outcome,
    p_duration_seconds,
    p_notes
  );

  -- Update lead status and call tracking
  UPDATE leads
  SET 
    call_attempts = call_attempts + 1,
    last_called_at = now(),
    last_called_by = v_user_id,
    last_call_outcome = p_outcome,
    status = CASE
      WHEN p_outcome = 'answered' THEN 'interested'
      WHEN p_outcome = 'bad_number' THEN 'dead'
      WHEN p_outcome = 'not_interested' THEN 'dead'
      ELSE status
    END,
    updated_at = now()
  WHERE id = p_lead_id;
END;
$$;

-- 3. Lock lead for agent
CREATE OR REPLACE FUNCTION lock_lead_for_agent(
  p_lead_id uuid,
  p_days integer DEFAULT 7
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_user_id uuid := auth.uid();
  v_email text;
  v_lock_expires timestamptz;
BEGIN
  v_email := (SELECT email FROM auth.users WHERE id = v_user_id);
  v_lock_expires := now() + (p_days || ' days')::interval;

  -- Create lock record
  INSERT INTO lead_locks (
    lead_id,
    primary_agent_id,
    primary_agent_email,
    lock_status,
    lock_expires_at
  ) VALUES (
    p_lead_id,
    v_user_id,
    v_email,
    'active',
    v_lock_expires
  );

  -- Update lead table
  UPDATE leads
  SET
    status = 'interested',
    locked_by = v_user_id,
    locked_by_email = v_email,
    locked_until = v_lock_expires,
    owner_id = v_user_id,
    lock_expires_at = v_lock_expires,
    updated_at = now()
  WHERE id = p_lead_id;
END;
$$;

-- 4. Request lead release or split
CREATE OR REPLACE FUNCTION request_lead_release_or_split(
  p_lead_id uuid,
  p_request_type text,
  p_message text DEFAULT NULL
)
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_requestor_id uuid := auth.uid();
  v_requestor_email text;
  v_lock lead_locks;
  v_request_id uuid;
BEGIN
  v_requestor_email := (SELECT email FROM auth.users WHERE id = v_requestor_id);

  -- Get active lock
  SELECT * INTO v_lock
  FROM lead_locks
  WHERE lead_id = p_lead_id
    AND lock_status = 'active'
    AND lock_expires_at > now()
  ORDER BY created_at DESC
  LIMIT 1;

  IF v_lock IS NULL THEN
    RAISE EXCEPTION 'No active lock for lead %', p_lead_id;
  END IF;

  -- Create request
  INSERT INTO lead_lock_requests (
    lead_id,
    from_agent_id,
    from_agent_email,
    to_agent_id,
    to_agent_email,
    request_type,
    message
  ) VALUES (
    p_lead_id,
    v_requestor_id,
    v_requestor_email,
    v_lock.primary_agent_id,
    v_lock.primary_agent_email,
    p_request_type,
    p_message
  )
  RETURNING id INTO v_request_id;

  RETURN v_request_id;
END;
$$;

-- 5. Respond to lead request
CREATE OR REPLACE FUNCTION respond_to_lead_request(
  p_request_id uuid,
  p_decision text -- 'approved' | 'rejected'
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_user_id uuid := auth.uid();
  v_request lead_lock_requests;
  v_lock lead_locks;
BEGIN
  -- Get request
  SELECT * INTO v_request
  FROM lead_lock_requests
  WHERE id = p_request_id
    AND to_agent_id = v_user_id
    AND status = 'pending';

  IF v_request IS NULL THEN
    RAISE EXCEPTION 'Request not found or already resolved';
  END IF;

  -- Update request status
  UPDATE lead_lock_requests
  SET status = p_decision, resolved_at = now()
  WHERE id = p_request_id;

  -- If approved, handle the request type
  IF p_decision = 'approved' THEN
    IF v_request.request_type = 'release' THEN
      -- Transfer ownership
      UPDATE lead_locks
      SET 
        primary_agent_id = v_request.from_agent_id,
        primary_agent_email = v_request.from_agent_email,
        lock_expires_at = now() + INTERVAL '7 days',
        updated_at = now()
      WHERE lead_id = v_request.lead_id
        AND lock_status = 'active';

      UPDATE leads
      SET
        locked_by = v_request.from_agent_id,
        locked_by_email = v_request.from_agent_email,
        locked_until = now() + INTERVAL '7 days',
        owner_id = v_request.from_agent_id,
        updated_at = now()
      WHERE id = v_request.lead_id;

    ELSIF v_request.request_type = 'split_50_50' THEN
      -- Add co-agent to lock
      UPDATE lead_locks
      SET 
        co_agent_id = v_request.from_agent_id,
        co_agent_email = v_request.from_agent_email,
        updated_at = now()
      WHERE lead_id = v_request.lead_id
        AND lock_status = 'active';

      -- Create commission split record
      INSERT INTO commissions (lead_id, owner_id, partner_id, split)
      VALUES (v_request.lead_id, v_user_id, v_request.from_agent_id, 50);
    END IF;
  END IF;
END;
$$;

-- =================================================================
-- MIGRATION: 20251202032516_fc1c954b-d9c1-4b48-bda5-357c1b94651c.sql
-- =================================================================
-- ============================================
-- DIALER V3.1 - LEAD RELEASE & 50/50 SPLIT LOGIC
-- ============================================

-- Drop existing function to change return type
DROP FUNCTION IF EXISTS request_lead_release_or_split(uuid, text, text);
DROP FUNCTION IF EXISTS respond_to_lead_request(uuid, text);

-- 1. Get lead lock state (lock + pending requests for current user)
CREATE OR REPLACE FUNCTION get_lead_lock_state(p_lead_id uuid)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_lock lead_locks;
  v_user_id uuid := auth.uid();
  v_pending_requests jsonb := '[]'::jsonb;
BEGIN
  -- Get active lock
  SELECT *
  INTO v_lock
  FROM lead_locks
  WHERE lead_id = p_lead_id
    AND lock_status = 'active'
    AND lock_expires_at > now()
  ORDER BY created_at DESC
  LIMIT 1;

  -- Get pending requests relevant to current user
  SELECT COALESCE(jsonb_agg(to_jsonb(r)), '[]'::jsonb)
  INTO v_pending_requests
  FROM lead_lock_requests r
  WHERE r.lead_id = p_lead_id
    AND r.status = 'pending'
    AND (r.from_agent_id = v_user_id OR r.to_agent_id = v_user_id);

  RETURN jsonb_build_object(
    'lock', to_jsonb(v_lock),
    'pending_requests', v_pending_requests
  );
END;
$$;

-- 2. Request lead release or split (returns void now)
CREATE OR REPLACE FUNCTION request_lead_release_or_split(
  p_lead_id uuid,
  p_request_type text,
  p_message text DEFAULT NULL
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_requestor_id uuid := auth.uid();
  v_requestor_email text;
  v_lock lead_locks;
BEGIN
  IF p_request_type NOT IN ('release', 'split_50_50') THEN
    RAISE EXCEPTION 'Invalid request_type: %', p_request_type;
  END IF;

  v_requestor_email := (SELECT email FROM auth.users WHERE id = v_requestor_id);

  -- Get active lock
  SELECT * INTO v_lock
  FROM lead_locks
  WHERE lead_id = p_lead_id
    AND lock_status = 'active'
    AND lock_expires_at > now()
  ORDER BY created_at DESC
  LIMIT 1;

  IF v_lock IS NULL THEN
    RAISE EXCEPTION 'No active lock for lead %', p_lead_id;
  END IF;

  -- Prevent requesting to yourself
  IF v_lock.primary_agent_id = v_requestor_id THEN
    RAISE EXCEPTION 'You already own this lock';
  END IF;

  -- Check for duplicate pending requests
  IF EXISTS (
    SELECT 1 FROM lead_lock_requests
    WHERE lead_id = p_lead_id
      AND from_agent_id = v_requestor_id
      AND status = 'pending'
  ) THEN
    RAISE EXCEPTION 'You already have a pending request for this lead';
  END IF;

  -- Create request
  INSERT INTO lead_lock_requests (
    lead_id,
    from_agent_id,
    from_agent_email,
    to_agent_id,
    to_agent_email,
    request_type,
    message
  ) VALUES (
    p_lead_id,
    v_requestor_id,
    v_requestor_email,
    v_lock.primary_agent_id,
    v_lock.primary_agent_email,
    p_request_type,
    p_message
  );
END;
$$;

-- 3. Respond to lead lock request
CREATE OR REPLACE FUNCTION respond_to_lead_lock_request(
  p_request_id uuid,
  p_decision text -- 'approve' | 'reject'
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_user_id uuid := auth.uid();
  v_req lead_lock_requests;
  v_lock lead_locks;
BEGIN
  IF p_decision NOT IN ('approve', 'reject') THEN
    RAISE EXCEPTION 'Invalid decision: %', p_decision;
  END IF;

  -- Get request
  SELECT * INTO v_req
  FROM lead_lock_requests
  WHERE id = p_request_id;

  IF v_req IS NULL THEN
    RAISE EXCEPTION 'Request not found';
  END IF;

  -- Only the target (owner) can respond
  IF v_req.to_agent_id <> v_user_id THEN
    RAISE EXCEPTION 'Not authorized to respond to this request';
  END IF;

  IF v_req.status <> 'pending' THEN
    RAISE EXCEPTION 'Request already resolved';
  END IF;

  -- Get active lock
  SELECT * INTO v_lock
  FROM lead_locks
  WHERE lead_id = v_req.lead_id
    AND lock_status = 'active'
    AND lock_expires_at > now()
  ORDER BY created_at DESC
  LIMIT 1;

  IF v_lock IS NULL THEN
    RAISE EXCEPTION 'No active lock to modify';
  END IF;

  -- Update request status
  UPDATE lead_lock_requests
  SET 
    status = CASE WHEN p_decision = 'approve' THEN 'approved' ELSE 'rejected' END,
    resolved_at = now()
  WHERE id = p_request_id;

  IF p_decision = 'reject' THEN
    RETURN;
  END IF;

  -- Handle approved requests
  IF v_req.request_type = 'release' THEN
    -- Release lock - lead becomes available again
    UPDATE lead_locks
    SET 
      lock_status = 'released',
      updated_at = now()
    WHERE id = v_lock.id;

    UPDATE leads
    SET 
      status = 'new',
      locked_by = NULL,
      locked_by_email = NULL,
      locked_until = NULL,
      owner_id = NULL,
      lock_expires_at = NULL,
      updated_at = now()
    WHERE id = v_req.lead_id;

  ELSIF v_req.request_type = 'split_50_50' THEN
    -- Add co-agent to lock (50/50 split)
    UPDATE lead_locks
    SET 
      co_agent_id = v_req.from_agent_id,
      co_agent_email = v_req.from_agent_email,
      updated_at = now()
    WHERE id = v_lock.id;

    -- Create commission split record if commissions table exists
    IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'commissions') THEN
      INSERT INTO commissions (lead_id, owner_id, partner_id, split)
      VALUES (v_req.lead_id, v_user_id, v_req.from_agent_id, 50)
      ON CONFLICT DO NOTHING;
    END IF;
  END IF;
END;
$$;

-- =================================================================
-- MIGRATION: 20251202033349_aef34b29-f3bd-4dce-a4b2-e75e8716df13.sql
-- =================================================================
-- Create credit_public_checks table for eligibility screening
CREATE TABLE IF NOT EXISTS credit_public_checks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  case_id uuid REFERENCES credit_repair_cases(id) ON DELETE CASCADE,
  lead_id uuid REFERENCES leads(id) ON DELETE SET NULL,
  application_id uuid REFERENCES fast_track_applications(id) ON DELETE SET NULL,
  
  full_name text,
  email text,
  phone text,
  address text,
  city text,
  state text,
  postal_code text,
  
  -- Result classification
  eligibility_status text, -- 'funding_ready' | 'needs_credit_clean' | 'high_risk' | 'unknown'
  risk_flags text[],
  soft_score integer,
  notes jsonb DEFAULT '{}'::jsonb,
  
  created_by uuid,
  created_at timestamptz DEFAULT now()
);

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_credit_public_checks_case_id ON credit_public_checks(case_id);
CREATE INDEX IF NOT EXISTS idx_credit_public_checks_lead_id ON credit_public_checks(lead_id);
CREATE INDEX IF NOT EXISTS idx_credit_public_checks_created_at ON credit_public_checks(created_at DESC);

-- Add mirror fields to credit_repair_cases for quick display
ALTER TABLE credit_repair_cases
  ADD COLUMN IF NOT EXISTS last_eligibility_status text,
  ADD COLUMN IF NOT EXISTS last_soft_score integer,
  ADD COLUMN IF NOT EXISTS last_public_check_at timestamptz;

-- RLS policies for credit_public_checks
ALTER TABLE credit_public_checks ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Credit specialists can view checks for assigned cases"
  ON credit_public_checks FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM credit_repair_cases
      WHERE credit_repair_cases.id = credit_public_checks.case_id
      AND (
        (has_role(auth.uid(), 'credit_repair_specialist') AND credit_repair_cases.assigned_specialist_id = auth.uid())
        OR has_role(auth.uid(), 'admin')
      )
    )
  );

CREATE POLICY "System can insert credit public checks"
  ON credit_public_checks FOR INSERT
  WITH CHECK (true);

COMMENT ON TABLE credit_public_checks IS 'Stores public/soft credit eligibility screening results for audit trail';
COMMENT ON COLUMN credit_repair_cases.last_eligibility_status IS 'Mirror of latest eligibility status for quick display';
COMMENT ON COLUMN credit_repair_cases.last_soft_score IS 'Mirror of latest soft score (0-100) for quick display';
COMMENT ON COLUMN credit_repair_cases.last_public_check_at IS 'Timestamp of last eligibility check run';

