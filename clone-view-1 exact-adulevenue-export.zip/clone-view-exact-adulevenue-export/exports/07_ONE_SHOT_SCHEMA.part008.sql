-- =================================================================
-- MIGRATION: 20251204050444_0295dff6-3856-4694-96c8-bb6179778c8d.sql
-- =================================================================
-- Create wolf_events telemetry table
CREATE TABLE IF NOT EXISTS public.wolf_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  event_type text NOT NULL,
  event_ts timestamptz NOT NULL DEFAULT now(),
  severity text NOT NULL DEFAULT 'info',
  actor_type text,
  actor_id uuid,
  actor_email text,
  context_type text,
  context_id text,
  source text,
  payload jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);

-- Create indexes for efficient querying
CREATE INDEX IF NOT EXISTS idx_wolf_events_type_ts ON public.wolf_events (event_type, event_ts DESC);
CREATE INDEX IF NOT EXISTS idx_wolf_events_context ON public.wolf_events (context_type, context_id);
CREATE INDEX IF NOT EXISTS idx_wolf_events_severity_ts ON public.wolf_events (severity, event_ts DESC);

-- Enable RLS
ALTER TABLE public.wolf_events ENABLE ROW LEVEL SECURITY;

-- Admin-only read policy
CREATE POLICY "Admins can view wolf_events"
ON public.wolf_events
FOR SELECT
USING (
  EXISTS (
    SELECT 1 FROM public.user_roles ur
    WHERE ur.user_id = auth.uid()
      AND ur.role = 'admin'
      AND ur.approved = true
  )
);

-- System can insert events (service role)
CREATE POLICY "System can insert wolf_events"
ON public.wolf_events
FOR INSERT
WITH CHECK (true);

-- =================================================================
-- MIGRATION: 20251204053652_7fe5465a-373a-46ac-8b0e-6ba35e6f39b2.sql
-- =================================================================
-- V5: Underwriting & Legal Engines Tables

-- 1. Wolf Underwriting Cases
CREATE TABLE IF NOT EXISTS public.wolf_underwriting_cases (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  
  -- Context
  deal_id uuid NOT NULL,
  deal_room_id uuid REFERENCES public.deal_rooms(id),
  funder_id uuid REFERENCES public.funders(id),
  vault_id uuid,
  
  -- Run context
  run_ts timestamptz NOT NULL DEFAULT now(),
  run_by_type text NOT NULL CHECK (run_by_type IN ('system', 'admin', 'worker', 'iso')),
  run_by_id uuid,
  run_source text NOT NULL CHECK (run_source IN ('deal_room_button', 'admin_console', 'auto_recheck', 'api')),
  
  -- Input snapshot
  input_snapshot jsonb NOT NULL DEFAULT '{}'::jsonb,
  config_snapshot jsonb,
  
  -- Output
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'in_progress', 'completed', 'error')),
  decision text CHECK (decision IN ('approve', 'decline', 'review', 'unknown')),
  decision_reason text,
  risk_score numeric(5,2),
  risk_buckets jsonb,
  recommended_products jsonb,
  recommended_funders jsonb,
  flags jsonb,
  
  engine_version text,
  meta jsonb,
  
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_wuc_deal_id ON public.wolf_underwriting_cases(deal_id);
CREATE INDEX IF NOT EXISTS idx_wuc_run_ts ON public.wolf_underwriting_cases(run_ts DESC);
CREATE INDEX IF NOT EXISTS idx_wuc_status ON public.wolf_underwriting_cases(status);

-- 2. Wolf Legal Scans
CREATE TABLE IF NOT EXISTS public.wolf_legal_scans (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  
  -- Context
  deal_id uuid,
  deal_contract_id uuid NOT NULL,
  funder_id uuid REFERENCES public.funders(id),
  vault_id uuid,
  
  -- File info
  storage_path text NOT NULL,
  file_hash text,
  
  -- Run context
  run_ts timestamptz NOT NULL DEFAULT now(),
  run_by_type text NOT NULL CHECK (run_by_type IN ('system', 'admin', 'worker')),
  run_by_id uuid,
  run_source text NOT NULL CHECK (run_source IN ('admin_button', 'auto_scan_on_upload', 'recheck', 'api')),
  
  -- Output
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'in_progress', 'completed', 'error')),
  risk_score numeric(5,2),
  risk_level text CHECK (risk_level IN ('low', 'medium', 'high', 'critical')),
  issues jsonb,
  recommendations jsonb,
  clauses_summary jsonb,
  raw_output jsonb,
  
  engine_version text,
  meta jsonb,
  
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_wls_contract_id ON public.wolf_legal_scans(deal_contract_id);
CREATE INDEX IF NOT EXISTS idx_wls_run_ts ON public.wolf_legal_scans(run_ts DESC);
CREATE INDEX IF NOT EXISTS idx_wls_deal_id ON public.wolf_legal_scans(deal_id);

-- RLS Policies for wolf_underwriting_cases
ALTER TABLE public.wolf_underwriting_cases ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins can manage underwriting cases"
  ON public.wolf_underwriting_cases FOR ALL
  USING (has_role(auth.uid(), 'admin'::public.app_role));

CREATE POLICY "System can insert underwriting cases"
  ON public.wolf_underwriting_cases FOR INSERT
  WITH CHECK (true);

-- RLS Policies for wolf_legal_scans
ALTER TABLE public.wolf_legal_scans ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins can manage legal scans"
  ON public.wolf_legal_scans FOR ALL
  USING (has_role(auth.uid(), 'admin'::public.app_role));

CREATE POLICY "System can insert legal scans"
  ON public.wolf_legal_scans FOR INSERT
  WITH CHECK (true);

-- Triggers for updated_at
CREATE TRIGGER update_wolf_underwriting_cases_updated_at
  BEFORE UPDATE ON public.wolf_underwriting_cases
  FOR EACH ROW EXECUTE FUNCTION public.handle_updated_at();

CREATE TRIGGER update_wolf_legal_scans_updated_at
  BEFORE UPDATE ON public.wolf_legal_scans
  FOR EACH ROW EXECUTE FUNCTION public.handle_updated_at();

-- =================================================================
-- MIGRATION: 20251204054959_c70c03d7-de31-41dd-b541-c625e669b69f.sql
-- =================================================================
-- V5 Fix: Add run_ts columns to underwriting and legal scan tables
-- These columns are expected by the UI for ordering and display

-- Add run_ts to wolf_underwriting_cases
ALTER TABLE public.wolf_underwriting_cases 
ADD COLUMN IF NOT EXISTS run_ts timestamptz NOT NULL DEFAULT now();

-- Add run_ts to wolf_legal_scans
ALTER TABLE public.wolf_legal_scans 
ADD COLUMN IF NOT EXISTS run_ts timestamptz NOT NULL DEFAULT now();

-- Add indexes for efficient ordering by run_ts
CREATE INDEX IF NOT EXISTS idx_wolf_uw_cases_run_ts 
ON public.wolf_underwriting_cases (run_ts DESC);

CREATE INDEX IF NOT EXISTS idx_wolf_legal_scans_run_ts 
ON public.wolf_legal_scans (run_ts DESC);

-- =================================================================
-- MIGRATION: 20251204060448_f9bed8fd-fb6d-4ec4-ae17-b8fadb21087f.sql
-- =================================================================
-- V6: Input Snapshots, Credit Engine, Login Firewall

-- 1. wolf_input_snapshots (unified input builder)
CREATE TABLE IF NOT EXISTS public.wolf_input_snapshots (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  deal_id uuid,
  deal_room_id uuid,
  lead_id uuid,
  vault_id uuid,
  snapshot jsonb NOT NULL,
  engine_version text NOT NULL DEFAULT 'v1',
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_wolf_snapshots_deal ON public.wolf_input_snapshots(deal_id);
CREATE INDEX IF NOT EXISTS idx_wolf_snapshots_lead ON public.wolf_input_snapshots(lead_id);

ALTER TABLE public.wolf_input_snapshots ENABLE ROW LEVEL SECURITY;

-- Admin-only access (service role bypasses RLS for edge functions)
CREATE POLICY "Admin read snapshots" ON public.wolf_input_snapshots 
  FOR SELECT USING (has_role(auth.uid(), 'admin'::public.app_role));
CREATE POLICY "Admin insert snapshots" ON public.wolf_input_snapshots 
  FOR INSERT WITH CHECK (has_role(auth.uid(), 'admin'::public.app_role));

-- 2. Add snapshot_id to wolf_underwriting_cases
ALTER TABLE public.wolf_underwriting_cases 
ADD COLUMN IF NOT EXISTS snapshot_id uuid REFERENCES public.wolf_input_snapshots(id);

-- 3. wolf_credit_cases (credit engine)
CREATE TABLE IF NOT EXISTS public.wolf_credit_cases (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  deal_id uuid,
  deal_room_id uuid,
  vault_id uuid,
  snapshot_id uuid REFERENCES public.wolf_input_snapshots(id),
  run_ts timestamptz NOT NULL DEFAULT now(),
  run_by_type text NOT NULL,
  run_by_id uuid,
  run_source text NOT NULL,
  routing_trigger text,
  status text NOT NULL DEFAULT 'completed',
  strategy text,
  plan jsonb,
  notes text,
  engine_version text NOT NULL DEFAULT 'v1',
  meta jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_wolf_credit_cases_deal ON public.wolf_credit_cases(deal_id);
CREATE INDEX IF NOT EXISTS idx_wolf_credit_cases_run_ts ON public.wolf_credit_cases(run_ts DESC);

ALTER TABLE public.wolf_credit_cases ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admin read credit cases" ON public.wolf_credit_cases 
  FOR SELECT USING (has_role(auth.uid(), 'admin'::public.app_role));
CREATE POLICY "Admin insert credit cases" ON public.wolf_credit_cases 
  FOR INSERT WITH CHECK (has_role(auth.uid(), 'admin'::public.app_role));
CREATE POLICY "Admin update credit cases" ON public.wolf_credit_cases 
  FOR UPDATE USING (has_role(auth.uid(), 'admin'::public.app_role));

-- 4. wolf_devices (login firewall)
CREATE TABLE IF NOT EXISTS public.wolf_devices (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  device_fingerprint text NOT NULL,
  ip_hash text,
  user_agent text,
  trust_level text NOT NULL DEFAULT 'unknown',
  first_seen_at timestamptz NOT NULL DEFAULT now(),
  last_seen_at timestamptz NOT NULL DEFAULT now(),
  failed_attempts int NOT NULL DEFAULT 0,
  meta jsonb
);

CREATE INDEX IF NOT EXISTS idx_wolf_devices_user ON public.wolf_devices(user_id);
CREATE INDEX IF NOT EXISTS idx_wolf_devices_fingerprint ON public.wolf_devices(device_fingerprint);

ALTER TABLE public.wolf_devices ENABLE ROW LEVEL SECURITY;

-- Users can only see their own devices
CREATE POLICY "Users read own devices" ON public.wolf_devices 
  FOR SELECT USING (user_id = auth.uid());
CREATE POLICY "Users update own devices" ON public.wolf_devices 
  FOR UPDATE USING (user_id = auth.uid());
-- Admin can manage all devices
CREATE POLICY "Admin manage devices" ON public.wolf_devices 
  FOR ALL USING (has_role(auth.uid(), 'admin'::public.app_role));

-- 5. wolf_identity_verifications
CREATE TABLE IF NOT EXISTS public.wolf_identity_verifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  provider text NOT NULL,
  status text NOT NULL,
  evidence jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_wolf_idv_user ON public.wolf_identity_verifications(user_id);

ALTER TABLE public.wolf_identity_verifications ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users read own verifications" ON public.wolf_identity_verifications 
  FOR SELECT USING (user_id = auth.uid());
CREATE POLICY "Admin manage verifications" ON public.wolf_identity_verifications 
  FOR ALL USING (has_role(auth.uid(), 'admin'::public.app_role));

-- =================================================================
-- MIGRATION: 20251204061924_61b71386-76a5-45a2-8d4d-d0cad68d6059.sql
-- =================================================================
-- V7+ Migration: Config Engine & History

-- 1. Add columns to wolf_master_config for versioning and protection
ALTER TABLE public.wolf_master_config
  ADD COLUMN IF NOT EXISTS version integer DEFAULT 1,
  ADD COLUMN IF NOT EXISTS is_protected boolean DEFAULT false;

-- 2. Add applied_change_group_id to wolf_suggestions
ALTER TABLE public.wolf_suggestions
  ADD COLUMN IF NOT EXISTS applied_change_group_id uuid;

-- 3. Create wolf_master_config_history table
CREATE TABLE IF NOT EXISTS public.wolf_master_config_history (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  change_group_id uuid NOT NULL,
  category text NOT NULL,
  key text NOT NULL,
  path text,
  old_value jsonb,
  new_value jsonb,
  suggestion_id uuid REFERENCES public.wolf_suggestions(id),
  applied_by_type text NOT NULL,
  applied_by_id uuid,
  applied_source text NOT NULL,
  risk_score numeric,
  comments text,
  is_rollback boolean DEFAULT false,
  rollback_of uuid REFERENCES public.wolf_master_config_history(id),
  version_before integer,
  version_after integer,
  created_at timestamptz NOT NULL DEFAULT now()
);

-- 4. Create indexes for wolf_master_config_history
CREATE INDEX IF NOT EXISTS idx_wmch_category_key ON public.wolf_master_config_history(category, key);
CREATE INDEX IF NOT EXISTS idx_wmch_change_group ON public.wolf_master_config_history(change_group_id);
CREATE INDEX IF NOT EXISTS idx_wmch_created_at ON public.wolf_master_config_history(created_at DESC);

-- 5. Enable RLS on wolf_master_config_history
ALTER TABLE public.wolf_master_config_history ENABLE ROW LEVEL SECURITY;

-- 6. RLS policies for wolf_master_config_history (admin-only)
CREATE POLICY "Admin read config history"
  ON public.wolf_master_config_history
  FOR SELECT
  USING (has_role(auth.uid(), 'admin'::public.app_role));

CREATE POLICY "Admin insert config history"
  ON public.wolf_master_config_history
  FOR INSERT
  WITH CHECK (has_role(auth.uid(), 'admin'::public.app_role));

-- =================================================================
-- MIGRATION: 20251204064355_b8411004-8baa-42e9-a13d-56b7b4e1985b.sql
-- =================================================================
-- V8: Multi-Portal Access Control + Security Engine

-- 1. Add is_primary to user_roles with partial unique constraint
ALTER TABLE public.user_roles
ADD COLUMN IF NOT EXISTS is_primary boolean DEFAULT false;

-- Partial unique index: only one primary role per user
CREATE UNIQUE INDEX IF NOT EXISTS idx_user_roles_primary_per_user
ON public.user_roles(user_id) WHERE is_primary = true;

-- 2. Create portal_profiles table (NO FK to auth.users, plain uuid)
CREATE TABLE IF NOT EXISTS public.portal_profiles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  primary_role text NOT NULL,
  iso_id uuid,
  funder_id uuid,
  client_business_id uuid,
  callcenter_team_id uuid,
  settings jsonb DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX IF NOT EXISTS idx_portal_profiles_user
ON public.portal_profiles(user_id);

-- Trigger for updated_at on portal_profiles
CREATE OR REPLACE FUNCTION public.update_portal_profiles_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trigger_portal_profiles_updated_at ON public.portal_profiles;
CREATE TRIGGER trigger_portal_profiles_updated_at
BEFORE UPDATE ON public.portal_profiles
FOR EACH ROW
EXECUTE FUNCTION public.update_portal_profiles_updated_at();

-- RLS for portal_profiles
ALTER TABLE public.portal_profiles ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "User can read own portal profile" ON public.portal_profiles;
CREATE POLICY "User can read own portal profile"
ON public.portal_profiles
FOR SELECT USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "Admin manage portal profiles" ON public.portal_profiles;
CREATE POLICY "Admin manage portal profiles"
ON public.portal_profiles
FOR ALL USING (has_role(auth.uid(), 'admin'::public.app_role));

DROP POLICY IF EXISTS "System can insert portal profiles" ON public.portal_profiles;
CREATE POLICY "System can insert portal profiles"
ON public.portal_profiles
FOR INSERT WITH CHECK (true);

-- 3. Create wolf_security_events table with acknowledgment fields
CREATE TABLE IF NOT EXISTS public.wolf_security_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  event_ts timestamptz NOT NULL DEFAULT now(),
  user_id uuid,
  device_id uuid,
  ip_hash text,
  portal text,
  event_type text NOT NULL,
  severity text NOT NULL DEFAULT 'info',
  source text NOT NULL,
  context jsonb DEFAULT '{}'::jsonb,
  acknowledged_at timestamptz,
  acknowledged_by uuid,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_wolf_security_events_ts
ON public.wolf_security_events(event_ts DESC);

CREATE INDEX IF NOT EXISTS idx_wolf_security_events_user
ON public.wolf_security_events(user_id);

CREATE INDEX IF NOT EXISTS idx_wolf_security_events_type
ON public.wolf_security_events(event_type);

CREATE INDEX IF NOT EXISTS idx_wolf_security_events_severity
ON public.wolf_security_events(severity);

-- RLS for wolf_security_events
ALTER TABLE public.wolf_security_events ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Admin read security events" ON public.wolf_security_events;
CREATE POLICY "Admin read security events"
ON public.wolf_security_events
FOR SELECT USING (has_role(auth.uid(), 'admin'::public.app_role));

DROP POLICY IF EXISTS "Admin update security events" ON public.wolf_security_events;
CREATE POLICY "Admin update security events"
ON public.wolf_security_events
FOR UPDATE USING (has_role(auth.uid(), 'admin'::public.app_role));

-- 4. Role change audit trigger
CREATE OR REPLACE FUNCTION public.audit_role_change()
RETURNS TRIGGER AS $$
DECLARE
  v_event_type text;
  v_user_email text;
BEGIN
  SELECT email INTO v_user_email FROM auth.users WHERE id = COALESCE(NEW.user_id, OLD.user_id);
  
  IF TG_OP = 'INSERT' THEN
    v_event_type := 'role_granted';
    INSERT INTO public.wolf_security_events (
      user_id, event_type, severity, source, context
    ) VALUES (
      NEW.user_id,
      v_event_type,
      'info',
      'role_audit_trigger',
      jsonb_build_object(
        'role', NEW.role,
        'approved', NEW.approved,
        'is_primary', NEW.is_primary,
        'user_email', v_user_email
      )
    );
  ELSIF TG_OP = 'DELETE' THEN
    v_event_type := 'role_revoked';
    INSERT INTO public.wolf_security_events (
      user_id, event_type, severity, source, context
    ) VALUES (
      OLD.user_id,
      v_event_type,
      'warning',
      'role_audit_trigger',
      jsonb_build_object(
        'role', OLD.role,
        'user_email', v_user_email
      )
    );
  ELSIF TG_OP = 'UPDATE' THEN
    IF OLD.approved IS DISTINCT FROM NEW.approved THEN
      v_event_type := CASE WHEN NEW.approved THEN 'role_approved' ELSE 'role_unapproved' END;
      INSERT INTO public.wolf_security_events (
        user_id, event_type, severity, source, context
      ) VALUES (
        NEW.user_id,
        v_event_type,
        CASE WHEN NEW.approved THEN 'info' ELSE 'warning' END,
        'role_audit_trigger',
        jsonb_build_object(
          'role', NEW.role,
          'approved', NEW.approved,
          'user_email', v_user_email
        )
      );
    END IF;
  END IF;
  
  RETURN COALESCE(NEW, OLD);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

DROP TRIGGER IF EXISTS trigger_audit_role_change ON public.user_roles;
CREATE TRIGGER trigger_audit_role_change
AFTER INSERT OR UPDATE OR DELETE ON public.user_roles
FOR EACH ROW
EXECUTE FUNCTION public.audit_role_change();

-- 5. Add unique constraint to wolf_master_config if not exists
CREATE UNIQUE INDEX IF NOT EXISTS idx_wolf_master_config_category_key
ON public.wolf_master_config(category, key);

-- 6. Insert portal routing config
INSERT INTO public.wolf_master_config (category, key, value, version, is_protected)
SELECT 'portal', 'routing', '{
  "priority": ["admin", "worker", "iso", "funder", "client", "affiliate", "callcenter"],
  "fallback_portal": "client",
  "no_roles_redirect": "/pending-approval",
  "auto_create_profile": true,
  "multi_role_behavior": "auto_route"
}'::jsonb, 1, false
WHERE NOT EXISTS (
  SELECT 1 FROM public.wolf_master_config WHERE category = 'portal' AND key = 'routing'
);

-- 7. Insert security policies config
INSERT INTO public.wolf_master_config (category, key, value, version, is_protected)
SELECT 'security', 'policies', '{
  "login": {
    "max_failed_attempts": 5,
    "challenge_threshold": 40,
    "block_threshold": 70
  },
  "portal": {
    "allow_multi_roles": true,
    "multi_role_warn_only": true
  },
  "monitor": {
    "max_events_per_user_hour": 200,
    "bruteforce_window_minutes": 15,
    "alert_cooldown_minutes": 30
  }
}'::jsonb, 1, true
WHERE NOT EXISTS (
  SELECT 1 FROM public.wolf_master_config WHERE category = 'security' AND key = 'policies'
);

-- =================================================================
-- MIGRATION: 20251204071404_8ebc263d-926d-4b3d-a90b-94163ef0c756.sql
-- =================================================================
-- V9: wolf_sessions table for session tracking

CREATE TABLE public.wolf_sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  user_email text NULL,
  device_id uuid NULL,
  portal text NOT NULL,
  ip_hash text NULL,
  user_agent text NULL,
  status text NOT NULL DEFAULT 'active',
  started_at timestamptz NOT NULL DEFAULT now(),
  last_seen_at timestamptz NOT NULL DEFAULT now(),
  terminated_at timestamptz NULL,
  terminated_by uuid NULL,
  terminated_reason text NULL,
  expires_at timestamptz NULL DEFAULT (now() + interval '24 hours'),
  meta jsonb NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX idx_wolf_sessions_user ON public.wolf_sessions(user_id);
CREATE INDEX idx_wolf_sessions_status ON public.wolf_sessions(status);
CREATE INDEX idx_wolf_sessions_portal ON public.wolf_sessions(portal);
CREATE INDEX idx_wolf_sessions_expires ON public.wolf_sessions(expires_at) WHERE status = 'active';

-- Enable RLS
ALTER TABLE public.wolf_sessions ENABLE ROW LEVEL SECURITY;

-- Admin: full access
CREATE POLICY "Admin manage sessions"
ON public.wolf_sessions
FOR ALL
USING (has_role(auth.uid(), 'admin'::public.app_role))
WITH CHECK (has_role(auth.uid(), 'admin'::public.app_role));

-- Users: read-only view of their own sessions
CREATE POLICY "Users view own sessions"
ON public.wolf_sessions
FOR SELECT
USING (user_id = auth.uid());

-- =================================================================
-- MIGRATION: 20251204195615_d4407f0a-451b-45b5-922f-ef207fa982cd.sql
-- =================================================================
-- V10 / B100: Session hygiene & guardrails for wolf_sessions

-- 1) Index for last_seen_at to support cleanup / analytics
CREATE INDEX IF NOT EXISTS idx_wolf_sessions_last_seen
ON public.wolf_sessions(last_seen_at);

-- 2) Enforce allowed statuses at DB level (matches existing usage)
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint
    WHERE conname = 'wolf_sessions_status_check'
      AND conrelid = 'public.wolf_sessions'::regclass
  ) THEN
    ALTER TABLE public.wolf_sessions
      ADD CONSTRAINT wolf_sessions_status_check
      CHECK (status IN ('active', 'revoked', 'expired'));
  END IF;
END;
$$;

-- 3) Document expiry semantics
COMMENT ON COLUMN public.wolf_sessions.expires_at IS
  'Soft TTL for sessions. V10/B100: wolf-session-expirer marks sessions as expired when expires_at < now() and status = active.';

-- 4) Optional helper column for housekeeping / batch tags
ALTER TABLE public.wolf_sessions
  ADD COLUMN IF NOT EXISTS cleanup_tag text;

COMMENT ON COLUMN public.wolf_sessions.cleanup_tag IS
  'Internal tag used by wolf-session-expirer for housekeeping/batch IDs. Not used by portals.';

-- =================================================================
-- MIGRATION: 20251204202754_5718d21e-7a58-4da8-8d0e-3024f28e2846.sql
-- =================================================================
-- ===========================================
-- V11 / B200 - Session Analytics + Correlation
-- ===========================================

-- 1) Session Analytics Table
CREATE TABLE IF NOT EXISTS public.wolf_session_analytics (
  id                uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id        uuid NOT NULL REFERENCES public.wolf_sessions(id) ON DELETE CASCADE,
  user_id           uuid NOT NULL,
  device_id         uuid,
  portal            text NOT NULL,
  start_time        timestamptz NOT NULL,
  end_time          timestamptz,
  duration_seconds  integer,
  idle_seconds      integer DEFAULT 0,
  heartbeat_count   integer DEFAULT 0,
  expired           boolean DEFAULT false,
  terminated        boolean DEFAULT false,
  risk_level        text DEFAULT 'none',
  created_at        timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_wsa_session_id ON public.wolf_session_analytics(session_id);
CREATE INDEX IF NOT EXISTS idx_wsa_user_id ON public.wolf_session_analytics(user_id);
CREATE INDEX IF NOT EXISTS idx_wsa_portal ON public.wolf_session_analytics(portal);
CREATE INDEX IF NOT EXISTS idx_wsa_created_at ON public.wolf_session_analytics(created_at);

ALTER TABLE public.wolf_session_analytics ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins can view wolf_session_analytics"
  ON public.wolf_session_analytics
  FOR SELECT
  USING (has_role(auth.uid(), 'admin'::public.app_role));

CREATE POLICY "Admins can manage wolf_session_analytics"
  ON public.wolf_session_analytics
  FOR ALL
  USING (has_role(auth.uid(), 'admin'::public.app_role));

-- 2) Security Correlation Table
CREATE TABLE IF NOT EXISTS public.wolf_security_correlations (
  id                   uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id           uuid NOT NULL REFERENCES public.wolf_sessions(id) ON DELETE CASCADE,
  user_id              uuid NOT NULL,
  device_id            uuid,
  ip_hash              text,
  portal               text,
  risk_sources         jsonb NOT NULL DEFAULT '[]'::jsonb,
  combined_risk_score  integer NOT NULL DEFAULT 0,
  created_at           timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_wsc_session_id ON public.wolf_security_correlations(session_id);
CREATE INDEX IF NOT EXISTS idx_wsc_user_id ON public.wolf_security_correlations(user_id);
CREATE INDEX IF NOT EXISTS idx_wsc_created_at ON public.wolf_security_correlations(created_at);
CREATE INDEX IF NOT EXISTS idx_wsc_score ON public.wolf_security_correlations(combined_risk_score);

ALTER TABLE public.wolf_security_correlations ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins can view wolf_security_correlations"
  ON public.wolf_security_correlations
  FOR SELECT
  USING (has_role(auth.uid(), 'admin'::public.app_role));

CREATE POLICY "Admins can manage wolf_security_correlations"
  ON public.wolf_security_correlations
  FOR ALL
  USING (has_role(auth.uid(), 'admin'::public.app_role));

-- =================================================================
-- MIGRATION: 20251204212451_83616b0d-9a85-4593-a973-0eac3baaeac6.sql
-- =================================================================
-- V2.0 – WOLF FUND CREDIT FIX BACK OFFICE FOUNDATION
-- Multi-Tenant + Unified Leads + Credit Cases V2

-- =============================================
-- 1. Multi-Tenant Foundation
-- =============================================

-- Tenants (brands, white-label instances)
CREATE TABLE IF NOT EXISTS public.wf_tenants (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name          text NOT NULL,
  slug          text UNIQUE NOT NULL,
  status        text NOT NULL DEFAULT 'active',
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now()
);

-- Link auth.users to tenants + roles
CREATE TABLE IF NOT EXISTS public.wf_tenant_users (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id     uuid NOT NULL REFERENCES public.wf_tenants(id) ON DELETE CASCADE,
  user_id       uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  role          text NOT NULL,
  is_primary    boolean NOT NULL DEFAULT false,
  created_at    timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, user_id)
);

ALTER TABLE public.wf_tenants ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.wf_tenant_users ENABLE ROW LEVEL SECURITY;

CREATE INDEX IF NOT EXISTS idx_wf_tenant_users_tenant ON public.wf_tenant_users(tenant_id);
CREATE INDEX IF NOT EXISTS idx_wf_tenant_users_user ON public.wf_tenant_users(user_id);

CREATE POLICY "Admins can view wf_tenants"
  ON public.wf_tenants FOR SELECT
  USING (has_role(auth.uid(), 'admin'::public.app_role));

CREATE POLICY "Admins can manage wf_tenants"
  ON public.wf_tenants FOR ALL
  USING (has_role(auth.uid(), 'admin'::public.app_role));

CREATE POLICY "Admins can view wf_tenant_users"
  ON public.wf_tenant_users FOR SELECT
  USING (has_role(auth.uid(), 'admin'::public.app_role));

CREATE POLICY "Admins can manage wf_tenant_users"
  ON public.wf_tenant_users FOR ALL
  USING (has_role(auth.uid(), 'admin'::public.app_role));

-- Insert default tenant
INSERT INTO public.wf_tenants (name, slug, status)
VALUES ('Wolf Fund', 'wolf-fund', 'active')
ON CONFLICT (slug) DO NOTHING;

-- =============================================
-- 2. Unified Leads Table: wf_leads
-- =============================================

CREATE TABLE IF NOT EXISTS public.wf_leads (
  id                uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id         uuid NOT NULL REFERENCES public.wf_tenants(id) ON DELETE CASCADE,
  source            text NOT NULL,
  channel           text,
  lead_type         text NOT NULL,
  first_name        text,
  last_name         text,
  full_name         text,
  email             text,
  phone             text,
  estimated_credit_score text,
  notes             text,
  status            text NOT NULL DEFAULT 'new',
  priority          text NOT NULL DEFAULT 'medium',
  assigned_to       uuid,
  assigned_at       timestamptz,
  converted_at      timestamptz,
  fast_track_id     uuid REFERENCES public.fast_track_applications(id) ON DELETE SET NULL,
  loan_application_id uuid REFERENCES public.loan_applications(id) ON DELETE SET NULL,
  legacy_credit_app_id uuid REFERENCES public.credit_repair_applications(id) ON DELETE SET NULL,
  credit_case_v2_id uuid,
  meta              jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_by        uuid,
  created_at        timestamptz NOT NULL DEFAULT now(),
  updated_at        timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.wf_leads ENABLE ROW LEVEL SECURITY;

CREATE INDEX IF NOT EXISTS idx_wf_leads_tenant ON public.wf_leads(tenant_id);
CREATE INDEX IF NOT EXISTS idx_wf_leads_status ON public.wf_leads(status);
CREATE INDEX IF NOT EXISTS idx_wf_leads_assigned_to ON public.wf_leads(assigned_to);
CREATE INDEX IF NOT EXISTS idx_wf_leads_lead_type ON public.wf_leads(lead_type);

CREATE POLICY "Admins can manage wf_leads"
  ON public.wf_leads FOR ALL
  USING (has_role(auth.uid(), 'admin'::public.app_role));

CREATE POLICY "Tenant workers can view tenant leads"
  ON public.wf_leads FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM public.wf_tenant_users tu
      WHERE tu.user_id = auth.uid()
        AND tu.tenant_id = wf_leads.tenant_id
    )
  );

CREATE POLICY "Tenant workers can insert tenant leads"
  ON public.wf_leads FOR INSERT
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.wf_tenant_users tu
      WHERE tu.user_id = auth.uid()
        AND tu.tenant_id = wf_leads.tenant_id
    )
  );

CREATE POLICY "Tenant workers can update tenant leads"
  ON public.wf_leads FOR UPDATE
  USING (
    EXISTS (
      SELECT 1 FROM public.wf_tenant_users tu
      WHERE tu.user_id = auth.uid()
        AND tu.tenant_id = wf_leads.tenant_id
    )
  );

CREATE TRIGGER set_wf_leads_updated_at
  BEFORE UPDATE ON public.wf_leads
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_updated_at();

-- =============================================
-- 3. New Credit Engine: credit_cases_v2
-- =============================================

CREATE TABLE IF NOT EXISTS public.credit_cases_v2 (
  id                  uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id           uuid NOT NULL REFERENCES public.wf_tenants(id) ON DELETE CASCADE,
  lead_id             uuid REFERENCES public.wf_leads(id) ON DELETE SET NULL,
  client_user_id      uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  client_full_name    text,
  client_email        text,
  client_phone        text,
  client_ssn_last4    text,
  client_zip          text,
  status              text NOT NULL DEFAULT 'intake',
  priority            text NOT NULL DEFAULT 'medium',
  assigned_to         uuid,
  assigned_at         timestamptz,
  bureaus             text[] DEFAULT ARRAY[]::text[],
  has_identity_theft  boolean DEFAULT false,
  identity_theft_notes text,
  initial_credit_score_range text,
  target_credit_score_range  text,
  documents_bucket    text DEFAULT 'credit-repair-documents',
  documents_path_root text,
  meta                jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_by          uuid,
  created_at          timestamptz NOT NULL DEFAULT now(),
  updated_at          timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.credit_cases_v2 ENABLE ROW LEVEL SECURITY;

CREATE INDEX IF NOT EXISTS idx_credit_cases_v2_tenant ON public.credit_cases_v2(tenant_id);
CREATE INDEX IF NOT EXISTS idx_credit_cases_v2_status ON public.credit_cases_v2(status);
CREATE INDEX IF NOT EXISTS idx_credit_cases_v2_assigned ON public.credit_cases_v2(assigned_to);

-- Activity log for credit cases
CREATE TABLE IF NOT EXISTS public.credit_case_v2_activity (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  case_id         uuid NOT NULL REFERENCES public.credit_cases_v2(id) ON DELETE CASCADE,
  tenant_id       uuid NOT NULL,
  actor_user_id   uuid,
  actor_role      text,
  event_type      text NOT NULL,
  message         text,
  payload         jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at      timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.credit_case_v2_activity ENABLE ROW LEVEL SECURITY;

CREATE INDEX IF NOT EXISTS idx_credit_case_v2_activity_case ON public.credit_case_v2_activity(case_id);
CREATE INDEX IF NOT EXISTS idx_credit_case_v2_activity_tenant ON public.credit_case_v2_activity(tenant_id);

-- RLS for credit_cases_v2
CREATE POLICY "Admins manage credit_cases_v2"
  ON public.credit_cases_v2 FOR ALL
  USING (has_role(auth.uid(), 'admin'::public.app_role));

CREATE POLICY "Tenant workers view credit_cases_v2"
  ON public.credit_cases_v2 FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM public.wf_tenant_users tu
      WHERE tu.user_id = auth.uid()
        AND tu.tenant_id = credit_cases_v2.tenant_id
    )
  );

CREATE POLICY "Tenant workers edit credit_cases_v2"
  ON public.credit_cases_v2 FOR UPDATE
  USING (
    EXISTS (
      SELECT 1 FROM public.wf_tenant_users tu
      WHERE tu.user_id = auth.uid()
        AND tu.tenant_id = credit_cases_v2.tenant_id
    )
  );

-- RLS for activity
CREATE POLICY "Admins manage credit_case_v2_activity"
  ON public.credit_case_v2_activity FOR ALL
  USING (has_role(auth.uid(), 'admin'::public.app_role));

CREATE POLICY "Tenant workers view credit_case_v2_activity"
  ON public.credit_case_v2_activity FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM public.wf_tenant_users tu
      WHERE tu.user_id = auth.uid()
        AND tu.tenant_id = credit_case_v2_activity.tenant_id
    )
  );

CREATE POLICY "Tenant workers insert credit_case_v2_activity"
  ON public.credit_case_v2_activity FOR INSERT
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.wf_tenant_users tu
      WHERE tu.user_id = auth.uid()
        AND tu.tenant_id = credit_case_v2_activity.tenant_id
    )
  );

-- Add FK from wf_leads to credit_cases_v2
ALTER TABLE public.wf_leads 
  ADD CONSTRAINT fk_wf_leads_credit_case_v2 
  FOREIGN KEY (credit_case_v2_id) 
  REFERENCES public.credit_cases_v2(id) 
  ON DELETE SET NULL;

-- Updated_at trigger for credit_cases_v2
CREATE TRIGGER set_credit_cases_v2_updated_at
  BEFORE UPDATE ON public.credit_cases_v2
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_updated_at();

