-- DATABASE FUNCTIONS EXPORT
-- Project Ref: tdzuhcswrojlleeupqvd
-- Export Date: 2025-12-14

-- Function: tenant_has_access
CREATE OR REPLACE FUNCTION public.tenant_has_access(user_id uuid, tid uuid)
 RETURNS boolean
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
BEGIN
  RETURN EXISTS (
    SELECT 1 FROM public.wf_tenant_users 
    WHERE wf_tenant_users.user_id = $1 
    AND wf_tenant_users.tenant_id = $2
  ) OR has_role($1, 'admin'::public.app_role);
END;
$function$;

-- Function: tenant_is_admin
CREATE OR REPLACE FUNCTION public.tenant_is_admin(user_id uuid, tid uuid)
 RETURNS boolean
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
BEGIN
  RETURN EXISTS (
    SELECT 1 FROM public.wf_tenant_users 
    WHERE wf_tenant_users.user_id = $1 
    AND wf_tenant_users.tenant_id = $2
    AND wf_tenant_users.role IN ('admin', 'owner')
  ) OR has_role($1, 'admin'::public.app_role);
END;
$function$;

-- Function: update_updated_at_column
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
 RETURNS trigger
 LANGUAGE plpgsql
 SET search_path TO 'public'
AS $function$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$function$;

-- Function: handle_new_user_profile
CREATE OR REPLACE FUNCTION public.handle_new_user_profile()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
BEGIN
  INSERT INTO public.profiles (id, email, full_name)
  VALUES (NEW.id, NEW.email, COALESCE(NEW.raw_user_meta_data ->> 'full_name', NEW.email));
  RETURN NEW;
END;
$function$;

-- Function: has_role (overload 1)
CREATE OR REPLACE FUNCTION public.has_role(target_role text)
 RETURNS boolean
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
  select exists (
    select 1
    from public.user_roles ur
    where ur.user_id = auth.uid()
      and ur.approved = true
      and ur.role = target_role::public.app_role
  );
$function$;

-- Function: has_role (overload 2)
CREATE OR REPLACE FUNCTION public.has_role(_user_id uuid, _role public.app_role)
 RETURNS boolean
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
  SELECT EXISTS (
    SELECT 1
    FROM public.user_roles
    WHERE user_id = _user_id
      AND role = _role
  )
$function$;

-- Function: is_owner
CREATE OR REPLACE FUNCTION public.is_owner()
 RETURNS boolean
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
BEGIN
  RETURN EXISTS (
    SELECT 1 FROM public.user_roles
    WHERE user_id = auth.uid() AND role = 'owner'::public.app_role AND approved = true
  );
END;
$function$;

-- Function: is_legal
CREATE OR REPLACE FUNCTION public.is_legal()
 RETURNS boolean
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
BEGIN
  RETURN EXISTS (
    SELECT 1 FROM public.user_roles
    WHERE user_id = auth.uid() AND role = 'legal'::public.app_role AND approved = true
  );
END;
$function$;

-- Function: user_tenant_id
CREATE OR REPLACE FUNCTION public.user_tenant_id()
 RETURNS uuid
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
BEGIN
  RETURN (
    SELECT tenant_id FROM public.wf_tenant_users
    WHERE user_id = auth.uid()
    LIMIT 1
  );
END;
$function$;

-- Function: can_access_tenant
CREATE OR REPLACE FUNCTION public.can_access_tenant(tid uuid)
 RETURNS boolean
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
BEGIN
  IF public.is_owner() THEN RETURN TRUE; END IF;
  RETURN public.user_tenant_id() = tid;
END;
$function$;

-- Function: can_access_vault
CREATE OR REPLACE FUNCTION public.can_access_vault(_user_id uuid)
 RETURNS boolean
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
  SELECT EXISTS (
    SELECT 1 FROM public.user_roles
    WHERE user_id = _user_id
      AND approved = true
      AND role IN ('owner'::public.app_role, 'legal'::public.app_role)
  );
$function$;

-- Function: get_role_level
CREATE OR REPLACE FUNCTION public.get_role_level(role_name text)
 RETURNS integer
 LANGUAGE sql
 IMMUTABLE
AS $function$
  SELECT CASE role_name
    WHEN 'owner' THEN 100
    WHEN 'tenant_admin' THEN 90
    WHEN 'admin' THEN 80
    WHEN 'underwriter' THEN 70
    WHEN 'credit_repair_specialist' THEN 65
    WHEN 'legal' THEN 60
    WHEN 'worker' THEN 50
    WHEN 'iso' THEN 40
    WHEN 'iso_partner' THEN 35
    WHEN 'client' THEN 20
    WHEN 'user' THEN 10
    ELSE 0
  END;
$function$;

-- Function: has_role_or_higher
CREATE OR REPLACE FUNCTION public.has_role_or_higher(_user_id uuid, _min_role text)
 RETURNS boolean
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
  SELECT EXISTS (
    SELECT 1 FROM public.user_roles
    WHERE user_id = _user_id
      AND approved = true
      AND get_role_level(role::text) >= get_role_level(_min_role)
  );
$function$;

-- Function: is_owner_or_tenant_admin
CREATE OR REPLACE FUNCTION public.is_owner_or_tenant_admin(_user_id uuid)
 RETURNS boolean
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
  SELECT EXISTS (
    SELECT 1 FROM public.user_roles
    WHERE user_id = _user_id
      AND approved = true
      AND role IN ('owner'::public.app_role, 'tenant_admin'::public.app_role)
  );
$function$;

-- Function: handle_new_user_signup
CREATE OR REPLACE FUNCTION public.handle_new_user_signup()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
BEGIN
  INSERT INTO public.user_roles (user_id, role, approved)
  VALUES (NEW.id, 'user'::public.app_role, true);
  RETURN NEW;
END;
$function$;

-- Function: promote_to_worker
CREATE OR REPLACE FUNCTION public.promote_to_worker(_user_id uuid)
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
BEGIN
  INSERT INTO public.user_roles (user_id, role, approved)
  VALUES (_user_id, 'worker'::public.app_role, false)
  ON CONFLICT (user_id, role) DO NOTHING;
END;
$function$;

-- Function: log_sensitive_access
CREATE OR REPLACE FUNCTION public.log_sensitive_access(table_name text, record_id uuid, field text)
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
BEGIN
  IF has_role(auth.uid(), 'admin'::public.app_role) THEN
    INSERT INTO admin_sensitive_data_access (admin_user_id, accessed_table, record_id, field_name)
    VALUES (auth.uid(), table_name, record_id, field);
  END IF;
END;
$function$;

-- Function: audit_role_change
CREATE OR REPLACE FUNCTION public.audit_role_change()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  v_event_type text;
  v_user_email text;
BEGIN
  SELECT email INTO v_user_email FROM auth.users WHERE id = COALESCE(NEW.user_id, OLD.user_id);
  
  IF TG_OP = 'INSERT' THEN
    v_event_type := 'role_granted';
    INSERT INTO public.wolf_security_events (
      user_id, event_type, severity, source, context
    ) VALUES (
      NEW.user_id,
      v_event_type,
      'info',
      'role_audit_trigger',
      jsonb_build_object(
        'role', NEW.role,
        'approved', NEW.approved,
        'is_primary', NEW.is_primary,
        'user_email', v_user_email
      )
    );
  ELSIF TG_OP = 'DELETE' THEN
    v_event_type := 'role_revoked';
    INSERT INTO public.wolf_security_events (
      user_id, event_type, severity, source, context
    ) VALUES (
      OLD.user_id,
      v_event_type,
      'warning',
      'role_audit_trigger',
      jsonb_build_object(
        'role', OLD.role,
        'user_email', v_user_email
      )
    );
  ELSIF TG_OP = 'UPDATE' THEN
    IF OLD.approved IS DISTINCT FROM NEW.approved THEN
      v_event_type := CASE WHEN NEW.approved THEN 'role_approved' ELSE 'role_unapproved' END;
      INSERT INTO public.wolf_security_events (
        user_id, event_type, severity, source, context
      ) VALUES (
        NEW.user_id,
        v_event_type,
        CASE WHEN NEW.approved THEN 'info' ELSE 'warning' END,
        'role_audit_trigger',
        jsonb_build_object(
          'role', NEW.role,
          'approved', NEW.approved,
          'user_email', v_user_email
        )
      );
    END IF;
  END IF;
  
  RETURN COALESCE(NEW, OLD);
END;
$function$;

-- Function: get_next_lead
CREATE OR REPLACE FUNCTION public.get_next_lead(p_worker_id uuid)
 RETURNS leads
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  result leads;
  lock_days integer := 7;
BEGIN
  UPDATE leads
     SET owner_id = NULL, lock_expires_at = NULL
   WHERE lock_expires_at IS NOT NULL
     AND lock_expires_at < now();

  SELECT *
    INTO result
    FROM leads
   WHERE status IN ('new', 'assigned', 'no_answer')
     AND (owner_id IS NULL OR owner_id = p_worker_id)
   ORDER BY
     (owner_id = p_worker_id) DESC,
     ai_score DESC NULLS LAST,
     created_at ASC
   FOR UPDATE SKIP LOCKED
   LIMIT 1;

  IF NOT FOUND THEN
    RETURN NULL;
  END IF;

  UPDATE leads
     SET owner_id = p_worker_id,
         lock_expires_at = now() + (lock_days || ' days')::interval
   WHERE id = result.id;

  SELECT * INTO result FROM leads WHERE id = result.id;

  RETURN result;
END;
$function$;

-- Function: start_call_session
CREATE OR REPLACE FUNCTION public.start_call_session(p_worker_id uuid)
 RETURNS call_sessions
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  new_session call_sessions;
BEGIN
  UPDATE call_sessions
     SET is_active = false, ended_at = now()
   WHERE worker_id = p_worker_id
     AND is_active = true;

  INSERT INTO call_sessions(worker_id)
  VALUES (p_worker_id)
  RETURNING * INTO new_session;

  RETURN new_session;
END;
$function$;

-- Function: stop_call_session
CREATE OR REPLACE FUNCTION public.stop_call_session(p_worker_id uuid)
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
BEGIN
  UPDATE call_sessions
     SET is_active = false, ended_at = now()
   WHERE worker_id = p_worker_id
     AND is_active = true;
END;
$function$;

-- Function: move_application_to_credit_repair
CREATE OR REPLACE FUNCTION public.move_application_to_credit_repair(p_application_id uuid, p_application_type text)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  v_email text;
  v_name text;
  v_user_id uuid;
  v_case_id uuid;
  v_app_exists boolean;
BEGIN
  IF p_application_type = 'fast_track' THEN
    SELECT email, client_name, user_id, true
    INTO v_email, v_name, v_user_id, v_app_exists
    FROM fast_track_applications
    WHERE id = p_application_id;
  ELSIF p_application_type = 'loan' THEN
    SELECT email, owner_name, user_id, true
    INTO v_email, v_name, v_user_id, v_app_exists
    FROM loan_applications
    WHERE id = p_application_id;
  ELSE
    RAISE EXCEPTION 'Invalid application type: %', p_application_type;
  END IF;

  IF NOT v_app_exists THEN
    RAISE EXCEPTION 'Application not found with id: %', p_application_id;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM credit_repair_applications 
    WHERE user_id = v_user_id
  ) THEN
    INSERT INTO credit_repair_applications (
      user_id, email, phone, full_name, status
    ) VALUES (
      v_user_id, v_email, '', COALESCE(v_name, v_email), 'active'
    );
  END IF;

  SELECT id INTO v_case_id
  FROM credit_repair_cases
  WHERE original_application_id = p_application_id
    AND original_application_type = p_application_type
  LIMIT 1;

  IF v_case_id IS NULL THEN
    INSERT INTO credit_repair_cases (
      credit_repair_application_id,
      original_application_id,
      original_application_type,
      from_declined_funding,
      status
    )
    SELECT cra.id, p_application_id, p_application_type, true, 'intake'
    FROM credit_repair_applications cra
    WHERE cra.user_id = v_user_id
    RETURNING id INTO v_case_id;
  END IF;

  IF p_application_type = 'fast_track' THEN
    UPDATE fast_track_applications
    SET status = 'moved_to_credit_repair', updated_at = now()
    WHERE id = p_application_id;
  ELSIF p_application_type = 'loan' THEN
    UPDATE loan_applications
    SET status = 'moved_to_credit_repair', updated_at = now()
    WHERE id = p_application_id;
  END IF;

  INSERT INTO activity_feed (
    actor_user_id, actor_email, actor_role, target_email,
    event_type, context_type, context_id, summary, decision
  ) VALUES (
    auth.uid(),
    (SELECT email FROM auth.users WHERE id = auth.uid()),
    'admin', v_email,
    'credit_repair', 'application', p_application_id,
    format('Moved %s application into Credit Repair workflow', p_application_type),
    'approved'
  );

  RETURN jsonb_build_object(
    'success', true,
    'case_id', v_case_id,
    'message', 'Application moved to Credit Repair workflow'
  );

EXCEPTION
  WHEN OTHERS THEN
    RAISE EXCEPTION 'Error moving to credit repair: %', SQLERRM;
END;
$function$;

-- Function: research_center_stats
CREATE OR REPLACE FUNCTION public.research_center_stats(p_lead_list_id uuid DEFAULT NULL::uuid)
 RETURNS json
 LANGUAGE plpgsql
 SECURITY DEFINER
AS $function$
DECLARE
  result json;
  today_start timestamp with time zone := date_trunc('day', now());
BEGIN
  SELECT json_build_object(
    'in_research', (
      SELECT count(*) FROM leads
      WHERE (email IS NULL OR email = '')
        AND (p_lead_list_id IS NULL OR lead_list_id = p_lead_list_id)
    ),
    'fixed_today', (
      SELECT count(*) FROM leads
      WHERE updated_at >= today_start
        AND email IS NOT NULL AND email <> ''
        AND (import_bucket IN ('dialer', 'email') OR route IN ('dialer', 'email', 'credit_fix'))
        AND (p_lead_list_id IS NULL OR lead_list_id = p_lead_list_id)
    ),
    'routed_dialer', (
      SELECT count(*) FROM leads
      WHERE updated_at >= today_start
        AND (import_bucket = 'dialer' OR route = 'dialer')
        AND (p_lead_list_id IS NULL OR lead_list_id = p_lead_list_id)
    ),
    'routed_email', (
      SELECT count(*) FROM leads
      WHERE updated_at >= today_start
        AND (import_bucket = 'email' OR route = 'email')
        AND (p_lead_list_id IS NULL OR lead_list_id = p_lead_list_id)
    )
  ) INTO result;
  
  RETURN result;
END;
$function$;

-- Function: claim_next_research_lead
CREATE OR REPLACE FUNCTION public.claim_next_research_lead(p_worker_id uuid)
 RETURNS leads
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  v_lead leads;
BEGIN
  UPDATE leads
  SET
    research_status = 'in_progress',
    research_assigned_to = p_worker_id,
    research_started_at = NOW(),
    research_attempts = COALESCE(research_attempts, 0) + 1
  WHERE id = (
    SELECT id FROM leads
    WHERE route = 'research'
      AND (research_status = 'pending' OR research_status IS NULL)
      AND status = 'new'
    ORDER BY created_at ASC
    LIMIT 1
    FOR UPDATE SKIP LOCKED
  )
  RETURNING * INTO v_lead;

  RETURN v_lead;
END;
$function$;

-- Function: handle_updated_at
CREATE OR REPLACE FUNCTION public.handle_updated_at()
 RETURNS trigger
 LANGUAGE plpgsql
AS $function$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$function$;
