-- =================================================================
-- MIGRATION: 20251206092803_55061ddf-2374-4257-8124-a1886d26fee6.sql
-- =================================================================
-- ============================================================================
-- MCA DEV BLUEPRINT v1.1 - FULL SCHEMA MIGRATION
-- Modules 1-7: Compliance OS, Product Catalog, Collections, Renewals, 
--              Investor Layer, Rule Engine, ISO Knowledge Hub
-- ============================================================================

-- ============================================================================
-- MODULE 1: COMPLIANCE OS
-- ============================================================================

-- TABLE: compliance_states (state x product rules)
CREATE TABLE IF NOT EXISTS compliance_states (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  state_code    text NOT NULL,
  product_type  text NOT NULL,
  requires_apr_disclosure  boolean NOT NULL DEFAULT false,
  prohibits_coj            boolean NOT NULL DEFAULT false,
  broker_license_required  boolean NOT NULL DEFAULT false,
  disclosure_template_id   uuid NULL,
  notes         text,
  is_active     boolean NOT NULL DEFAULT true,
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_compliance_states_unique
  ON compliance_states(state_code, product_type)
  WHERE is_active = true;

-- TABLE: compliance_disclosure_templates
CREATE TABLE IF NOT EXISTS compliance_disclosure_templates (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name         text NOT NULL,
  state_code   text NOT NULL,
  product_type text NOT NULL,
  version      integer NOT NULL DEFAULT 1,
  body_markdown text NOT NULL,
  is_active    boolean NOT NULL DEFAULT true,
  created_at   timestamptz NOT NULL DEFAULT now(),
  updated_at   timestamptz NOT NULL DEFAULT now()
);

-- TABLE: compliance_deal_checks
CREATE TABLE IF NOT EXISTS compliance_deal_checks (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  deal_id       uuid NOT NULL,
  check_key     text NOT NULL,
  status        text NOT NULL DEFAULT 'pending',
  checked_by    uuid NULL,
  checked_at    timestamptz NULL,
  notes         text,
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_compliance_deal_checks_deal ON compliance_deal_checks(deal_id);

-- TABLE: kyc_results
CREATE TABLE IF NOT EXISTS kyc_results (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  merchant_id   uuid NOT NULL,
  provider      text NOT NULL,
  result        text NOT NULL,
  score         numeric(6,2) NULL,
  risk_band     text NULL,
  raw_json      jsonb NULL,
  created_at    timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_kyc_results_merchant ON kyc_results(merchant_id);

-- ============================================================================
-- MODULE 2: PRODUCT CATALOG & RISK MATRIX
-- ============================================================================

-- TABLE: mca_products
CREATE TABLE IF NOT EXISTS mca_products (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  code        text NOT NULL,
  name        text NOT NULL,
  description text,
  is_active   boolean NOT NULL DEFAULT true,
  created_at  timestamptz NOT NULL DEFAULT now(),
  updated_at  timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_mca_products_code ON mca_products(code);

-- TABLE: risk_tiers
CREATE TABLE IF NOT EXISTS risk_tiers (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  code         text NOT NULL,
  description  text,
  min_score    numeric(5,2) NOT NULL,
  max_score    numeric(5,2) NOT NULL,
  default_factor_rate_min numeric(5,3),
  default_factor_rate_max numeric(5,3),
  default_term_min_days integer,
  default_term_max_days integer,
  created_at   timestamptz NOT NULL DEFAULT now(),
  updated_at   timestamptz NOT NULL DEFAULT now()
);

-- TABLE: industry_rules
CREATE TABLE IF NOT EXISTS industry_rules (
  id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  naics_code     text NULL,
  industry_label text NOT NULL,
  product_allowed boolean NOT NULL DEFAULT true,
  excluded       boolean NOT NULL DEFAULT false,
  notes          text,
  created_at     timestamptz NOT NULL DEFAULT now(),
  updated_at     timestamptz NOT NULL DEFAULT now()
);

-- TABLE: product_pricing_rules
CREATE TABLE IF NOT EXISTS product_pricing_rules (
  id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  product_id     uuid NOT NULL REFERENCES mca_products(id) ON DELETE CASCADE,
  risk_tier_id   uuid NOT NULL REFERENCES risk_tiers(id),
  state_code     text NULL,
  factor_min     numeric(5,3) NOT NULL,
  factor_max     numeric(5,3) NOT NULL,
  term_min_days  integer NOT NULL,
  term_max_days  integer NOT NULL,
  max_approval_pct_of_avg_monthly numeric(5,2) NOT NULL DEFAULT 1.2,
  is_active      boolean NOT NULL DEFAULT true,
  created_at     timestamptz NOT NULL DEFAULT now(),
  updated_at     timestamptz NOT NULL DEFAULT now()
);

-- ============================================================================
-- MODULE 3: COLLECTIONS ENGINE
-- ============================================================================

-- TABLE: collection_cases
CREATE TABLE IF NOT EXISTS collection_cases (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  deal_id         uuid NOT NULL,
  status          text NOT NULL DEFAULT 'soft',
  reason          text NULL,
  dpd             integer NOT NULL DEFAULT 0,
  assigned_to     uuid NULL,
  strategy        text NULL,
  notes           text,
  created_at      timestamptz NOT NULL DEFAULT now(),
  updated_at      timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_collection_cases_deal ON collection_cases(deal_id);

-- TABLE: collection_events
CREATE TABLE IF NOT EXISTS collection_events (
  id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  case_id        uuid NOT NULL REFERENCES collection_cases(id) ON DELETE CASCADE,
  event_type     text NOT NULL,
  channel        text NULL,
  actor_type     text NOT NULL,
  actor_id       uuid NULL,
  payload        jsonb NULL,
  created_at     timestamptz NOT NULL DEFAULT now()
);

-- TABLE: settlements
CREATE TABLE IF NOT EXISTS settlements (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  deal_id         uuid NOT NULL,
  case_id         uuid NULL REFERENCES collection_cases(id) ON DELETE SET NULL,
  settlement_amount numeric(12,2) NOT NULL,
  original_balance  numeric(12,2) NOT NULL,
  discount_pct      numeric(5,2) NOT NULL,
  payment_plan_json jsonb NULL,
  status           text NOT NULL DEFAULT 'pending',
  created_by       uuid NULL,
  created_at       timestamptz NOT NULL DEFAULT now(),
  updated_at       timestamptz NOT NULL DEFAULT now()
);

-- ============================================================================
-- MODULE 4: RENEWAL ENGINE
-- ============================================================================

-- TABLE: renewal_rules
CREATE TABLE IF NOT EXISTS renewal_rules (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  min_paid_pct    numeric(5,2) NOT NULL DEFAULT 0.35,
  max_paid_pct    numeric(5,2) NOT NULL DEFAULT 0.60,
  min_days_since_fund integer NOT NULL DEFAULT 45,
  allow_stack     boolean NOT NULL DEFAULT false,
  is_active       boolean NOT NULL DEFAULT true,
  created_at      timestamptz NOT NULL DEFAULT now(),
  updated_at      timestamptz NOT NULL DEFAULT now()
);

-- TABLE: renewal_offers
CREATE TABLE IF NOT EXISTS renewal_offers (
  id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  original_deal_id uuid NOT NULL,
  lead_id          uuid NOT NULL,
  iso_id           uuid NULL,
  created_by       uuid NULL,
  status           text NOT NULL DEFAULT 'draft',
  offer_json       jsonb NOT NULL,
  triggered_at     timestamptz NOT NULL DEFAULT now(),
  sent_at          timestamptz NULL,
  responded_at     timestamptz NULL,
  notes            text,
  created_at       timestamptz NOT NULL DEFAULT now(),
  updated_at       timestamptz NOT NULL DEFAULT now()
);

-- ============================================================================
-- MODULE 5: INVESTOR & SPV LAYER
-- ============================================================================

-- TABLE: funds
CREATE TABLE IF NOT EXISTS funds (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  code        text NOT NULL,
  name        text NOT NULL,
  description text,
  status      text NOT NULL DEFAULT 'open',
  created_at  timestamptz NOT NULL DEFAULT now(),
  updated_at  timestamptz NOT NULL DEFAULT now()
);

-- TABLE: spvs
CREATE TABLE IF NOT EXISTS spvs (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  fund_id     uuid NOT NULL REFERENCES funds(id) ON DELETE CASCADE,
  code        text NOT NULL,
  name        text NOT NULL,
  description text,
  status      text NOT NULL DEFAULT 'open',
  created_at  timestamptz NOT NULL DEFAULT now(),
  updated_at  timestamptz NOT NULL DEFAULT now()
);

-- TABLE: investors
CREATE TABLE IF NOT EXISTS investors (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name        text NOT NULL,
  email       text NULL,
  phone       text NULL,
  entity_type text NOT NULL DEFAULT 'individual',
  notes       text,
  created_at  timestamptz NOT NULL DEFAULT now(),
  updated_at  timestamptz NOT NULL DEFAULT now()
);

-- TABLE: investor_positions
CREATE TABLE IF NOT EXISTS investor_positions (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  investor_id uuid NOT NULL REFERENCES investors(id) ON DELETE CASCADE,
  fund_id     uuid NULL REFERENCES funds(id) ON DELETE SET NULL,
  spv_id      uuid NULL REFERENCES spvs(id) ON DELETE SET NULL,
  committed   numeric(14,2) NOT NULL,
  contributed numeric(14,2) NOT NULL DEFAULT 0,
  returned    numeric(14,2) NOT NULL DEFAULT 0,
  preferred_return_pct numeric(5,2) NULL,
  created_at  timestamptz NOT NULL DEFAULT now(),
  updated_at  timestamptz NOT NULL DEFAULT now()
);

-- TABLE: fund_deal_allocations
CREATE TABLE IF NOT EXISTS fund_deal_allocations (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  deal_id     uuid NOT NULL,
  fund_id     uuid NULL REFERENCES funds(id),
  spv_id      uuid NULL REFERENCES spvs(id),
  allocated_principal numeric(14,2) NOT NULL,
  participation_pct   numeric(5,2) NULL,
  created_at  timestamptz NOT NULL DEFAULT now()
);

-- ============================================================================
-- MODULE 6: RULE ENGINE
-- ============================================================================

-- TABLE: uw_rule_sets
CREATE TABLE IF NOT EXISTS uw_rule_sets (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name         text NOT NULL,
  description  text,
  version      integer NOT NULL DEFAULT 1,
  is_active    boolean NOT NULL DEFAULT true,
  created_at   timestamptz NOT NULL DEFAULT now(),
  updated_at   timestamptz NOT NULL DEFAULT now()
);

-- TABLE: uw_rules
CREATE TABLE IF NOT EXISTS uw_rules (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  rule_set_id   uuid NOT NULL REFERENCES uw_rule_sets(id) ON DELETE CASCADE,
  scope         text NOT NULL,
  field         text NOT NULL,
  operator      text NOT NULL,
  value_json    jsonb NOT NULL,
  action        text NOT NULL,
  params_json   jsonb NULL,
  priority      integer NOT NULL DEFAULT 100,
  is_active     boolean NOT NULL DEFAULT true,
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now()
);

-- ============================================================================
-- MODULE 7: ISO KNOWLEDGE HUB
-- ============================================================================

-- TABLE: iso_training_modules
CREATE TABLE IF NOT EXISTS iso_training_modules (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  slug        text NOT NULL,
  title       text NOT NULL,
  description text,
  content_md  text NOT NULL,
  is_required boolean NOT NULL DEFAULT true,
  order_index integer NOT NULL DEFAULT 1,
  created_at  timestamptz NOT NULL DEFAULT now(),
  updated_at  timestamptz NOT NULL DEFAULT now()
);

-- TABLE: iso_training_completions
CREATE TABLE IF NOT EXISTS iso_training_completions (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  iso_id      uuid NOT NULL,
  module_id   uuid NOT NULL REFERENCES iso_training_modules(id) ON DELETE CASCADE,
  completed_at timestamptz NOT NULL DEFAULT now(),
  score       numeric(5,2) NULL,
  created_at  timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_iso_training_unique
  ON iso_training_completions(iso_id, module_id);

-- TABLE: iso_statistics
CREATE TABLE IF NOT EXISTS iso_statistics (
  id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  iso_id         uuid NOT NULL,
  deals_submitted integer NOT NULL DEFAULT 0,
  deals_funded    integer NOT NULL DEFAULT 0,
  approval_rate   numeric(5,2) NULL,
  avg_commission  numeric(12,2) NULL,
  last_updated    timestamptz NOT NULL DEFAULT now()
);

-- ============================================================================
-- RLS POLICIES
-- ============================================================================

-- Enable RLS on all new tables
ALTER TABLE compliance_states ENABLE ROW LEVEL SECURITY;
ALTER TABLE compliance_disclosure_templates ENABLE ROW LEVEL SECURITY;
ALTER TABLE compliance_deal_checks ENABLE ROW LEVEL SECURITY;
ALTER TABLE kyc_results ENABLE ROW LEVEL SECURITY;
ALTER TABLE mca_products ENABLE ROW LEVEL SECURITY;
ALTER TABLE risk_tiers ENABLE ROW LEVEL SECURITY;
ALTER TABLE industry_rules ENABLE ROW LEVEL SECURITY;
ALTER TABLE product_pricing_rules ENABLE ROW LEVEL SECURITY;
ALTER TABLE collection_cases ENABLE ROW LEVEL SECURITY;
ALTER TABLE collection_events ENABLE ROW LEVEL SECURITY;
ALTER TABLE settlements ENABLE ROW LEVEL SECURITY;
ALTER TABLE renewal_rules ENABLE ROW LEVEL SECURITY;
ALTER TABLE renewal_offers ENABLE ROW LEVEL SECURITY;
ALTER TABLE funds ENABLE ROW LEVEL SECURITY;
ALTER TABLE spvs ENABLE ROW LEVEL SECURITY;
ALTER TABLE investors ENABLE ROW LEVEL SECURITY;
ALTER TABLE investor_positions ENABLE ROW LEVEL SECURITY;
ALTER TABLE fund_deal_allocations ENABLE ROW LEVEL SECURITY;
ALTER TABLE uw_rule_sets ENABLE ROW LEVEL SECURITY;
ALTER TABLE uw_rules ENABLE ROW LEVEL SECURITY;
ALTER TABLE iso_training_modules ENABLE ROW LEVEL SECURITY;
ALTER TABLE iso_training_completions ENABLE ROW LEVEL SECURITY;
ALTER TABLE iso_statistics ENABLE ROW LEVEL SECURITY;

-- Admin policies for all tables
CREATE POLICY "admin_manage_compliance_states" ON compliance_states FOR ALL USING (has_role(auth.uid(), 'admin'::public.app_role));
CREATE POLICY "admin_manage_disclosure_templates" ON compliance_disclosure_templates FOR ALL USING (has_role(auth.uid(), 'admin'::public.app_role));
CREATE POLICY "admin_manage_compliance_checks" ON compliance_deal_checks FOR ALL USING (has_role(auth.uid(), 'admin'::public.app_role));
CREATE POLICY "admin_manage_kyc_results" ON kyc_results FOR ALL USING (has_role(auth.uid(), 'admin'::public.app_role));
CREATE POLICY "admin_manage_mca_products" ON mca_products FOR ALL USING (has_role(auth.uid(), 'admin'::public.app_role));
CREATE POLICY "admin_manage_risk_tiers" ON risk_tiers FOR ALL USING (has_role(auth.uid(), 'admin'::public.app_role));
CREATE POLICY "admin_manage_industry_rules" ON industry_rules FOR ALL USING (has_role(auth.uid(), 'admin'::public.app_role));
CREATE POLICY "admin_manage_pricing_rules" ON product_pricing_rules FOR ALL USING (has_role(auth.uid(), 'admin'::public.app_role));
CREATE POLICY "admin_manage_collection_cases" ON collection_cases FOR ALL USING (has_role(auth.uid(), 'admin'::public.app_role));
CREATE POLICY "admin_manage_collection_events" ON collection_events FOR ALL USING (has_role(auth.uid(), 'admin'::public.app_role));
CREATE POLICY "admin_manage_settlements" ON settlements FOR ALL USING (has_role(auth.uid(), 'admin'::public.app_role));
CREATE POLICY "admin_manage_renewal_rules" ON renewal_rules FOR ALL USING (has_role(auth.uid(), 'admin'::public.app_role));
CREATE POLICY "admin_manage_renewal_offers" ON renewal_offers FOR ALL USING (has_role(auth.uid(), 'admin'::public.app_role));
CREATE POLICY "admin_manage_funds" ON funds FOR ALL USING (has_role(auth.uid(), 'admin'::public.app_role));
CREATE POLICY "admin_manage_spvs" ON spvs FOR ALL USING (has_role(auth.uid(), 'admin'::public.app_role));
CREATE POLICY "admin_manage_investors" ON investors FOR ALL USING (has_role(auth.uid(), 'admin'::public.app_role));
CREATE POLICY "admin_manage_investor_positions" ON investor_positions FOR ALL USING (has_role(auth.uid(), 'admin'::public.app_role));
CREATE POLICY "admin_manage_fund_allocations" ON fund_deal_allocations FOR ALL USING (has_role(auth.uid(), 'admin'::public.app_role));
CREATE POLICY "admin_manage_uw_rule_sets" ON uw_rule_sets FOR ALL USING (has_role(auth.uid(), 'admin'::public.app_role));
CREATE POLICY "admin_manage_uw_rules" ON uw_rules FOR ALL USING (has_role(auth.uid(), 'admin'::public.app_role));
CREATE POLICY "admin_manage_training_modules" ON iso_training_modules FOR ALL USING (has_role(auth.uid(), 'admin'::public.app_role));
CREATE POLICY "admin_manage_training_completions" ON iso_training_completions FOR ALL USING (has_role(auth.uid(), 'admin'::public.app_role));
CREATE POLICY "admin_manage_iso_statistics" ON iso_statistics FOR ALL USING (has_role(auth.uid(), 'admin'::public.app_role));

-- Worker read policies for relevant tables
CREATE POLICY "workers_read_mca_products" ON mca_products FOR SELECT USING (has_role(auth.uid(), 'worker'::public.app_role) AND is_active = true);
CREATE POLICY "workers_read_risk_tiers" ON risk_tiers FOR SELECT USING (has_role(auth.uid(), 'worker'::public.app_role));
CREATE POLICY "workers_read_training_modules" ON iso_training_modules FOR SELECT USING (true);

-- Underwriter policies
CREATE POLICY "underwriter_read_compliance" ON compliance_states FOR SELECT USING (has_role(auth.uid(), 'underwriter'::public.app_role));
CREATE POLICY "underwriter_read_products" ON mca_products FOR SELECT USING (has_role(auth.uid(), 'underwriter'::public.app_role));
CREATE POLICY "underwriter_read_pricing" ON product_pricing_rules FOR SELECT USING (has_role(auth.uid(), 'underwriter'::public.app_role));
CREATE POLICY "underwriter_read_risk_tiers" ON risk_tiers FOR SELECT USING (has_role(auth.uid(), 'underwriter'::public.app_role));
CREATE POLICY "underwriter_manage_compliance_checks" ON compliance_deal_checks FOR ALL USING (has_role(auth.uid(), 'underwriter'::public.app_role));

-- ISO partner policies
CREATE POLICY "iso_read_own_statistics" ON iso_statistics FOR SELECT USING (iso_id IN (SELECT id FROM iso_partners WHERE user_id = auth.uid()));
CREATE POLICY "iso_read_training_modules" ON iso_training_modules FOR SELECT USING (true);
CREATE POLICY "iso_manage_own_completions" ON iso_training_completions FOR ALL USING (iso_id IN (SELECT id FROM iso_partners WHERE user_id = auth.uid()));

-- Seed default data
INSERT INTO renewal_rules (min_paid_pct, max_paid_pct, min_days_since_fund, allow_stack, is_active)
VALUES (0.35, 0.60, 45, false, true)
ON CONFLICT DO NOTHING;

INSERT INTO uw_rule_sets (name, description, version, is_active)
VALUES ('Standard MCA v1', 'Default underwriting rules for MCA products', 1, true)
ON CONFLICT DO NOTHING;

INSERT INTO risk_tiers (code, description, min_score, max_score, default_factor_rate_min, default_factor_rate_max, default_term_min_days, default_term_max_days) VALUES
('A', 'Premium tier - low risk', 80, 100, 1.15, 1.25, 90, 180),
('B', 'Standard tier - moderate risk', 60, 79, 1.25, 1.35, 60, 120),
('C', 'Subprime tier - higher risk', 40, 59, 1.35, 1.45, 45, 90),
('D', 'High risk tier', 0, 39, 1.45, 1.55, 30, 60)
ON CONFLICT DO NOTHING;

INSERT INTO mca_products (code, name, description, is_active) VALUES
('STD_MCA', 'Standard MCA', 'Standard merchant cash advance with daily ACH', true),
('REV_SPLIT', 'Revenue Split', 'Percentage of daily credit card sales', true),
('LOCKBOX', 'Lockbox', 'Lockbox arrangement with split deposits', true),
('CONSOLIDATION', 'Consolidation', 'Consolidate existing positions', true),
('SECOND_POS', 'Second Position', 'Second position behind existing funder', true)
ON CONFLICT DO NOTHING;

-- =================================================================
-- MIGRATION: 20251206143642_53ce5da5-7e8a-4e67-9f2f-c2938e60ac88.sql
-- =================================================================
-- System Settings table for global mode control
CREATE TABLE IF NOT EXISTS system_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  key text NOT NULL UNIQUE,
  value_json jsonb NOT NULL,
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE system_settings ENABLE ROW LEVEL SECURITY;

-- Admin can read/write
CREATE POLICY "Admins can manage system_settings"
  ON system_settings FOR ALL
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'admin'
    )
  );

-- Workers can read mode (needed for autopilot behavior)
CREATE POLICY "Workers can read system_settings"
  ON system_settings FOR SELECT
  USING (auth.uid() IS NOT NULL);

-- Seed default mode = AUTOPILOT
INSERT INTO system_settings (key, value_json)
VALUES ('system_mode', '{"mode":"AUTOPILOT"}'::jsonb)
ON CONFLICT (key) DO NOTHING;

-- Seed owner optimization pin
INSERT INTO system_settings (key, value_json)
VALUES ('optimization_pin', '{"pin":"555"}'::jsonb)
ON CONFLICT (key) DO NOTHING;

-- =================================================================
-- MIGRATION: 20251206144857_2ec51ab8-6797-4828-9ef8-ef0053a7c6b2.sql
-- =================================================================
-- Activity log table for tracking all AI actions and proposals
CREATE TABLE IF NOT EXISTS public.activity_log (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  created_at timestamptz DEFAULT now(),
  module text NOT NULL,
  actor text NOT NULL,
  mode text NOT NULL,
  severity text NOT NULL,
  title text NOT NULL,
  summary text NOT NULL,
  proposed_action text NULL,
  auto_executed boolean DEFAULT false,
  metadata jsonb DEFAULT '{}'::jsonb
);

-- Enable RLS
ALTER TABLE public.activity_log ENABLE ROW LEVEL SECURITY;

-- Index for latest events
CREATE INDEX idx_activity_log_created_at ON public.activity_log (created_at DESC);
CREATE INDEX idx_activity_log_module ON public.activity_log (module, created_at DESC);

-- RLS policies - admin can do everything, authenticated users can read
CREATE POLICY "Admin full access to activity_log" ON public.activity_log
  FOR ALL USING (
    EXISTS (SELECT 1 FROM user_roles WHERE user_id = auth.uid() AND role = 'admin')
  );

CREATE POLICY "Authenticated users can read activity_log" ON public.activity_log
  FOR SELECT USING (auth.uid() IS NOT NULL);

-- Allow inserts from edge functions (service role)
CREATE POLICY "Service role can insert activity_log" ON public.activity_log
  FOR INSERT WITH CHECK (true);

-- =================================================================
-- MIGRATION: 20251206150909_396b61df-8700-4913-acef-bf66ce46f1df.sql
-- =================================================================
-- Advanced System Mode Settings - update existing seeds
-- Seed / upsert core mode settings for execution_mode, strategy_profile, owner_mode

INSERT INTO public.system_settings (key, value_json)
VALUES
  ('execution_mode', '{"mode": "AUTOPILOT"}'::jsonb),
  ('strategy_profile', '{"profile": "STANDARD"}'::jsonb),
  ('owner_mode', '{"status": "LOCKED"}'::jsonb)
ON CONFLICT (key) DO UPDATE
SET value_json = EXCLUDED.value_json;

-- Create activity_events table for enhanced activity logging with mode metadata
CREATE TABLE IF NOT EXISTS public.activity_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  created_at timestamptz NOT NULL DEFAULT now(),

  -- actor
  actor_type text NOT NULL,               -- 'ADMIN' | 'WORKER' | 'AI' | 'SYSTEM'
  actor_id uuid NULL,                     -- optional user id

  -- what happened
  scope text NOT NULL,                    -- 'UNDERWRITING' | 'COLLECTIONS' | 'RENEWALS' | 'CREDIT_REPAIR' | 'SYSTEM_MODE' | 'LEADS' | 'GENERAL'
  event_type text NOT NULL,               -- 'DECISION' | 'ACTION' | 'MODE_CHANGE' | 'SUMMARY' | 'JOB_RUN'
  decision text NULL,                     -- 'APPROVED' | 'DECLINED' | 'ESCALATED' | 'AUTO_ACTION' | 'INFO'
  severity text NULL,                     -- 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL'

  -- business context
  lead_id uuid NULL,
  deal_id uuid NULL,
  iso_id uuid NULL,

  -- MODE SNAPSHOT at the moment of event
  execution_mode text NOT NULL DEFAULT 'AUTOPILOT',   -- MANUAL | AUTOPILOT
  strategy_profile text NOT NULL DEFAULT 'STANDARD',  -- STANDARD | ECO | AGGRESSIVE
  owner_mode text NOT NULL DEFAULT 'LOCKED',          -- LOCKED | OPTIMIZATION

  -- human-readable + machine-readable
  summary text NOT NULL,
  details_json jsonb NULL
);

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_activity_events_created_at ON public.activity_events (created_at DESC);
CREATE INDEX IF NOT EXISTS idx_activity_events_scope ON public.activity_events (scope, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_activity_events_execution_mode ON public.activity_events (execution_mode);
CREATE INDEX IF NOT EXISTS idx_activity_events_decision ON public.activity_events (decision);

-- Enable RLS
ALTER TABLE public.activity_events ENABLE ROW LEVEL SECURITY;

-- RLS policies for activity_events
CREATE POLICY "admins_can_read_activity_events"
ON public.activity_events
FOR SELECT
USING (
  EXISTS (
    SELECT 1 FROM public.user_roles
    WHERE user_id = auth.uid()
    AND role = 'admin'
    AND approved = true
  )
);

CREATE POLICY "system_can_insert_activity_events"
ON public.activity_events
FOR INSERT
WITH CHECK (true);

-- Allow workers to read their own events
CREATE POLICY "users_can_read_own_activity_events"
ON public.activity_events
FOR SELECT
USING (actor_id = auth.uid());

-- =================================================================
-- MIGRATION: 20251206163507_cdac218b-0240-4d4d-8610-71284dae522b.sql
-- =================================================================
-- System Optimization Suggestions table for 555 mode
CREATE TABLE IF NOT EXISTS public.system_optimization_suggestions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  created_at timestamptz DEFAULT now(),
  scope text NOT NULL, -- 'COLLECTIONS' | 'RENEWALS' | 'LEADS' | 'CREDIT_REPAIR'
  suggestion_type text NOT NULL, -- 'INCREASE_VOLUME' | 'DECREASE_VOLUME' | 'ADJUST_RENEWAL_FACTOR' | etc.
  current_value jsonb,
  proposed_value jsonb,
  rationale text,
  status text DEFAULT 'pending', -- 'pending' | 'applied' | 'rejected'
  applied_at timestamptz,
  applied_by uuid REFERENCES auth.users(id)
);

-- Enable RLS
ALTER TABLE public.system_optimization_suggestions ENABLE ROW LEVEL SECURITY;

-- Only admins can view/manage suggestions
CREATE POLICY "Admins can read optimization suggestions"
  ON public.system_optimization_suggestions
  FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM public.user_roles
      WHERE user_id = auth.uid()
      AND role = 'admin'
      AND approved = true
    )
  );

CREATE POLICY "Admins can insert optimization suggestions"
  ON public.system_optimization_suggestions
  FOR INSERT
  WITH CHECK (true);

CREATE POLICY "Admins can update optimization suggestions"
  ON public.system_optimization_suggestions
  FOR UPDATE
  USING (
    EXISTS (
      SELECT 1 FROM public.user_roles
      WHERE user_id = auth.uid()
      AND role = 'admin'
      AND approved = true
    )
  );

-- Index for efficient queries
CREATE INDEX idx_system_optimization_suggestions_status 
  ON public.system_optimization_suggestions(status);
CREATE INDEX idx_system_optimization_suggestions_scope 
  ON public.system_optimization_suggestions(scope);

-- =================================================================
-- MIGRATION: 20251206213810_5b756b33-5b91-43de-b7f5-8e17e26ef7f2.sql
-- =================================================================
-- Create templates master library table
CREATE TABLE IF NOT EXISTS public.templates_master_library (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  category text NOT NULL,
  name text NOT NULL,
  version int NOT NULL DEFAULT 1,
  channel text NOT NULL,
  storage_path text,
  subject text,
  body text,
  placeholders jsonb NOT NULL DEFAULT '[]',
  created_at timestamp with time zone DEFAULT now(),
  updated_at timestamp with time zone DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.templates_master_library ENABLE ROW LEVEL SECURITY;

-- Admin full access
CREATE POLICY "Admins can manage templates"
ON public.templates_master_library
FOR ALL
USING (has_role(auth.uid(), 'admin'::public.app_role));

-- Workers can read templates
CREATE POLICY "Workers can read templates"
ON public.templates_master_library
FOR SELECT
USING (has_role(auth.uid(), 'worker'::public.app_role) OR has_role(auth.uid(), 'credit_repair_specialist'::public.app_role));

-- Create storage bucket for templates
INSERT INTO storage.buckets (id, name, public)
VALUES ('templates-library', 'templates-library', false)
ON CONFLICT (id) DO NOTHING;

-- Storage policies for templates-library bucket
CREATE POLICY "Admins can upload templates"
ON storage.objects
FOR INSERT
WITH CHECK (bucket_id = 'templates-library' AND has_role(auth.uid(), 'admin'::public.app_role));

CREATE POLICY "Admins can update templates"
ON storage.objects
FOR UPDATE
USING (bucket_id = 'templates-library' AND has_role(auth.uid(), 'admin'::public.app_role));

CREATE POLICY "Admins can delete templates"
ON storage.objects
FOR DELETE
USING (bucket_id = 'templates-library' AND has_role(auth.uid(), 'admin'::public.app_role));

CREATE POLICY "Authenticated users can read templates"
ON storage.objects
FOR SELECT
USING (bucket_id = 'templates-library' AND auth.role() = 'authenticated');

-- Create generated-documents bucket
INSERT INTO storage.buckets (id, name, public)
VALUES ('generated-documents', 'generated-documents', false)
ON CONFLICT (id) DO NOTHING;

-- Storage policies for generated-documents bucket
CREATE POLICY "Authenticated users can upload generated docs"
ON storage.objects
FOR INSERT
WITH CHECK (bucket_id = 'generated-documents' AND auth.role() = 'authenticated');

CREATE POLICY "Users can read own generated docs"
ON storage.objects
FOR SELECT
USING (bucket_id = 'generated-documents' AND auth.role() = 'authenticated');

-- Trigger for updated_at
CREATE TRIGGER update_templates_master_library_updated_at
BEFORE UPDATE ON public.templates_master_library
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- =================================================================
-- MIGRATION: 20251206235405_38f5e72e-4163-470c-aab6-d4a5882f1740.sql
-- =================================================================
-- Add mode and is_active columns to templates_master_library
ALTER TABLE public.templates_master_library 
ADD COLUMN IF NOT EXISTS mode text DEFAULT 'STANDARD',
ADD COLUMN IF NOT EXISTS is_active boolean DEFAULT true;

-- Create template-uploads bucket for raw uploaded templates (if not exists)
INSERT INTO storage.buckets (id, name, public)
VALUES ('template-uploads', 'template-uploads', false)
ON CONFLICT (id) DO NOTHING;

-- =================================================================
-- MIGRATION: 20251207044157_134bae90-adc9-4d06-8f5b-d742807d62e6.sql
-- =================================================================
-- ===================================================================
-- PHASE 1 MIGRATION: Wolf Fund Universal File System
-- ===================================================================

-- STEP 1: Add new roles to app_role enum
ALTER TYPE public.app_role ADD VALUE IF NOT EXISTS 'owner';
ALTER TYPE public.app_role ADD VALUE IF NOT EXISTS 'legal';
ALTER TYPE public.app_role ADD VALUE IF NOT EXISTS 'tenant_admin';
ALTER TYPE public.app_role ADD VALUE IF NOT EXISTS 'iso_partner';

-- STEP 2: Create security definer functions
-- ===================================================================
-- VAULT_ID COLUMN DOCUMENTATION
-- 
-- IMPORTANT: There are TWO columns named "vault_id" in this schema:
--
-- 1. intake_clients.vault_id (e.g. "WF-000001")
--    - This is the UNIVERSAL WOLF FILE NUMBER
--    - Human-facing identifier used in UI, Puzzle Panel, Motherboard
--    - All system joins should reference intake_clients.id (UUID) 
--      or intake_clients.vault_id (human-readable)
--
-- 2. client_vault.vault_id
--    - This is an INTERNAL PII VAULT identifier
--    - Used only within the client_vault table for legacy compatibility
--    - NOT the global Wolf File ID
--    - Should NOT be used for cross-table joins
--
-- RULE: Always join via intake_clients.id or intake_clients.vault_id
--       Never use client_vault.vault_id as a universal anchor
-- ===================================================================

-- Check if current user is OWNER (God mode)
CREATE OR REPLACE FUNCTION public.is_owner()
RETURNS BOOLEAN AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 FROM public.user_roles
    WHERE user_id = auth.uid() 
      AND role = 'owner'::public.app_role
      AND approved = true
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER STABLE SET search_path = public;

-- Check if current user has legal role
CREATE OR REPLACE FUNCTION public.is_legal()
RETURNS BOOLEAN AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 FROM public.user_roles
    WHERE user_id = auth.uid() 
      AND role = 'legal'::public.app_role
      AND approved = true
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER STABLE SET search_path = public;

-- Get current user's tenant_id
CREATE OR REPLACE FUNCTION public.user_tenant_id()
RETURNS UUID AS $$
BEGIN
  RETURN (
    SELECT tenant_id FROM public.wf_tenant_users
    WHERE user_id = auth.uid()
    LIMIT 1
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER STABLE SET search_path = public;

-- Check if user can access a specific tenant
CREATE OR REPLACE FUNCTION public.can_access_tenant(tid UUID)
RETURNS BOOLEAN AS $$
BEGIN
  -- OWNER can access ALL tenants
  IF public.is_owner() THEN RETURN TRUE; END IF;
  -- Others can only access their own tenant
  RETURN public.user_tenant_id() = tid;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER STABLE SET search_path = public;

-- STEP 3: Add tenant_id columns to all tenant-scoped tables
ALTER TABLE public.intake_clients ADD COLUMN IF NOT EXISTS tenant_id UUID REFERENCES public.wf_tenants(id);
ALTER TABLE public.client_vault ADD COLUMN IF NOT EXISTS tenant_id UUID REFERENCES public.wf_tenants(id);
ALTER TABLE public.fast_track_applications ADD COLUMN IF NOT EXISTS tenant_id UUID REFERENCES public.wf_tenants(id);
ALTER TABLE public.deals ADD COLUMN IF NOT EXISTS tenant_id UUID REFERENCES public.wf_tenants(id);
ALTER TABLE public.credit_repair_cases ADD COLUMN IF NOT EXISTS tenant_id UUID REFERENCES public.wf_tenants(id);
ALTER TABLE public.collection_cases ADD COLUMN IF NOT EXISTS tenant_id UUID REFERENCES public.wf_tenants(id);
ALTER TABLE public.audit_logs ADD COLUMN IF NOT EXISTS tenant_id UUID REFERENCES public.wf_tenants(id);
ALTER TABLE public.funded_contracts ADD COLUMN IF NOT EXISTS tenant_id UUID REFERENCES public.wf_tenants(id);
ALTER TABLE public.outreach_tasks ADD COLUMN IF NOT EXISTS tenant_id UUID REFERENCES public.wf_tenants(id);

-- STEP 4: Add vault_id to intake_clients + create sequence
CREATE SEQUENCE IF NOT EXISTS public.wolf_file_seq START 100;

ALTER TABLE public.intake_clients ADD COLUMN IF NOT EXISTS vault_id TEXT UNIQUE;

-- STEP 5: Add intake_client_id columns
ALTER TABLE public.fast_track_applications ADD COLUMN IF NOT EXISTS intake_client_id UUID REFERENCES public.intake_clients(id);
ALTER TABLE public.deals ADD COLUMN IF NOT EXISTS intake_client_id UUID REFERENCES public.intake_clients(id);
ALTER TABLE public.credit_repair_cases ADD COLUMN IF NOT EXISTS intake_client_id UUID REFERENCES public.intake_clients(id);
ALTER TABLE public.collection_cases ADD COLUMN IF NOT EXISTS intake_client_id UUID REFERENCES public.intake_clients(id);
ALTER TABLE public.funded_contracts ADD COLUMN IF NOT EXISTS intake_client_id UUID REFERENCES public.intake_clients(id);
ALTER TABLE public.outreach_tasks ADD COLUMN IF NOT EXISTS intake_client_id UUID REFERENCES public.intake_clients(id);

-- STEP 6: Add audit_logs extensions
ALTER TABLE public.audit_logs ADD COLUMN IF NOT EXISTS intake_client_id UUID REFERENCES public.intake_clients(id);
ALTER TABLE public.audit_logs ADD COLUMN IF NOT EXISTS table_name TEXT;
ALTER TABLE public.audit_logs ADD COLUMN IF NOT EXISTS previous_values JSONB;

-- STEP 7: Create all indexes
CREATE INDEX IF NOT EXISTS idx_intake_clients_tenant ON public.intake_clients(tenant_id);
CREATE INDEX IF NOT EXISTS idx_intake_clients_vault_id ON public.intake_clients(vault_id);
CREATE INDEX IF NOT EXISTS idx_client_vault_tenant ON public.client_vault(tenant_id);
CREATE INDEX IF NOT EXISTS idx_fta_tenant_intake ON public.fast_track_applications(tenant_id, intake_client_id);
CREATE INDEX IF NOT EXISTS idx_deals_tenant_intake ON public.deals(tenant_id, intake_client_id);
CREATE INDEX IF NOT EXISTS idx_crc_tenant_intake ON public.credit_repair_cases(tenant_id, intake_client_id);
CREATE INDEX IF NOT EXISTS idx_cc_tenant_intake ON public.collection_cases(tenant_id, intake_client_id);
CREATE INDEX IF NOT EXISTS idx_fc_tenant_intake ON public.funded_contracts(tenant_id, intake_client_id);
CREATE INDEX IF NOT EXISTS idx_ot_tenant_intake ON public.outreach_tasks(tenant_id, intake_client_id);
CREATE INDEX IF NOT EXISTS idx_audit_logs_tenant ON public.audit_logs(tenant_id);
CREATE INDEX IF NOT EXISTS idx_audit_logs_intake_client ON public.audit_logs(intake_client_id);
CREATE INDEX IF NOT EXISTS idx_audit_logs_action_type ON public.audit_logs(action_type);

-- STEP 8: RLS Policies for intake_clients
DROP POLICY IF EXISTS "Owner sees all intake_clients" ON public.intake_clients;
DROP POLICY IF EXISTS "Tenant users see own tenant intake_clients" ON public.intake_clients;

CREATE POLICY "Owner sees all intake_clients"
  ON public.intake_clients FOR ALL
  USING (public.is_owner());

CREATE POLICY "Tenant users see own tenant intake_clients"
  ON public.intake_clients FOR ALL
  USING (public.can_access_tenant(tenant_id));

-- STEP 9: RLS Policies for client_vault (OWNER + LEGAL only)
DROP POLICY IF EXISTS "Only admins can manage client vault" ON public.client_vault;
DROP POLICY IF EXISTS "Only admins can view client vault" ON public.client_vault;
DROP POLICY IF EXISTS "Owner full vault access" ON public.client_vault;
DROP POLICY IF EXISTS "Legal read vault" ON public.client_vault;

CREATE POLICY "Owner full vault access"
  ON public.client_vault FOR ALL
  USING (public.is_owner());

CREATE POLICY "Legal read vault"
  ON public.client_vault FOR SELECT
  USING (public.is_legal() AND public.can_access_tenant(tenant_id));

-- STEP 10: RLS Policies for audit_logs (OWNER reads, all authenticated insert)
DROP POLICY IF EXISTS "Admin full access to audit_logs" ON public.audit_logs;
DROP POLICY IF EXISTS "Owner reads all audit_logs" ON public.audit_logs;
DROP POLICY IF EXISTS "Authenticated insert audit_logs" ON public.audit_logs;

CREATE POLICY "Owner reads all audit_logs"
  ON public.audit_logs FOR SELECT
  USING (public.is_owner());

CREATE POLICY "Authenticated insert audit_logs"
  ON public.audit_logs FOR INSERT
  WITH CHECK (auth.uid() IS NOT NULL);

-- STEP 11: Prevent UPDATE/DELETE on audit_logs
CREATE OR REPLACE RULE "No updates to audit_logs" AS ON UPDATE TO public.audit_logs DO INSTEAD NOTHING;
CREATE OR REPLACE RULE "No deletes from audit_logs" AS ON DELETE TO public.audit_logs DO INSTEAD NOTHING;

