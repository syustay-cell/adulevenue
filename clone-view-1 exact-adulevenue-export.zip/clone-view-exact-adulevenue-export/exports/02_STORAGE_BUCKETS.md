# Storage Buckets Configuration

**Project Ref:** tdzuhcswrojlleeupqvd  
**Export Date:** 2025-12-14  

## Buckets

| Bucket Name | Public |
|-------------|--------|
| fast-track-documents | No |
| loan-application-documents | No |
| credit-repair-documents | No |
| iso-partner-documents | No |
| lead-imports | No |
| lead-lists | No |
| lead-files | No |
| deal-contracts | No |
| wolf_documents | No |
| templates-library | No |
| generated-documents | No |
| template-uploads | No |

## Recreation SQL

```sql
-- Create storage buckets
INSERT INTO storage.buckets (id, name, public) VALUES 
  ('fast-track-documents', 'fast-track-documents', false),
  ('loan-application-documents', 'loan-application-documents', false),
  ('credit-repair-documents', 'credit-repair-documents', false),
  ('iso-partner-documents', 'iso-partner-documents', false),
  ('lead-imports', 'lead-imports', false),
  ('lead-lists', 'lead-lists', false),
  ('lead-files', 'lead-files', false),
  ('deal-contracts', 'deal-contracts', false),
  ('wolf_documents', 'wolf_documents', false),
  ('templates-library', 'templates-library', false),
  ('generated-documents', 'generated-documents', false),
  ('template-uploads', 'template-uploads', false);
```

---
**Note:** Storage policies must be created separately based on your RLS requirements.
