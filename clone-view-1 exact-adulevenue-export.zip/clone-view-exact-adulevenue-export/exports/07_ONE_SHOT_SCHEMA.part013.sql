-- =================================================================
-- MIGRATION: 20251207045722_816ef3e3-1a90-46b8-93a2-1116c6fef06f.sql
-- =================================================================
-- ===================================================================
-- PHASE 1 MIGRATION: Wolf Fund Universal File System (FINAL FULL PACKAGE)
-- ===================================================================

-- STEP 1: Add new roles to app_role enum (IF NOT EXISTS handles duplicates)
DO $$ BEGIN
  ALTER TYPE public.app_role ADD VALUE IF NOT EXISTS 'owner';
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  ALTER TYPE public.app_role ADD VALUE IF NOT EXISTS 'legal';
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  ALTER TYPE public.app_role ADD VALUE IF NOT EXISTS 'tenant_admin';
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  ALTER TYPE public.app_role ADD VALUE IF NOT EXISTS 'iso_partner';
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

-- ===================================================================
-- VAULT_ID COLUMN DOCUMENTATION
--
-- IMPORTANT: TWO vault_id columns exist:
--
-- 1. intake_clients.vault_id  → The official Wolf File ID (WF-000001)
--    • Human-facing ID
--    • Main system anchor for all apps
--
-- 2. client_vault.vault_id    → Internal legacy reference
--    • NOT a universal ID
--    • NOT used for joins
--
-- RULE: Always join via intake_clients.id or intake_clients.vault_id
-- ===================================================================

-- ===================================================================
-- SECURITY DEFINER FUNCTIONS (CREATE OR REPLACE handles existing)
-- ===================================================================

CREATE OR REPLACE FUNCTION public.is_owner()
RETURNS BOOLEAN AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 FROM public.user_roles
    WHERE user_id = auth.uid() AND role = 'owner'::public.app_role AND approved = true
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER STABLE SET search_path = public;

CREATE OR REPLACE FUNCTION public.is_legal()
RETURNS BOOLEAN AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 FROM public.user_roles
    WHERE user_id = auth.uid() AND role = 'legal'::public.app_role AND approved = true
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER STABLE SET search_path = public;

CREATE OR REPLACE FUNCTION public.user_tenant_id()
RETURNS UUID AS $$
BEGIN
  RETURN (
    SELECT tenant_id FROM public.wf_tenant_users
    WHERE user_id = auth.uid()
    LIMIT 1
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER STABLE SET search_path = public;

CREATE OR REPLACE FUNCTION public.can_access_tenant(tid UUID)
RETURNS BOOLEAN AS $$
BEGIN
  IF public.is_owner() THEN RETURN TRUE; END IF;
  RETURN public.user_tenant_id() = tid;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER STABLE SET search_path = public;

-- ===================================================================
-- STEP 3: Add tenant_id columns (IF NOT EXISTS handles existing)
-- ===================================================================

ALTER TABLE public.intake_clients ADD COLUMN IF NOT EXISTS tenant_id UUID REFERENCES public.wf_tenants(id);
ALTER TABLE public.client_vault ADD COLUMN IF NOT EXISTS tenant_id UUID REFERENCES public.wf_tenants(id);
ALTER TABLE public.fast_track_applications ADD COLUMN IF NOT EXISTS tenant_id UUID REFERENCES public.wf_tenants(id);
ALTER TABLE public.deals ADD COLUMN IF NOT EXISTS tenant_id UUID REFERENCES public.wf_tenants(id);
ALTER TABLE public.credit_repair_cases ADD COLUMN IF NOT EXISTS tenant_id UUID REFERENCES public.wf_tenants(id);
ALTER TABLE public.collection_cases ADD COLUMN IF NOT EXISTS tenant_id UUID REFERENCES public.wf_tenants(id);
ALTER TABLE public.audit_logs ADD COLUMN IF NOT EXISTS tenant_id UUID REFERENCES public.wf_tenants(id);
ALTER TABLE public.funded_contracts ADD COLUMN IF NOT EXISTS tenant_id UUID REFERENCES public.wf_tenants(id);
ALTER TABLE public.outreach_tasks ADD COLUMN IF NOT EXISTS tenant_id UUID REFERENCES public.wf_tenants(id);

-- ===================================================================
-- STEP 4: Add vault_id to intake_clients
-- ===================================================================

CREATE SEQUENCE IF NOT EXISTS public.wolf_file_seq START 100;

ALTER TABLE public.intake_clients ADD COLUMN IF NOT EXISTS vault_id TEXT UNIQUE;

-- Backfill vault_id for any rows missing it
UPDATE public.intake_clients
SET vault_id = 'WF-' || LPAD(nextval('public.wolf_file_seq')::TEXT, 6, '0')
WHERE vault_id IS NULL;

-- ===================================================================
-- STEP 5: Add intake_client_id columns
-- ===================================================================

ALTER TABLE public.fast_track_applications ADD COLUMN IF NOT EXISTS intake_client_id UUID REFERENCES public.intake_clients(id);
ALTER TABLE public.deals ADD COLUMN IF NOT EXISTS intake_client_id UUID REFERENCES public.intake_clients(id);
ALTER TABLE public.credit_repair_cases ADD COLUMN IF NOT EXISTS intake_client_id UUID REFERENCES public.intake_clients(id);
ALTER TABLE public.collection_cases ADD COLUMN IF NOT EXISTS intake_client_id UUID REFERENCES public.intake_clients(id);
ALTER TABLE public.funded_contracts ADD COLUMN IF NOT EXISTS intake_client_id UUID REFERENCES public.intake_clients(id);
ALTER TABLE public.outreach_tasks ADD COLUMN IF NOT EXISTS intake_client_id UUID REFERENCES public.intake_clients(id);

-- ===================================================================
-- STEP 6: Audit logs enhancements
-- ===================================================================

ALTER TABLE public.audit_logs ADD COLUMN IF NOT EXISTS intake_client_id UUID REFERENCES public.intake_clients(id);
ALTER TABLE public.audit_logs ADD COLUMN IF NOT EXISTS table_name TEXT;
ALTER TABLE public.audit_logs ADD COLUMN IF NOT EXISTS previous_values JSONB;

-- ===================================================================
-- STEP 7: Indexes
-- ===================================================================

CREATE INDEX IF NOT EXISTS idx_intake_clients_tenant ON public.intake_clients(tenant_id);
CREATE INDEX IF NOT EXISTS idx_intake_clients_vault_id ON public.intake_clients(vault_id);
CREATE INDEX IF NOT EXISTS idx_client_vault_tenant ON public.client_vault(tenant_id);
CREATE INDEX IF NOT EXISTS idx_fta_tenant_intake ON public.fast_track_applications(tenant_id, intake_client_id);
CREATE INDEX IF NOT EXISTS idx_deals_tenant_intake ON public.deals(tenant_id, intake_client_id);
CREATE INDEX IF NOT EXISTS idx_crc_tenant_intake ON public.credit_repair_cases(tenant_id, intake_client_id);
CREATE INDEX IF NOT EXISTS idx_cc_tenant_intake ON public.collection_cases(tenant_id, intake_client_id);
CREATE INDEX IF NOT EXISTS idx_fc_tenant_intake ON public.funded_contracts(tenant_id, intake_client_id);
CREATE INDEX IF NOT EXISTS idx_ot_tenant_intake ON public.outreach_tasks(tenant_id, intake_client_id);
CREATE INDEX IF NOT EXISTS idx_audit_logs_tenant ON public.audit_logs(tenant_id);
CREATE INDEX IF NOT EXISTS idx_audit_logs_intake_client ON public.audit_logs(intake_client_id);
CREATE INDEX IF NOT EXISTS idx_audit_logs_action_type ON public.audit_logs(action_type);

-- ===================================================================
-- STEP 8: RLS for intake_clients
-- ===================================================================

DROP POLICY IF EXISTS "Owner sees all intake_clients" ON public.intake_clients;
DROP POLICY IF EXISTS "Tenant users see own tenant intake_clients" ON public.intake_clients;

CREATE POLICY "Owner sees all intake_clients"
  ON public.intake_clients FOR ALL
  USING (public.is_owner());

CREATE POLICY "Tenant users see own tenant intake_clients"
  ON public.intake_clients FOR ALL
  USING (public.can_access_tenant(tenant_id));

-- ===================================================================
-- STEP 9: RLS for client_vault (OWNER + LEGAL ONLY)
-- ===================================================================

DROP POLICY IF EXISTS "Only admins can manage client vault" ON public.client_vault;
DROP POLICY IF EXISTS "Only admins can view client vault" ON public.client_vault;
DROP POLICY IF EXISTS "Owner full vault access" ON public.client_vault;
DROP POLICY IF EXISTS "Legal read vault" ON public.client_vault;

CREATE POLICY "Owner full vault access"
  ON public.client_vault FOR ALL
  USING (public.is_owner());

CREATE POLICY "Legal read vault"
  ON public.client_vault FOR SELECT
  USING (public.is_legal() AND public.can_access_tenant(tenant_id));

-- ===================================================================
-- STEP 10: RLS for audit_logs
-- ===================================================================

DROP POLICY IF EXISTS "Admin full access to audit_logs" ON public.audit_logs;
DROP POLICY IF EXISTS "Owner reads all audit_logs" ON public.audit_logs;
DROP POLICY IF EXISTS "Authenticated insert audit_logs" ON public.audit_logs;

CREATE POLICY "Owner reads all audit_logs"
  ON public.audit_logs FOR SELECT
  USING (public.is_owner());

CREATE POLICY "Authenticated insert audit_logs"
  ON public.audit_logs FOR INSERT
  WITH CHECK (auth.uid() IS NOT NULL);

-- Immutability rules for audit_logs
CREATE OR REPLACE RULE "No updates to audit_logs" AS ON UPDATE TO public.audit_logs DO INSTEAD NOTHING;
CREATE OR REPLACE RULE "No deletes from audit_logs" AS ON DELETE TO public.audit_logs DO INSTEAD NOTHING;

-- =================================================================
-- MIGRATION: 20251207061405_220b519b-512f-448f-890a-2d3d269caeb2.sql
-- =================================================================
-- Create user_settings table for audio accessibility preferences
CREATE TABLE IF NOT EXISTS public.user_settings (
  user_id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  auto_tts_enabled BOOLEAN NOT NULL DEFAULT false,
  tts_voice TEXT DEFAULT 'nova',
  tts_speed NUMERIC(3,2) DEFAULT 1.0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.user_settings ENABLE ROW LEVEL SECURITY;

-- Users can only read/update their own settings
CREATE POLICY "Users can view own settings"
  ON public.user_settings FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own settings"
  ON public.user_settings FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own settings"
  ON public.user_settings FOR UPDATE
  USING (auth.uid() = user_id);

-- Auto-update updated_at
CREATE TRIGGER update_user_settings_updated_at
  BEFORE UPDATE ON public.user_settings
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

-- =================================================================
-- MIGRATION: 20251207170658_7881f272-e84d-49d8-9fdb-6081e535d014.sql
-- =================================================================
-- wf_events: generic event bus for the entire Wolf ecosystem
CREATE TABLE IF NOT EXISTS public.wf_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid REFERENCES public.wf_tenants(id) ON DELETE CASCADE,
  user_id uuid REFERENCES auth.users(id),
  role text CHECK (role IN ('owner', 'admin', 'worker', 'credit_specialist', 'underwriter')),

  -- event classification
  event_type text NOT NULL,
  source text NOT NULL,
  severity text DEFAULT 'info' CHECK (severity IN ('info', 'warning', 'success', 'critical')),

  -- references to underlying entities (nullable)
  deal_id uuid,
  credit_case_id uuid,
  collection_case_id uuid,
  application_id uuid,
  task_id uuid,

  -- payload data
  title text NOT NULL,
  description text,
  meta jsonb DEFAULT '{}'::jsonb,

  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_wf_events_tenant_created ON public.wf_events (tenant_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_wf_events_type ON public.wf_events (event_type, source);

ALTER TABLE public.wf_events ENABLE ROW LEVEL SECURITY;

-- Owner/Admin can see all events in their tenants
CREATE POLICY "wf_events_owner_admin_select" ON public.wf_events FOR SELECT
USING (
  has_role(auth.uid(), 'admin'::public.app_role) OR has_role(auth.uid(), 'owner'::public.app_role)
);

-- Workers can see their own events
CREATE POLICY "wf_events_worker_self" ON public.wf_events FOR SELECT
USING (auth.uid() = user_id);

-- System can insert events
CREATE POLICY "wf_events_system_insert" ON public.wf_events FOR INSERT
WITH CHECK (true);

-- wf_suggestions: system-generated or AI-generated next actions
CREATE TABLE IF NOT EXISTS public.wf_suggestions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid REFERENCES public.wf_tenants(id) ON DELETE CASCADE,
  user_id uuid REFERENCES auth.users(id),
  role text,
  scope text NOT NULL CHECK (scope IN ('owner', 'admin', 'worker', 'global')),
  category text NOT NULL,
  title text NOT NULL,
  body text,
  suggested_value jsonb DEFAULT '{}'::jsonb,
  severity text DEFAULT 'info' CHECK (severity IN ('info', 'warning', 'high', 'critical')),
  auto_apply boolean DEFAULT false,

  -- optional references to records
  deal_id uuid,
  credit_case_id uuid,
  collection_case_id uuid,
  application_id uuid,
  task_id uuid,

  status text NOT NULL DEFAULT 'open' CHECK (status IN ('open', 'dismissed', 'applied')),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_wf_suggestions_tenant_status ON public.wf_suggestions (tenant_id, status, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_wf_suggestions_user_role ON public.wf_suggestions (user_id, role, status);

ALTER TABLE public.wf_suggestions ENABLE ROW LEVEL SECURITY;

-- Owner/Admin can see all suggestions
CREATE POLICY "wf_suggestions_owner_admin_select" ON public.wf_suggestions FOR SELECT
USING (
  has_role(auth.uid(), 'admin'::public.app_role) OR has_role(auth.uid(), 'owner'::public.app_role)
);

-- Target user can see their suggestions
CREATE POLICY "wf_suggestions_target_user" ON public.wf_suggestions FOR SELECT
USING (user_id IS NOT NULL AND auth.uid() = user_id);

-- Owner/Admin can update suggestions
CREATE POLICY "wf_suggestions_owner_admin_update" ON public.wf_suggestions FOR UPDATE
USING (
  has_role(auth.uid(), 'admin'::public.app_role) OR has_role(auth.uid(), 'owner'::public.app_role)
);

-- System can insert suggestions
CREATE POLICY "wf_suggestions_system_insert" ON public.wf_suggestions FOR INSERT
WITH CHECK (true);

-- Trigger for updated_at
CREATE OR REPLACE FUNCTION public.set_wf_suggestions_updated_at()
RETURNS trigger AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_wf_suggestions_updated_at ON public.wf_suggestions;

CREATE TRIGGER trg_wf_suggestions_updated_at
BEFORE UPDATE ON public.wf_suggestions
FOR EACH ROW EXECUTE FUNCTION public.set_wf_suggestions_updated_at();

-- =================================================================
-- MIGRATION: 20251207170936_e36d8cc3-3800-4d1a-8a13-e43cd83fb78e.sql
-- =================================================================
-- Fix search_path for set_wf_suggestions_updated_at function
CREATE OR REPLACE FUNCTION public.set_wf_suggestions_updated_at()
RETURNS trigger 
LANGUAGE plpgsql
SET search_path = public
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

-- =================================================================
-- MIGRATION: 20251207182117_8d955cc7-72a8-41dd-95c9-1c927c2b8fd5.sql
-- =================================================================
-- PHASE 4: wf_insights + wf_insight_runs

-- 1) INSIGHTS TABLE
create table if not exists public.wf_insights (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid references public.wf_tenants(id) on delete cascade,
  user_id uuid references auth.users(id),
  role text, -- 'owner' | 'admin' | 'worker' | 'system'
  scope text not null, -- 'owner' | 'admin' | 'worker' | 'global'
  category text not null, -- 'funding' | 'credit' | 'collections' | 'tasks' | 'ops' | etc.
  title text not null,
  body text,
  severity text not null default 'info', -- 'info' | 'warning' | 'high' | 'critical'
  impact_score numeric(5,2), -- optional scoring 0-100
  confidence_score numeric(5,2), -- optional scoring 0-100
  suggested_value jsonb default '{}'::jsonb, -- AI recommended payload
  status text not null default 'open', -- 'open' | 'dismissed' | 'applied'
  source text not null default 'ai-insight-engine',
  run_id uuid, -- fk to wf_insight_runs.id
  meta jsonb default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists idx_wf_insights_tenant_status
  on public.wf_insights (tenant_id, status, created_at desc);

create index if not exists idx_wf_insights_user_role
  on public.wf_insights (user_id, role, status);

-- Trigger to keep updated_at fresh
create or replace function public.set_wf_insights_updated_at()
returns trigger as $$
begin
  new.updated_at = now();
  return new;
end;
$$ language plpgsql security definer set search_path = public;

drop trigger if exists trg_wf_insights_updated_at on public.wf_insights;

create trigger trg_wf_insights_updated_at
before update on public.wf_insights
for each row execute function public.set_wf_insights_updated_at();

-- 2) RUNS TABLE
create table if not exists public.wf_insight_runs (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid references public.wf_tenants(id) on delete set null,
  user_id uuid references auth.users(id),
  total_candidates integer not null default 0,
  total_inserted integer not null default 0,
  created_at timestamptz not null default now()
);

create index if not exists idx_wf_insight_runs_tenant
  on public.wf_insight_runs (tenant_id, created_at desc);

-- Enable RLS
alter table public.wf_insights enable row level security;
alter table public.wf_insight_runs enable row level security;

-- INSIGHTS RLS

-- Owners/Admins: see all insights for their tenant
create policy wf_insights_owner_admin_select
on public.wf_insights
for select
using (
  auth.uid() is not null
  and tenant_id in (
    select tenant_id
    from public.user_roles
    where user_id = auth.uid()
      and role in ('owner', 'admin')
      and approved = true
  )
);

-- Workers: see only insights scoped to them (user_id match OR scope='worker' and same tenant)
create policy wf_insights_worker_select
on public.wf_insights
for select
using (
  auth.uid() is not null
  and (
    user_id = auth.uid()
    or (
      scope = 'worker'
      and tenant_id in (
        select tenant_id
        from public.user_roles
        where user_id = auth.uid()
          and role = 'worker'
          and approved = true
      )
    )
  )
);

-- System insert (edge function with service key)
create policy wf_insights_system_insert
on public.wf_insights
for insert
with check (true);

-- Owner/Admin update (status: open -> dismissed/applied)
create policy wf_insights_owner_admin_update
on public.wf_insights
for update
using (
  auth.uid() is not null
  and tenant_id in (
    select tenant_id
    from public.user_roles
    where user_id = auth.uid()
      and role in ('owner', 'admin')
      and approved = true
  )
);

-- RUNS RLS

-- Owners/Admins: see runs for their tenant
create policy wf_insight_runs_owner_admin_select
on public.wf_insight_runs
for select
using (
  auth.uid() is not null
  and (
    tenant_id is null
    or tenant_id in (
      select tenant_id
      from public.user_roles
      where user_id = auth.uid()
        and role in ('owner', 'admin')
        and approved = true
    )
  )
);

-- System insert
create policy wf_insight_runs_system_insert
on public.wf_insight_runs
for insert
with check (true);

-- =================================================================
-- MIGRATION: 20251207185917_71acbbcf-40c2-454c-a577-3437bbd5eee6.sql
-- =================================================================
-- Fix RLS policies for wf_insights and wf_insight_runs
-- The original policies incorrectly referenced user_roles.tenant_id which doesn't exist
-- We need to join wf_tenant_users to get tenant association

-- Drop existing policies
DROP POLICY IF EXISTS wf_insights_owner_admin_select ON public.wf_insights;
DROP POLICY IF EXISTS wf_insights_worker_select ON public.wf_insights;
DROP POLICY IF EXISTS wf_insights_owner_admin_update ON public.wf_insights;
DROP POLICY IF EXISTS wf_insight_runs_owner_admin_select ON public.wf_insight_runs;

-- Recreate policies using wf_tenant_users + user_roles

-- Owners/Admins: see all insights for their tenant
CREATE POLICY wf_insights_owner_admin_select
ON public.wf_insights
FOR SELECT
USING (
  auth.uid() IS NOT NULL
  AND tenant_id IN (
    SELECT tu.tenant_id
    FROM public.wf_tenant_users tu
    JOIN public.user_roles ur ON ur.user_id = tu.user_id
    WHERE tu.user_id = auth.uid()
      AND ur.role IN ('owner', 'admin')
      AND ur.approved = true
  )
);

-- Workers: see only insights scoped to them (user_id match OR scope='worker' and same tenant)
CREATE POLICY wf_insights_worker_select
ON public.wf_insights
FOR SELECT
USING (
  auth.uid() IS NOT NULL
  AND (
    user_id = auth.uid()
    OR (
      scope = 'worker'
      AND tenant_id IN (
        SELECT tu.tenant_id
        FROM public.wf_tenant_users tu
        JOIN public.user_roles ur ON ur.user_id = tu.user_id
        WHERE tu.user_id = auth.uid()
          AND ur.role = 'worker'
          AND ur.approved = true
      )
    )
  )
);

-- Owner/Admin update (status: open -> dismissed/applied)
CREATE POLICY wf_insights_owner_admin_update
ON public.wf_insights
FOR UPDATE
USING (
  auth.uid() IS NOT NULL
  AND tenant_id IN (
    SELECT tu.tenant_id
    FROM public.wf_tenant_users tu
    JOIN public.user_roles ur ON ur.user_id = tu.user_id
    WHERE tu.user_id = auth.uid()
      AND ur.role IN ('owner', 'admin')
      AND ur.approved = true
  )
);

-- RUNS RLS - Owners/Admins: see runs for their tenant
CREATE POLICY wf_insight_runs_owner_admin_select
ON public.wf_insight_runs
FOR SELECT
USING (
  auth.uid() IS NOT NULL
  AND (
    tenant_id IS NULL
    OR tenant_id IN (
      SELECT tu.tenant_id
      FROM public.wf_tenant_users tu
      JOIN public.user_roles ur ON ur.user_id = tu.user_id
      WHERE tu.user_id = auth.uid()
        AND ur.role IN ('owner', 'admin')
        AND ur.approved = true
    )
  )
);

-- Add missing index for category lookups
CREATE INDEX IF NOT EXISTS idx_wf_insights_category
  ON public.wf_insights (category);

-- =================================================================
-- MIGRATION: 20251207200202_e5c560cb-6dae-4274-b081-e0606106bba2.sql
-- =================================================================
-- Phase 5: AI Autopilot Engine Tables

-- 1. wf_autopilot_runs - log each autopilot run per tenant
CREATE TABLE public.wf_autopilot_runs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.wf_tenants(id) ON DELETE CASCADE,
  started_at timestamptz NOT NULL DEFAULT now(),
  finished_at timestamptz,
  status text NOT NULL DEFAULT 'running', -- 'running' | 'success' | 'partial' | 'failed'
  total_insights integer NOT NULL DEFAULT 0,
  total_actions integer NOT NULL DEFAULT 0,
  total_tags integer NOT NULL DEFAULT 0,
  error_message text,
  meta jsonb NOT NULL DEFAULT '{}'::jsonb
);

CREATE INDEX idx_wf_autopilot_runs_tenant_started
  ON public.wf_autopilot_runs (tenant_id, started_at DESC);

ALTER TABLE public.wf_autopilot_runs ENABLE ROW LEVEL SECURITY;

CREATE POLICY wf_autopilot_runs_owner_admin_select
ON public.wf_autopilot_runs
FOR SELECT
USING (
  auth.uid() IS NOT NULL
  AND tenant_id IN (
    SELECT tu.tenant_id
    FROM public.wf_tenant_users tu
    JOIN public.user_roles ur ON ur.user_id = tu.user_id
    WHERE tu.user_id = auth.uid()
      AND ur.role IN ('owner', 'admin')
      AND ur.approved = true
  )
);

CREATE POLICY wf_autopilot_runs_system_insert
ON public.wf_autopilot_runs
FOR INSERT
WITH CHECK (true);

CREATE POLICY wf_autopilot_runs_system_update
ON public.wf_autopilot_runs
FOR UPDATE
USING (true);

-- 2. wf_autopilot_actions - concrete actions for humans
CREATE TABLE public.wf_autopilot_actions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.wf_tenants(id) ON DELETE CASCADE,
  run_id uuid REFERENCES public.wf_autopilot_runs(id) ON DELETE CASCADE,
  user_id uuid,
  role text,
  scope text NOT NULL,
  category text NOT NULL,
  title text NOT NULL,
  body text,
  severity text NOT NULL DEFAULT 'info',
  status text NOT NULL DEFAULT 'open',
  related_deal_id uuid,
  related_credit_case_id uuid,
  related_collection_case_id uuid,
  related_application_id uuid,
  related_task_id uuid,
  impact_score numeric,
  confidence_score numeric,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  meta jsonb NOT NULL DEFAULT '{}'::jsonb
);

CREATE INDEX idx_wf_autopilot_actions_tenant_status
  ON public.wf_autopilot_actions (tenant_id, status, created_at DESC);

CREATE INDEX idx_wf_autopilot_actions_user_status
  ON public.wf_autopilot_actions (user_id, status);

CREATE OR REPLACE FUNCTION public.set_wf_autopilot_actions_updated_at()
RETURNS trigger
LANGUAGE plpgsql
SET search_path = public
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

CREATE TRIGGER trg_wf_autopilot_actions_updated_at
  BEFORE UPDATE ON public.wf_autopilot_actions
  FOR EACH ROW
  EXECUTE FUNCTION public.set_wf_autopilot_actions_updated_at();

ALTER TABLE public.wf_autopilot_actions ENABLE ROW LEVEL SECURITY;

CREATE POLICY wf_autopilot_actions_owner_admin_select
ON public.wf_autopilot_actions
FOR SELECT
USING (
  auth.uid() IS NOT NULL
  AND tenant_id IN (
    SELECT tu.tenant_id
    FROM public.wf_tenant_users tu
    JOIN public.user_roles ur ON ur.user_id = tu.user_id
    WHERE tu.user_id = auth.uid()
      AND ur.role IN ('owner', 'admin')
      AND ur.approved = true
  )
);

CREATE POLICY wf_autopilot_actions_worker_select
ON public.wf_autopilot_actions
FOR SELECT
USING (
  auth.uid() IS NOT NULL
  AND user_id = auth.uid()
);

CREATE POLICY wf_autopilot_actions_system_insert
ON public.wf_autopilot_actions
FOR INSERT
WITH CHECK (true);

CREATE POLICY wf_autopilot_actions_owner_admin_update
ON public.wf_autopilot_actions
FOR UPDATE
USING (
  auth.uid() IS NOT NULL
  AND tenant_id IN (
    SELECT tu.tenant_id
    FROM public.wf_tenant_users tu
    JOIN public.user_roles ur ON ur.user_id = tu.user_id
    WHERE tu.user_id = auth.uid()
      AND ur.role IN ('owner', 'admin')
      AND ur.approved = true
  )
);

-- 3. wf_worker_tags - persistent performance tags per user/tenant
CREATE TABLE public.wf_worker_tags (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.wf_tenants(id) ON DELETE CASCADE,
  user_id uuid NOT NULL,
  tag text NOT NULL,
  score numeric NOT NULL DEFAULT 0,
  last_updated_at timestamptz NOT NULL DEFAULT now(),
  meta jsonb NOT NULL DEFAULT '{}'::jsonb,
  UNIQUE(tenant_id, user_id, tag)
);

CREATE INDEX idx_wf_worker_tags_tenant_user
  ON public.wf_worker_tags (tenant_id, user_id, tag);

ALTER TABLE public.wf_worker_tags ENABLE ROW LEVEL SECURITY;

CREATE POLICY wf_worker_tags_owner_admin_select
ON public.wf_worker_tags
FOR SELECT
USING (
  auth.uid() IS NOT NULL
  AND tenant_id IN (
    SELECT tu.tenant_id
    FROM public.wf_tenant_users tu
    JOIN public.user_roles ur ON ur.user_id = tu.user_id
    WHERE tu.user_id = auth.uid()
      AND ur.role IN ('owner', 'admin')
      AND ur.approved = true
  )
);

CREATE POLICY wf_worker_tags_worker_select
ON public.wf_worker_tags
FOR SELECT
USING (
  auth.uid() IS NOT NULL
  AND user_id = auth.uid()
);

CREATE POLICY wf_worker_tags_system_write
ON public.wf_worker_tags
FOR ALL
USING (true)
WITH CHECK (true);

-- =================================================================
-- MIGRATION: 20251207202439_c1e05d15-63ca-46c3-80bd-a795515b8c68.sql
-- =================================================================
-- Phase 5 REV 2: Add worker update policy for autopilot actions

-- Worker: UPDATE own actions (mark done/dismissed)
CREATE POLICY wf_autopilot_actions_worker_update
ON public.wf_autopilot_actions
FOR UPDATE
USING (
  auth.uid() IS NOT NULL
  AND user_id = auth.uid()
);

-- =================================================================
-- MIGRATION: 20251207205104_00879095-0595-4f6a-9200-2c11e9afcf25.sql
-- =================================================================
-- Phase 6: AI Control Tower Tables

-- 1. wf_autopilot_policies - per-tenant configuration for autopilot + SLAs
CREATE TABLE public.wf_autopilot_policies (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.wf_tenants(id) ON DELETE CASCADE,
  autopilot_enabled boolean NOT NULL DEFAULT true,
  schedule_type text NOT NULL DEFAULT 'daily',
  schedule_time text NULL,
  schedule_timezone text NULL DEFAULT 'America/New_York',
  max_open_actions integer NULL,
  max_critical_insights integer NULL,
  max_hours_since_last_run integer NULL,
  last_manual_override_at timestamptz NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  meta jsonb NOT NULL DEFAULT '{}'::jsonb,
  UNIQUE(tenant_id)
);

CREATE INDEX idx_wf_autopilot_policies_tenant ON public.wf_autopilot_policies (tenant_id);
CREATE INDEX idx_wf_autopilot_policies_schedule ON public.wf_autopilot_policies (schedule_type);

CREATE OR REPLACE FUNCTION public.set_wf_autopilot_policies_updated_at()
RETURNS trigger
LANGUAGE plpgsql
SET search_path = public
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

CREATE TRIGGER trg_wf_autopilot_policies_updated_at
  BEFORE UPDATE ON public.wf_autopilot_policies
  FOR EACH ROW
  EXECUTE FUNCTION public.set_wf_autopilot_policies_updated_at();

ALTER TABLE public.wf_autopilot_policies ENABLE ROW LEVEL SECURITY;

CREATE POLICY wf_autopilot_policies_owner_admin_select
ON public.wf_autopilot_policies
FOR SELECT
USING (
  auth.uid() IS NOT NULL
  AND tenant_id IN (
    SELECT tu.tenant_id
    FROM public.wf_tenant_users tu
    JOIN public.user_roles ur ON ur.user_id = tu.user_id
    WHERE tu.user_id = auth.uid()
      AND ur.role IN ('owner', 'admin')
      AND ur.approved = true
  )
);

CREATE POLICY wf_autopilot_policies_owner_admin_update
ON public.wf_autopilot_policies
FOR UPDATE
USING (
  auth.uid() IS NOT NULL
  AND tenant_id IN (
    SELECT tu.tenant_id
    FROM public.wf_tenant_users tu
    JOIN public.user_roles ur ON ur.user_id = tu.user_id
    WHERE tu.user_id = auth.uid()
      AND ur.role IN ('owner', 'admin')
      AND ur.approved = true
  )
);

CREATE POLICY wf_autopilot_policies_system_insert
ON public.wf_autopilot_policies
FOR INSERT
WITH CHECK (true);

CREATE POLICY wf_autopilot_policies_system_update
ON public.wf_autopilot_policies
FOR UPDATE
USING (true);

-- 2. wf_alert_channels - where to send alerts
CREATE TABLE public.wf_alert_channels (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.wf_tenants(id) ON DELETE CASCADE,
  type text NOT NULL,
  target text NOT NULL,
  enabled boolean NOT NULL DEFAULT true,
  meta jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX idx_wf_alert_channels_tenant ON public.wf_alert_channels (tenant_id);

ALTER TABLE public.wf_alert_channels ENABLE ROW LEVEL SECURITY;

CREATE POLICY wf_alert_channels_owner_admin_select
ON public.wf_alert_channels
FOR SELECT
USING (
  auth.uid() IS NOT NULL
  AND tenant_id IN (
    SELECT tu.tenant_id
    FROM public.wf_tenant_users tu
    JOIN public.user_roles ur ON ur.user_id = tu.user_id
    WHERE tu.user_id = auth.uid()
      AND ur.role IN ('owner', 'admin')
      AND ur.approved = true
  )
);

CREATE POLICY wf_alert_channels_owner_admin_update
ON public.wf_alert_channels
FOR UPDATE
USING (
  auth.uid() IS NOT NULL
  AND tenant_id IN (
    SELECT tu.tenant_id
    FROM public.wf_tenant_users tu
    JOIN public.user_roles ur ON ur.user_id = tu.user_id
    WHERE tu.user_id = auth.uid()
      AND ur.role IN ('owner', 'admin')
      AND ur.approved = true
  )
);

CREATE POLICY wf_alert_channels_system_insert
ON public.wf_alert_channels
FOR INSERT
WITH CHECK (true);

-- 3. wf_alert_events - alert log table
CREATE TABLE public.wf_alert_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.wf_tenants(id) ON DELETE CASCADE,
  severity text NOT NULL,
  category text NOT NULL,
  title text NOT NULL,
  body text NULL,
  source text NOT NULL DEFAULT 'ai-alert-engine',
  related_run_id uuid NULL REFERENCES public.wf_autopilot_runs(id) ON DELETE SET NULL,
  related_policy_id uuid NULL REFERENCES public.wf_autopilot_policies(id) ON DELETE SET NULL,
  meta jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX idx_wf_alert_events_tenant_created ON public.wf_alert_events (tenant_id, created_at DESC);
CREATE INDEX idx_wf_alert_events_severity ON public.wf_alert_events (severity);

ALTER TABLE public.wf_alert_events ENABLE ROW LEVEL SECURITY;

CREATE POLICY wf_alert_events_owner_admin_select
ON public.wf_alert_events
FOR SELECT
USING (
  auth.uid() IS NOT NULL
  AND tenant_id IN (
    SELECT tu.tenant_id
    FROM public.wf_tenant_users tu
    JOIN public.user_roles ur ON ur.user_id = tu.user_id
    WHERE tu.user_id = auth.uid()
      AND ur.role IN ('owner', 'admin')
      AND ur.approved = true
  )
);

CREATE POLICY wf_alert_events_worker_select
ON public.wf_alert_events
FOR SELECT
USING (
  auth.uid() IS NOT NULL
  AND tenant_id IN (
    SELECT tu.tenant_id
    FROM public.wf_tenant_users tu
    WHERE tu.user_id = auth.uid()
  )
);

CREATE POLICY wf_alert_events_system_insert
ON public.wf_alert_events
FOR INSERT
WITH CHECK (true);

