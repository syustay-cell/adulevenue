-- =================================================================
-- MIGRATION: 20251201065910_2d08f094-aaac-42cb-bb42-9d11eb1b2275.sql
-- =================================================================
-- Create billing_plans table for Credit Fix Back Office billing
CREATE TABLE IF NOT EXISTS public.billing_plans (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  plan_name TEXT NOT NULL,
  plan_type TEXT NOT NULL, -- 'monthly', 'annual', 'one_time'
  price NUMERIC NOT NULL,
  features JSONB DEFAULT '[]'::jsonb,
  is_active BOOLEAN DEFAULT true,
  stripe_price_id TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Create billing_subscriptions table
CREATE TABLE IF NOT EXISTS public.billing_subscriptions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL,
  plan_id UUID REFERENCES public.billing_plans(id),
  stripe_subscription_id TEXT,
  stripe_customer_id TEXT,
  status TEXT NOT NULL DEFAULT 'active', -- 'active', 'cancelled', 'past_due', 'on_hold'
  current_period_start TIMESTAMP WITH TIME ZONE,
  current_period_end TIMESTAMP WITH TIME ZONE,
  cancelled_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.billing_plans ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.billing_subscriptions ENABLE ROW LEVEL SECURITY;

-- RLS Policies for billing_plans
CREATE POLICY "Anyone can view active plans"
  ON public.billing_plans
  FOR SELECT
  USING (is_active = true);

CREATE POLICY "Admins can manage plans"
  ON public.billing_plans
  FOR ALL
  USING (has_role(auth.uid(), 'admin'::public.app_role));

-- RLS Policies for billing_subscriptions
CREATE POLICY "Users can view own subscriptions"
  ON public.billing_subscriptions
  FOR SELECT
  USING (user_id = auth.uid() OR has_role(auth.uid(), 'admin'::public.app_role));

CREATE POLICY "Admins can manage all subscriptions"
  ON public.billing_subscriptions
  FOR ALL
  USING (has_role(auth.uid(), 'admin'::public.app_role));

-- Create trigger for updated_at
CREATE TRIGGER set_billing_plans_updated_at
  BEFORE UPDATE ON public.billing_plans
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_updated_at();

CREATE TRIGGER set_billing_subscriptions_updated_at
  BEFORE UPDATE ON public.billing_subscriptions
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_updated_at();

-- =================================================================
-- MIGRATION: 20251201084255_9b1dc2d1-145f-4347-a694-ddcf2b077f1b.sql
-- =================================================================
-- Add signature column to credit_repair_dispute_drafts table
ALTER TABLE credit_repair_dispute_drafts 
ADD COLUMN signature TEXT;

-- =================================================================
-- MIGRATION: 20251201191753_28348e5e-5bf6-4460-a082-b21d06648942.sql
-- =================================================================
-- P2 Security Fix: Tighten RLS policies for worker_activity_logs and outbound_emails
-- These tables currently have overly permissive INSERT policies that allow any authenticated user
-- to insert arbitrary records, which could lead to fake logs and corrupted audit trails.

-- Fix worker_activity_logs INSERT policy
DROP POLICY IF EXISTS "System can insert activity logs" ON public.worker_activity_logs;

CREATE POLICY "Users can insert own activity logs"
ON public.worker_activity_logs FOR INSERT
WITH CHECK (worker_id = auth.uid());

-- Allow service role to insert activity logs for system operations
CREATE POLICY "Service role can insert activity logs"
ON public.worker_activity_logs FOR INSERT
WITH CHECK (auth.role() = 'service_role');

-- Fix outbound_emails INSERT policy
DROP POLICY IF EXISTS "System can insert outbound emails" ON public.outbound_emails;

CREATE POLICY "Users can insert own emails"
ON public.outbound_emails FOR INSERT
WITH CHECK (worker_id = auth.uid());

-- Allow service role to insert emails for system operations
CREATE POLICY "Service role can insert outbound emails"
ON public.outbound_emails FOR INSERT
WITH CHECK (auth.role() = 'service_role');

-- =================================================================
-- MIGRATION: 20251201192056_336978e8-2e4c-49bc-a545-a6c57185be13.sql
-- =================================================================
-- Live Activity Command Center – activity_feed table
-- This tracks all important events happening across Wolf Fund platform

CREATE TABLE IF NOT EXISTS public.activity_feed (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),

  -- Who triggered it (worker/admin/ISO/system user)
  actor_user_id   UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  actor_email     TEXT,

  -- Who it is about (client / lead / ISO / worker)
  target_user_id  UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  target_email    TEXT,

  -- High-level classification
  event_type      TEXT NOT NULL,  -- 'new_application', 'status_change', 'permission_request', 'permission_decision', 'credit_case_update', 'call_log', etc.
  context_type    TEXT NOT NULL,  -- 'funding_case', 'credit_case', 'lead', 'iso', 'system'
  context_id      UUID,           -- id of related case/lead/etc.

  -- Decision info (for approvals / denials)
  decision        TEXT,           -- 'approved' | 'denied' | 'pending' | 'n/a'
  decision_reason TEXT,

  -- Human readable summary for the row
  summary         TEXT NOT NULL,

  -- Extra data if needed
  details         JSONB DEFAULT '{}'::jsonb
);

-- Enable RLS
ALTER TABLE public.activity_feed ENABLE ROW LEVEL SECURITY;

-- RLS Policies
CREATE POLICY "Admins can see all activity"
ON public.activity_feed FOR SELECT
USING (has_role(auth.uid(), 'admin'::public.app_role));

CREATE POLICY "Users can see activity where they are actor or target"
ON public.activity_feed FOR SELECT
USING (
  actor_user_id = auth.uid() OR target_user_id = auth.uid()
);

CREATE POLICY "System can insert activity"
ON public.activity_feed FOR INSERT
WITH CHECK (true);

-- Create index for performance on recent activity queries
CREATE INDEX idx_activity_feed_created_at ON public.activity_feed(created_at DESC);
CREATE INDEX idx_activity_feed_event_type ON public.activity_feed(event_type);
CREATE INDEX idx_activity_feed_decision ON public.activity_feed(decision);

-- Enable realtime for live updates
ALTER PUBLICATION supabase_realtime ADD TABLE public.activity_feed;

-- =================================================================
-- MIGRATION: 20251201193715_5d6edd9c-b533-48d7-86c9-ab3840deb2c1.sql
-- =================================================================
-- Add actor_role field to activity_feed table
ALTER TABLE activity_feed ADD COLUMN IF NOT EXISTS actor_role text;

-- Add index for faster filtering
CREATE INDEX IF NOT EXISTS idx_activity_feed_event_type ON activity_feed(event_type);
CREATE INDEX IF NOT EXISTS idx_activity_feed_decision ON activity_feed(decision);
CREATE INDEX IF NOT EXISTS idx_activity_feed_created_at ON activity_feed(created_at DESC);

-- =================================================================
-- MIGRATION: 20251201203902_cc9fdc1b-d256-4f83-9cfa-f4fcc3f77566.sql
-- =================================================================
-- ============================================
-- LEAD ENGINE DATABASE SCHEMA
-- ============================================

-- 1. Lead Sources (where leads come from)
CREATE TABLE IF NOT EXISTS lead_sources (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  channel text NOT NULL CHECK (channel IN ('web_form', 'pdf_import', 'csv', 'api', 'referral', 'iso_partner')),
  campaign text,
  meta jsonb DEFAULT '{}'::jsonb,
  created_at timestamptz DEFAULT now()
);

-- 2. Leads (main lead tracking table)
CREATE TABLE IF NOT EXISTS leads (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  source_id uuid REFERENCES lead_sources(id),
  
  first_name text,
  last_name text,
  email text,
  phone text,
  
  business_name text,
  requested_amount numeric,
  est_credit_score int,
  
  lead_type text CHECK (lead_type IN ('credit_repair', 'funding', 'both', 'unknown')),
  problem_flags text[] DEFAULT ARRAY[]::text[],
  
  priority_score int DEFAULT 50 CHECK (priority_score >= 0 AND priority_score <= 100),
  
  status text NOT NULL DEFAULT 'new' CHECK (status IN ('new','assigned','in_progress','contacted','converted','not_qualified','do_not_contact')),
  
  assigned_worker_id uuid REFERENCES auth.users(id),
  notes text,
  
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- 3. Lead Import Batches (for PDF/Excel uploads)
CREATE TABLE IF NOT EXISTS lead_import_batches (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  source_id uuid REFERENCES lead_sources(id),
  uploaded_by uuid NOT NULL REFERENCES auth.users(id),
  file_name text NOT NULL,
  file_path text NOT NULL,
  total_rows int DEFAULT 0,
  imported_rows int DEFAULT 0,
  error_count int DEFAULT 0,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','processing','completed','failed')),
  error_log jsonb,
  created_at timestamptz DEFAULT now(),
  completed_at timestamptz
);

-- 4. Lead Tasks (calls, emails, follow-ups)
CREATE TABLE IF NOT EXISTS lead_tasks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id uuid REFERENCES leads(id) ON DELETE CASCADE,
  worker_id uuid REFERENCES auth.users(id),
  task_type text NOT NULL CHECK (task_type IN ('call','email','sms','follow_up','meeting')),
  status text NOT NULL DEFAULT 'open' CHECK (status IN ('open','completed','skipped','cancelled')),
  due_at timestamptz,
  completed_at timestamptz,
  notes text,
  created_at timestamptz DEFAULT now()
);

-- 5. Lead Call Logs
CREATE TABLE IF NOT EXISTS lead_call_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id uuid REFERENCES leads(id) ON DELETE CASCADE,
  worker_id uuid REFERENCES auth.users(id),
  outcome text CHECK (outcome IN ('answered','voicemail','no_answer','bad_number','busy','callback_scheduled')),
  duration_seconds int,
  notes text,
  created_at timestamptz DEFAULT now()
);

-- ============================================
-- RLS POLICIES
-- ============================================

-- Lead Sources
ALTER TABLE lead_sources ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins can manage lead sources"
  ON lead_sources FOR ALL
  USING (has_role(auth.uid(), 'admin'::public.app_role));

CREATE POLICY "Workers can view lead sources"
  ON lead_sources FOR SELECT
  USING (has_role(auth.uid(), 'worker'::public.app_role) OR has_role(auth.uid(), 'admin'::public.app_role));

-- Leads
ALTER TABLE leads ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins can manage all leads"
  ON leads FOR ALL
  USING (has_role(auth.uid(), 'admin'::public.app_role));

CREATE POLICY "Workers can view assigned leads"
  ON leads FOR SELECT
  USING (assigned_worker_id = auth.uid() OR has_role(auth.uid(), 'admin'::public.app_role));

CREATE POLICY "Workers can update assigned leads"
  ON leads FOR UPDATE
  USING (assigned_worker_id = auth.uid() OR has_role(auth.uid(), 'admin'::public.app_role));

-- Lead Import Batches
ALTER TABLE lead_import_batches ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins can manage import batches"
  ON lead_import_batches FOR ALL
  USING (has_role(auth.uid(), 'admin'::public.app_role));

-- Lead Tasks
ALTER TABLE lead_tasks ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Workers can manage own tasks"
  ON lead_tasks FOR ALL
  USING (worker_id = auth.uid() OR has_role(auth.uid(), 'admin'::public.app_role));

-- Lead Call Logs
ALTER TABLE lead_call_logs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Workers can log own calls"
  ON lead_call_logs FOR INSERT
  WITH CHECK (worker_id = auth.uid() OR has_role(auth.uid(), 'admin'::public.app_role));

CREATE POLICY "Workers and admins can view call logs"
  ON lead_call_logs FOR SELECT
  USING (worker_id = auth.uid() OR has_role(auth.uid(), 'admin'::public.app_role));

-- ============================================
-- TRIGGERS
-- ============================================

CREATE TRIGGER update_leads_updated_at
  BEFORE UPDATE ON leads
  FOR EACH ROW
  EXECUTE FUNCTION handle_updated_at();

-- ============================================
-- INDEXES
-- ============================================

CREATE INDEX idx_leads_status ON leads(status);
CREATE INDEX idx_leads_assigned_worker ON leads(assigned_worker_id);
CREATE INDEX idx_leads_created_at ON leads(created_at DESC);
CREATE INDEX idx_leads_priority_score ON leads(priority_score DESC);
CREATE INDEX idx_lead_tasks_worker_status ON lead_tasks(worker_id, status);
CREATE INDEX idx_lead_call_logs_lead_id ON lead_call_logs(lead_id);

-- =================================================================
-- MIGRATION: 20251201204205_49265960-1c58-4626-86bb-4114a3127956.sql
-- =================================================================
-- Create storage bucket for lead imports
INSERT INTO storage.buckets (id, name, public)
VALUES ('lead-imports', 'lead-imports', false)
ON CONFLICT (id) DO NOTHING;

-- Storage policies for lead-imports bucket
CREATE POLICY "Admins can upload lead files"
  ON storage.objects FOR INSERT
  WITH CHECK (
    bucket_id = 'lead-imports' AND
    (SELECT has_role(auth.uid(), 'admin'::public.app_role))
  );

CREATE POLICY "Admins can view lead files"
  ON storage.objects FOR SELECT
  USING (
    bucket_id = 'lead-imports' AND
    (SELECT has_role(auth.uid(), 'admin'::public.app_role))
  );

CREATE POLICY "Admins can delete lead files"
  ON storage.objects FOR DELETE
  USING (
    bucket_id = 'lead-imports' AND
    (SELECT has_role(auth.uid(), 'admin'::public.app_role))
  );

-- =================================================================
-- MIGRATION: 20251201213737_9a6ad1e6-e746-4675-aa61-ca85e7d05bf1.sql
-- =================================================================
-- Create helper function to move application to credit repair atomically
CREATE OR REPLACE FUNCTION move_application_to_credit_repair(
  p_application_id uuid,
  p_application_type text,
  p_user_id uuid,
  p_email text,
  p_phone text,
  p_name text
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_credit_app_id uuid;
  v_case_id uuid;
  v_table_name text;
BEGIN
  -- Determine table name
  v_table_name := CASE 
    WHEN p_application_type = 'fast_track' THEN 'fast_track_applications'
    WHEN p_application_type = 'loan' THEN 'loan_applications'
    ELSE 'credit_repair_applications'
  END;

  -- Check if credit repair application exists for this user
  SELECT id INTO v_credit_app_id
  FROM credit_repair_applications
  WHERE user_id = p_user_id
  LIMIT 1;

  -- Create credit repair application if it doesn't exist
  IF v_credit_app_id IS NULL THEN
    INSERT INTO credit_repair_applications (
      user_id,
      email,
      phone,
      full_name,
      status
    ) VALUES (
      p_user_id,
      p_email,
      p_phone,
      p_name,
      'active'
    )
    RETURNING id INTO v_credit_app_id;
  END IF;

  -- Check if case already exists for this application
  SELECT id INTO v_case_id
  FROM credit_repair_cases
  WHERE original_application_id = p_application_id
    AND original_application_type = p_application_type
  LIMIT 1;

  -- Create case if it doesn't exist
  IF v_case_id IS NULL THEN
    INSERT INTO credit_repair_cases (
      credit_repair_application_id,
      original_application_id,
      original_application_type,
      from_declined_funding,
      status
    ) VALUES (
      v_credit_app_id,
      p_application_id,
      p_application_type,
      true,
      'intake'
    )
    RETURNING id INTO v_case_id;
  END IF;

  -- Update original application status (only if not already moved)
  IF p_application_type IN ('fast_track', 'loan') THEN
    EXECUTE format(
      'UPDATE %I SET status = $1 WHERE id = $2 AND status != $1',
      v_table_name
    ) USING 'moved_to_credit_repair', p_application_id;
  END IF;

  -- Return success with IDs
  RETURN jsonb_build_object(
    'success', true,
    'creditAppId', v_credit_app_id,
    'caseId', v_case_id,
    'message', 'Application successfully moved to credit repair'
  );

EXCEPTION
  WHEN OTHERS THEN
    RAISE EXCEPTION 'Failed to move to credit repair: %', SQLERRM;
END;
$$;

-- =================================================================
-- MIGRATION: 20251201220712_d3edd980-0977-4e4c-b87a-8e9db39b1f7f.sql
-- =================================================================
-- Create the atomic function for moving applications to credit repair
CREATE OR REPLACE FUNCTION move_application_to_credit_repair(p_application_id uuid, p_application_type text)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_email text;
  v_name text;
  v_user_id uuid;
  v_case_id uuid;
  v_app_exists boolean;
BEGIN
  -- 1. Validate application exists and get details
  IF p_application_type = 'fast_track' THEN
    SELECT 
      email, 
      client_name, 
      user_id,
      true
    INTO v_email, v_name, v_user_id, v_app_exists
    FROM fast_track_applications
    WHERE id = p_application_id;
  ELSIF p_application_type = 'loan' THEN
    SELECT 
      email, 
      owner_name, 
      user_id,
      true
    INTO v_email, v_name, v_user_id, v_app_exists
    FROM loan_applications
    WHERE id = p_application_id;
  ELSE
    RAISE EXCEPTION 'Invalid application type: %', p_application_type;
  END IF;

  IF NOT v_app_exists THEN
    RAISE EXCEPTION 'Application not found with id: %', p_application_id;
  END IF;

  -- 2. Check if credit repair application exists for this user
  IF NOT EXISTS (
    SELECT 1 FROM credit_repair_applications 
    WHERE user_id = v_user_id
  ) THEN
    INSERT INTO credit_repair_applications (
      user_id,
      email,
      phone,
      full_name,
      status
    ) VALUES (
      v_user_id,
      v_email,
      '',
      COALESCE(v_name, v_email),
      'active'
    );
  END IF;

  -- 3. Check if case already exists for this application
  SELECT id INTO v_case_id
  FROM credit_repair_cases
  WHERE original_application_id = p_application_id
    AND original_application_type = p_application_type
  LIMIT 1;

  -- 4. Create case if it doesn't exist
  IF v_case_id IS NULL THEN
    INSERT INTO credit_repair_cases (
      credit_repair_application_id,
      original_application_id,
      original_application_type,
      from_declined_funding,
      status
    )
    SELECT 
      cra.id,
      p_application_id,
      p_application_type,
      true,
      'intake'
    FROM credit_repair_applications cra
    WHERE cra.user_id = v_user_id
    RETURNING id INTO v_case_id;
  END IF;

  -- 5. Update application status
  IF p_application_type = 'fast_track' THEN
    UPDATE fast_track_applications
    SET 
      status = 'moved_to_credit_repair',
      updated_at = now()
    WHERE id = p_application_id;
  ELSIF p_application_type = 'loan' THEN
    UPDATE loan_applications
    SET 
      status = 'moved_to_credit_repair',
      updated_at = now()
    WHERE id = p_application_id;
  END IF;

  -- 6. Log activity
  INSERT INTO activity_feed (
    actor_user_id,
    actor_email,
    actor_role,
    target_email,
    event_type,
    context_type,
    context_id,
    summary,
    decision
  ) VALUES (
    auth.uid(),
    (SELECT email FROM auth.users WHERE id = auth.uid()),
    'admin',
    v_email,
    'credit_repair',
    'application',
    p_application_id,
    format('Moved %s application into Credit Repair workflow', p_application_type),
    'approved'
  );

  -- 7. Return success with case ID
  RETURN jsonb_build_object(
    'success', true,
    'case_id', v_case_id,
    'message', 'Application moved to Credit Repair ✍🏼 workflow'
  );

EXCEPTION
  WHEN OTHERS THEN
    RAISE EXCEPTION 'Error moving to credit repair: %', SQLERRM;
END;
$$;

-- =================================================================
-- MIGRATION: 20251202001029_00eae09e-4e93-4bbd-867a-788f57b9f4b0.sql
-- =================================================================
-- C.1: Lead Engine V3 Tables

-- Master list of uploaded lead files
CREATE TABLE IF NOT EXISTS lead_lists (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  source text,
  file_path text NOT NULL,
  status text NOT NULL DEFAULT 'pending',
  total_rows integer DEFAULT 0,
  processed_rows integer DEFAULT 0,
  error_message text,
  created_by uuid REFERENCES auth.users (id),
  created_at timestamptz DEFAULT now()
);

-- Modify existing leads table to align with V3 spec
ALTER TABLE leads ADD COLUMN IF NOT EXISTS lead_list_id uuid REFERENCES lead_lists (id) ON DELETE CASCADE;
ALTER TABLE leads ADD COLUMN IF NOT EXISTS full_name text;
ALTER TABLE leads ADD COLUMN IF NOT EXISTS need_type text;
ALTER TABLE leads ADD COLUMN IF NOT EXISTS assigned_to uuid REFERENCES auth.users (id);

-- Enable RLS
ALTER TABLE lead_lists ENABLE ROW LEVEL SECURITY;

-- RLS Policies for lead_lists
CREATE POLICY "Admins can see all lead lists"
ON lead_lists FOR SELECT
USING (has_role(auth.uid(), 'admin'::public.app_role));

CREATE POLICY "Admins can insert lead lists"
ON lead_lists FOR INSERT
WITH CHECK (has_role(auth.uid(), 'admin'::public.app_role));

CREATE POLICY "Admins can update lead lists"
ON lead_lists FOR UPDATE
USING (has_role(auth.uid(), 'admin'::public.app_role));

-- Update leads RLS policies
CREATE POLICY "Admins can see all leads"
ON leads FOR SELECT
USING (has_role(auth.uid(), 'admin'::public.app_role));

CREATE POLICY "Workers see assigned leads"
ON leads FOR SELECT
USING (assigned_to = auth.uid());

CREATE POLICY "Admins can update leads"
ON leads FOR UPDATE
USING (has_role(auth.uid(), 'admin'::public.app_role));

-- Storage bucket for lead lists (created via Supabase dashboard or migration)
INSERT INTO storage.buckets (id, name, public)
VALUES ('lead-lists', 'lead-lists', false)
ON CONFLICT (id) DO NOTHING;

-- Storage policies
CREATE POLICY "Admins can upload lead lists"
ON storage.objects FOR INSERT
WITH CHECK (
  bucket_id = 'lead-lists' AND
  has_role(auth.uid(), 'admin'::public.app_role)
);

CREATE POLICY "Admins can read lead lists"
ON storage.objects FOR SELECT
USING (
  bucket_id = 'lead-lists' AND
  has_role(auth.uid(), 'admin'::public.app_role)
);

-- =================================================================
-- MIGRATION: 20251202002841_5516c13c-21bb-42a2-a94e-474d3f568994.sql
-- =================================================================
-- Add missing RLS policies for lead_lists and leads tables

-- Drop existing conflicting policy if it exists
DROP POLICY IF EXISTS "Workers can update assigned leads" ON leads;

-- Workers can insert new leads (from manual entry or imports)
DO $$ BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies WHERE tablename = 'leads' AND policyname = 'Workers can insert leads'
  ) THEN
    CREATE POLICY "Workers can insert leads"
    ON leads FOR INSERT
    WITH CHECK (
      auth.uid() IN (
        SELECT user_id FROM user_roles 
        WHERE role = 'worker' AND approved = true
      )
    );
  END IF;
END $$;

-- Workers can update leads assigned to them
CREATE POLICY "Workers can update assigned leads"
ON leads FOR UPDATE
USING (
  assigned_to = auth.uid() OR
  auth.uid() IN (
    SELECT user_id FROM user_roles WHERE role = 'admin' AND approved = true
  )
);

-- Admin can delete lead_lists
DO $$ BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies WHERE tablename = 'lead_lists' AND policyname = 'Admins can delete lead lists'
  ) THEN
    CREATE POLICY "Admins can delete lead lists"
    ON lead_lists FOR DELETE
    USING (
      auth.uid() IN (
        SELECT user_id FROM user_roles WHERE role = 'admin' AND approved = true
      )
    );
  END IF;
END $$;

-- =================================================================
-- MIGRATION: 20251202004534_0db38f02-f928-451a-b0a0-2ca4d07f6c27.sql
-- =================================================================
-- Wolf Brain V1 Database Schema
-- Add AI fields to leads table
ALTER TABLE leads
  ADD COLUMN IF NOT EXISTS ai_score              integer,
  ADD COLUMN IF NOT EXISTS ai_priority           text CHECK (ai_priority IN ('A', 'B', 'C')),
  ADD COLUMN IF NOT EXISTS ai_recommended_path   text CHECK (ai_recommended_path IN ('fast_track_funding', 'credit_fix_first', 'hybrid_path', 'do_not_work')),
  ADD COLUMN IF NOT EXISTS ai_risk_flags         jsonb DEFAULT '[]'::jsonb,
  ADD COLUMN IF NOT EXISTS ai_notes              jsonb DEFAULT '{}'::jsonb,
  ADD COLUMN IF NOT EXISTS ai_last_evaluated_at  timestamptz;

-- Add AI fields to fast_track_applications
ALTER TABLE fast_track_applications
  ADD COLUMN IF NOT EXISTS ai_score              integer,
  ADD COLUMN IF NOT EXISTS ai_recommended_path   text CHECK (ai_recommended_path IN ('fast_track_funding', 'credit_fix_first', 'hybrid_path', 'do_not_work')),
  ADD COLUMN IF NOT EXISTS ai_notes              jsonb DEFAULT '{}'::jsonb,
  ADD COLUMN IF NOT EXISTS ai_last_evaluated_at  timestamptz;

-- Add AI fields to credit_repair_cases
ALTER TABLE credit_repair_cases
  ADD COLUMN IF NOT EXISTS ai_score              integer,
  ADD COLUMN IF NOT EXISTS ai_recommended_path   text CHECK (ai_recommended_path IN ('fast_track_funding', 'credit_fix_first', 'hybrid_path', 'do_not_work')),
  ADD COLUMN IF NOT EXISTS ai_notes              jsonb DEFAULT '{}'::jsonb,
  ADD COLUMN IF NOT EXISTS ai_last_evaluated_at  timestamptz;

-- Create ai_events log table
CREATE TABLE IF NOT EXISTS ai_events (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  entity_type     text NOT NULL CHECK (entity_type IN ('lead', 'application', 'credit_case')),
  entity_id       uuid NOT NULL,
  model_name      text,
  event_type      text NOT NULL CHECK (event_type IN ('intake', 're_eval', 'routing_decision')),
  payload_in      jsonb,
  payload_out     jsonb,
  created_at      timestamptz DEFAULT now()
);

-- Enable RLS on ai_events
ALTER TABLE ai_events ENABLE ROW LEVEL SECURITY;

-- RLS Policy: Admins can view ai_events
CREATE POLICY "Admins can view ai events"
  ON ai_events FOR SELECT
  USING (
    auth.uid() IN (
      SELECT user_id
      FROM user_roles
      WHERE role = 'admin' AND approved = true
    )
  );

-- RLS Policy: System can insert ai_events (for edge functions)
CREATE POLICY "System can insert ai events"
  ON ai_events FOR INSERT
  WITH CHECK (true);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_ai_events_entity ON ai_events(entity_type, entity_id);
CREATE INDEX IF NOT EXISTS idx_ai_events_created_at ON ai_events(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_leads_ai_score ON leads(ai_score DESC) WHERE ai_score IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_leads_ai_priority ON leads(ai_priority) WHERE ai_priority IS NOT NULL;

-- =================================================================
-- MIGRATION: 20251202012306_8eda6f96-890a-40a0-abb0-4a32408df324.sql
-- =================================================================
-- 1. Add AI fields to leads table
ALTER TABLE leads
  ADD COLUMN IF NOT EXISTS ai_score numeric,
  ADD COLUMN IF NOT EXISTS ai_priority text,
  ADD COLUMN IF NOT EXISTS ai_recommended_path text,
  ADD COLUMN IF NOT EXISTS ai_risk_flags text[],
  ADD COLUMN IF NOT EXISTS ai_notes jsonb,
  ADD COLUMN IF NOT EXISTS ai_last_evaluated_at timestamptz;

-- Add indexes for performance
CREATE INDEX IF NOT EXISTS idx_leads_ai_score ON leads (ai_score DESC NULLS LAST);
CREATE INDEX IF NOT EXISTS idx_leads_status ON leads (status);

-- 2. Create ai_events audit log table
CREATE TABLE IF NOT EXISTS ai_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  entity_type text NOT NULL,
  entity_id uuid NOT NULL,
  model_name text NOT NULL,
  event_type text NOT NULL,
  payload_in jsonb NOT NULL,
  payload_out jsonb NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE ai_events ENABLE ROW LEVEL SECURITY;

-- Policy: Admins can view all AI events
CREATE POLICY "Admins can see all ai_events"
  ON ai_events FOR SELECT
  USING (
    auth.uid() IN (
      SELECT user_id FROM user_roles
      WHERE role = 'admin' AND approved = true
    )
  );

-- Policy: System can insert AI events
CREATE POLICY "System can insert ai_events"
  ON ai_events FOR INSERT
  WITH CHECK (true);

-- =================================================================
-- MIGRATION: 20251202014918_ed8f4ace-ca4d-4a59-a3bd-705bf08f4fea.sql
-- =================================================================
-- Create credit_public_snapshot table for legal/public record checks
CREATE TABLE IF NOT EXISTS credit_public_snapshot (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id UUID REFERENCES leads(id) ON DELETE CASCADE,
  full_name TEXT,
  dob DATE,
  last4_ssn TEXT,
  address TEXT,
  city TEXT,
  state TEXT,
  postal_code TEXT,
  
  -- Public/legal signals (high-level, not raw CRA data)
  has_bankruptcy BOOLEAN DEFAULT false,
  bankruptcy_filed_at DATE,
  lien_count INTEGER DEFAULT 0,
  judgment_count INTEGER DEFAULT 0,
  ucc_count INTEGER DEFAULT 0,
  recent_default BOOLEAN DEFAULT false,
  
  risk_level TEXT, -- 'low' | 'medium' | 'high'
  readiness_score INTEGER, -- 0-100
  recommended_path TEXT, -- 'funding_first' | 'credit_fix_first' | 'mixed' | 'manual_review'
  vendor_name TEXT,
  vendor_reference TEXT,
  
  raw_vendor_payload JSONB,
  
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Index for fast lead lookups
CREATE INDEX IF NOT EXISTS idx_credit_public_snapshot_lead
  ON credit_public_snapshot (lead_id);

-- RLS policies
ALTER TABLE credit_public_snapshot ENABLE ROW LEVEL SECURITY;

-- Admins can view all snapshots
CREATE POLICY "Admins can view credit public snapshots"
  ON credit_public_snapshot
  FOR SELECT
  USING (has_role(auth.uid(), 'admin'::public.app_role));

-- System can insert snapshots
CREATE POLICY "System can insert credit public snapshots"
  ON credit_public_snapshot
  FOR INSERT
  WITH CHECK (true);

-- =================================================================
-- MIGRATION: 20251202020618_f7a1c2de-be1b-48bc-a2ef-b38a99afa2bd.sql
-- =================================================================
-- Add Smart Dialer V2 fields to leads table
ALTER TABLE leads
ADD COLUMN IF NOT EXISTS status TEXT DEFAULT 'new',
ADD COLUMN IF NOT EXISTS attempt_count INTEGER DEFAULT 0,
ADD COLUMN IF NOT EXISTS last_attempt_at TIMESTAMPTZ,
ADD COLUMN IF NOT EXISTS next_attempt_at TIMESTAMPTZ,
ADD COLUMN IF NOT EXISTS outcome TEXT;

-- Create index for smart queue query performance
CREATE INDEX IF NOT EXISTS idx_leads_smart_queue 
ON leads (status, next_attempt_at, ai_score DESC, created_at);

-- Add comment explaining allowed statuses
COMMENT ON COLUMN leads.status IS 'Allowed values: new, no_answer, contacted, interested, do_not_contact, bad_number';
COMMENT ON COLUMN leads.outcome IS 'Call outcome: interested, not_interested, bad_number, no_answer, etc.';

