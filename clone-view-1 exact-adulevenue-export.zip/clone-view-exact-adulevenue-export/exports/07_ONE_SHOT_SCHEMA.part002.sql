-- =================================================================
-- MIGRATION: 20251130065553_982d2d69-e332-47a2-891c-17bb9632c3c1.sql
-- =================================================================
-- Create document_extractions table for OCR results
CREATE TABLE IF NOT EXISTS public.document_extractions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  application_type TEXT NOT NULL,
  application_id UUID NOT NULL,
  document_type TEXT NOT NULL,
  raw_text TEXT,
  parsed_data JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Create funders table
CREATE TABLE IF NOT EXISTS public.funders (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  contact_email TEXT NOT NULL,
  portal_url TEXT,
  preferences JSONB DEFAULT '{}'::jsonb,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Create funder_submissions table
CREATE TABLE IF NOT EXISTS public.funder_submissions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  application_id UUID NOT NULL,
  application_type TEXT NOT NULL,
  funder_id UUID REFERENCES public.funders(id) ON DELETE CASCADE,
  mode TEXT NOT NULL CHECK (mode IN ('full', 'summary')),
  attachments_included JSONB DEFAULT '[]'::jsonb,
  sent_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  status TEXT DEFAULT 'sent' CHECK (status IN ('sent', 'opened', 'responded')),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Create legal_risk_feedback table
CREATE TABLE IF NOT EXISTS public.legal_risk_feedback (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  application_id UUID NOT NULL,
  application_type TEXT NOT NULL,
  finding_type TEXT NOT NULL,
  finding_id TEXT NOT NULL,
  is_relevant BOOLEAN NOT NULL,
  notes TEXT,
  created_by UUID NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Enable RLS on all new tables
ALTER TABLE public.document_extractions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.funders ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.funder_submissions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.legal_risk_feedback ENABLE ROW LEVEL SECURITY;

-- RLS policies for document_extractions
CREATE POLICY "Admins can view document extractions" ON public.document_extractions
  FOR SELECT USING (has_role(auth.uid(), 'admin'::public.app_role));

CREATE POLICY "System can insert document extractions" ON public.document_extractions
  FOR INSERT WITH CHECK (true);

-- RLS policies for funders
CREATE POLICY "Admins can manage funders" ON public.funders
  FOR ALL USING (has_role(auth.uid(), 'admin'::public.app_role));

-- RLS policies for funder_submissions
CREATE POLICY "Admins can view funder submissions" ON public.funder_submissions
  FOR SELECT USING (has_role(auth.uid(), 'admin'::public.app_role));

CREATE POLICY "Admins can create funder submissions" ON public.funder_submissions
  FOR INSERT WITH CHECK (has_role(auth.uid(), 'admin'::public.app_role));

CREATE POLICY "Admins can update funder submissions" ON public.funder_submissions
  FOR UPDATE USING (has_role(auth.uid(), 'admin'::public.app_role));

-- RLS policies for legal_risk_feedback
CREATE POLICY "Admins can manage legal risk feedback" ON public.legal_risk_feedback
  FOR ALL USING (has_role(auth.uid(), 'admin'::public.app_role));

-- Create indexes for performance
CREATE INDEX idx_document_extractions_application ON public.document_extractions(application_type, application_id);
CREATE INDEX idx_funder_submissions_application ON public.funder_submissions(application_type, application_id);
CREATE INDEX idx_funder_submissions_funder ON public.funder_submissions(funder_id);
CREATE INDEX idx_legal_risk_feedback_application ON public.legal_risk_feedback(application_type, application_id);

-- =================================================================
-- MIGRATION: 20251130081717_0fb90591-0f39-4ea7-b9cf-df1bf1ef89a4.sql
-- =================================================================
-- Create underwriting_feedback table for AI learning
CREATE TABLE IF NOT EXISTS public.underwriting_feedback (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  underwriting_case_id UUID NOT NULL REFERENCES public.underwriting_cases(id) ON DELETE CASCADE,
  application_id UUID NOT NULL,
  application_type TEXT NOT NULL,
  field TEXT NOT NULL, -- e.g., "existing_funding_lender", "risk_level", "nsf_count"
  original_value TEXT,
  corrected_value TEXT NOT NULL,
  feedback_type TEXT NOT NULL, -- "false_positive", "missed_detection", "incorrect_value", "incorrect_classification"
  notes TEXT,
  corrected_by UUID NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.underwriting_feedback ENABLE ROW LEVEL SECURITY;

-- Admins can insert feedback
CREATE POLICY "Admins can create feedback"
  ON public.underwriting_feedback
  FOR INSERT
  TO authenticated
  WITH CHECK (has_role(auth.uid(), 'admin'::public.app_role));

-- Admins can view all feedback
CREATE POLICY "Admins can view all feedback"
  ON public.underwriting_feedback
  FOR SELECT
  TO authenticated
  USING (has_role(auth.uid(), 'admin'::public.app_role));

-- Admins can update feedback
CREATE POLICY "Admins can update feedback"
  ON public.underwriting_feedback
  FOR UPDATE
  TO authenticated
  USING (has_role(auth.uid(), 'admin'::public.app_role));

-- Create index for faster lookups
CREATE INDEX idx_underwriting_feedback_case ON public.underwriting_feedback(underwriting_case_id);
CREATE INDEX idx_underwriting_feedback_field ON public.underwriting_feedback(field);
CREATE INDEX idx_underwriting_feedback_type ON public.underwriting_feedback(feedback_type);

-- =================================================================
-- MIGRATION: 20251130093619_99ef4984-c74b-4482-8ecc-8c47e790ccef.sql
-- =================================================================
-- Fix document_extractions INSERT policy to restrict to admins only
-- This prevents unauthorized users from inserting arbitrary document extraction records

-- Drop the existing overly permissive policy
DROP POLICY IF EXISTS "System can insert document extractions" ON document_extractions;

-- Create new admin-only INSERT policy
CREATE POLICY "Admins can insert document extractions" 
ON document_extractions 
FOR INSERT 
WITH CHECK (has_role(auth.uid(), 'admin'::public.app_role));

-- Note: Edge functions using service role client will bypass RLS automatically

-- =================================================================
-- MIGRATION: 20251130094852_c99dd3bf-a5d5-477a-a494-eaa04551aaaf.sql
-- =================================================================
-- Fix RLS policies for intake_logs, iso_partner_applications, and loan_applications
-- These tables currently allow any authenticated user to insert, but should restrict based on role

-- Fix intake_logs: Only workers and admins can create intake logs
DROP POLICY IF EXISTS "Workers can create intake logs" ON intake_logs;

CREATE POLICY "Workers and admins can create intake logs"
ON intake_logs
FOR INSERT
WITH CHECK (
  has_role(auth.uid(), 'worker'::public.app_role) OR 
  has_role(auth.uid(), 'admin'::public.app_role)
);

-- Fix iso_partner_applications: Anyone can submit (public form), but add user_id check for authenticated submissions
DROP POLICY IF EXISTS "Anyone can submit ISO applications" ON iso_partner_applications;

CREATE POLICY "Public and authenticated users can submit ISO applications"
ON iso_partner_applications
FOR INSERT
WITH CHECK (
  (auth.uid() IS NULL) OR  -- Allow public submissions
  (user_id = auth.uid() OR user_id IS NULL)  -- If authenticated, must match user_id
);

-- Fix loan_applications: Only authenticated users for their own records
DROP POLICY IF EXISTS "Authenticated users can submit loan applications" ON loan_applications;

CREATE POLICY "Users can submit loan applications for themselves"
ON loan_applications
FOR INSERT
WITH CHECK (
  auth.uid() IS NOT NULL AND 
  (user_id = auth.uid())
);

-- Fix fast_track_applications for consistency (already mostly correct but tighten)
DROP POLICY IF EXISTS "Authenticated users can submit applications" ON fast_track_applications;

CREATE POLICY "Users can submit fast track applications for themselves"
ON fast_track_applications
FOR INSERT
WITH CHECK (
  auth.uid() IS NOT NULL AND 
  (user_id = auth.uid())
);

-- =================================================================
-- MIGRATION: 20251130162202_f409e497-ca5c-4320-b33c-cfd483af3f62.sql
-- =================================================================
-- Add client_name field to fast_track_applications table
ALTER TABLE public.fast_track_applications
ADD COLUMN IF NOT EXISTS client_name TEXT;

-- =================================================================
-- MIGRATION: 20251130174120_4b80a65b-8637-4120-946d-6fb1b9499491.sql
-- =================================================================
-- Create funded_contracts table to track active funding agreements
CREATE TABLE IF NOT EXISTS public.funded_contracts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  application_id UUID NOT NULL,
  application_type TEXT NOT NULL CHECK (application_type IN ('fast_track', 'loan')),
  client_name TEXT NOT NULL,
  business_name TEXT NOT NULL,
  funding_amount NUMERIC NOT NULL,
  daily_payment NUMERIC,
  contract_start_date TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  contract_end_date TIMESTAMP WITH TIME ZONE NOT NULL,
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'completed', 'defaulted', 'renewed')),
  renewal_eligible BOOLEAN DEFAULT false,
  original_credit_score TEXT,
  original_revenue NUMERIC,
  notes TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.funded_contracts ENABLE ROW LEVEL SECURITY;

-- Admin can manage all funded contracts
CREATE POLICY "Admins can manage funded contracts"
ON public.funded_contracts
FOR ALL
USING (has_role(auth.uid(), 'admin'::public.app_role));

-- Create index for performance
CREATE INDEX idx_funded_contracts_end_date ON public.funded_contracts(contract_end_date);
CREATE INDEX idx_funded_contracts_status ON public.funded_contracts(status);
CREATE INDEX idx_funded_contracts_renewal_eligible ON public.funded_contracts(renewal_eligible);

-- Create trigger for updated_at
CREATE TRIGGER update_funded_contracts_updated_at
BEFORE UPDATE ON public.funded_contracts
FOR EACH ROW
EXECUTE FUNCTION public.handle_updated_at();

-- Create renewal_opportunities table to track identified upsell chances
CREATE TABLE IF NOT EXISTS public.renewal_opportunities (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  funded_contract_id UUID NOT NULL REFERENCES public.funded_contracts(id) ON DELETE CASCADE,
  opportunity_type TEXT NOT NULL CHECK (opportunity_type IN ('renewal', 'upsell', 'refinance')),
  suggested_amount NUMERIC,
  reason TEXT NOT NULL,
  current_metrics JSONB,
  comparison_metrics JSONB,
  priority TEXT DEFAULT 'medium' CHECK (priority IN ('low', 'medium', 'high')),
  status TEXT DEFAULT 'identified' CHECK (status IN ('identified', 'contacted', 'approved', 'declined', 'converted')),
  identified_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  contacted_at TIMESTAMP WITH TIME ZONE,
  resolved_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.renewal_opportunities ENABLE ROW LEVEL SECURITY;

-- Admin can manage all renewal opportunities
CREATE POLICY "Admins can manage renewal opportunities"
ON public.renewal_opportunities
FOR ALL
USING (has_role(auth.uid(), 'admin'::public.app_role));

-- Create index for performance
CREATE INDEX idx_renewal_opportunities_status ON public.renewal_opportunities(status);
CREATE INDEX idx_renewal_opportunities_priority ON public.renewal_opportunities(priority);
CREATE INDEX idx_renewal_opportunities_contract_id ON public.renewal_opportunities(funded_contract_id);

-- =================================================================
-- MIGRATION: 20251130175018_1aba0957-eaa8-4111-aae6-bef8084ff9b5.sql
-- =================================================================
-- ISO Commission Tracking Tables
CREATE TABLE IF NOT EXISTS public.iso_commissions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  iso_partner_id UUID NOT NULL REFERENCES iso_partner_applications(id) ON DELETE CASCADE,
  funded_contract_id UUID NOT NULL REFERENCES funded_contracts(id) ON DELETE CASCADE,
  commission_rate DECIMAL(5,2) NOT NULL, -- e.g., 5.00 for 5%
  commission_amount DECIMAL(12,2) NOT NULL,
  payment_status TEXT NOT NULL DEFAULT 'pending' CHECK (payment_status IN ('pending', 'processing', 'paid', 'cancelled')),
  payment_date TIMESTAMP WITH TIME ZONE,
  payment_method TEXT,
  notes TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

CREATE INDEX idx_iso_commissions_partner ON public.iso_commissions(iso_partner_id);
CREATE INDEX idx_iso_commissions_contract ON public.iso_commissions(funded_contract_id);
CREATE INDEX idx_iso_commissions_status ON public.iso_commissions(payment_status);

-- Risk Alerts and Monitoring
CREATE TABLE IF NOT EXISTS public.risk_alerts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  alert_type TEXT NOT NULL CHECK (alert_type IN ('high_risk_application', 'credit_score_drop', 'payment_default', 'fraud_suspicion', 'contract_breach', 'overdue_payment')),
  severity TEXT NOT NULL DEFAULT 'medium' CHECK (severity IN ('low', 'medium', 'high', 'critical')),
  entity_type TEXT NOT NULL CHECK (entity_type IN ('application', 'contract', 'client', 'worker', 'iso_partner')),
  entity_id UUID NOT NULL,
  title TEXT NOT NULL,
  description TEXT NOT NULL,
  metadata JSONB,
  status TEXT NOT NULL DEFAULT 'open' CHECK (status IN ('open', 'acknowledged', 'investigating', 'resolved', 'dismissed')),
  assigned_to UUID,
  resolved_at TIMESTAMP WITH TIME ZONE,
  resolved_by UUID,
  resolution_notes TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

CREATE INDEX idx_risk_alerts_type ON public.risk_alerts(alert_type);
CREATE INDEX idx_risk_alerts_severity ON public.risk_alerts(severity);
CREATE INDEX idx_risk_alerts_status ON public.risk_alerts(status);
CREATE INDEX idx_risk_alerts_entity ON public.risk_alerts(entity_type, entity_id);
CREATE INDEX idx_risk_alerts_created ON public.risk_alerts(created_at DESC);

-- Contract Templates and Documents
CREATE TABLE IF NOT EXISTS public.contract_templates (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  template_name TEXT NOT NULL,
  template_type TEXT NOT NULL CHECK (template_type IN ('funding_agreement', 'iso_agreement', 'credit_repair_agreement', 'service_agreement', 'amendment')),
  template_content TEXT NOT NULL,
  variables JSONB, -- JSON array of variable placeholders
  version INTEGER NOT NULL DEFAULT 1,
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_by UUID,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

CREATE INDEX idx_contract_templates_type ON public.contract_templates(template_type);
CREATE INDEX idx_contract_templates_active ON public.contract_templates(is_active);

-- Audit Log for Compliance
CREATE TABLE IF NOT EXISTS public.audit_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL,
  action_type TEXT NOT NULL CHECK (action_type IN ('view', 'create', 'update', 'delete', 'export', 'approve', 'reject', 'send', 'sign')),
  resource_type TEXT NOT NULL CHECK (resource_type IN ('application', 'contract', 'user', 'commission', 'document', 'report', 'credit_repair_case', 'underwriting_case')),
  resource_id UUID NOT NULL,
  changes JSONB, -- before/after values for updates
  ip_address TEXT,
  user_agent TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

CREATE INDEX idx_audit_logs_user ON public.audit_logs(user_id);
CREATE INDEX idx_audit_logs_resource ON public.audit_logs(resource_type, resource_id);
CREATE INDEX idx_audit_logs_action ON public.audit_logs(action_type);
CREATE INDEX idx_audit_logs_created ON public.audit_logs(created_at DESC);

-- Communication Log for automated workflows
CREATE TABLE IF NOT EXISTS public.communication_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  recipient_type TEXT NOT NULL CHECK (recipient_type IN ('client', 'worker', 'iso_partner', 'admin')),
  recipient_id UUID NOT NULL,
  recipient_email TEXT,
  recipient_phone TEXT,
  communication_type TEXT NOT NULL CHECK (communication_type IN ('email', 'sms', 'push')),
  template_name TEXT,
  subject TEXT,
  content TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'sent', 'delivered', 'failed', 'bounced')),
  sent_at TIMESTAMP WITH TIME ZONE,
  delivered_at TIMESTAMP WITH TIME ZONE,
  error_message TEXT,
  metadata JSONB,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

CREATE INDEX idx_communication_logs_recipient ON public.communication_logs(recipient_type, recipient_id);
CREATE INDEX idx_communication_logs_status ON public.communication_logs(status);
CREATE INDEX idx_communication_logs_created ON public.communication_logs(created_at DESC);

-- Add triggers for updated_at
CREATE TRIGGER update_iso_commissions_updated_at
  BEFORE UPDATE ON public.iso_commissions
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_updated_at();

CREATE TRIGGER update_risk_alerts_updated_at
  BEFORE UPDATE ON public.risk_alerts
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_updated_at();

CREATE TRIGGER update_contract_templates_updated_at
  BEFORE UPDATE ON public.contract_templates
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_updated_at();

-- RLS Policies (Admin-only access)
ALTER TABLE public.iso_commissions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.risk_alerts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.contract_templates ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.audit_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.communication_logs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admin full access to iso_commissions" ON public.iso_commissions FOR ALL USING (
  EXISTS (
    SELECT 1 FROM public.user_roles
    WHERE user_roles.user_id = auth.uid()
    AND user_roles.role = 'admin'
    AND user_roles.approved = true
  )
);

CREATE POLICY "Admin full access to risk_alerts" ON public.risk_alerts FOR ALL USING (
  EXISTS (
    SELECT 1 FROM public.user_roles
    WHERE user_roles.user_id = auth.uid()
    AND user_roles.role = 'admin'
    AND user_roles.approved = true
  )
);

CREATE POLICY "Admin full access to contract_templates" ON public.contract_templates FOR ALL USING (
  EXISTS (
    SELECT 1 FROM public.user_roles
    WHERE user_roles.user_id = auth.uid()
    AND user_roles.role = 'admin'
    AND user_roles.approved = true
  )
);

CREATE POLICY "Admin full access to audit_logs" ON public.audit_logs FOR ALL USING (
  EXISTS (
    SELECT 1 FROM public.user_roles
    WHERE user_roles.user_id = auth.uid()
    AND user_roles.role = 'admin'
    AND user_roles.approved = true
  )
);

CREATE POLICY "Admin full access to communication_logs" ON public.communication_logs FOR ALL USING (
  EXISTS (
    SELECT 1 FROM public.user_roles
    WHERE user_roles.user_id = auth.uid()
    AND user_roles.role = 'admin'
    AND user_roles.approved = true
  )
);

-- =================================================================
-- MIGRATION: 20251130201708_a52c7e70-19f8-48b0-bd98-ef1cea62075c.sql
-- =================================================================
-- Lead Generation System Tables

-- Lead assignments table
CREATE TABLE IF NOT EXISTS public.lead_assignments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_name TEXT NOT NULL,
  lead_email TEXT,
  lead_phone TEXT,
  lead_business_name TEXT,
  lead_source TEXT,
  lead_status TEXT DEFAULT 'new',
  assigned_worker_id UUID,
  assigned_at TIMESTAMPTZ,
  last_contact_at TIMESTAMPTZ,
  next_follow_up_date TIMESTAMPTZ,
  lead_score INTEGER DEFAULT 0,
  notes TEXT,
  metadata JSONB DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- Worker activity logs table
CREATE TABLE IF NOT EXISTS public.worker_activity_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  worker_id UUID NOT NULL,
  worker_type TEXT DEFAULT 'human',
  activity_type TEXT NOT NULL,
  lead_id UUID REFERENCES public.lead_assignments(id) ON DELETE CASCADE,
  action_description TEXT NOT NULL,
  approval_status TEXT DEFAULT 'pending',
  approved_by UUID,
  approved_at TIMESTAMPTZ,
  metadata JSONB DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Outbound emails table
CREATE TABLE IF NOT EXISTS public.outbound_emails (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id UUID REFERENCES public.lead_assignments(id) ON DELETE CASCADE,
  worker_id UUID NOT NULL,
  worker_type TEXT DEFAULT 'human',
  recipient_email TEXT NOT NULL,
  subject TEXT NOT NULL,
  body TEXT NOT NULL,
  draft_status TEXT DEFAULT 'draft',
  sent_at TIMESTAMPTZ,
  opened_at TIMESTAMPTZ,
  replied_at TIMESTAMPTZ,
  approval_status TEXT DEFAULT 'pending',
  approved_by UUID,
  approved_at TIMESTAMPTZ,
  metadata JSONB DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.lead_assignments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.worker_activity_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.outbound_emails ENABLE ROW LEVEL SECURITY;

-- RLS Policies for lead_assignments
CREATE POLICY "Admins can manage all leads"
  ON public.lead_assignments FOR ALL
  USING (has_role(auth.uid(), 'admin'::public.app_role));

CREATE POLICY "Lead gen workers can view assigned leads"
  ON public.lead_assignments FOR SELECT
  USING (
    assigned_worker_id = auth.uid() OR
    has_role(auth.uid(), 'admin'::public.app_role)
  );

-- RLS Policies for worker_activity_logs
CREATE POLICY "Admins can view all activity logs"
  ON public.worker_activity_logs FOR SELECT
  USING (has_role(auth.uid(), 'admin'::public.app_role));

CREATE POLICY "Workers can view their own activity"
  ON public.worker_activity_logs FOR SELECT
  USING (worker_id = auth.uid());

CREATE POLICY "System can insert activity logs"
  ON public.worker_activity_logs FOR INSERT
  WITH CHECK (true);

-- RLS Policies for outbound_emails
CREATE POLICY "Admins can manage all outbound emails"
  ON public.outbound_emails FOR ALL
  USING (has_role(auth.uid(), 'admin'::public.app_role));

CREATE POLICY "Workers can view their own emails"
  ON public.outbound_emails FOR SELECT
  USING (worker_id = auth.uid());

CREATE POLICY "System can insert outbound emails"
  ON public.outbound_emails FOR INSERT
  WITH CHECK (true);

-- Add is_lead_gen_worker flag to user_roles table metadata
COMMENT ON COLUMN public.user_roles.role IS 'User role with optional lead_gen flag in metadata';

-- Indexes for performance
CREATE INDEX idx_lead_assignments_worker ON public.lead_assignments(assigned_worker_id);
CREATE INDEX idx_lead_assignments_status ON public.lead_assignments(lead_status);
CREATE INDEX idx_worker_activity_logs_worker ON public.worker_activity_logs(worker_id);
CREATE INDEX idx_worker_activity_logs_lead ON public.worker_activity_logs(lead_id);
CREATE INDEX idx_outbound_emails_lead ON public.outbound_emails(lead_id);
CREATE INDEX idx_outbound_emails_worker ON public.outbound_emails(worker_id);

-- Trigger for updated_at
CREATE TRIGGER update_lead_assignments_updated_at
  BEFORE UPDATE ON public.lead_assignments
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_updated_at();

-- =================================================================
-- MIGRATION: 20251130213326_90150b31-539c-4c92-aaea-73f0090c5781.sql
-- =================================================================
-- Create email_templates table
CREATE TABLE IF NOT EXISTS email_templates (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  template_type TEXT NOT NULL, -- 'iso_approval', 'credit_repair', 'funder_notification', 'ai_outreach', 'reminder'
  subject TEXT NOT NULL,
  body TEXT NOT NULL,
  is_default BOOLEAN DEFAULT false,
  created_by UUID REFERENCES auth.users(id),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Enable RLS
ALTER TABLE email_templates ENABLE ROW LEVEL SECURITY;

-- Admin full access
CREATE POLICY "Admins can manage email templates"
  ON email_templates
  FOR ALL
  TO authenticated
  USING (has_role(auth.uid(), 'admin'::public.app_role));

-- Add trigger for updated_at
CREATE TRIGGER update_email_templates_updated_at
  BEFORE UPDATE ON email_templates
  FOR EACH ROW
  EXECUTE FUNCTION handle_updated_at();

-- Insert default templates
INSERT INTO email_templates (name, template_type, subject, body, is_default) VALUES
('ISO Partner Approval', 'iso_approval', 'Welcome to Wolf Fund - ISO Partner Approved', 
'<h1>Congratulations, {{iso_name}}!</h1>
<p>Your ISO Partner application has been approved. You now have access to the Wolf Fund platform.</p>
<p>You can now:</p>
<ul>
  <li>Submit Fast Track applications for your clients</li>
  <li>Log client intakes</li>
  <li>Track your submissions and commissions</li>
</ul>
<p>Login at: https://wolffund.app</p>
<p>Best regards,<br>Wolf Fund Team</p>', true),

('Credit Repair Activation', 'credit_repair', 'Client Moved to Credit Repair Track', 
'<h1>Credit Repair Case Assigned</h1>
<p>A client has been moved into the Credit Repair track:</p>
<p><strong>Client:</strong> {{client_name}}<br>
<strong>Business:</strong> {{business_name}}</p>
<p>Please upload any supporting documents and stay in touch with your admin for next steps.</p>
<p>Best regards,<br>Wolf Fund Team</p>', true),

('Funder Submission', 'funder_notification', 'New Funding Application - {{business_name}}', 
'<h1>New Funding Application</h1>
<p>We have a new funding opportunity for your review:</p>
<p><strong>Business:</strong> {{business_name}}<br>
<strong>Requested Amount:</strong> ${{funding_amount}}<br>
<strong>Industry:</strong> {{industry}}</p>
<p>{{funder_safe_summary}}</p>
<p>Please review and let us know if you would like to proceed.</p>
<p>Best regards,<br>Wolf Fund</p>', true),

('Follow-Up Reminder', 'reminder', 'Follow-Up Reminder - {{client_name}}', 
'<h1>Follow-Up Task Reminder</h1>
<p><strong>Client:</strong> {{client_name}}<br>
<strong>Business:</strong> {{business_name}}</p>
<p>It has been 20 days since onboarding. Please reach out to check on their status and discuss potential next steps or additional funding opportunities.</p>
<p>Best regards,<br>Wolf Fund Team</p>', true),

('AI Outreach', 'ai_outreach', '{{subject}}', 
'<p>{{body}}</p>
<p>Best regards,<br>Wolf Fund Team</p>', true);

-- =================================================================
-- MIGRATION: 20251130235534_48e37b54-0bff-4c94-8385-cbf12ab7f004.sql
-- =================================================================
-- Add scan tracking fields to underwriting_cases
ALTER TABLE underwriting_cases 
ADD COLUMN IF NOT EXISTS last_scan_at TIMESTAMP WITH TIME ZONE,
ADD COLUMN IF NOT EXISTS next_scan_at TIMESTAMP WITH TIME ZONE;

-- Add scan tracking fields to fast_track_applications
ALTER TABLE fast_track_applications
ADD COLUMN IF NOT EXISTS last_scan_at TIMESTAMP WITH TIME ZONE,
ADD COLUMN IF NOT EXISTS next_scan_at TIMESTAMP WITH TIME ZONE;

-- Add scan tracking fields to loan_applications
ALTER TABLE loan_applications
ADD COLUMN IF NOT EXISTS last_scan_at TIMESTAMP WITH TIME ZONE,
ADD COLUMN IF NOT EXISTS next_scan_at TIMESTAMP WITH TIME ZONE;

-- Add scan tracking fields to credit_repair_cases
ALTER TABLE credit_repair_cases
ADD COLUMN IF NOT EXISTS last_scan_at TIMESTAMP WITH TIME ZONE,
ADD COLUMN IF NOT EXISTS next_scan_at TIMESTAMP WITH TIME ZONE;

-- Add commission_rate to iso_partner_applications for tracking per-ISO rates
ALTER TABLE iso_partner_applications
ADD COLUMN IF NOT EXISTS commission_rate NUMERIC DEFAULT 8.0;

-- Create index for efficient scan queries
CREATE INDEX IF NOT EXISTS idx_underwriting_last_scan ON underwriting_cases(last_scan_at);
CREATE INDEX IF NOT EXISTS idx_fast_track_last_scan ON fast_track_applications(last_scan_at);
CREATE INDEX IF NOT EXISTS idx_loan_last_scan ON loan_applications(last_scan_at);
CREATE INDEX IF NOT EXISTS idx_credit_repair_last_scan ON credit_repair_cases(last_scan_at);

-- =================================================================
-- MIGRATION: 20251201045513_40142c6a-7f18-4326-83ab-6dfd2eba02cb.sql
-- =================================================================
-- Phase 1: Credit Fix Back Office Database Schema

-- Enhance credit_repair_items table with AI dispute fields
ALTER TABLE credit_repair_items
ADD COLUMN IF NOT EXISTS dispute_reason TEXT,
ADD COLUMN IF NOT EXISTS dispute_basis_code TEXT,
ADD COLUMN IF NOT EXISTS source_bureau TEXT,
ADD COLUMN IF NOT EXISTS collector_state TEXT,
ADD COLUMN IF NOT EXISTS client_state TEXT,
ADD COLUMN IF NOT EXISTS risk_tags TEXT[],
ADD COLUMN IF NOT EXISTS ai_generated BOOLEAN DEFAULT false,
ADD COLUMN IF NOT EXISTS ai_last_reviewed_at TIMESTAMP WITH TIME ZONE;

-- Add comment to dispute_basis_code for clarity
COMMENT ON COLUMN credit_repair_items.dispute_basis_code IS 'Enum-like values: licensing_issue, reporting_inconsistency, validation_requested, unverified_debt, statute_of_limitations, identity_theft, inaccurate_dates, duplicate_entry';

-- Add comment to source_bureau
COMMENT ON COLUMN credit_repair_items.source_bureau IS 'Values: experian, equifax, transunion, all';

-- Create credit_repair_dispute_drafts table
CREATE TABLE IF NOT EXISTS credit_repair_dispute_drafts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  case_id UUID NOT NULL REFERENCES credit_repair_cases(id) ON DELETE CASCADE,
  item_id UUID REFERENCES credit_repair_items(id) ON DELETE SET NULL,
  target TEXT NOT NULL CHECK (target IN ('bureau', 'creditor', 'collector')),
  target_name TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'draft' CHECK (status IN ('draft', 'approved', 'archived')),
  subject TEXT NOT NULL,
  body TEXT NOT NULL,
  created_by UUID NOT NULL,
  worker_type TEXT NOT NULL DEFAULT 'human' CHECK (worker_type IN ('ai', 'human')),
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Add index for performance
CREATE INDEX IF NOT EXISTS idx_dispute_drafts_case_id ON credit_repair_dispute_drafts(case_id);
CREATE INDEX IF NOT EXISTS idx_dispute_drafts_item_id ON credit_repair_dispute_drafts(item_id);
CREATE INDEX IF NOT EXISTS idx_dispute_drafts_status ON credit_repair_dispute_drafts(status);

-- Enable RLS on credit_repair_dispute_drafts
ALTER TABLE credit_repair_dispute_drafts ENABLE ROW LEVEL SECURITY;

-- RLS Policies for credit_repair_dispute_drafts
CREATE POLICY "Credit specialists can view drafts for assigned cases"
ON credit_repair_dispute_drafts
FOR SELECT
USING (
  EXISTS (
    SELECT 1 FROM credit_repair_cases
    WHERE credit_repair_cases.id = credit_repair_dispute_drafts.case_id
    AND (
      (has_role(auth.uid(), 'credit_repair_specialist'::public.app_role) AND credit_repair_cases.assigned_specialist_id = auth.uid())
      OR has_role(auth.uid(), 'admin'::public.app_role)
    )
  )
);

CREATE POLICY "Credit specialists can insert drafts for assigned cases"
ON credit_repair_dispute_drafts
FOR INSERT
WITH CHECK (
  EXISTS (
    SELECT 1 FROM credit_repair_cases
    WHERE credit_repair_cases.id = credit_repair_dispute_drafts.case_id
    AND (
      (has_role(auth.uid(), 'credit_repair_specialist'::public.app_role) AND credit_repair_cases.assigned_specialist_id = auth.uid())
      OR has_role(auth.uid(), 'admin'::public.app_role)
    )
  )
  AND created_by = auth.uid()
);

CREATE POLICY "Credit specialists can update drafts for assigned cases"
ON credit_repair_dispute_drafts
FOR UPDATE
USING (
  EXISTS (
    SELECT 1 FROM credit_repair_cases
    WHERE credit_repair_cases.id = credit_repair_dispute_drafts.case_id
    AND (
      (has_role(auth.uid(), 'credit_repair_specialist'::public.app_role) AND credit_repair_cases.assigned_specialist_id = auth.uid())
      OR has_role(auth.uid(), 'admin'::public.app_role)
    )
  )
);

CREATE POLICY "Admins can delete dispute drafts"
ON credit_repair_dispute_drafts
FOR DELETE
USING (has_role(auth.uid(), 'admin'::public.app_role));

-- Enhance credit_repair_tasks with source field
ALTER TABLE credit_repair_tasks
ADD COLUMN IF NOT EXISTS source TEXT DEFAULT 'manual' CHECK (source IN ('ai', 'manual'));

-- Add trigger for updated_at on dispute_drafts
CREATE TRIGGER update_dispute_drafts_updated_at
BEFORE UPDATE ON credit_repair_dispute_drafts
FOR EACH ROW
EXECUTE FUNCTION public.handle_updated_at();

-- =================================================================
-- MIGRATION: 20251201054729_cae4f687-29db-4e6c-845e-954c2b37c5c2.sql
-- =================================================================
-- Phase 2: Compliance & UX Database Enhancements

-- 1. Add compliance fields to credit_repair_items
ALTER TABLE credit_repair_items
ADD COLUMN IF NOT EXISTS metro2_code TEXT,
ADD COLUMN IF NOT EXISTS fcra_section TEXT,
ADD COLUMN IF NOT EXISTS fdcpa_section TEXT;

-- 2. Create standards reference table
CREATE TABLE IF NOT EXISTS credit_standards_reference (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    standard_type TEXT NOT NULL,
    reference_code TEXT NOT NULL,
    description TEXT,
    jurisdiction TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 3. Enable RLS on credit_standards_reference
ALTER TABLE credit_standards_reference ENABLE ROW LEVEL SECURITY;

-- 4. RLS policies for credit_standards_reference
CREATE POLICY "Credit specialists and admins can view standards"
ON credit_standards_reference FOR SELECT
TO authenticated
USING (
  has_role(auth.uid(), 'credit_repair_specialist'::public.app_role) OR 
  has_role(auth.uid(), 'admin'::public.app_role)
);

CREATE POLICY "Admins can manage standards"
ON credit_standards_reference FOR ALL
TO authenticated
USING (has_role(auth.uid(), 'admin'::public.app_role));

-- 5. Pre-populate compliance reference data
INSERT INTO credit_standards_reference (standard_type, reference_code, description, jurisdiction) VALUES
('FCRA', '§611', 'Right to dispute inaccuracies – bureaus must investigate within 30 days.', 'Federal'),
('FCRA', '§609', 'Right to access full consumer report including account details.', 'Federal'),
('FCRA', '§623', 'Responsibilities of furnishers of information to consumer reporting agencies.', 'Federal'),
('FDCPA', '§807', 'Prohibits false, deceptive, or misleading representation in collection of debts.', 'Federal'),
('FDCPA', '§806', 'Harassment or abuse restrictions – no oppressive conduct.', 'Federal'),
('FDCPA', '§812', 'Requires debt collectors to be licensed in consumer''s state of residence.', 'Varies by state'),
('FDCPA', '§704', 'Acquisition of location information – restrictions on third-party contacts.', 'Federal'),
('METRO2', 'METRO2-001', 'Account Status (DS) – data must reflect accurate date of last activity.', 'Industry'),
('METRO2', 'METRO2-050', 'Data Field 50 – Compliance review for credit furnishing accuracy.', 'Industry'),
('METRO2', 'METRO2-J1', 'J1 Segment – Account information must match across all reporting agencies.', 'Industry'),
('METRO2', 'METRO2-K2', 'K2 Segment – Original creditor information accuracy requirements.', 'Industry')
ON CONFLICT DO NOTHING;

-- =================================================================
-- MIGRATION: 20251201060146_ed5e27bb-a0b5-48dc-8f2c-fb94ac8f9052.sql
-- =================================================================
-- Insert dispute letter templates with compliance placeholders
INSERT INTO email_templates (name, template_type, subject, body, is_default) VALUES
(
  'Bureau Dispute Letter - Compliance',
  'dispute_letter_bureau',
  'Formal Dispute Request - Account Verification',
  '<p>To Whom It May Concern,</p>

<p>I am writing to formally dispute the following information on my credit report:</p>

<p><strong>Account Details:</strong><br/>
Creditor: {{creditor_name}}<br/>
Account Number: {{account_number}}<br/>
Item Type: {{item_type}}</p>

<p><strong>Dispute Basis:</strong><br/>
{{dispute_reason}}</p>

<p><strong>Legal Reference:</strong><br/>
Pursuant to {{fcra_section}} of the Fair Credit Reporting Act, I request immediate investigation of this account and verification of its accuracy.</p>

<p><strong>Reporting Standards:</strong><br/>
The information reported appears inconsistent with Metro 2 reporting standards ({{metro2_code}}).</p>

<p><strong>Collection Practices:</strong><br/>
Please note that under {{fdcpa_section}} of the Fair Debt Collection Practices Act, certain collection activities may require proper licensing and compliance with federal regulations.</p>

<p>Please conduct a thorough investigation and provide written verification of this debt within 30 days as required by law. If you cannot verify this information, it must be removed from my credit report immediately.</p>

<p>Sincerely,<br/>
{{client_name}}</p>',
  true
),
(
  'Creditor Validation Request - Compliance',
  'dispute_letter_creditor',
  'Account Validation Request - {{account_number}}',
  '<p>Dear {{creditor_name}},</p>

<p>I am requesting validation of the following account reported on my credit file:</p>

<p><strong>Account Information:</strong><br/>
Account Number: {{account_number}}<br/>
Current Status: {{item_status}}</p>

<p><strong>Validation Request:</strong><br/>
{{dispute_reason}}</p>

<p>Under {{fcra_section}}, I have the right to dispute any information I believe to be inaccurate, incomplete, or unverifiable.</p>

<p>Please ensure all reporting complies with Metro 2 standards ({{metro2_code}}) regarding accurate account status and date reporting.</p>

<p>Additionally, pursuant to {{fdcpa_section}}, I request confirmation of proper licensing and authorization to collect or report on this account.</p>

<p>Please provide the following documentation:<br/>
1. Original signed contract or agreement<br/>
2. Complete payment history<br/>
3. Verification of your legal right to report this account<br/>
4. Chain of custody if this account was sold or transferred</p>

<p>If you cannot provide complete validation within 30 days, please update your records to reflect deletion of this account and notify all credit bureaus accordingly.</p>

<p>Best regards,<br/>
{{client_name}}</p>',
  true
);

