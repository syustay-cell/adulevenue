-- ENUMS EXPORT
-- Project Ref: tdzuhcswrojlleeupqvd
-- Export Date: 2025-12-14

-- ai_report_type enum
CREATE TYPE public.ai_report_type AS ENUM (
  'underwriting',
  'legal_search',
  'lien_bankruptcy',
  'business_background',
  'credit_analysis',
  'lead_enrichment',
  'research_summary'
);

-- app_role enum
CREATE TYPE public.app_role AS ENUM (
  'admin',
  'user',
  'worker',
  'credit_repair_specialist',
  'underwriter',
  'owner',
  'legal',
  'tenant_admin',
  'iso_partner'
);

-- case_stage enum
CREATE TYPE public.case_stage AS ENUM (
  'lead_new',
  'lead_contacted',
  'docs_requested',
  'docs_received',
  'uw_in_review',
  'uw_conditional',
  'uw_approved',
  'uw_declined',
  'sent_to_credit_fix',
  'credit_fix_in_progress',
  'credit_fix_ready_for_uw',
  'offer_sent',
  'offer_accepted',
  'funded',
  'closed_lost'
);

-- participant_role enum
CREATE TYPE public.participant_role AS ENUM (
  'OPENER',
  'CLOSER',
  'REFERRAL_PARTNER',
  'ISO_PARTNER',
  'HOUSE',
  'AI_AUTOPILOT'
);

-- product_line enum
CREATE TYPE public.product_line AS ENUM (
  'mca',
  'term_loan',
  'loc',
  'credit_fix_only',
  'hybrid',
  'general',
  'credit_fix',
  'loan'
);

-- request_status enum
CREATE TYPE public.request_status AS ENUM (
  'PENDING',
  'SUCCESS',
  'ERROR'
);
