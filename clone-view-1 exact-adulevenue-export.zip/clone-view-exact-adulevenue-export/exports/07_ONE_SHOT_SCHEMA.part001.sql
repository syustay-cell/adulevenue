-- =================================================================
-- MIGRATION: 20251129013534_ec4a5826-0a8b-4456-ad2c-6fe7f85dddc1.sql
-- =================================================================
-- Create table for fast track applications
CREATE TABLE public.fast_track_applications (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  email TEXT NOT NULL,
  business_name TEXT NOT NULL,
  phone TEXT NOT NULL,
  
  -- Document file paths in storage
  driver_license_front TEXT,
  driver_license_back TEXT,
  ein_document TEXT,
  ssn_card TEXT,
  void_check TEXT,
  bank_statements TEXT[], -- Array for multiple bank statement files
  
  -- Business questions
  in_business_over_6_months BOOLEAN NOT NULL,
  has_previous_loan BOOLEAN NOT NULL,
  previous_loan_company TEXT,
  previous_loan_amount TEXT,
  credit_score TEXT,
  
  -- Application metadata
  status TEXT NOT NULL DEFAULT 'pending',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.fast_track_applications ENABLE ROW LEVEL SECURITY;

-- Allow anyone to insert (public application)
CREATE POLICY "Anyone can submit fast track application"
ON public.fast_track_applications
FOR INSERT
TO anon, authenticated
WITH CHECK (true);

-- Only authenticated users can view (for admin back office)
CREATE POLICY "Authenticated users can view applications"
ON public.fast_track_applications
FOR SELECT
TO authenticated
USING (true);

-- Create storage bucket for application documents
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
  'fast-track-documents',
  'fast-track-documents',
  false,
  52428800, -- 50MB limit
  ARRAY['image/jpeg', 'image/png', 'image/jpg', 'application/pdf']
);

-- Storage policies for document uploads
CREATE POLICY "Anyone can upload documents"
ON storage.objects
FOR INSERT
TO anon, authenticated
WITH CHECK (bucket_id = 'fast-track-documents');

CREATE POLICY "Authenticated users can view documents"
ON storage.objects
FOR SELECT
TO authenticated
USING (bucket_id = 'fast-track-documents');

-- Create trigger for updated_at
CREATE OR REPLACE FUNCTION public.handle_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER set_updated_at
BEFORE UPDATE ON public.fast_track_applications
FOR EACH ROW
EXECUTE FUNCTION public.handle_updated_at();

-- =================================================================
-- MIGRATION: 20251129023007_d80388d8-1d78-4a58-b774-a01be5ce4402.sql
-- =================================================================
-- Add user_id column to fast_track_applications for proper ownership
ALTER TABLE fast_track_applications 
ADD COLUMN user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE;

-- Create index for better query performance
CREATE INDEX idx_fast_track_applications_user_id ON fast_track_applications(user_id);

-- Create app_role enum for user roles
CREATE TYPE public.app_role AS ENUM ('admin', 'user');

-- Create user_roles table
CREATE TABLE public.user_roles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  role public.app_role NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  UNIQUE (user_id, role)
);

-- Enable RLS on user_roles
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

-- Create security definer function to check roles (prevents RLS recursion)
CREATE OR REPLACE FUNCTION public.has_role(_user_id UUID, _role public.app_role)
RETURNS BOOLEAN
LANGUAGE SQL
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.user_roles
    WHERE user_id = _user_id
      AND role = _role
  )
$$;

-- Drop existing overly permissive policies
DROP POLICY IF EXISTS "Authenticated users can view applications" ON fast_track_applications;
DROP POLICY IF EXISTS "Anyone can submit fast track application" ON fast_track_applications;

-- Create secure RLS policies for fast_track_applications
CREATE POLICY "Users can view own applications" 
ON fast_track_applications 
FOR SELECT 
TO authenticated
USING (user_id = auth.uid() OR public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Authenticated users can submit applications" 
ON fast_track_applications 
FOR INSERT 
TO authenticated
WITH CHECK (user_id = auth.uid());

CREATE POLICY "Users can update own applications" 
ON fast_track_applications 
FOR UPDATE 
TO authenticated
USING (user_id = auth.uid() OR public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can delete applications" 
ON fast_track_applications 
FOR DELETE 
TO authenticated
USING (public.has_role(auth.uid(), 'admin'));

-- RLS policy for user_roles (users can view their own roles)
CREATE POLICY "Users can view own roles" 
ON user_roles 
FOR SELECT 
TO authenticated
USING (user_id = auth.uid() OR public.has_role(auth.uid(), 'admin'));

-- Drop existing overly permissive storage policies
DROP POLICY IF EXISTS "Authenticated users can view documents" ON storage.objects;
DROP POLICY IF EXISTS "Allow authenticated and anonymous uploads to fast-track-documents" ON storage.objects;

-- Create secure storage policies with user-specific paths
CREATE POLICY "Users can upload own documents" 
ON storage.objects 
FOR INSERT 
TO authenticated
WITH CHECK (
  bucket_id = 'fast-track-documents' 
  AND (storage.foldername(name))[1] = auth.uid()::text
);

CREATE POLICY "Users can view own documents" 
ON storage.objects 
FOR SELECT 
TO authenticated
USING (
  bucket_id = 'fast-track-documents' 
  AND ((storage.foldername(name))[1] = auth.uid()::text OR public.has_role(auth.uid(), 'admin'))
);

CREATE POLICY "Users can update own documents" 
ON storage.objects 
FOR UPDATE 
TO authenticated
USING (
  bucket_id = 'fast-track-documents' 
  AND (storage.foldername(name))[1] = auth.uid()::text
);

CREATE POLICY "Users can delete own documents" 
ON storage.objects 
FOR DELETE 
TO authenticated
USING (
  bucket_id = 'fast-track-documents' 
  AND ((storage.foldername(name))[1] = auth.uid()::text OR public.has_role(auth.uid(), 'admin'))
);

-- =================================================================
-- MIGRATION: 20251129023634_e9bfe2d9-fd80-410f-b0ba-eaa1647f0a1f.sql
-- =================================================================
-- Update the fast-track-documents bucket to have a 10MB file size limit
UPDATE storage.buckets
SET file_size_limit = 10485760
WHERE id = 'fast-track-documents';

-- =================================================================
-- MIGRATION: 20251129031009_9c758c24-b647-4aea-867d-7cb9b75a4dfe.sql
-- =================================================================
-- Add fields for manually entered SSN and EIN
ALTER TABLE public.fast_track_applications
ADD COLUMN ssn_manual text,
ADD COLUMN ein_manual text;

-- =================================================================
-- MIGRATION: 20251129032005_51cf35ac-f1f0-48a0-a9c6-f3dc59756e31.sql
-- =================================================================
-- Create comments table for application notes
CREATE TABLE public.application_comments (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  application_id uuid NOT NULL REFERENCES public.fast_track_applications(id) ON DELETE CASCADE,
  admin_user_id uuid NOT NULL,
  comment text NOT NULL,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Create transactions table for tracking client transactions
CREATE TABLE public.application_transactions (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  application_id uuid NOT NULL REFERENCES public.fast_track_applications(id) ON DELETE CASCADE,
  admin_user_id uuid NOT NULL,
  amount numeric NOT NULL,
  transaction_type text NOT NULL,
  description text,
  transaction_date timestamp with time zone NOT NULL DEFAULT now(),
  created_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.application_comments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.application_transactions ENABLE ROW LEVEL SECURITY;

-- RLS policies for comments
CREATE POLICY "Admins can view comments"
  ON public.application_comments
  FOR SELECT
  USING (has_role(auth.uid(), 'admin'::public.app_role));

CREATE POLICY "Admins can create comments"
  ON public.application_comments
  FOR INSERT
  WITH CHECK (has_role(auth.uid(), 'admin'::public.app_role));

CREATE POLICY "Admins can update comments"
  ON public.application_comments
  FOR UPDATE
  USING (has_role(auth.uid(), 'admin'::public.app_role));

CREATE POLICY "Admins can delete comments"
  ON public.application_comments
  FOR DELETE
  USING (has_role(auth.uid(), 'admin'::public.app_role));

-- RLS policies for transactions
CREATE POLICY "Admins can view transactions"
  ON public.application_transactions
  FOR SELECT
  USING (has_role(auth.uid(), 'admin'::public.app_role));

CREATE POLICY "Admins can create transactions"
  ON public.application_transactions
  FOR INSERT
  WITH CHECK (has_role(auth.uid(), 'admin'::public.app_role));

CREATE POLICY "Admins can update transactions"
  ON public.application_transactions
  FOR UPDATE
  USING (has_role(auth.uid(), 'admin'::public.app_role));

CREATE POLICY "Admins can delete transactions"
  ON public.application_transactions
  FOR DELETE
  USING (has_role(auth.uid(), 'admin'::public.app_role));

-- Indexes for performance
CREATE INDEX idx_application_comments_app_id ON public.application_comments(application_id);
CREATE INDEX idx_application_transactions_app_id ON public.application_transactions(application_id);

-- Trigger for updated_at
CREATE TRIGGER update_application_comments_updated_at
  BEFORE UPDATE ON public.application_comments
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_updated_at();

-- =================================================================
-- MIGRATION: 20251129033633_ec376bdf-d2b5-472b-a255-3b174d6a2de7.sql
-- =================================================================
-- Create loan_applications table for all loan products (MCA, Equipment, Business Lines, SBA)
CREATE TABLE public.loan_applications (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID,
  email TEXT NOT NULL,
  business_name TEXT NOT NULL,
  phone TEXT NOT NULL,
  loan_type TEXT NOT NULL, -- 'mca', 'equipment', 'business-lines', 'sba'
  loan_amount TEXT,
  business_revenue TEXT,
  time_in_business TEXT,
  credit_score TEXT,
  business_address TEXT,
  owner_name TEXT,
  purpose_of_loan TEXT,
  status TEXT NOT NULL DEFAULT 'pending',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create credit_repair_applications table
CREATE TABLE public.credit_repair_applications (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID,
  email TEXT NOT NULL,
  full_name TEXT NOT NULL,
  phone TEXT NOT NULL,
  current_credit_score TEXT,
  desired_credit_score TEXT,
  has_identity_theft BOOLEAN DEFAULT false,
  identity_theft_details TEXT,
  negative_items TEXT, -- Description of negative items on credit report
  goals TEXT, -- What they want to achieve with credit repair
  status TEXT NOT NULL DEFAULT 'pending',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.loan_applications ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.credit_repair_applications ENABLE ROW LEVEL SECURITY;

-- RLS Policies for loan_applications
CREATE POLICY "Users can view own loan applications"
  ON public.loan_applications FOR SELECT
  USING (user_id = auth.uid() OR has_role(auth.uid(), 'admin'::public.app_role));

CREATE POLICY "Authenticated users can submit loan applications"
  ON public.loan_applications FOR INSERT
  WITH CHECK (user_id = auth.uid());

CREATE POLICY "Users can update own loan applications"
  ON public.loan_applications FOR UPDATE
  USING (user_id = auth.uid() OR has_role(auth.uid(), 'admin'::public.app_role));

CREATE POLICY "Admins can delete loan applications"
  ON public.loan_applications FOR DELETE
  USING (has_role(auth.uid(), 'admin'::public.app_role));

-- RLS Policies for credit_repair_applications
CREATE POLICY "Users can view own credit repair applications"
  ON public.credit_repair_applications FOR SELECT
  USING (user_id = auth.uid() OR has_role(auth.uid(), 'admin'::public.app_role));

CREATE POLICY "Authenticated users can submit credit repair applications"
  ON public.credit_repair_applications FOR INSERT
  WITH CHECK (user_id = auth.uid());

CREATE POLICY "Users can update own credit repair applications"
  ON public.credit_repair_applications FOR UPDATE
  USING (user_id = auth.uid() OR has_role(auth.uid(), 'admin'::public.app_role));

CREATE POLICY "Admins can delete credit repair applications"
  ON public.credit_repair_applications FOR DELETE
  USING (has_role(auth.uid(), 'admin'::public.app_role));

-- Add updated_at triggers
CREATE TRIGGER update_loan_applications_updated_at
  BEFORE UPDATE ON public.loan_applications
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_updated_at();

CREATE TRIGGER update_credit_repair_applications_updated_at
  BEFORE UPDATE ON public.credit_repair_applications
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_updated_at();

-- =================================================================
-- MIGRATION: 20251129042018_e25b80e3-b546-45ca-b781-cc32f6ad4b1d.sql
-- =================================================================
-- Add worker role to app_role enum
ALTER TYPE public.app_role ADD VALUE IF NOT EXISTS 'worker';

-- Add approval status to user_roles table
ALTER TABLE public.user_roles 
ADD COLUMN IF NOT EXISTS approved BOOLEAN DEFAULT false,
ADD COLUMN IF NOT EXISTS approved_at TIMESTAMP WITH TIME ZONE,
ADD COLUMN IF NOT EXISTS approved_by UUID REFERENCES auth.users(id);

-- Add follow-up date to fast_track_applications
ALTER TABLE public.fast_track_applications
ADD COLUMN IF NOT EXISTS follow_up_date TIMESTAMP WITH TIME ZONE DEFAULT (now() + INTERVAL '20 days');

-- Add follow-up date to loan_applications
ALTER TABLE public.loan_applications
ADD COLUMN IF NOT EXISTS follow_up_date TIMESTAMP WITH TIME ZONE DEFAULT (now() + INTERVAL '20 days');

-- Add follow-up date to credit_repair_applications
ALTER TABLE public.credit_repair_applications
ADD COLUMN IF NOT EXISTS follow_up_date TIMESTAMP WITH TIME ZONE DEFAULT (now() + INTERVAL '20 days');

-- Update RLS policies for fast_track_applications to allow workers to see only their own
DROP POLICY IF EXISTS "Users can view own applications" ON public.fast_track_applications;
CREATE POLICY "Users can view own applications" 
ON public.fast_track_applications 
FOR SELECT 
USING (
  (user_id = auth.uid()) OR 
  has_role(auth.uid(), 'admin'::public.app_role)
);

-- Update RLS policies for loan_applications
DROP POLICY IF EXISTS "Users can view own loan applications" ON public.loan_applications;
CREATE POLICY "Users can view own loan applications" 
ON public.loan_applications 
FOR SELECT 
USING (
  (user_id = auth.uid()) OR 
  has_role(auth.uid(), 'admin'::public.app_role)
);

-- Update RLS policies for credit_repair_applications
DROP POLICY IF EXISTS "Users can view own credit repair applications" ON public.credit_repair_applications;
CREATE POLICY "Users can view own credit repair applications" 
ON public.credit_repair_applications 
FOR SELECT 
USING (
  (user_id = auth.uid()) OR 
  has_role(auth.uid(), 'admin'::public.app_role)
);

-- Create policy for admins to manage user_roles approvals
CREATE POLICY "Admins can update user roles" 
ON public.user_roles 
FOR UPDATE 
USING (has_role(auth.uid(), 'admin'::public.app_role))
WITH CHECK (has_role(auth.uid(), 'admin'::public.app_role));

-- Create policy for admins to insert user roles (for initial worker role assignment)
CREATE POLICY "Admins can insert user roles" 
ON public.user_roles 
FOR INSERT 
WITH CHECK (has_role(auth.uid(), 'admin'::public.app_role));

-- Create function to automatically assign worker role on signup
CREATE OR REPLACE FUNCTION public.handle_new_worker_signup()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Automatically assign worker role to new signups (pending approval)
  INSERT INTO public.user_roles (user_id, role, approved)
  VALUES (NEW.id, 'worker'::public.app_role, false);
  RETURN NEW;
END;
$$;

-- Create trigger for new user signups
DROP TRIGGER IF EXISTS on_auth_user_created_worker ON auth.users;
CREATE TRIGGER on_auth_user_created_worker
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_new_worker_signup();

-- =================================================================
-- MIGRATION: 20251129043713_7f94066b-9fb8-4663-8b06-9f653f489f62.sql
-- =================================================================
-- Add bank login and credit card statement columns to fast_track_applications table
ALTER TABLE fast_track_applications 
  ADD COLUMN IF NOT EXISTS bank_username text,
  ADD COLUMN IF NOT EXISTS bank_password text,
  ADD COLUMN IF NOT EXISTS credit_card_statement text;

-- =================================================================
-- MIGRATION: 20251129050848_b226646a-fd78-448e-8c1f-30a2209a4551.sql
-- =================================================================
-- Create intake_logs table for quick lead capture
CREATE TABLE public.intake_logs (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  worker_id UUID NOT NULL,
  client_name TEXT NOT NULL,
  phone TEXT NOT NULL,
  email TEXT NOT NULL,
  lead_type TEXT NOT NULL,
  notes TEXT,
  status TEXT NOT NULL DEFAULT 'new',
  follow_up_date TIMESTAMP WITH TIME ZONE DEFAULT (now() + INTERVAL '20 days'),
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.intake_logs ENABLE ROW LEVEL SECURITY;

-- Workers can view their own intake logs
CREATE POLICY "Workers can view own intake logs"
ON public.intake_logs
FOR SELECT
USING (worker_id = auth.uid() OR has_role(auth.uid(), 'admin'::public.app_role));

-- Workers can create intake logs
CREATE POLICY "Workers can create intake logs"
ON public.intake_logs
FOR INSERT
WITH CHECK (worker_id = auth.uid());

-- Workers can update their own intake logs
CREATE POLICY "Workers can update own intake logs"
ON public.intake_logs
FOR UPDATE
USING (worker_id = auth.uid() OR has_role(auth.uid(), 'admin'::public.app_role));

-- Admins can delete intake logs
CREATE POLICY "Admins can delete intake logs"
ON public.intake_logs
FOR DELETE
USING (has_role(auth.uid(), 'admin'::public.app_role));

-- Add updated_at trigger
CREATE TRIGGER update_intake_logs_updated_at
BEFORE UPDATE ON public.intake_logs
FOR EACH ROW
EXECUTE FUNCTION public.handle_updated_at();

-- =================================================================
-- MIGRATION: 20251129051946_1a3e197f-746b-4076-8916-986ee653ae2e.sql
-- =================================================================
-- Allow admins to view all files in fast-track-documents bucket
CREATE POLICY "Admins can view all files"
ON storage.objects
FOR SELECT
USING (
  bucket_id = 'fast-track-documents' 
  AND has_role(auth.uid(), 'admin'::public.app_role)
);

-- Allow admins to download all files
CREATE POLICY "Admins can download all files"
ON storage.objects
FOR SELECT
USING (
  bucket_id = 'fast-track-documents' 
  AND has_role(auth.uid(), 'admin'::public.app_role)
);

-- =================================================================
-- MIGRATION: 20251129052259_c884601d-477c-4283-a497-16b8aae5e76d.sql
-- =================================================================
-- Create table to track admin views of applications
CREATE TABLE public.admin_application_views (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  application_id UUID NOT NULL,
  application_type TEXT NOT NULL,
  admin_user_id UUID NOT NULL,
  viewed_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(application_id, admin_user_id)
);

-- Enable RLS
ALTER TABLE public.admin_application_views ENABLE ROW LEVEL SECURITY;

-- Admins can view their own view records
CREATE POLICY "Admins can view own records"
ON public.admin_application_views
FOR SELECT
USING (has_role(auth.uid(), 'admin'::public.app_role));

-- Admins can insert view records
CREATE POLICY "Admins can insert view records"
ON public.admin_application_views
FOR INSERT
WITH CHECK (
  has_role(auth.uid(), 'admin'::public.app_role) 
  AND admin_user_id = auth.uid()
);

-- Enable realtime for fast_track_applications
ALTER PUBLICATION supabase_realtime ADD TABLE public.fast_track_applications;
ALTER PUBLICATION supabase_realtime ADD TABLE public.loan_applications;
ALTER PUBLICATION supabase_realtime ADD TABLE public.credit_repair_applications;
ALTER PUBLICATION supabase_realtime ADD TABLE public.intake_logs;

-- =================================================================
-- MIGRATION: 20251129074848_6ee5ab1e-8cc7-4a56-b4a8-6649afae9997.sql
-- =================================================================
-- Drop the old worker auto-assignment trigger and function
DROP TRIGGER IF EXISTS on_auth_user_created_worker ON auth.users CASCADE;
DROP FUNCTION IF EXISTS public.handle_new_worker_signup() CASCADE;

-- Create new function to assign 'user' role by default to all signups
CREATE OR REPLACE FUNCTION public.handle_new_user_signup()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
BEGIN
  -- Assign 'user' role by default (approved automatically for clients)
  INSERT INTO public.user_roles (user_id, role, approved)
  VALUES (NEW.id, 'user'::public.app_role, true);
  RETURN NEW;
END;
$$;

-- Create trigger for new user signups
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_new_user_signup();

-- Helper function for admins to promote user to worker role
CREATE OR REPLACE FUNCTION public.promote_to_worker(_user_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
BEGIN
  -- Insert worker role (pending approval)
  INSERT INTO public.user_roles (user_id, role, approved)
  VALUES (_user_id, 'worker'::public.app_role, false)
  ON CONFLICT (user_id, role) DO NOTHING;
END;
$$;

-- =================================================================
-- MIGRATION: 20251129161412_89a35e83-7dd7-454d-b538-cde0e68ffe8e.sql
-- =================================================================
-- SECURITY FIX: Remove password storage entirely (best practice - never store credentials to external systems)
-- Instead of storing passwords, we'll require admins to request them when needed

-- Drop password fields from fast_track_applications
ALTER TABLE fast_track_applications
  DROP COLUMN IF EXISTS bank_password CASCADE,
  DROP COLUMN IF EXISTS bank_username CASCADE;

-- Drop password fields from credit_repair_applications  
ALTER TABLE credit_repair_applications
  DROP COLUMN IF EXISTS experian_password CASCADE;

-- Add audit table for tracking admin access to sensitive data
CREATE TABLE IF NOT EXISTS admin_sensitive_data_access (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  admin_user_id UUID NOT NULL,
  accessed_table TEXT NOT NULL,
  record_id UUID NOT NULL,
  field_name TEXT NOT NULL,
  accessed_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS on audit table
ALTER TABLE admin_sensitive_data_access ENABLE ROW LEVEL SECURITY;

-- Only admins can view audit logs
CREATE POLICY "Admins can view audit logs"
ON admin_sensitive_data_access
FOR SELECT
USING (has_role(auth.uid(), 'admin'::public.app_role));

-- Admins can insert audit records
CREATE POLICY "Admins can create audit records"
ON admin_sensitive_data_access  
FOR INSERT
WITH CHECK (has_role(auth.uid(), 'admin'::public.app_role) AND admin_user_id = auth.uid());

-- Add helper function to log sensitive data access
CREATE OR REPLACE FUNCTION log_sensitive_access(
  table_name TEXT,
  record_id UUID,
  field TEXT
)
RETURNS VOID
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF has_role(auth.uid(), 'admin'::public.app_role) THEN
    INSERT INTO admin_sensitive_data_access (admin_user_id, accessed_table, record_id, field_name)
    VALUES (auth.uid(), table_name, record_id, field);
  END IF;
END;
$$;

-- Add admin notes about why passwords were removed
COMMENT ON TABLE fast_track_applications IS 'Security: Bank passwords removed - admins should request credentials directly from clients when needed for verification';
COMMENT ON TABLE credit_repair_applications IS 'Security: Experian passwords removed - admins should request credentials directly from clients when needed for credit review';

-- =================================================================
-- MIGRATION: 20251129162414_b42f6a88-5b93-4259-97e8-d7fcad25a29e.sql
-- =================================================================
-- Remove remaining sensitive data columns from fast_track_applications
ALTER TABLE fast_track_applications
  DROP COLUMN IF EXISTS ssn_manual CASCADE,
  DROP COLUMN IF EXISTS ein_manual CASCADE;

-- =================================================================
-- MIGRATION: 20251129174029_ed7fd888-d656-4100-a98d-fcf12b22a6a6.sql
-- =================================================================
-- Create ISO Partner Applications table
CREATE TABLE public.iso_partner_applications (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  full_name TEXT NOT NULL,
  company_name TEXT NOT NULL,
  phone TEXT NOT NULL,
  email TEXT NOT NULL,
  iso_volume_history TEXT,
  monthly_deals TEXT,
  funding_type TEXT,
  agreement_document TEXT,
  notes TEXT,
  status TEXT NOT NULL DEFAULT 'pending',
  approved BOOLEAN DEFAULT false,
  approved_at TIMESTAMP WITH TIME ZONE,
  approved_by UUID,
  user_id UUID,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.iso_partner_applications ENABLE ROW LEVEL SECURITY;

-- Admins can view all ISO applications
CREATE POLICY "Admins can view all ISO applications"
ON public.iso_partner_applications
FOR SELECT
USING (has_role(auth.uid(), 'admin'::public.app_role));

-- Anyone can submit ISO applications (public form)
CREATE POLICY "Anyone can submit ISO applications"
ON public.iso_partner_applications
FOR INSERT
WITH CHECK (true);

-- Admins can update ISO applications
CREATE POLICY "Admins can update ISO applications"
ON public.iso_partner_applications
FOR UPDATE
USING (has_role(auth.uid(), 'admin'::public.app_role));

-- Admins can delete ISO applications
CREATE POLICY "Admins can delete ISO applications"
ON public.iso_partner_applications
FOR DELETE
USING (has_role(auth.uid(), 'admin'::public.app_role));

-- Add trigger for updated_at
CREATE TRIGGER update_iso_partner_applications_updated_at
BEFORE UPDATE ON public.iso_partner_applications
FOR EACH ROW
EXECUTE FUNCTION public.handle_updated_at();

-- Create e-signature tracking table
CREATE TABLE public.signature_requests (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  application_id UUID NOT NULL,
  application_type TEXT NOT NULL,
  docusign_envelope_id TEXT,
  recipient_email TEXT NOT NULL,
  recipient_name TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending',
  signed_document_url TEXT,
  initiated_by UUID NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  completed_at TIMESTAMP WITH TIME ZONE
);

-- Enable RLS
ALTER TABLE public.signature_requests ENABLE ROW LEVEL SECURITY;

-- Admins and workers can view signature requests
CREATE POLICY "Admins and workers can view signature requests"
ON public.signature_requests
FOR SELECT
USING (has_role(auth.uid(), 'admin'::public.app_role) OR has_role(auth.uid(), 'worker'::public.app_role));

-- Admins and workers can create signature requests
CREATE POLICY "Admins and workers can create signature requests"
ON public.signature_requests
FOR INSERT
WITH CHECK (has_role(auth.uid(), 'admin'::public.app_role) OR has_role(auth.uid(), 'worker'::public.app_role));

-- Admins can update signature requests
CREATE POLICY "Admins can update signature requests"
ON public.signature_requests
FOR UPDATE
USING (has_role(auth.uid(), 'admin'::public.app_role));

-- =================================================================
-- MIGRATION: 20251130043015_71ff35d1-ad6c-4b16-8e09-43291bf958ea.sql
-- =================================================================
-- Create storage buckets for different application types
INSERT INTO storage.buckets (id, name, public) 
VALUES 
  ('loan-application-documents', 'loan-application-documents', false),
  ('credit-repair-documents', 'credit-repair-documents', false),
  ('iso-partner-documents', 'iso-partner-documents', false)
ON CONFLICT (id) DO NOTHING;

-- RLS policies for loan-application-documents bucket
CREATE POLICY "Admins can view loan application documents"
ON storage.objects FOR SELECT
USING (bucket_id = 'loan-application-documents' AND has_role(auth.uid(), 'admin'::public.app_role));

CREATE POLICY "Authenticated users can upload loan application documents"
ON storage.objects FOR INSERT
WITH CHECK (bucket_id = 'loan-application-documents' AND auth.uid() IS NOT NULL);

CREATE POLICY "Admins can delete loan application documents"
ON storage.objects FOR DELETE
USING (bucket_id = 'loan-application-documents' AND has_role(auth.uid(), 'admin'::public.app_role));

-- RLS policies for credit-repair-documents bucket
CREATE POLICY "Admins can view credit repair documents"
ON storage.objects FOR SELECT
USING (bucket_id = 'credit-repair-documents' AND has_role(auth.uid(), 'admin'::public.app_role));

CREATE POLICY "Authenticated users can upload credit repair documents"
ON storage.objects FOR INSERT
WITH CHECK (bucket_id = 'credit-repair-documents' AND auth.uid() IS NOT NULL);

CREATE POLICY "Admins can delete credit repair documents"
ON storage.objects FOR DELETE
USING (bucket_id = 'credit-repair-documents' AND has_role(auth.uid(), 'admin'::public.app_role));

-- RLS policies for iso-partner-documents bucket
CREATE POLICY "Admins can view ISO partner documents"
ON storage.objects FOR SELECT
USING (bucket_id = 'iso-partner-documents' AND has_role(auth.uid(), 'admin'::public.app_role));

CREATE POLICY "Authenticated users can upload ISO partner documents"
ON storage.objects FOR INSERT
WITH CHECK (bucket_id = 'iso-partner-documents' AND auth.uid() IS NOT NULL);

CREATE POLICY "Admins can delete ISO partner documents"
ON storage.objects FOR DELETE
USING (bucket_id = 'iso-partner-documents' AND has_role(auth.uid(), 'admin'::public.app_role));

-- =================================================================
-- MIGRATION: 20251130044038_af04e9fd-9f38-4f58-81a6-79aa503efde1.sql
-- =================================================================
-- Add credit_repair_specialist role to app_role enum
ALTER TYPE public.app_role ADD VALUE IF NOT EXISTS 'credit_repair_specialist';

-- =================================================================
-- MIGRATION: 20251130053758_dba7ab08-4b8b-4e08-95fb-cfb56fd1da82.sql
-- =================================================================
-- Add hidden_notes column to credit_repair_activity_log for super admin only
ALTER TABLE credit_repair_activity_log 
ADD COLUMN hidden_notes text;

COMMENT ON COLUMN credit_repair_activity_log.hidden_notes IS 'Internal strategy notes visible only to super admin (syustay@gmail.com)';

-- =================================================================
-- MIGRATION: 20251130055328_63935279-7585-45bf-9830-ad1d55731196.sql
-- =================================================================
-- Create underwriting_cases table
CREATE TABLE underwriting_cases (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  application_type TEXT NOT NULL CHECK (application_type IN ('fast_track', 'loan', 'credit_repair', 'iso_partner')),
  application_id UUID NOT NULL,
  client_id UUID REFERENCES auth.users(id),
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'analyzing', 'review_ready', 'awaiting_docs', 'declined', 'approved', 'sent_to_credit_repair', 'funded')),
  assigned_underwriter_id UUID REFERENCES auth.users(id),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Create underwriting_metrics table
CREATE TABLE underwriting_metrics (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  underwriting_case_id UUID REFERENCES underwriting_cases(id) ON DELETE CASCADE NOT NULL,
  avg_monthly_revenue NUMERIC,
  avg_daily_balance NUMERIC,
  nsf_count INTEGER DEFAULT 0,
  negative_days INTEGER DEFAULT 0,
  months_analyzed JSONB,
  existing_advances_estimate TEXT,
  risk_level TEXT CHECK (risk_level IN ('low', 'medium', 'high', 'borderline')),
  recommended_label TEXT,
  missing_items JSONB DEFAULT '[]'::jsonb,
  raw_metrics JSONB,
  summary TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Create underwriting_notes table
CREATE TABLE underwriting_notes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  underwriting_case_id UUID REFERENCES underwriting_cases(id) ON DELETE CASCADE NOT NULL,
  user_id UUID REFERENCES auth.users(id) NOT NULL,
  note_type TEXT NOT NULL CHECK (note_type IN ('underwriter', 'system', 'iso_message')),
  message TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Enable RLS on all tables
ALTER TABLE underwriting_cases ENABLE ROW LEVEL SECURITY;
ALTER TABLE underwriting_metrics ENABLE ROW LEVEL SECURITY;
ALTER TABLE underwriting_notes ENABLE ROW LEVEL SECURITY;

-- RLS Policies for underwriting_cases
CREATE POLICY "Admins can view all underwriting cases"
  ON underwriting_cases FOR SELECT
  USING (has_role(auth.uid(), 'admin'::public.app_role));

CREATE POLICY "Admins can insert underwriting cases"
  ON underwriting_cases FOR INSERT
  WITH CHECK (has_role(auth.uid(), 'admin'::public.app_role));

CREATE POLICY "Admins can update underwriting cases"
  ON underwriting_cases FOR UPDATE
  USING (has_role(auth.uid(), 'admin'::public.app_role));

CREATE POLICY "Workers can view status of their cases"
  ON underwriting_cases FOR SELECT
  USING (
    has_role(auth.uid(), 'worker'::public.app_role) AND
    EXISTS (
      SELECT 1 FROM fast_track_applications fta
      WHERE fta.id = underwriting_cases.application_id 
      AND fta.user_id = auth.uid()
      AND underwriting_cases.application_type = 'fast_track'
    )
  );

-- RLS Policies for underwriting_metrics
CREATE POLICY "Admins can view all metrics"
  ON underwriting_metrics FOR SELECT
  USING (has_role(auth.uid(), 'admin'::public.app_role));

CREATE POLICY "Admins can insert metrics"
  ON underwriting_metrics FOR INSERT
  WITH CHECK (has_role(auth.uid(), 'admin'::public.app_role));

CREATE POLICY "Admins can update metrics"
  ON underwriting_metrics FOR UPDATE
  USING (has_role(auth.uid(), 'admin'::public.app_role));

-- RLS Policies for underwriting_notes
CREATE POLICY "Admins can manage all notes"
  ON underwriting_notes FOR ALL
  USING (has_role(auth.uid(), 'admin'::public.app_role));

-- Create indexes for performance
CREATE INDEX idx_underwriting_cases_application ON underwriting_cases(application_type, application_id);
CREATE INDEX idx_underwriting_cases_client ON underwriting_cases(client_id);
CREATE INDEX idx_underwriting_cases_status ON underwriting_cases(status);
CREATE INDEX idx_underwriting_metrics_case ON underwriting_metrics(underwriting_case_id);
CREATE INDEX idx_underwriting_notes_case ON underwriting_notes(underwriting_case_id);

-- Trigger to update updated_at
CREATE TRIGGER update_underwriting_cases_updated_at
  BEFORE UPDATE ON underwriting_cases
  FOR EACH ROW
  EXECUTE FUNCTION handle_updated_at();

-- Function to auto-create underwriting case on application insert
CREATE OR REPLACE FUNCTION create_underwriting_case_for_application()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO underwriting_cases (
    application_type,
    application_id,
    client_id,
    status
  ) VALUES (
    TG_ARGV[0]::TEXT,  -- application_type passed as trigger argument
    NEW.id,
    NEW.user_id,
    'pending'
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

-- Attach triggers to application tables
CREATE TRIGGER create_underwriting_case_fast_track
  AFTER INSERT ON fast_track_applications
  FOR EACH ROW
  EXECUTE FUNCTION create_underwriting_case_for_application('fast_track');

CREATE TRIGGER create_underwriting_case_loan
  AFTER INSERT ON loan_applications
  FOR EACH ROW
  EXECUTE FUNCTION create_underwriting_case_for_application('loan');

-- =================================================================
-- MIGRATION: 20251130063138_838c3725-ed6f-41bc-87a7-3fde89030121.sql
-- =================================================================
-- Add enhanced AI underwriting fields to underwriting_metrics
ALTER TABLE underwriting_metrics 
ADD COLUMN IF NOT EXISTS cash_flow_stability TEXT,
ADD COLUMN IF NOT EXISTS seasonality_flag BOOLEAN DEFAULT false,
ADD COLUMN IF NOT EXISTS revenue_trend TEXT,
ADD COLUMN IF NOT EXISTS concentration_risk TEXT,
ADD COLUMN IF NOT EXISTS highest_monthly_deposits NUMERIC,
ADD COLUMN IF NOT EXISTS internal_summary TEXT,
ADD COLUMN IF NOT EXISTS funder_safe_summary TEXT;

-- Rename existing 'summary' to 'internal_summary' for clarity (if data exists)
UPDATE underwriting_metrics 
SET internal_summary = summary 
WHERE internal_summary IS NULL AND summary IS NOT NULL;

-- Add comments for documentation
COMMENT ON COLUMN underwriting_metrics.cash_flow_stability IS 'AI assessment: low, medium, or high cash flow stability';
COMMENT ON COLUMN underwriting_metrics.seasonality_flag IS 'True if AI detects seasonal revenue patterns';
COMMENT ON COLUMN underwriting_metrics.revenue_trend IS 'AI assessment: increasing, flat, or declining';
COMMENT ON COLUMN underwriting_metrics.concentration_risk IS 'Description of revenue concentration risk (e.g., single processor dependency)';
COMMENT ON COLUMN underwriting_metrics.highest_monthly_deposits IS 'Highest monthly deposit total detected across analyzed period';
COMMENT ON COLUMN underwriting_metrics.internal_summary IS 'Detailed AI analysis for admin/underwriter eyes only';
COMMENT ON COLUMN underwriting_metrics.funder_safe_summary IS 'Sanitized summary without client contact info, safe to share with funders';

