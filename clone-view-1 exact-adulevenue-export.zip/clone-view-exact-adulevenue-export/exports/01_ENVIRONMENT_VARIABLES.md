# Environment Variables (Names Only)

**Project Ref:** tdzuhcswrojlleeupqvd  
**Export Date:** 2025-12-14  

## Supabase System Variables (Auto-configured)
- SUPABASE_URL
- SUPABASE_ANON_KEY
- SUPABASE_SERVICE_ROLE_KEY
- SUPABASE_PUBLISHABLE_KEY
- SUPABASE_DB_URL

## Application Secrets
- OPENAI_API_KEY
- RESEND_API_KEY
- TWILIO_ACCOUNT_SID
- TWILIO_AUTH_TOKEN
- TWILIO_PHONE_NUMBER
- RECAPTCHA_SECRET_KEY
- RECAPTCHA_SITE_KEY
- DOCUSIGN_INTEGRATION_KEY
- DOCUSIGN_SECRET_KEY
- DOCUSIGN_ACCOUNT_ID
- AI_GATEWAY_API_KEY

## Vite Frontend Variables
- VITE_SUPABASE_URL
- VITE_SUPABASE_ANON_KEY
- VITE_SUPABASE_PUBLISHABLE_KEY
- VITE_SUPABASE_PROJECT_ID

---
**Note:** Values are redacted for security. You must provide your own values when recreating this project.
